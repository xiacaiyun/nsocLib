/**
 * 
 */
package com.citigroup.impl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import com.citigroup.dao.IDatabaseOperation;
import com.citigroup.dbc.DatabaseConnection;

/**
 * @author lt05027
 *
 */
public class DatabaseOperation implements IDatabaseOperation{
	private Connection conn = null;
	private DatabaseConnection dbc = null;
	
	public DatabaseOperation() throws Exception{
		dbc = new DatabaseConnection();
		try {
			conn = dbc.getDatabaseConnection();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			throw e;
		}
	}

	@SuppressWarnings("finally")
	@Override
	public String getResourceName(String resourceSoeid) throws Exception {
		// TODO Auto-generated method stub
		String resourceName = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		String sql = "select rsrc_nm from rsrc_mstr where rsrc_soeid = ?";
		try{
			pstmt = this.conn.prepareStatement(sql);
			pstmt.setString(1, resourceSoeid);
			rs = pstmt.executeQuery();
			if(rs.next()){
				resourceName = rs.getString(1);
			}
			
			System.out.println("Inside Runner --->>> DatabaseOperation ......");
			System.out.println("Resource Name: " + resourceName);
		}catch(Exception e){
			throw e;
		}finally{
			this.dbc.close();
			return resourceName;
		}
		
	}
	
	public static void main(String[] args){
		
	}
	
	
}
