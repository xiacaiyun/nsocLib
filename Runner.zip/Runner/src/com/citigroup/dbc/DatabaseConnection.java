/**
 * 
 */
package com.citigroup.dbc;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

/**
 * @author lt05027
 *
 */
public class DatabaseConnection {

	private final String DBDRIVER = "oracle.jdbc.driver.OracleDriver";
	private final String DBURL = "jdbc:oracle:thin:@//gpd-8bf-0860.nam.nsroot.net:1550/US1TL3D.DEV.MW.NAM.INTL";
	private final String DBUSER = "fid91";
	private final String DBPASS = "dwh1592";
	private Connection conn = null;
	
	public Connection getDatabaseConnection() throws Exception{
		try {
			Class.forName(DBDRIVER);
			conn = DriverManager.getConnection(DBURL, DBUSER, DBPASS);
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			throw e;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			throw e;
		}
		
		return conn;
	}
	
	public void close() throws Exception{
		try {
			conn.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			throw e;
		}
	}
	
}
