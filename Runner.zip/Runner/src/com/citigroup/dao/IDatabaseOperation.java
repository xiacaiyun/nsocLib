/**
 * 
 */
package com.citigroup.dao;

/**
 * @author lt05027
 *
 */
public interface IDatabaseOperation {
	
	public String getResourceName(String resourceSoeid) throws Exception;
}
