/**
 * 
 */
package com.citigroup.use;

import java.io.IOException;
import java.net.URL;
import java.net.URLClassLoader;

import org.junit.Test;

import com.citigroup.dao.IDatabaseOperation;

/**
 * @author lt05027
 *
 */
public class UseDatabaseOperation {
	
	public void test(String resourceSoeid){
		String resourceName = null;
		URLClassLoader urlClassLoader = null;
		try{
			URL url = new URL("file:C:\\Users\\LT05027\\Desktop\\exported-jars\\Runner.jar");
			urlClassLoader = new URLClassLoader(new URL[]{url}, Thread.currentThread().getContextClassLoader());
			Class<?> clazz = urlClassLoader.loadClass("com.citigroup.impl.DatabaseOperation");
			IDatabaseOperation databaseOperation = (IDatabaseOperation)clazz.newInstance();
			resourceName = databaseOperation.getResourceName(resourceSoeid);
			
			System.out.println("Inside Launcher --->>> UseDatabaseOperation");
			System.out.println("Resource SOEID: " + resourceSoeid);
			System.out.println("Resource Name: " + resourceName);
			
		}catch(Exception e){
			e.printStackTrace();
		}finally{
			try {
				urlClassLoader.close();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
		}
	}
	
	@Test
	public void test(){
		this.test("lt05027");
	}
}
