package cn.nsoc.common.storer.option;

import cn.nsoc.common.storer.annotation.QueryOperator;

import java.util.List;

/**
 * Created by sam on 17-7-20.
 */
public class QueryItem {
    private String field;
    private QueryOperator operator;
    private Object value;

    public QueryItem(String field, QueryOperator operator) {
        this(field, operator, null);
    }

    public QueryItem(String field, QueryOperator operator, Object value) {
        setField(field);
        setOperator(operator);
        setValue(value);
    }

    public String getField() {
        return field;
    }

    public void setField(String field) {
        this.field = field;
    }

    public QueryOperator getOperator() {
        return operator;
    }

    public void setOperator(QueryOperator operator) {
        this.operator = operator;
    }

    public Object getValue() {
        return value;
    }

    public void setValue(Object value) {
        this.value = value;
    }

    public void toStatment(StringBuilder sb, List<QueryItem> values) {
        sb.append("%s");
        values.add(this);
    }
}
