package cn.nsoc.common.storer.option;

import java.util.List;
import java.util.Map;

/**
 * Created by sam on 16-7-14.
 */
public interface UpdateBuilder {

    UpdateBuilder include(String... fields);

    UpdateBuilder include(String field, UpdateOperator operator);

    UpdateBuilder exclude(String... fields);

    boolean hasInclude();

    boolean hasExclude();

    Map<String, UpdateOperator> getIncludes();

    List<String> getExcludes();
}
