package cn.nsoc.common.storer.context;

import cn.nsoc.common.storer.ValueConverter;
import cn.nsoc.common.storer.annotation.DbField;
import cn.nsoc.common.storer.annotation.DbQuery;
import org.springframework.util.StringUtils;

import java.lang.reflect.Field;

/**
 * Created by sam on 16-6-22.
 */
public class EntityProperty {

    private Field field;
    private String fieldName;
    private DbField dbField;
    private DbQuery dbQuery;
    private boolean bAutoIncrement;
    private boolean bIsKey;
    private boolean bRenamed;

    private ValueConverter valueConverter;

    public EntityProperty() {
        bAutoIncrement = false;
        bIsKey = false;
    }

    public Field getField() {
        return field;
    }

    public void setField(Field field) {
        this.field = field;
    }

    public void setIsKey(boolean bKey) {
        bIsKey = bKey;
    }

    public boolean getIsKey() {
        return bIsKey;
    }

    public void setAutoIncrement(boolean bAutoInc) {
        bAutoIncrement = bAutoInc;
    }

    public boolean getAutoIncrement() {
        return bAutoIncrement;
    }

    public DbField getDbField() {
        return dbField;
    }

    public void setDbField(DbField dbField) {
        this.dbField = dbField;
        if (StringUtils.hasText(dbField.name())) {
            fieldName = dbField.name();
            bRenamed = true;
        }
    }

    public ValueConverter getValueConverter() {
        return valueConverter;
    }

    public void setValueConverter(ValueConverter valueConverter) {
        this.valueConverter = valueConverter;
    }

    public DbQuery getDbQuery() {
        return dbQuery;
    }

    public void setDbQuery(DbQuery dbQuery) {
        this.dbQuery = dbQuery;
        if (StringUtils.hasText(dbQuery.name())) {
            fieldName = dbQuery.name();
            bRenamed = true;
        }
    }

    public String getFieldName() {
        return isRenamed() ? fieldName : field.getName();
    }

    public boolean isRenamed() {
        return bRenamed;
    }

    public String getFieldNameInClass() {
        return field.getName();
    }
}
