package cn.nsoc.common.storer.context;

import cn.nsoc.base.entity.sys.NSException;
import cn.nsoc.common.storer.ValueConverterFactory;
import cn.nsoc.common.storer.annotation.DbField;
import cn.nsoc.common.storer.annotation.DbQuery;
import cn.nsoc.common.storer.annotation.DbTable;
import cn.nsoc.common.storer.annotation.QueryOperator;
import org.springframework.util.Assert;
import org.springframework.util.StringUtils;

import java.lang.reflect.Field;
import java.lang.reflect.Modifier;
import java.lang.reflect.ParameterizedType;
import java.lang.reflect.Type;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.locks.ReentrantLock;
import java.util.regex.Pattern;

/**
 * Created by sam on 17-8-3.
 */
public class ContextParser {

    private String tblPrefix;
    private final ValueConverterFactory vcfactory;
    private final HashMap<Class<?>, EntityContext> typeMap = new HashMap<>();
    private final ReentrantLock mapLock = new ReentrantLock();

    private static final Pattern TrimIDList = Pattern.compile("IDList$", Pattern.CASE_INSENSITIVE);
    private static final Pattern TrimNotInIDList = Pattern.compile("NotInIDList$", Pattern.CASE_INSENSITIVE);
    private static final Pattern TrimFrom = Pattern.compile("^from", Pattern.CASE_INSENSITIVE);
    private static final Pattern TrimTo = Pattern.compile("^to", Pattern.CASE_INSENSITIVE);
    private static final Pattern TrimIsOrNotNull = Pattern.compile("IsOrNotNull$", Pattern.CASE_INSENSITIVE);


    public ContextParser() {
        this(null);
    }

    public ContextParser(ValueConverterFactory vcfactory) {
        this(vcfactory, "tbl_");
    }

    public ContextParser(ValueConverterFactory vcfactory, String tblPrefix) {
        this.vcfactory = vcfactory;
        this.tblPrefix = tblPrefix;
    }

    protected Class<?> getGenericClass(Field f){
        Class<?> fType = f.getType();
        if (List.class.isAssignableFrom(fType)){
            Type[] argTypes = ((ParameterizedType)f.getGenericType()).getActualTypeArguments();
            Assert.notNull(argTypes);
            Assert.isTrue(argTypes.length > 0);
            return (Class<?>)argTypes[0];
        }
        else if (Set.class.isAssignableFrom(fType)){
            Type[] argTypes = ((ParameterizedType)f.getGenericType()).getActualTypeArguments();
            Assert.notNull(argTypes);
            Assert.isTrue(argTypes.length > 0);
            return (Class<?>)argTypes[0];
        }
        else if (Map.class.isAssignableFrom(fType)){
            Type[] argTypes = ((ParameterizedType)f.getGenericType()).getActualTypeArguments();
            Assert.notNull(argTypes);
            Assert.isTrue(argTypes.length > 1);
            return (Class<?>)argTypes[1];
        }
        else {
            return fType;
        }
    }

    protected EntityProperty createEntityProperty(){
        return new EntityProperty();
    }

    protected EntityContext parseContext(Class<?> cls) throws NSException {
        EntityContext ctx = createEntityContext();
        ctx.setType(cls);

        DbTable tbl = cls.getAnnotation(DbTable.class);
        if ((tbl != null) && StringUtils.hasLength(tbl.name())) {
            ctx.setTableName(tbl.name());
        }
        else {
            ctx.setTableName(String.format("%s%s", this.getTblPrefix(), cls.getSimpleName().toLowerCase()));
        }

        for (Field f : cls.getDeclaredFields()) {
            if (Modifier.isStatic(f.getModifiers())) {
                continue;
            }

            f.setAccessible(true);

            EntityProperty prop = parseField(ctx, f);

            if (prop!= null){
                ctx.addProperty(prop);

                if (prop.isRenamed()) {
                    ctx.setHasRenamedField(true);
                }

                if (prop.getIsKey()) {
                    ctx.setKeyProperty(prop);
                }
            }
        }
        return ctx;
    }

    protected EntityProperty parseField(EntityContext ctx, Field f) throws NSException {
        EntityProperty prop = createEntityProperty();

        DbField fd = f.getAnnotation(DbField.class);
        if (fd != null) {
            prop.setDbField(fd);
            prop.setIsKey(fd.isKey());
            prop.setAutoIncrement(fd.isAutoIncrement());
        }

        DbQuery query = f.getAnnotation(DbQuery.class);
        Class<?> fType = f.getType();
        if (query != null) {
            prop.setDbQuery(query);

            switch (query.Operator()) {
                case In:
                case NotIn: {
                    if (f.getType() != List.class) {
                        throw new NSException(f.getName() + "必须是List<E>");
                    } else {
                        fType = getGenericClass(f);
                    }
                    break;
                }
                default:
                    break;
            }
        }

        prop.setField(f);
        prop.setValueConverter(getVcfactory().getValueConverter(fType));
        return prop;
    }

    public EntityContext createEntityContext(){
        return new EntityContext();
    }

    public EntityContext getObjectProperties(Class<?> cls) throws NSException {

        EntityContext ctx = typeMap.get(cls);
        if (ctx != null) {
            return ctx;
        }

        ctx = parseContext(cls);
        mapLock.lock();
        try {
            typeMap.putIfAbsent(cls, ctx);
            return ctx;
        } finally {
            mapLock.unlock();
        }
    }

    public EntityContext getObjectProperties(Object o) throws NSException {
        return getObjectProperties(o.getClass());
    }

    public String getTblPrefix() {
        return tblPrefix;
    }

    public ValueConverterFactory getVcfactory() {
        return vcfactory;
    }

    public String trimQueryFlag(QueryOperator operator, String fieldname){
        switch (operator){
            case In:
                return TrimIDList.matcher(fieldname).replaceFirst("");

            case NotIn:
                return TrimNotInIDList.matcher(fieldname).replaceFirst("");
            case IsOrNotNull:
                return TrimIsOrNotNull.matcher(fieldname).replaceFirst("");

            case LessThan:
            case LessEqual:
                return TrimTo.matcher(fieldname).replaceFirst("");

            case GreatThan:
            case GreatEqual:
                return TrimFrom.matcher(fieldname).replaceFirst("");
            default:
                return fieldname;
        }
    }
}
