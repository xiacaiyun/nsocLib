package cn.nsoc.common.storer.db;

import cn.nsoc.common.storer.entity.StorerTypeEnum;

import javax.sql.DataSource;

/**
 * Created by sam on 16-9-20.
 */
public class SqlServerJdbcStorer extends JdbcDbStorer {

    public SqlServerJdbcStorer(DataSource ds) {
        super(ds, StorerTypeEnum.sqlserver);
        setKeywordQuoter("[", "]");
    }
}
