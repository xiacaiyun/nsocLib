package cn.nsoc.common.storer.biz;

import org.springframework.util.StringUtils;

import java.util.*;
import java.util.function.Predicate;

/**
 * Created by xiacaiyun on 2016/12/8.
 */
public class SmartPageContext extends PageContext {

    private static final String SPLIT_CHAR = ",";
    private static final String ITEM_SPLIT_CHAR = "-";
    private Map<Integer, String> pageRecIds;


    public SmartPageContext(IPager pager) {
        this(pager,false);
    }

    public SmartPageContext(IPager pager, boolean withNextId) {
        this((pager == null) ? null : pager.getPageId(),
                (pager == null) ? null : pager.getCountPerPage(),
                (pager == null)  ? null : pager.getPageRecIds(),
                withNextId);
    }

    public SmartPageContext(Integer pageId, Integer countperpage, String pagerecids) {
        this(pageId,countperpage,pagerecids,false);
    }

    public SmartPageContext(Integer pageId, Integer countperpage, String pagerecids,boolean withNextId) {
        super(pageId, countperpage,withNextId);
        ClearRecordID();
        if ((this.getCurPage() > 1) && StringUtils.hasText(pagerecids)) {
            for (String pItem : pagerecids.split(SPLIT_CHAR)) {
                if (!StringUtils.hasText(pItem) || (!pItem.contains(ITEM_SPLIT_CHAR)))
                    continue;
                String[] items = pItem.split(ITEM_SPLIT_CHAR);
                Integer idx = Integer.valueOf(items[0]);
                String val = items[1].trim();
                if (idx != null && StringUtils.hasText(val)) {
                    pageRecIds.put(idx, val);
                }
            }
        }
    }

    public static String formatPageRecIds(Map<Integer, String> pagerecIds) {
        List<String> list = new ArrayList<>();
        for (Map.Entry<Integer, String> m : pagerecIds.entrySet()) {
            String tmp = String.format("%s%s%s", m.getKey(), ITEM_SPLIT_CHAR, m.getValue());
            list.add(tmp);
        }
        return String.join(SPLIT_CHAR, list);
    }

    public static class SmartPageOffsetModel {
        String recId;
        int SmartPageOffset;

        public String getRecId() {
            return recId;
        }

        public void setRecId(String recId) {
            this.recId = recId;
        }

        public int getSmartPageOffset() {
            return SmartPageOffset;
        }

        public void setSmartPageOffset(int smartPageOffset) {
            SmartPageOffset = smartPageOffset;
        }
    }

    public SmartPageOffsetModel GetSmartPageOffset() {
        SmartPageOffsetModel model = new SmartPageOffsetModel();
        int curpage = getCurPage();
        // if not found kvp = {0,null}
        Map.Entry<Integer, String> kvp = pageRecIds.entrySet().stream()
                .filter(p -> (p.getKey() < curpage) && StringUtils.hasText(p.getValue())).
                sorted(Comparator.comparing(Map.Entry::getKey)).findFirst().orElse(null);
        if (kvp != null) {
            model.recId = kvp.getValue();
            model.SmartPageOffset = kvp.getKey();
        }
        return model;
    }

    public int ClearRecordID() {
        pageRecIds = new HashMap<>();
        return 0;
    }

    public void SetRecordID(int pageId, String recId) {
        pageRecIds.put(pageId, recId);
    }

}
