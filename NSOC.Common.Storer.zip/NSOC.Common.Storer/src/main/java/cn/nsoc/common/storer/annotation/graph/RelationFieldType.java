package cn.nsoc.common.storer.annotation.graph;

public enum RelationFieldType {
    from,
    to,
    direction,
    mindepth,
    maxdepth
}
