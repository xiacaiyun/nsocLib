package cn.nsoc.common.storer.db;

import cn.nsoc.common.storer.context.EntityContext;
import cn.nsoc.common.storer.option.InsertBuilder;
import cn.nsoc.common.storer.option.InsertOption;
import cn.nsoc.common.storer.option.UpdateOperator;
import org.springframework.util.Assert;
import org.springframework.util.StringUtils;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by sam on 16-7-19.
 */
public class DbInsertBuilder implements InsertBuilder {
    private InsertOption insertOption;
    private final List<String> itemlist = new ArrayList<>();
    private DbStorer dbStorer = null;

    public DbInsertBuilder(DbStorer dbStorer) {
        Assert.notNull(dbStorer);
        this.dbStorer = dbStorer;
    }


    @Override
    public InsertOption getInsertOption() {
        return this.insertOption;
    }

    @Override
    public void setInsertOption(InsertOption option) {
        this.insertOption = option;
    }

    @Override
    public InsertBuilder append(String field, UpdateOperator operator) {
        if (StringUtils.hasText(field)) {

            switch (operator) {
                case Add:
                    itemlist.add(String.format(" %s = %s + Values(%s) ",
                            dbStorer.getQuoteField(field), dbStorer.getQuoteField(field), dbStorer.getQuoteField(field)));
                    break;
                case Set:
                    itemlist.add(String.format(" %s = Values(%s) ", dbStorer.getQuoteField(field), dbStorer.getQuoteField(field)));
                    break;
                default:
                    break;
            }
        }
        return this;
    }

    @Override
    public EntityContext getContext() {
        return null;
    }

    @Override
    public String toString() {
        if (itemlist.isEmpty())
            return "";
        else
            return String.join(",", itemlist);
    }
}
