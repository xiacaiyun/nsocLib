package cn.nsoc.common.storer.entity;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by bobwang on 10/24/16.
 */
public class MetaDesc {

    public static class ItemDesc {
        public boolean IsKey;
        public boolean IsAutocrement;
        public String ItemName;
        public String ItemType;
        public String TypeSize;

        public ItemDesc(String name, String type, String size, boolean key, boolean autocrement) {
            ItemName = name;
            ItemType = type;
            TypeSize = size;
            IsKey = key;
            IsAutocrement = autocrement;
        }

        @Override
        public String toString() {
            return String.format("%s_%s_%s_%s_%s", ItemName, ItemType, TypeSize, IsKey ? "1" : "0", IsAutocrement ? "1" : "0");
        }
    }

    private List<ItemDesc> items;

    public MetaDesc() {
        items = new ArrayList<>();
    }

    public List<ItemDesc> getEntrys() {
        return items;
    }

    public ItemDesc addDesc(String name, String type, String size, boolean key, boolean autocrement) {
        ItemDesc entry = new ItemDesc(name, type, size, key, autocrement);
        items.add(entry);
        return entry;
    }


}
