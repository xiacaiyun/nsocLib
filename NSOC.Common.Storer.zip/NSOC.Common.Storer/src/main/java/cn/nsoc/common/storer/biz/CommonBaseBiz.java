package cn.nsoc.common.storer.biz;

import cn.nsoc.base.entity.sys.NSException;
import cn.nsoc.common.storer.EntityCollection;
import cn.nsoc.common.storer.EntityQuery;
import cn.nsoc.common.storer.Storer;
import cn.nsoc.common.storer.db.DbStorer;
import cn.nsoc.common.storer.db.JdbcDbStorer;

/**
 * Created by sam on 17-9-21.
 */
public class CommonBaseBiz {
    private Storer storer;
    private Storer readOnlyStorer;

    public Storer getStorer() {
        return getStorer(false);
    }

    public Storer getStorer(boolean readonly) {

        if (readonly) {
            if (readOnlyStorer == null) {
                readOnlyStorer = JdbcDbStorer.getReadonlyInstance();
            }
            return readOnlyStorer;
        } else {
            if (storer == null) {
                storer = JdbcDbStorer.getInstance();
            }
            return storer;
        }
    }

    public boolean isDbStorer(){
        return getStorer() instanceof DbStorer;
    }

    public void setStorer(Storer storer) {
        this.storer = storer;
    }

    public void setStorer(Storer storer, Storer readOnlyStorer) {

        this.storer = storer;
        this.readOnlyStorer = readOnlyStorer;
    }

    public CommonBaseBiz() {
    }

    public CommonBaseBiz(Storer storer, Storer readOnlyStorer) {
        this();
        setStorer(storer, readOnlyStorer);
    }

    public CommonBaseBiz(String name) {
        this(JdbcDbStorer.getInstance(name), JdbcDbStorer.getInstance(name, true));
    }

    public CommonBaseBiz(Storer storer) {
        this(storer, null);
    }


    public <E, Q extends EntityQuery, C extends EntityCollection<E, Q>> C load(C me, PageContext ctx) throws NSException {
        EntityQuery query = me.getQuery();
        query.start = ctx.getStart();

        query.count = ctx.getCountPerPage() + (ctx.isWithNextId() ? 1 : 0);
        getStorer().load(me);
        ctx.setCollection(me);
        return me;
    }

    public  <E, Q extends EntityQuery, C extends EntityCollection<E,Q>>  C load(C me) throws NSException {
        return getStorer().load(me);
    }

}
