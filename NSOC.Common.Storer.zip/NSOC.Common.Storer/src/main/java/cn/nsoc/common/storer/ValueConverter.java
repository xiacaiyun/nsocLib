package cn.nsoc.common.storer;

import cn.nsoc.base.entity.sys.NSException;

/**
 * Created by sam on 16-6-22.
 */
public interface ValueConverter {
    Object toDsValue(Object me);

    Object fromDsValue(Object me) throws NSException;
}
