package cn.nsoc.common.storer.biz;

/**
 * Created by sam on 17-2-7.
 * 分页Model,用于分页的List
 */
public class PagedModel implements IPager {

    private Integer pageId;

    private Integer countPerPage;

    private String pagerecids;

    @Override
    public Integer getPageId() {
        return pageId;
    }

    @Override
    public void setPageId(Integer pageId) {
        this.pageId = pageId;
    }

    @Override
    public Integer getCountPerPage() {
        return countPerPage;
    }

    @Override
    public void setCountPerPage(Integer countPerPage) {
        this.countPerPage = countPerPage;
    }

    @Override
    public String getPageRecIds() {
        return pagerecids;
    }

    @Override
    public void setPageRecIds(String pagerecids) {
        this.pagerecids = pagerecids;
    }
}
