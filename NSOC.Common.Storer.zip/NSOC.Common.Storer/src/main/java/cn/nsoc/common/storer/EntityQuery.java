package cn.nsoc.common.storer;

import cn.nsoc.common.storer.annotation.DbField;
import cn.nsoc.common.storer.option.SelectBuilder;

/**
 * Created by sam on 16-6-8.
 */
public class EntityQuery {

    @DbField(isRequired = false)
    public int start = 0;

    @DbField(isRequired = false)
    public String nextRow;

    @DbField(isRequired = false)
    public int count = Integer.MAX_VALUE;

    @DbField(isRequired = false)
    public long totalCount;

    @DbField(isRequired = false)
    public boolean skipTotalCount = false;

    @DbField(isRequired = false)
    public boolean partialMode;

    @DbField(isRequired = false)
    public Enum orderBy;

    @DbField(isRequired = false)
    public Enum groupBy;

    @DbField(isRequired = false)
    public SelectBuilder selectFields;
}
