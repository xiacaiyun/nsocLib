package cn.nsoc.common.storer.db;

import cn.nsoc.common.storer.EntityCollection;
import cn.nsoc.common.storer.EntityQuery;
import cn.nsoc.common.storer.annotation.DbField;
import cn.nsoc.common.storer.annotation.DbTable;

/**
 * Created by sam on 17-7-16.
 */
public class CTest1 {
    @DbTable(name = "tbl_test1")
    public static class Entity {
        @DbField(isKey = true)
        private int a;
        private long b;
        private int c;
        private int d;

        public int getA() {
            return a;
        }

        public void setA(int a) {
            this.a = a;
        }

        public long getB() {
            return b;
        }

        public void setB(long b) {
            this.b = b;
        }

        public int getC() {
            return c;
        }

        public void setC(int c) {
            this.c = c;
        }

        public int getD() {
            return d;
        }

        public void setD(int d) {
            this.d = d;
        }
    }

    public static class Query extends EntityQuery {
        private Integer a;
        private Integer b;
        private Integer c;
        private Integer d;

        public Integer getA() {
            return a;
        }

        public void setA(Integer a) {
            this.a = a;
        }

        public Integer getB() {
            return b;
        }

        public void setB(Integer b) {
            this.b = b;
        }

        public Integer getC() {
            return c;
        }

        public void setC(Integer c) {
            this.c = c;
        }

        public Integer getD() {
            return d;
        }

        public void setD(Integer d) {
            this.d = d;
        }
    }

    public static class Coll extends EntityCollection<Entity, Query> {

        public Coll() {
            super(Entity.class, Query.class);
        }

        public Coll(Query query) {
            this();

            setQuery(query);
        }
    }
}
