package cn.nsoc.common.storer.db;

import cn.nsoc.common.storer.EntityCollection;
import cn.nsoc.common.storer.EntityQuery;
import cn.nsoc.common.storer.annotation.DbField;
import cn.nsoc.common.storer.annotation.DbTable;

import java.sql.Timestamp;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.Date;


/**
 * Created by chenxl on 2017/10/20.
 */
public class CTestTime {
    @DbTable(name = "tbl_testtime")
    public static class Entity {
        @DbField(isKey = true, isAutoIncrement = true)
        private Integer id;
        private LocalDateTime timestamp;
        private LocalDateTime date;
        private LocalDateTime datetime;

        public Integer getId() {
            return id;
        }

        public void setId(Integer id) {
            this.id = id;
        }

        public LocalDateTime getTimestamp() {
            return timestamp;
        }

        public void setTimestamp(LocalDateTime timestamp) {
            this.timestamp = timestamp;
        }

        public LocalDateTime getDate() {
            return date;
        }

        public void setDate(LocalDateTime date) {
            this.date = date;
        }

        public LocalDateTime getDatetime() {
            return datetime;
        }

        public void setDatetime(LocalDateTime datetime) {
            this.datetime = datetime;
        }
    }

    public static class Query extends EntityQuery {

        private Integer id;
        private LocalDateTime timestamp;
        private LocalDateTime date;
        private LocalDateTime datetime;

        public Integer getId() {
            return id;
        }

        public void setId(Integer id) {
            this.id = id;
        }

        public LocalDateTime getTimestamp() {
            return timestamp;
        }

        public void setTimestamp(LocalDateTime timestamp) {
            this.timestamp = timestamp;
        }

        public LocalDateTime getDate() {
            return date;
        }

        public void setDate(LocalDateTime date) {
            this.date = date;
        }

        public LocalDateTime getDatetime() {
            return datetime;
        }

        public void setDatetime(LocalDateTime datetime) {
            this.datetime = datetime;
        }
    }
    public static class QueryDate extends EntityQuery {

        private Integer id;
        private LocalDate timestamp;
        private LocalDate date;
        private LocalDate datetime;

        public Integer getId() {
            return id;
        }

        public void setId(Integer id) {
            this.id = id;
        }

        public LocalDate getTimestamp() {
            return timestamp;
        }

        public void setTimestamp(LocalDate timestamp) {
            this.timestamp = timestamp;
        }

        public LocalDate getDate() {
            return date;
        }

        public void setDate(LocalDate date) {
            this.date = date;
        }

        public LocalDate getDatetime() {
            return datetime;
        }

        public void setDatetime(LocalDate datetime) {
            this.datetime = datetime;
        }
    }

    public static class Coll extends EntityCollection<CTestTime.Entity, CTestTime.Query> {

        public Coll() {
            super(CTestTime.Entity.class, CTestTime.Query.class);
        }

        public Coll(CTestTime.Query query) {
            this();

            setQuery(query);
        }
    }

    public static class CollQueryDate extends EntityCollection<CTestTime.Entity, CTestTime.QueryDate> {

        public CollQueryDate() {
            super(CTestTime.Entity.class, CTestTime.QueryDate.class);
        }

        public CollQueryDate(CTestTime.QueryDate query) {
            this();

            setQuery(query);
        }
    }
}
