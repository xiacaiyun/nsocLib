package cn.nsoc.common.storer.db;

import cn.nsoc.common.storer.annotation.QueryOperator;
import cn.nsoc.common.storer.biz.PageContext;
import cn.nsoc.common.storer.option.QueryBuilder;
import junit.framework.TestCase;
import org.apache.commons.dbcp2.BasicDataSource;

/**
 * Created by sam on 17-7-16.
 */
public class JdbcDbStorerTest extends TestCase {

    private JdbcDbStorer dbStorer;

    public void setUp() throws Exception {
        super.setUp();

        BasicDataSource dsTest = new BasicDataSource();
        dsTest.setDriverClassName("com.mysql.cj.jdbc.Driver");
        dsTest.setUrl("jdbc:mysql://192.168.1.39:34006/db_test?allowMultiQueries=true&useUnicode=true&characterEncoding=UTF8&autoReconnect=true&failOverReadOnly=false&zeroDateTimeBehavior=convertToNull&serverTimezone=UTC");
        dsTest.setUsername("test");
        dsTest.setPassword("tttttt");
        dsTest.setInitialSize(3);

        dbStorer = JdbcDbStorer.createJdbcDbStorer("mysql", dsTest);
    }

    // 测试 简单 QueryBuilder
    public void testBuildConditions1() throws Exception {

        DbSelectBuilder dbSelectBuilder = new DbSelectBuilder(dbStorer, null);

        dbSelectBuilder.addQuery(new QueryBuilder().and("a", QueryOperator.Equal, 3)
                .or("b", QueryOperator.Equal, 3)
                .or("c", QueryOperator.Equal, 3));


        CTest1.Query query = new CTest1.Query();
        query.selectFields = dbSelectBuilder;

        CTest1.Coll coll = new CTest1.Coll(query);

        dbStorer.load(coll);

        assertTrue(!coll.isEmpty());

    }

    // 测试 嵌套 QueryBuilder
    public void testBuildConditions2() throws Exception {

        DbSelectBuilder dbSelectBuilder = new DbSelectBuilder(dbStorer, null);


        QueryBuilder inner = new QueryBuilder();
        inner.add("b", QueryOperator.GreatEqual, 5)
                .and("c", QueryOperator.LessEqual, 10);

        dbSelectBuilder.addQuery(new QueryBuilder().and("a", QueryOperator.Equal, 3)
                .or(inner));

        CTest1.Query query = new CTest1.Query();
        query.selectFields = dbSelectBuilder;

        CTest1.Coll coll = new CTest1.Coll(query);

        dbStorer.load(coll);

        assertTrue(!coll.isEmpty());

    }


    // 测试 Query with QueryBuilder
    public void testBuildConditions3() throws Exception {

        DbSelectBuilder dbSelectBuilder = new DbSelectBuilder(dbStorer, null);
        QueryBuilder inner = new QueryBuilder();
        inner.add("b", QueryOperator.GreatEqual, 5)
                .and("c", QueryOperator.LessEqual, 10);

        dbSelectBuilder.addQuery(new QueryBuilder().or(inner));


        CTest1.Query query = new CTest1.Query();
        query.setA(3);
        query.selectFields = dbSelectBuilder;

        CTest1.Coll coll = new CTest1.Coll(query);

        dbStorer.load(coll);

        assertTrue(!coll.isEmpty());

    }

    // 测试 Query without QueryBuilder
    public void testBuildConditions4() throws Exception {

        CTest1.Query query = new CTest1.Query();
        query.setA(3);

        CTest1.Coll coll = new CTest1.Coll(query);

        dbStorer.load(coll);

        assertTrue(coll.size() == 1);

    }

    // 测试 不同 operator 的 QueryBuilder
    public void testBuildConditions5() throws Exception {
        DbSelectBuilder dbSelectBuilder = new DbSelectBuilder(dbStorer, null);
        dbSelectBuilder.addQuery(new QueryBuilder().and("a", QueryOperator.GreatEqual, 10));
        CTest2.Query query = new CTest2.Query();
        query.selectFields = dbSelectBuilder;
        CTest2.Coll coll = new CTest2.Coll(query);
        dbStorer.load(coll);
        assertTrue(!coll.isEmpty());


        dbSelectBuilder = new DbSelectBuilder(dbStorer, null);
        dbSelectBuilder.addQuery(new QueryBuilder().and("b", QueryOperator.Like, "abc"));
        query.selectFields = dbSelectBuilder;
        dbStorer.load(coll);
        assertTrue(!coll.isEmpty());
    }





    // 测试 Query without QueryBuilder
    public void testIUD() throws Exception {
        CTest1.Entity entity = new CTest1.Entity();
        entity.setB(1000000L);
        entity.setC(200);
        entity.setD(300);

        dbStorer.insert(entity);
        assertTrue(entity.getA() > 0);


        entity.setB(1000001L);
        entity.setC(201);
        entity.setD(301);

        dbStorer.update(entity);


        CTest1.Query query = new CTest1.Query();
        query.setA(entity.getA());
        CTest1.Coll coll = (CTest1.Coll) dbStorer.load(new CTest1.Coll(query));

        CTest1.Entity found = coll.firstOrDefault();

        assertNotNull(found);
        assertTrue(found.getB() == 1000001L);
        assertTrue(found.getC() == 201);
        assertTrue(found.getD() == 301);

        entity.setC(202);
        entity.setD(302);

        DbUpdateBuilder ub = new DbUpdateBuilder(dbStorer);
        ub.exclude("b");
        dbStorer.update(entity, ub);

        coll = (CTest1.Coll) dbStorer.load(new CTest1.Coll(query));
        found = coll.firstOrDefault();

        assertNotNull(found);
        assertTrue(found.getB() == 1000001L);
        assertTrue(found.getC() == 202);
        assertTrue(found.getD() == 302);


        entity.setD(303);

        ub = new DbUpdateBuilder(dbStorer);
        ub.include("d");
        dbStorer.update(entity, ub);

        coll = (CTest1.Coll) dbStorer.load(new CTest1.Coll(query));
        found = coll.firstOrDefault();

        assertNotNull(found);
        assertTrue(found.getB() == 1000001L);
        assertTrue(found.getC() == 202);
        assertTrue(found.getD() == 303);


        dbStorer.delete(query, CTest1.Entity.class);
        coll = (CTest1.Coll) dbStorer.load(new CTest1.Coll(query));
        assertTrue(coll.isEmpty());


        dbStorer.delete(entity);
    }

    // 测试 Query with
    public void testQuery() throws Exception {
        CTest1.Entity entity = new CTest1.Entity();
        entity.setB(1000000L);
        entity.setC(200);
        entity.setD(300);

        dbStorer.insert(entity);
        assertTrue(entity.getA() > 0);


        DbSelectBuilder dbSelectBuilder = new DbSelectBuilder(dbStorer, null);
        dbSelectBuilder.addField("b","sum(b)");
        dbSelectBuilder.addField("c","count(c)");

        CTest1.Query query = new CTest1.Query();
        query.selectFields = dbSelectBuilder;


        CTest1.Coll coll = new CTest1.Coll(query);

        dbStorer.load(coll);

        assertTrue(!coll.isEmpty());
        CTest1.Entity stat = coll.firstOrDefault();
        assertTrue(stat.getB() >= entity.getB());
        assertTrue(stat.getC() >= 1);

        dbStorer.delete(entity);
    }
}