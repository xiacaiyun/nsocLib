package cn.nsoc.common.storer.db;

import cn.nsoc.common.storer.biz.CommonBaseBiz;
import cn.nsoc.common.storer.biz.PageContext;
import junit.framework.TestCase;
import org.apache.commons.dbcp2.BasicDataSource;

public class CommonBaseBizTest extends TestCase {

    private JdbcDbStorer dbStorer;

    public void setUp() throws Exception {
        super.setUp();

        BasicDataSource dsTest = new BasicDataSource();
        dsTest.setDriverClassName("com.mysql.cj.jdbc.Driver");
        dsTest.setUrl("jdbc:mysql://192.168.1.39:34006/db_test?allowMultiQueries=true&useUnicode=true&characterEncoding=UTF8&autoReconnect=true&failOverReadOnly=false&zeroDateTimeBehavior=convertToNull&serverTimezone=UTC");
        dsTest.setUsername("test");
        dsTest.setPassword("tttttt");
        dsTest.setInitialSize(3);

        dbStorer = JdbcDbStorer.createJdbcDbStorer("mysql", dsTest);
    }

    public void testLoadWithPageContext() throws Exception {

        CTest1.Entity entity = new CTest1.Entity();
        entity.setB(100L);
        entity.setC(200);
        entity.setD(300);

        CommonBaseBiz biz = new CommonBaseBiz(dbStorer);

        dbStorer.insert(entity);
        assertTrue(entity.getA() > 0);

        PageContext pctx = new PageContext(null,null);
        assertTrue(pctx.getCountPerPage() != Integer.MAX_VALUE);


        CTest1.Coll coll = biz.load(new CTest1.Coll(),pctx);

        assertTrue(pctx.getCountCurPage() > 0);
        assertEquals(pctx.getCountCurPage(),coll.size());
        assertTrue(pctx.getTotalCount() > 0);
        assertTrue(pctx.getTotalPage() > 0);

        dbStorer.delete(entity);
    }
}