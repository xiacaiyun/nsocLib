$(function(){
	//页面加载完成之后执行
	pageInit();
});
function pageInit(){
     // jsonReader : {
     //         root: "rows",    // json中代表实际模型数据的入口
     //           page: "page",    // json中代表当前页码的数据
     //           total: "total",    // json中代表页码总数的数据
     //           records: "records", // json中代表数据行总数的数据
     //           repeatitems: true, // 如果设为false，则jqGrid在解析json时，会根据name来搜索对应的数据元素（即可以json中元素可以不按顺序）；而所使用的name是来自于colModel中的name设定。
     //           cell: "cell",
     //           id: "id",
     //           userdata: "userdata",
     //            subgrid: {
     //                root:"rows",
     //                   repeatitems: true,
     //                   cell:"cell"
     //            }}
	//创建jqGrid组件
	$("#list2").jqGrid(
			{
				url : '../helloform',//组件创建完成之后请求数据的url
				datatype : "json",//请求数据返回的类型。可选json,xml,txt
				colNames : [ 'Inv No', 'Date', 'Client', 'Amount', 'Tax','Total', 'Notes' ],//jqGrid的列显示名字
				colModel : [ //jqGrid每一列的配置信息。包括名字，索引，宽度,对齐方式.....
				             {name : 'id',index : 'id',width : 55,editable:true},
				             {name : 'invdate',index : 'invdate',width : 90},
				             {name : 'name',index : 'name asc, invdate',width : 100},
				             {name : 'amount',index : 'amount',width : 80,align : "right"},
				             {name : 'tax',index : 'tax',width : 80,align : "right"},
				             {name : 'total',index : 'total',width : 80,align : "right"},
				             {name : 'note',index : 'note',width : 150,sortable : false}
				           ],
                // jsonReader : {
                //     root: "page.list",
                //     page: "page.currPage",
                //     total: "page.totalPage",
                //     records: "page.totalCount"
                // },
                rownumbers: true,
                styleUI: 'Bootstrap',
				rowNum : 12,//一页显示多少条
				rowList : [ 10, 20, 30 ],//可供用户选择一页显示多少条
				pager : '#pager2',//表格页脚的占位符(一般是div)的id
				sortname : 'id',//初始化的时候排序的字段
				sortorder : "desc",//排序方式,可选desc,asc
				viewrecords : true,
				caption : "JSON Example",//表格的标题名字
			});
	/*创建jqGrid的操作按钮容器*/
	/*可以控制界面上增删改查的按钮是否显示*/
    $("#list2").jqGrid('navGrid', '#pager2', {edit : true,add : true,del : true});
}