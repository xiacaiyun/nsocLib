package cn.nsoc.bizmon.biz.dw;

import java.util.List;

public class ESResult<T> {

	private long total;
	private long current;
	private List<T> data;

	public long getTotal() {
		return total;
	}

	public void setTotal(long total) {
		this.total = total;
	}

	public long getCurrent() {
		return current;
	}

	public void setCurrent(long current) {
		this.current = current;
	}

	public List<T> getData() {
		return data;
	}

	public void setData(List<T> data) {
		this.data = data;
	}

}
