package cn.nsoc.bizmon.biz.dw.entity;

public class DevMobile {
	String mobile;
	String mac;
	public String getMobile() {
		return mobile;
	}
	public void setMobile(String mobile) {
		this.mobile = mobile;
	}
	public String getMac() {
		return mac;
	}
	public void setMac(String mac) {
		this.mac = mac;
	}
	
}
