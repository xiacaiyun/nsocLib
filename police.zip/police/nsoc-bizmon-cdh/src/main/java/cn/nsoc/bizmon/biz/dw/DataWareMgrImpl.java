package cn.nsoc.bizmon.biz.dw;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import cn.nsoc.base.entity.sys.NSException;
import cn.nsoc.bizmon.biz.dw.entity.DevGreatSearch;
import cn.nsoc.bizmon.entity.api.CollideRequest;
import cn.nsoc.bizmon.entity.api.Person;
import cn.nsoc.bizmon.entity.api.SummaryResponse;
import cn.nsoc.nspider.app.police.entity.rule.TrackCatelog;

@Service("dataWareMgr")
public class DataWareMgrImpl implements DataWareMgr {
    @Autowired
    ElasticSearchMgr esMgr;
    @Autowired
    HBaseMgr hbaseMgr;
    @Autowired
    SparkMgr sparkMgr;
    @Autowired
    Neo4jMgr neo4jMgr;
    
    @Override
    public List<SummaryResponse> summary(String type, String val, long start, long end,
            int rowStart, int rowCount) throws NSException {
        return esMgr.summary(type, val, start, end, rowStart, rowCount);
    }
    
    @Override
    public List<String> findImgs(long start, long end, String pid) throws NSException {
        return hbaseMgr.findImgs(pid, start, end);
    }
    
    @Override
    public ESResult<DevGreatSearch> search(String keyword, TrackCatelog tranType,
            String subtype, int rowStart, int rowCount) {
        return esMgr.search(keyword, tranType, subtype, rowStart, rowCount);
    }

    @Override
    public Person findInfo(String searchid) {
        return esMgr.findInfo(searchid);
    }

    @Override
    public String findIconByPid(String pid) {
        return hbaseMgr.findIconByPid(pid);
    }

    @Override
    public List<Map<String, Object>> findIdFromVirt(String account) throws NSException {
        return esMgr.findIdFromVirt(account);
    }

    @Override
    public List<Map<String, Object>> findVirtById(String pid, String mobile) throws NSException {
        return esMgr.findVirtById(pid, mobile);
    }

    @Override
    public String findMacFromMobile(String mobile) throws NSException {
        return esMgr.findMacFromMobile(mobile);
    }

    @Override
    public String findMobileFromMac(String mac) throws NSException {
        return esMgr.findMobileFromMac(mac);
    }

    @Override
    public List<Map<String, Object>> macTrace(long start, long end, String mac) throws NSException {
        return hbaseMgr.macTrace(start, end, mac);
    }

    @Override
    public List<Map<String, Object>> fulTrace(long start, long end, String pid, String mobile)
            throws NSException {
        return esMgr.fulTrace(start, end, pid, mobile);
    }

    @Override
    public List<Map<String, Object>> collide(List<CollideRequest> models, int min)
            throws NSException {
        return sparkMgr.collide(models, min);
    }

    @Override
    public List<Map<String, Object>> relation(List<Map<String, String>> virtuals)
            throws NSException {
        return esMgr.relation(virtuals);
    }

    @Override
    public List<Map<String, Object>> findChat(String type, String val, long start, long end,
            int rowStart, int rowCount) throws NSException {
        return esMgr.findChat(type, val, start, end, rowStart, rowCount);
    }

    @Override
    public List<Map<String, Object>> findWbonline(String pid, int start, int limit)
            throws NSException {
        return hbaseMgr.findWbonline(pid, start, limit);
    }

    @Override
    public List<Map<String, Object>> findWifiOnline(String pid, String mobile, int start, int limit)
            throws NSException {
        List<Map<String, Object>> result = new ArrayList<>();
        if(StringUtils.isNotBlank(pid)) {
            result.addAll(hbaseMgr.findWifiOnline(pid, start, limit));
        }
        if(StringUtils.isNotBlank(mobile)) {
            result.addAll(hbaseMgr.findWifiOnline(mobile, start, limit));
        }
        return result;
    }

    @Override
    public List<Map<String, Object>> findMail(String pid, String mobile, int start, int limit)
            throws NSException {
        return hbaseMgr.findMail(pid, start, limit);
    }

    @Override
    public List<Map<String, Object>> findHttp(String pid, String mobile, int start, int limit)
            throws NSException {
        return hbaseMgr.findHttp(pid, start, limit);
    }

    @Override
    public String findImgByVK(String vk) {
        return hbaseMgr.findImgByVK(vk);
    }

    @Override
    public long findHotstat(String servicecode, long time) {
        return hbaseMgr.findHotstat(servicecode, time);
    }

}
