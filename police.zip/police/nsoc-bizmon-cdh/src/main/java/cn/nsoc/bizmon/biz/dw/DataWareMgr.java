package cn.nsoc.bizmon.biz.dw;

import java.util.List;
import java.util.Map;
import cn.nsoc.base.entity.sys.NSException;
import cn.nsoc.bizmon.biz.dw.entity.DevGreatSearch;
import cn.nsoc.bizmon.entity.api.CollideRequest;
import cn.nsoc.bizmon.entity.api.Person;
import cn.nsoc.bizmon.entity.api.SummaryResponse;
import cn.nsoc.nspider.app.police.entity.rule.TrackCatelog;

public interface DataWareMgr {

    public ESResult<DevGreatSearch> search(String keyword, TrackCatelog tranType, String subtype,
            int rowStart, int rowCount);

    public Person findInfo(String id);

    public String findIconByPid(String pid);

    public String findImgByVK(String vk);

    public List<SummaryResponse> summary(String type, String val, long start, long end,
            int rowStart, int rowCount) throws NSException;

    public List<Map<String, Object>> findIdFromVirt(String account) throws NSException;

    public String findMobileFromMac(String val) throws NSException;

    public List<Map<String, Object>> findVirtById(String pid, String mobile) throws NSException;

    public List<String> findImgs(long start, long end, String pid) throws NSException;

    public String findMacFromMobile(String mobile) throws NSException;

    public List<Map<String, Object>> macTrace(long start, long end, String mac) throws NSException;

    public List<Map<String, Object>> fulTrace(long start, long end, String pid, String mobile)
            throws NSException;

    public List<Map<String, Object>> collide(List<CollideRequest> models, int min)
            throws NSException;

    public List<Map<String, Object>> relation(List<Map<String, String>> virtuals)
            throws NSException;

    public List<Map<String, Object>> findChat(String type, String val, long start, long end,
            int rowStart, int rowCount) throws NSException;

    public List<Map<String, Object>> findWbonline(String pid, int start, int limit)
            throws NSException;

    public List<Map<String, Object>> findWifiOnline(String pid, String mobile, int start, int limit)
            throws NSException;

    public List<Map<String, Object>> findMail(String pid, String mobile, int start, int limit)
            throws NSException;

    public List<Map<String, Object>> findHttp(String pid, String mobile, int start, int limit)
            throws NSException;
    public long findHotstat(String servicecode, long time);
}
