package cn.nsoc.bizmon.biz.dw.entity;

import com.google.gson.annotations.SerializedName;

import cn.nsoc.nspider.app.police.entity.objects.ObjIMMsg;

public class DevImMsg {
	
	@SerializedName(ObjIMMsg.FD_SEND_TIME)
	private Long sendTime;
	@SerializedName(ObjIMMsg.FD_FROM_ID)
	private String fromId;
	@SerializedName(ObjIMMsg.FD_TO_ID)
	private String toId;
	@SerializedName(ObjIMMsg.FD_GRP_NO)
	private String grpNo;
	@SerializedName(ObjIMMsg.FD_GROUP_NAME)
	private String grpName;
	@SerializedName(ObjIMMsg.FD_SERVICE_CODE)
	private String serviceCode;
	private String content;


	public Long getSendTime() {
        return sendTime;
    }

    public void setSendTime(Long sendTime) {
        this.sendTime = sendTime;
    }

    public String getFromId() {
		return fromId;
	}

	public void setFromId(String fromId) {
		this.fromId = fromId;
	}

	public String getToId() {
		return toId;
	}

	public void setToId(String toId) {
		this.toId = toId;
	}

	public String getGrpNo() {
		return grpNo;
	}

	public void setGrpNo(String grpNo) {
		this.grpNo = grpNo;
	}

	public String getGrpName() {
		return grpName;
	}

	public void setGrpName(String grpName) {
		this.grpName = grpName;
	}

	public String getServiceCode() {
		return serviceCode;
	}

	public void setServiceCode(String serviceCode) {
		this.serviceCode = serviceCode;
	}

	public String getContent() {
		return content;
	}

	public void setContent(String content) {
		this.content = content;
	}

}
