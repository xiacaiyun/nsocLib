package cn.nsoc.bizmon.biz.dw.entity;

import com.google.gson.annotations.SerializedName;

import cn.nsoc.nspider.app.police.entity.objects.ObjDevTrack;

public class DevTrack {
	@SerializedName(ObjDevTrack.FD_TRACK_ID)
	String trackId;
	@SerializedName(ObjDevTrack.FD_SEARCH_ID)
	String searchId;
	@SerializedName(ObjDevTrack.FD_WORD)
	String keyword;
	@SerializedName(ObjDevTrack.FD_CATELOG)
	int catelog;
	@SerializedName(ObjDevTrack.FD_SORT)
	String subCatelog;
	@SerializedName(ObjDevTrack.FD_NAME)
	String username;
	public String getTrackId() {
		return trackId;
	}
	public void setTrackId(String trackId) {
		this.trackId = trackId;
	}
	public String getSearchId() {
		return searchId;
	}
	public void setSearchId(String searchId) {
		this.searchId = searchId;
	}
	public String getKeyword() {
		return keyword;
	}
	public void setKeyword(String keyword) {
		this.keyword = keyword;
	}
	public int getCatelog() {
		return catelog;
	}
	public void setCatelog(int catelog) {
		this.catelog = catelog;
	}
	public String getSubCatelog() {
		return subCatelog;
	}
	public void setSubCatelog(String subCatelog) {
		this.subCatelog = subCatelog;
	}
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}


}
