package cn.nsoc.bizmon.biz.dw;

import static java.util.stream.Collectors.toList;
import java.util.List;
import java.util.Map;
import javax.annotation.PostConstruct;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import cn.nsoc.altergraph.alter.GraphBaseFactory;
import cn.nsoc.altergraph.alter.VirtualID;
import cn.nsoc.altergraph.conf.BaseDefine;
import cn.nsoc.altergraph.i.IBaseAlter;
import cn.nsoc.base.entity.sys.NSException;

@Service("neo4jMgr")
public class Neo4jMgr {
    @Value("${neo4j.host}")
    String server;
    @Value("${neo4j.username}")
    String username;
    @Value("${neo4j.password}")
    String password;

    IBaseAlter client;

    @PostConstruct
    public void init() throws NSException {
        client = GraphBaseFactory.getBaseAlterIsOnlyQuery(BaseDefine.NEO4J, server, username,
                password);
    }

    public List<Map<String, Object>> relation(List<Map<String, String>> virtuals)
            throws NSException {
        return client.polymerizationQuery(virtuals.stream()
                .map(l -> new VirtualID(l.get("virval"), l.get("virtype"))).collect(toList()));
    }


}
