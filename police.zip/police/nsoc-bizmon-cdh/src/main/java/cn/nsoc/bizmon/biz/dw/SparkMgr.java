package cn.nsoc.bizmon.biz.dw;

import static java.util.stream.Collectors.toList;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import javax.annotation.PostConstruct;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import cn.nsoc.base.entity.sys.NSException;
import cn.nsoc.bizmon.entity.api.CollideRequest;
import cn.nsoc.scm.ISCMClient;
import cn.nsoc.scm.client.SCMFactory;
import cn.nsoc.scm.entity.CollisionElement;
import cn.nsoc.scm.entity.SCMReqData;
import cn.nsoc.scm.tools.SCMDefine;

@Service("sparkMgr")
public class SparkMgr {
    
    private ISCMClient client;
    @Value("${scm.host}")
    String host;
    @Value("${scm.port}")
    int port;
    
    @PostConstruct
    public void init() throws NSException {
        client = SCMFactory.getSCMClient();
        client.init(host, port);
    }
    
    public List<Map<String, Object>> collide(List<CollideRequest> models, int min) throws NSException {
        SCMReqData collisionData = new SCMReqData();
        collisionData.setMin(min).setType(SCMDefine.TYPE_MAC);
        for(CollideRequest req: models) {
            for(String place: req.getPlace()) {
                collisionData.addElement(new CollisionElement().setFromTime(req.getFromtime()).setToTime(req.getTotime()).addPlace(place));
            }
        }
        List<Map<String, Object>> result = new ArrayList<>();
        try {
            result = client.runCollision(collisionData).getReduceDatas().stream().map(l->{
                Map<String, Object> m = new HashMap<>();
                m.put("c_sc", l.getV().size());
                m.put("s_sc", l.getV());
                m.put("s_mac", l.getK());
                return m;
            }).collect(toList());
        } catch (IOException e) {
            throw new NSException(e);
        }
        return result;
    }

}
