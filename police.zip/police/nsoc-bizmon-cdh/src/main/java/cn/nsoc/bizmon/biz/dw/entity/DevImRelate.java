package cn.nsoc.bizmon.biz.dw.entity;

import com.google.gson.annotations.SerializedName;

import cn.nsoc.nspider.app.police.entity.objects.ObjIMRelate;

public class DevImRelate {
	@SerializedName(ObjIMRelate.FD_IM_TYPE)
	private String imType;
	@SerializedName(ObjIMRelate.FD_SELF_ID)
	private String selfId;
	@SerializedName(ObjIMRelate.FD_CONTACT_ID)
	private String contactId;
	public String getImType() {
		return imType;
	}
	public void setImType(String imType) {
		this.imType = imType;
	}
	public String getSelfId() {
		return selfId;
	}
	public void setSelfId(String selfId) {
		this.selfId = selfId;
	}
	public String getContactId() {
		return contactId;
	}
	public void setContactId(String contactId) {
		this.contactId = contactId;
	}
	
	
}
