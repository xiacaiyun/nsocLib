package cn.nsoc.bizmon.biz.dw.entity;

import com.google.gson.annotations.SerializedName;

import cn.nsoc.nspider.app.police.entity.objects.ObjDevVirtLookup;

public class DevVirtLookup {
	@SerializedName(ObjDevVirtLookup.FD_CERT_ID)
	private String certId;
	@SerializedName(ObjDevVirtLookup.FD_CERT_TYPE)
	private String certType;
	@SerializedName(ObjDevVirtLookup.FD_ACCOUNT_TYPE)
	private String accountType;
	@SerializedName(ObjDevVirtLookup.FD_ACCOUNT_CODE)
	private String accountCode;
	public String getCertId() {
		return certId;
	}
	public void setCertId(String certId) {
		this.certId = certId;
	}
	public String getCertType() {
		return certType;
	}
	public void setCertType(String certType) {
		this.certType = certType;
	}
	public String getAccountType() {
		return accountType;
	}
	public void setAccountType(String accountType) {
		this.accountType = accountType;
	}
	public String getAccountCode() {
		return accountCode;
	}
	public void setAccountCode(String accountCode) {
		this.accountCode = accountCode;
	}
	
}
