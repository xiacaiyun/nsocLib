package cn.nsoc.bizmon.biz.dw.entity;

@Deprecated
public class DevPhoto {
	
	private String serviceCode;
	private String mimeName;
	private String relatePath;
	public String getServiceCode() {
		return serviceCode;
	}
	public void setServiceCode(String serviceCode) {
		this.serviceCode = serviceCode;
	}
	public String getMimeName() {
		return mimeName;
	}
	public void setMimeName(String mimeName) {
		this.mimeName = mimeName;
	}
	public String getRelatePath() {
		return relatePath;
	}
	public void setRelatePath(String relatePath) {
		this.relatePath = relatePath;
	}
	
}
