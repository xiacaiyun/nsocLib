package cn.nsoc.bizmon.biz.dw;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import javax.annotation.PostConstruct;
import org.apache.commons.lang3.StringUtils;
import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.hbase.HBaseConfiguration;
import org.apache.hadoop.hbase.TableName;
import org.apache.hadoop.hbase.client.Connection;
import org.apache.hadoop.hbase.client.ConnectionFactory;
import org.apache.hadoop.hbase.client.Get;
import org.apache.hadoop.hbase.client.Result;
import org.apache.hadoop.hbase.client.ResultScanner;
import org.apache.hadoop.hbase.client.Scan;
import org.apache.hadoop.hbase.client.Table;
import org.apache.hadoop.hbase.filter.Filter;
import org.apache.hadoop.hbase.filter.PrefixFilter;
import org.apache.hadoop.hbase.util.Bytes;
import org.apache.log4j.Logger;
import org.springframework.stereotype.Service;
import cn.nsoc.base.entity.sys.NSException;
import cn.nsoc.bizmon.util.Hptimer;
import cn.nsoc.nspider.app.police.entity.objects.ObjDevCertImg;
import cn.nsoc.nspider.app.police.entity.objects.ObjDevPhoto;

@Service("hbaseMgr")
public class HBaseMgr {
    private static final Logger logger = Logger.getLogger(HBaseMgr.class);
    private static final long ONE_DAY_SECONDS = 24 * 60 * 60;
    private Configuration conf = null;

    @PostConstruct
    public void init() {
        conf = HBaseConfiguration.create();
    }


    public List<Map<String, Object>> findWbonline(String pid, int start, int limit) {
        List<Map<String, Object>> result = new ArrayList<>();
        try (Connection connection = ConnectionFactory.createConnection(conf);
                Table table = connection.getTable(TableName.valueOf("police.dev_term_track"))) {
            Scan scan = new Scan();
            Filter prefix = new PrefixFilter(Bytes.toBytes(pid));
            scan.setFilter(prefix);
            scan.setBatch(1000);
            byte[] fam = Bytes.toBytes("f");
            ResultScanner rs = table.getScanner(scan);
            Result val = null;
            while ((val = rs.next()) != null) {
                if (start-- > 0) {
                    continue;
                }
                if (--limit < 0) {
                    break;
                }
                String ter = Bytes.toString((val.getValue(fam, Bytes.toBytes("ter"))));
                String sc = Bytes.toString(val.getValue(fam, Bytes.toBytes("sc")));
                byte[] ontStr = val.getValue(fam, Bytes.toBytes("ont"));
                byte[] oftStr = val.getValue(fam, Bytes.toBytes("oft"));

                Map<String, Object> pair = new HashMap<>();
                if (ontStr != null) {
                    pair.put("online_time", Bytes.toLong(ontStr));
                }
                if (oftStr != null) {
                    pair.put("offline_time", Bytes.toLong(oftStr));
                }
                pair.put("sc", sc);
                pair.put("terminal_id", ter);
                result.add(pair);
            }
            rs.close();
        } catch (Exception e) {
            logger.error("hbase error", e);
        }
        return result;

    }

    public List<Map<String, Object>> findWifiOnline(String acc, int start, int limit) {
        List<Map<String, Object>> result = new ArrayList<>();
        try (Connection connection = ConnectionFactory.createConnection(conf);
                Table table = connection.getTable(TableName.valueOf("police.dev_wifi_track"))) {
            Scan scan = new Scan();
            Filter prefix = new PrefixFilter(Bytes.toBytes(acc));
            scan.setFilter(prefix);
            scan.setBatch(1000);
            byte[] fam = Bytes.toBytes("f");
            ResultScanner rs = table.getScanner(scan);
            Result val = null;
            while ((val = rs.next()) != null) {
                if (start-- > 0) {
                    continue;
                }
                if (--limit < 0) {
                    break;
                }

                String ap = Bytes.toString((val.getValue(fam, Bytes.toBytes("ap"))));
                String sc = Bytes.toString(val.getValue(fam, Bytes.toBytes("sc")));
                byte[] ontStr = val.getValue(fam, Bytes.toBytes("ont"));
                byte[] oftStr = val.getValue(fam, Bytes.toBytes("oft"));

                Map<String, Object> pair = new HashMap<>();
                if (ontStr != null) {
                    pair.put("online_time", Bytes.toLong(ontStr));
                }
                if (oftStr != null) {
                    pair.put("offline_time", Bytes.toLong(oftStr));
                }
                pair.put("servicecode", sc);
                pair.put("ap", ap);
                result.add(pair);
            }
        } catch (Exception e) {
            logger.error("hbase error", e);
        }
        return result;
    }

    public List<Map<String, Object>> findMail(String acc, int start, int limit) {
        List<Map<String, Object>> result = new ArrayList<>();
        try (Connection connection = ConnectionFactory.createConnection(conf);
                Table table = connection.getTable(TableName.valueOf("police.dev_mail_track"))) {
            Scan scan = new Scan();
            Filter prefix = new PrefixFilter(Bytes.toBytes(acc));
            scan.setFilter(prefix);
            scan.setBatch(1000);
            byte[] fam = Bytes.toBytes("f");
            ResultScanner rs = table.getScanner(scan);
            Result val = null;
            while ((val = rs.next()) != null) {
                if (start-- > 0) {
                    continue;
                }
                if (--limit < 0) {
                    break;
                }

                String sc = Bytes.toString(val.getValue(fam, Bytes.toBytes("sc")));
                String mfr = Bytes.toString(val.getValue(fam, Bytes.toBytes("mfr")));
                String rp = Bytes.toString(val.getValue(fam, Bytes.toBytes("rp")));
                String cc = Bytes.toString(val.getValue(fam, Bytes.toBytes("cc")));
                String sub = Bytes.toString(val.getValue(fam, Bytes.toBytes("sub")));
                byte[] cptStr = val.getValue(fam, Bytes.toBytes("cpt"));

                Map<String, Object> element = new HashMap<>();
                if (cptStr != null) {
                    element.put("send_time", Bytes.toLong(cptStr));
                }
                element.put("mail_from", mfr);
                element.put("mail_to", rp);
                element.put("mail_cc", cc);
                element.put("mail_subject", sub);
                element.put("servicecode", sc);
                result.add(element);
            }
        } catch (Exception e) {
            logger.error("hbase error", e);
        }
        return result;
    }

    public List<Map<String, Object>> findHttp(String acc, int start, int limit) {
        List<Map<String, Object>> result = new ArrayList<>();
        try (Connection connection = ConnectionFactory.createConnection(conf);
                Table table = connection.getTable(TableName.valueOf("police.dev_http_track"))) {
            Scan scan = new Scan();
            Filter prefix = new PrefixFilter(Bytes.toBytes(acc));
            scan.setFilter(prefix);
            scan.setBatch(1000);
            byte[] fam = Bytes.toBytes("f");
            ResultScanner rs = table.getScanner(scan);
            Result val = null;
            while ((val = rs.next()) != null) {
                if (start-- > 0) {
                    continue;
                }
                if (--limit < 0) {
                    break;
                }

                String sc = Bytes.toString(val.getValue(fam, Bytes.toBytes("sc")));
                String mo = Bytes.toString(val.getValue(fam, Bytes.toBytes("mo")));
                String url = Bytes.toString(val.getValue(fam, Bytes.toBytes("url")));
                byte[] cptStr = val.getValue(fam, Bytes.toBytes("cpt"));

                Map<String, Object> element = new HashMap<>();
                if (cptStr != null) {
                    element.put("send_time", Bytes.toLong(cptStr));
                }
                element.put("sessionid", mo);
                element.put("url", url);
                element.put("servicecode", sc);
                result.add(element);
            }
        } catch (Exception e) {
            logger.error("hbase error", e);
        }
        return result;
    }

    public String findIconByPid(String acc) {
        String image = null;
        try (Connection connection = ConnectionFactory.createConnection(conf);
                Table table = connection.getTable(TableName.valueOf("dev_cert_img"))) {
            Scan scan = new Scan();
            Filter prefix = new PrefixFilter(Bytes.toBytes(acc));
            scan.setFilter(prefix);
            scan.setBatch(10);
            byte[] fam = Bytes.toBytes("f");
            ResultScanner rs = table.getScanner(scan);
            Result val = rs.next();
            if (val != null) {
                image = Bytes.toString(val.getValue(fam, Bytes.toBytes(ObjDevCertImg.FD_IMG)));
            }
        } catch (Exception e) {
            logger.error("hbase error", e);
        }
        return image;
    }
    
    public List<String> findImgs(String pid, long start, long end) throws NSException {

        List<String> result = new ArrayList<>();
        try (Connection connection = ConnectionFactory.createConnection(conf);
                Table table = connection.getTable(TableName.valueOf("police.dev_photo"))) {
            Scan scan = new Scan();
            Filter prefix = new PrefixFilter(Bytes.toBytes(pid));
            scan.setFilter(prefix);
            scan.setStartRow(String.format("%s%s", pid, start - ONE_DAY_SECONDS).getBytes());
            scan.setStopRow(String.format("%s%s", pid, end).getBytes());
            scan.setBatch(1000);
            ResultScanner rs = table.getScanner(scan);
            Result val = null;
            while ((val = rs.next()) != null) {
                String vk = Bytes.toString(val.getRow());
                result.add(vk);
            }
        } catch (Exception e) {
            logger.error("hbase error", e);
        }
        return result;
    
        
    }
    
    public String findImgByVK(String vk) {
        String image = null;
        try (Connection connection = ConnectionFactory.createConnection(conf);
                Table table = connection.getTable(TableName.valueOf("police.dev_photo"))) {
            byte[] fam = Bytes.toBytes("f");
            Result val = table.get(new Get(vk.getBytes()));
            if (val != null) {
                image = Bytes.toString(val.getValue(fam, Bytes.toBytes(ObjDevPhoto.FD_PICTURE)));
            }
        } catch (Exception e) {
            logger.error("hbase error", e);
        }
        return image;
    }


    public List<Map<String, Object>> macTrace(long start, long end, String mac) {
        List<Map<String, Object>> result = new ArrayList<>();
        try (Connection connection = ConnectionFactory.createConnection(conf);
                Table table = connection.getTable(TableName.valueOf("police.dev_mac_fast"))) {
            mac = StringUtils.remove(mac, "-").toLowerCase();
            Scan scan = new Scan();
            scan.setStartRow(String.format("%s%s", mac, start).getBytes());
            scan.setStopRow(String.format("%s%s", mac, end+1).getBytes());
            scan.setBatch(1000);
            byte[] fam = Bytes.toBytes("f");
            ResultScanner rs = table.getScanner(scan);
            Result val = null;
            while ((val = rs.next()) != null) {
                String sc = Bytes.toString(val.getValue(fam, Bytes.toBytes("sc")));
                String timeStr = Bytes.toString(val.getRow());

                Map<String, Object> element = new HashMap<>();
                if (timeStr == null) {
                    continue;
                }
                element.put("online_time",Long.parseLong(timeStr.substring(mac.length())));
                element.put("service_code", sc);
                result.add(element);
            }
        } catch (Exception e) {
            logger.error("hbase error", e);
        }
        return result;
    }


    public long findHotstat(String servicecode, long time) {
        try (Connection connection = ConnectionFactory.createConnection(conf);
                Table table = connection.getTable(TableName.valueOf("police.dev_hotstat"))) {
            Result val = table.get(new Get(String.format("%s%s", servicecode, time).getBytes()));
            byte[] fam = Bytes.toBytes("f");
            if(val != null && !val.isEmpty()) {
                return Bytes.toInt(val.getValue(fam, Bytes.toBytes("tot")));
            }
        } catch (Exception e) {
            logger.error("hbase error", e);
        }
        return 0;
    }
}
