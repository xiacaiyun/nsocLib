package cn.nsoc.bizmon.biz.dw.entity;

import com.google.gson.annotations.SerializedName;

import cn.nsoc.nspider.app.police.entity.objects.ObjDevGreatSearch;

public class DevGreatSearch {
	String id;
	@SerializedName(ObjDevGreatSearch.FD_WORD)
	String keyword;
	@SerializedName(ObjDevGreatSearch.FD_CATELOG)
	String catelog;
	@SerializedName(ObjDevGreatSearch.FD_SORT)
	String subCatelog;
	@SerializedName(ObjDevGreatSearch.FD_NAME)
	String username;

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getKeyword() {
		return keyword;
	}

	public void setKeyword(String keyword) {
		this.keyword = keyword;
	}

	public String getCatelog() {
		return catelog;
	}

	public void setCatelog(String catelog) {
		this.catelog = catelog;
	}

	public String getSubCatelog() {
		return subCatelog;
	}

	public void setSubCatelog(String subCatelog) {
		this.subCatelog = subCatelog;
	}

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	@Override
	public String toString() {
		return "DevGreatSearch [id=" + id + ", keyword=" + keyword + ", catelog=" + catelog + ", subCatelog="
				+ subCatelog + ", username=" + username + "]";
	}
	
	

}
