package cn.nsoc.bizmon.biz.dw;

import java.io.IOException;
import java.io.InputStream;

import javax.annotation.PostConstruct;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.FileSystem;
import org.apache.hadoop.fs.Path;
import org.apache.log4j.Logger;
import org.springframework.stereotype.Component;

@Component
public class HdfsHelper {
	private static final Logger logger = Logger.getLogger(HdfsHelper.class);
	private FileSystem fs;

	@PostConstruct
	public void initialize() {
		Configuration conf = new Configuration();
		conf.addResource("hdfs-site.xml");
		System.getProperties().setProperty("HADOOP_USER_NAME", "nsoc");
		try {
			fs = FileSystem.get(conf);
		} catch (IOException e) {
			logger.error("hdfs failed", e);
			throw new RuntimeException();
		}
	}
	
	public InputStream open(String uri) {
		 try {
			return fs.open(new Path(uri));
		} catch (IllegalArgumentException | IOException e) {
			logger.error("hdfs file not found", e);
			return null;
		}
	}
}
