package cn.nsoc.bizmon.biz.dw;

import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.List;

import org.elasticsearch.action.search.SearchResponse;
import org.elasticsearch.search.SearchHit;
import org.elasticsearch.search.SearchHits;

import com.google.gson.Gson;

public class ESUtil {
	
	public static <T> ESResult<T> fetch(SearchResponse response, Class<T> clazz) {
		ESResult<T> result = new ESResult<>();
    	SearchHits hits = response.getHits();
    	result.setTotal(hits.getTotalHits());
    	result.setCurrent(hits.getHits().length);
    	List<T> data = new ArrayList<>();
    	Gson gson = new Gson();
    	for(SearchHit hit:hits) {
    		T element = gson.fromJson(hit.getSourceAsString(), clazz);
    		try {
				Field field = clazz.getDeclaredField("id");
				field.setAccessible(true);
				field.set(element, hit.getId());
			} catch (NoSuchFieldException | SecurityException | IllegalArgumentException | IllegalAccessException e) {
			}
    		data.add(element);
    	}
    	result.setData(data);
    	return result;
	}
}
