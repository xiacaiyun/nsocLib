package cn.nsoc.bizmon.biz.mysql;

import cn.nsoc.base.entity.sys.NSException;
import cn.nsoc.bizmon.biz.SuspectJsonModel;
import cn.nsoc.bizmon.entity.defines.Constants;
import cn.nsoc.bizmon.entity.mysql.Monitor;
import cn.nsoc.bizmon.entity.mysql.Suspect;
import cn.nsoc.bizmon.entity.mysql.Suspectinfo;
import cn.nsoc.common.applib.controller.NController;
import cn.nsoc.common.storer.db.DbSelectBuilder;
import cn.nsoc.common.storer.db.JdbcDbStorer;
import cn.nsoc.common.util.ExportHelper;
import cn.nsoc.common.util.Misc;
import org.springframework.util.StringUtils;

import javax.servlet.http.HttpServletResponse;
import java.util.stream.Collectors;

public class SuspectinfoBiz {
    JdbcDbStorer dbStorer;

    public SuspectinfoBiz() {
        dbStorer = JdbcDbStorer.getInstance();
    }

    public SuspectinfoBiz(JdbcDbStorer storer) {
        dbStorer = storer;
    }

    public Suspectinfo.Coll load(Suspectinfo.Coll me) throws NSException {
        return (Suspectinfo.Coll) dbStorer.load(me);
    }

    public Suspectinfo.Coll loadByKeyword(Suspectinfo.Coll me, String keyword) throws NSException {
        Suspectinfo.Query query = me.getQuery();
        if (StringUtils.hasText(keyword)) {
            Suspect.Coll coll = new Suspect.Coll();
            new SuspectBiz().loadBykeyword(coll, keyword);
            if (coll.isEmpty()) {
                return me;
            }
            query.setIdIDList(coll.stream().map(l -> l.getInfoid()).distinct().collect(Collectors.toList()));
        }
        DbSelectBuilder selectBuilder = new DbSelectBuilder(dbStorer, null);
        selectBuilder.addField("name", "ANY_VALUE(name)");
        selectBuilder.addField("userid", "ANY_VALUE(userid)");
        selectBuilder.addField("updatetime", "ANY_VALUE(updatetime)");
        selectBuilder.addField("createtime", "ANY_VALUE(createtime)");
        selectBuilder.addField("configid", "ANY_VALUE(configid)");
        selectBuilder.addField("id", "ANY_VALUE(id)");
//        selectBuilder.addField("count", "count(1)");
        query.selectFields = selectBuilder;
        query.groupBy = Suspectinfo.Query.GroupByEnum.NAME;
        return (Suspectinfo.Coll) dbStorer.load(me);
    }


    public boolean insert(Suspectinfo.Entity me) throws NSException {
        return dbStorer.insert(me);
    }

    public boolean delete(Suspectinfo.Entity me) throws NSException {
        Suspectinfo.Query query = new Suspectinfo.Query();
        query.setId(me.getId());
        return dbStorer.delete(query, me.getClass());
    }

    public boolean update(Suspectinfo.Entity me) throws NSException {
        return dbStorer.update(me);
    }

    public Suspectinfo.Entity get(String id) throws NSException {
        Suspectinfo.Query query = new Suspectinfo.Query();
        query.setId(id);
        Suspectinfo.Coll results = load(new Suspectinfo.Coll(query));
        return results.isEmpty() ? null : results.get(0);
    }

    public void buildExcel(Suspect.Coll expData, HttpServletResponse response) throws NSException {
        StringBuilder sb = new StringBuilder();
        Suspectinfo.Coll coll = new Suspectinfo.Coll();
        new SuspectinfoBiz().load(coll);
        sb.append("<table border=1><tr> " +
                "<th>库名称</th> " +
                "<th>" + Constants.SuspectFields.SEQ_NO + "</th> " +
                "<th>" + Constants.SuspectFields.DISTRICT + "</th> " +
                "<th>" + Constants.SuspectFields.USERNAME + "</th> " +
                "<th>" + Constants.SuspectFields.GENDER + "</th> " +
                "<th>" + Constants.SuspectFields.PID + "</th> " +
                "<th>" + Constants.SuspectFields.BORN_PLACE + "</th> " +
                "<th>" + Constants.SuspectFields.RESIDENCE_PLACE + "</th> " +
                "<th>" + Constants.SuspectFields.ADDR_BOOK_NAME + "</th> " +
                "<th>" + Constants.SuspectFields.IMPORTANT_PERSON + "</th> " +
                "<th>" + Constants.SuspectFields.MOBILE + "</th> " +
                "<th>" + Constants.SuspectFields.MAC + "</th> " +
                "<th>" + Constants.SuspectFields.WX_GROUP_ID + "</th> " +
                "<th>" + Constants.SuspectFields.WX_GROUP_NAME + "</th> " +
                "<th>" + Constants.SuspectFields.WX + "</th> " +
                "<th>" + Constants.SuspectFields.WX_ID + "</th> " +
                "<th>" + Constants.SuspectFields.WX_NAME + "</th> " +
                "<th>" + Constants.SuspectFields.QQ + "</th> " +
                "<th>" + Constants.SuspectFields.NICKNAME + "</th> " +
                "<th>" + Constants.SuspectFields.QQ_GROUP + "</th> " +
                "<th>" + Constants.SuspectFields.GROUP + "</th> " +
                "<th>" + Constants.SuspectFields.GROUP_NICKNAME + "</th> " +
                "<th>" + Constants.SuspectFields.REMARK1 + "</th> " +
                "<th>" + Constants.SuspectFields.REMARK2 + "</th> " +
                "<th>" + Constants.SuspectFields.REMARK3 + "</th></tr>");

        // 添加内容
        for (Suspect.Entity a : expData) {
            String data = "";
            SuspectJsonModel jsonModel = Misc.fromJson(a.getOther(), SuspectJsonModel.class);
            if(jsonModel == null){
                jsonModel = new SuspectJsonModel();
            }
            data = String.format("<tr> " +
                            ExportHelper.CELL_COLUMN +
                            ExportHelper.CELL_COLUMN +
                            ExportHelper.CELL_COLUMN +
                            ExportHelper.CELL_COLUMN +
                            ExportHelper.CELL_COLUMN +
                            ExportHelper.CELL_COLUMN +
                            ExportHelper.CELL_COLUMN +
                            ExportHelper.CELL_COLUMN +
                            ExportHelper.CELL_COLUMN +
                            ExportHelper.CELL_COLUMN +
                            ExportHelper.CELL_COLUMN +
                            ExportHelper.CELL_COLUMN +
                            ExportHelper.CELL_COLUMN +
                            ExportHelper.CELL_COLUMN +
                            ExportHelper.CELL_COLUMN +
                            ExportHelper.CELL_COLUMN +
                            ExportHelper.CELL_COLUMN +
                            ExportHelper.CELL_COLUMN +
                            ExportHelper.CELL_COLUMN +
                            ExportHelper.CELL_COLUMN +
                            ExportHelper.CELL_COLUMN +
                            ExportHelper.CELL_COLUMN +
                            ExportHelper.CELL_COLUMN +
                            ExportHelper.CELL_COLUMN +
                            ExportHelper.CELL_COLUMN + "</tr>",
                    coll.find(a.getInfoid()) == null ? "" : coll.find(a.getInfoid()).getName(),
                    a.getSeqno(),
                    jsonModel.getDistrict() != null ? jsonModel.getDistrict() : "",
                    a.getUsername(),
                    jsonModel.getGender() != null ? jsonModel.getGender() : "",
                    a.getPid(),
                    jsonModel.getBornplace() != null ? jsonModel.getBornplace() : "",
                    jsonModel.getResidenceplace() != null ? jsonModel.getResidenceplace() : "",
                    jsonModel.getAddrbookname() != null ? jsonModel.getAddrbookname() : "",
                    jsonModel.getImportantperson() != null ? jsonModel.getImportantperson() : "",
                    a.getMobile(),
                    a.getMac(),
                    a.getWxgroupid() == null ? "" : a.getWxgroupid(),
                    jsonModel.getWxgroupname() != null ? jsonModel.getWxgroupname() : "",
                    a.getWx() == null ? "" : a.getWx(),
                    a.getWxid() == null ? "" : a.getWxid(),
                    jsonModel.getWxname() == null ? "" : jsonModel.getWxname(),
                    a.getQq() == null ? "" : a.getQq(),
                    jsonModel.getNickname() != null ? jsonModel.getNickname() : "",
                    jsonModel.getQqgroup() != null ? jsonModel.getQqgroup() : "",
                    jsonModel.getGroup() != null ? jsonModel.getGroup() : "",
                    jsonModel.getGroupnickname() != null ? jsonModel.getGroupnickname() : "",
                    jsonModel.getRemark1() != null ? jsonModel.getRemark1() : "",
                    jsonModel.getRemark2() != null ? jsonModel.getRemark2() : "",
                    jsonModel.getRemark3() != null ? jsonModel.getRemark3() : "");
            sb.append(data);
        }
        sb.append("</table>");
        String excelData = ExportHelper.BuildDownLoadHtml(sb.toString());
        String fileName = "库列表";
        NController.exportToExcel(response, excelData, fileName);
    }



}

