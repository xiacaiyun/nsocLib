package cn.nsoc.bizmon.biz.mysql;


import cn.nsoc.base.entity.define.NSExceptionCode;
import cn.nsoc.base.entity.sys.NSException;
import cn.nsoc.bizmon.entity.defines.MonType;
import cn.nsoc.bizmon.entity.mysql.Suspect;
import cn.nsoc.common.conveyor.*;
import org.apache.commons.lang3.tuple.ImmutablePair;
import org.apache.poi.ss.formula.functions.T;

import java.util.ArrayList;
import java.util.List;

public class SuspectCache extends ConveyorImpl<String, Suspect.Coll, String> {

    private static SuspectCache defaultInstance;

    class AppDataKeyTransform implements IKeyTransform<String, String> {
        @Override
        public String onTransform(String src) throws NSException {
            return src;
        }
    }

    class AppDataCountPolicy extends CounterPolicyImpl {
        @Override
        public long onSetMaximumSize() {
            return 100;
        }

        @Override
        public long onSetExpireAfterAccess() {
            return 600;
        }

        @Override
        public int onSetConcurrencyLevel() {
            return 2;
        }
    }

    class AppDataFetch implements IQuickFetch<String, Suspect.Coll,String> {
        @Override
        public Suspect.Coll onLoad(String key, String searchKey) throws NSException {
            try {
                Suspect.Coll sColl = new Suspect.Coll();
//                Suspect.Query query = sColl.getQuery();
//                query.
                new SuspectBiz().loadBykeyword(sColl,null);
                return sColl;
            } catch (Exception e) {
                throw new NSException(NSExceptionCode.Runtime_Error,e);
            }

        }
    }

//    static class KeyModel{
//        String monkey;
//        MonType monType;
//    }
//    class AppInitialize implements IDataInitialize<KeyModel,Suspect.Coll>{
//
//        @Override
//        public List<ImmutablePair<KeyModel,Suspect.Coll>> onGetSnap() throws NSException {
//            Suspect.Coll sColl = new Suspect.Coll();
//            Suspect.Query query = sColl.getQuery();
//            query.start = 0;
//            query.count = 1000;
//            new SuspectBiz().loadBykeyword(sColl,null);
//            List<ImmutablePair<KeyModel, Suspect.Coll>> result = new ArrayList<>();
//            sColl.forEach(p-> result.add(new ImmutablePair<>(p.get,p)));
//            return result;
//        }
//
//    }

    private void start() throws NSException {

        initialize(new SuspectCache.AppDataFetch(), new SuspectCache.AppDataKeyTransform(),
                new SuspectCache.AppDataCountPolicy(), null);
    }
    
    public static SuspectCache getInstance() throws NSException {
        if (defaultInstance == null) {
            defaultInstance = new SuspectCache();
            defaultInstance.start();
        }
        return defaultInstance;
    }
}