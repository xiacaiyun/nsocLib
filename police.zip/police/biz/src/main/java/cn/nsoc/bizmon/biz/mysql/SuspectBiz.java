package cn.nsoc.bizmon.biz.mysql;

import cn.nsoc.base.entity.sys.NSException;
import cn.nsoc.bizmon.entity.defines.MonType;
import cn.nsoc.bizmon.entity.mysql.Suspect;
import cn.nsoc.common.storer.annotation.QueryOperator;
import cn.nsoc.common.storer.db.DbSelectBuilder;
import cn.nsoc.common.storer.db.JdbcDbStorer;
import cn.nsoc.common.storer.option.QueryBuilder;

import org.apache.log4j.Logger;
import org.springframework.util.StringUtils;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.function.Function;
import java.util.stream.Collectors;


public class SuspectBiz {
	private static final Logger logger = Logger.getLogger(SuspectBiz.class);
    JdbcDbStorer dbStorer;

    public SuspectBiz() {
        dbStorer = JdbcDbStorer.getInstance();
    }

    public SuspectBiz(JdbcDbStorer storer) {
        dbStorer = storer;
    }

    public Suspect.Coll load(Suspect.Coll me) throws NSException {
        return (Suspect.Coll) dbStorer.load(me);
    }

    public boolean insert(Suspect.Entity me) throws NSException {
        return dbStorer.insert(me);
    }


    public boolean delete(Suspect.Entity me) throws NSException {
        return dbStorer.delete(me);
    }

    public boolean update(Suspect.Entity me) throws NSException {
        return dbStorer.update(me);
    }

    public boolean deleteByInfoid(String infoid) throws NSException {
        List<String> list = getIdListByInfoId(infoid);
        if (list != null && list.isEmpty()) {
            return true;
        }
        Suspect.Query query = new Suspect.Query();
        query.setIdIDList(list);
        return dbStorer.delete(query, Suspect.Entity.class);
    }

    public Suspect.Entity get(String id) throws NSException {
        Suspect.Query query = new Suspect.Query();
        query.setId(id);
        Suspect.Coll results = loadBykeyword(new Suspect.Coll(query), null);
        return results.isEmpty() ? null : results.get(0);
    }

    public List<String> getIdListByInfoId(String infoId) throws NSException {
        if (StringUtils.hasText(infoId)) {
            Suspect.Coll coll = new Suspect.Coll();
            Suspect.Query query = coll.getQuery();
            query.setInfoid(infoId);
            dbStorer.load(coll);
            return coll.stream().map(p -> p.getId()).distinct().collect(Collectors.toList());
        } else {
            return Collections.emptyList();
        }
    }

    public Suspect.Coll getCollbyMonkey(int type, String monkey){
        MonType byVal = MonType.getByVal(type);
        try {
            return getCollbyMonkey(byVal,monkey);
        } catch (NSException e) {
            return new Suspect.Coll();
        }
    }

    public Suspect.Coll getCollbyMonkey(MonType type, String monkey) throws NSException {
        Suspect.Coll coll = new Suspect.Coll();
        Suspect.Query query = coll.getQuery();
        if (type != null) {
            switch (type) {
                case PID:
                    query.setPid(monkey);
                    break;
                case USERNAME:
                    query.setUsername(monkey);
                    break;
                case MOBILE:
                    query.setMobile(monkey);
                    break;
                case WXGROUPID:
                    query.setWxgroupid(monkey);
                    break;
                case WXID:
                    query.setWxid(monkey);
                    break;
                case WX:
                    query.setWx(monkey);
                    break;
                case QQ:
                    query.setQq(monkey);
                    break;
                case MAC:
                    query.setMac(monkey);
                    break;
                default:
                    break;
            }
        }
        return loadBykeyword(coll, null);
    }

    public Suspect.Coll loadBykeyword(Suspect.Coll me, String keyword) throws NSException {
        Suspect.Query query = me.getQuery();
        DbSelectBuilder dbSelectBuilder = new DbSelectBuilder(dbStorer, null);
        if (StringUtils.hasText(keyword)) {
            QueryBuilder inner = new QueryBuilder();
            inner.add("mobile", QueryOperator.Like, keyword).or("mac", QueryOperator.Like, keyword).
                     or("username", QueryOperator.Like, keyword)
                    .or("pid", QueryOperator.Like, keyword);
            dbSelectBuilder.addQuery(new QueryBuilder().and(inner));
        }
        dbSelectBuilder.addField("id,infoid,seqno,username,pid,mobile,mac,wxgroupid,wx,wxid,qq".split(","));
        dbSelectBuilder.addField("other", "JSON_UNQUOTE(other)");
        query.selectFields = dbSelectBuilder;
        return (Suspect.Coll) dbStorer.load(me);
    }


    public boolean isRelatedSuspect(Integer montype, String monkey) throws NSException {
        boolean flag;
        Suspect.Coll coll;
        MonType type = MonType.getByVal(montype);
        List<String> listFieldNames = Arrays.stream(Suspect.Entity.class.getDeclaredFields()).
                map(l -> l.getName()).collect(Collectors.toList());
        if (type != null && listFieldNames.contains(type.name().toLowerCase())) {
            coll = getCollbyMonkey(type, monkey);
            if (coll.isEmpty()) {
                flag = false;
            } else {
                flag = true;
            }
        } else {
            flag = false;
        }
        return flag;
    }

    public Map<String, Integer> fetchCount(Suspect.Coll me) throws NSException {
        Suspect.Query query = me.getQuery();
        DbSelectBuilder selectBuilder = new DbSelectBuilder(dbStorer, null);
        selectBuilder.addField("infoid");
        selectBuilder.addField("count", "count(1)");
        query.selectFields = selectBuilder;
        query.groupBy = Suspect.GroupBy.INFOID;
        Suspect.Coll coll = (Suspect.Coll) dbStorer.load(me);
        Map<String, Integer> map = coll.stream().collect(Collectors.toMap(l -> l.getInfoid(), l -> l.count));
        return map;
    }

    public void batchInsert(List<Suspect.Entity> list) throws SQLException {
        String sql = String.format("insert into %s (id, infoid, seqno,username,pid,mobile,mac,wxgroupid,wx,wxid,qq,other) values(?,?,?,?,?,?,?,?,?,?,?,?)","po_suspect");

        Connection connection = dbStorer.getConn();
        PreparedStatement ps = connection.prepareStatement(sql);
        final int batchSize = 1000;
        int count = 0;
        for (Suspect.Entity suspect : list) {
            ps.setString(1, suspect.getId());
            ps.setString(2, suspect.getInfoid());
            ps.setString(3, suspect.getSeqno());
            ps.setString(4, suspect.getUsername());
            ps.setString(5, suspect.getPid());
            ps.setString(6, suspect.getMobile());
            ps.setString(7, suspect.getMac());
            ps.setString(8, suspect.getWxgroupid());
            ps.setString(9, suspect.getWx());
            ps.setString(10, suspect.getWxid());
            ps.setString(11, suspect.getQq());
            ps.setString(12, suspect.getOther());
            ps.addBatch();
            if (++count % batchSize == 0) {
                ps.executeBatch();
            }
        }
        ps.executeBatch(); // insert remaining records
        ps.close();
        connection.close();
    }

	public Map<String, Suspect.Entity> loadByIds(List<String> suspectIds) {
		Suspect.Coll coll = new Suspect.Coll();
		Suspect.Query query = coll.getQuery();
		query.setIdIDList(suspectIds);
		try {
			coll = load(coll);
		} catch (NSException e) {
			logger.error("place query failed", e);
			return new HashMap<String, Suspect.Entity>();
		}
		return coll.stream().collect(Collectors.toMap(Suspect.Entity::getId, Function.identity()));
	}

}

