package cn.nsoc.bizmon.biz.mysql;

import cn.nsoc.base.entity.sys.NSException;
import cn.nsoc.bizmon.entity.mysql.Monitor;
import cn.nsoc.bizmon.entity.mysql.Prewarning;
import cn.nsoc.bizmon.entity.mysql.Prewarning.Coll;
import cn.nsoc.common.storer.db.DbSelectBuilder;
import cn.nsoc.common.storer.db.JdbcDbStorer;

import java.util.List;
import java.util.stream.Collectors;

public class PrewarningBiz {
    JdbcDbStorer dbStorer;

    public PrewarningBiz() {
        dbStorer = JdbcDbStorer.getInstance();
    }

    public PrewarningBiz(JdbcDbStorer storer) {
        dbStorer = storer;
    }

    public Prewarning.Coll load(Prewarning.Coll me) throws NSException {
        return (Prewarning.Coll) dbStorer.load(me);
    }

    public Prewarning.Coll loadAll(Prewarning.Coll me, List<String> names) throws NSException {
        Prewarning.Query query = me.getQuery();
        if (names != null) {
            Monitor.Coll monitorColl = new Monitor.Coll();
            Monitor.Query monitorQuery = monitorColl.getQuery();
            monitorQuery.setIsvalid(1);
            if (names != null && !names.isEmpty()) {
                monitorQuery.setNameIDList(names);
            }
            new MonitorBiz().load(monitorColl);
            if (!monitorColl.isEmpty()) {
                query.setMonidIDList(monitorColl.stream().map(p -> p.getId()).distinct().collect(Collectors.toList()));
            } else {
                return new Prewarning.Coll();
            }
        }
        return (Prewarning.Coll) dbStorer.load(me);
    }

    public boolean insert(Prewarning.Entity me) throws NSException {
        return dbStorer.insert(me);
    }

    public boolean delete(Prewarning.Entity me) throws NSException {
        return dbStorer.delete(me);
    }

    public boolean delete(Prewarning.Query me) throws NSException {
        return dbStorer.delete(me, Prewarning.Entity.class);
    }

    public boolean update(Prewarning.Entity me) throws NSException {
        return dbStorer.update(me);
    }

    public Prewarning.Entity get(String auid) throws NSException {
        Prewarning.Query query = new Prewarning.Query();
        query.setAuid(auid);
        Prewarning.Coll results = load(new Prewarning.Coll(query));
        return results.isEmpty() ? null : results.get(0);
    }


    public int countMonkey(Prewarning.Query query) throws NSException {
        DbSelectBuilder fields = new DbSelectBuilder(dbStorer, null);
        fields.addField("count", "count(distinct monkey)");
        query.selectFields = fields;
        query.start = 0;
        query.count = 1;
        Prewarning.Coll results = this.load(new Prewarning.Coll(query));
        return results.isEmpty() ? 0 : results.get(0).getCount();
    }

    public Prewarning.Coll getStatusById(List<String> ids, long start) throws NSException {
        Prewarning.Query query = new Prewarning.Query();
        DbSelectBuilder fields = new DbSelectBuilder(dbStorer, null);
        fields.addField("monid");
        fields.addField("count", "count(1)");
        fields.addField("scs", "count(distinct servicecode)");
        query.selectFields = fields;
        query.skipTotalCount = true;
        query.setMonidIDList(ids);
        query.setFromevtime((int) start);
        query.groupBy = Prewarning.GroupByEnum.MONID;
        return this.load(new Prewarning.Coll(query));
    }

    public List<String> getMonkeyList() throws NSException {
        Prewarning.Coll coll = new Prewarning.Coll();
        Prewarning.Query query = coll.getQuery();
        DbSelectBuilder selectBuilder = new DbSelectBuilder(dbStorer, null);
        selectBuilder.addField("monkey", "distinct(monkey)");
        query.selectFields = selectBuilder;
        this.load(coll);
        return coll.stream().map(p -> p.getMonkey()).distinct().collect(Collectors.toList());
    }


}

