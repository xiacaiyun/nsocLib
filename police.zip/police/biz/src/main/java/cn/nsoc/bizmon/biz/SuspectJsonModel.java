package cn.nsoc.bizmon.biz;

import org.springframework.util.StringUtils;

public class SuspectJsonModel {
    private String district;
    private String gender;
    private String bornplace;
    private String residenceplace;
    private String remark1;
    private String remark2;
    private String remark3;
    private String groupnickname;
    private String group;
    private String nickname;
    private String wxgroupname;
    private String addrbookname;
    private String wxname;
    private String qqgroup;
    private String importantperson;

    public String getDistrict() {
        return district;
    }

    public void setDistrict(String district) {
        this.district = district;
    }

    public String getGender() {
        return gender;
    }

    public void setGender(String gender) {
        this.gender = gender;
    }

    public String getBornplace() {
        return bornplace;
    }

    public void setBornplace(String bornplace) {
        this.bornplace = bornplace;
    }

    public String getResidenceplace() {
        return residenceplace;
    }

    public void setResidenceplace(String residenceplace) {
        this.residenceplace = residenceplace;
    }

    public String getRemark1() {
        return remark1;
    }

    public void setRemark1(String remark1) {
        this.remark1 = remark1;
    }

    public String getRemark2() {
        return remark2;
    }

    public void setRemark2(String remark2) {
        this.remark2 = remark2;
    }

    public String getRemark3() {
        return remark3;
    }

    public void setRemark3(String remark3) {
        this.remark3 = remark3;
    }

    public String getGroupnickname() {
        return groupnickname;
    }

    public void setGroupnickname(String groupnickname) {
        this.groupnickname = groupnickname;
    }

    public String getGroup() {
        return group;
    }

    public void setGroup(String group) {
        this.group = group;
    }

    public String getNickname() {
        return nickname;
    }

    public void setNickname(String nickname) {
        this.nickname = nickname;
    }

    public String getWxgroupname() {
        return wxgroupname;
    }

    public void setWxgroupname(String wxgroupname) {
        this.wxgroupname = wxgroupname;
    }

    public String getAddrbookname() {
        return addrbookname;
    }

    public void setAddrbookname(String addrbookname) {
        this.addrbookname = addrbookname;
    }

    public String getWxname() {
        return wxname;
    }

    public void setWxname(String wxname) {
        this.wxname = wxname;
    }

    public String getQqgroup() {
        return qqgroup;
    }

    public void setQqgroup(String qqgroup) {
        this.qqgroup = qqgroup;
    }

    public String getImportantperson() {
        return importantperson;
    }

    public void setImportantperson(String importantperson) {
        if (!StringUtils.hasText(importantperson) || importantperson.compareToIgnoreCase("0") == 0) {
            this.importantperson = "0";
        } else {
            this.importantperson = "1";
        }

    }
}
