package cn.nsoc.bizmon.biz;


import java.util.UUID;

/**
 * Created by sam on 16-9-19.
 */
public class AppAuth {

    private AppAuth() {
    }

    public static final String SZAPPID = "F66D0BEB-23F6-4E0F-A574-FCBE0D4D008F";
    public static final String SZPRODUCTNAME = "NSOC业务应用监测系统";
    public static final String SZPRODUCTSHORTNAME = "BizMon";

    /// <summary>
    /// 基础模块
    /// </summary>
    public static final String SZBASICMODULEID = "50DD42CE-06A7-4503-B758-56704379DB88";


    public static final UUID AppID         = UUID.fromString(SZAPPID);
    public static final UUID BasicModuleID = UUID.fromString(SZBASICMODULEID);


    public static boolean isValidAppID(UUID appId) {
        return AppID.equals(appId);
    }

}
