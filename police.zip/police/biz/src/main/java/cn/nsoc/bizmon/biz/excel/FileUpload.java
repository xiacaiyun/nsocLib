package cn.nsoc.bizmon.biz.excel;

import cn.nsoc.base.entity.sys.NSException;
import org.springframework.web.multipart.commons.CommonsMultipartFile;

import java.io.IOException;
import java.util.List;
import java.util.Map;

/**
 * Created by Administrator on 2017/7/12.
 */

public interface FileUpload {
    public List<List<String>> readXls(CommonsMultipartFile file, Map<String,Integer> columnMap, int type) throws IOException;
    public boolean save(List<List<String>> list,Map<String,Integer>columnMap,String infoId,StringBuilder sb) throws NSException;
    public boolean batchUpdatePlace(List<List<String>> list,Map<String,Integer> columnMap) throws NSException;
}
