package cn.nsoc.bizmon.biz.mysql;

import cn.nsoc.base.entity.sys.NSException;
import cn.nsoc.bizmon.entity.defines.Constants;
import cn.nsoc.bizmon.entity.defines.PlaceStatus;
import cn.nsoc.bizmon.entity.mysql.Device;
import cn.nsoc.bizmon.entity.mysql.Devstat;
import cn.nsoc.bizmon.entity.mysql.Place;
import cn.nsoc.common.storer.annotation.QueryOperator;
import cn.nsoc.common.storer.db.DbSelectBuilder;
import cn.nsoc.common.storer.db.DbUpdateBuilder;
import cn.nsoc.common.storer.db.JdbcDbStorer;
import cn.nsoc.common.storer.option.QueryBuilder;
import org.apache.log4j.Logger;
import org.springframework.util.StringUtils;

import java.util.*;
import java.util.function.Function;
import java.util.stream.Collectors;


public class PlaceBiz {
	private static final Logger logger = Logger.getLogger(PlaceBiz.class);
	JdbcDbStorer dbStorer;


	public PlaceBiz() {
		dbStorer = JdbcDbStorer.getInstance();
	}

	public PlaceBiz(JdbcDbStorer storer) {
		dbStorer = storer;
	}

	public Place.Coll loadPartial(Place.Coll me) throws NSException {
		Place.Query query = me.getQuery();
		DbSelectBuilder builder = new DbSelectBuilder(dbStorer, null);
		builder.addField("servicecode");
		builder.addField("servicename");
		builder.addField("address");
		builder.addField("servicetype");
		builder.addField("lng");
		builder.addField("lat");
		query.selectFields = builder;
		return (Place.Coll) dbStorer.load(me);
	}
	public Place.Coll load(Place.Coll me) throws NSException {
		return (Place.Coll) dbStorer.load(me);
	}

	public Place.Coll loadForAlarm(Place.Coll me) throws NSException {
		Place.Query query = me.getQuery();
		DbSelectBuilder builder = new DbSelectBuilder(dbStorer, null);
		builder.addField("servicecode");
		builder.addField("servicename");
		builder.addField("address");
		query.selectFields = builder;
		query.setFromupdatetime(Constants.UPDATE_TIME);
		return (Place.Coll) dbStorer.load(me);
	}

	public Place.Coll loadByKeyword(Place.Coll me, String keyword) throws NSException {
		Place.Query query = me.getQuery();
		if (StringUtils.hasText(keyword)) {
			DbSelectBuilder dbSelectBuilder = new DbSelectBuilder(dbStorer, null);
			QueryBuilder inner = new QueryBuilder();
			inner.add("servicecode", QueryOperator.Like, keyword).or("servicename", QueryOperator.Like, keyword)
					.or("address", QueryOperator.Like, keyword);
			dbSelectBuilder.addQuery(new QueryBuilder().and(inner));
			query.selectFields = dbSelectBuilder;
		}
		if (query.getPlacestatus() != null) {
			List<String> scCodes = getServiceCodeByStatus(query.getPlacestatus());
			if(scCodes.isEmpty()){
				return new Place.Coll();
			}
			query.setServicecodeIDList(scCodes);
			query.setPlacestatus(null);
		}
		query.setFromupdatetime(Constants.UPDATE_TIME);
		return (Place.Coll) dbStorer.load(me);
	}


	public Place.Coll loadForFront(Place.Coll me, String keyword) throws NSException {
		Place.Query query = me.getQuery();
		StringBuilder sqlBuilder = new StringBuilder();

		if (StringUtils.hasText(keyword)) {
			sqlBuilder.append("(");
			sqlBuilder.append("SELECT * FROM db_bizmon.po_place where");
			String[] split = keyword.split(",");
			StringBuilder innerSql = new StringBuilder();
			for (String key : split) {
				innerSql.append(" servicename like '%" + key + "%'").append(" or address like '%" + key + "%' or");
			}
			innerSql.setLength(innerSql.length()-2);
			sqlBuilder.append(innerSql.toString());
			sqlBuilder.append(")");
		}
		if (query.getPlacestatus() != null) {
			List<String> scCodes = getServiceCodeByStatus(query.getPlacestatus());
			if(scCodes.isEmpty()){
				return new Place.Coll();
			}
			query.setServicecodeIDList(scCodes);
			query.setPlacestatus(null);
		}
		query.setFromupdatetime(Constants.UPDATE_TIME);
		return (Place.Coll) dbStorer.load(me,sqlBuilder.toString());
	}

	public boolean insert(Place.Entity me) throws NSException {
		return dbStorer.insert(me);
	}

	public boolean delete(Place.Entity me) throws NSException {
		return dbStorer.delete(me);
	}

	public boolean fakeDelete(Place.Entity me) throws NSException {
		DbUpdateBuilder updateBuilder = new DbUpdateBuilder(dbStorer);
		updateBuilder.include("deleted");
		me.setDeleted(1);
		return dbStorer.update(me,updateBuilder);
	}

	public boolean delete(Place.Query me) throws NSException {
		return dbStorer.delete(me, Place.Entity.class);
	}

	public boolean update(Place.Entity me) throws NSException {
		return dbStorer.update(me);
	}


	public boolean partUpdate(Place.Entity me, Place.Query query) throws NSException {
		DbUpdateBuilder updateBuilder = new DbUpdateBuilder(dbStorer);
		updateBuilder.include("policecode");
		updateBuilder.include("policename");
		return dbStorer.update(me,updateBuilder,query);
	}

	public boolean partUpdate(Place.Entity me) throws NSException {
		DbUpdateBuilder updateBuilder = new DbUpdateBuilder(dbStorer);
		updateBuilder.include("policecode");
		updateBuilder.include("policename");
		updateBuilder.include("property");
		updateBuilder.include("orgname");
		return dbStorer.update(me,updateBuilder);
	}

	public Place.Entity get(String servicecode) throws NSException {
		Place.Query query = new Place.Query();
		query.setServicecode(servicecode);
		Place.Coll results = load(new Place.Coll(query));
		return results.isEmpty() ? null : results.get(0);
	}

	public Place.Coll loadPlaceSummaryForFront(Place.Coll me,String keyword) throws NSException {
		Place.Query query = me.getQuery();
		DbSelectBuilder builder = new DbSelectBuilder(dbStorer, null);
		StringBuilder sqlBuilder = new StringBuilder();
		builder.addField("servicetype");
		builder.addField("placecount", "count(1)");
		if (StringUtils.hasText(keyword)) {
			sqlBuilder.append("(");
			sqlBuilder.append("SELECT * FROM db_bizmon.po_place where");
			String[] split = keyword.split(",");
			StringBuilder innerSql = new StringBuilder();
			for (String key : split) {
				innerSql.append(" servicename like '%" + key + "%'").append(" or address like '%" + key + "%' or");
			}
			innerSql.setLength(innerSql.length()-2);
			sqlBuilder.append(innerSql.toString());
			sqlBuilder.append(")");
		}
		query.selectFields = builder;
		query.setFromupdatetime(Constants.UPDATE_TIME);
		query.groupBy = Place.Query.GroupByEnum.SERVICETYPE;
		return (Place.Coll) dbStorer.load(me,sqlBuilder.toString());
	}

	public Place.Coll loadPlaceSummary(Place.Coll me,String keyword) throws NSException {
		Place.Query query = me.getQuery();
		DbSelectBuilder builder = new DbSelectBuilder(dbStorer, null);
		builder.addField("servicetype");
		builder.addField("placecount", "count(1)");
		if (StringUtils.hasText(keyword)) {
			QueryBuilder inner = new QueryBuilder();
			inner.add("servicecode", QueryOperator.Like, keyword).or("servicename", QueryOperator.Like, keyword)
					.or("address", QueryOperator.Like, keyword);
			builder.addQuery(new QueryBuilder().and(inner));
		}
		query.setDeleted(0);
		query.selectFields = builder;
		query.setFromupdatetime(Constants.UPDATE_TIME);
		query.groupBy = Place.Query.GroupByEnum.SERVICETYPE;
		return (Place.Coll) dbStorer.load(me);
	}


	public Map<String, String> getDictFromPlace(String type) throws NSException {
		Place.Coll coll = new Place.Coll();
		Place.Query query = coll.getQuery();
		query.count = Integer.MAX_VALUE;

		if ("service".compareToIgnoreCase(type) == 0) {
			load(coll);
			return coll.stream().collect(Collectors.toMap(Place.Entity::getServicecode, Place.Entity::getServicename));
		} else if ("police".compareToIgnoreCase(type) == 0) {
			loadpolicedict(coll);
			Map<String, String> map = new HashMap<>();
			coll.forEach(item->{
				if(item!=null && item.getPolicecode() != null){
					map.put(item.getPolicecode(),item.getPolicename());
				}
			});
			return map;
		} else {
			return null;
		}

	}

	public Place.Coll loadpolicedict(Place.Coll me) throws NSException {
		Place.Query query = me.getQuery();
		query.setPolicecodeIsOrNotNull(false);
		DbSelectBuilder builder = new DbSelectBuilder(dbStorer, null);
		builder.addField("policecode", "distinct policecode");
		builder.addField("policename");
		query.selectFields = builder;
		return (Place.Coll) dbStorer.load(me);
	}

	public Place.Coll loadservicetype(Place.Coll me) throws NSException {
		Place.Query query = me.getQuery();
		DbSelectBuilder builder = new DbSelectBuilder(dbStorer, null);
		builder.addField("servicetype", "distinct servicetype");
		query.selectFields = builder;
		return (Place.Coll) dbStorer.load(me);
	}


	public Map<String, PlaceStatus> findDeviceStatus(List<String> services, long evtime) throws NSException {

		DbSelectBuilder fields = new DbSelectBuilder(dbStorer, null);
		fields.addField("servicecode");
		fields.addField("devicecount", "count(1)");

		Place.Query query = new Place.Query();
		query.setServicecodeIDList(services);
		query.selectFields = fields;
		query.groupBy = Place.Query.GroupByEnum.SERVICECODE;

		Place.Coll coll = (Place.Coll) dbStorer.load(new Place.Coll(query), "po_device");
		Map<String, Long> total = coll.stream().collect(Collectors.toMap(Place.Entity::getServicecode, Place.Entity::getDevicecount));

		query.setEvtime(evtime);
		coll = (Place.Coll) dbStorer.load(new Place.Coll(query), "po_devstat");
		Map<String, Long> active = coll.stream().collect(Collectors.toMap(Place.Entity::getServicecode, Place.Entity::getDevicecount));
		Map<String, PlaceStatus> result = new HashMap<>(total.size());
		total.keySet().forEach(sc -> {
			if (!active.containsKey(sc)) {
				result.put(sc, PlaceStatus.DAMAGED);
			} else if (total.get(sc) == active.get(sc)) {
				result.put(sc, PlaceStatus.INTACT);
			} else
				result.put(sc, PlaceStatus.PARTIAL);
		});
		return result;
	}


	public int getPlaceStatus(String servicecode,Device.Coll dcoll,Devstat.Coll dscoll) throws NSException {

//		int devCount = 0;
		int devstCount = 0;

//		Device.Coll newdcoll = dcoll.find(servicecode);  //newdcoll这里其实是Device.Entity,所以=newdcoll.get(0)
//		devcie找不到该sc
//		if (newdcoll.isEmpty()) {
//			return PlaceStatus.DAMAGED.getVal();
//		} else {
//			devCount = newdcoll.get(0).devcount;
//		}
		Devstat.Coll newdscoll = dscoll.findByServiceCode(servicecode);

		if (newdscoll.isEmpty()) {
			return PlaceStatus.DAMAGED.getVal();
		} else {
			devstCount = newdscoll.get(0).getDevcount();
		}

		if (devstCount >0) {
			return PlaceStatus.INTACT.getVal();
		} else {
			return PlaceStatus.DAMAGED.getVal();
		}
	}

	public List<String> getServiceCodeByStatus(Integer statusValue) throws NSException {
		Place.Coll pColl = new Place.Coll();
		Place.Query placeQuery = pColl.getQuery();
		placeQuery.setFromupdatetime(Constants.UPDATE_TIME);
		new PlaceBiz().load(pColl);
		if(pColl.isEmpty()){
			return Collections.emptyList();
		}
		List<String> intactList = new ArrayList<>();
		List<String> damagedList = new ArrayList<>();
//		List<String> partialList = new ArrayList<>();

		List<String> scList = pColl.stream().map(Place.Entity::getServicecode).distinct().collect(Collectors.toList());

//		Device.Coll dColl = new Device.Coll();
//		DeviceBiz dbiz = new DeviceBiz();
//		Device.Query dquery = dColl.getQuery();
//		dquery.setServicecodeIDList(scList);
//		dbiz.loadDevCount(dColl);
//		Device.Coll deviceColl  = dbiz.loadByServiceCodes(scList);
//		if(deviceColl.isEmpty()){
//			return Collections.emptyList();
//		}
//		List<String> nos = deviceColl.stream().map(p -> p.getNo()).distinct().collect(Collectors.toList());
//		Map<String, Integer> deviceMap = dColl.stream().collect(Collectors.toMap(Device.Entity::getServicecode, Device.Entity::getDevcount));

		DevstatBiz dsbiz = new DevstatBiz();
		Devstat.Coll dsColl = dsbiz.loadDevOnlineCount(null, scList);
		Map<String, Integer> devStatMap = dsColl.stream().collect(Collectors.toMap(Devstat.Entity::getServicecode, Devstat.Entity::getDevcount));

		for (String s : scList) {
			//stat表与dev表数量相同，即为完好
			if (devStatMap.get(s)!=null) {
				intactList.add(s);
				continue;
			}
			//stat表中找不到该场所 或者 场所没装设备 即为损坏
			if (!devStatMap.containsKey(s)) {
				damagedList.add(s);
				continue;
			}
			//stat表与dev表数量不同
//			if (deviceMap.get(s) != devStatMap.get(s)) {
//				partialList.add(s);
//				continue;
//			}
		}
		//页面点击显示完好
		if (PlaceStatus.INTACT.getVal() == statusValue) {
			return intactList.stream().distinct().collect(Collectors.toList());
		}
		//页面点击显示损坏
		else if (PlaceStatus.DAMAGED.getVal() == statusValue) {
			return damagedList.stream().distinct().collect(Collectors.toList());
		}
		//页面点击显示部分
		else{
			return Collections.emptyList();
		}

	}


	public String getServiceNames(String servicecode,Map<String, String> serviceDictFromDb) throws NSException {
		String serviceNames = "";

		if(StringUtils.hasText(servicecode)) {
			if (Constants.SERVICE_CODE.equalsIgnoreCase(servicecode)) {
				return Constants.SERVICE_NAME;
			} else if (servicecode.indexOf(',') < 0) {
				return serviceDictFromDb.getOrDefault(servicecode, serviceNames);
			} else {
				List<String> serviceNamesList = new ArrayList<>();
				String[] split = servicecode.split(",");
				for (String s : split) {
					serviceNamesList.add(serviceDictFromDb.getOrDefault(s, ""));
				}
				serviceNames = String.join(",", serviceNamesList);
				return serviceNames;
			}
		}else {
			return serviceNames;
		}
	}
	
	public Map<String, Place.Entity> loadByCodes(List<String> scs) {
		Place.Coll coll = new Place.Coll();
		Place.Query query = coll.getQuery();
		query.setServicecodeIDList(scs);
		try {
			coll = loadPartial(coll);
		} catch (NSException e) {
			logger.error("place query failed", e);
			return new HashMap<String, Place.Entity>();
		}
		return coll.stream().collect(Collectors.toMap(Place.Entity::getServicecode, Function.identity()));
	}
	
	public List<String> loadByCodesForNames(List<String> scs) {
		Place.Coll coll = new Place.Coll();
		Place.Query query = coll.getQuery();
		query.setServicecodeIDList(scs);
		try {
			coll = loadPartial(coll);
		} catch (NSException e) {
			logger.error("place query failed", e);
			return null;
		}
		return coll.stream().map(Place.Entity::getServicename).collect(Collectors.toList());
	}
}

