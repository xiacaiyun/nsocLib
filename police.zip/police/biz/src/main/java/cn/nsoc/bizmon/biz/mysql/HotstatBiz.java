package cn.nsoc.bizmon.biz.mysql;

import static java.util.stream.Collectors.joining;

import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;
import org.apache.commons.lang3.StringUtils;
import cn.nsoc.base.entity.sys.NSException;
import cn.nsoc.bizmon.entity.mysql.Hotstat;
import cn.nsoc.bizmon.entity.mysql.Hotstat.Coll;
import cn.nsoc.bizmon.util.Hptimer;
import cn.nsoc.common.storer.db.DbSelectBuilder;
import cn.nsoc.common.storer.db.JdbcDbStorer;

public class HotstatBiz {
	public static final String GAPTIME = "gaptime";
	public static final String GAPWBCOUNT = "wbcount";
	public static final String GAPWIFICOUNT = "wificount";
	public static final String GAPAUDITCOUNT = "auditcount";
	public static final String GAPTOTAL = "total";
	public static final String PSNAME = "policename";
	public static final String SERVICECODE = "servicecode";
	private static final String OBJECT_NAME = "po_hotstat";

	JdbcDbStorer dbStorer;

	public HotstatBiz() {
		dbStorer = JdbcDbStorer.getInstance();
	}

	public HotstatBiz(JdbcDbStorer storer) {
		dbStorer = storer;
	}

	public Hotstat.Coll load(Hotstat.Coll me) throws NSException {
		return (Hotstat.Coll) dbStorer.load(me);
	}

	public boolean insert(Hotstat.Entity me) throws NSException {
		return dbStorer.insert(me);
	}

	public boolean delete(Hotstat.Entity me) throws NSException {
		return dbStorer.delete(me);
	}

	public boolean delete(Hotstat.Query me) throws NSException {
		return dbStorer.delete(me, Hotstat.Entity.class);
	}

	public boolean update(Hotstat.Entity me) throws NSException {
		return dbStorer.update(me);
	}

	public Hotstat.Entity get(int gaptime) throws NSException {
		Hotstat.Query query = new Hotstat.Query();
		query.setGaptime(gaptime);
		Hotstat.Coll results = load(new Hotstat.Coll(query));
		return results.isEmpty() ? null : results.get(0);
	}

	public Hotstat.Coll getStat(long start, long end, String place) throws NSException {
		Hotstat.Query query = new Hotstat.Query();
		query.setFromgaptime(start);
		query.setTogaptime(end);
		query.setServicecode(place);
		DbSelectBuilder builder = new DbSelectBuilder(dbStorer, null);
		builder.addField(GAPTIME);
		builder.addField(GAPWBCOUNT);
		builder.addField(GAPWIFICOUNT);
		builder.addField(GAPAUDITCOUNT);
		builder.addField(GAPTOTAL);
		builder.addField(SERVICECODE);
		query.selectFields = builder;
		query.skipTotalCount = true;
		query.orderBy = Hotstat.Query.GroupByEnum.GAPTIME__DESC;
		Hotstat.Coll me = new Hotstat.Coll(query);
		return load(me);
	}

	public Hotstat.Coll getTotal(long start, long end, List<String> scs, List<String> polices) throws NSException {
		DbSelectBuilder fields = new DbSelectBuilder(dbStorer, null);
		fields.addField(GAPTIME);
		fields.addField(GAPWBCOUNT);
		fields.addField(GAPWIFICOUNT);
		fields.addField(GAPAUDITCOUNT);
		fields.addField(GAPTOTAL);
		Hotstat.Query query = new Hotstat.Query();
		query.selectFields = fields;
		query.skipTotalCount = true;
		query.groupBy = Hotstat.Query.GroupByEnum.GAPTIME;
		query.orderBy = Hotstat.Query.GroupByEnum.GAPTIME__DESC;
		StringBuilder sb = new StringBuilder();
		sb.append("(");
		sb.append(String.format(
				" SELECT %s, sum(%s) as total, sum(%s) as wbcount, sum(%s) as wificount, sum(%s) as auditcount ",
				GAPTIME, GAPTOTAL, GAPWBCOUNT, GAPWIFICOUNT, GAPAUDITCOUNT));
		sb.append(String.format(" FROM %s where %s >= %d ", OBJECT_NAME, GAPTIME, start));
		sb.append(String.format(" and %s < %d ", GAPTIME, end));
		if (scs != null && !scs.isEmpty()) {
			sb.append(String.format(" and servicecode in ('%s')", scs.stream().collect(joining("','"))));
		} else if (polices != null && !polices.isEmpty()) {
			sb.append(String.format(
					" and servicecode in (select servicecode from po_place p where p.policecode in ('%s'))",
					polices.stream().collect(joining("','"))));
		}
		sb.append(String.format(" GROUP BY %s ", GAPTIME));
		sb.append(")");
		Hotstat.Coll me = new Hotstat.Coll(query);
		return (Hotstat.Coll) dbStorer.load(me, sb.toString());
	}

	public Coll getRealtime(long start, long end, List<String> scs, List<String> polices) throws NSException {
		DbSelectBuilder fields = new DbSelectBuilder(dbStorer, null);
		fields.addField(SERVICECODE);
		fields.addField(GAPTIME);
		fields.addField(GAPWBCOUNT);
		fields.addField(GAPWIFICOUNT);
		fields.addField(GAPAUDITCOUNT);
		fields.addField(GAPTOTAL);
		Hotstat.Query query = new Hotstat.Query();
		query.selectFields = fields;
		query.skipTotalCount = true;
		query.groupBy = Hotstat.Query.GroupByEnum.SERVICECODE;
		StringBuilder sb = new StringBuilder();
		sb.append("(");
		sb.append(String.format(
				" SELECT %s, max(%s) as gaptime, round(avg(%s)) as total, round(avg(%s)) as wbcount, "
						+ " round(avg(%s)) as wificount, round(avg(%s)) as auditcount ",
				SERVICECODE, GAPTIME, GAPTOTAL, GAPWBCOUNT, GAPWIFICOUNT, GAPAUDITCOUNT));
		sb.append(String.format(" FROM %s where %s >= %d ", OBJECT_NAME, GAPTIME, start));
		sb.append(String.format(" and %s < %d ", GAPTIME, end));
		if (scs != null && !scs.isEmpty()) {
			sb.append(String.format(" and servicecode in ('%s')", scs.stream().collect(joining("','"))));
		} else if (polices != null && !polices.isEmpty()) {
			sb.append(String.format(
					" and servicecode in (select servicecode from po_place p where p.policecode in ('%s'))",
					polices.stream().collect(joining("','"))));
		}
		sb.append(String.format(" GROUP BY %s ", SERVICECODE));
		sb.append(")");
		Hotstat.Coll me = new Hotstat.Coll(query);
		return (Hotstat.Coll) dbStorer.load(me, sb.toString());
	}

	public Hotstat.Coll getTotal(long start, long end, List<String> scs, List<String> polices, String type)
			throws NSException {
		DbSelectBuilder fields = new DbSelectBuilder(dbStorer, null);
		fields.addField(GAPTIME);
		fields.addField(GAPTOTAL);
		Hotstat.Query query = new Hotstat.Query();
		query.selectFields = fields;
		query.skipTotalCount = true;
		query.orderBy = Hotstat.Query.GroupByEnum.GAPTIME__DESC;
		StringBuilder sb = new StringBuilder();
		sb.append("(");
		sb.append(String.format(" SELECT %s, sum(%s) as total ", GAPTIME, GAPTOTAL));
		sb.append(String.format(" FROM %s where %s >= %d ", OBJECT_NAME, GAPTIME, start));
		sb.append(String.format(" and %s < %d ", GAPTIME, end));
		if (scs != null && !scs.isEmpty()) {
			sb.append(String.format(" and servicecode in ('%s')", scs.stream().collect(joining("','"))));
		} else if (polices != null && !polices.isEmpty()) {
			sb.append(String.format(
					" and servicecode in (select servicecode from po_place p where p.policecode in ('%s'))",
					polices.stream().collect(joining("','"))));
		}
		if (StringUtils.isNotBlank(type)) {
			sb.append(String.format(
					" and servicecode in (select servicecode from po_place p where p.servicetype = '%s')", type));
		}
		sb.append(String.format(" GROUP BY %s ", GAPTIME));
		sb.append(")");
		Hotstat.Coll me = new Hotstat.Coll(query);
		return (Hotstat.Coll) dbStorer.load(me, sb.toString());
	}

	public Coll getRealtime(long start, long end, List<String> scs, List<String> polices, String type)
			throws NSException {
		DbSelectBuilder fields = new DbSelectBuilder(dbStorer, null);
		fields.addField(SERVICECODE);
		fields.addField(GAPTIME);
		fields.addField(GAPTOTAL);
		Hotstat.Query query = new Hotstat.Query();
		query.selectFields = fields;
		query.skipTotalCount = true;
		StringBuilder sb = new StringBuilder();
		sb.append("(");
		sb.append(String.format(" SELECT %s, max(%s) as gaptime, round(avg(%s)) as total ", SERVICECODE, GAPTIME,
				GAPTOTAL));
		sb.append(String.format(" FROM %s where %s >= %d ", OBJECT_NAME, GAPTIME, start));
		sb.append(String.format(" and %s < %d ", GAPTIME, end));
		if (scs != null && !scs.isEmpty()) {
			sb.append(String.format(" and servicecode in ('%s')", scs.stream().collect(joining("','"))));
		} else if (polices != null && !polices.isEmpty()) {
			sb.append(String.format(
					" and servicecode in (select servicecode from po_place p where p.policecode in ('%s'))",
					polices.stream().collect(joining("','"))));
		}
		if (StringUtils.isNotBlank(type)) {
			sb.append(String.format(
					" and servicecode in (select servicecode from po_place p where p.servicetype = '%s')", type));
		}
		sb.append(String.format(" GROUP BY %s ", SERVICECODE));
		sb.append(")");
		Hotstat.Coll me = new Hotstat.Coll(query);
		return (Hotstat.Coll) dbStorer.load(me, sb.toString());
	}

}
