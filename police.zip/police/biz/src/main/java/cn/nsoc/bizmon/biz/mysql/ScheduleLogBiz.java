package cn.nsoc.bizmon.biz.mysql;

import cn.nsoc.base.entity.sys.NSException;
import cn.nsoc.bizmon.entity.mysql.ScheduleLog;
import cn.nsoc.common.storer.db.JdbcDbStorer;

public class ScheduleLogBiz {
	JdbcDbStorer dbStorer;

	public ScheduleLogBiz(){
		dbStorer = JdbcDbStorer.getInstance();
	}

	public ScheduleLogBiz(JdbcDbStorer storer){
		dbStorer = storer;
	}

	public ScheduleLog.Coll load(ScheduleLog.Coll me) throws NSException {
		return (ScheduleLog.Coll)dbStorer.load(me);
	}

	public boolean insert(ScheduleLog.Entity me) throws NSException {
		return dbStorer.insert(me);
	}

	public boolean delete(ScheduleLog.Entity me) throws NSException {
		return dbStorer.delete(me);
	}

	public boolean update(ScheduleLog.Entity me) throws NSException {
		return dbStorer.update(me);
	}

	public ScheduleLog.Entity get(long id) throws NSException {
		ScheduleLog.Query query = new ScheduleLog.Query();
		query.setId(id);
		ScheduleLog.Coll results = load(new ScheduleLog.Coll(query));
		return results.isEmpty() ? null:results.get(0);
	}

}

