package cn.nsoc.bizmon.biz.mysql;

import cn.nsoc.base.entity.sys.NSException;
import cn.nsoc.bizmon.entity.mysql.Config;
import cn.nsoc.common.storer.db.JdbcDbStorer;

import java.util.HashMap;
import java.util.Map;
import java.util.stream.Collectors;

/**
 * Created by Carol on 2017/9/7.
 */
public class ConfigBiz {

    JdbcDbStorer dbStorer;

    public ConfigBiz(){
        dbStorer = JdbcDbStorer.getInstance();
    }

    public ConfigBiz(JdbcDbStorer storer){
        dbStorer = storer;
    }

    public Config.Coll load(Config.Coll me) throws NSException {
        return (Config.Coll)dbStorer.load(me);
    }


    public boolean insert(Config.Entity me) throws NSException {
        return dbStorer.insert(me);
    }

    public boolean delete(Config.Entity me) throws NSException {
        return dbStorer.delete(me);
    }

    public boolean delete(Config.Query me) throws NSException {
        return dbStorer.delete(me, Config.Entity.class);
    }

    public boolean update(Config.Entity me) throws NSException {
        return dbStorer.update(me);
    }

    public Config.Entity get(int id) throws NSException {
        Config.Query query = new Config.Query();
        query.setId(id);
        Config.Coll results = load(new Config.Coll(query));
        return results.isEmpty() ? null:results.get(0);
    }


    public Map<Integer, String> getConfigDict() throws NSException {
        Config.Coll coll = new Config.Coll();
        load(coll);
        if(!coll.isEmpty()){
            return coll.stream().collect(Collectors.toMap(p->p.getId(),p->p.getDetail()));
        }else {
            return new HashMap<>();
        }

    }






}
