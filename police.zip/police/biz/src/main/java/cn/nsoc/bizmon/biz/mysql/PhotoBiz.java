package cn.nsoc.bizmon.biz.mysql;

import cn.nsoc.base.entity.sys.NSException;
import cn.nsoc.bizmon.entity.mysql.Photo;
import cn.nsoc.common.storer.db.JdbcDbStorer;
import org.springframework.util.StringUtils;

/**
 * Created by Carol on 2017/9/7.
 */
public class PhotoBiz {

    JdbcDbStorer dbStorer;

    public PhotoBiz(){
        dbStorer = JdbcDbStorer.getInstance();
    }

    public PhotoBiz(JdbcDbStorer storer){
        dbStorer = storer;
    }

    public Photo.Coll load(Photo.Coll me) throws NSException {
        Photo.Query query = me.getQuery();
        query.orderBy = Photo.Query.OrderBy.time__desc;
        return (Photo.Coll)dbStorer.load(me);
    }


    public boolean insert(Photo.Entity me) throws NSException {
        return dbStorer.insert(me);
    }

    public boolean delete(Photo.Entity me) throws NSException {
        return dbStorer.delete(me);
    }

    public boolean delete(Photo.Query me) throws NSException {
        return dbStorer.delete(me, Photo.Entity.class);
    }

    public boolean update(Photo.Entity me) throws NSException {
        return dbStorer.update(me);
    }

    public Photo.Entity get(String id) throws NSException {
        Photo.Query query = new Photo.Query();
        query.setId(id);
        Photo.Coll results = load(new Photo.Coll(query));
        return results.isEmpty() ? null:results.get(0);
    }

    public Photo.Entity findByPid(String pid) throws NSException {
        if(!StringUtils.hasText(pid)){
            return null;
        }
        Photo.Query query = new Photo.Query();
        query.setPid(pid);
        Photo.Coll results = load(new Photo.Coll(query));
        return results.isEmpty() ? null:results.get(0);
    }

}
