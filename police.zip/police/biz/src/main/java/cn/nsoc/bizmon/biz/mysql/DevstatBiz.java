package cn.nsoc.bizmon.biz.mysql;

import cn.nsoc.base.entity.sys.NSException;
import cn.nsoc.bizmon.entity.defines.Constants;
import cn.nsoc.bizmon.entity.mysql.Devstat;
import cn.nsoc.bizmon.util.Hptimer;
import cn.nsoc.common.storer.db.DbSelectBuilder;
import cn.nsoc.common.storer.db.JdbcDbStorer;

import java.util.List;

public class DevstatBiz {
	JdbcDbStorer dbStorer;

	public DevstatBiz(){
		dbStorer = JdbcDbStorer.getInstance();
	}

	public DevstatBiz(JdbcDbStorer storer){
		dbStorer = storer;
	}

	public Devstat.Coll load(Devstat.Coll me) throws NSException {
		return (Devstat.Coll)dbStorer.load(me);
	}

	public Devstat.Coll loadDevOnlineCount(List<String> nos, List<String> scCodeList) throws NSException {
		Devstat.Coll coll = new Devstat.Coll();
		Devstat.Query query = coll.getQuery();
		query.setDevnoIDList(nos);
		query.setServicecodeIDList(scCodeList);
		query.setFromevtime(((int) Hptimer.nowSeconds() - Constants.DEVICE_STATUS_GAP));
		DbSelectBuilder builder = new DbSelectBuilder(dbStorer,null);
		builder.addField("servicecode");
		builder.addField("devcount","count(distinct devno)");
		query.selectFields = builder;
		query.groupBy = Devstat.Query.GroupByEnum.SERVICECODE;
		return (Devstat.Coll)dbStorer.load(coll);
	}

	public boolean insert(Devstat.Entity me) throws NSException {
		return dbStorer.insert(me);
	}

	public boolean delete(Devstat.Entity me) throws NSException {
		return dbStorer.delete(me);
	}

	public boolean delete(Devstat.Query query) throws NSException {
		return dbStorer.delete(query, Devstat.Entity.class);
	}
	
	public boolean update(Devstat.Entity me) throws NSException {
		return dbStorer.update(me);
	}

	public Devstat.Entity get(String devno,String servicecode) throws NSException {
		Devstat.Query query = new Devstat.Query();
		query.setDevno(devno);
		query.setServicecode(servicecode);
		Devstat.Coll results = load(new Devstat.Coll(query));
		return results.isEmpty() ? null:results.get(0);
	}

	public Devstat.Coll findonline(int evtime)throws NSException{
		Devstat.Coll coll = new Devstat.Coll();
		Devstat.Query query = coll.getQuery();
		query.setFromevtime(evtime);
		return (Devstat.Coll)dbStorer.load(coll);
	}

}

