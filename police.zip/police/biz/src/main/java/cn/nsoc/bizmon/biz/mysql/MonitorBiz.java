package cn.nsoc.bizmon.biz.mysql;

import cn.nsoc.base.entity.sys.NSException;
import cn.nsoc.bizmon.entity.defines.MonType;
import cn.nsoc.bizmon.entity.mysql.Monitor;
import cn.nsoc.common.storer.db.DbSelectBuilder;
import cn.nsoc.common.storer.db.DbUpdateBuilder;
import cn.nsoc.common.storer.db.JdbcDbStorer;
import cn.nsoc.common.util.Misc;
import org.apache.log4j.Logger;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

public class MonitorBiz {
    JdbcDbStorer dbStorer;

    private static final Logger logger = Logger.getLogger(MonitorBiz.class);

    public MonitorBiz() {
        dbStorer = JdbcDbStorer.getInstance();
    }

    public MonitorBiz(JdbcDbStorer storer) {
        dbStorer = storer;
    }

    public Monitor.Coll load(Monitor.Coll me) throws NSException {
        return (Monitor.Coll) dbStorer.load(me);
    }

    public Monitor.Coll loadValid(Monitor.Coll me) throws NSException {
        me.getQuery().setIsvalid(1);
        return (Monitor.Coll) dbStorer.load(me);
    }

    public Monitor.Coll loadPartial(Monitor.Coll me) throws NSException {
        Monitor.Query query = me.getQuery();
        query.skipTotalCount = true;
        DbSelectBuilder selectBuilder = new DbSelectBuilder(dbStorer, null);
        selectBuilder.addField("name,servicecode,monkey,montype,starttime,endtime".split(","));
        query.selectFields = selectBuilder;
        return (Monitor.Coll) dbStorer.load(me);
    }

    public Monitor.Coll selectName(Monitor.Coll me) throws NSException {
        Monitor.Query query = me.getQuery();
        if (!query.partialMode) {
            DbSelectBuilder selectBuilder = new DbSelectBuilder(dbStorer, null);
            selectBuilder.addField("name", "ANY_VALUE(name)");
            selectBuilder.addField("monkey", "ANY_VALUE(monkey)");
            selectBuilder.addField("servicecode", "ANY_VALUE(servicecode)");
            selectBuilder.addField("montype", "ANY_VALUE(montype)");
            selectBuilder.addField("starttime", "ANY_VALUE(starttime)");
            selectBuilder.addField("endtime", "ANY_VALUE(endtime)");
            selectBuilder.addField("isvalid", "ANY_VALUE(isvalid)");
            selectBuilder.addField("id", "ANY_VALUE(id)");
            selectBuilder.addField("suspectid", "ANY_VALUE(suspectid)");
            selectBuilder.addField("count", "count(1)");
            query.selectFields = selectBuilder;
        }else {
            DbSelectBuilder selectBuilder = new DbSelectBuilder(dbStorer, null);
            selectBuilder.addField("name");
            query.selectFields = selectBuilder;
        }
        query.groupBy = Monitor.GroupByEnum.NAME;
        return (Monitor.Coll) dbStorer.load(me);
    }


    public boolean insert(Monitor.Entity me) throws NSException {
        me.setIsvalid(1);
        return dbStorer.insert(me);
    }

    public boolean delete(Monitor.Entity me) throws NSException {
        return dbStorer.delete(me);
    }

    public boolean updateIsValid(Monitor.Entity me, Integer isValid) throws NSException {
        DbUpdateBuilder ub = new DbUpdateBuilder(JdbcDbStorer.getInstance());
        ub.include("isvalid");
        me.setIsvalid(isValid);
        return JdbcDbStorer.getInstance().update(me, ub);

    }

    public boolean update(Monitor.Entity me) throws NSException {
        return dbStorer.update(me);
    }

    public boolean batchUpdate(Monitor.Entity me, Monitor.Query query) throws NSException {
        DbUpdateBuilder updateBuilder = new DbUpdateBuilder(dbStorer);
        updateBuilder.include(new String[]{"name", "servicecode", "montype", "starttime", "endtime"});
        return dbStorer.update(me, updateBuilder, query);
    }


    public Monitor.Entity get(String id) throws NSException {
        Monitor.Query query = new Monitor.Query();
        query.setId(id);
        Monitor.Coll results = load(new Monitor.Coll(query));
        return results.isEmpty() ? null : results.get(0);
    }

    public List<String> getIdListbyName(String names) throws NSException {
        Monitor.Query query = new Monitor.Query();
        query.setNameIDList(Misc.strToStrList(names));
//        query.setIsvalid(1);
        Monitor.Coll results = load(new Monitor.Coll(query));
        return results.isEmpty() ? null : results.stream().map(l -> l.getId()).distinct().collect(Collectors.toList());
    }

    public List<String> getIdListbyName(List<String> names) throws NSException {
        Monitor.Query query = new Monitor.Query();
        query.setNameIDList(names);
        query.setIsvalid(1);
        Monitor.Coll results = load(new Monitor.Coll(query));
        return results.isEmpty() ? null : results.stream().map(l -> l.getId()).distinct().collect(Collectors.toList());
    }

    public Monitor.Coll getMonitorsbyName(List<String> names) throws NSException {
        Monitor.Query query = new Monitor.Query();
        query.setNameIDList(names);
        query.setIsvalid(1);
        Monitor.Coll results = load(new Monitor.Coll(query));
        return results.isEmpty() ? new Monitor.Coll() : results;
    }

    public int findTotal() throws NSException {
        Monitor.Query query = new Monitor.Query();
        query.setIsvalid(1);
        DbSelectBuilder fields = new DbSelectBuilder(dbStorer, null);
        fields.addField("total", "count(1)");
        query.selectFields = fields;
        query.skipTotalCount = true;
        Monitor.Coll me = new Monitor.Coll(query);
        this.load(me);
        if (!me.isEmpty()) return me.get(0).getTotal();
        return 0;
    }

    public Monitor.Entity countNameKeyword(String monkey, Integer montype, List<String> nameIDList) throws NSException {
        Monitor.Query query = new Monitor.Query();
        DbSelectBuilder fields = new DbSelectBuilder(dbStorer, null);
        fields.addField("namecount", "count(distinct name)");
        fields.addField("monkeycount", "count(distinct monkey)");
        query.selectFields = fields;
        query.setIsvalid(1);
        query.setMonkey(monkey);
        query.setMontype(montype);
        query.setNameIDList(nameIDList);
        Monitor.Coll results = load(new Monitor.Coll(query));
        return results.firstOrDefault(); //返回entity   firstOrDefault()=get(0)
    }

    public List<Object> toHtml(Monitor.Coll coll) throws NSException {
        PlaceBiz placeBiz = new PlaceBiz();
        Map<String, String> service = placeBiz.getDictFromPlace("service");
        List<Object> result = new ArrayList<>();
        coll.forEach(l -> {
            Map<String, Object> map = new HashMap<>();
            map.put("id", l.getId());
            map.put("monkey", l.getMonkey());
            map.put("montype", MonType.getByVal(l.getMontype()) == null ? "" : MonType.getByVal(l.getMontype()).getDes());
            map.put("montypeval", l.getMontype());
            map.put("name", l.getName());
            map.put("starttime", Misc.toStdString(l.getStarttime()));
            map.put("endtime", Misc.toStdString(l.getEndtime()));
            map.put("servicecode", l.getServicecode());
            map.put("isvalid", l.getIsvalid());
            map.put("count", l.count);
            try {
                map.put("servicename", placeBiz.getServiceNames(l.getServicecode(), service));
            } catch (NSException e) {
                logger.warn("serviceName find failed! message: " + e);
            }
            result.add(map);
        });
        return result;
    }


}

