package cn.nsoc.bizmon.biz.mysql;

import cn.nsoc.base.entity.sys.NSException;
import cn.nsoc.bizmon.entity.defines.Constants;
import cn.nsoc.bizmon.entity.mysql.Device;
import cn.nsoc.bizmon.entity.mysql.Devstat;
import cn.nsoc.bizmon.entity.mysql.Place;
import cn.nsoc.bizmon.util.Hptimer;
import cn.nsoc.common.storer.annotation.QueryOperator;
import cn.nsoc.common.storer.db.DbSelectBuilder;
import cn.nsoc.common.storer.db.JdbcDbStorer;
import cn.nsoc.common.storer.option.QueryBuilder;
import cn.nsoc.common.util.Misc;
import org.springframework.util.StringUtils;

import java.util.List;
import java.util.stream.Collectors;

public class DeviceBiz {
    JdbcDbStorer dbStorer;

    public DeviceBiz() {
        dbStorer = JdbcDbStorer.getInstance();
    }

    public DeviceBiz(JdbcDbStorer storer) {
        dbStorer = storer;
    }

    public Device.Coll load(Device.Coll me) throws NSException {
        return (Device.Coll) dbStorer.load(me);
    }

    public Device.Coll loadDevCount(Device.Coll me) throws NSException {
        Device.Query query = me.getQuery();
        DbSelectBuilder builder = new DbSelectBuilder(dbStorer, null);
        builder.addField("devcount", "count(no)");
        builder.addField("servicecode");
        query.selectFields = builder;
        query.groupBy = Device.Query.GroupByEnum.SERVICECODE;
        return (Device.Coll) dbStorer.load(me);
    }

    public Place.Coll getSummary() throws NSException {
        DbSelectBuilder fields = new DbSelectBuilder(dbStorer, null);
        fields.addField("servicetype");
        fields.addField("devicecount", "count(1)");
        Place.Query query = new Place.Query();
        query.selectFields = fields;
        query.groupBy = Place.Query.GroupByEnum.SERVICETYPE;
        String tableName = String.format("(select a.servicecode,a.servicetype from po_place a,po_device b where a.servicecode = b.servicecode" +
                " and a.updatetime >= '%s')", Misc.toStdString(Constants.UPDATE_TIME));
        Place.Coll me = new Place.Coll(query);
        return (Place.Coll) dbStorer.load(me, tableName);
    }

    public boolean insert(Device.Entity me) throws NSException {
        return dbStorer.insert(me);
    }

    public boolean delete(Device.Entity me) throws NSException {
        return dbStorer.delete(me);
    }

    public boolean update(Device.Entity me) throws NSException {
        return dbStorer.update(me);
    }

    public Device.Entity get(String no) throws NSException {
        Device.Query query = new Device.Query();
        query.setNo(no);
        Device.Coll results = load(new Device.Coll(query));
        return results.isEmpty() ? null : results.get(0);
    }

    public Device.Coll loaddevice(Device.Coll me, int DEVICE_STATUS_GAP, String keyword) throws NSException {
        Device.Query query = me.getQuery();
        DbSelectBuilder builder = new DbSelectBuilder(dbStorer, null);
        builder.addField("no");
        builder.addField("mac");
        builder.addField("servicecode");
//		builder.addField("evtime","(select evtime from po_devstat s where s.devno = t.no)");
//		builder.addField("devtype","(select devtype from po_devstat s where s.devno = t.no)");
        builder.addField("orgname", "(select orgname from po_place s where s.servicecode = t.servicecode)");

        if (query.getIsonline() != null) {
            DevstatBiz devstatBiz = new DevstatBiz();
            Devstat.Coll onlineColl = devstatBiz.findonline((int) (Hptimer.nowSeconds() - DEVICE_STATUS_GAP));
            if (!onlineColl.isEmpty()) {
                if (query.getIsonline()) {
                    query.setNoIDList(onlineColl.stream().map(l -> l.getDevno()).distinct().collect(Collectors.toList()));
                } else {
                    query.setNoNotInIDList(onlineColl.stream().map(l -> l.getDevno()).distinct().collect(Collectors.toList()));
                }
            } else if (query.getIsonline()) {
                return new Device.Coll();
            }
            query.setIsonline(null);
        }
        if (StringUtils.hasText(keyword)) {
            QueryBuilder inner = new QueryBuilder();
            inner.add("no", QueryOperator.Like, keyword).or("mac", QueryOperator.Like, keyword);
            builder.addQuery(new QueryBuilder().and(inner));
        }
        query.selectFields = builder;
        return (Device.Coll) dbStorer.load(me);
    }

    public Device.Coll loadByServiceCodes(List<String> scs) throws NSException {
        if (scs != null && scs.isEmpty()) {
            return new Device.Coll();
        }
        Device.Coll coll = new Device.Coll();
        Device.Query query = coll.getQuery();
        query.setServicecodeIDList(scs);
        return (Device.Coll) dbStorer.load(coll);
    }
}

