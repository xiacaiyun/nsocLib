package cn.nsoc.bizmon.biz.mysql;

import cn.nsoc.base.entity.sys.NSException;
import cn.nsoc.bizmon.entity.mysql.Notice;
import cn.nsoc.common.storer.db.JdbcDbStorer;


public class NoticeBiz {

    JdbcDbStorer dbStorer;

    public NoticeBiz(){
        dbStorer = JdbcDbStorer.getInstance();
    }

    public NoticeBiz(JdbcDbStorer storer){
        dbStorer = storer;
    }

    public Notice.Coll load(Notice.Coll me) throws NSException {
        return (Notice.Coll)dbStorer.load(me);
    }


    public boolean insert(Notice.Entity me) throws NSException {
        return dbStorer.insert(me);
    }

    public boolean delete(Notice.Entity me) throws NSException {
        return dbStorer.delete(me);
    }

    public boolean delete(Notice.Query me) throws NSException {
        return dbStorer.delete(me, Notice.Entity.class);
    }

    public boolean update(Notice.Entity me) throws NSException {
        return dbStorer.update(me);
    }

    public Notice.Entity get(String id) throws NSException {
        Notice.Query query = new Notice.Query();
        query.setId(id);
        Notice.Coll results = load(new Notice.Coll(query));
        return results.isEmpty() ? null:results.get(0);
    }


}
