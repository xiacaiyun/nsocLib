package cn.nsoc.bizmon.biz.excel;

import cn.nsoc.base.entity.sys.NSException;
import cn.nsoc.bizmon.biz.SuspectJsonModel;
import cn.nsoc.bizmon.biz.mysql.PlaceBiz;
import cn.nsoc.bizmon.biz.mysql.SuspectBiz;
import cn.nsoc.bizmon.entity.defines.Constants;
import cn.nsoc.bizmon.entity.mysql.Place;
import cn.nsoc.bizmon.entity.mysql.Suspect;
import cn.nsoc.common.util.IDWorker;
import cn.nsoc.common.util.IntEncoder;
import cn.nsoc.common.util.Misc;
import org.apache.log4j.Logger;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;
import org.springframework.web.multipart.commons.CommonsMultipartFile;

import java.io.IOException;
import java.lang.reflect.Field;
import java.sql.SQLException;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;


/**
 * Created by Administrator on 2017/7/12.
 */
@Service("fileupload")
public class FileUploadImpl implements FileUpload {

    private static Logger logger = Logger.getLogger(FileUploadImpl.class);

    @Override
    public List<List<String>> readXls(CommonsMultipartFile file, Map<String, Integer> columnMap, int type) throws IOException {
        Workbook wb = null;
        String fileName = file.getOriginalFilename();
        try {
            if (fileName.endsWith(".xls")) {
                wb = new HSSFWorkbook(file.getInputStream());
            } else if (fileName.endsWith(".xlsx")) {
                wb = new XSSFWorkbook(file.getInputStream());
            }
        } catch (IOException e) {
            logger.error("create workbook failed!: " + e);
        }
        List<List<String>> result = new ArrayList<>();
        if (wb != null) {
            Sheet sheet = wb.getSheetAt(0);
            Row headRow = sheet.getRow(0);
            if (headRow != null) {
                Field[] fields;
                if (type == 1) {
                    fields = Constants.SuspectFields.class.getDeclaredFields();
                } else {
                    fields = Constants.PlaceFields.class.getDeclaredFields();
                }
                for (int i = 0; i < headRow.getLastCellNum(); i++) {  //getLastCellNum读到有内容的最后一列(cell)
                    Cell cell = headRow.getCell(i);  //赋给cell对象
                    columnMap.put(getCellValue(cell), i); //用Map把headRow头列的列名找到对应的顺序下标; getCellValue(cell)存的如"序号"
                }
                if (type == 2 || fieldsValidate(columnMap, fields)) {
                    for (int rowNum = 1; rowNum <= sheet.getLastRowNum(); rowNum++) {
                        // HSSFRow表示行
                        Row hssfRow = sheet.getRow(rowNum);
                        if (hssfRow == null) {
                            continue;
                        }
                        List<String> rowList = new ArrayList<>();
                        // 遍历改行，获取处理每个cell元素
                        for (int colIx = 0; colIx < columnMap.size(); colIx++) {
                            // HSSFCell 表示单元格
                            Cell cell = hssfRow.getCell(colIx);
                            rowList.add(getCellValue(cell));
                        }
                        result.add(rowList);
                    }
                }

            }
        }
        return result;
    }

    @Override
    public boolean save(List<List<String>> list, Map<String, Integer> columnMap, String infoId, StringBuilder sb) throws NSException {
        if (list != null && !list.isEmpty()) {
            SuspectBiz biz = new SuspectBiz();
            List<Suspect.Entity> objectList = new ArrayList<>();
            for (List<String> l : list) {
                Suspect.Entity suspect = new Suspect.Entity();
                SuspectJsonModel jsonModel = new SuspectJsonModel();
                if (columnMap.get(Constants.SuspectFields.DISTRICT) != null) {
                    jsonModel.setDistrict(l.get(columnMap.get(Constants.SuspectFields.DISTRICT)));
                }
                if (columnMap.get(Constants.SuspectFields.GENDER) != null) {
                    jsonModel.setGender(l.get(columnMap.get(Constants.SuspectFields.GENDER)));
                }
                if (columnMap.get(Constants.SuspectFields.BORN_PLACE) != null) {
                    jsonModel.setBornplace(l.get(columnMap.get(Constants.SuspectFields.BORN_PLACE)));
                }
                if (columnMap.get(Constants.SuspectFields.RESIDENCE_PLACE) != null) {
                    jsonModel.setResidenceplace(l.get(columnMap.get(Constants.SuspectFields.RESIDENCE_PLACE)));
                }
                if (columnMap.get(Constants.SuspectFields.ADDR_BOOK_NAME) != null) {
                    jsonModel.setAddrbookname(l.get(columnMap.get(Constants.SuspectFields.ADDR_BOOK_NAME)));
                }
                if (columnMap.get(Constants.SuspectFields.IMPORTANT_PERSON) != null) {
                    if(StringUtils.hasText(l.get(columnMap.get(Constants.SuspectFields.IMPORTANT_PERSON))) &&
                            !l.get(columnMap.get(Constants.SuspectFields.IMPORTANT_PERSON)).equalsIgnoreCase("0")){
                        jsonModel.setImportantperson("1");
                    }else {
                        jsonModel.setImportantperson("0");
                    }
                }
                if (columnMap.get(Constants.SuspectFields.QQ_GROUP) != null) {
                    jsonModel.setQqgroup(l.get(columnMap.get(Constants.SuspectFields.QQ_GROUP)));
                }
                if (columnMap.get(Constants.SuspectFields.WX_NAME) != null) {
                    jsonModel.setWxname(l.get(columnMap.get(Constants.SuspectFields.WX_NAME)));
                }
                if (columnMap.get(Constants.SuspectFields.NICKNAME) != null) {
                    jsonModel.setNickname(l.get(columnMap.get(Constants.SuspectFields.NICKNAME)));
                }
                if (columnMap.get(Constants.SuspectFields.GROUP) != null) {
                    jsonModel.setGroup(l.get(columnMap.get(Constants.SuspectFields.GROUP)));
                }
                if (columnMap.get(Constants.SuspectFields.GROUP_NICKNAME) != null) {
                    jsonModel.setGroupnickname(l.get(columnMap.get(Constants.SuspectFields.GROUP_NICKNAME)));
                }
                if (columnMap.get(Constants.SuspectFields.WX_GROUP_NAME) != null) {
                    jsonModel.setWxgroupname(l.get(columnMap.get(Constants.SuspectFields.WX_GROUP_NAME)));
                }
                if (columnMap.get(Constants.SuspectFields.REMARK1) != null) {
                    jsonModel.setRemark1(l.get(columnMap.get(Constants.SuspectFields.REMARK1)));
                }
                if (columnMap.get(Constants.SuspectFields.REMARK2) != null) {
                    jsonModel.setRemark2(l.get(columnMap.get(Constants.SuspectFields.REMARK2)));
                }
                if (columnMap.get(Constants.SuspectFields.REMARK3) != null) {
                    jsonModel.setRemark3(l.get(columnMap.get(Constants.SuspectFields.REMARK3)));
                }
                if (columnMap.get(Constants.SuspectFields.SEQ_NO) != null) {
                    suspect.setSeqno(l.get(columnMap.get(Constants.SuspectFields.SEQ_NO)));
                }
                if (columnMap.get(Constants.SuspectFields.USERNAME) != null) {
                    suspect.setUsername(l.get(columnMap.get(Constants.SuspectFields.USERNAME)));
                }
                if (columnMap.get(Constants.SuspectFields.PID) != null) {
                    suspect.setPid(l.get(columnMap.get(Constants.SuspectFields.PID)).trim());
                }
                if (columnMap.get(Constants.SuspectFields.MOBILE) != null) {
                    String num = l.get(columnMap.get(Constants.SuspectFields.MOBILE)).trim();
                    suspect.setMobile(num);
                }
                if (columnMap.get(Constants.SuspectFields.MAC) != null) {
                    suspect.setMac(l.get(columnMap.get(Constants.SuspectFields.MAC)).trim());
                }
                if (columnMap.get(Constants.SuspectFields.WX_GROUP_ID) != null) {
                    suspect.setWxgroupid(l.get(columnMap.get(Constants.SuspectFields.WX_GROUP_ID)));
                }
                if (columnMap.get(Constants.SuspectFields.WX) != null) {
                    suspect.setWx(l.get(columnMap.get(Constants.SuspectFields.WX)));
                }
                if (columnMap.get(Constants.SuspectFields.WX_ID) != null) {
                    suspect.setWxid(l.get(columnMap.get(Constants.SuspectFields.WX_ID)));
                }
                if (columnMap.get(Constants.SuspectFields.QQ) != null) {
                    suspect.setQq(l.get(columnMap.get(Constants.SuspectFields.QQ)));
                }
                suspect.setId(IntEncoder.encode36(IDWorker.NextID()));
                suspect.setInfoid(infoId);
                suspect.setOther(Misc.toJson(jsonModel));
                if (StringUtils.hasText(suspect.toString())) {
                    objectList.add(suspect);
                }

            }
            try {
                biz.batchInsert(objectList);
            } catch (SQLException e) {
                logger.error("batch insert failed!: " + e);
            }
        }
        return true;
    }

    //    @Override
//    public boolean batchUpdatePlace(List<List<String>> list, Map<String, Integer> columnMap) throws NSException {
//
//        if (list != null && !list.isEmpty()) {
//            PlaceBiz placeBiz = new PlaceBiz();
//            Map<String, List<String>> resultMap = new HashMap<>();
//            Place.Coll coll = new Place.Coll();
//            placeBiz.loadpolicedict(coll);
//            Map<String, String> dict = new HashMap<>();
//            coll.forEach(item -> {
//                if (item != null && item.getPolicecode() != null) {
//                    dict.put(item.getPolicename(), item.getPolicecode());
//                }
//            });
//
//            //grouy by policeName  start
//            for (Place.Entity entity : coll) {
//                if (!StringUtils.hasText(entity.getPolicename())) {
//                    continue;
//                }
//                List<String> codeList = new ArrayList<>();
//                for (List<String> l : list) {
//                    if (columnMap.containsKey(Constants.POLICENAME) && entity.getPolicename().equalsIgnoreCase(l.get(columnMap.get(Constants.POLICENAME)))) {
//                        codeList.add(l.get(columnMap.get(Constants.SERVICCODE)));
//                    }
//                }
//                resultMap.put(entity.getPolicename(), codeList);
//            }
//
//            try {
//                for (Map.Entry<String, List<String>> entry : resultMap.entrySet()) {
//                    if (entry == null || entry.getValue().isEmpty()) {
//                        continue;
//                    }
//                    Place.Entity entity = new Place.Entity();
//                    entity.setPolicename(entry.getKey());
//                    entity.setPolicecode(dict.getOrDefault(entry.getKey(), ""));
//                    Place.Query query = new Place.Query();
//                    query.setServicecodeIDList(entry.getValue());
//                    placeBiz.partUpdate(entity, query);
//                }
//            } catch (NSException ex) {
//                logger.error("batch update po_place failed!: " + ex);
//            }
//
//        }
//        return true;
//    }
    @Override
    public boolean batchUpdatePlace(List<List<String>> list, Map<String, Integer> columnMap) throws NSException {

        if (list != null && !list.isEmpty()) {
            PlaceBiz placeBiz = new PlaceBiz();
            Place.Coll coll = new Place.Coll();
            placeBiz.loadpolicedict(coll);
            Map<String, String> dict = new HashMap<>();
            coll.forEach(item -> {
                if (item != null && item.getPolicecode() != null) {
                    dict.put(item.getPolicename(), item.getPolicecode());
                }
            });
            for (List<String> l : list) {
                Place.Entity place = new Place.Entity();
                if (columnMap.get(Constants.PlaceFields.POLICENAME) != null) {
                    place.setPolicename(l.get(columnMap.get(Constants.PlaceFields.POLICENAME)));
                    place.setPolicecode(dict.getOrDefault(l.get(columnMap.get(Constants.PlaceFields.POLICENAME)), ""));
                }
                if (columnMap.get(Constants.PlaceFields.ORGNAME) != null) {
                    place.setOrgname(l.get(columnMap.get(Constants.PlaceFields.ORGNAME)));
                }
                if (columnMap.get(Constants.PlaceFields.PROPERTY) != null) {
                    place.setProperty(l.get(columnMap.get(Constants.PlaceFields.PROPERTY)));
                }
                if (columnMap.get(Constants.PlaceFields.SERVICCODE) != null) {
                    place.setServicecode(l.get(columnMap.get(Constants.PlaceFields.SERVICCODE)));
                }
                placeBiz.partUpdate(place);
            }

        }
        return true;
    }

    public String getCellValue(Cell cell) {

        if (cell == null) return "";

        if (cell.getCellType() == Cell.CELL_TYPE_STRING) {

            return cell.getStringCellValue();

        } else if (cell.getCellType() == Cell.CELL_TYPE_BOOLEAN) {

            return String.valueOf(cell.getBooleanCellValue());

        } else if (cell.getCellType() == Cell.CELL_TYPE_FORMULA) {

            return cell.getCellFormula();

        } else if (cell.getCellType() == Cell.CELL_TYPE_NUMERIC) {
            DecimalFormat df = new DecimalFormat("0");
            return df.format(cell.getNumericCellValue());
        }
        return "";
    }

    public boolean fieldsValidate(Map<String, Integer> columnMap, Field[] fieldArray) {
        List<String> fields = new ArrayList<>();
        for (Field field : fieldArray) {
            try {
                fields.add(field.get(field.getName()).toString());
            } catch (IllegalAccessException e) {
                logger.error("parse Constants.Fields failed!: " + e);
            }
        }

        for (Map.Entry<String, Integer> entry : columnMap.entrySet()) {
            if (entry.getKey() != null && !fields.contains(entry.getKey())) {
                logger.error(entry.getKey() + " not match with Constants.Fields! ");
                return false;
            }
        }
        return true;
    }


}
