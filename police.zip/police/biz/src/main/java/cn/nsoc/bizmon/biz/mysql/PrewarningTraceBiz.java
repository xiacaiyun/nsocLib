package cn.nsoc.bizmon.biz.mysql;

import cn.nsoc.base.entity.sys.NSException;
import cn.nsoc.bizmon.entity.mysql.PrewarningTrace;
import cn.nsoc.bizmon.util.RSHelper;
import cn.nsoc.common.storer.db.DbSelectBuilder;
import cn.nsoc.common.storer.db.JdbcDbStorer;
import org.apache.log4j.Logger;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

public class PrewarningTraceBiz {
	private static final Logger logger = Logger.getLogger(PrewarningTraceBiz.class);
	
	JdbcDbStorer dbStorer;

	public PrewarningTraceBiz() {
		dbStorer = JdbcDbStorer.getInstance();
	}

	public PrewarningTraceBiz(JdbcDbStorer storer) {
		dbStorer = storer;
	}

	public PrewarningTrace.Coll load(PrewarningTrace.Coll me) throws NSException {
		return (PrewarningTrace.Coll) dbStorer.load(me);
	}

	public boolean insert(PrewarningTrace.Entity me) throws NSException {
		return dbStorer.insert(me);
	}

	public boolean delete(PrewarningTrace.Entity me) throws NSException {
		return dbStorer.delete(me);
	}

	public boolean update(PrewarningTrace.Entity me) throws NSException {
		return dbStorer.update(me);
	}

	public PrewarningTrace.Entity get(int montype, String monkey) throws NSException {
		PrewarningTrace.Query query = new PrewarningTrace.Query();
		query.setMontype(montype);
		query.setMonkey(monkey);
		PrewarningTrace.Coll results = load(new PrewarningTrace.Coll(query));
		return results.isEmpty() ? null : results.get(0);
	}

	public int findTotal() throws NSException {
		PrewarningTrace.Query query = new PrewarningTrace.Query();
		DbSelectBuilder fields = new DbSelectBuilder(dbStorer, null);
		fields.addField("total", "count(1)");
		query.selectFields = fields;
		query.skipTotalCount = true;
		PrewarningTrace.Coll me = new PrewarningTrace.Coll(query);
		this.load(me);
		if (!me.isEmpty())
			return me.get(0).getTotal();
		return 0;
	}

	public List<Map<String, Object>> radarSearch(long start, List<String> monids) throws SQLException {
		Connection conn = dbStorer.getConn();
		Statement stmt = null;
		ResultSet res = null;
		List<Map<String, Object>> rows = new ArrayList<>();
		StringBuilder sql = new StringBuilder();
		sql.append("SELECT w.evtime, w.monid, p.lng, p.lat, p.servicename,  p.address, s.username as `name`, s.pid, s.mobile "
				+ "FROM po_prewarning_trace as w JOIN po_place p on w.servicecode=p.servicecode "
				+ " LEFT OUTER JOIN po_suspect s ON w.suspectid=s.id ");
		sql.append(String.format(" where w.evtime >= %s", start));
		if(monids.size() > 0) {
			sql.append(String.format(" and w.monid in ('%s')", monids.stream().collect(Collectors.joining("','"))));
		}
		
		try {
			stmt = conn.createStatement();
			logger.debug(String.format("radar sql is: %s", sql));
			res = stmt.executeQuery(sql.toString());
			while (res.next()) {
				rows.add(RSHelper.toDict(res));
			}
			return rows;
		} finally {
			if (res != null) {
				try {
					res.close();
				} catch (Exception e) {
					logger.error("close ResultSet error", e);
				}
			}
			if (stmt != null) {
				try {
					stmt.close();
				} catch (Exception e) {
					logger.error("close stmt error", e);
				}
			}
			if (conn != null) {
				try {
					conn.close();
				} catch (Exception e) {
					logger.error("close connection error", e);
				}
			}
			
		}

	}
}
