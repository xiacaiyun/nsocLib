package cn.nsoc.bizmon.biz.mysql;

import cn.nsoc.base.entity.sys.NSException;
import cn.nsoc.bizmon.entity.mysql.MonitorRule;
import cn.nsoc.bizmon.entity.mysql.Prewarning;
import cn.nsoc.common.storer.db.JdbcDbStorer;

public class MonitorRuleBiz {
	JdbcDbStorer dbStorer;

	public MonitorRuleBiz(){
		dbStorer = JdbcDbStorer.getInstance();
	}

	public MonitorRuleBiz(JdbcDbStorer storer){
		dbStorer = storer;
	}

	public MonitorRule.Coll load(MonitorRule.Coll me) throws NSException {
		return (MonitorRule.Coll)dbStorer.load(me);
	}


	public boolean insert(MonitorRule.Entity me) throws NSException {
		return dbStorer.insert(me);
	}

	public boolean delete(MonitorRule.Entity me) throws NSException {
		return dbStorer.delete(me);
	}
	
	public boolean delete(Prewarning.Query me) throws NSException {
		return dbStorer.delete(me, MonitorRule.Entity.class);
	}
	
	public boolean update(MonitorRule.Entity me) throws NSException {
		return dbStorer.update(me);
	}

	public MonitorRule.Entity get(int id) throws NSException {
		MonitorRule.Query query = new MonitorRule.Query();
		query.setId(id);
		MonitorRule.Coll results = load(new MonitorRule.Coll(query));
		return results.isEmpty() ? null:results.get(0);
	}


}

