package cn.nsoc.scm.jetty

import java.io.FileInputStream
import javax.servlet.http.{HttpServletRequest, HttpServletResponse}

import cn.nsoc.scm.model.CalculateModel
import cn.nsoc.scm.tools.Transformation
import org.apache.hadoop.conf.Configuration
import org.apache.hadoop.hbase.HBaseConfiguration
import org.apache.spark.{SparkConf, SparkContext}
import org.mortbay.jetty.{HttpStatus, Request, Server}
import org.mortbay.jetty.handler._
import cn.nsoc.scm.define.{Msg, SCMConf, SCMDefine}
import cn.nsoc.scm.tools.Transformation.RequestInfo
import org.apache.log4j.Logger

object JettyServer extends AbstractHandler{
  private val logger = Logger.getLogger("SCM_JettyServer")
  private val sparkConf: SparkConf = new SparkConf().setAppName(SCMConf.getAppName)
    .set("es.nodes", SCMConf.getEsNodes).set("es.port", SCMConf.getEsPort)
  private val sc = new SparkContext(sparkConf)
  private val hbase: Configuration = HBaseConfiguration.create()

  /**
    * 处理请求 返回响应
    * @param target 目标
    * @param request 请求
    * @param response 响应
    * @param dispatch 调度
    */
  override def handle(target: String,
                      request: HttpServletRequest,
                      response: HttpServletResponse,
                      dispatch: Int): Unit = {
    hbase.addResource(new FileInputStream("hbase-site.xml"))
    val url = request.getRequestURI
    logger.info(s"Url ---------> $url")
    logger.info(s"Hbase zk ----> ${hbase.get(SCMConf.HBASE_ZOOKEEPER_QUORUM)}")
    logger.info(s"Sources -----> ${SCMConf.getJettyReqName}")
    logger.info(s"App name ----> ${SCMConf.getAppName}")
    url match {
      case SCMConf.getJettyReqName =>
        //request中的target 用,号分割
        val json: String = request.getParameter(SCMDefine.REQUEST_JSON_NAME)
        logger.info(s"""Request json: $json""")
        val op: String = request.getParameter(SCMDefine.OP_OPNAME)
        logger.info(s"""Request operation: $op""")

        val responseInfo: RequestInfo = Transformation.json2Obj(json)
        val min = responseInfo.min
        val max = responseInfo.max
        val cookie = responseInfo.cookie
        val ctype = responseInfo.`type`
        val param = responseInfo.SEPs
        try {
          val model = new CalculateModel
          if(SCMDefine.OP_FORECASTING.equals(op)) {
            val resultArray = model.forecasting(param, ctype, max.toInt, sc)
            val result = Transformation.array2Json(resultArray, Msg.RESPONSE_SUCCESS_CODE,
              Msg.RESPONSE_SUCCESS_MSG, cookie.toString, ctype, op)
            response.setStatus(HttpStatus.ORDINAL_200_OK)
            response.getWriter.println(result)
            logger.info(s"""Calculate Result: $result""")
          } else {
            val resultRDD = model.calculate(op, min.toInt, max.toInt, param, sc, hbase)
            val result = Transformation.rdd2JsonStr(resultRDD, Msg.RESPONSE_SUCCESS_CODE,
              Msg.RESPONSE_SUCCESS_MSG, cookie.toString, ctype, op)
            response.setStatus(HttpStatus.ORDINAL_200_OK)
            response.getWriter.println(result)
            logger.info(s"""Calculate Result: $result""")
          }

          request.asInstanceOf[Request].setHandled(true)
          response.getWriter.close()
        } catch {
          case e: Exception =>
            logger.error(">>>>>>>>>>>>>>>>>>>>ERROR>>>>>>>>>>>>>>>>>>>>")
            logger.error(e)
            logger.error(">>>>>>>>>>>>>>>>>>>>ERROR>>>>>>>>>>>>>>>>>>>>")
            response.setStatus(HttpStatus.ORDINAL_200_OK)
            response.getWriter.print(Transformation.errorMsg(Msg.RESPONSE_FAIL_CODE, e.getMessage, cookie.toString, ctype))
            request.asInstanceOf[Request].setHandled(true)
            response.getWriter.close()
        }

      case _ =>
        logger.error(s"UKnow request source: $url")
        response.setStatus(HttpStatus.ORDINAL_404_Not_Found)
        response.getWriter.print(s"""Request sources is not fount. Sources: $url""")
        request.asInstanceOf[Request].setHandled(true)
        response.getWriter.close()
    }
  }

  def main(args: Array[String]): Unit = {
    logger.info(s"""Jetty server start ...""")
    val server = new Server(SCMConf.getJettyPort)
    server.setHandler(this)
    server.start()
  }

}
