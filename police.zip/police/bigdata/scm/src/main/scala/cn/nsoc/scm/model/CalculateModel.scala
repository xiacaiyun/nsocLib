package cn.nsoc.scm.model

import java.util

import cn.nsoc.scm.define.{SCMConf, SCMDefine}
import cn.nsoc.scm.tools.Transformation
import org.apache.hadoop.conf.Configuration
import org.apache.hadoop.hbase.util.Base64
import org.apache.hadoop.hbase.client.{Result, Scan}
import org.apache.hadoop.hbase.io.ImmutableBytesWritable
import org.apache.hadoop.hbase.mapreduce.TableInputFormat
import org.apache.hadoop.hbase.protobuf.ProtobufUtil
import org.apache.log4j.Logger
import org.apache.spark.rdd.RDD
import org.apache.spark.SparkContext
import org.apache.spark.mllib.linalg.DenseVector

/**
  * 计算模型
  */
class CalculateModel {
  private val logger = Logger.getLogger("SCM_CalculateModel")

  /**
    * 计算主体，选择何种方式计算
    * @param op 计算方法
    * @param calculateInfo 参数
    * @param sc SparkContext
    * @param hbase Configuration
    * @return 计算结果json字符串    println(s"Calculate start ... "
    */
  def calculate(op: String,
                min: Int,
                max: Int,
                calculateInfo: util.ArrayList[(String, String, String)],
                sc: SparkContext, hbase: Configuration): RDD[(String, (Int, String, String))] = {

    if(max <= 0 || min <= 0 || min > max) {
      logger.error(s"Parameter error. max: $max min: $min")
      throw new IllegalArgumentException(s"max <= 0 or min <= 0 or min > max. max: $max min: $min")
    }

    logger.info(s"Calculate start ... ")
    op match {
      case  SCMDefine.OP_COLLISION =>
        collisionFromHbase(min, max, SCMConf.getCollisionPlaceRange, SCMConf.getCollisionTimeRange,
          SCMConf.getCollisionMacRange, calculateInfo, sc, hbase)

      case SCMDefine.OP_ACCOMPANY =>
        val snm = Transformation.list2Tuple(calculateInfo)
        logger.debug(s"AccompanyQueryAccuracy -> ${SCMConf.getAccompanyQueryAccuracy}")
        accompany(min, max, snm._1, snm._2, snm._3, SCMConf.getAccompanyQueryAccuracy,
          SCMConf.getAccompanyMaxPlace, sc, hbase)

      case SCMDefine.OP_FLOATING_POPULATION =>
        val snp = Transformation.list2Tuple(calculateInfo)
        floatingPopulation(min, max, snp._1, snp._2, snp._3, sc)

      case SCMDefine.OP_RESIDENT_POPULATION =>
        val snp = Transformation.list2Tuple(calculateInfo)
        residentPopulation(min, max, snp._1, snp._2, snp._3, SCMConf.getResidentPopulationAccuracy, sc)

      case _ => throw new Exception("Unknown request op.")
    }
  }

  //聚合函数
  val add: ((Int, String, String), (Int, String, String)) => (Int, String, String) =
    (a: (Int, String, String), b: (Int, String, String)) => (a._1 + b._1, a._2 + ":" + b._2, a._3 + ":" + b._3)

  /**
    * Read HBase data join and reduceByKey
    * @param min Min collision location count
    * @param max Max collision location count
    * @param timeRange Time rang
    * @param localRange Location rang
    * @param macRange Mac rang
    * @param startEndLocals (StartTime, EndTime, Location)
    * @param sc SparkContext
    * @param hbase Configuration
    * @return RDD[String]
    */
  private def collisionFromHbase(min: Int,
                                 max: Int,
                                 localRange: (Int, Int),
                                 timeRange: (Int, Int),
                                 macRange: (Int, Int),
                                 startEndLocals: util.ArrayList[(String, String, String)],
                                 sc: SparkContext,
                                 hbase: Configuration): RDD[(String, (Int, String, String))] = {

    if(localRange == null || timeRange == null || macRange == null || startEndLocals.isEmpty || sc == null || hbase == null) {
      logger.error(s"Parameter is null.")
      throw new NullPointerException
    }


    logger.info("Start collision ...")
    //rdd集合
    val rdds = new util.ArrayList[RDD[(String,(Int, String, String))]]()
    //去重函数
    val dis = (countLocalTime: (Int, String, String), _: (Int, String, String)) => countLocalTime

    val f = "f".getBytes()
    val time = "ti".getBytes()
    val serviceCode = "sc".getBytes()
    val mac = "mac".getBytes()

    val one = 1

    hbase.set(TableInputFormat.INPUT_TABLE, SCMConf.getCollisionInputTable)
    //遍历条件，根据条件，开始读取HBase数据
    for(tupleIndex <- 0 until startEndLocals.size()) {
      if(!"".equals(startEndLocals.get(tupleIndex)._3)) {
        val sel = startEndLocals.get(tupleIndex)

        val startRow = sel._3.reverse + sel._1.substring(2, sel._1.length)
        logger.info(s"Read hbase row of start row: ${new String(startRow)}")
        val endRow = sel._3.reverse + sel._2.substring(2, sel._2.length)
        logger.info(s"Read hbase row of end row: ${new String(endRow)}")

        hbase.set(TableInputFormat.SCAN, getScanInString(startRow, endRow))

        //把HBase数据读取到到RDD
        val rdd = sc.newAPIHadoopRDD(hbase, classOf[TableInputFormat], classOf[ImmutableBytesWritable], classOf[Result])
        val r = rdd.map {
          kv =>
            //            new String(kv._2.getRow) //获取RowKey 982000d3101710121515070024D7A16C00
            val v = kv._2
            (v.getValue(f, mac).toString, (1, v.getValue(f, serviceCode).toString, v.getValue(f, time).toString))
        }.reduceByKey(dis, 300)
//            .map {
//          line =>
//            if (sel._3.length == 9) {
//              val time = line.substring(timeRange._1 - one, timeRange._2 - one)
//              val location = line.substring(localRange._1, localRange._2 - one)
//              val mac = line.substring(macRange._1 - one, macRange._2 - one)
//
//              (mac, (1, location, time))
//            } else {
//              val time = line.substring(timeRange._1, timeRange._2)
//              val location = line.substring(localRange._1, localRange._2)
//              val mac = line.substring(macRange._1, macRange._2)
//
//              (mac, (1, location, time))
//            }
//        }.reduceByKey(dis, 300) //去除单个区间内的重复采集数据

        rdds.add(r) //将rdd加入到rdds集合
      }
    }

    if(rdds.size() == 0) return null
    //链接运算
    var rdd = rdds.get(0)
    for(i <- 1 until rdds.size()) {
      rdd = rdd.union(rdds.get(i))
    }

    //聚合，计算完成
    val r1 = rdd.reduceByKey(add).filter{
      f =>
        f._2._1 >= min && f._2._1 <= max
    }
    r1
  }

  private def getScanInString(startRow: String, endRow: String): String = {
    val scan = new Scan()
    //起始行
    scan.setStartRow(startRow.getBytes())
    //结束行
    scan.setStopRow(endRow.getBytes())
    //最大返回版本数(设置为1，只需要一条即可)
    scan.setMaxVersions(1)
    scan.setCacheBlocks(false)
    val proto = ProtobufUtil.toScan(scan)

    Base64.encodeBytes(proto.toByteArray)
  }

  /**
    * Accompany calculate
    * @param min Min collision location count
    * @param max Max collision location count
    * @param startTime Start time
    * @param endTime End time
    * @param macs Macs
    * @param accuracy Accuracy use query es dis
    * @param maxPlace Max collision place
    * @param sc SparkContext
    * @param hbase HbaseConfig
    * @return RDD[(String, (Int, String, String))]
    */
  private def accompany(min: Int,
                        max: Int,
                        startTime: Long,
                        endTime: Long,
                        macs: Array[String],
                        accuracy: Int,
                        maxPlace: Int,
                        sc: SparkContext,
                        hbase: Configuration): RDD[(String, (Int, String, String))] = {

    if(macs.isEmpty) throw new NullPointerException("Macs is empty")

    logger.info("Start accompany ...")

    val serviceCodeName = SCMConf.getAccompanyFieldServiceCode
    val timeChange = SCMConf.getTimeChange
    val one_s = Transformation.ONE_THOUSAND_MILLISECONDS
    val timeFormat = SCMConf.ACCOMPANY_TIME_FORMAT

    val ad: ((String, String, String), (String, String, String)) => (String, String, String) =
      (a: (String, String, String), b: (String, String, String)) =>
        (a._1 + ":" + b._1, s"${a._2}:${b._2}", s"${a._3}:${b._3}")

    val dis = (a: (String, String, String), b: (String, String, String)) => {
      val a_begin = a._2.toLong
      val a_end = a._3.toLong
      val b_begin = b._2.toLong
      val b_end = b._3.toLong
      var r_begin = 0L
      var r_end = 0L
      if(a_begin > b_begin) {
        r_begin = b_begin
      } else {
        r_begin = a_begin
      }

      if(a_end < b_end) {
        r_end = b_end
      } else {
        r_end = a_end
      }

      (a._1, r_begin + "", r_end + "")
    }

    hbase.set(TableInputFormat.INPUT_TABLE, SCMConf.getAccompanyInputTable)
    val startRow = s"${macs(0)}$startTime"
    logger.info(s"Read hbase row of start row: $startRow")
    val endRow = s"${macs(0)}$endTime"
    logger.info(s"Read hbase row of end row: $endRow")

    hbase.set(TableInputFormat.SCAN, getScanInString(startRow, endRow))

    //把HBase数据读取到到RDD
    val rdd = sc.newAPIHadoopRDD(hbase, classOf[TableInputFormat], classOf[ImmutableBytesWritable], classOf[Result])
      .map{
        kv =>
          val result = kv._2
          val rowKey = result.getRow.toString
          val timeStamp = rowKey.substring(12, 22).toLong
          val serviceCode = result.getValue("f".getBytes(), serviceCodeName.getBytes())
          val mac = rowKey.substring(0, 12)
          val begin = (timeStamp * one_s - timeChange) + ""
          val end = (timeStamp * one_s + timeChange) + ""
          (s"${timeStamp/accuracy}$serviceCode$mac", (serviceCode.toString, begin, end))
      }
      .reduceByKey(dis)
      .map{
        kMst =>
          val mst = kMst._2
          val serviceCode = mst._1
          val begin = mst._2
          val end = mst._3
          ("k", (serviceCode, begin, end))
      }
      .reduceByKey(ad)

    val rddCount = rdd.count()
    val rddList = rdd.take(rddCount.toInt)

    val startEndLocal = new util.ArrayList[(String, String, String)]()
    rddList.foreach{
      kv =>
        val pt = kv._2
        val places = pt._1.split(":")
        val begins = pt._2.split(":")
        val ends = pt._3.split(":")
        var maxIndex = places.length
        if(maxIndex > maxPlace) {
          maxIndex = maxPlace
        }
        for(index <- 0 until maxIndex) {
          val begin = begins(index).toLong
          val end = ends(index).toLong
          val place = places(index)
          startEndLocal.add((Transformation.getTime(begin, timeFormat),
            Transformation.getTime(end, timeFormat),
            place.substring(4, place.length)))
        }
    }

    collisionFromHbase(min, max, SCMConf.getCollisionPlaceRange, SCMConf.getCollisionTimeRange, SCMConf.getCollisionMacRange, startEndLocal, sc, hbase)
  }

  /**
    * Floating population count
    * @param min Min place
    * @param max Max place
    * @param startTime Start time
    * @param endTime End time
    * @param places Places
    * @param sc SparkContext
    * @return RDD[(String, (Int, String, String))]
    */
  private def floatingPopulation(
                                  min: Int,
                                  max: Int,
                                  startTime: Long,
                                  endTime: Long,
                                  places: Array[String],
                                  sc: SparkContext): RDD[(String, (Int, String, String))] = {
    import org.elasticsearch.spark._
    logger.info("Start floating population ...")

    val timeName = SCMConf.getEsFieldTime
    val serviceCodeName = SCMConf.getFieldServiceCode
    val macName = SCMConf.getEsFieldMac

    val dis = (macPlaceTime: (String, String, String), _: (String, String, String)) => macPlaceTime
    val rdd = sc.esRDD(s"${SCMConf.getEsIndex}/${SCMConf.getEsType}", Transformation.esQuery(startTime, endTime, places))
      .map{
      kv =>
        val dataMap = kv._2
        val timeStamp = dataMap.get(timeName)
        val serviceCode = dataMap.get(serviceCodeName)
        val mac = dataMap.get(macName)
        (s"${serviceCode.getOrElse("NULL").toString}${mac.getOrElse("NULL").toString}",
          (mac.getOrElse("NULL").toString, serviceCode.getOrElse("NULL").toString, timeStamp.getOrElse("0").toString))
    }
      .reduceByKey(dis, 300)
      .map{
        kMst =>
          val mst = kMst._2
          val mac = mst._1
          val serviceCode = mst._2
          val timeStamp = mst._3
          (mac, (1, serviceCode, timeStamp))
      }
      .reduceByKey(add, 300)
      .filter{
        v =>
          v._2._1 <= max && v._2._1 >= min
      }

    rdd
  }

  /**
    * Resident population count
    * @param min Min mac
    * @param max Max mac
    * @param startTime Start time
    * @param endTime End time
    * @param places Places
    * @param accuracy Accuracy use query es dis
    * @param sc SparkContext
    * @return
    */
  private def residentPopulation(
                                  min: Int,
                                  max: Int,
                                  startTime: Long,
                                  endTime: Long,
                                  places: Array[String],
                                  accuracy: Int,
                                  sc: SparkContext): RDD[(String, (Int, String, String))] = {
    import org.elasticsearch.spark._
    logger.info("Start resident population ...")

    val timeName = SCMConf.getEsFieldTime
    val serviceCodeName = SCMConf.getFieldServiceCode
    val macName = SCMConf.getEsFieldMac

    val dis = (a: (String, String, String), _: (String, String, String)) => a
    val rdd = sc.esRDD(s"${SCMConf.getEsIndex}/${SCMConf.getEsType}", Transformation.esQuery(startTime, endTime, places))
      .map{
      kv =>
        val dataMap = kv._2
        val timeStamp = dataMap.get(timeName)
        val serviceCode = dataMap.get(serviceCodeName)
        val mac = dataMap.get(macName)
        (s"${timeStamp.getOrElse(0L).toString.toLong/accuracy}${serviceCode.getOrElse("NULL").toString}${mac.getOrElse("NULL").toString}",
          (mac.getOrElse("NULL").toString, serviceCode.getOrElse("NULL").toString, timeStamp.getOrElse("0").toString))
    }
      .reduceByKey(dis, 200)
      .map{
        kMst =>
          val mst = kMst._2
          val mac = mst._1
          val serviceCode = mst._2
          val timeStamp = mst._3
          (serviceCode, (1, mac, timeStamp))
      }
      .reduceByKey(add, 200)
      .filter{
        v =>
          v._2._1 <= max && v._2._1 >= min
      }

    rdd
  }


  /**
    * Forecasting
    * @param calculateInfo Start time,end time,places list
    * @param serviceType WangBa,wifi,total...
    * @param period Default 12
    * @param sc SparkContext
    * @return Timestamps and forecasting values
    */
  def forecasting(calculateInfo: util.ArrayList[(String, String, String)],
                 serviceType: String,
                 period: Int,
                 sc: SparkContext
                 ): Array[(Long, Double)] = {
    import org.elasticsearch.spark._
    val timeName = SCMConf.getEsFieldTimeForecasting
    val timeHz = SCMDefine.TIME_HZ
    val serviceCodeName = SCMConf.getEsFieldServiceCodeForecasting
    val modelType = SCMConf.getForecastingModelType

    val dis = (a: (String, String, String), _: (String, String, String)) => a
    val sep = Transformation.list2Tuple(calculateInfo)
    val startTime = sep._1
    val endTime = sep._2
    val places = sep._3

    val rdd = sc.esRDD(s"${SCMConf.getEsIndexForecasting}/${SCMConf.getEsTypeForecasting}",
      Transformation.forEsQuery(startTime, endTime, places))
      .map{
        kv =>
          val dataMap = kv._2
          val timeStamp = dataMap.get(timeName)
          val serviceCode = dataMap.get(serviceCodeName)
          val count = dataMap.get(serviceType)
          (s"${timeStamp.getOrElse(0L).toString.toLong}${serviceCode.getOrElse("NULL").toString}",
            (count.getOrElse("0").toString, serviceCode.getOrElse("NULL").toString, timeStamp.getOrElse("0").toString))
      }
      .reduceByKey(dis)
      .map{
        kv =>
          val cst = kv._2
          val count = cst._1
          val time = cst._3
          (time.toLong, count.toDouble)
      }
      .reduceByKey(_ + _)
      .sortByKey()

    val rddCount = rdd.count()
    if(rddCount < 3 * period) {
      throw new Exception(s"Source data to short. Source data length: $rddCount")
    }
    val rddList = rdd.take(rddCount.toInt)
    var train = Array[Double]()
    var sourceData = Array[(Long, Double)]()
    var lastTime = 0L
    rddList.foreach{
      tc =>
        val count = tc._2
        lastTime = tc._1
        train = train ++ Array(count)
        sourceData = sourceData ++ Array[(Long, Double)]((lastTime, count))
    }

    val model = HoltWinters.fitModel(new DenseVector(train), period, modelType, "BOBYQA")
    val forecasted = model.forecast(new DenseVector(train), new DenseVector(new Array[Double](period)))
    val tf = new Array[(Long, Double)](forecasted.size)
    for(index <- 0 until forecasted.size) {
      lastTime = lastTime + timeHz
      tf(index) = (lastTime, forecasted(index))
    }

    sourceData ++ tf
  }


}
