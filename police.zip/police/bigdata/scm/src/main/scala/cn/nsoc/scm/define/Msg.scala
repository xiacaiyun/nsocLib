package cn.nsoc.scm.define

object Msg {
  val RESPONSE_SUCCESS_CODE: String = "0"
  val RESPONSE_FAIL_CODE: String = "1"
  val RESPONSE_ERROR_CODE: String = "2"

  val RESPONSE_SUCCESS_MSG: String = "pass"
}
