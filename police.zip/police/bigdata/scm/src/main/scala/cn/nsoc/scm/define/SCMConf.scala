package cn.nsoc.scm.define

import java.io.FileInputStream
import java.util.Properties

import scala.language.implicitConversions


object SCMConf {
  private val properties = new Properties()
  properties.load(new FileInputStream("scm_conf.properties"))

  implicit def toRange(str: String): (Int, Int) = {
    val splitStr = str.split(",")
    if(splitStr.length == 2){
      val v1 = splitStr(0).toInt
      val v2 = splitStr(1).toInt
      (v1, v2)
    } else {
      null
    }
  }


  //配置名称
  val APP_NAME = "app.name"
  //hbase
  val HBASE_ZOOKEEPER_QUORUM = "hbase.zookeeper.quorum"
  val HBASE_ZOOKEEPER_PROPERTY_CLIENTPORT = "hbase.zookeeper.property.clientPort"
  val ZOOKEEPER_ZNODE_PARENT = "zookeeper.znode.parent"
  //jetty
  val JETTY_SERVER_PORT = "jetty.server.port"
  val JETTY_REQUEST_NAME = "jetty.request.name"
  //collision
  val COLLISION_INPUT_TABLE = "collision.input.table"
  val COLLISION_PARSER_TIME_RANGE = "collision.parser.timeRange"
  val COLLISION_PARSER_LOCAL_RANGE = "collision.parser.localRange"
  val COLLISION_PARSER_MAC_RANGE = "collision.parser.macRange"
  val COLLISION_PARSER_TIME_FORMAT = "collision.parser.timeFormat"
  //accompany
  val ACCOMPANY_INPUT_TABLE = "accompany.input.table"
  val ACCOMPANY_TABLE_FIELD_SERVICE_CODE = "accompany.table.field.servicecode"
  val ACCOMPANY_TIME_CHANGE = "accompany.timeChange"
  val ACCOMPANY_QUERY_ACCURACY = "accompany.query.accuracy"
  val ACCOMPANY_MAX_PLACE = "accompany.max.place"
  val ACCOMPANY_TIME_FORMAT = "accompany.time.format"

  val RESIDENT_POPULATION_ACCURACY = "resident.population.accuracy"

  //elasticsearch
  val ES_INPUT_INDEX = "calculate.es.input.index"
  val ES_INPUT_TYPE = "calculate.es.input.type"
  val ES_FIELD_TIME = "calculate.es.field.time"
  val ES_FIELD_SERVICE_CODE = "calculate.es.field.servicecode"
  val ES_FIELD_MAC = "calculate.es.field.mac"
  val ES_INPUT_INDEX_FORECASTING = "forecasting.es.input.index"
  val ES_INPUT_TYPE_FORECASTING = "forecasting.es.input.type"
  val ES_INPUT_TIME_FORECASTING = "forecasting.es.input.time"
  val ES_INPUT_SERVICE_CODE_FORECASTING = "forecasting.es.input.servicecode"

  val FORECASTING_MODEL_PERIOD = "forecasting.model.period"
  val FORECASTING_MODEL_TYPE = "forecasting.model.type"

  val ES_NODES = "es.nodes"
  val ES_PORT = "es.port"



  //获取配置值
  val getAppName: String = properties.getProperty(APP_NAME, "spark_calculate_model")
  //jetty配置
  val getJettyPort: Int = properties.getProperty(JETTY_SERVER_PORT, "23333").toInt
  val getJettyReqName: String = properties.getProperty(JETTY_REQUEST_NAME, "/calculate")

  //collision
  val getCollisionInputTable: String = properties.getProperty(COLLISION_INPUT_TABLE, "")
  val getCollisionPlaceRange: (Int, Int) = properties.getProperty(COLLISION_PARSER_LOCAL_RANGE, "0, 10")
  val getCollisionTimeRange: (Int, Int) = properties.getProperty(COLLISION_PARSER_TIME_RANGE, "10, 22")
  val getCollisionMacRange: (Int, Int) = properties.getProperty(COLLISION_PARSER_MAC_RANGE, "22, 34")
  val getCollisionTimeFormat: String = properties.getProperty(COLLISION_PARSER_TIME_FORMAT, "yyMMddhhmmss")

  //accompany
  val getAccompanyInputTable: String = properties.getProperty(ACCOMPANY_INPUT_TABLE, "")
  val getAccompanyQueryAccuracy: Int = properties.getProperty(ACCOMPANY_QUERY_ACCURACY, "100").toInt
  val getAccompanyMaxPlace: Int = properties.getProperty(ACCOMPANY_MAX_PLACE, "100").toInt
  val getAccompanyTimeFormat: String = properties.getProperty(ACCOMPANY_TIME_FORMAT, "yyyyMMddHHmmss")
  val getAccompanyFieldServiceCode: String = properties.getProperty(ACCOMPANY_TABLE_FIELD_SERVICE_CODE, "")

  val getTimeChange: Long = properties.getProperty(ACCOMPANY_TIME_CHANGE, "30000").toLong

  val getEsIndex: String = properties.getProperty(ES_INPUT_INDEX, "")
  val getEsType: String = properties.getProperty(ES_INPUT_TYPE, "")
  val getEsFieldTime: String = properties.getProperty(ES_FIELD_TIME, "")
  val getFieldServiceCode: String = properties.getProperty(ES_FIELD_SERVICE_CODE, "")
  val getEsFieldMac: String = properties.getProperty(ES_FIELD_MAC, "")

  val getEsIndexForecasting: String = properties.getProperty(ES_INPUT_INDEX_FORECASTING, "")
  val getEsTypeForecasting: String = properties.getProperty(ES_INPUT_TYPE_FORECASTING, "")
  val getEsFieldTimeForecasting: String = properties.getProperty(ES_INPUT_TIME_FORECASTING, "")
  val getEsFieldServiceCodeForecasting: String = properties.getProperty(ES_INPUT_SERVICE_CODE_FORECASTING, "")

  val getEsNodes: String = properties.getProperty(ES_NODES, "")
  val getEsPort: String = properties.getProperty(ES_PORT, "")

  val getForecastingModelPeriod: Int = properties.getProperty(FORECASTING_MODEL_PERIOD, "12").toInt
  val getForecastingModelType: String = properties.getProperty(FORECASTING_MODEL_TYPE, "multiplicative")

  val getResidentPopulationAccuracy: Int = properties.getProperty(RESIDENT_POPULATION_ACCURACY, "1000").toInt

}
