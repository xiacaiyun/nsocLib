package cn.nsoc.scm.define

object SCMDefine {
  val OP_COLLISION = "collision"
  val OP_RESIDENT_POPULATION = "residentPopulation"
  val OP_FLOATING_POPULATION = "floatingPopulation"
  val OP_ACCOMPANY = "accompany"
  val OP_FORECASTING = "forecasting"
  val OP_OPNAME = "op"

  val REQUEST_JSON_NAME = "requestJson"

  val TIME_HZ = 300
  val FORECASTING_RETURN_TIMESTAMP = "time"
  val FORECASTING_RETURN_COUNT = "count"
}
