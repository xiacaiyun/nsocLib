package cn.nsoc.scm.tools

import java.text.SimpleDateFormat
import java.util
import java.util.Date

import cn.nsoc.scm.define.{SCMConf, SCMDefine}
import org.apache.log4j.Logger
import org.apache.spark.rdd.RDD
import org.json4s.DefaultFormats
import org.json4s.jackson.JsonMethods.parse


/**
  * 转换
  * Create by Alan 2017.10.21
  */
object Transformation {
  private val LOGGER = Logger.getLogger("SCM_CalculateModel")
  private val RESPONSE_CODE_NAME: String = "responseCode"
  private val MSG_NAME: String = "msg"
  private val COOKIE_NAME: String = "cookie"
  private val TYPE_NAME: String = "type"
  private val RESULT_ARRAY_NAME: String = "hits"

  private val COUNT_PLACE_NAME: String = "total"
  private val MAC_NAME: String = "mac"
  private val PLACE_INFO_NAME: String = "pt"
  private val PLACE_NAME: String = "place"
  private val TIME_NAME: String = "time"

  private val ES_QUERY_QUERY = "query"
  private val ES_QUERY_RANGE = "range"
  private val ES_QUERY_BOOL = "bool"
  private val ES_QUERY_MUST = "must"
  private val ES_QUERY_TERMS = "terms"
  private val ES_QUERY_FILTER = "filter"
  private val ES_QUERY_GT = "gt"
  private val ES_QUERY_LTE = "lte"

  val POLYMERIZATION_PLACE = "3101"
  val DEFAULT_MAC_LENGTH = 12
  val ONE_THOUSAND_MILLISECONDS = 1000


  val errorMsg: (String, String, String, String) => String = (responseCode: String,
                                                              msg: String,
                                                              cookie: String,
                                                              ctype: String) =>
    s"""{"$RESPONSE_CODE_NAME":$responseCode,"$MSG_NAME":"$msg","$COOKIE_NAME":$cookie,"$TYPE_NAME":"$ctype","$RESULT_ARRAY_NAME":[]}"""

  val esQuery: (Long, Long, Array[String]) => String = (startTime: Long, endTime: Long, places: Array[String]) => {
    if(places.isEmpty) {
      s"""{"$ES_QUERY_QUERY":{"$ES_QUERY_RANGE":{"${SCMConf.getEsFieldTime}":
         |{"$ES_QUERY_GT":$startTime,"$ES_QUERY_LTE":$endTime}}}}""".stripMargin
    } else {
      val queryHead =
        s"""{"$ES_QUERY_QUERY": {"$ES_QUERY_BOOL": {"$ES_QUERY_MUST":
           |{"$ES_QUERY_TERMS": {"${SCMConf.getFieldServiceCode}": [""".stripMargin
      var placesStr: String = ""
      for(place: String <- places) {
        placesStr += s""""$place","""
      }
      placesStr = placesStr.substring(0, placesStr.length - 1)
      val queryTail =
        s"""]}},"$ES_QUERY_FILTER": {"$ES_QUERY_RANGE": {"${SCMConf.getEsFieldTime}":
           |{"$ES_QUERY_GT": "$startTime","$ES_QUERY_LTE": "$endTime"}}}}}}""".stripMargin

      val query = s"$queryHead$placesStr$queryTail"
      LOGGER.info(s"Builder es query. query: $query")
      query
    }

  }


  val accEsQuery: (Long, Long, Array[String]) => String = (startTime: Long, endTime: Long, macs: Array[String]) => {
    if(macs.isEmpty) {
      throw new IllegalArgumentException("Must have mac")
    } else {
      val queryHead =
        s"""{"$ES_QUERY_QUERY": {"$ES_QUERY_BOOL": {"$ES_QUERY_MUST":
           |{"$ES_QUERY_TERMS": {"${SCMConf.getEsFieldMac}": [""".stripMargin
      var macsStr: String = ""
      for(macs: String <- macs) {
        macsStr += s""""$macs","""
      }
      macsStr = macsStr.substring(0, macsStr.length - 1)
      val queryTail =
        s"""]}},"$ES_QUERY_FILTER": {"$ES_QUERY_RANGE": {"${SCMConf.getEsFieldTime}":
           |{"$ES_QUERY_GT": "$startTime","$ES_QUERY_LTE": "$endTime"}}}}}}""".stripMargin

      val query = s"$queryHead$macsStr$queryTail"
      LOGGER.debug(s"Builder es query. query: $query")
      query
    }

  }


  val forEsQuery: (Long, Long, Array[String]) => String = (startTime: Long, endTime: Long, places: Array[String]) => {
    if(places.isEmpty) {
      throw new IllegalArgumentException("Must have place")
    } else {
      val queryHead =
        s"""{"$ES_QUERY_QUERY": {"$ES_QUERY_BOOL": {"$ES_QUERY_MUST":
           |{"$ES_QUERY_TERMS": {"${SCMConf.getEsFieldServiceCodeForecasting}": [""".stripMargin
      var placesStr: String = ""
      for(place: String <- places) {
        placesStr += s""""$place","""
      }
      placesStr = placesStr.substring(0, placesStr.length - 1)
      val queryTail =
        s"""]}},"$ES_QUERY_FILTER": {"$ES_QUERY_RANGE": {"${SCMConf.getEsFieldTimeForecasting}":
           |{"$ES_QUERY_GT": "$startTime","$ES_QUERY_LTE": "$endTime"}}}}}}""".stripMargin

      val query = s"$queryHead$placesStr$queryTail"
      LOGGER.debug(s"Builder es query. query: $query")
      query
    }

  }

  def list2Tuple(calculateInfo: util.ArrayList[(String, String, String)]): (Long, Long, Array[String]) ={
    val startTime = Transformation.getTimeStamp(calculateInfo.get(0)._1, SCMConf.ACCOMPANY_TIME_FORMAT)/ONE_THOUSAND_MILLISECONDS
    val endTime = Transformation.getTimeStamp(calculateInfo.get(0)._2, SCMConf.ACCOMPANY_TIME_FORMAT)/ONE_THOUSAND_MILLISECONDS
    var array = Array[String]()
    for(index <- 0 until calculateInfo.size()) {
      if(!"".equals(calculateInfo.get(index)._3)) {
        array = array ++ Array(calculateInfo.get(index)._3)
      }
    }

    (startTime, endTime, array)
  }


  def array2Json(array: Array[(Long, Double)],
                responseCode: String,
                msg: String,
                cookie: String,
                ctype: String,
                op: String): String = {
    if(responseCode.isEmpty || msg.isEmpty || cookie.isEmpty
      || ctype.isEmpty) throw new NullPointerException

    //rdd大小
    val num = array.length
    if(num == 0) {
      return s"""{"$RESPONSE_CODE_NAME":$responseCode,"$MSG_NAME":"$msg","$COOKIE_NAME":$cookie,
                |"$TYPE_NAME":"$ctype","$RESULT_ARRAY_NAME":[]}""".stripMargin
    }

    //返回字符串构造
    var data: String =
      s"""{"$RESPONSE_CODE_NAME":$responseCode,"$MSG_NAME":"$msg","$COOKIE_NAME":$cookie,
         |"$TYPE_NAME":"$ctype","$RESULT_ARRAY_NAME":[""".stripMargin

    var arr = ""
    array.foreach{
      v =>
        arr += s"""{"${SCMDefine.FORECASTING_RETURN_TIMESTAMP}":${v._1},"${SCMDefine.FORECASTING_RETURN_COUNT}":${v._2}},"""
    }

    s"$data${arr.substring(0, arr.length - 1)}]}"
  }

  /**
    * RDD转换到json字符串
    * @param rdd RDD[(String, (Int, String, String))]
    * @return json字符串
    */
  def rdd2JsonStr(rdd: RDD[(String, (Int, String, String))],
                  responseCode: String,
                  msg: String,
                  cookie: String,
                  ctype: String,
                  op: String): String = {

    if(responseCode.isEmpty || msg.isEmpty || cookie.isEmpty
      || ctype.isEmpty) throw new NullPointerException

    //rdd大小
    val num = rdd.count().toInt
    if(num == 0) {
        return s"""{"$RESPONSE_CODE_NAME":$responseCode,"$MSG_NAME":"$msg","$COOKIE_NAME":$cookie,
           |"$TYPE_NAME":"$ctype","$RESULT_ARRAY_NAME":[]}""".stripMargin
    }

    //返回字符串构造
    var data: String =
      s"""{"$RESPONSE_CODE_NAME":$responseCode,"$MSG_NAME":"$msg","$COOKIE_NAME":$cookie,
         |"$TYPE_NAME":"$ctype","$RESULT_ARRAY_NAME":[""".stripMargin

    //获取rdd中的数据
    val rddList = rdd.take(num)

    if(SCMDefine.OP_RESIDENT_POPULATION.equals(op)) {
      rddList.map {
        attribute =>
          val serviceCode = attribute._1
          val macs = attribute._2._2
          val times = attribute._2._3
          s"""{"$COUNT_PLACE_NAME":${attribute._2._1},"$PLACE_NAME":"$serviceCode",
             |"$PLACE_INFO_NAME":${placeAndTime(MAC_NAME, macs, TIME_NAME, times)}""".stripMargin
      }.foreach{
        s =>
          data = s"$data$s,"
      }
    } else {
      rddList.map {
        attribute =>
          val mac1 = attribute._1
          var mac = ""
          if (mac1.length == DEFAULT_MAC_LENGTH) {
            //给mac地址添加"-"符号
            for (i <- 0 until mac1.length by 2) {
              mac = mac + mac1.substring(i, i + 2) + "-"
            }
            mac = mac.substring(0, mac.length - 1)

            s"""{"$COUNT_PLACE_NAME":${attribute._2._1},"$MAC_NAME":"$mac",
             |"$PLACE_INFO_NAME":${polymerizationPlacesAndTimes(attribute._2._2, attribute._2._3)}""".
              stripMargin
        } else {
          mac = mac1
          s"""{"$COUNT_PLACE_NAME":${attribute._2._1},"$MAC_NAME":"$mac",
             |"$PLACE_INFO_NAME":${placeAndTime(PLACE_NAME, attribute._2._2, TIME_NAME,
              attribute._2._3)} """.
              stripMargin
        }
      }.foreach{
          s =>
          data = s"$data$s,"
      }
    }

    if (num == 0) s"$data]}" else s"${data.substring(0, data.length - 1)}]}"

  }

  /**
    * 补全区域编号和时间转换
    * @param places 区域编号
    * @param times 时间
    * @return 字符串
    */
  def polymerizationPlacesAndTimes(places: String, times: String): String = {
    val placesArray = places.split(":")
    val timesArray = times.split(":")
    var r = "["

    for(i <- 0 until placesArray.length) {
      r = s"""$r{"$PLACE_NAME":"$POLYMERIZATION_PLACE${placesArray(i).reverse}","$TIME_NAME":"${getTimeStamp(timesArray(i), SCMConf.getCollisionTimeFormat)}"},"""
    }

    s"""${r.substring(0, r.length - 1)}]}"""
  }

  def placeAndTime(attName: String, attVal: String, attName1: String, attVal1: String): String = {
    val attValArray = attVal.split(":")
    val attValArray1 = attVal1.split(":")
    var returnStr = "["

    for(i <- 0 until attValArray.length) {
      returnStr = s"""$returnStr{"$attName":"${attValArray(i)}","$attName1":"${attValArray1(i)}"},"""
    }

    s"""${returnStr.substring(0, returnStr.length - 1)}]}"""
  }

  /**
    *时间转化
    * @param time 时间
    * @return
    */
  def getTimeStamp(time: String, format: String): Long = {
    //时间格式
    val timeFormat = new SimpleDateFormat(format)
    val date = timeFormat.parse(time)
    date.getTime
  }

  /**
    *时间转化
    * @param timeStamp 时间
    * @return
    */
  def getTime(timeStamp: Long, format: String): String = {
    //时间格式
    val timeFormat = new SimpleDateFormat(format)
    val date = timeFormat.format(new Date(timeStamp))
    date
  }

  def changeTime(time: String, change: Long): String = {
    val timeStamp = getTimeStamp(time, SCMConf.getCollisionTimeFormat)
    val changedTime = timeStamp + change

    getTime(changedTime, SCMConf.getCollisionTimeFormat)
  }

  /**
    * 将json字符串转换为对象
    * @param json json
    * @return
    */
  def json2Obj(json: String): RequestInfo = {
    implicit val formats: DefaultFormats.type = DefaultFormats
    parse(json).extract[RequestInfo]
  }


  /**
    * Json to calculate parameter
    * @param fromtime This is start time
    * @param totime This is end time
    * @param place This is location code
    */
  case class ParamInfo(fromtime: String, totime: String, place: Array[String])

  /**
    * Json to massage case class
    * @param min Min collision value
    * @param max Max collision value
    * @param cookie Cookie
    * @param `type` Request type
    * @param param Calculate parameter
    */
  case class RequestInfo(min: Int, max: Int, cookie: Int, `type`: String, param: Array[ParamInfo]) {
    val SEPs: util.ArrayList[(String, String, String)] = {
      //sep startTime,endTime,place 起始时间,结束时间,地点编号
      val sep = new util.ArrayList[(String, String, String)]()
      param.foreach{
        timePlaceTuple =>
          //起始时间
          val fromTime = timePlaceTuple.fromtime
          //结束时间
          val toTime = timePlaceTuple.totime
          //地点
          val place = timePlaceTuple.place
          if(place.length == 0) {
            sep.add(fromTime.toString.replaceAll("-", "").replaceAll(" ", "").replaceAll(":", ""),
              toTime.toString.replaceAll("-", "").replaceAll(" ", "").replaceAll(":", ""), "")
          }
          place.foreach{
            p =>
              sep.add(fromTime.toString.replaceAll("-", "").replaceAll(" ", "").replaceAll(":", ""),
                toTime.toString.replaceAll("-", "").replaceAll(" ", "").replaceAll(":", ""), p.replaceFirst(POLYMERIZATION_PLACE, ""))
          }
      }
      sep
    }
  }
}
