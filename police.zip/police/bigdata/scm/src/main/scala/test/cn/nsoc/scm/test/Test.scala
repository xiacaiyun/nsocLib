package test.cn.nsoc.scm.test

import cn.nsoc.scm.define.SCMConf
import cn.nsoc.scm.tools.Transformation

object Test {
  def main(args: Array[String]): Unit = {
//    println(Transformation.getTimeStamp("20171012000000", SCMConf.SCM_ES_TIME_FORMAT))
    //println(Transformation.getTime(1507793289000L, SCMConf.SCM_ES_TIME_FORMAT))
    println(Transformation.accEsQuery(1509955200L, 1509962400L, Array("6C-72-E7-60-F5-08")))
//    println("12345".substring(0, 4))
  }

}
