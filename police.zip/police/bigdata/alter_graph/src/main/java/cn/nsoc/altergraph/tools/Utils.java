package cn.nsoc.altergraph.tools;

public class Utils {
    public static long toHashCode(Object... os) {
        StringBuilder sb = new StringBuilder();
        for(Object o: os) {
            sb.append(o);
        }
        return sb.toString().hashCode();
    }
}
