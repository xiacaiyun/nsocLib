package cn.nsoc.altergraph.i;

import cn.nsoc.altergraph.alter.CreateBuilder;
import cn.nsoc.altergraph.alter.QueryBuilder;
import cn.nsoc.altergraph.alter.VirtualID;
import cn.nsoc.base.entity.sys.NSException;

import java.util.List;
import java.util.Map;

/**
 * Define graph database alter.
 * Create by Alan 2017.10.16
 */
public interface IBaseAlter {
    /**
     * Create nodes
     * @param createBuilders ICreateBuilder list
     */
    void create(List<CreateBuilder> createBuilders) throws NSException;

    /**
     * Query relational network for one layer
     * @param nodeId Start node id
     * @return Nodes list. Dose not include incoming nodes
     * @throws NSException NSException
     */
    List<Map<String, Object>> query(String nodeId) throws NSException;

    /**
     * Query by id and type
     * @param nodeId Node id
     * @param type Type
     * @return Nodes list. Dose not include incoming nodes
     * @throws NSException NSException
     */
    List<Map<String, Object>> query(String nodeId, String type) throws NSException;

    /**
     * Query relational network
     * @param nodeId Start node id
     * @param layer Relationship layer number
     * @return IQueryRow
     */
    List<IQueryRow> query(String nodeId, int layer) throws NSException;

    /**
     * Query relational network
     * @param nodeId Start node id
     * @param layer Relationship layer number
     * @param nodeType Node type
     * @return IQueryRow
     */
    List<IQueryRow> query(String nodeId, int layer, String nodeType) throws NSException;

    /**
     * Query relational network
     * @param nodeId Start node id
     * @param layer Relationship layer number
     * @param nodeType Node type
     * @param startLabel Start label example: group
     * @param toLabel To label example: single
     * @return IQueryRow
     */
    List<IQueryRow> query(String nodeId, int layer, String nodeType, String startLabel, String toLabel) throws NSException;

    /**
     * Query relationship network
     * @param queryBuilder QueryBuilder
     * @return IQueryRow
     * @throws NSException NSException
     */
     List<IQueryRow> query(QueryBuilder queryBuilder) throws NSException;


    /**
     * Query by ids polymerization nodes
     * @param ids Node id and type example: Map[qq001, qq; wx001, wx; ...]
     * @return Polymerization nodes. Dose not include incoming nodes
     * @throws NSException NSException
     */
     List<Map<String, Object>> polymerizationQuery(List<VirtualID> ids) throws NSException;

    /**
     *Shutdown neo4jAlter
     */
    void shutdown();
}
