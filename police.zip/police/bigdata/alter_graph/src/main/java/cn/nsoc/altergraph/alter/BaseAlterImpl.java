package cn.nsoc.altergraph.alter;

import cn.nsoc.altergraph.i.IBaseAlter;
import cn.nsoc.altergraph.i.IQueryRow;
import cn.nsoc.base.entity.sys.NSException;

import java.util.List;
import java.util.Map;

public abstract class BaseAlterImpl implements IBaseAlter {

    @Override
    public void create(List<CreateBuilder> createBuilders) throws NSException {

    }

    @Override
    public List<Map<String, Object>> query(String nodeId) throws NSException {
        return null;
    }

    @Override
    public List<IQueryRow> query(String nodeId, int layer) throws NSException {
        return null;
    }

    @Override
    public List<IQueryRow> query(QueryBuilder queryBuilder) throws NSException {
        return null;
    }

    @Override
    public List<Map<String, Object>> query(String nodeId, String type) throws NSException {
        return null;
    }

    @Override
    public List<IQueryRow> query(String nodeId, int layer, String nodeType) throws NSException {
        return null;
    }

    @Override
    public List<IQueryRow> query(String nodeId, int layer, String nodeType, String startLabel, String toLabel) throws NSException {
        return null;
    }

    @Override
    public List<Map<String, Object>> polymerizationQuery(List<VirtualID> ids) throws NSException {
        return null;
    }

    @Override
    public void shutdown() {

    }
}
