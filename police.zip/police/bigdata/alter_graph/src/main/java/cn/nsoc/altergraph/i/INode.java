package cn.nsoc.altergraph.i;

import java.util.Map;

/**
 * Define node.
 * Create by Alan 2017.10.16
 */
public interface INode {
    /**
     * Get node id
     * @return node id
     */
    String getId();

    /**
     * Get node label
     * @return node label
     */
    String[] getLbs();

    /**
     * Get node attributes
     * @return node attributes
     */
    Map<String, String> getAtts();
}
