package cn.nsoc.altergraph.alter;

import cn.nsoc.altergraph.tools.Cache4MapDB;
import cn.nsoc.altergraph.tools.ConnectionTools;
import org.apache.log4j.Logger;
import org.mapdb.BTreeMap;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Set;

/**
 * Cql runnable
 */
public class RunCql implements Runnable{
    private ConnectionTools connTools;
    private Cache4MapDB db;
    private static final Logger LOGGER = Logger.getLogger("RunCql");
    private boolean run = true;
    private boolean isRun = false;
    private long wait = 0L;
    private String cacheName;

    public RunCql(ConnectionTools tools, Cache4MapDB db, String cacheName) {
        this.connTools = tools;
        this.db = db;
        this.cacheName = cacheName;
    }

    @Override
    public void run() {
        BTreeMap exeNodeCqlCache;
        PreparedStatement statement = null;
        Connection connection = null;
        try {
            isRun = true;
            Thread.sleep(1000);
            while (run) {
                try{
                    exeNodeCqlCache = db.getTreeMap(cacheName, 100000);
                    Set keySet = exeNodeCqlCache.keySet();
                    if(keySet.isEmpty()) {
                        wait += 1000L;
                        LOGGER.debug(String.format("Cache cql is empty, wait %d ms", wait));
                        Thread.sleep(wait);
                        if(wait > 120000) {
                            LOGGER.debug(String.format("Cache cql is empty, wait = %d > 1200000 set wait =  300000", wait));
                            wait = 30000L;
                        }
                    } else {
                        wait = 0L;
                        connection = connTools.getConn();
                        LOGGER.debug(String.format("Create node get connection: %s", connection));
                        for (Object key : keySet) {
                            Object cql = exeNodeCqlCache.get(key);
                            LOGGER.info("Exec cql: " + cql);
                            try {
                                statement = connection.prepareStatement(String.valueOf(cql));
                                statement.execute();
                                exeNodeCqlCache.remove(key);
                            } catch (SQLException e) {
                                if(exeNodeCqlCache.containsKey(key)) {
                                    exeNodeCqlCache.remove(key);
                                }
                                LOGGER.error(String.format("The cql exec fail and deleted. cql: %s", String.valueOf(cql)));
                                LOGGER.error(e);
                            }
                        }
                    }
                } finally {
                    try {
                        if (statement != null) statement.close();
                        if (connection != null) connection.close();
                    } catch (SQLException e) {
                        LOGGER.error(e);
                    }
                }
            }

            isRun = false;
        } catch (SQLException | InterruptedException e) {
            LOGGER.error(e);
        }
    }


    /**
     * Stop sed cql
     */
    public void stop() {
        this.run = false;
    }

    /**
     * Check sender is run.
     * @return Is run
     */
    public boolean isRun() {
        return this.isRun;
    }
}
