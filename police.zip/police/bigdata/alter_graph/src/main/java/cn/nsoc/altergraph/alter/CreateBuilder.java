package cn.nsoc.altergraph.alter;

import cn.nsoc.altergraph.i.INode;
import cn.nsoc.altergraph.i.IRel;

import java.io.IOException;

/**
 * Create builder
 * Create by Alan 2017.10.25
 */
public class CreateBuilder {
    //Start node
    private INode fromNode;
    //End node
    private INode toNode;
    //Relationship
    private IRel rel;

    public CreateBuilder(){}

    public CreateBuilder(INode fromNode, INode toNode, IRel rel) {
        setFromNode(fromNode);
        setToNode(toNode);
        setRel(rel);
    }

    /**
     * Get start node
     * @return INode
     * @throws IOException io exception
     */
    INode getFromNode() throws IOException {
        return fromNode;
    }

    /**
     * Get end node
     * @return INode
     * @throws IOException io exception
     */
    INode getToNode() throws IOException {
        return toNode;
    }


    /**
     * Get Relationship
     * @return Relationship
     * @throws IOException io exception
     */
    Relationship getRelationship() throws IOException {
        if(this.fromNode == null || this.toNode == null || this.rel == null)
            throw new NullPointerException("fromNode or toNode or rel is null");

        Relationship relationship = new Relationship();
        relationship
                .setRelName(rel.getRelName())
                .setFromLab(getLabs(fromNode.getLbs()))
                .setToLab(getLabs(toNode.getLbs()))
                .setFromId(fromNode.getId())
                .setToId(toNode.getId()).setAtts(rel.getAtts());

        return relationship;
    }

    /**
     * Set start node
     * @param fromNode Start node
     * @return CreateBuilder
     */
    public CreateBuilder setFromNode(INode fromNode) {
        if (fromNode == null) throw new NullPointerException();
        this.fromNode = fromNode;
        return this;
    }

    /**
     * Set addRel
     * @param rel Start node
     * @return CreateBuilder
     */
    public CreateBuilder setRel(IRel rel) {
        if (rel == null) throw new NullPointerException();
        this.rel = rel;
        return this;
    }

    /**
     * Set end node
     * @param toNode Start node
     * @return CreateBuilder
     */
    public CreateBuilder setToNode(INode toNode) {
        if (toNode == null) throw new NullPointerException();
        this.toNode = toNode;
        return this;
    }

    /**
     * Lab array to lab string
     * @param labs Lab string
     * @return Lab string
     */
    private String getLabs(String[] labs) {
        StringBuilder r = new StringBuilder();
        for(String l: labs) {
            r.append(l).append(":");
        }
        int lastMao = r.lastIndexOf(":");
        return r.delete(lastMao, lastMao + 1).toString();
    }
}
