package cn.nsoc.altergraph.alter;

import cn.nsoc.altergraph.conf.RelDirect;

public class QueryBuilder {
    private String nodeId;
    private String type;
    private RelDirect direct;
    private A2.B a2b;

    /**
     * Build query
     * @param nodeId Node id
     * @param nodeType Node type
     * @param node2node relationship
     */
    public QueryBuilder(String nodeId, String nodeType, RelDirect direct, A2.B node2node) {
        this.nodeId = nodeId;
        this.type = nodeType;
        this.a2b = node2node;
        this.direct = direct;
    }

    /**
     * Build query
     * @param nodeId Node id
     * @param nodeType Node type
     * @param relName Relationship name
     * @param startLab Start lab example: user
     * @param toLab To lab example: group
     * @param layer Relationship layer
     */
    public QueryBuilder(String nodeId, String nodeType, String relName, String startLab, String toLab, int layer, RelDirect direct) {
        A2.R r = A2.start(startLab);
        for(int layerIndex = 0; layerIndex < layer; layerIndex ++) {
            r.addRel(relName);
        }
        this.a2b = r.endRel().to(toLab);
        this.nodeId = nodeId;
        this.type = nodeType;
        this.direct = direct;
    }

    public String getType() {
        return type;
    }

    public A2.B getA2b() {
        return a2b;
    }

    public String getNodeId() {
        return nodeId;
    }

    public void setType(String type) {
        this.type = type;
    }

    public void setA2b(A2.B a2b) {
        this.a2b = a2b;
    }

    public void setNodeId(String nodeId) {
        this.nodeId = nodeId;
    }

    public RelDirect getDirect() {
        return direct;
    }

    public void setDirect(RelDirect direct) {
        this.direct = direct;
    }
}

