package cn.nsoc.altergraph.i;

import java.util.Map;

public interface IRel {
    /**
     * Get relationship name
     * @return relationship name
     */
    String getRelName();
    /**
     * Get relationship attributes
     * @return relationship attributes
     */
    Map<String, String> getAtts();
}
