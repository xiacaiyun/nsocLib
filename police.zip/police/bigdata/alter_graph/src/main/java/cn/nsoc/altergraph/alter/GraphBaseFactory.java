package cn.nsoc.altergraph.alter;

import cn.nsoc.altergraph.conf.BaseDefine;
import cn.nsoc.altergraph.i.IBaseAlter;
import cn.nsoc.base.entity.sys.NSException;

/**
 * Get implements instance
 * Create by Alan 2017.10.26
 */
public class GraphBaseFactory {
    /**
     * Get IBaseAlter implements
     * @param baseType example: neo4j_sync or neo4j_async or neo4j_query ...
     * @param ipAndPort Connection to base ip and port example: 127.0.0.1:1234
     * @param user Connection to base user
     * @param password Connection to base password
     * @return IBaseAlter implements instance
     * @throws NSException NSException
     */
    public static IBaseAlter getBaseAlter(String baseType,
                                          String ipAndPort,
                                          String user,
                                          String password,
                                          boolean isSync,
                                          boolean isOnlyQuery) throws NSException {
        String type = baseType.trim().toLowerCase();
        Neo4jAlter baseAlter;
        switch (type) {
            case BaseDefine.NEO4J:
                baseAlter = new Neo4jAlter(ipAndPort, user, password);
                try {
                    if(isOnlyQuery) {
                        baseAlter.initOnlyQuery();
                    } else {
                        if(isSync) {
                            baseAlter.initSync();
                        } else {
                            baseAlter.initAsync();
                        }
                    }
                    return baseAlter;
                } catch (NSException e) {
                    throw new NSException(e);
                }
            default:
                throw new NSException(String.format("Invalidate base type:%s", baseType));
        }
    }

    /**
     * Default IBaseAlter implements
     * @return IBaseAlter
     */
    public static IBaseAlter getDefaultBaseAlter() {
        return new DefaultBaseAlter();
    }

    /**
     * Get base alter is only query
     * @param baseType example: neo4j_sync or neo4j_async or neo4j_query ...
     * @param ipAndPort Connection to base ip and port example: 127.0.0.1:1234
     * @param user Connection to base user
     * @param password Connection to base password
     * @return IBaseAlter implements instance
     * @throws NSException NSException
     */
    public static IBaseAlter getBaseAlterIsOnlyQuery(String baseType,
                                 String ipAndPort,
                                 String user,
                                 String password) throws NSException {
        return getBaseAlter(baseType, ipAndPort, user, password, false, true);
    }

}
