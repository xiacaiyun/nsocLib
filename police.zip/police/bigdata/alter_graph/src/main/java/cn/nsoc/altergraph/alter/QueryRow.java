package cn.nsoc.altergraph.alter;

import cn.nsoc.altergraph.i.IQueryRow;
import cn.nsoc.base.entity.sys.NSException;

import java.util.List;
import java.util.Map;

public class QueryRow implements IQueryRow {
    private List<Map<String, Object>> items;
    public QueryRow(List<Map<String, Object>> items) {
        this.items = items;
    }

    @Override
    public int getCount() {
        return items.size();
    }

    @Override
    public List<Map<String, Object>> getItems() {
        return items;
    }

    @Override
    public Map<String, Object> getOneRelNode() throws NSException {
        if(items.size() <= 1) {
            throw new NSException(String.format("No one relationship node. Item size: %d", getCount()));
        }
        return items.get(1);
    }
}
