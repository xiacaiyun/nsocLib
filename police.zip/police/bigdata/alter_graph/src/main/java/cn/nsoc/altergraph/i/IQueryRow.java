package cn.nsoc.altergraph.i;

import cn.nsoc.base.entity.sys.NSException;

import java.util.List;
import java.util.Map;

/**
 * Define query result value.
 * Create by Alan 2017.10.16
 */
public interface IQueryRow {
    /**
     * Get result count
     * @return result count
     */
    int getCount();

    /**
     * Get result Items
     * One layer relationship: List(1):startNode-List(2):endNode
     * Two layer relationship: List(1):startNode-List(2):connectionNode-List(3):endNode
     * @return Result items
     */
    List<Map<String, Object>> getItems();

    /**
     * Get one relationship node
     * Map<String, Object>: AttributeName -> AttributeValue
     * @return node
     */
    Map<String, Object> getOneRelNode() throws NSException;
}
