package cn.nsoc.altergraph.alter;

import cn.nsoc.altergraph.conf.BaseDefine;
import cn.nsoc.altergraph.conf.RelDirect;
import cn.nsoc.altergraph.i.INode;
import cn.nsoc.altergraph.i.IQueryRow;
import cn.nsoc.base.entity.tuple.Tuple2;
import org.apache.log4j.Logger;
import org.json.JSONObject;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

class AssemblyDevice {
    private static final Logger LOGGER = Logger.getLogger("AssemblyDevice");
    private static final String CQL_MATCH = "MATCH";
    private static final String CQL_AS = "AS";
    private static final String CQL_ROW = "row";
    private static final String CQL_UNWIND = "UNWIND";
    private static final String CQL_CREATE = "MERGE";
    private static final String CQL_DELETE = "DELETE";
    private static final String CQL_RETURN = "RETURN";
    private static final String CQL_SET = "SET";
    private static final String CQL_START_NODE_NAME = "from";
    private static final String CQL_TO_NODE_NAME = "to";
    private static final String CQL_ATTRIBUTE_CREATE_NAME = "pt";
    private static final String CQL_ATTRIBUTE_UPDATE_NAME = "up";
    private static final String CQL_ATTRIBUTE_ID_NAME = "id";
    private static final String CQL_RELATIONSHIP_NAME = "r";
    private static final String CQL_SPACE = " ";
    private static final String CQL_COMMA = ",";
    private static final String CQL_DOT = ".";
    private static final String CQL_COLON = ":";
    private static final String CQL_SIGN = "=";
    private static final String CQL_SINGLE_QUOTE = "\'";
    private static final String CQL_DOUBLE_QUOTE = "\"";
    private static final String JSON_SOURCE_NAME = "s";
    private static final String JSON_TARGET_NAME = "t";

    private static final String CQL_NODE_NAME = "n";

    //当前拼接的CQL
    private String currentCql = "";

    AssemblyDevice(){}

    /**
     * Get batch create node Cql
     * @param nodes Nodes list
     * @return Cql
     */
    String createNodesCql(List<INode> nodes) {
        //要插入的属性键值对
        Map<String, String> oneAtt;
        //标签数组
        String[] labels;

        if (nodes == null || nodes.size() == 0) {
            throw new NullPointerException();
        } else {
            oneAtt = nodes.get(0).getAtts();
            labels = nodes.get(0).getLbs();
        }

        //拼装属性
        StringBuilder nodesData = new StringBuilder("[");
        for (INode node : nodes) {
            nodesData.append(String.format(
                    "{%s%s%s%s%s%s%s%s{",
                    CQL_ATTRIBUTE_ID_NAME, CQL_COLON, CQL_DOUBLE_QUOTE, node.getId(),
                    CQL_DOUBLE_QUOTE, CQL_COMMA, CQL_ATTRIBUTE_CREATE_NAME, CQL_COLON));
            for (Map.Entry<String, String> attribute : node.getAtts().entrySet()) {
                nodesData.append(String.format(
                        "%s%s%s%s%s%s",
                        attribute.getKey(), CQL_COLON, CQL_DOUBLE_QUOTE,
                        attribute.getValue(), CQL_DOUBLE_QUOTE, CQL_COMMA));
            }
            nodesData = deleteLastComma(nodesData);
            nodesData.append(String.format("}}%s", CQL_COMMA));
        }
        nodesData = deleteLastComma(nodesData);
        nodesData.append("]");

        //拼装cql
        StringBuilder createNodesCql = new StringBuilder(String.format(
                "%s%s%s%s%s%s%s%s",
                CQL_UNWIND, CQL_SPACE, nodesData, CQL_SPACE, CQL_AS, CQL_SPACE, CQL_ROW, CQL_SPACE));
        createNodesCql.append(String.format("%s%s(%s", CQL_CREATE, CQL_SPACE, CQL_NODE_NAME));
        for (String label : labels) {
            createNodesCql.append(String.format("%s%s", CQL_COLON, label));
        }
        createNodesCql.append(String.format(
                "%s{%s%s%s%s%s})%s%s%s",
                CQL_SPACE, CQL_ATTRIBUTE_ID_NAME, CQL_COLON,
                CQL_ROW, CQL_DOT, CQL_ATTRIBUTE_ID_NAME, CQL_SPACE, CQL_SET, CQL_SPACE));
        for (Map.Entry<String, String> kv : oneAtt.entrySet()) {
            createNodesCql.append(String.format(
                    "%s%s%s%s%s%s%s%s%s%s",
                    CQL_NODE_NAME, CQL_DOT, kv.getKey(), CQL_SIGN, CQL_ROW,
                    CQL_DOT, CQL_ATTRIBUTE_CREATE_NAME, CQL_DOT, kv.getKey(), CQL_COMMA));
        }

        createNodesCql = deleteLastComma(createNodesCql);
        currentCql = createNodesCql.toString();

        LOGGER.debug(String.format("Create batch nodes %s ", currentCql));

        return createNodesCql.toString();
    }

    /**
     * Get batch create relationship Cql have attributes
     * @param relationship  Relationship name
     * @param rels Relationship list
     * @return Cql
     */
    private String createRelsCqlHaveAttr(
            String fromLbl,
            String toLbl,
            String relationship,
            List<Relationship> rels) {

        Map<String, String> oneAttribute;
        if(relationship == null || rels == null
                || relationship.length() == 0
                || rels.size() == 0) {
            throw new NullPointerException();
        } else {
            oneAttribute = rels.get(0).getAtts();
        }
        StringBuilder relationshipsData = new StringBuilder("[");
        for(Relationship mould: rels) {
            relationshipsData.append(String.format(
                    "{%s%s%s%s%s%s%s%s%s%s%s%s%s%s{",
                    CQL_START_NODE_NAME, CQL_COLON, CQL_DOUBLE_QUOTE, mould.getFromId(),
                    CQL_DOUBLE_QUOTE, CQL_COMMA, CQL_TO_NODE_NAME, CQL_COLON, CQL_DOUBLE_QUOTE,
                    mould.getToId(), CQL_DOUBLE_QUOTE, CQL_COMMA, CQL_ATTRIBUTE_CREATE_NAME, CQL_COLON));
            for(Map.Entry<String, String> attribute: mould.getAtts().entrySet()) {
                relationshipsData.append(String.format(
                        "%s%s%s%s%s%s",
                        attribute.getKey(), CQL_COLON, CQL_DOUBLE_QUOTE,
                        attribute.getValue(), CQL_DOUBLE_QUOTE, CQL_COMMA));
            }
            relationshipsData = deleteLastComma(relationshipsData);
            relationshipsData.append("}}").append(CQL_COMMA);
        }
        relationshipsData = deleteLastComma(relationshipsData);
        relationshipsData.append("]");

        StringBuilder createCql = new StringBuilder(String.format(
                "%s%s%s%s%s%s%s%s",
                CQL_UNWIND, CQL_SPACE, relationshipsData, CQL_SPACE, CQL_AS, CQL_SPACE, CQL_ROW, CQL_SPACE));

        createCql.append(String.format(
                "%s%s(%s%s%s%s{%s%s%s%s%s})%s%s%s(%s%s%s%s{%s%s%s%s%s})%s",
                CQL_MATCH, CQL_SPACE, CQL_START_NODE_NAME, CQL_COLON,fromLbl,
                CQL_SPACE, CQL_ATTRIBUTE_ID_NAME, CQL_COLON,
                CQL_ROW, CQL_DOT, CQL_START_NODE_NAME, CQL_SPACE, CQL_MATCH,
                CQL_SPACE, CQL_TO_NODE_NAME, CQL_COLON, toLbl, CQL_SPACE,
                CQL_ATTRIBUTE_ID_NAME, CQL_COLON, CQL_ROW, CQL_DOT, CQL_TO_NODE_NAME, CQL_SPACE));

        createCql.append(String.format(
                "%s%s(%s)-[%s%s%s]->(%s)%s%s%s",
                CQL_CREATE, CQL_SPACE, CQL_START_NODE_NAME, CQL_RELATIONSHIP_NAME,
                CQL_COLON, relationship, CQL_TO_NODE_NAME, CQL_SPACE, CQL_SET, CQL_SPACE));

        for(Map.Entry<String, String> attKV: oneAttribute.entrySet()) {
            createCql.append(String.format(
                    "%s%s%s%s%s%s%s%s%s%s",
                    CQL_RELATIONSHIP_NAME, CQL_DOT, attKV.getKey(), CQL_SIGN, CQL_ROW,
                    CQL_DOT, CQL_ATTRIBUTE_CREATE_NAME, CQL_DOT, attKV.getKey(), CQL_COMMA));
        }

        createCql = deleteLastComma(createCql);
        currentCql = createCql.toString();
        LOGGER.debug(String.format("Create batch relationships %s ", currentCql));
        return createCql.toString();
    }

    /**
     * Get batch create relationship Cql
     * @param relationship  Relationship name
     * @param rels Relationship list
     * @return Cql
     */
    String createRelsCql(
            String fromLbl,
            String toLbl,
            String relationship,
            List<Relationship> rels) {

        Map<String, String> oneAttribute;
        if(relationship == null || rels == null
                || relationship.length() == 0
                || rels.size() == 0) {
            throw new NullPointerException();
        } else {
            oneAttribute = rels.get(0).getAtts();
        }

        StringBuilder createCql = new StringBuilder();
        if(oneAttribute != null && oneAttribute.size() > 0) {
            return createRelsCqlHaveAttr(fromLbl, toLbl, relationship, rels);
        } else {
            StringBuilder relsData = new StringBuilder("[");
            for(Relationship mould: rels) {
                relsData.append(String.format(
                        "{%s%s%s%s%s%s%s%s%s%s%s}%s",
                        CQL_START_NODE_NAME, CQL_COLON, CQL_DOUBLE_QUOTE, mould.getFromId(),
                        CQL_DOUBLE_QUOTE, CQL_COMMA, CQL_TO_NODE_NAME, CQL_COLON, CQL_DOUBLE_QUOTE,
                        mould.getToId(), CQL_DOUBLE_QUOTE, CQL_COMMA));

            }
            deleteLastComma(relsData);
            relsData.append("]");

            createCql.append(String.format(
                    "%s%s%s%s%s%s%s%s",
                    CQL_UNWIND, CQL_SPACE, relsData, CQL_SPACE, CQL_AS, CQL_SPACE, CQL_ROW, CQL_SPACE));

            createCql.append(String.format(
                    "%s%s(%s%s%s%s{%s%s%s%s%s})%s%s%s(%s%s%s%s{%s%s%s%s%s})%s",
                    CQL_MATCH, CQL_SPACE, CQL_START_NODE_NAME, CQL_COLON,fromLbl,
                    CQL_SPACE, CQL_ATTRIBUTE_ID_NAME, CQL_COLON,
                    CQL_ROW, CQL_DOT, CQL_START_NODE_NAME, CQL_SPACE, CQL_MATCH,
                    CQL_SPACE, CQL_TO_NODE_NAME, CQL_COLON, toLbl, CQL_SPACE,
                    CQL_ATTRIBUTE_ID_NAME, CQL_COLON, CQL_ROW, CQL_DOT, CQL_TO_NODE_NAME, CQL_SPACE));

            createCql.append(String.format(
                    "%s%s(%s)-[%s%s%s]->(%s)",
                    CQL_CREATE, CQL_SPACE, CQL_START_NODE_NAME, CQL_RELATIONSHIP_NAME,
                    CQL_COLON, relationship, CQL_TO_NODE_NAME));

        }


        currentCql = createCql.toString();
        LOGGER.debug(String.format("Create batch relationships %s ", currentCql));
        return createCql.toString();
    }


    Tuple2<String, List<String>> createQueryCql(QueryBuilder builder) {
        List<String> queryAtt = new ArrayList<>();
        String startNode = builder.getNodeId();
        String type = builder.getType();
        String fromLab = builder.getA2b().getFromLab();
        String toLab = builder.getA2b().getToLab();
        List<String> rels = builder.getA2b().getRel();
        RelDirect direct = builder.getDirect();

        StringBuilder queryCql = new StringBuilder(String.format("%s%s", CQL_MATCH, CQL_SPACE));
        queryCql.append(buildNode(CQL_NODE_NAME, startNode, fromLab, type));
        queryAtt.add(CQL_NODE_NAME);
        for(int relIndex = 0; relIndex < rels.size(); relIndex ++) {
            String relName = CQL_RELATIONSHIP_NAME + relIndex;
            queryCql.append(buildRel(relName, rels.get(relIndex), direct));
            String nodeName = CQL_NODE_NAME + relIndex;
            queryCql.append(buildNode(nodeName, "", toLab, type));
            queryAtt.add(nodeName);
        }

        queryCql.append(String.format("%s%s%s", CQL_SPACE, CQL_RETURN, CQL_SPACE));

        for(String re: queryAtt) {
            queryCql.append(re).append(",");
        }

        queryCql = deleteLastComma(queryCql);
        currentCql = queryCql.toString();
        LOGGER.debug(String.format("Query sql %s ", currentCql));

        return new Tuple2<>(queryCql.toString(), queryAtt);
    }

    List<IQueryRow> result2List(ResultSet resultSet, List<String> retN) throws SQLException {
        if(retN == null || retN.size() == 0) throw new NullPointerException();
        List<IQueryRow> rows = new ArrayList<>();

        while (resultSet.next()){
            List<Map<String, Object>> nodeList = new ArrayList<>();
            for(String nodeName: retN) {
                String nodeInfo = resultSet.getString(nodeName);
                JSONObject jsonObject = new JSONObject(nodeInfo);
                nodeList.add(jsonObject.toMap());
            }
            IQueryRow row = new QueryRow(nodeList);
            rows.add(row);
        }

        return rows;
    }

    private String buildNode(String name, String id, String lab, String type) {
        StringBuilder builder = new StringBuilder(String.format("(%s", name));
        if(lab != null && lab.length() > 0) {
            builder.append(String.format("%s%s%s", CQL_COLON, lab, CQL_SPACE));
        }

        if(id != null && id.length() > 0) {
            builder.append(String.format("%s{%s%s%s%s%s",
                    CQL_SPACE, CQL_ATTRIBUTE_ID_NAME, CQL_COLON, CQL_SINGLE_QUOTE, id, CQL_SINGLE_QUOTE));
            if(type != null && type.length() > 0) {
                builder.append(String.format("%s%s%s%s%s%s})",
                        CQL_COMMA, BaseDefine.NODE_TYPE_NAME, CQL_COLON, CQL_SINGLE_QUOTE, type, CQL_SINGLE_QUOTE));
            } else {
                builder.append("})");
            }
        } else {
            if(type != null && type.length() > 0) {
                builder.append(String.format("%s{%s%s%s%s%s})",
                        CQL_SPACE, BaseDefine.NODE_TYPE_NAME, CQL_COLON, CQL_SINGLE_QUOTE, type, CQL_SINGLE_QUOTE));
            } else {
                builder.append(")");
            }
        }


        return builder.toString();
    }

    private String buildRel(String relName, String rel, RelDirect dir) {
        StringBuilder builder = new StringBuilder();
        switch (dir) {
            case POSITIVE:
                builder.append(String.format("-[%s", relName));
                if(rel != null && rel.length() > 0) {
                    builder.append(String.format("%s%s]->", CQL_COLON, rel));
                } else {
                    builder.append("]->");
                }
                break;
            case REVERSE:
                builder.append(String.format("<-[%s", relName));
                if(rel != null && rel.length() > 0) {
                    builder.append(String.format("%s%s]-", CQL_COLON, rel));
                } else {
                    builder.append("]-");
                }
                break;
            case UNDIRECTED:
                builder.append(String.format("-[%s", relName));
                if(rel != null && rel.length() > 0) {
                    builder.append(String.format("%s%s]-", CQL_COLON, rel));
                } else {
                    builder.append("]-");
                }
                break;
        }

        return builder.toString();
    }


    /**
     * 删除最后一个逗号
     * @param sb StringBuilder
     * @return 删除完的StringBuilder
     */
    public StringBuilder deleteLastComma(StringBuilder sb) {
        int lastCommaIndex = sb.lastIndexOf(",");
        if(lastCommaIndex < 0) {return  sb;}
        //删除最后一个逗号
        return sb.delete(lastCommaIndex, lastCommaIndex + 1);
    }

    /**
     * 获取最近一条拼接的cql
     * @return cql
     */
    String getCurrentCql() {
        return this.currentCql;
    }


}
