package cn.nsoc.altergraph.conf;

/**
 *Direction definition
 */
public enum  RelDirect {
    POSITIVE,REVERSE,UNDIRECTED
}
