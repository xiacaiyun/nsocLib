package cn.nsoc.altergraph.alter;

/**
 * default Neo4jAlter implements
 */
class DefaultBaseAlter extends BaseAlterImpl {}
