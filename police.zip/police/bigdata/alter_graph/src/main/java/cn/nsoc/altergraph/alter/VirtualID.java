package cn.nsoc.altergraph.alter;

public class VirtualID {
    private String id;
    private String type;

    public VirtualID() {}
    public VirtualID(String id, String type) {
        this.id = id;
        this.type = type;
    }

    public final String getType() {
        return type;
    }

    public final String getId() {
        return id;
    }

    public final void setType(String type) {
        this.type = type;
    }

    public final void setId(String id) {
        this.id = id;
    }
}
