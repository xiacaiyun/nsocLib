package cn.nsoc.altergraph.alter;

import cn.nsoc.altergraph.conf.RelDirect;
import cn.nsoc.altergraph.i.*;
import cn.nsoc.altergraph.tools.Cache4MapDB;
import cn.nsoc.altergraph.tools.ConnectionTools;
import cn.nsoc.altergraph.tools.Utils;
import cn.nsoc.base.entity.sys.NSException;
import cn.nsoc.base.entity.tuple.Tuple2;
import cn.nsoc.nspider.commlib.Util;
import org.apache.log4j.Logger;
import org.mapdb.BTreeMap;
import org.mapdb.HTreeMap;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.*;

/**
 * Neo4j implements
 * Create by Alan 2017.10.25
 */
class Neo4jAlter extends BaseAlterImpl {
    private static final Logger LOGGER = Logger.getLogger("Neo4jAlter");
    private int initType;
    private AssemblyDevice assemblyDevice;
    private ConnectionTools connTools;
    private Cache4MapDB db;
    private long key;
    private HTreeMap nodeCacheK;
    private HTreeMap relCacheK;
    private HTreeMap idCache;
    private BTreeMap exeCqlCache;
    private RunCql runCql;
    private String server;
    private String user;
    private String password;
    private final static int MAX_SIZE = 50000000;
    //Cache 10 year
    private final static int CACHE_TIME_MINUTES = 60 * 24* 30 * 12 * 10;

    private final static String ID_CACHE_KEY = "id";
    private final static String NODE_CACHE_NAME = "node";
    private final static String REL_CACHE_NAME = "rel";
    private final static String EXEC_CACHE_NAME = "exec";
    private final static String ID_CACHE_NAME = "idCache";

    /**
     * 构造方法
     */
    Neo4jAlter(String ipAndPort, String user, String password) {
        this.server = ipAndPort;
        this.user = user;
        this.password = password;
        this.initType = -1;
    }


    void initSync() throws NSException {
        this.initType = 1;
        db = Cache4MapDB.getDB(Util.getWorkingPath(), "graph.createAsync");
        assemblyDevice = new AssemblyDevice();
        connTools = ConnectionTools.getInstance(server, user, password);
        key = Utils.toHashCode(server, user, password);
        nodeCacheK = db.getMap(NODE_CACHE_NAME, MAX_SIZE, CACHE_TIME_MINUTES);
        relCacheK = db.getMap(REL_CACHE_NAME, MAX_SIZE, CACHE_TIME_MINUTES);
    }

    void initAsync() throws NSException {
        this.initType = 2;
        db = Cache4MapDB.getDB(Util.getWorkingPath(), "graph.createAsync");
        assemblyDevice = new AssemblyDevice();
        connTools = ConnectionTools.getInstance(server, user, password);
        key = Utils.toHashCode(server, user, password);
        nodeCacheK = db.getMap(NODE_CACHE_NAME, MAX_SIZE, CACHE_TIME_MINUTES);
        relCacheK = db.getMap(REL_CACHE_NAME, MAX_SIZE, CACHE_TIME_MINUTES);
        exeCqlCache = db.getTreeMap(EXEC_CACHE_NAME, 100000);
        idCache = db.getMap(ID_CACHE_NAME, 1, CACHE_TIME_MINUTES);

        long id = setId(ID_CACHE_KEY, 0L);
        LOGGER.debug(String.format("Set createAsync cql id: %d ", id));

        runCql = new RunCql(connTools, db, EXEC_CACHE_NAME);
        Thread thread = new Thread(runCql);
        thread.start();
        LOGGER.info("Sender is start: " + runCql.isRun());
    }

    void initOnlyQuery() throws NSException {
        this.initType = 3;
        assemblyDevice = new AssemblyDevice();
        connTools = ConnectionTools.getInstance(server, user, password);
    }

    @Override
    public void create(List<CreateBuilder> createBuilders) throws NSException {
        switch (this.initType) {
            case -1: throw new NSException("No init. You must call init... method.");
            case 1: createSync(createBuilders);
            break;
            case 2: createAsync(createBuilders);
            break;
            case 3: throw new NSException("You initOnlyQuery, but call create.");
            default: throw  new NSException(String.format("Unknown error. initType: %d ", initType));
        }
    }

    /**
     * Create node
     * @param nodes Node list
     * @throws SQLException Sql exception
     */
    private void createNodes(List<INode> nodes) throws SQLException{
        Connection connection = null;
        PreparedStatement statement = null;
        try {
            connection = connTools.getConn();
            LOGGER.info(String.format("Create node get connection -> %s", connection));
            statement = connection.prepareStatement(assemblyDevice.createNodesCql(nodes));
            statement.execute();
        } catch (SQLException e){
            LOGGER.error(e);
            throw e;
        } finally {
            if(statement != null) statement.close();
            connTools.release(connection);
        }
    }

    /**
     * Create getRelationship
     * @param rels Relationship list
     * @throws SQLException Sql exception
     */
    private void createRels(List<Relationship> rels) throws SQLException{
        Connection connection = null;
        PreparedStatement statement = null;
        try {
            connection = connTools.getConn();
            LOGGER.info(String.format("Create relationship get connection -> %s", connection));
            Relationship rel = rels.get(0);
            statement = connection.prepareStatement(
                    assemblyDevice.createRelsCql(rel.getFromLab(), rel.getToLab(), rel.getRelName(), rels));

            statement.execute();
        } catch (SQLException e){
            LOGGER.error(e);
            throw e;
        } finally {
            if(statement != null) statement.close();
            connTools.release(connection);
        }
    }


    private void createSync(List<CreateBuilder> createBuilders) throws NSException {
        if(nodeCacheK == null || relCacheK == null) {
            LOGGER.error("No init nodeCheck or relCheck, check you code must call initSync.");
            throw new NSException("No init nodeCheck or relCheck, check you code must call initSync.");
        }
        try {
            Tuple2<List<INode>, List<Relationship>> nr = dis(createBuilders);

            for(Map.Entry<Integer, List<INode>> reduceNode: nodeReduce(nr.getA()).entrySet()) {
                createNodes(reduceNode.getValue());
            }

            for(Map.Entry<Integer, List<Relationship>> reduceRel: relReduce(nr.getB()).entrySet()) {
                createRels(reduceRel.getValue());
            }
        } catch (SQLException | IOException e) {
            throw new NSException(e);
        }

    }

    private synchronized void createAsync(List<CreateBuilder> createBuilders) throws NSException {
        if(exeCqlCache == null || idCache == null) {
            LOGGER.error("No init exeCqlCache or idCache, check you code must call initAsync.");
            throw new NSException("No init exeCqlCache or idCache, check you code must call initAsync.");
        }
        try {
            long insertCount = (long) idCache.get(ID_CACHE_KEY);
            LOGGER.debug(String.format("Get id as map db: %d ", insertCount));
            Tuple2<List<INode>, List<Relationship>> nr = dis(createBuilders);
            for(Map.Entry<Integer, List<INode>> reduceNode: nodeReduce(nr.getA()).entrySet()) {
                String cql = assemblyDevice.createNodesCql(reduceNode.getValue());
                exeCqlCache.put(insertCount, cql);
                insertCount++;
            }
            idCache.put(ID_CACHE_KEY, insertCount);
            for(Map.Entry<Integer, List<Relationship>> reduceRel: relReduce(nr.getB()).entrySet()) {
                Relationship rel = reduceRel.getValue().get(0);
                String cql = assemblyDevice.createRelsCql(rel.getFromLab(), rel.getToLab(), rel.getRelName(), reduceRel.getValue());
                exeCqlCache.put(insertCount, cql);
                insertCount++;
            }
            idCache.put(ID_CACHE_KEY, insertCount);
        } catch (IOException e) {
            throw new NSException(e);
        }
    }


    /**
     * Distinct method
     * @param createBuilders CreateBuilder list
     * @return Tuple2
     * @throws IOException IOException
     */
    private Tuple2<List<INode>, List<Relationship>> dis(List<CreateBuilder> createBuilders) throws IOException{
        List<INode> nodes = new ArrayList<>();
        List<Relationship> rels = new ArrayList<>();
        for(CreateBuilder builder: createBuilders) {
            long fromNodeK = getNodeK(builder.getFromNode());
            if(!nodeCacheK.containsKey(fromNodeK)) {
                nodeCacheK.put(fromNodeK, 1);
                nodes.add(builder.getFromNode());
            }
            long toNodeK = getNodeK(builder.getToNode());
            if(!nodeCacheK.containsKey(toNodeK)) {
                nodeCacheK.put(toNodeK, 1);
                nodes.add(builder.getToNode());
            }
            long relK = getRelK(builder.getRelationship());
            if(!relCacheK.containsKey(relK)) {
                relCacheK.put(relK, 1);
                rels.add(builder.getRelationship());
            }
        }
        return new Tuple2<>(nodes, rels);
    }


    @Override
    public List<Map<String, Object>> query(String nodeId) throws NSException {
        List<IQueryRow> rows = query(nodeId, 1);
        List<Map<String, Object>> r = new ArrayList<>();
        for(IQueryRow row: rows) {
            r.add(row.getOneRelNode());
        }
        return r;
    }

    @Override
    public List<Map<String, Object>> query(String nodeId, String type) throws NSException {
        List<IQueryRow> rows = query(nodeId, 1, type);
        List<Map<String, Object>> r = new ArrayList<>();
        for(IQueryRow row: rows) {
            r.add(row.getOneRelNode());
        }
        return r;
    }

    @Override
    public List<IQueryRow> query(String nodeId, int layer) throws NSException {
        QueryBuilder queryBuilder = new QueryBuilder(nodeId, "", "", "", "", layer, RelDirect.POSITIVE);
        return query(queryBuilder);
    }

    @Override
    public List<IQueryRow> query(String nodeId, int layer, String nodeType) throws NSException {
        QueryBuilder queryBuilder = new QueryBuilder(nodeId, nodeType, "", "", "", layer, RelDirect.POSITIVE);
        return query(queryBuilder);
    }

    @Override
    public List<IQueryRow> query(String nodeId, int layer, String nodeType, String startLabel, String toLabel) throws NSException {
        QueryBuilder queryBuilder = new QueryBuilder(nodeId, nodeType, "", startLabel, toLabel, layer, RelDirect.POSITIVE);
        return query(queryBuilder);
    }

    @Override
    public List<IQueryRow> query(QueryBuilder queryBuilder) throws NSException {
        if(connTools == null || assemblyDevice == null) {
            LOGGER.error("No init connTools or assemblyDevice, check you code must call init... method." +
                    "If you only run query(), just call initOnlyQuery, else call initSync or initAsync.");
            throw new NSException("No init connTools or assemblyDevice, check you code must call init... method." +
                    "If you only run query(), just call initOnlyQuery, else call initSync or initAsync.");
        }
        Connection connection = null;
        PreparedStatement statement = null;
        List<IQueryRow> rows;
        try {
            try {
                connection = connTools.getConn();
                Tuple2<String, List<String>> tuple2 = assemblyDevice.createQueryCql(queryBuilder);
                statement = connection.prepareStatement(tuple2.getA());

                rows = assemblyDevice.result2List(statement.executeQuery(), tuple2.getB());
            } finally {
                if(statement != null) statement.close();
                connTools.release(connection);
            }
        } catch (SQLException e) {
            LOGGER.error(e);
            throw new NSException(e);
        }

        return rows;
    }

    @Override
    public List<Map<String, Object>> polymerizationQuery(List<VirtualID> ids) throws NSException {
        if(ids == null || ids.isEmpty()) {
            throw new NSException("ids is null or empty");
        }

        List<Map<String, Object>> nodes = new ArrayList<>();
        for(VirtualID id: ids) {
            try{
                nodes.addAll(query(id.getId(), id.getType()));
            } catch (Exception e) {
                LOGGER.error(e);
            }
        }

        return nodes;
    }

    @Override
    public void shutdown() {
        LOGGER.info("Shutdown neo4jAlter...");
        if(this.runCql != null) this.runCql.stop();
        if(connTools != null) connTools.shutdown(key);
        if (db != null) db.shutdown();
    }


    /**
     * Reduce method
     * @param rels Relationship list
     * @return Map
     */
    private Map<Integer, List<Relationship>> relReduce(List<Relationship> rels) {
        Map<Integer, List<Relationship>> r = new TreeMap<>();
        for(Relationship rel: rels) {
            StringBuilder k = new StringBuilder(rel.getFromLab() + rel.getToLab() + rel.getRelName());
            for(Map.Entry<String, String> atts: rel.getAtts().entrySet()) {
                k.append(atts.getKey());
            }
            if(r.get(k.toString().hashCode()) == null) {
                List<Relationship> relList = new ArrayList<>();
                relList.add(rel);
                r.put(k.toString().hashCode(), relList);
            } else {
                r.get(k.toString().hashCode()).add(rel);
            }
        }

        return r;
    }

    /**
     * Reduce method
     * @param nodes Node list
     * @return Map
     */
    private Map<Integer, List<INode>> nodeReduce(List<INode> nodes) {
        Map<Integer, List<INode>> r = new TreeMap<>();
        for(INode node: nodes) {
            StringBuilder k = new StringBuilder();
            for(String lb: node.getLbs()) {
                k.append(lb);
            }
            if(r.get(k.toString().hashCode()) == null){
                List<INode> relList = new ArrayList<>();
                relList.add(node);
                r.put(k.toString().hashCode(), relList);
            } else {
                r.get(k.toString().hashCode()).add(node);
            }
        }

        return r;
    }

    /**
     * Get node hashcode count => k
     * @param node INode
     * @return k
     */
    private long getNodeK(INode node) {
        StringBuilder sb = new StringBuilder();
        for(String l: node.getLbs()) {
            sb.append(l);
        }

        for (Map.Entry<String, String> m: node.getAtts().entrySet()){
            sb.append(m.getKey()).append(m.getValue());
        }

        sb.append(node.getId());
        return sb.toString().hashCode();
    }

    /**
     * Get relationship hashcode count => k
     * @param rel Relationship
     * @return k
     */
    private long getRelK(Relationship rel) {
        StringBuilder sb = new StringBuilder();

        for (Map.Entry<String, String> m: rel.getAtts().entrySet()){
            sb.append(m.getKey()).append(m.getValue());
        }

        sb.append(String.format("%s%s%s%s%s", rel.getRelName(), rel.getFromId(), rel.getToId(), rel.getFromLab(), rel.getToLab()));

        return sb.toString().hashCode();
    }

    /**
     * Set cql id
     * @param key Cache id key
     * @param id Id
     * @return Id
     */
    private long setId(String key, long id) {
        Object cacheId = idCache.get(key);
        if(cacheId == null || (long)cacheId > 10000000000L) {
            idCache.put(key, id);
        }
        return (long)idCache.get(key);
    }

}
