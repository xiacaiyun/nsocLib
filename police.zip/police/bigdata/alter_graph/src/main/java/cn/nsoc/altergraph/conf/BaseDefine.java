package cn.nsoc.altergraph.conf;

public class BaseDefine {
    public static final String NEO4J = "neo4j";

    public static final String NODE_TYPE_NAME = "type";
    public static final String NODE_TAG_NAME = "tag";
    public static final String NODE_GROUP_LAB = "group";
    public static final String NODE_USER_LAB = "user";


    public static final String QQ_NODE_TYPE = "qq";
    public static final String WEIXIN_NODE_TYPE = "wx";
    public static final String EMAIL_NODE_TYPE = "mail";

    public static final String MAP_TYPE_NAME = "virtype";
    public static final String MAP_ID_NAME = "virval";

}
