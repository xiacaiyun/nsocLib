package cn.nsoc.altergraph.tools;

import java.util.Hashtable;
import java.util.Map;

public class CacheData {
    private volatile static Map<String, CacheData> catchDatas = new Hashtable();
    private Map<Long, Integer> cache1;
    private Map<Long, Integer> cache2;
    private Map<Long, Integer> cache3;
    private static final int V = 1;

    private CacheData() {
        cache1 = new Hashtable<>(5000);
        cache2 = new Hashtable<>(5000);
        cache3 = new Hashtable<>(5000);
    }

    public static CacheData getCatchData(String name) {
        if(!catchDatas.containsKey(name)) {
            synchronized (CacheData.class){
                if (!catchDatas.containsKey(name)){
                    catchDatas.put(name, new CacheData());
                }
            }
        }
        return catchDatas.get(name);
    }

    public boolean isExists(long k){
        if(cache1.containsKey(k) || cache2.containsKey(k) || cache3.containsKey(k)) {
            return true;
        } else {
            put(k);
            return false;
        }
    }

    private void put(long k) {
        int max = 10000;
        if(cache1.size() >= max) {
            if(cache2.size() >= max) {
                if(cache3.size() >= max){
                    cache1.clear();
                } else {
                    cache3.put(k, V);
                }
            } else {
                cache2.put(k, V);
                if(cache3.size() >= max && cache2.size() == max - V) {
                    cache3.clear();
                }
            }
        } else {
            cache1.put(k, V);
            if(cache2.size() >= max && cache3.size() >= max && cache1.size() == max - V) {
                cache2.clear();
            }
        }
    }
}
