package cn.nsoc.altergraph.alter;

import java.util.Map;

/**
 * Nodes relationships.
 * Create by Alan 2017.10.16
 */
class Relationship {
    private String relName;
    private String fromId;
    private String toId;
    private String fromLab;
    private String toLab;
    private Map<String, String> atts;


    /**
     * Get getRelationship name
     * @return getRelationship name
     */
    String getRelName(){
        return this.relName;
    }

    /**
     * Get getRelationship from id
     * @return from id
     */
    String getFromId(){
        return this.fromId;
    }

    /**
     * Get getRelationship to id
     * @return to id
     */
    String getToId(){
        return this.toId;
    }

    /**
     * Get getRelationship from label
     * @return from label
     */
    String getFromLab(){
        return this.fromLab;
    }

    /**
     * Get getRelationship to label
     * @return to label
     */
    String getToLab(){
        return this.toLab;
    }

    /**
     * Get getRelationship attributes
     * @return getRelationship attributes
     */
    Map<String, String> getAtts(){
        return this.atts;
    }

    Relationship setAtts(Map<String, String> atts) {
        this.atts = atts;
        return this;
    }

    Relationship setFromId(String fromId) {
        this.fromId = fromId;
        return this;
    }

    Relationship setFromLab(String fromLab) {
        this.fromLab = fromLab;
        return this;
    }

    Relationship setRelName(String relName) {
        this.relName = relName;
        return this;
    }

    Relationship setToId(String toId) {
        this.toId = toId;
        return this;
    }

    Relationship setToLab(String toLab) {
        this.toLab = toLab;
        return this;
    }

}
