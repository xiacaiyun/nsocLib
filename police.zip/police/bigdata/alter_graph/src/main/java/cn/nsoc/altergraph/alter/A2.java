package cn.nsoc.altergraph.alter;

import java.util.ArrayList;
import java.util.List;

/**
 * Query condition set
 * A to B: start - relationship - to - relationship - to - ... - to
 * Create by Alan 2017.10.26
 */
public class A2{
    public static R start(String label) {
        return new R(label);
    }

    public static class B{
        String fromLab;
        List<String> rel;
        String toLab;
        B(String from, List<String> relationship) {
            fromLab = from;
            rel = relationship;
        }

        public B to(String label) {
            toLab = label;
            return this;
        }

        String getFromLab() {
            return fromLab;
        }

        List<String> getRel() {
            return rel;
        }

        String getToLab() {
            return toLab;
        }
    }

    public static class R{
        String lab;
        List<String> rel;
        R(String label) {
            lab = label;
            rel = new ArrayList<>();
        }

        public R addRel(String rel){
            this.rel.add(rel);
            return this;
        }

        public B  endRel() {
            if(rel.size() == 0) throw new NullPointerException("Must run addRel as endRel before");
            return new B(lab, rel);
        }

    }
}
