package cn.nsoc.altergraph.tools;

import cn.nsoc.base.entity.sys.NSException;
import com.zaxxer.hikari.HikariDataSource;

import java.beans.PropertyVetoException;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.Map;

/**
 * C3P0 connection pool build.
 * Create by Alan 2017.09.26
 */
public class ConnectionTools {
    private volatile HikariDataSource dataSource = null;
    private static volatile Map<Long, ConnectionTools> instances = new HashMap<>();

    private ConnectionTools(String ip, String user, String password) throws PropertyVetoException {

        dataSource = new HikariDataSource();
        dataSource.setDriverClassName("org.neo4j.jdbc.Driver");
        dataSource.setJdbcUrl(String.format("jdbc:neo4j:http://%s", ip));
        dataSource.setUsername(user);
        dataSource.setPassword(password);
        dataSource.setConnectionTimeout(600000);
        dataSource.setMinimumIdle(3);
        dataSource.setMaximumPoolSize(20);
    }

    public static synchronized ConnectionTools getInstance(String ip, String user, String password) throws NSException {
        if(ip == null || user == null || password == null ||
                ip.length() == 0 || user.length() == 0 || password.length() == 0)
            throw new NullPointerException("You ip or user or password is null or is \"\"");

        long k = Utils.toHashCode(ip, user, password);
        if(instances.get(k) == null) {
            synchronized (ConnectionTools.class) {
                if(instances.get(k) == null) {
                    try {
                        instances.put(k, new ConnectionTools(ip, user, password));
                    } catch (PropertyVetoException e) {
                        throw new NSException(e);
                    }
                }
            }
        }
        return instances.get(k);
    }


    /**
     * Get connection
     * @return Databases connection.
     * @throws SQLException sql异常
     */
    public Connection getConn() throws SQLException {
        return dataSource.getConnection();
    }

    /**
     * Release connection
     * @param connection Connection
     * @throws SQLException Sql exception
     */
    public void release(Connection connection) throws SQLException {
        if(connection != null) connection.close();
    }

    public synchronized void shutdown(long k) {
        ConnectionTools connTool = instances.get(k);
        if(connTool != null && connTool.dataSource != null) {
            connTool.dataSource.close();
            instances.remove(k);
        }
    }
}
