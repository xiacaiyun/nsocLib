package cn.nsoc.altergraph.test;

import cn.nsoc.altergraph.alter.A2;
import cn.nsoc.altergraph.alter.CreateBuilder;
import cn.nsoc.altergraph.alter.QueryBuilder;
import cn.nsoc.altergraph.conf.BaseDefine;
import cn.nsoc.altergraph.conf.RelDirect;
import cn.nsoc.altergraph.alter.GraphBaseFactory;
import cn.nsoc.altergraph.i.IBaseAlter;
import cn.nsoc.altergraph.i.IQueryRow;
import cn.nsoc.altergraph.tools.Utils;
import cn.nsoc.base.entity.sys.NSException;
import junit.framework.TestCase;

import java.nio.file.Paths;
import java.util.*;

public class SyncTest extends TestCase {
    private IBaseAlter baseAlter;

    public void setUp() throws Exception {
        super.setUp();
        baseAlter = GraphBaseFactory.getBaseAlter(BaseDefine.NEO4J, "192.168.1.123:7474", "neo4j", "admin", true, false);
    }

    public void testCreate() throws NSException {
       List<CreateBuilder> builders = new ArrayList<>();
       for(int count =5001; count < 5002; count += 1) {
           builders.add(new CreateBuilder(new QQNode("qq" + count, BaseDefine.NODE_USER_LAB),
                   new QQNode("group" + (count + 1), BaseDefine.NODE_GROUP_LAB),
                   new Rel("belong_to").addAtt("create", "Master")));
           if(count % 500 == 0) {
               baseAlter.create(new ArrayList<>(builders));
               builders.clear();
           }
       }
        baseAlter.create(new ArrayList<>(builders));
    }

    public void testCreate1() throws NSException {
        List<CreateBuilder> builders = new ArrayList<>();
        builders.add(new CreateBuilder(new QQNode("qq00111", "user"),
                new QQNode("qq0012351", "user"),
                new Rel("friend")));
        builders.add(new CreateBuilder(new QQNode("qq0012354", "user"),
                new QQNode("qq0012358", "user"),
                new Rel("friend")));
        baseAlter.create(new ArrayList<>(builders));
    }



    public void testQuery() {
        try {
            List<IQueryRow> rows = baseAlter.query(new QueryBuilder("qq5","qq", RelDirect.POSITIVE,
                    A2.start("user").addRel("").endRel().to("group")));
            for(IQueryRow row: rows) {
                System.out.println("----------------");
                //row 完整的一行
                // getItems():返回节点List 带有起始节点 结构为: list第一个元素为起始节点,第二个元素为连接到的节点
                for(Map<String, Object> m: row.getItems()) {
                    for(Map.Entry<String, Object> entry: m.entrySet()) {
                        System.out.println(entry.getKey() + "  " + entry.getValue());
                    }
                }

                // getOneRelNode():返回 返回和起始节点只有一层关系的节点
                Map<String, Object> m = row.getOneRelNode();
                for(Map.Entry<String, Object> entry: m.entrySet()) {
                    System.out.println(entry.getKey() + "  " + entry.getValue());
                }

                System.out.println("----------------");
                System.out.println();
            }

        } catch (NSException e) {
            e.printStackTrace();
        }

    }

    public void testQuery1() throws NSException {
        String server = "192.168.1.123:7474";
        String userName = "neo4j";
        String password = "admin";
        IBaseAlter baseAlter = GraphBaseFactory.getBaseAlter(BaseDefine.NEO4J, server, userName, password, true, true);
        try {
            //传入节点ID 返回所有和该ID有一层关系的所有节点
            //Map<String, Object>: Map<节点属性名, 节点属性值>
            List<Map<String, Object>> nodes = baseAlter.query("3094544049");
            for(Map<String, Object> node: nodes) {
                for(Map.Entry<String, Object> entry: node.entrySet()) {
                    System.out.println("AttributeName:" + entry.getKey() + "  Value" + entry.getValue());
                }
            }
        } catch (NSException e) {
            e.printStackTrace();
        }

    }

    public void testDefault() {
        IBaseAlter baseAlter = GraphBaseFactory.getDefaultBaseAlter();
        try {
            baseAlter.create(null);
        } catch (NSException e) {
            e.printStackTrace();
        }
    }

    public void testHashCode() {
//        System.out.println(Paths.get(Util.getWorkingPath(), "graph.createAsync").toString());
        System.out.println(Paths.get("/home/kyle/Work/pr", "lib.zip").toString());
        System.out.println(Utils.toHashCode("1200wer", "2333", 12) + " " + Utils.toHashCode("1200wer", "2333", 12));
    }

}

