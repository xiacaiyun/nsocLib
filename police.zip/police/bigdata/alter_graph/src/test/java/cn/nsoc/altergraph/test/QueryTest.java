package cn.nsoc.altergraph.test;

import cn.nsoc.altergraph.alter.GraphBaseFactory;
import cn.nsoc.altergraph.alter.VirtualID;
import cn.nsoc.altergraph.i.IBaseAlter;
import cn.nsoc.altergraph.i.IQueryRow;
import cn.nsoc.base.entity.sys.NSException;
import junit.framework.TestCase;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

public class QueryTest extends TestCase {
    private IBaseAlter baseAlter;

    public void setUp() throws Exception {
        super.setUp();
        baseAlter = GraphBaseFactory.getBaseAlterIsOnlyQuery("neo4j",
                "192.168.1.123:7474", "neo4j", "admin");
    }

    public void testQueryById() throws NSException {
        List<Map<String, Object>> nodes = baseAlter.query("694904293");
        showNodes(nodes);
    }

    public void testQueryByIdAndLayer() throws NSException {
        List<IQueryRow> rows = baseAlter.query("1412357109", 2);
        showRows(rows);
    }

    public void testQueryByIdLayerAndType() throws NSException {
        List<IQueryRow> rows = baseAlter.query("1412357109", 2, "1001");
        showRows(rows);
    }

    public void testQueryByIdLayerTypeStartLabAndEndLab() throws NSException {
        List<IQueryRow> rows = baseAlter.query("", 1, "1001", "single", "group");
        showRows(rows);
    }

    public void testPolymerizationQuery() throws NSException {
        List<VirtualID> ids = new ArrayList<>();
        ids.add(new VirtualID("1412357109", "1001"));
        ids.add(new VirtualID("694904293", "1001"));

        List<Map<String, Object>> nodes = baseAlter.polymerizationQuery(ids);
        showNodes(nodes);
    }

    private void showNodes(List<Map<String, Object>> nodes) {
        for(Map<String, Object> node: nodes) {
            for(Map.Entry<String, Object> entry: node.entrySet()) {
                System.out.println(String.format("%s  %s", entry.getKey(), entry.getValue()));
            }
        }
    }

    private void showRows(List<IQueryRow> rows) {
        for(IQueryRow row: rows) {
            List<Map<String, Object>> nodes = row.getItems();
            for(Map<String, Object> node: nodes) {
                for(Map.Entry<String, Object> entry: node.entrySet()) {
                    System.out.println(String.format("%s  %s", entry.getKey(), entry.getValue()));
                }
            }
            System.out.println("----------------------");
        }
    }

}
