package cn.nsoc.altergraph.test;

import cn.nsoc.altergraph.alter.CreateBuilder;
import cn.nsoc.altergraph.conf.BaseDefine;
import cn.nsoc.altergraph.alter.GraphBaseFactory;
import cn.nsoc.altergraph.i.IBaseAlter;
import cn.nsoc.base.entity.sys.NSException;

import java.util.ArrayList;
import java.util.List;

public class AsyncTest {
    public static void main(String... args) throws NSException, InterruptedException {
        IBaseAlter baseAlter = GraphBaseFactory.getBaseAlter(BaseDefine.NEO4J, "192.168.1.123", "neo4j", "admin", false, false);
        List<CreateBuilder> builders = new ArrayList<>();
        for(int count = 5001; count < 5300; count += 1) {
            builders.add(new CreateBuilder(new QQNode("qq" + count, BaseDefine.NODE_USER_LAB),
                    new QQNode("group" + (count + 1), BaseDefine.NODE_GROUP_LAB),
                    new Rel("belong_to").addAtt("create",  "alan")));
            if(count % 500 == 0) {
                baseAlter.create(new ArrayList<>(builders));
                builders.clear();
            }
        }
        baseAlter.create(new ArrayList<>(builders));
    }
}
