package cn.nsoc.altergraph.test;

import cn.nsoc.altergraph.i.IRel;

import java.util.HashMap;
import java.util.Map;

public class Rel implements IRel {
    private String relName;
    Map<String, String> map = new HashMap<>();

    public Rel(String relName) {
        this.relName = relName;
    }

    @Override
    public String getRelName() {
        return relName;
    }


    @Override
    public Map<String, String> getAtts() {
        return map;
    }

    public Rel addAtt(String k, String v) {
        map.put(k, v);
        return this;
    }
}
