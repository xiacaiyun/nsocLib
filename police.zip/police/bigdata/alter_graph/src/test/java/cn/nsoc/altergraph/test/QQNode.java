package cn.nsoc.altergraph.test;

import cn.nsoc.altergraph.conf.BaseDefine;
import cn.nsoc.altergraph.i.INode;

import java.util.HashMap;
import java.util.Map;

/**
 * qq node implements
 * Create by Alan 2017.10.26
 */
public class QQNode implements INode{
    //group or user
    private String lab;
    //group id or user id
    private String id;
    //QQNode attribute example: type->qq number->1367890987
    private Map<String, String> atts = new HashMap<>();

    public QQNode(String id, String lab) {
        this.id = id;
        this.lab = lab;
        //qq node default attribute type->qq
        atts.put(BaseDefine.NODE_TYPE_NAME, BaseDefine.QQ_NODE_TYPE);
        atts.put(BaseDefine.NODE_TAG_NAME, lab);
    }

    @Override
    public String getId() {
        return this.id;
    }

    @Override
    public String[] getLbs() {
        return new String[]{lab};
    }

    @Override
    public Map<String, String> getAtts() {
        return this.atts;
    }

    /**
     * Add qq node attribute
     * @param attName Attribute name
     * @param attValue Attribute value
     */
    public void addAtt(String attName, String attValue) {
        atts.put(attName, attValue);
    }
}
