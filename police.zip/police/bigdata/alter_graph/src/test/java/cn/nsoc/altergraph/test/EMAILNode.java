package cn.nsoc.altergraph.test;

import cn.nsoc.altergraph.conf.BaseDefine;
import cn.nsoc.altergraph.i.INode;

import java.util.HashMap;
import java.util.Map;

public class EMAILNode implements INode {
    //user
    private static final String lab = BaseDefine.NODE_USER_LAB;
    //group id or user id
    private String id;
    //QQNode attribute example: type->email address->13456789@qq.com
    private Map<String, String> atts = new HashMap<>();

    public EMAILNode(String id) {
        this.id = id;
        //qq node default attribute type->qq
        atts.put(BaseDefine.NODE_TYPE_NAME, BaseDefine.QQ_NODE_TYPE);
    }

    @Override
    public String getId() {
        return this.id;
    }

    @Override
    public String[] getLbs() {
        return new String[]{lab};
    }

    @Override
    public Map<String, String> getAtts() {
        return this.atts;
    }

    /**
     * Add Email node attribute
     * @param attName Attribute name
     * @param attValue Attribute value
     */
    public void addAtt(String attName, String attValue) {
        atts.put(attName, attValue);
    }
}
