package cn.nsoc.altergraph.test;

import cn.nsoc.altergraph.tools.Cache4MapDB;
import org.mapdb.HTreeMap;

public class Cache4MapDBTest {
    public static void main(String... args) throws InterruptedException {
//        HTreeMap mapDB = Cache4MapDB.getMap("test", 1000, 100);
//
//        for(int index = 0; index < 10; index ++) {
//            mapDB.put(index, index);
//            Thread.sleep(1000);
//        }

//        DB db = DBMaker
//                .fileDB("/var/nsoc/worker/graph.cache2")
//                .fileMmapEnable()
//                .fileMmapEnableIfSupported()
//                .fileMmapPreclearDisable()
//                .cleanerHackEnable()
//                .closeOnJvmShutdown()
//                .concurrencyScale(2)
//                .make();
//        HTreeMap map = db.get("test");
//        System.out.println(map.get(1) + " " + map.get(2) + " " + map.get(3));
//
//        Thread.sleep(10000);
//        System.out.println(mapDB.get(1) + " " + mapDB.get(2) + " " + mapDB.get(3));
//        Thread.sleep(60000);
//        System.out.println(mapDB.get(1) + " " + mapDB.get(2) + " " + mapDB.get(3));

    }
}
