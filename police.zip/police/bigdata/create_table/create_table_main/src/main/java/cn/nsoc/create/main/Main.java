package cn.nsoc.create.main;

import cn.nsoc.create.IAlterBase;
import org.apache.log4j.Logger;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;

public class Main {
    private static Logger LOGGER = Logger.getLogger(Main.class);
    public static void main(String... args) {
        LOGGER.info(String.format("Start ... args length is %s", args.length));
        if(args.length < 3) {
            System.out.println("参数不足, 请按照以下说明输入参数: ");
            System.out.println("1.创建表: ");
            System.out.println("CDH集群+Elasticsearch 请输入:ce(或classLoad.properties中配置的类名) fileSource(若要创建表,则输入建表Sql文件路径,若要增加字段,则输入字段文件路径.) ip:port");
            System.out.println("CDH集群+HBase 请输入:ch(或classLoad.properties中配置的类名) sqlFileSource ip:port");
            System.out.println("TDH集群+Elasticsearch 请输入:te(或classLoad.properties中配置的类名) sqlFileSource ip:port");
            System.out.println("TDH集群+HBase 请输入:th(或classLoad.properties中配置的类名) sqlFileSource ip:port");
            System.out.println("2.删除所有的表: ");
            System.out.println("CDH集群+Elasticsearch 请输入:ce(或classLoad.properties中配置的类名) delete ip:port");
            System.out.println("CDH集群+HBase 请输入:ch(或classLoad.properties中配置的类名) delete ip:port");
            System.out.println("TDH集群+Elasticsearch 请输入:te(或classLoad.properties中配置的类名) delete ip:port");
            System.out.println("TDH集群+HBase 请输入:th(或classLoad.properties中配置的类名) delete ip:port");
            System.exit(0);
        }

        if("delete".equals(args[1])) {
            for(IAlterBase createTable: getClass(args[0])) {
                if (createTable == null) throw new NullPointerException();
                //创建表
                createTable.deleteAllTable(args[2]);
            }
        } else {
            for(IAlterBase createTable: getClass(args[0])) {
                if (createTable == null) throw new NullPointerException();
                //创建表
                createTable.create(args[1], args[2]);
            }
        }
    }

    /**
     *  通过反射获取配置文件和加载类
     *
     * @param simpleName 配置文件中的简单名字
     * @return 创建好的对象
     */
    private static List<IAlterBase> getClass(String simpleName) {
        LOGGER.info(String.format("Simple class name %s ", simpleName));
        Properties properties;
        IAlterBase createTable;
        List<IAlterBase> list = null;
        try {
            properties = new Properties();
            properties.load(Main.class.getClassLoader().getResourceAsStream("classLoad.properties"));
            String className = properties.getProperty(simpleName);
            LOGGER.info(String.format("Full class name %s ", className));
            list = new ArrayList<>();
            for(String cn: className.split(",")) {
                Class<?> clazz = Class.forName(cn);
                createTable = (IAlterBase)clazz.newInstance();
                list.add(createTable);
            }
        } catch (IOException | ClassNotFoundException | InstantiationException | IllegalAccessException e) {
            LOGGER.error("Get properties or get class error.", e);
            e.printStackTrace();
        }
        return list;
    }

}
