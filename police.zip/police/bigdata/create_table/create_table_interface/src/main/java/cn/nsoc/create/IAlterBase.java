package cn.nsoc.create;

public interface IAlterBase {
    /**
     * 创建表
     * @param sqlSource 建表的sql数据源
     */
    void create(String sqlSource, String ipAndPort);

    /**
     * 删除全部表
     * @param ipAndPort ip 和 port
     */
    void deleteAllTable(String ipAndPort);
}
