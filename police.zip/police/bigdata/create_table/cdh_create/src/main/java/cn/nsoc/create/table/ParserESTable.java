package cn.nsoc.create.table;

import java.util.HashMap;
import java.util.Map;

/**
 * 解析es表
 * Create by Alan 2017.09.14
 */
public class ParserESTable implements ITable{
    //sql内容
    private String context;
    //带有表名的头部
    private String head;
    //带有元素的中间部分
    private String element;
    //带有分片和复制的尾部
    private String tail;
    //es中是否存在的标志
    private boolean exists = false;

    /**
     * 构造函数
     * @param context sql
     */
    public ParserESTable(String context) {
        assert context != null;
        this.context = context;
        String[] contexts = context.toLowerCase().replace("(", ")").split("\\)");
        assert contexts.length == 3;
        this.head = contexts[0];
        this.element = contexts[1];
        this.tail = contexts[2];

    }

    /**
     * 获取索引
     * @return 索引
     */
    public String getIndex() {
//        assert this.head.length() > 0;
//        return this.head.trim().split("table ")[1].split("\\.")[0];
        return getTableName();
    }

    /**
     * 获取类型
     * @return 类型
     */
    public String getType() {
        assert this.head.length() > 0;
        return this.head.trim().split("table ")[1].split("\\.")[1];
    }

    /**
     * 获取分片数量
     * @return 分片数量
     */
    public int getShards() {
        assert this.tail.length() > 22;
        return Integer.parseInt(this.tail.trim().split("shard number ")[1].split("replication")[0].trim().replace("\n", ""));
    }

    /**
     * 获取复制数量
     * @return 复制数量
     */
    public int getReplicas() {
        assert this.tail.length() > 22;
        return Integer.parseInt(this.tail.trim().split("replication ")[1].trim().replace("\n", ""));
    }

    /**
     * 获取从sql中提取出来的mapping关系,主要是字段类型
     * @return mapping
     */
    public Map<String, Map<String, String>> getElementAndMapping() {
        assert this.element.length() > 0;
        String[] elements = this.element.split(",");
        Map<String, Map<String, String>> r = new HashMap<>();
        for(String s: elements) {
            String[] kvs = s.replace("default null", "").trim().split(" ");
            Map<String, String> kv = new HashMap<>();
            //此处可以扩展,指定每个字段的mapping关系,当前只考虑字段类型,顾没有做进一步处理
            kv.put("type", kvs[kvs.length - 1]);
            r.put(kvs[0], kv);
        }

        return r;
    }

    /**
     * 获取完整的sql
     * @return sql
     */
    public String getContext() {
        return context;
    }

    /**
     * 是否存在于目标es
     * @return 存在:true 不存在:false
     */
    @Override
    public boolean isExists() {
        return exists;
    }

    /**
     * 设置存在标志
     * @param exists 存在标志
     */
    public void setExists(boolean exists) {
        this.exists = exists;
    }

    /**
     * 获取表名,此处表名和index一致
     * @return 表名
     */
    public String getTableName() {
        assert this.head.length() > 0;
        return this.head.trim().split("table ")[1];
    }

}
