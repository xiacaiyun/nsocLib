package cn.nsoc.create.es;

import cn.nsoc.create.IAlterBase;
import cn.nsoc.create.parser.CDHTableParser;
import cn.nsoc.create.parser.CreateElasticsearchTableMapping;
import cn.nsoc.create.parser.Json2MappingObject;
import cn.nsoc.create.parser.SqlTypeMapES;
import cn.nsoc.create.table.ITable;
import cn.nsoc.create.table.ParserESTable;
import org.apache.log4j.Logger;
import org.elasticsearch.action.ActionFuture;
import org.elasticsearch.action.admin.indices.create.CreateIndexRequestBuilder;
import org.elasticsearch.action.admin.indices.mapping.put.PutMappingRequest;
import org.elasticsearch.action.admin.indices.mapping.put.PutMappingRequestBuilder;
import org.elasticsearch.action.admin.indices.mapping.put.PutMappingResponse;
import org.elasticsearch.action.admin.indices.stats.IndicesStatsRequest;
import org.elasticsearch.action.admin.indices.stats.IndicesStatsResponse;
import org.elasticsearch.client.Requests;
import org.elasticsearch.client.transport.TransportClient;
import org.elasticsearch.common.settings.Settings;
import org.elasticsearch.common.transport.InetSocketTransportAddress;
import org.elasticsearch.common.xcontent.XContentBuilder;
import org.elasticsearch.common.xcontent.XContentFactory;
import org.elasticsearch.transport.client.PreBuiltTransportClient;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.InetAddress;
import java.net.UnknownHostException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 * CDH创建ES索引实现
 * Create by Alan 2017.09.12
 */
public class AlterTable2ElasticsearchAsCDH implements IAlterBase {
    private static Logger LOGGER = Logger.getLogger("AlterTable2ElasticsearchAsCDH");
    private String elasticsearchName;
    private String esType;

    public AlterTable2ElasticsearchAsCDH() {}

    /**
     *建表
     * @param sqlSource 建表的sql数据源
     * @param ipAndPort ip 和 port
     */
    @Override
    public void create(String sqlSource, String ipAndPort) {
        System.out.println("正在连接CHD-Elasticsearch...");

        BufferedReader br = null;
        TransportClient client = null;
        try {
            br = new BufferedReader(new InputStreamReader(System.in));
            System.out.println("请输入Elasticsearch集群名:");
            this.elasticsearchName = br.readLine();
            System.out.println("请选择操作类型, 创建表请输入1, 增加字段请输入2:");
            String op = br.readLine();
            if("1".equals(op.trim())) { //创建表
                System.out.println("设置Elasticsearch type(使用默认值则直接回车):");
                this.esType = br.readLine();
                System.out.println("请输入映射文件路径(此文件用于规定字段类型,字段是否能被搜索,分词器设置等等,若使用默认设置,则直接回车.):");
                String mappingFile = br.readLine();
                boolean isDefault = true;

                CDHTableParser parser = new CDHTableParser();
                LOGGER.info("Create CDHTableParser success.");
                List<ITable> tables = parser.getTables("es", sqlSource);
                LOGGER.info(String.format("Get tables success. Table number: %s", tables.size()));

                //获取所有索引列表
                Settings settings = Settings.builder()
                        .put("cluster.name", this.elasticsearchName)
                        .build();
                client = new PreBuiltTransportClient(settings).addTransportAddresses(inetSocketTransportAddress(ipAndPort));
                ActionFuture<IndicesStatsResponse> isr = client.admin().indices().stats(new IndicesStatsRequest().all());
                Set<String> set = isr.actionGet().getIndices().keySet();
                ITable[] iTables = getSortTables(tables, set);

                //是否输入了mapping路径
                Json2MappingObject json2MappingObject = null;
                if(mappingFile != null && mappingFile.trim().length() > 0) {
                    json2MappingObject = new Json2MappingObject(mappingFile);
                    isDefault = false;
                }

                //遍历表
                for(ITable table: iTables) {
                    ParserESTable parserESTable = (ParserESTable) table;
                    boolean isSuccess;
                    //在es中是否存在此表
                    if(parserESTable.isExists()) {
                        System.out.println(String.format("%s 表在Elasticsearch中已经存在, 是否覆盖? 输入 y 表示覆盖,否则不覆盖.", parserESTable.getTableName()));
                        String ow = br.readLine();
                        //若存在,是否覆盖
                        if("y".equals(ow.toLowerCase())) {
                            //是否有映射文件,映射文件中是否有此表
                            if(json2MappingObject != null && json2MappingObject.getMappingObjects().get(((ParserESTable) table).getIndex()) != null) {
                                //通过index拿到mapping对象
                                CreateElasticsearchTableMapping mappingObject = json2MappingObject.getMappingObjects().get(((ParserESTable) table).getIndex());
                                //建表
                                isSuccess =  create(parserESTable, client, parserESTable.getShards(), parserESTable.getReplicas(), mappingObject.getNameTypeValues());
                            } else {
                                //是否输入了映射文件路径
                                if(isDefault) {
                                    //未输入, 直接创建
                                    isSuccess =  create(parserESTable, client, parserESTable.getShards(), parserESTable.getReplicas(), parserESTable.getElementAndMapping());
                                } else {
                                    //输入了配置文件,但是映射文件中没有此表,则提示,让使用者确定是否创建
                                    System.out.println(String.format("%s 表在映射文件中未找到, 是否继续创建索引? 若要继续创建, 请输入y, 否则按任意键.", parserESTable.getTableName()));
                                    if("y".equals(br.readLine().trim().toLowerCase())) {
                                        //输入y,直接创建
                                        isSuccess =  create(parserESTable, client, parserESTable.getShards(), parserESTable.getReplicas(), parserESTable.getElementAndMapping());
                                    } else {
                                        //其他按键,不创建
                                        isSuccess = false;
                                        System.out.println(String.format("%s 将不进行创建, 因为映射文件中不存在,并且选择了不继续创建.", parserESTable.getTableName()));
                                    }
                                }
                            }
                        } else {
                            System.out.println(String.format("%s 将不进行创建, 因为Elasticsearch中已经存在,并且选择了不覆盖.", parserESTable.getTableName()));
                            isSuccess = false;
                        }
                    } else {
                        //判断映射文件中是否存在此表
                        if(json2MappingObject != null && json2MappingObject.getMappingObjects().get(((ParserESTable) table).getIndex()) != null) {
                            CreateElasticsearchTableMapping mappingObject = json2MappingObject.getMappingObjects().get(((ParserESTable) table).getIndex());
                            isSuccess =  create(parserESTable, client, parserESTable.getShards(), parserESTable.getReplicas(), mappingObject.getNameTypeValues());
                        } else {
                            if(isDefault) {
                                isSuccess =  create(parserESTable, client, parserESTable.getShards(), parserESTable.getReplicas(), parserESTable.getElementAndMapping());
                            } else {
                                System.out.println(String.format("%s 表在映射文件中未找到, 是否继续创建索引? 若要继续创建, 请输入y, 否则按任意键.", parserESTable.getTableName()));
                                if("y".equals(br.readLine().trim().toLowerCase())) {
                                    isSuccess =  create(parserESTable, client, parserESTable.getShards(), parserESTable.getReplicas(), parserESTable.getElementAndMapping());
                                } else {
                                    isSuccess = false;
                                    System.out.println(String.format("%s 将不进行创建, 因为映射文件中不存在,并且选择了不继续创建此表.", parserESTable.getTableName()));
                                }
                            }
                        }
                    }

                    LOGGER.info(String.format("Create table %s success: %s", table.getTableName(), isSuccess));
                }
                System.out.println("成功!");
            } else if("2".equals(op.trim())) { //增加字段
                //获取所有索引列表
                Settings settings = Settings.builder()
                        .put("cluster.name", this.elasticsearchName)
                        .build();
                client = new PreBuiltTransportClient(settings).addTransportAddresses(inetSocketTransportAddress(ipAndPort));
                addMapping(sqlSource, client);
            } else {
                System.out.println("未知输入.");
                System.exit(1);
            }

        } catch (IOException e) {
            LOGGER.error(e);
            e.printStackTrace();
        } finally {
            close(br, client);
        }

    }

    /**
     * 删除es中的所有表
     * @param ipAndPort ip 和 port
     */
    @Override
    public void deleteAllTable(String ipAndPort) {
        TransportClient client = null;
        BufferedReader br = null;
        try {
            br = new BufferedReader(new InputStreamReader(System.in));
            System.out.println("请输入Elasticsearch集群名:");
            this.elasticsearchName = br.readLine();
            //获取所有索引列表
            Settings settings = Settings.builder()
                    .put("cluster.name", this.elasticsearchName)
                    .build();
            client = new PreBuiltTransportClient(settings).addTransportAddresses(inetSocketTransportAddress(ipAndPort));
            ActionFuture<IndicesStatsResponse> isr = client.admin().indices().stats(new IndicesStatsRequest().all());
            Set<String> set = isr.actionGet().getIndices().keySet();
            StringBuilder sb = new StringBuilder();
            for(String name: set) {
                sb.append(name).append("\n");
            }
            System.out.println(String.format("%s 中一共有 %s 张表, 如下\n%s您确定要全部删除吗? 确定则输入y, 否则按回车键结束.", this.elasticsearchName, set.size(), sb.toString()));
            if("y".equals(br.readLine().trim().toLowerCase())) {
                for(String index: set) {
                    boolean isDelete = client.admin().indices().prepareDelete(index).execute().actionGet().isAcknowledged();
                    System.out.println(String.format("Delete %s success: %s", index, isDelete));
                }
            } else {
                System.exit(0);
            }

            System.out.println("成功!");
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            close(br, client);
        }

    }


    /**
     * 创建表
     * @param table IESTable
     * @param shardNumber 分片数量
     * @param replicas 复制份数
     * @throws IOException io异常
     */
    private boolean create(ParserESTable table, TransportClient client, int shardNumber, int replicas, Map<String, Map<String, String>> nameTypeValues) throws IOException {
        LOGGER.info(String.format("Create es table as cdh. Cluster name: %s shardNumber: %d replicas: %d", this.elasticsearchName, shardNumber, replicas));

        //表在es中若存在,直接删除
        if (table.isExists()) {
            client.admin().indices().prepareDelete(table.getTableName()).execute().actionGet();
        }

        Map<String, Object> smap = new HashMap<>();
        smap.put("number_of_shards", shardNumber);
        smap.put("number_of_replicas", replicas);

        CreateIndexRequestBuilder createIndexRequestBuilder = client.admin().indices().prepareCreate(table.getIndex());
        createIndexRequestBuilder.setSettings(smap);
        XContentBuilder mapping = XContentFactory.jsonBuilder()
                .startObject()
                .startObject("properties");
        LOGGER.info("Begin put data.");

        //拼装数据,此处是映射设置的关键
        for (Map.Entry<String, Map<String, String>> entry : nameTypeValues.entrySet()) {
            mapping.startObject(entry.getKey());
            for (Map.Entry<String, String> entry1 : entry.getValue().entrySet()) {
                if ("type".equals(entry1.getKey().trim())) {
                    //字段类型需要映射,有可能出现es中不存在的数据类型
                    mapping.field(entry1.getKey(), SqlTypeMapES.SQL_TYPE_MAP_2_ES.getOrDefault(entry1.getValue(), "string"));
                } else {
                    //此处属于扩展,可以为字段扩展是否被索引等功能
                    mapping.field(entry1.getKey(), entry1.getValue());
                }
            }
            mapping.endObject();
        }
        mapping.endObject()
                .endObject();

        LOGGER.info(String.format("Json data is %s", mapping.string()));

        if (this.esType != null && this.esType.length() > 0) {
            createIndexRequestBuilder.addMapping(this.esType, mapping);
        } else {
            createIndexRequestBuilder.addMapping(table.getType(), mapping);
        }
        createIndexRequestBuilder.execute().actionGet();
        LOGGER.info(String.format("Create %s susses.", table.getTableName()));

        return true;

    }

    /**
     * 添加字段和mapping
     * @param client es客户端
     */
    private void addMapping(String mappingFile, TransportClient client) {
        try {
            Json2MappingObject json2MappingObject;
            if(mappingFile != null && mappingFile.trim().length() > 0) {
                json2MappingObject = new Json2MappingObject(mappingFile);
                PutMappingRequestBuilder putMappingRequest;

                for(String index: json2MappingObject.getIndexs()) {
                    XContentBuilder mapping = XContentFactory.jsonBuilder()
                            .startObject()
                            .startObject("properties");
                    //拼装数据,此处是映射设置的关键
                    for (Map.Entry<String, Map<String, String>> entry : json2MappingObject.getMappingObjects().get(index).getNameTypeValues().entrySet()) {
                        mapping.startObject(entry.getKey());
                        for (Map.Entry<String, String> entry1 : entry.getValue().entrySet()) {
                            if ("type".equals(entry1.getKey().trim())) {
                                //字段类型需要映射,有可能出现es中不存在的数据类型
                                mapping.field(entry1.getKey(), SqlTypeMapES.SQL_TYPE_MAP_2_ES.getOrDefault(entry1.getValue(), "string"));
                            } else {
                                //此处属于扩展,可以为字段扩展是否被索引等功能
                                mapping.field(entry1.getKey(), entry1.getValue());
                            }
                        }
                        mapping.endObject();
                    }
                    mapping.endObject()
                            .endObject();

                    try{
                        putMappingRequest = client.admin().indices().preparePutMapping(index);
                        putMappingRequest.setType(json2MappingObject.getMappingObjects().get(index).getType());
                        putMappingRequest.setSource(mapping);
                        putMappingRequest.execute().actionGet();
                        LOGGER.info(String.format("Json file context: %s", mapping.string()));
                    } catch (Exception e){
                        System.out.println(String.format("索引,类型不存在或要创建的字段已经存在,检查字段文件. index: %s", index));
                        LOGGER.error(String.format("索引或类型不存在或其他异常,检查字段文件. index: %s", index));
                    }
                }
            } else {
                System.out.println("未输入字段文件路径.");
                System.exit(0);
            }
        } catch (IOException e) {
            LOGGER.error(e);
            e.printStackTrace();
        }
    }

    /**
     * @param t 表集合
     * @param names hbase存在的表集合
     * @return 存在的排在后边的表集合
     */
    private ITable[] getSortTables(List<ITable> t, Set<String> names) {

        ITable[] r = new ITable[t.size()];
        int j = t.size() - 1;
        int i = 0;

        for(ITable table: t) {
            if(names.contains(table.getTableName())) {
                ((ParserESTable) table).setExists(true);
                r[j] = table;
                j --;
            } else {
                r[i] = table;
                i++;
            }
        }
        System.out.println(String.format("即将插入的表共有: %s 张, 其中有 %s 张在Elasticsearch中已经存在.", t.size(), t.size() - 1 - j));

        return r;
    }


    /**
     * 拼装Host和Port
     * @return 拼装好的InetSocketTransportAddress数组
     * @throws UnknownHostException 未知host异常
     */
    private InetSocketTransportAddress[] inetSocketTransportAddress(String hostAndPort) throws UnknownHostException {
        String [] s = hostAndPort.split(":");
        LOGGER.info(String.format("Ip and port: %s:%s", s[0], s[1]));
        InetSocketTransportAddress[] r = new InetSocketTransportAddress[1];
        r[0] = new InetSocketTransportAddress(InetAddress.getByName(s[0]), Integer.parseInt(s[1]));
        return r;
    }

    private void close(BufferedReader br, TransportClient client) {
        try {
            if (br != null) br.close();
            if (client != null) client.close();
        } catch (IOException e) {
            LOGGER.error(e);
            e.printStackTrace();
        }
    }
}
