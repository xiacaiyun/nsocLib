package cn.nsoc.create.parser;

import org.json.JSONObject;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.*;

/**
 * 解析json,构造映射关系
 * Create by Alan 2017.09.14
 */
public class Json2MappingObject {
    private List<String> indexs;
    private List<String> indexAndTypes;
    private Map<String, CreateElasticsearchTableMapping> mappingObjects;

    /**
     * 构造函数
     * @param jsonFilePath json文件路径
     */
    public Json2MappingObject(String jsonFilePath) {
        try {
            json2Mapping(jsonFilePath);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public Json2MappingObject(){}

    /**
     * 解析json文件, 构造映射关系
     * @param jsonFilePath json文件路径
     * @return 映射关系集合, 因为可能存在多个index,所以返回集合
     * @throws IOException io异常
     */
    public List<CreateElasticsearchTableMapping> json2Mapping(String jsonFilePath) throws IOException {
        //"D:\\pro\\test\\jsont.txt"
        List<String> lines = Files.readAllLines(Paths.get(jsonFilePath), StandardCharsets.UTF_8);
        StringBuilder sb = new StringBuilder();
        for (String line : lines) {
            sb.append(line).append("\n");
        }
        String fromFile = sb.toString();

        this.indexs = new ArrayList<>();
        this.indexAndTypes = new ArrayList<>();
        this.mappingObjects = new HashMap<>();
        //json解析
        JSONObject jsonObject = new JSONObject(fromFile);
        List<CreateElasticsearchTableMapping> r = new ArrayList<>();
        for(String k1: jsonObject.keySet()) {
            //索引
            indexs.add(k1);
            for(String k2: jsonObject.getJSONObject(k1).keySet()) {
                //类型
                indexAndTypes.add(k1 + k2);
                Map<String, Map<String, String>> nameTypeValues = new HashMap<>();
                for(String k3: jsonObject.getJSONObject(k1).getJSONObject(k2).keySet()) {
                    //字段名
                    Map<String, String > typeValues = new HashMap<>();
                    for(String k4: jsonObject.getJSONObject(k1).getJSONObject(k2).getJSONObject(k3).keySet()) {
                        //属性和值
                        String k5 = jsonObject.getJSONObject(k1).getJSONObject(k2).getJSONObject(k3).get(k4).toString();
                        typeValues.put(k4, k5);
                    }
                    nameTypeValues.put(k3, typeValues);
                }
                CreateElasticsearchTableMapping mapping = new CreateElasticsearchTableMapping(k1, k2, nameTypeValues);
                r.add(mapping);
                mappingObjects.put(k1, mapping);
            }
        }

//        for(CreateElasticsearchTableMapping mapping: list) {
//            System.out.println("Index -> " + mapping.getIndex() + " Type -> " + mapping.getType());
//            for(Map.Entry<String, Map<String, String>> entry: mapping.getNameTypeValues().entrySet()) {
//                for (Map.Entry<String, String> entry1: entry.getValue().entrySet()){
//                    System.out.println("f -> " + entry.getKey() + " : " + entry1.getKey() + " " + entry1.getValue());
//                }
//            }
//        }
        return r;
    }

    /**
     * 获取映射对象
     * @return 映射对象
     */
    public Map<String, CreateElasticsearchTableMapping> getMappingObjects() {
        return mappingObjects;
    }

    /**
     * 获取索引和类型集合
     * @return 索引+类型 集合
     */
    public List<String> getIndexAndTypes() {
        return indexAndTypes;
    }

    /**
     * 获取索引集合
     * @return 索引集合
     */
    public List<String> getIndexs() {
        return indexs;
    }

}

