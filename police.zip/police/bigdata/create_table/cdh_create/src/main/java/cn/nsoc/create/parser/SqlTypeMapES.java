package cn.nsoc.create.parser;

import java.util.HashMap;
import java.util.Map;

/**
 * 类型的映射关系, 由于一些sql中的字段在es中未必存在, 所以有必要做映射
 */
public class SqlTypeMapES {
    public static Map<String, String> SQL_TYPE_MAP_2_ES;

    static {
        SQL_TYPE_MAP_2_ES = new HashMap<>();
        //long,integer,short,byte,double,float
        SQL_TYPE_MAP_2_ES.put("keyword", "keyword");
        SQL_TYPE_MAP_2_ES.put("text", "text");
        SQL_TYPE_MAP_2_ES.put("string", "keyword");
        SQL_TYPE_MAP_2_ES.put("int", "integer");
        SQL_TYPE_MAP_2_ES.put("bigint", "long");
        SQL_TYPE_MAP_2_ES.put("date", "date");
        SQL_TYPE_MAP_2_ES.put("double", "double");
    }

}
