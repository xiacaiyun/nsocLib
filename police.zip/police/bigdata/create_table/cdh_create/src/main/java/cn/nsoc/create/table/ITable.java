package cn.nsoc.create.table;

public interface ITable {
    /**
     * 是否存在的标志
     * @return 是否存在
     */
    boolean isExists();
    /**
     * 获取表名
     */
    String getTableName();
}
