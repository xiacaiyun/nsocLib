package cn.nsoc.create.table;

import org.apache.log4j.Logger;

import java.util.ArrayList;
import java.util.List;

/**
 * 解析HBase表
 */
public class ParserHbaseTable implements ITable{
    private static Logger LOGGER = Logger.getLogger("ParserHBaseTable");
    //sql
    private String context;
    //带有表名的头部分
    private String head;
    //带有列族的尾部分
    private String tail;
    //是否存在的标志, 默认不存在
    private boolean exists = false;

    /**
     * 构造函数
     * @param context 建表sql语句
     */
    public ParserHbaseTable(String context) {
        assert context != null;
        this.context = context;
        String[] contexts = context.trim().toLowerCase().replace("(", ")").split("\\)");
        assert contexts.length >= 3;
        this.head = contexts[0];
        this.tail = contexts[contexts.length - 1];
    }

    /**
     * 获取表名
     * @return 表名
     */
    public String getTableName() {
        assert this.head.length() > 0;
        return this.head.trim().split("table ")[1];
    }

    /**
     * 获取列族
     * @return 列族
     */
    public List<byte[]> getColumnFamily() {
        assert tail != null;
        String[] fn = this.tail.replace("'", "").split(",");
        List<byte[]> r = new ArrayList<>();
        StringBuilder tmp = new StringBuilder();
        LOGGER.info(String.format("Get column family. Tail: %s ", this.tail));
        for(int i = 1; i < fn.length; i ++) {
            String v = fn[i].split(":")[0];
            if(!tmp.toString().contains(v)){
                r.add(v.getBytes());
                tmp.append(v);
                LOGGER.info(String.format("Column family: %s ", v));
            }
        }
        return r;
    }

    /**
     * 获取存在标记
     * @return 存在:true 不存在: false
     */
    @Override
    public boolean isExists() {
        return exists;
    }

    /**
     * 设置存在标记,默认在HBase中是不存在的,所以默认值为false
     * @param exists 是否存在
     */
    public void setExists(boolean exists) {
        this.exists = exists;
    }

    /**
     * 获取完整的sql语句
     * @return 完整的sql语句
     */
    public String getContext() {
        return context;
    }

}
