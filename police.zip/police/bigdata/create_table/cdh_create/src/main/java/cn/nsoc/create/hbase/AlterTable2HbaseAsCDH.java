package cn.nsoc.create.hbase;

import cn.nsoc.create.IAlterBase;
import cn.nsoc.create.parser.CDHTableParser;
import cn.nsoc.create.table.ITable;
import cn.nsoc.create.table.ParserHbaseTable;
import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.hbase.*;
import org.apache.hadoop.hbase.client.*;
import org.apache.log4j.Logger;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;

public class AlterTable2HbaseAsCDH implements IAlterBase {

    //日志记录
    private static Logger LOGGER = Logger.getLogger("AlterTable2HbaseAsCDH");
    //配置
    private Configuration config;

    public AlterTable2HbaseAsCDH() {
        config = HBaseConfiguration.create();
    }

    /**
     *创建HBase表
     * @param sqlSource 建表的sql数据源
     * @param ipAndPort ip 和 port
     */
    @Override
    public void create(String sqlSource, String ipAndPort) {
        System.out.println("正在连接CHD-HBase...");
        String[] ipArray = ipAndPort.split(":");

        //连接
        Connection connection = null;
        Admin admin = null;
        BufferedReader br = null;
        try {
            br = new BufferedReader(new InputStreamReader(System.in));
            System.out.println("如果自定义了zookeeper.znode.parent属性, 则输入(若没有自定义, 则使用默认值, 直接回车即可.):");
            String zookeeperZnodeParent = br.readLine();

            //解析器
            CDHTableParser parser = new CDHTableParser();
            //表
            List<ITable> tables = parser.getTables("hb", sqlSource);
            config.set("hbase.zookeeper.property.clientPort", ipArray[1]);
            config.set("hbase.zookeeper.quorum", ipArray[0]);
            //如果输入了zookeeper.znode.parent, 则设置输入的值
            if(zookeeperZnodeParent != null && zookeeperZnodeParent.trim().length() > 0) {
                config.set("zookeeper.znode.parent",zookeeperZnodeParent);
            }

            connection = ConnectionFactory.createConnection(config);
            LOGGER.info("Create connection success.");
            admin = connection.getAdmin();
            LOGGER.info("Get admin success.");

            //本地判断
            TableName[] tableNames = admin.listTableNames();
            List<String> names = new ArrayList<>(tableNames.length);
            for(TableName name: tableNames) {
                names.add(new String(name.getName()));
            }
            ITable[] iTables = getSortTables(tables, names);

            for(ITable table: iTables) {
                ParserHbaseTable cdhTableParser = (ParserHbaseTable) table;
                boolean isSuccess;
                if(cdhTableParser.isExists()) {
                    System.out.println(String.format("%s 表在HBase中已经存在, 是否覆盖? 输入 y 表示覆盖,否则不覆盖.", cdhTableParser.getTableName()));
                    String ow = br.readLine();
                    if("y".equals(ow.toLowerCase())) {
                        isSuccess = create(cdhTableParser, admin);
                    } else {
                        System.out.println(String.format("%s 将不进行创建, 因为HBase中已经存在,并且选择了不覆盖.", cdhTableParser.getTableName()));
                        isSuccess = false;
                    }
                } else {
                    isSuccess = create(cdhTableParser, admin);
                }

                LOGGER.info(String.format("Create table %s success: %s", table.getTableName(), isSuccess));
            }
        } catch (IOException e) {
            LOGGER.error(e);
            e.printStackTrace();
        } finally {
           close(admin, connection, br);
        }
    }

    @Override
    public void deleteAllTable(String ipAndPort) {
        System.out.println("正在连接CHD-HBase...");
        String[] ipArray = ipAndPort.split(":");

        //连接
        Connection connection = null;
        Admin admin = null;
        BufferedReader br = null;
        try {
            br = new BufferedReader(new InputStreamReader(System.in));
            System.out.println("如果自定义了zookeeper.znode.parent属性, 则输入(若没有自定义, 则使用默认值, 直接回车即可.):");
            String zookeeperZnodeParent = br.readLine();

            config.set("hbase.zookeeper.property.clientPort", ipArray[1]);
            config.set("hbase.zookeeper.quorum", ipArray[0]);
            //如果输入了zookeeper.znode.parent, 则设置输入的值
            if (zookeeperZnodeParent != null && zookeeperZnodeParent.trim().length() > 0) {
                config.set("zookeeper.znode.parent", zookeeperZnodeParent);
            }

            connection = ConnectionFactory.createConnection(config);
            LOGGER.info("Create connection success.");
            admin = connection.getAdmin();
            LOGGER.info("Get admin success.");

            //获取
            TableName[] tableNames = admin.listTableNames();
            StringBuilder names = new StringBuilder();
            for(TableName t: tableNames) {
                names.append(t.toString()).append("\n");
            }
            System.out.println(String.format("Hbase中一共有 %d 张表, 分别为:\n %s您确定要全部删除么? 如果确定, 请输入y, 否则按任意键退出.", tableNames.length, names.toString()));
            String isDelete = br.readLine();
            if("y".equals(isDelete.trim().toLowerCase())) {
                admin.disableTables(".*");
                admin.deleteTables(".*");
            }
            System.out.println(String.format("Delete success: %s ", true));
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            close(admin, connection, br);
        }
    }

    /**
     * @param t 表集合
     * @param names hbase存在的表集合
     * @return 存在的排在后边的表集合
     */
    private ITable[] getSortTables(List<ITable> t, List<String> names) {

        ITable[] r = new ITable[t.size()];
        int j = t.size() - 1;
        int i = 0;

        for(ITable table: t) {
            if(names.contains(table.getTableName())) {
                ((ParserHbaseTable) table).setExists(true);
                r[j] = table;
                j --;
            } else {
                r[i] = table;
                i++;
            }
        }
        System.out.println(String.format("即将插入的表共有: %s 张, 其中有 %s 张在Hbase中已经存在.", t.size(), t.size() - 1 - j));

        return r;
    }


    /**
     * 创建表
     * @param hbaseTable 读取到的表
     * @param admin admin
     * @throws IOException io异常
     */
    private boolean create(ParserHbaseTable hbaseTable, Admin admin) throws IOException{
        //表名
        String tableName = hbaseTable.getTableName();
        //如果表存在, 便删除
        if(hbaseTable.isExists()) {
            admin.disableTable(TableName.valueOf(tableName));
            admin.deleteTable(TableName.valueOf(tableName));
        }
        LOGGER.info(String.format("Create table %s ", tableName));

        HTableDescriptor table = new HTableDescriptor(TableName.valueOf(tableName));
        //获取列族
        for(byte[] b: hbaseTable.getColumnFamily()) {
            table.addFamily(new HColumnDescriptor(b));
            LOGGER.info(String.format("Family %s ", new String(b)));
        }
        admin.createTable(table);
        return true;
    }

    /**
     * 关闭资源
     * @param admin Admin
     * @param connection Connection
     * @param br BufferedReader
     */
    private void close(Admin admin, Connection connection, BufferedReader br) {
        try {
            if(admin != null) admin.close();
            if(connection != null) connection.close();
            if(br != null) br.close();
        } catch (IOException e) {
            LOGGER.error(e);
            e.printStackTrace();
        }
    }
}
