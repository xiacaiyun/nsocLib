package cn.nsoc.create.parser;

import java.util.Map;

/**
 * es mapping实体类
 * Create by Alan 2017.09.14
 */
public class CreateElasticsearchTableMapping{
    private String index;
    private String type;
    private Map<String, Map<String, String>> nameTypeValues;

    /**
     * 构造函数
     * @param index 索引
     * @param type 类型
     * @param nameTypeValues <字段名<属性,属性值>>
     */
    public CreateElasticsearchTableMapping(String index, String type, Map<String, Map<String, String>> nameTypeValues) {
        setIndex(index);
        setType(type);
        setNameTypeValues(nameTypeValues);
    }

    /**
     * 获取类型
     * @return 类型
     */
    public String getType() {
        return type;
    }

    /**
     * 获取索引
     * @return 索引
     */
    public String getIndex() {
        return index;
    }

    /**
     * 获取映射关系
     * @return 映射关系
     */
    public Map<String, Map<String, String>> getNameTypeValues() {
        return nameTypeValues;
    }

    /**
     * 设置类型
     * @param type 类型
     */
    public void setType(String type) {
        this.type = type;
    }

    /**
     * 设置索引
     * @param index 索引
     */
    public void setIndex(String index) {
        this.index = index.toLowerCase();
    }

    /**
     * 设置映射
     * @param nameTypeValues 映射
     */
    public void setNameTypeValues(Map<String, Map<String, String>> nameTypeValues) {
        this.nameTypeValues = nameTypeValues;
    }
}
