package cn.nsoc.create.parser;

import cn.nsoc.create.table.ITable;
import cn.nsoc.create.table.ParserESTable;
import cn.nsoc.create.table.ParserHbaseTable;
import org.apache.log4j.Logger;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;

/**
 * 解析器
 * Create by Alan 2017.09.11
 */
public class CDHTableParser {
    private static Logger LOGGER = Logger.getLogger("CDHTableParser");

    /**
     * 获取表
     * @param type 表类型
     * @param sqlSources sql文件路径
     * @return 表集合
     */
    public List<ITable> getTables(String type, String sqlSources) throws IOException {
        if (sqlSources == null || sqlSources.length() == 0 || type == null || type.length() != 2) {
            throw new NullPointerException("Sql file sources or type is null.");
        }
        //解析好的table集合
        List<ITable> tables = new ArrayList<>();
            LOGGER.info(String.format("Parser sql file. path: %s ", sqlSources));
            List<String> lines = Files.readAllLines(Paths.get(sqlSources), StandardCharsets.UTF_8);
            StringBuilder sb = new StringBuilder();
            for (String line : lines) {
                sb.append(line).append("\n");
            }
            String fromFile = sb.toString();

            String[] s = fromFile.split(";");
            for (String t : s) {
                if ("es".equals(type) && t.contains("STORED AS ES")) {
                    //解析并把解析好的es table添加到table集合中
                    tables.add(new ParserESTable(t));
                    LOGGER.info(String.format("Elasticsearch table: %s ", t));
                } else if ("hb".equals(type) && t.contains("org.apache.hadoop.hive.hbase.HBaseStorageHandler")) {
                    //解析并把解析好的hbase table添加到table集合中
                    tables.add(new ParserHbaseTable(t));
                    LOGGER.info(String.format("Hbase table: %s ", t));
                }
            }
        return tables;
    }

}
