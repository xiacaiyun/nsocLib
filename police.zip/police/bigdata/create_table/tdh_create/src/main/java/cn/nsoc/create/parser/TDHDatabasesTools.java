package cn.nsoc.create.parser;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

public class TDHDatabasesTools {
    /**
     * 获取es或hbase上已经存在的表
     * @param tableType es或者hb
     * @param connection 连接
     * @return 表集合
     */
    public static List<String> getTableNames(String tableType, Connection connection) {
        Statement statement1 = null;
        //用户获取表结构,提取es表
        Statement statement2 = null;
        List<String> tableNames = tableNames = new ArrayList<>();
        try {
            //用于获取所有表
            statement1 = connection.createStatement();
            //用于获取表结构,提取es表
            statement2 = connection.createStatement();

            String sql = "SHOW TABLES";
            ResultSet resultSet = statement1.executeQuery(sql);
            while (resultSet.next()){
                String tableName = resultSet.getString(1 );
                ResultSet resultSet1 = statement2.executeQuery(String.format("DESC %s ", tableName));
                while (resultSet1.next()) {
                    String context = resultSet1.getString(1);
                    if ("es".equals(tableType.trim().toLowerCase()) && context != null && (context.trim()).contains("index.number_of_shards")) {
                        tableNames.add(tableName);
                        break;
                    } else if("hb".equals(tableType.trim().toLowerCase()) && context != null && (context.trim()).equals("vk")) {
                        tableNames.add(tableName);
                    }
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            try {
                if(statement1 != null) statement1.close();
                if(statement2 != null) statement2.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
        return tableNames;
    }
}
