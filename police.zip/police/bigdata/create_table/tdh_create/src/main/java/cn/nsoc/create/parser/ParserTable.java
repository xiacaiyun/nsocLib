package cn.nsoc.create.parser;

/**
 * table实体类
 */
public class ParserTable {
    private String tableName;
    private String context;
    private boolean exists = false;

    public ParserTable(String context) {
        if(context == null || context.length() <= 0) {
            throw new NullPointerException();
        }
        String tm = context.trim().toLowerCase();
        setTableName(tm.split("\\(")[0].trim().split("table ")[1]);
        setContext(context);
    }

    public String getContext() {
        return context;
    }

    public String getTableName() {
        return tableName;
    }

    public boolean isExists() {
        return exists;
    }

    public void setExists(boolean exists) {
        this.exists = exists;
    }

    public void setContext(String context) {
        this.context = context;
    }

    public void setTableName(String tableName) {
        this.tableName = tableName;
    }
}
