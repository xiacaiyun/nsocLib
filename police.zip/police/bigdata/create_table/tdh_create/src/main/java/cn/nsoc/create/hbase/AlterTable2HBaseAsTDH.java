package cn.nsoc.create.hbase;

import cn.nsoc.create.IAlterBase;
import cn.nsoc.create.parser.ParserTable;
import cn.nsoc.create.parser.TDHDatabasesTools;
import cn.nsoc.create.parser.TDHTableParser;
import org.apache.log4j.Logger;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.sql.*;
import java.util.List;

/**
 * 在TDH上创建HBase表
 * Create by Alan 2017.09.12
 */
public class AlterTable2HBaseAsTDH implements IAlterBase {
    private static Logger LOGGER = Logger.getLogger("AlterTable2HBaseAsTDH");
    //输入流
    private BufferedReader br = null;

    public AlterTable2HBaseAsTDH() {
        try {
            Class.forName("org.apache.hive.jdbc.HiveDriver");
        } catch (Exception e) {
            e.printStackTrace();
            LOGGER.error(e);
            System.exit(1);
        }
    }

    /**
     * 创建表
     * @param table 建表sql
     * @param statement Statement
     * @throws SQLException io异常
     */
    private void create(ParserTable table, Statement statement) throws SQLException, IOException {
        if(table.isExists()) {
            System.out.println(String.format("在数据库中已经存在HBase表 %s 是否要覆盖,如果要覆盖,请输入y,否则按回车键结束.", table.getTableName()));
            if("y".equals(getReader().readLine().trim().toLowerCase())) {
                statement.execute(String.format("DROP TABLE %s ", table.getTableName()));
            } else {
                return;
            }
        }
        LOGGER.info(String.format("Create table sql: %s ", table.getContext()));
        statement.execute(table.getContext());
    }

    /**
     * 接收用户名和密码的输入
     * @return 用户名和密码数组
     */
    private String[] printUserNameAndPassword() {
        System.out.println("请输入用户名和密码...");
        String[] up = new String[2];
        try {
            System.out.println("用户名:");
            up[0] = getReader().readLine();
            System.out.println("密码:");
            up[1] = getReader().readLine();
        } catch (IOException e) {
            e.printStackTrace();
        }
        return up;
    }

    /**
     * 创建表
     * @param sqlSource 建表的sql数据源
     * @param ipAndPort ip和端口
     */
    @Override
    public void create(String sqlSource, String ipAndPort) {
        System.out.println("正在连接THD-JDBC-HBase ...");
        Connection conn = null;
        Statement stmt = null;
        try {
            System.out.println("请输入数据库名:");
            String database = getReader().readLine();
            if(database != null && database.trim().length() > 0) {
                conn = getConn(ipAndPort, database);
            } else {
                System.out.println("您输入的数据库名有错误.");
                System.exit(1);
            }

            TDHTableParser parser = new TDHTableParser();
            //获取建表语句
            List<ParserTable> list = parser.getTables("hb", sqlSource);
            //获取数据库中的hbase表
            List<String> esTablesAsDatabase = TDHDatabasesTools.getTableNames("hb", conn);
            //获取标记以后的,并且排好序的表
            ParserTable[] sortTables = getSortTables(list, esTablesAsDatabase);

            stmt = conn.createStatement();
            for(ParserTable table: sortTables) {
                create(table, stmt);
                LOGGER.info("Create table success.");
            }

            System.out.println("成功!");
        } catch (SQLException | IOException e) {
            LOGGER.error(e);
            e.printStackTrace();
        } finally {
            try {
                if(stmt != null) stmt.close();
                if(conn != null) conn.close();
                getReader().close();
            } catch (SQLException | IOException e) {
                LOGGER.error("Close source exception.", e);
                e.printStackTrace();
            }
        }
    }

    /**
     * 删除所有的表
     * @param ipAndPort ip 和 port
     */
    @Override
    public void deleteAllTable(String ipAndPort) {
        Connection connection = null;
        //用于删除表
        Statement statement3 = null;
        try {
            System.out.println("请输入数据库名:");
            String database = getReader().readLine();
            if(database != null && database.trim().length() > 0) {
                connection = getConn(ipAndPort, database);
            } else {
                System.out.println("您输入的数据库名有错误.");
                System.exit(1);
            }

            List<String> tableNames = TDHDatabasesTools.getTableNames("hb", connection);
            if(tableNames.size() == 0) {
                System.out.println("数据库中不存在HBase表...");
                System.exit(0);
            }
            StringBuilder sb = new StringBuilder();
            for(String ta: tableNames) {
                sb.append(ta).append("\n");
            }

            System.out.println(String.format("%s 中一共有 %d 张HBase表, 如下\n%s您确定要全部删除吗? 确定, 请输入y, 否则按回车键结束.", database, tableNames.size(), sb.toString()));
            if("y".equals(getReader().readLine().trim().toLowerCase())) {
                //用于删除表
                statement3 = connection.createStatement();
                for(String tableName: tableNames) {
                    statement3.execute(String.format("DROP TABLE %s ", tableName)); //不管是否成功,总是返回false！！！
                    System.out.println(String.format("HBase table %s delete success: %s ", tableName, true));
                }
            } else {
                System.exit(0);
            }

            System.out.println("成功!");
        } catch (SQLException | IOException e) {
            LOGGER.error(e);
            e.printStackTrace();
        } finally {
            try {
                if(statement3 != null) statement3.close();
                if(connection != null) connection.close();
                getReader().close();
            } catch (IOException | SQLException e) {
                LOGGER.error("Close resources fail.", e);
                e.printStackTrace();
            }
        }
    }

    /**
     * @param t 表集合
     * @param names hbase存在的表集合
     * @return 存在的排在后边的表集合
     */
    private ParserTable[] getSortTables(List<ParserTable> t, List<String> names) {

        ParserTable[] r = new ParserTable[t.size()];
        int j = t.size() - 1;
        int i = 0;

        for(ParserTable table: t) {
            if(names.contains(table.getTableName())) {
                table.setExists(true);
                r[j] = table;
                j --;
            } else if(names.contains(table.getTableName().split("\\.")[1].trim())){
                table.setExists(true);
                r[j] = table;
                j --;
            } else  {
                r[i] = table;
                i++;
            }
        }
        System.out.println(String.format("即将插入的表共有: %s 张, 其中有 %s 张在HBase中已经存在.", t.size(), t.size() - 1 - j));

        return r;
    }

    /**
     * 获取输入
     * @return BufferedReader流
     */
    private BufferedReader getReader() {
        if(this.br == null) {
            this.br = new BufferedReader(new InputStreamReader(System.in));
        }
        return  this.br;
    }

    /**
     * 数据库连接
     * @param ipAndPort ip和port
     * @param database 数据库名
     * @return 数据库连接
     */
    private Connection getConn(String ipAndPort, String database) {
        if(ipAndPort == null || ipAndPort.length() < 8) {
            throw new NullPointerException("ip and port is null");
        }

        //设置用户名和密码
        String[] np = printUserNameAndPassword();
        String user = np[0];
        String password = np[1];
        String url = String.format("jdbc:hive2://%s/%s", ipAndPort, database);

        Connection conn = null;
        try {
            conn = DriverManager.getConnection(url, user, password);
            LOGGER.info(String.format("Get connection success. Url: %s user: %s", url, user));
        } catch (SQLException e) {
            LOGGER.error(e);
            System.out.println("Get connection error. Check ip or port or user or password.");
            System.exit(1);
        }
        return conn;
    }

}
