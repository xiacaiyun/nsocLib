package cn.nsoc.create.parser;

import org.apache.log4j.Logger;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;

/**
 * 解析器
 * Create by Alan 2017.09.11
 */
public class TDHTableParser {
    private static Logger LOGGER = Logger.getLogger("TDHTableParser");
    /**
     * 获取表
     * @param sqlSources sql文件路径
     * @return 表集合
     */
    public List<ParserTable> getTables(String type, String sqlSources) throws IOException {
        if (sqlSources == null || sqlSources.length() == 0 || type == null || type.length() != 2) {
            throw new NullPointerException("Sql file sources or type is null.");
        }
        //解析好的table集合
        List<ParserTable> tables = new ArrayList<>();
        LOGGER.info(String.format("TDHTableParser sql file. path: %s ", sqlSources));
        List<String> lines = Files.readAllLines(Paths.get(sqlSources), StandardCharsets.UTF_8);
        StringBuilder sb = new StringBuilder();
        for(String line : lines){
            sb.append(line).append("\n");
        }
        String fromFile = sb.toString();

        String[] s = fromFile.split(";");
        int i = 1;
        for(String t: s) {
            if("es".equals(type) && t.contains("STORED AS ES")) {
                //解析并把解析好的es table添加到table集合中
                tables.add(new ParserTable(t));
                LOGGER.info(String.format("Parser es table %d", i ++));
            } else if("hb".equals(type) && t.contains("org.apache.hadoop.hive.hbase.HBaseStorageHandler")) {
                //解析并把解析好的hbase table添加到table集合中
                tables.add(new ParserTable(t));
                LOGGER.info(String.format("Parser hbase table %d", i ++));
            }
        }
        return tables;
    }

}
