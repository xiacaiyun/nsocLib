package cn.nsoc.create.es;

import cn.nsoc.create.IAlterBase;
import cn.nsoc.create.parser.ParserTable;
import cn.nsoc.create.parser.TDHDatabasesTools;
import cn.nsoc.create.parser.TDHTableParser;
import org.apache.log4j.Logger;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.sql.*;
import java.util.List;

/**
 * 对TDH上的es进行操作
 * Create by Alan 2017.09.13
 */
public class AlterTable2ElasticsearchAsTDH implements IAlterBase {
    private static Logger LOGGER = Logger.getLogger("AlterTable2ElasticsearchAsTDH");
    private BufferedReader br;

    public AlterTable2ElasticsearchAsTDH() {
        try {
            Class.forName("org.apache.hive.jdbc.HiveDriver");
        } catch (Exception e) {
            e.printStackTrace();
            System.exit(1);
        }
    }

    /**
     * 创建表
     * @param table 建表sql
     * @param statement Statement
     * @throws SQLException io异常
     */
    private void create(ParserTable table, Statement statement) throws SQLException, IOException {
        if(table.isExists()) {
            System.out.println(String.format("在数据库中已经存在Elasticsearch表 %s 是否要覆盖,如果要覆盖,请输入y,否则按回车键结束.", table.getTableName()));
            if("y".equals(getReader().readLine().trim().toLowerCase())) {
                statement.execute(String.format("DROP TABLE %s ", table.getTableName()));
            } else {
                return;
            }
        }
        LOGGER.info(String.format("Create table sql: %s ", table.getContext()));
        statement.execute(table.getContext());
    }

    @Override
    public void create(String sqlSource, String ipAndPort) {
        System.out.println("正在连接THD-JDBC-Elasticsearch...");

        Connection conn = null;
        Statement stmt = null;
        try {
            System.out.println("请输入数据库名:");
            String database = getReader().readLine();
            if(database != null && database.trim().length() > 0) {
                conn = getConn(ipAndPort, database);
            } else {
                System.out.println("您输入的数据库名有错误.");
                System.exit(1);
            }
            TDHTableParser parser = new TDHTableParser();
            //获取es类型的表
            List<ParserTable> list = parser.getTables("es", sqlSource);
            //获取数据库中的es表
            List<String> esTablesAsDatabase = TDHDatabasesTools.getTableNames("es", conn);
            //获取标记以后的,并且排好序的表
            ParserTable[] sortTables = getSortTables(list, esTablesAsDatabase);

            stmt = conn.createStatement();

            for(ParserTable table: sortTables) {
                create(table, stmt);
                LOGGER.info("Create table success.");
            }

            System.out.println("成功!");
        } catch (SQLException | IOException e) {
            LOGGER.error(e);
            e.printStackTrace();
        } finally {
            try {
                getReader().close();
                if(stmt != null) stmt.close();
                if(conn != null) conn.close();
            } catch (SQLException | IOException e) {
                LOGGER.error("Close sources exception.", e);
                e.printStackTrace();
            }
        }
    }


    /**
     * 删除所有的表
     * @param ipAndPort ip 和 port
     */
    @Override
    public void deleteAllTable(String ipAndPort) {
        Connection connection = null;
        //用于删除表
        Statement statement3 = null;
        try {
            System.out.println("请输入数据库名:");
            String database = getReader().readLine();
            if(database != null && database.trim().length() > 0) {
                connection = getConn(ipAndPort, database);
            } else {
                System.out.println("您输入的数据库名有错误.");
                System.exit(1);
            }


            List<String> tableNames = TDHDatabasesTools.getTableNames("es", connection);
            if(tableNames.size() <= 0) {
                System.out.println(String.format("%s 中不存在Elasticsearch表...", database));
                System.exit(0);
            }
            StringBuilder sb = new StringBuilder();
            for(String ta: tableNames) {
                sb.append(ta).append("\n");
            }
            System.out.println(String.format("%s 中一共有 %d 张Elasticsearch表, 如下\n%s您确定要全部删除吗? 确定, 请输入y, 否则按回车键结束.", database, tableNames.size(), sb.toString()));
            if("y".equals(getReader().readLine().trim().toLowerCase())) {
                //用于删除表
                statement3 = connection.createStatement();
                for(String tableName: tableNames) {
                    statement3.execute(String.format("DROP TABLE %s ", tableName)); //不管是否成功,总是返回false！！！
                    System.out.println(String.format("Elasticsearch table %s delete success: %s ", tableName, true));
                }
            } else {
                System.exit(0);
            }
            System.out.println("成功!");
        } catch (SQLException | IOException e) {
            LOGGER.error(e);
            e.printStackTrace();
        } finally {
            try {
                getReader().close();
                if(statement3 != null) statement3.close();
                if(connection != null) connection.close();
            } catch (IOException | SQLException e) {
                e.printStackTrace();
            }
        }
    }

    /**
     * @param t 表集合
     * @param names hbase存在的表集合
     * @return 存在的排在后边的表集合
     */
    private ParserTable[] getSortTables(List<ParserTable> t, List<String> names) {

        ParserTable[] r = new ParserTable[t.size()];
        int j = t.size() - 1;
        int i = 0;

        for(ParserTable table: t) {
            if(names.contains(table.getTableName())) {
                table.setExists(true);
                r[j] = table;
                j = j - 1;
            } else if(names.contains(table.getTableName().split("\\.")[1].trim())){
                table.setExists(true);
                r[j] = table;
                j = j - 1;
            } else {
                r[i] = table;
                i = i + 1;
            }
        }
        System.out.println(String.format("即将插入的表共有: %s 张, 其中有 %s 张在Elasticsearch中已经存在.", t.size(), t.size() - 1 - j));

        return r;
    }

    /**
     * 获取连接
     * @param ipAndPort ip和port
     * @param database 数据库
     * @return 连接
     */
    private Connection getConn(String ipAndPort, String database) {
        if(ipAndPort == null || ipAndPort.length() < 8) {
            throw new NullPointerException("Ip and port is null");
        }

        //设置用户名和密码
        String[] np = printUserNameAndPassword();
        String user = np[0];
        String password = np[1];
        String url = String.format("jdbc:hive2://%s/%s", ipAndPort, database);

        Connection conn = null;
        try {
            conn = DriverManager.getConnection(url, user, password);
            LOGGER.info(String.format("Get connection success. Url: %s user: %s", url, user));
        } catch (SQLException e) {
            System.out.println("Get connection error. Check ip or port or user or password.");
            LOGGER.error(e);
            System.exit(1);
        }
        return conn;
    }

    private BufferedReader getReader() {
        if(this.br == null) {
            this.br = new BufferedReader(new InputStreamReader(System.in));
        }
        return  this.br;
    }

    private String[] printUserNameAndPassword() {
        System.out.println("请输入用户名和密码...");
        String[] up = new String[2];
        try {
            System.out.println("用户名: ");
            up[0] = getReader().readLine();
            System.out.println("密码: ");
            up[1] = getReader().readLine();
        } catch (IOException e) {
            e.printStackTrace();
        }
        return up;
    }
}
