package cn.nsoc.rcmd.tools;

import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClientBuilder;
import org.apache.http.util.EntityUtils;
import org.json.JSONArray;
import org.json.JSONObject;

import java.io.IOException;

public class HttpTools {
    private static final String RET = "ret";
    private static final String DATA = "data";
    private static final String TYPE = "type";
    private static final String SERVICE_CODE = "servicecode";

    public static String getPlaces(String url, int type) throws IOException {
        if(type == -4040) {
            return "ALL";
        }
        StringBuilder places = new StringBuilder();
        HttpPost post = new HttpPost(url);
        CloseableHttpClient client = HttpClientBuilder.create().build();
        CloseableHttpResponse response = client.execute(post);
        String res = EntityUtils.toString(response.getEntity());
        JSONObject object = new JSONObject(res);
        if(object.getBoolean(RET)) {
            JSONArray array = object.getJSONArray(DATA);
            for(Object js: array) {
                if(js instanceof JSONObject && ((JSONObject) js).getInt(TYPE) == type) {
                    places.append(String.format("%s,", ((JSONObject) js).getString(SERVICE_CODE)));
                }
            }
        }
        int lastCommaIndex = places.lastIndexOf(",");
        places.delete(lastCommaIndex, lastCommaIndex + 1);
        return places.toString();
    }
}
