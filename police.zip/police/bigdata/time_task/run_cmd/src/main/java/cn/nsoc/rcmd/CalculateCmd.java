package cn.nsoc.rcmd;


import cn.nsoc.rcmd.tools.CmdBuildTools;
import cn.nsoc.rcmd.tools.HttpTools;
import org.apache.log4j.Logger;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.text.ParseException;


class CalculateCmd {
    private static final Logger LOGGER = Logger.getLogger("rcmd");
    private CmdBuildTools cmdBuild;

    CalculateCmd(String propertiesPath) {
        try {
            cmdBuild = new CmdBuildTools(propertiesPath);
        } catch (IOException e) {
            LOGGER.error(e);
        }
    }

    void fp() {
        try {
            String type = cmdBuild.getProp().getProperty("fp.query.place.type", "");
            if("".equals(type) || "ALL".equals(type.trim().toUpperCase())) {
                type = "-4040";
            }

            String data = HttpTools.getPlaces(cmdBuild.getProp().getProperty("fp.service_code_server"),
                    Integer.parseInt(type));
            String cmd = cmdBuild.fpCmd() + data;
//            exec(cmd);
            System.out.println(cmd);
        } catch (IOException | ParseException | IllegalAccessException e) {
            LOGGER.error(e);
        }
    }

    void rp() {
        try {
            String type = cmdBuild.getProp().getProperty("rp.query.place.type", "");
            if("".equals(type) || "ALL".equals(type.trim().toUpperCase())) {
                type = "-4040";
            }

            String data = HttpTools.getPlaces(cmdBuild.getProp().getProperty("rp.service_code_server"),
                    Integer.parseInt(type));
            String cmd = cmdBuild.rpCmd() + data;
//            exec(cmd);
            System.out.println(cmd);
        } catch (IOException | ParseException | IllegalAccessException e) {
            LOGGER.error(e);
        }
    }

    private void exec(String cmd) {
        LOGGER.debug("Exec cmd: " + cmd);
        Runtime runtime = Runtime.getRuntime();
        Process process = null;
        InputStream in = null;
        try {
            process = runtime.exec(cmd);
            in = process.getInputStream();
            BufferedReader bs = new BufferedReader(new InputStreamReader(in));
            String result;
            StringBuilder message = new StringBuilder();
            LOGGER.info("Exec: ");
            while ((result = bs.readLine()) != null) {
                message.append(result).append("\n");
            }
            LOGGER.info(message.toString());
        } catch (IOException e) {
            LOGGER.error(e);
        } finally {
            try {
                if(in != null) {
                    in.close();
                    LOGGER.info("Close input stream");
                }
                if(process != null) {
                    process.destroy();
                    LOGGER.info("Destroy process");
                }
            } catch (IOException e) {
                LOGGER.error(e);
            }
        }
    }

}
