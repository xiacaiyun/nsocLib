package cn.nsoc.rcmd;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;

public class RunCmd {
    public static void main(String... args) {
        BufferedReader br = null;
        String filePath = "";

        int fPRunPeriod = 1;
        long fpDelay = 0;

        int rPRunPeriod = 1;
        long rpDelay = 0;
        try {
            br = new BufferedReader(new InputStreamReader(System.in));
            System.out.println("请输入配置文件路径(rcmd.properties):");
            filePath = br.readLine();
            checkNull(filePath);
            System.out.println("请输入流动人口计算任务第一次执行的时间(例如 2017-10-10 06:00:00):");
            fpDelay = delay(br.readLine());
            System.out.println("请输入流动人口计算任务的执行间隔(以天为单位):");
            fPRunPeriod = toInt(br.readLine());
            System.out.println("请输入常驻人口计算任务第一次执行的时间(例如 2017-10-10 02:00:00):");
            rpDelay = delay(br.readLine());
            System.out.println("请输入常驻人口计算任务的执行间隔(以天为单位):");
            rPRunPeriod = toInt(br.readLine());

        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            try {
                assert br != null;
                br.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }

        System.out.println("Start... ");
        CalculateCmd calculateCmd = new CalculateCmd(filePath);
        ScheduledExecutorService service = Executors.newSingleThreadScheduledExecutor();
        service.scheduleAtFixedRate(calculateCmd::fp, fpDelay, dayToSeconds(fPRunPeriod),
                TimeUnit.SECONDS);
        service.scheduleAtFixedRate(calculateCmd::rp, rpDelay, dayToSeconds(rPRunPeriod),
                TimeUnit.SECONDS);
    }

    private static void checkNull(String p) {
        if(p == null || "".equals(p)) {
            throw new NullPointerException("请输入正确的参数.");
        }
    }

    private static long delay(String date) {
        checkNull(date);
        long delay;
        try {
            long d1 = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").parse(date).getTime();
            delay = (d1 - System.currentTimeMillis())/1000L;
            if(delay <= 0) {
                throw new RuntimeException("请输入正确的时间.");
            }
        } catch (ParseException e) {
            throw new RuntimeException("请输入正确的时间.");
        }
        return delay;
    }

    private static int toInt(String p) {
        checkNull(p);
        int num;
        try {
            num = Integer.parseInt(p);
        } catch (NumberFormatException e) {
            throw new RuntimeException("请输入正确的参数.");
        }
        return num;
    }

    private static long dayToSeconds(int day) {
        return day * 24 * 60 * 60;
    }
}
