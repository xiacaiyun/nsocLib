package cn.nsoc.rcmd.tools;

import java.io.FileInputStream;
import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Properties;

public class CmdBuildTools {
    private Properties prop;
    private String currentCmd;
    private static final String DATE_FORMAT = "yyyy-MM-dd HH:mm:ss";
    private static final long ONE_SECOND = 1000L;
    private static final long ONE_DAY = 24*60*60*1000;
    private static final String Y_M_D = "yyyy-MM-dd";

    public CmdBuildTools(String propertiesPath) throws IOException {
        prop = new Properties();
        prop.load(new FileInputStream(propertiesPath));
    }

    public String fpCmd() throws IllegalAccessException, ParseException {
        String[] sn = parserDate("fp.query.time.start", "fp.query.time.end");
        String cmd = String.format("%s %s %s %s %s %s %s %s %s %s %s ",
                prop.getProperty("fp.spark.cmd", "spark-submit"),
                prop.getProperty("fp.exec.jar", ""),
                prop.getProperty("fp.es.nodes", ""),
                prop.getProperty("fp.es.index", ""),
                prop.getProperty("fp.es.type", ""),
                prop.getProperty("fp.save.target", "/user/calculate/fp"),
                sn[0], sn[1],
                prop.getProperty("fp.calculate.accuracy", "100"),
                prop.getProperty("fp.count.max", "1000"),
                prop.getProperty("fp.count.min", "2"));
        currentCmd = cmd;
        return cmd;
    }

    public String rpCmd() throws IllegalAccessException, ParseException {
        String[] sn = parserDate("rp.query.time.start", "rp.query.time.end");
        String cmd = String.format("%s %s %s %s %s %s %s %s %s %s ",
                prop.getProperty("rp.spark.cmd", "spark-submit"),
                prop.getProperty("rp.exec.jar", ""),
                prop.getProperty("rp.es.nodes", ""),
                prop.getProperty("rp.es.index", ""),
                prop.getProperty("rp.es.type", ""),
                prop.getProperty("rp.save.target", "/user/calculate/rp"),
                sn[0], sn[1],
//                prop.getProperty("rp.calculate.accuracy", "1000"),
                prop.getProperty("rp.count.max", "100000"),
                prop.getProperty("rp.count.min", "100"));
        currentCmd = cmd;
        return cmd;
    }

    public String getCurrentCmd() {
        return currentCmd;
    }

    public Properties getProp() {
        return prop;
    }

    private String[] parserDate(String startPropName, String endPropName) throws IllegalAccessException, ParseException {
        long currentDate = System.currentTimeMillis();
        String ymd = new SimpleDateFormat(Y_M_D).format(currentDate);
        long startTime = new SimpleDateFormat(DATE_FORMAT).parse(String.format("%s %s", ymd, prop.getProperty(startPropName))).getTime();
        long endTime = new SimpleDateFormat(DATE_FORMAT).parse(String.format("%s %s", ymd, prop.getProperty(endPropName))).getTime();
        if(endTime > currentDate) {
            startTime = startTime - ONE_DAY;
            endTime = endTime - ONE_DAY;
        }
        return new String[]{(startTime/ ONE_SECOND)+"", (endTime/ ONE_SECOND)+""};
    }

    private long getTimeStamp(String date, String format, long change) throws ParseException, IllegalAccessException {
        if (date.length() == 0) throw new IllegalAccessException("Date is \"\"");
        SimpleDateFormat dateFormat = new SimpleDateFormat(format);
        return (dateFormat.parse(date).getTime())/change;
    }
}
