package cn.nsoc.pr

object Polymerization {
  def main(args: Array[String]): Unit = {

  }
}
