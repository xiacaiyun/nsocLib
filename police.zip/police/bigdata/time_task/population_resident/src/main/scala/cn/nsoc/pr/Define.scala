package cn.nsoc.pr

import java.text.SimpleDateFormat

import org.apache.log4j.Logger

object Define {
  private val LOGGER = Logger.getLogger("floating_population")

  val JSON_RESULT_RET = "ret"
  val JSON_RESULT_DATA = "data"
  val JSON_RESULT_TYPE = "type"
  val JSON_RESULT_SERVICE_CODE = "servicecode"
//  val QUERY_ES_INDEX = "police.dev_mac"
//  val QUERY_ES_TYPE = "dev_mac"

  val ES_FIELD_TIME = "online_time"
  val ES_FIELD_SERVICE_CODE = "service_code"
  val ES_FIELD_MAC = "mac"

  private val ES_QUERY_QUERY = "query"
  private val ES_QUERY_RANGE = "range"
  private val ES_QUERY_BOOL = "bool"
  private val ES_QUERY_MUST = "must"
  private val ES_QUERY_TERMS = "terms"
  private val ES_QUERY_FILTER = "filter"
  private val ES_QUERY_GT = "gt"
  private val ES_QUERY_LTE = "lte"

  private val DATE_FORMAT = "yyMMddHHmmss"


  val esQuery: (Long, Long, Array[String]) => String = (startTime: Long, endTime: Long, places: Array[String]) => {
    if(places.isEmpty) {
      s"""{"$ES_QUERY_QUERY":{"$ES_QUERY_RANGE":{"$ES_FIELD_TIME":
         |{"$ES_QUERY_GT":$startTime,"$ES_QUERY_LTE":$endTime}}}}""".stripMargin
    } else {
      val queryHead =
        s"""{"$ES_QUERY_QUERY": {"$ES_QUERY_BOOL": {"$ES_QUERY_MUST":
           |{"$ES_QUERY_TERMS": {"$ES_FIELD_SERVICE_CODE": [""".stripMargin
      var placesStr: String = ""
      for(place: String <- places) {
        placesStr += s""""$place","""
      }
      placesStr = placesStr.substring(0, placesStr.length - 1)
      val queryTail =
        s"""]}},"$ES_QUERY_FILTER": {"$ES_QUERY_RANGE": {"$ES_FIELD_TIME":
           |{"$ES_QUERY_GT": "$startTime","$ES_QUERY_LTE": "$endTime"}}}}}}""".stripMargin

      val query = s"$queryHead$placesStr$queryTail"
      LOGGER.info(s"Builder es query. query: $query")
      query
    }

  }

  def getTimeStampAsChange(time: String, change: Long): Long = {
    val dateFormat = new SimpleDateFormat(DATE_FORMAT)
    dateFormat.parse(time).getTime/change
  }
}
