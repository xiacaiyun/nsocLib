//package cn.nsoc.pf
//
//object TestGetPlace {
//  def main(args: Array[String]): Unit = {
//    val places = Main.getPlaces("http://192.168.2.28:10007/biz/napi/internal/placeex/places", 2)
//    for(place <- places) {
//      println(place)
//    }
//  }
//
//}
