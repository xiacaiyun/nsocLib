package cn.nsoc.pf

import org.apache.log4j.Logger
import org.apache.spark.{SparkConf, SparkContext}

/**
  * Calculate floating population
  * Create by Alan 2017.11.13
  */
object Analyze{
  private val logger = Logger.getLogger("floating_population")

  def main(args: Array[String]): Unit = {
    if(args.length < 10){
      val errMsg = "Args: ESServerUrl ESIndex ESType SaveTarget StartTime EndTime Accuracy Max Min Data\n" +
        "Example: 192.168.1.121:2181 /user/save/ 1506823800 1507600800 1000 10 2 31010121140116,31010121140126"
      println(errMsg)
      logger.error(errMsg)
      throw new IllegalArgumentException(errMsg)
    }

    val elasticsearchServerUrl = args(0)
    val esIndex = args(1)
    val esType = args(2)
    val saveTarget = args(3)
    //Time to time stamp -> s
    val startTime = args(4).toLong
    val endTime = args(5).toLong
    if(startTime > endTime) {
      println(s"Start time: $startTime End time: $endTime.")
      throw new IllegalArgumentException(s"Start time: $startTime End time: $endTime.")
    }

    val accuracy = args(6).toInt
    val max = args(7).toInt
    val min = args(8).toInt
    val data = args(9)
    if(max <= 0 || min <= 0 || min > max) {
      println(s"Max: $max Min: $min.")
      throw new IllegalArgumentException(s"Max: $max Min: $min.")
    }

    var places = data.trim.split(",")
    if("ALL".equals(data.trim.toUpperCase())) {
      places = Array[String]()
    }
    logger.info(
      s"""Run floating population args:ESServerUrl=$elasticsearchServerUrl
         | ESIndex=$esIndex ESType=$esType SaveTarget=$saveTarget StartTime=$startTime EndTime=$endTime
         |  Accuracy=$accuracy Max=$max Min=$min Data=$data""".stripMargin)
    println(
      s"""Run floating population args:ESServerUrl=$elasticsearchServerUrl
         | ESIndex=$esIndex ESType=$esType SaveTarget=$saveTarget StartTime=$startTime EndTime=$endTime
         |  Accuracy=$accuracy Max=$max Min=$min Data=$data""".stripMargin)

    val conf = new SparkConf().setAppName("Floating population").set("es.nodes", elasticsearchServerUrl)
    val sc = new SparkContext(conf)
    floatingPopulation(esIndex, esType, min, max, startTime, endTime, places, accuracy, saveTarget, sc)

  }

  /**
    * Floating population count
    * @param min Min place
    * @param max Max place
    * @param startDate Start time
    * @param endDate End time
    * @param places Places
    * @param target Calculate result save target
    * @param sc SparkContext
    * @return RDD[(String, (Int, String, String))]
    */
  private def floatingPopulation(
                                  esIndex: String,
                                  esType: String,
                                  min: Int,
                                  max: Int,
                                  startDate: Long,
                                  endDate: Long,
                                  places: Array[String],
                                  accuracy: Int,
                                  target: String,
                                  sc: SparkContext): Unit= {
    import org.elasticsearch.spark._
    println("Start floating population ...")
    logger.info("Start floating population ...")
    val save = s"""$target-$startDate-$endDate"""
    val dis = (a: (String, String, String), _: (String, String, String)) => a
    //聚合函数
    val add: ((Int, String, String), (Int, String, String)) => (Int, String, String) =
      (a: (Int, String, String), b: (Int, String, String)) => (a._1 + b._1, a._2 + ":" + b._2, a._3 + ":" + b._3)
    println(s"${Define.esQuery(startDate, endDate, places)}")
    sc.esRDD(s"$esIndex/$esType", Define.esQuery(startDate, endDate, places))
      .map{
        kv =>
          val dataMap = kv._2
          val timeStamp = dataMap.get(Define.ES_FIELD_TIME)
          val serviceCode = dataMap.get(Define.ES_FIELD_SERVICE_CODE)
          val mac = dataMap.get(Define.ES_FIELD_MAC)
          (s"${timeStamp.getOrElse("0").toString.toLong/accuracy}${serviceCode.getOrElse("NULL").toString}${mac.getOrElse("NULL").toString}",
            (mac.getOrElse("NULL").toString, serviceCode.getOrElse("NULL").toString, timeStamp.getOrElse("0").toString))
      }
      .reduceByKey(dis, 300)
      .map{
        kMst =>
          val mst = kMst._2
          val mac = mst._1
          val serviceCode = mst._2
          val timeStamp = mst._3
          (mac, (1, serviceCode, timeStamp))
      }
      .reduceByKey(add, 300)
      .filter{
        v =>
          v._2._1 <= max && v._2._1 >= min
      }
      .repartition(300)
      .map{
        kv =>
          val mac = kv._1
          val cst = kv._2
          val count = cst._1
          val serviceCodes = cst._2
          val timeStamps = cst._3
          s"""$mac,$count,$serviceCodes,$timeStamps"""
      }
      .saveAsTextFile(save)
     println(s"Floating population end. result save path: $save")
  }

}
