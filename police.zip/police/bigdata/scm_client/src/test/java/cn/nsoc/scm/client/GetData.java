package cn.nsoc.scm.client;

import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClientBuilder;
import org.apache.http.util.EntityUtils;
import org.json.JSONArray;
import org.json.JSONObject;

import java.io.IOException;

public class GetData {

    public static void main(String ... args) throws IOException {
        HttpPost post = new HttpPost("http://192.168.2.28:10007/biz/napi/internal/placeex/places");
        CloseableHttpClient client = HttpClientBuilder.create().build();
        CloseableHttpResponse response = client.execute(post);
        String res = EntityUtils.toString(response.getEntity());
        JSONObject object = new JSONObject(res);
        if(object.getBoolean("ret")) {
            JSONArray array = object.getJSONArray("data");
            for(Object js: array) {
                if(js instanceof JSONObject && ((JSONObject) js).getInt("type") == 2) {
                    System.out.println(((JSONObject) js).getString("servicecode"));
                }
            }
        }
    }
}
