package cn.nsoc.scm.client;

import cn.nsoc.scm.SCMClient;
import cn.nsoc.scm.SCMResultItem;
import cn.nsoc.scm.entity.AccompanyElement;
import cn.nsoc.scm.entity.CacheServiceCode;
import cn.nsoc.scm.entity.CollisionElement;
import cn.nsoc.scm.entity.SCMReqData;
import cn.nsoc.scm.tools.Parser;
import cn.nsoc.scm.tools.SCMDefine;
import cn.nsoc.scm.tools.SCMKV;
import junit.framework.TestCase;

import java.util.List;
import java.util.Map;


public class SCMClientTest extends TestCase{
    private SCMClient client;
    private static final String HOTEL_SERVICE_CODE_URL = "http://192.168.2.28:10007/biz/napi/internal/placeex/places";

    public void setUp() throws Exception {
        super.setUp();
        client = SCMFactory.getSCMClient();
        client.init("15.17.26.18", 23333);
    }


    public void testRunCollision() {
        SCMReqData sCMReqData = new SCMReqData();
        sCMReqData.setMin(2).setType(SCMDefine.TYPE_MAC)
                .addElement(new CollisionElement()
                        .setFromTime("2017-12-10 12:00:00")
                        .setToTime("2017-12-10 13:00:00")
                        .addPlace("31010121000111"))//805000A210171106164536
                .addElement(new CollisionElement()
                        .setFromTime("2017-12-10 12:00:00")
                        .setToTime("2017-12-10 13:00:00")
                        .addPlace("31010121000111"));


//                .addElement(new CollisionElement()
//                .setFromTime("2017-11-06 16:44:00")
//                .setToTime("2017-11-06 16:47:00")
//                .addPlace("0121164047"));

//                .addPlace("0121165005")
//                .addPlace("0121161009")
//                .addElement(new CollisionElement()
//                .setFromTime("2017-10-12 08:40:00")
//                .setToTime("2017-10-12 22:47:00")
//                .addPlace("0121165003"))
//                .addElement(new CollisionElement()
//                .setFromTime("2017-10-10 08:50:00")
//                .setToTime("2017-10-12 22:57:00")
//                .addPlace("0121020129"))
//                .addElement(new CollisionElement()
//                .setFromTime("2017-10-12 08:35:00")
//                .setToTime("2017-10-12 22:37:00")
//                .addPlace("0121161009"))
//                .addElement(new CollisionElement()
//                .setFromTime("2017-10-12 08:58:00")
//                .setToTime("2017-10-12 22:50:00")
//                .addPlace("0121161015"));

        try {
            long startTestTime = System.currentTimeMillis();
            SCMResultItem result = client.runCollision(sCMReqData);
            System.out.println("testRunCollision " + result.getCookie());
            System.out.println(Parser.toJson(result));
            long endTestTime = System.currentTimeMillis();
            System.out.println("Collision time: " + (endTestTime - startTestTime)/1000D);
            //Parser.toJson(result) example : {"ret":true,"code":0,"data":[{"c_sc":3,"s_mac":["00-EC-0A-1A-3A-6A"],"s_sc":["31010121161009","31010127001411","31010121020189"]},{"c_sc":3,"s_mac":["EC-01-EE-0E-3F-B3","44-04-44-2B-BF-CE","1C-77-F6-19-16-9A"],"s_sc":["31010121165003","31010121161009","31010121161015"]},{"c_sc":5,"s_mac":["6C-72-E7-60-F5-08","50-8F-4C-6F-8B-E7"],"s_sc":["31010121165003","31010121161009","31010121020129","31010121161015","31010127001411"]},{"c_sc":3,"s_mac":["30-84-54-9E-1C-D5"],"s_sc":["31010121161015","31010127001411","31010121161009"]},{"c_sc":3,"s_mac":["38-29-5A-B6-2E-1F","54-DC-1D-3E-00-88","F4-29-81-5C-67-EC","F8-23-B2-89-AF-19","00-EC-0A-D4-7E-A3","DC-6D-CD-DC-EB-57","54-25-EA-C1-68-98","D8-9A-34-1D-6A-E3","C8-F2-30-19-4B-DA","FC-1A-11-DC-4C-15","B8-37-65-08-F3-F5"],"s_sc":["31010127001411","31010121161009","31010121165003"]},{"c_sc":3,"s_mac":["38-6E-A2-51-B9-26"],"s_sc":["31010127001411","31010121020189","31010121165003"]}]}

            List<SCMKV> kvs = result.getReduceDatas();
            for(SCMKV scmkv: kvs) {
                for(String mac: scmkv.getK()) {
                    System.out.println(mac);
                }
                for(String place: scmkv.getV()) {
                    System.out.println(place);
                }

                System.out.println("--------------");
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void testRunAccompany() {
        //"C8-94-BB-70-98-F6","6C-72-E7-60-F5-08","2C-57-31-15-AC-6E","6C-2F-2C-EF-38-42","50-8F-4C-6F-8B-E7","2C-5B-B8-03-38-8F","58-44-98-C0-8B-D3"
        SCMReqData SCMReqData = new SCMReqData();
        SCMReqData.setMax(7).setMin(1).setType(SCMDefine.TYPE_MAC)
                .addElement(new AccompanyElement()
                        .setFromTime("2017-11-06 17:00:00")
                        .setToTime("2017-11-06 20:00:00")
                        .addMac("6C-72-E7-60-F5-08"));

        try {
            SCMResultItem result = client.runAccompany(SCMReqData);
            System.out.println(result.getSourcesJson());
            System.out.println("testRunAccompany " + result.getCookie());
            System.out.println(Parser.toJson(result));
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void testRunFloatingPopulation(){
        try {
            SCMReqData SCMReqData = new SCMReqData();
            SCMReqData.setMax(100).setMin(2).setType(SCMDefine.TYPE_MAC)
                    .addElement(new CollisionElement()
                        .setFromTime("2017-10-12 00:00:00")
                        .setToTime("2017-10-12 06:00:00")
                        //.setPlaces(CacheServiceCode.getInstance(HOTEL_SERVICE_CODE_URL).getCache(SCMDefine.RETURN_HOTEL_TYPE)));
                                    .addPlace("31010121000018")
                                    .addPlace("31010121000021")
                                    .addPlace("31010121000024")
                                    .addPlace("31010121000027")
                                    .addPlace("31010121140091")
                                    .addPlace("31010121140116")
                                    .addPlace("31010121140126")
                                    .addPlace("31010121140129")
                                    .addPlace("3101012B000496")
                                    .addPlace("31010321168007"));
            long startTestTime = System.currentTimeMillis();
            SCMResultItem result = client.runFloatingPopulation(SCMReqData);
//            System.out.println(result.getSourcesJson());
            System.out.println("testRunFloatingPopulation " + result.getCookie());
            System.out.println(Parser.toJson(result));
            long endTestTime = System.currentTimeMillis();
            System.out.println("Collision time: " + (endTestTime - startTestTime)/1000D);
            //Parser.toJson(result) example : {"ret":true,"code":0,"data":[{"c_sc":3,"s_mac":["00-EC-0A-1A-3A-6A"],"s_sc":["31010121161009","31010127001411","31010121020189"]},{"c_sc":3,"s_mac":["EC-01-EE-0E-3F-B3","44-04-44-2B-BF-CE","1C-77-F6-19-16-9A"],"s_sc":["31010121165003","31010121161009","31010121161015"]},{"c_sc":5,"s_mac":["6C-72-E7-60-F5-08","50-8F-4C-6F-8B-E7"],"s_sc":["31010121165003","31010121161009","31010121020129","31010121161015","31010127001411"]},{"c_sc":3,"s_mac":["30-84-54-9E-1C-D5"],"s_sc":["31010121161015","31010127001411","31010121161009"]},{"c_sc":3,"s_mac":["38-29-5A-B6-2E-1F","54-DC-1D-3E-00-88","F4-29-81-5C-67-EC","F8-23-B2-89-AF-19","00-EC-0A-D4-7E-A3","DC-6D-CD-DC-EB-57","54-25-EA-C1-68-98","D8-9A-34-1D-6A-E3","C8-F2-30-19-4B-DA","FC-1A-11-DC-4C-15","B8-37-65-08-F3-F5"],"s_sc":["31010127001411","31010121161009","31010121165003"]},{"c_sc":3,"s_mac":["38-6E-A2-51-B9-26"],"s_sc":["31010127001411","31010121020189","31010121165003"]}]}
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void testRunResidentPopulation() {
        try {
            SCMReqData SCMReqData = new SCMReqData();
            SCMReqData.setMax(100).setMin(2).setType(SCMDefine.TYPE_PLACE)
                    .addElement(new CollisionElement()
                        .setFromTime("2017-10-12 00:00:00")
                        .setToTime("2017-10-12 22:00:00")
//                        .addPlace(""));
                        .setPlaces(CacheServiceCode.getInstance(HOTEL_SERVICE_CODE_URL).getCache(SCMDefine.RETURN_HOTEL_TYPE)));

            long startTestTime = System.currentTimeMillis();
            SCMResultItem result = client.runResidentPopulation(SCMReqData);
            System.out.println(result.getSourcesJson());
//            for(SCMKV scmkv: result.getReduceDatas()) {
//                for(String k: scmkv.getK()){
//                    System.out.print(k + "-");
//                }
//                System.out.println();
//                for(String v: scmkv.getK()){
//                    System.out.print(v + "-");
//                }
//                System.out.println();
//            }
//            System.out.println(result.getSourcesJson());
            System.out.println("testRunResidentPopulation " + result.getCookie());
            System.out.println(Parser.toJson(result));
            long endTestTime = System.currentTimeMillis();
            System.out.println("Collision time: " + (endTestTime - startTestTime)/1000D);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }


    public void testRunForecasting() {
        try {
            SCMReqData SCMReqData = new SCMReqData();
            SCMReqData.setMax(10).setMin(2).setType("gap_total")
                    .addElement(new CollisionElement()
                            .setFromTime("2017-11-06 00:00:00")
                            .setToTime("2017-11-06 23:59:00")
                            .addPlace("31010121161001")
                            .addPlace("31010121161013")
                            .addPlace("31010127000661")
                            .addPlace("31010127001290")
                            .addPlace("31010127002131")
                            .addPlace("31010128000631")
                            .addPlace("3101012A000462")
                            .addPlace("3101012A000846")
                            .addPlace("3101012A002449")
                            .addPlace("3101012A002455")
                            .addPlace("31010321180001")
                            .addPlace("31010321180024"));


            long startTestTime = System.currentTimeMillis();
            SCMResultForecasting result = client.runForecasting(SCMReqData);
            System.out.println(result.getSourcesJson());
            System.out.println("testRunResidentPopulation " + result.getCookie());
            for(Map.Entry<Long, Double> entry: result.getForecastingData().entrySet()) {
                System.out.println(entry.getKey() + "," + entry.getValue());
            }
            long endTestTime = System.currentTimeMillis();
            System.out.println("Calculate time: " + (endTestTime - startTestTime)/1000D);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

}
