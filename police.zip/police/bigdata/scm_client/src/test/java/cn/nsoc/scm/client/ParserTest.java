package cn.nsoc.scm.client;

import cn.nsoc.scm.SCMElement;
import cn.nsoc.scm.entity.CollisionElement;
import cn.nsoc.scm.entity.SCMReqData;
import cn.nsoc.scm.tools.Parser;
import junit.framework.TestCase;

import java.util.ArrayList;
import java.util.List;

public class ParserTest extends TestCase {
    public void setUp() throws Exception {
        super.setUp();
    }

    public void testToJson1() {
        SCMReqData SCMReqData = new SCMReqData();
        SCMReqData.setMax(3);
        SCMReqData.setMin(2);
        SCMReqData.setType("mac");
        List<SCMElement> yuanData = new ArrayList<>();
        List<String> places1 = new ArrayList<>();
        places1.add("12333");
        places1.add("12344");
        List<String> places2 = new ArrayList<>();
        places2.add("321");
        places2.add("456");
        yuanData.add(new CollisionElement("2017-12-23 14:12:11", "2017-12-25 14:12:11", places1));
        yuanData.add(new CollisionElement("2017-12-26 14:12:11", "2017-12-27 14:12:11", places2));
        SCMReqData.setElements(yuanData);

        System.out.println(Parser.toJson(SCMReqData));
    }

    public void testToJson2() {
        System.out.println("eeew1".hashCode() + " " + "eeew1".hashCode());
    }
}
