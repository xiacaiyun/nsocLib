package cn.nsoc.scm.client;

import cn.nsoc.scm.SCMResultData;
import cn.nsoc.scm.tools.SCMDefine;
import org.json.JSONObject;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class SCMResultKPlaceData implements SCMResultData {
    private JSONObject jsonObject;

    SCMResultKPlaceData(JSONObject jsonObject) {
        this.jsonObject = jsonObject;
    }

    @Override
    public int getTotal() throws IOException {
        return jsonObject.getInt(SCMDefine.COUNT_PLACE_NAME);
    }

    @Override
    public String getKey() throws IOException {
        return jsonObject.getString(SCMDefine.PLACE_NAME);
    }

    @Override
    public List<String> getValues() throws IOException {
        List<String> places = new ArrayList<>();
        for(Object obj: jsonObject.getJSONArray(SCMDefine.PLACE_INFO_NAME)) {
            if(obj instanceof JSONObject) {
                JSONObject jso = ((JSONObject) obj);
                if(!jso.isNull(SCMDefine.MAC_NAME)) {
                    String place = ((JSONObject) obj).getString(SCMDefine.MAC_NAME);
                    places.add(place);
                }
            }
        }
        return places;
    }

    @Override
    public long getHashCount() {
        StringBuilder sb = new StringBuilder();
        for(Object obj: jsonObject.getJSONArray(SCMDefine.PLACE_INFO_NAME)) {
            if(obj instanceof JSONObject) {
                String place = ((JSONObject) obj).getString(SCMDefine.PLACE_NAME);
                sb.append(place);
            }
        }
        return sb.toString().hashCode();
    }

}
