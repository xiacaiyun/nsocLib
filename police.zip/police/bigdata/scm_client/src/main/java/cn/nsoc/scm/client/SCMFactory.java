package cn.nsoc.scm.client;

/**
 * SCM client factory
 */
public class SCMFactory {

    /**
     * Get scm client
     * @return SCMClient
     */
    public synchronized static cn.nsoc.scm.SCMClient getSCMClient() {
        return new cn.nsoc.scm.client.SCMClient();
    }
}
