package cn.nsoc.scm;

import cn.nsoc.scm.tools.SCMKV;

import java.io.IOException;
import java.util.List;

/**
 * Define result data
 * Create by Alan 2017.10.19
 */
public interface SCMResultItem {
    /**
     * Get response code
     * 0: success
     * 1: fail
     * 2: error
     * @return Response code
     * @throws IOException io exception
     */
    int getResponseCode() throws IOException;

    /**
     * Judgment request is success
     * success: true
     * fail: false
     * @return Is success
     * @throws IOException io exception
     */
    boolean isSuccess() throws IOException;

    /**
     * Get message
     * @return Message
     * @throws IOException io exception
     */
    String getMessage() throws IOException;

    /**
     * Get cookie
     * @return cookie
     * @throws IOException io exception
     */
    int getCookie() throws IOException;

    /**
     * Get type default: mac
     * @return Type
     * @throws IOException io exception
     */
    String getType() throws IOException;

    /**
     * Get result data
     * @return SCMResultData list
     * @throws IOException io exception
     */
    List<SCMResultData> getResultData() throws IOException;

    /**
     * Get reduce result data
     * 聚合去过相同地点的mac 不同的地点组合为不同的SCMKV[K:mac集合 V:地点集合]
     * example:SCMKV1[K:mac1,mac2 V:place1,place2] SCMKV1[K:mac1,mac2,mac3 V:place1,place2,place3]
     * @return SCMResultData list
     * @throws IOException io exception
     */
    List<SCMKV> getReduceDatas() throws IOException;

    /**
     * Get source json
     * @return source json
     */
    String getSourcesJson();
}
