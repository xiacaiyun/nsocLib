package cn.nsoc.scm.client;

import cn.nsoc.scm.tools.SCMDefine;
import org.json.JSONArray;
import org.json.JSONObject;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
import java.util.TreeMap;

public class SCMResultForecasting {

    private JSONObject jsonObject;
    private String sourcesJson = "";

    SCMResultForecasting(String json){
        sourcesJson = json;
        if(json == null || json.length() == 0) throw new NullPointerException();
        jsonObject = new JSONObject(json);
    }

    public int getResponseCode() throws IOException {
        return jsonObject.getInt(SCMDefine.RESPONSE_CODE_NAME);
    }

    public boolean isSuccess() throws IOException {
        return getResponseCode() == 0;
    }

    public String getMessage() throws IOException {
        return jsonObject.getString(SCMDefine.MSG_NAME);
    }

    public int getCookie() throws IOException {
        return jsonObject.getInt(SCMDefine.COOKIE_NAME);
    }

    public String getType() throws IOException {
        return jsonObject.getString(SCMDefine.TYPE_NAME);
    }

    public String getSourcesJson() {
        return sourcesJson;
    }

    public Map<Long, Double> getForecastingData() {
        JSONArray array = jsonObject.getJSONArray(SCMDefine.RESULT_ARRAY_NAME);
        Map<Long, Double> result = new TreeMap<>();
        for(Object o: array) {
            if(o instanceof JSONObject) {
                result.put(((JSONObject) o).getLong(SCMDefine.FORECASTING_RETURN_TIMESTAMP),
                        ((JSONObject) o).getDouble(SCMDefine.FORECASTING_RETURN_COUNT));
            }
        }

        return result;
    }
}
