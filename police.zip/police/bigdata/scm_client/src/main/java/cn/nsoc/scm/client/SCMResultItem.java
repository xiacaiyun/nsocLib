package cn.nsoc.scm.client;

import cn.nsoc.scm.SCMResultData;
import cn.nsoc.scm.tools.SCMDefine;
import cn.nsoc.scm.tools.SCMKV;
import org.json.JSONArray;
import org.json.JSONObject;
import sun.reflect.generics.reflectiveObjects.NotImplementedException;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

class SCMResultItem implements cn.nsoc.scm.SCMResultItem {

    private JSONObject jsonObject;
    private String sourcesJson = "";

    SCMResultItem(String json){
        sourcesJson = json;
        if(json == null || json.length() == 0) throw new NullPointerException();
        jsonObject = new JSONObject(json);
    }

    @Override
    public int getResponseCode() throws IOException {
        return jsonObject.getInt(SCMDefine.RESPONSE_CODE_NAME);
    }

    @Override
    public boolean isSuccess() throws IOException {
        return getResponseCode() == 0;
    }

    @Override
    public String getMessage() throws IOException {
        return jsonObject.getString(SCMDefine.MSG_NAME);
    }

    @Override
    public int getCookie() throws IOException {
        return jsonObject.getInt(SCMDefine.COOKIE_NAME);
    }

    @Override
    public String getType() throws IOException {
        return jsonObject.getString(SCMDefine.TYPE_NAME);
    }

    @Override
    public List<SCMResultData> getResultData() throws IOException {
        JSONArray array = jsonObject.getJSONArray(SCMDefine.RESULT_ARRAY_NAME);
        List<SCMResultData> r = new ArrayList<>();
        if(SCMDefine.TYPE_PLACE.equals(getType())) {
            for(Object obj: array) {
                if(obj instanceof JSONObject) {
                    r.add(new SCMResultKPlaceData((JSONObject) obj));
                }
            }
        } else {
            for(Object obj: array) {
                if(obj instanceof JSONObject) {
                    r.add(new SCMResultKMacData((JSONObject) obj));
                }
            }
        }
        return r;
    }

    @Override
    public List<SCMKV> getReduceDatas() throws IOException {
        if(SCMDefine.TYPE_PLACE.equals(getType())) throw new NotImplementedException();

        List<SCMResultData> datas = getResultData();
        if(datas == null) throw new NullPointerException();

        Map<Long, SCMKV> reduceMap = new HashMap<>();

        //将地点相同的mac聚合
        for(SCMResultData resultData: datas) {
            SCMKV macPlace = reduceMap.get(resultData.getHashCount());
            if(macPlace == null) {
                SCMKV scmkv = new SCMKV();

                scmkv.getK().add(resultData.getKey());
                for(String place: resultData.getValues()) {
                    scmkv.getV().add(place);
                }
                reduceMap.put(resultData.getHashCount(), scmkv);
            } else {
                macPlace.getK().add(resultData.getKey());
            }
        }
        List<SCMKV> scmkvs = new ArrayList<>();
        for(Map.Entry<Long, SCMKV> entry: reduceMap.entrySet()) {
            scmkvs.add(entry.getValue());
        }
        return scmkvs;
    }

    @Override
    public String getSourcesJson() {
        return sourcesJson;
    }
}
