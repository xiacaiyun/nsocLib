package cn.nsoc.scm.client;

import cn.nsoc.base.entity.sys.NSException;
import cn.nsoc.scm.SCMResultItem;
import cn.nsoc.scm.entity.SCMReqData;
import cn.nsoc.scm.tools.Parser;
import cn.nsoc.scm.tools.SCMUtils;
import org.apache.http.NameValuePair;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClientBuilder;
import org.apache.http.message.BasicNameValuePair;
import org.apache.http.util.EntityUtils;
import org.apache.log4j.Logger;
import org.json.JSONException;

import java.io.IOException;
import java.net.URI;
import java.util.ArrayList;
import java.util.List;

/**
 * Scm client implements
 * Create by Alan 2017.10.18
 */
public class SCMClient implements cn.nsoc.scm.SCMClient {
    private static final Logger LOGGER = Logger.getLogger("SCMClient");

    private HttpPost post;
    private CloseableHttpClient client;
    private static final String COLLISION_REQUEST_OP = "collision";
    private static final String ACCOMPANY_REQUEST_OP = "accompany";
    private static final String RESIDENT_POPULATION_REQUEST_OP = "residentPopulation";
    private static final String FORECASTING_REQUEST_OP = "forecasting";
    private static final String FLOATING_POPULATION_REQUEST_OP = "floatingPopulation";
    private static final String HTTP_START = "http://";
    private String ip;
    private int port;


    @Override
    public void init(String ip, int port) throws NSException {
        if (SCMUtils.isNull(ip)) {
            throw new NullPointerException(String.format("Ip is null or \"\" is: %s", ip));
        }

        if (!SCMUtils.isPort(port)) {
            throw new IllegalArgumentException(String.format("Port is %d", port));
        }

        this.ip = ip;
        this.port = port;
        post = new HttpPost();
        client = HttpClientBuilder.create().build();
    }

    @Override
    public SCMResultItem runAccompany(SCMReqData data) throws NSException {
        String requestJson;
        String resJson = "";
        cn.nsoc.scm.SCMResultItem item;
        try {
            requestJson = Parser.toJsonAsAccompany(data);
            LOGGER.debug(String.format("Run accompany. Request json: %s", requestJson));
            resJson = send(requestJson, ACCOMPANY_REQUEST_OP, "/spark/analysis/accompany");
            LOGGER.debug(String.format("Run accompany. Response json: %s", resJson));
            item = new cn.nsoc.scm.client.SCMResultItem(resJson);
            checkCookie(data.getCookie(), item.getCookie());
        } catch (JSONException | IOException e) {
            LOGGER.error(String.format("Response: %s", resJson), e);
            throw new NSException(String.format("Response: %s Exception: %s", resJson, e.getMessage()));
        }

        return item;
    }

    @Override
    public SCMResultItem runCollision(SCMReqData data) throws NSException {
        String requestJson;
        String resJson = "";
        cn.nsoc.scm.SCMResultItem item;
        try {
            requestJson = Parser.toJsonAsCollision(data);
            LOGGER.debug(String.format("Run collision. Request json: %s", requestJson));
            resJson = send(requestJson, COLLISION_REQUEST_OP, "/spark/analysis/collision");
            LOGGER.debug(String.format("Run collision. Response json: %s", resJson));
            item = new cn.nsoc.scm.client.SCMResultItem(resJson);

            checkCookie(data.getCookie(), item.getCookie());
        } catch (JSONException | IOException e) {
            LOGGER.error(String.format("Response: %s", resJson), e);
            throw new NSException(String.format("Response: %s Exception: %s", resJson, e.getMessage()));
        }

        return item;
    }

    @Override
    public SCMResultItem runFloatingPopulation(SCMReqData data) throws NSException {
        String requestJson;
        String resJson = "";
        cn.nsoc.scm.SCMResultItem item;
        try {
            requestJson = Parser.toJsonAsCollision(data);
            LOGGER.debug(String.format("Run floating population. Request json: %s", requestJson));
            resJson = send(requestJson, FLOATING_POPULATION_REQUEST_OP, "/spark/analysis/floating");
            LOGGER.debug(String.format("Run floating population. Response json: %s", resJson));
            item = new cn.nsoc.scm.client.SCMResultItem(resJson);

            checkCookie(data.getCookie(), item.getCookie());
        } catch (JSONException | IOException e) {
            LOGGER.error(String.format("Response: %s", resJson), e);
            throw new NSException(String.format("Response: %s Exception: %s", resJson, e.getMessage()));
        }
        return item;
    }

    @Override
    public SCMResultItem runResidentPopulation(SCMReqData data) throws NSException {
        String requestJson;
        String resJson = "";
        cn.nsoc.scm.SCMResultItem item;
        try {
            requestJson = Parser.toJsonAsCollision(data);
            LOGGER.debug(String.format("Run resident population. Request json: %s", requestJson));
            resJson = send(requestJson, RESIDENT_POPULATION_REQUEST_OP, "/spark/analysis/resident");
            LOGGER.debug(String.format("Run resident population. Response json: %s", resJson));
            item = new cn.nsoc.scm.client.SCMResultItem(resJson);

            checkCookie(data.getCookie(), item.getCookie());
        } catch (JSONException | IOException e) {
            LOGGER.error(String.format("Response: %s", resJson), e);
            throw new NSException(String.format("Response: %s Exception: %s", resJson, e.getMessage()));
        }

        return item;
    }

    @Override
    public SCMResultForecasting runForecasting(SCMReqData data) throws NSException {
        String requestJson;
        String resJson = "";
        SCMResultForecasting forecasting;
        try {
            requestJson = Parser.toJsonAsCollision(data);
            LOGGER.debug(String.format("Run forecasting. Request json: %s", requestJson));
            resJson = send(requestJson, FORECASTING_REQUEST_OP, "/spark/analysis/forecasting");
            LOGGER.debug(String.format("Run forecasting. Response json: %s", resJson));
            forecasting = new SCMResultForecasting(resJson);
            checkCookie(data.getCookie(), forecasting.getCookie());
        } catch (JSONException | IOException e) {
            LOGGER.error(String.format("Response: %s", resJson), e);
            throw new NSException(String.format("Response: %s Exception: %s", resJson, e.getMessage()));
        }

        return forecasting;
    }

    /**
     * Send request
     *
     * @param requestJson Request json
     * @param op          option
     * @return Json string
     * @throws IOException io exception
     */
    private String send(String requestJson, String op, String uri) throws IOException {
        if (this.post == null) {
            LOGGER.error("RequestPost is null. You must first run init.");
            throw new NullPointerException("RequestPost is null. You must first run init.");
        }
        if (requestJson == null || requestJson.length() == 0) {
            LOGGER.error("Request json is null.");
            throw new NullPointerException("Request json is null.");
        }
        LOGGER.debug(String.format("Run send. Send json: %s. Send op: %s", requestJson, op));
        List<NameValuePair> nameValuePairs = new ArrayList<>();
        nameValuePairs.add(new BasicNameValuePair("op", op));
        nameValuePairs.add(new BasicNameValuePair("requestJson", requestJson));
        post.setURI(URI.create(getUrl(ip, port, uri)));
        post.setEntity(new UrlEncodedFormEntity(nameValuePairs));
        LOGGER.debug(String.format("Post : %s", EntityUtils.toString(post.getEntity())));
        try (CloseableHttpResponse response = client.execute(post)) {
            return EntityUtils.toString(response.getEntity());
        }

    }

    /**
     * Get request url
     *
     * @param ip   ip
     * @param port port
     * @return url
     */
    private String getUrl(String ip, int port, String resources) {
        return String.format("%s%s:%d%s", HTTP_START, ip, port, resources);
    }

    /**
     * Check cookie is equals
     *
     * @param reqCookie Request cookie
     * @param resCookie Response cookie
     */
    private void checkCookie(int reqCookie, int resCookie) throws NSException {
        if (reqCookie != resCookie) {
            throw new NSException(
                    String.format("Request cookie not equals response cookie. Request cookie: %d Response cookie: %d",
                            reqCookie, resCookie));
        }
    }


}
