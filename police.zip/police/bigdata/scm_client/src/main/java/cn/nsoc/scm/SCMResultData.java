package cn.nsoc.scm;

import java.io.IOException;
import java.util.List;

/**
 * Define result data
 * Create by Alan 2017.10.18
 */
public interface SCMResultData {

    /**
     * Get hash count by places list
     * @return Hash count
     */
    long getHashCount();

    /**
     * Get place total
     * @return Place total
     * @throws IOException io exception
     */
    int getTotal() throws IOException;

    /**
     * Get mac
     * @return Mac
     * @throws IOException io exception
     */
    String getKey() throws IOException;

    /**
     * get places
     * @return Places list
     * @throws IOException io exception
     */
    List<String> getValues() throws IOException;
}
