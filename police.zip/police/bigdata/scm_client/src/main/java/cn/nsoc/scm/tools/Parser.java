package cn.nsoc.scm.tools;

import cn.nsoc.scm.SCMResultData;
import cn.nsoc.scm.SCMResultItem;
import cn.nsoc.scm.SCMElement;
import cn.nsoc.scm.entity.AccompanyElement;
import cn.nsoc.scm.entity.SCMReqData;
import cn.nsoc.scm.entity.CollisionElement;
import org.json.JSONArray;
import org.json.JSONObject;

import java.io.IOException;
import java.util.*;

/**
 * Parser
 * Create by Alan 2017.10.23
 */
public class Parser {
    /**
     * SCMReqData to json
     * @param data SCMReqData
     * @return json
     */
    public static synchronized String toJsonAsCollision(SCMReqData data) throws NullPointerException {
        if(data == null) throw new NullPointerException();
        JSONObject jsonObject = new JSONObject();
        jsonObject.put(SCMDefine.MAX, data.getMax());
        jsonObject.put(SCMDefine.MIN, data.getMin());
        jsonObject.put(SCMDefine.TYPE, data.getType());
        jsonObject.put(SCMDefine.COOKIE, data.getCookie());

        //Return info
        JSONArray jsonArray = new JSONArray();
        for(SCMElement SCMElement : data.getElements()) {
            JSONObject yuanJson = new JSONObject();
            yuanJson.put(SCMDefine.FROM_TIME, SCMElement.getFromTime());
            yuanJson.put(SCMDefine.TO_TIME, SCMElement.getToTime());
            JSONArray placesJson = new JSONArray();

            for(String place: SCMElement.getPlaces()) {
                placesJson.put(place);
            }

            yuanJson.put(SCMDefine.PLACE_NAME, placesJson);
            jsonArray.put(yuanJson);
        }

        jsonObject.put(SCMDefine.PARAM, jsonArray);

        return jsonObject.toString();
    }

    /**
     * SCMReqData to json
     * @param data SCMReqData
     * @return json
     */
    public static synchronized String toJsonAsAccompany(SCMReqData data) throws NullPointerException {
        if(data == null) throw new NullPointerException();
        JSONObject jsonObject = new JSONObject();
        jsonObject.put(SCMDefine.MAX, data.getMax());
        jsonObject.put(SCMDefine.MIN, data.getMin());
        jsonObject.put(SCMDefine.TYPE, data.getType());
        jsonObject.put(SCMDefine.COOKIE, data.getCookie());
        if(data.getElements() != null && data.getElements().size() > 0) {
            AccompanyElement element = (AccompanyElement)data.getElements().get(0);
            jsonObject.put(SCMDefine.FROM_TIME, element.getFromTime());
            jsonObject.put(SCMDefine.TO_TIME, element.getToTime());
            jsonObject.put(SCMDefine.MAC_NAME, element.getMac());
        }

        return jsonObject.toString();
    }

    /**
     * SCMResultItem to json
     * @param item SCMResultItem
     * @return json
     * @throws IOException io exception
     */
    public static synchronized String toJsonAsCollision(SCMResultItem item) throws IOException {
        if(item == null) throw new NullPointerException();

        JSONObject jsonObject = new JSONObject();

        jsonObject.put(SCMDefine.RETURN_RET, item.isSuccess())
                .put(SCMDefine.RETURN_CODE, item.getResponseCode());

        //如果计算成功,则返回计算好的mac和地点信息，否则返回错误信息
        if(item.isSuccess()) {
            JSONArray data = new JSONArray();
            if(SCMDefine.TYPE_PLACE.equals(item.getType())) {
                for(SCMResultData resultData: item.getResultData()) {
                    JSONObject dataJson = new JSONObject();
                    dataJson.put(SCMDefine.RETURN_C_MC, resultData.getTotal())
                            .put(SCMDefine.RETURN_S_PLACE, resultData.getKey())
                            .put(SCMDefine.RETURN_S_MC, reduce(resultData.getValues(), 1));
                    data.put(dataJson);
                }
            } else {
                for(Map.Entry<Long, SCMKV> entry: reduce(item.getResultData()).entrySet()) {
                    SCMKV scmkv = entry.getValue();
                    JSONObject dataJson = new JSONObject();
                    dataJson.put(SCMDefine.RETURN_C_SC, scmkv.getV().size())
                            .put(SCMDefine.RETURN_S_MAC, scmkv.getK())
                            .put(SCMDefine.RETURN_S_SC, scmkv.getV());
                    data.put(dataJson);
                }
            }

            jsonObject.put(SCMDefine.RETURN_DATA, data);
        } else {
            jsonObject.put(SCMDefine.MSG_NAME, item.getMessage());
        }

        return jsonObject.toString();
    }

    /**
     * Reduce method
     * @param datas SCMResultData list
     * @return Reduce map
     * @throws IOException io exception
     */
    private static Map<Long, SCMKV> reduce(List<SCMResultData> datas) throws IOException {
        if(datas == null) throw new NullPointerException();

        Map<Long, SCMKV> reduceMap = new HashMap<>();

        //将地点相同的mac聚合
        for(SCMResultData resultData: datas) {
            SCMKV macPlace = reduceMap.get(resultData.getHashCount());
            if(macPlace == null) {
                SCMKV scmkv = new SCMKV();

                scmkv.getK().add(resultData.getKey());
                for(String place: resultData.getValues()) {
                    scmkv.getV().add(place);
                }

                reduceMap.put(resultData.getHashCount(), scmkv);
            } else {
                macPlace.getK().add(resultData.getKey());
            }
        }
        return reduceMap;
    }


    private static List<JSONObject> reduce(List<String> stringList, int c) {
        Map<String, JSONObject> reduceMap = new Hashtable<>();
        for(String s: stringList) {
            JSONObject value = reduceMap.get(s);
            if(value == null) {
                reduceMap.put(s, new JSONObject().put(SCMDefine.MAC_NAME, s).put(SCMDefine.COUNT_MAC_NAME, c));
            } else {
                int count = value.getInt(SCMDefine.COUNT_MAC_NAME) + c;
                value.put(SCMDefine.COUNT_MAC_NAME, count);
            }
        }

        return new ArrayList<>(reduceMap.values());
    }
}
