package cn.nsoc.scm.entity;

import cn.nsoc.scm.SCMElement;
import cn.nsoc.scm.tools.SCMUtils;

import java.util.ArrayList;
import java.util.List;

/**
 * Define collision data
 * Create by Alan 2017.10.21
 */
public class SCMReqData {
    private int max = 0;
    private int min;
    private int cookie = -1;
    private String type;
    private List<SCMElement> yuanData;

    public SCMReqData() {
        yuanData = new ArrayList<>();
    }

    public int getMax() {
        if(max == 0) {
            for(SCMElement yd: this.yuanData) {
                max += yd.getPlaces().size();
            }
        }
        return max;
    }

    public int getMin() {
        return min;
    }

    public String getType() {
        return type;
    }

    public List<SCMElement> getElements() {
        return yuanData;
    }

    public SCMReqData setMax(int max) throws IndexOutOfBoundsException{
        if(max <= 0) throw new IndexOutOfBoundsException("max mast > 0");
//        if(min > 0 && min > max) throw new IndexOutOfBoundsException("max mast > min");
        this.max = max;
        return this;
    }

    public SCMReqData setMin(int min) {
        if(min <= 0) throw new IndexOutOfBoundsException("min mast > 0");
//        if(max > 0 && max < min) throw new IndexOutOfBoundsException("max mast > min");
        this.min = min;
        return this;
    }

    public SCMReqData setType(String type) {
        this.type = type;
        return this;
    }

    public SCMReqData setElements(List<SCMElement> SCMElements) {
        this.yuanData = SCMElements;
        return this;
    }

    public SCMReqData addElement(SCMElement SCMElement) {
        this.yuanData.add(SCMElement);
        return this;
    }

    public void setCookie(int cookie) {
        this.cookie = cookie;
    }

    public int getCookie() {
        if(cookie == -1) {
            cookie = SCMUtils.cookie();
        }
        return this.cookie;
    }
}
