package cn.nsoc.scm.entity;

import cn.nsoc.scm.SCMElement;
import sun.reflect.generics.reflectiveObjects.NotImplementedException;

import java.util.ArrayList;
import java.util.List;

/**
 * 碰撞元数据,格式（fromtime,totime,places[]）
 * Create by Alan 2017.10.21
 */
public class CollisionElement implements SCMElement {
    private String fromTime;
    private String toTime;
    private List<String> places;

    public CollisionElement() {
        places = new ArrayList<>();
    }

    public CollisionElement(String fromTime, String toTime, List<String> places){
        this.fromTime = fromTime;
        this.toTime = toTime;
        this.places = places;
    }

    public List<String> getPlaces() {
        return places;
    }

    @Override
    public String getMac() throws NotImplementedException {
        throw new NotImplementedException();
    }

    public String getFromTime() {
        return fromTime;
    }

    public String getToTime() {
        return toTime;
    }

    public CollisionElement setFromTime(String fromTime) {
        this.fromTime = fromTime;
        return this;
    }

    @Override
    public SCMElement setMac(String mac) throws NotImplementedException{
        throw new NotImplementedException();
    }


    public CollisionElement setPlaces(List<String> places) {
        this.places = places;
        return this;
    }

    public CollisionElement setToTime(String toTime) {
        this.toTime = toTime;
        return this;
    }

    public CollisionElement addPlace(String place) {
        this.places.add(place);
        return this;
    }

}
