package cn.nsoc.scm.tools;

public class SCMUtils {
    private static final int PORT_MAX = 65535;
    private static final int PORT_MIN = 1024;
    private static volatile int cookie = 0;

    public static boolean isNull(String str) {
        return str == null || str.length() == 0;
    }

    public static boolean isPort(int port) {
        return port <= PORT_MAX && port > PORT_MIN;
    }

    public static synchronized int cookie(){
        if(cookie > 100000) {
            cookie = 0;
        }
        ++ cookie;
        return cookie;
    }

}
