package cn.nsoc.scm.tools;

public class SCMDefine {
    public static final String COUNT_PLACE_NAME = "total";
    public static final String COUNT_MAC_NAME = "count";
    public static final String MAC_NAME = "mac";
    public static final String PLACE_INFO_NAME = "pt";
    public static final String PLACE_NAME = "place";
    public static final String TIME_NAME = "time";
    public static final String RESPONSE_CODE_NAME = "responseCode";
    public static final String MSG_NAME = "msg";
    public static final String COOKIE_NAME = "cookie";
    public static final String TYPE_NAME = "type";
    public static final String RESULT_ARRAY_NAME = "hits";

    public static final String MAX = "max";
    public static final String MIN = "min";
    public static final String COOKIE = "cookie";
    public static final String TYPE = "type";
    public static final String TYPE_MAC = "mac";
    public static final String TYPE_PLACE = "place";
    public static final String PARAM = "param";

    public static final String FROM_TIME = "fromtime";
    public static final String TO_TIME = "totime";
    public static final String FORECASTING_RETURN_TIMESTAMP = "time";
    public static final String FORECASTING_RETURN_COUNT = "count";

    public static final String RETURN_RET = "ret";
    public static final String RETURN_DATA = "data";
    public static final String RETURN_C_SC = "c_sc";
    public static final String RETURN_C_MC = "c_mc";
    public static final String RETURN_S_MAC = "s_mac";
    public static final String RETURN_S_PLACE = "s_place";
    public static final String RETURN_S_SC = "s_sc";
    public static final String RETURN_S_MC = "s_mc";
    public static final String RETURN_CODE = "code";
    public static final String RETURN_SERVICE_CODE = "servicecode";

    public static final int RETURN_WANGBA_TYPE = 1;
    public static final int RETURN_HOTEL_TYPE = 2;
    public static final int RETURN_XIUTAN_TYPE = 3;

}
