package cn.nsoc.scm.tools;

import java.util.ArrayList;
import java.util.List;

/**
 * scm kv use reduce
 * Create by Alan 2017.10.21
 */
public class SCMKV {
    private List<String> k = new ArrayList<>();
    private List<String> v = new ArrayList<>();

    /**
     * Key list
     * @return Key list
     */
     public List<String> getK() {
        return k;
    }

    /**
     * Values list
     * @return Values list
     */
     public List<String> getV() {
        return v;
    }
}
