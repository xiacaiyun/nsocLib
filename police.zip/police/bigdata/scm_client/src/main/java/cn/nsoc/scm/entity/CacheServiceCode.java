package cn.nsoc.scm.entity;

import cn.nsoc.scm.tools.SCMDefine;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClientBuilder;
import org.apache.http.util.EntityUtils;
import org.apache.log4j.Logger;
import org.json.JSONArray;
import org.json.JSONObject;

import java.io.IOException;
import java.util.Hashtable;
import java.util.Map;
import java.util.Vector;

/**
 * Cache service code
 * WangBa Hotel XiuTan
 * Create by Alan 2017.11.07
 */
public class CacheServiceCode {
    private static final Logger LOGGER = Logger.getLogger("CacheServiceCode");
    private static final long halfDay = 43200000;
    private static CacheServiceCode csc = null;
    private Map<Integer, Vector<String>> cache;
    private long updateDateTime;
    private HttpPost post;
    private CloseableHttpClient client;
    private String url;

    /**
     * Builder Cache
     * @param url Service code server url
     * @throws IOException IOException
     */
    private CacheServiceCode(String url) throws IOException {
        post = new HttpPost(url);
        this.url = url;
        client = HttpClientBuilder.create().build();
        cache = cache();
        this.updateDateTime = System.currentTimeMillis();
    }

    /**
     * Get CacheServiceCode singleton instance
     * @param url Service code server url
     * @return CacheServiceCode Object
     * @throws IOException IOException
     */
    public static CacheServiceCode getInstance(String url) throws IOException {
        if(csc == null) {
            synchronized (CacheServiceCode.class) {
                if(csc == null) {
                    csc = new CacheServiceCode(url);
                }
            }
        }
        LOGGER.debug(String.format("Get instance %s", csc));
        return csc;
    }

    /**
     * Get update time
     * @return time
     */
    public long getUpdateDateTime() {
        return updateDateTime;
    }

    /**
     * Get cache
     * @param type Example: Hotel -> 2
     * @return Cache vector
     * @throws IOException IOException
     */
    public Vector<String> getCache(int type) throws IOException {
        long nowDate = System.currentTimeMillis();
        Map<Integer, Vector<String>> serviceCodes = new Hashtable<>();
        if(nowDate - halfDay > this.updateDateTime) {
            try {
                serviceCodes = cache();
            } catch (IOException e) {
                if(!this.cache.isEmpty()) {
                    LOGGER.warn(String.format("%s. %s. Cache map not update.", e.getMessage(), this.url));
                } else {
                    LOGGER.error(String.format("%s. %s. Cache map is empty, you must update.", e.getMessage(), this.url));
                    throw e;
                }
            }
        }

        if(!serviceCodes.isEmpty()) {
           this.cache = serviceCodes;
           this.updateDateTime = nowDate;
        }
        return this.cache.get(type);
    }

    /**
     * Cache method
     * @return Map[Type -> Cache]
     * @throws IOException IOException
     */
    private Map<Integer, Vector<String>> cache() throws IOException {
        Map<Integer, Vector<String>> tmpCache = new Hashtable<>();
        CloseableHttpResponse response = client.execute(post);
        String res = EntityUtils.toString(response.getEntity());
        JSONObject object = new JSONObject(res);
        if(object.getBoolean(SCMDefine.RETURN_RET)) {
            JSONArray array = object.getJSONArray(SCMDefine.RETURN_DATA);
            for(Object js: array) {
                if(js instanceof JSONObject) {
                    int type = ((JSONObject) js).getInt(SCMDefine.TYPE);
                    if(tmpCache.get(type) == null) {
                        Vector<String> services = new Vector<>();
                        services.add(((JSONObject) js).getString(SCMDefine.RETURN_SERVICE_CODE));
                        tmpCache.put(type, services);
                    } else {
                        tmpCache.get(type).add(((JSONObject) js).getString(SCMDefine.RETURN_SERVICE_CODE));
                    }
                }
            }
        }
        return tmpCache;
    }


}
