package cn.nsoc.scm.entity;

import cn.nsoc.scm.SCMElement;
import sun.reflect.generics.reflectiveObjects.NotImplementedException;

import java.util.List;

public class AccompanyElement implements SCMElement {
    private String fromTime;
    private String toTime;
    private String mac;

    public AccompanyElement() {
    }

    public AccompanyElement(String fromTime, String toTime, String mac){
        this.fromTime = fromTime;
        this.toTime = toTime;
        this.mac = mac;
    }

    public String getMac() {
        return mac;
    }

    public String getFromTime() {
        return fromTime;
    }

    public String getToTime() {
        return toTime;
    }

    @Override
    public List<String> getPlaces() throws NotImplementedException {
        throw new NotImplementedException();
    }

    public AccompanyElement setFromTime(String fromTime) {
        this.fromTime = fromTime;
        return this;
    }

    public AccompanyElement setMac(String mac) {
        this.mac = mac;
        return this;
    }

    @Override
    public SCMElement setPlaces(List<String> mac) throws NotImplementedException{
        throw new NotImplementedException();
    }

    public AccompanyElement setToTime(String toTime) {
        this.toTime = toTime;
        return this;
    }


    @Override
    public SCMElement addPlace(String mac) throws NotImplementedException {
        throw new NotImplementedException();
    }
}
