package cn.nsoc.scm;


import sun.reflect.generics.reflectiveObjects.NotImplementedException;

import java.util.List;

public interface SCMElement {

    String getMac() throws NotImplementedException;

    String getFromTime();

    String getToTime();

    List<String> getPlaces() throws NotImplementedException;

    SCMElement setFromTime(String fromTime);

    SCMElement setMac(String mac);

    SCMElement setPlaces(List<String> mac) throws NotImplementedException;

    SCMElement setToTime(String toTime);

    SCMElement addPlace(String mac) throws NotImplementedException;
}
