package cn.nsoc.scm;

import cn.nsoc.base.entity.sys.NSException;
import cn.nsoc.scm.client.SCMResultForecasting;
import cn.nsoc.scm.entity.SCMReqData;

/**
 * Define scm client method
 * Create by Alan 2017.10.18
 */
public interface SCMClient {
    /**
     * Init url
     * @param ip ip
     * @param port port
     * @throws NSException NSException
     */
    void init(String ip, int port) throws NSException;


    /**
     * Accompany request send
     * @param data Request SCMReqData
     * @return Accompany result
     * @throws NSException NSException
     */
    SCMResultItem runAccompany(SCMReqData data) throws NSException;

    /**
     * Collision request send
     * @param data SCMReqData
     * @return SCMResultItem
     * @throws NSException NSException
     */
    SCMResultItem runCollision(SCMReqData data) throws NSException;

    /**
     * Floating population statistics
     * 流动人口统计，可用于找出一定时间内出现在多个地点的人，比如一天之内出现在了多家酒店等等
     * @param data SCMReqData
     * @return SCMResultItem
     * @throws NSException NSException
     */
    SCMResultItem runFloatingPopulation(SCMReqData data) throws NSException;

    /**
     * Resident population statistics
     * 常驻人口统计，可用于找出一定时间内每个地点出现的人，比如15天内每家酒店出现的人
     * @param data SCMReqData
     * @return SCMResultItem
     * @throws NSException NSException
     */
    SCMResultItem runResidentPopulation(SCMReqData data) throws NSException;

    /**
     * Forecasting floating population
     * @param data SCMReqData
     * @return SCMResultForecasting
     * @throws NSException NSException
     */
    SCMResultForecasting runForecasting(SCMReqData data) throws NSException;
}
