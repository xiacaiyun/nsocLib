package cn.nsoc.bizmon.web.schedule;

import cn.nsoc.base.entity.sys.NSException;
import cn.nsoc.bizmon.biz.mysql.*;
import cn.nsoc.bizmon.entity.mysql.*;
import cn.nsoc.bizmon.util.Hptimer;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;

import static cn.nsoc.bizmon.entity.defines.Constants.SECONDS_OF_ONE_DAY;

@Service
public class PolicehpScheduler {
	private static final Logger logger = Logger.getLogger(PolicehpScheduler.class);
	
	@Value("${expired.warn.days}")
	private int days;
	
	public void clearExpiredPrewarn(){
		ScheduleLog.Entity log = new ScheduleLog.Entity(ScheduleLog.ClearName.WARN, LocalDateTime.now());
		PrewarningBiz biz = new PrewarningBiz();
		Prewarning.Query query = new Prewarning.Query();
		query.setToevtime((int) (Hptimer.nowSeconds() / SECONDS_OF_ONE_DAY  - days) * SECONDS_OF_ONE_DAY);
		try {
			boolean result = biz.delete(query);
			if (result){
				logger.info(String.format("clear prewarning success, items before: %s cleared", Hptimer.format(query.getToevtime())));
			} else {
				log.setSuccess(false);
			}
		} catch (NSException e) {
			logger.error(String.format("clear prewarning failed, items before: %s not cleared", Hptimer.format(query.getToevtime())), e);
			log.setSuccess(false);
			log.setMsg(e.getMessage());
		}
		log.setEndtime(LocalDateTime.now());
		ScheduleLogBiz sbiz = new ScheduleLogBiz();
		try {
			sbiz.insert(log);
		} catch (NSException e) {
			logger.error("insert clear warn log error", e);
		}
	}
	
	public void clearExpiredDevstat(){
		ScheduleLog.Entity log = new ScheduleLog.Entity(ScheduleLog.ClearName.DEVSTAT, LocalDateTime.now());
		DevstatBiz biz = new DevstatBiz();
		Devstat.Query query = new Devstat.Query();
		query.setExpiredTime((int) (Hptimer.nowSeconds() / SECONDS_OF_ONE_DAY  - days) * SECONDS_OF_ONE_DAY);
		
		try {
			boolean result = biz.delete(query);
			if (result){
				logger.info(String.format("clear old devstat success, items before: %s cleared", Hptimer.format(query.getExpiredTime())));
			} else {
				log.setSuccess(false);
			}
		} catch (NSException e) {
			logger.error(String.format("clear old devstat failed, items before: %s not cleared", Hptimer.format(query.getExpiredTime())), e);
			log.setSuccess(false);
			log.setMsg(e.getMessage());
		}
		log.setEndtime(LocalDateTime.now());
		ScheduleLogBiz sbiz = new ScheduleLogBiz();
		try {
			sbiz.insert(log);
		} catch (NSException e) {
			logger.error("insert clear devstat log error", e);
		}
	}
	
	public void clearExpiredHotstat(){
		ScheduleLog.Entity log = new ScheduleLog.Entity(ScheduleLog.ClearName.HOTSTAT, LocalDateTime.now());
		HotstatBiz biz = new HotstatBiz();
		Hotstat.Query query = new Hotstat.Query();
		query.expiredTime = (int) ((Hptimer.nowSeconds() / SECONDS_OF_ONE_DAY  - days) * SECONDS_OF_ONE_DAY);
		try {
			boolean result = biz.delete(query);
			if (result){
				logger.info(String.format("clear old Hotstat success, items before: %s cleared", Hptimer.format(query.expiredTime)));
			} else {
				log.setSuccess(false);
			}
		} catch (NSException e) {
			logger.error(String.format("clear old Hotstat failed, items before: %s not cleared", Hptimer.format(query.expiredTime)), e);
			log.setSuccess(false);
			log.setMsg(e.getMessage());
		}
		log.setEndtime(LocalDateTime.now());
		ScheduleLogBiz sbiz = new ScheduleLogBiz();
		try {
			sbiz.insert(log);
		} catch (NSException e) {
			logger.error("insert clear hotstat log error", e);
		}
	}
	
	public void clearExpiredPlace(){
		ScheduleLog.Entity log = new ScheduleLog.Entity(ScheduleLog.ClearName.PLACE, LocalDateTime.now());
		PlaceBiz biz = new PlaceBiz();
		Place.Query query = new Place.Query();
		query.setExpiredTime(LocalDateTime.now().minusDays(days).format(Hptimer.SDTF));
		try {
			boolean result = biz.delete(query);
			if (result){
				logger.info(String.format("clear old place success, items before: %s cleared", query.getExpiredTime()));
			} else {
				log.setSuccess(false);
			}
		} catch (NSException e) {
			logger.error(String.format("clear old place failed, items before: %s not cleared", query.getExpiredTime()), e);
			log.setSuccess(false);
			log.setMsg(e.getMessage());
		}
		log.setEndtime(LocalDateTime.now());
		ScheduleLogBiz sbiz = new ScheduleLogBiz();
		try {
			sbiz.insert(log);
		} catch (NSException e) {
			logger.error("insert clear hotstat log error", e);
		}
	}
}
