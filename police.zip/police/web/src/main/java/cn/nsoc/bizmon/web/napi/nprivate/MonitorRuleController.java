package cn.nsoc.bizmon.web.napi.nprivate;

import cn.nsoc.base.entity.sys.NSException;
import cn.nsoc.bizmon.biz.mysql.MonitorRuleBiz;
import cn.nsoc.bizmon.entity.defines.MonType;
import cn.nsoc.bizmon.entity.mysql.MonitorRule;
import cn.nsoc.bizmon.web.model.BatchUpdateModel;
import cn.nsoc.bizmon.web.model.EraseModel;
import cn.nsoc.common.applib.controls.JsonRet;
import cn.nsoc.common.applib.controls.PageContext;
import cn.nsoc.common.applib.controls.PagedModel;
import cn.nsoc.common.applib.controls.WebHelper;
import cn.nsoc.common.applib.rights.Right;
import cn.nsoc.common.util.Misc;
import cn.nsoc.nspider.app.police.entity.objects.*;
import cn.nsoc.nspider.app.police.entity.rule.AuthenticateType;
import cn.nsoc.nspider.app.police.entity.rule.CertificateType;
import cn.nsoc.nspider.app.police.entity.rule.MonitorTypeEnum;
import org.apache.log4j.Logger;
import org.springframework.stereotype.Controller;
import org.springframework.validation.Errors;
import org.springframework.web.bind.annotation.*;

import java.lang.reflect.Field;
import java.util.*;

/**
 * Created by Administrator on 2017/7/11.
 */
@Controller
@RequestMapping(value = "/napi/private/monitorrule")
@Right(allowAnonymous = true)
public class MonitorRuleController {

    private static final Logger logger = Logger.getLogger(MonitorRuleController.class);

    @RequestMapping(value = "/datacode/list")
    @ResponseBody
    public JsonRet dataCodeList() throws NSException {
        String fileName = "WA_BASIC_0006,WA_BASIC_0022,WA_BASIC_0023,WA_BASIC_0027," +
                "WA_SOURCE_0002,WA_SOURCE_0005,WA_SOURCE_FJ_0001,WA_SOURCE_FJ_0002" +
                ",WA_SOURCE_FJ_1001,WA_SOURCE_FJ_1002";
        String[] split = fileName.split(",");
        return new JsonRet(split);
    }

    @RequestMapping(value = "/matchvalue/get")
    @ResponseBody
    public JsonRet getMatchValue(@RequestParam(required = false) Integer key) throws NSException {
        String value = "";
        if(key!=null){
            MonitorTypeEnum typeEnum = MonitorTypeEnum.convert(key);
            Field field = null;
            try {
                field = CertificateType.class.getDeclaredField(typeEnum.name());
                if(field!=null) {
                    value = (String) field.get(field.getName());
                }
                if(typeEnum.equals(MonitorTypeEnum.PID)){
                    value = AuthenticateType.PID+"/"+value;
                }
            } catch (NoSuchFieldException|IllegalAccessException e) {
                logger.error("CertificateType or AuthenticateType parse fields failed!: "+e);
            }
        }

        return new JsonRet(value);
    }

    @RequestMapping(value = "/constant/list")
    @ResponseBody
    public JsonRet constantList(String objectName) throws NSException {
        Map<String, String> map = new HashMap<>();
        Map<String, String> result = new LinkedHashMap<>();
        Field[] declaredfields = null;
        if (objectName != null) {
            switch (objectName) {
                case "WA_BASIC_0006":
                    declaredfields = ObjBasic0006.class.getDeclaredFields();
                    break;
                case "WA_BASIC_0022":
                    declaredfields = ObjBasic0022.class.getDeclaredFields();
                    break;
                case "WA_BASIC_0023":
                    declaredfields = ObjBasic0023.class.getDeclaredFields();
                    break;
                case "WA_BASIC_0027":
                    declaredfields = ObjBasic0027.class.getDeclaredFields();
                    break;
                case "WA_SOURCE_0002":
                    declaredfields = ObjSource0002.class.getDeclaredFields();
                    break;
                case "WA_SOURCE_0005":
                    declaredfields = ObjSource0005.class.getDeclaredFields();
                    break;
                case "WA_SOURCE_FJ_0001":
                    declaredfields = ObjSourceFj0001.class.getDeclaredFields();
                    break;
                case "WA_SOURCE_FJ_0002":
                    declaredfields = ObjSourceFj0002.class.getDeclaredFields();
                    break;
                case "WA_SOURCE_FJ_1001":
                    declaredfields = ObjSourceFj1001.class.getDeclaredFields();
                    break;
                case "WA_SOURCE_FJ_1002":
                    declaredfields = ObjSourceFj1002.class.getDeclaredFields();
                    break;
                default:
                    break;
            }
            if (declaredfields != null) {
                for (Field field : declaredfields) {
                    field.setAccessible(true);
                    try {
                        if (!field.getName().equalsIgnoreCase("OBJECT_NAME")) {
                            map.put(field.getName().replace("FD_", ""), (String) field.get(field.getName()));
                        }
                    } catch (IllegalAccessException e) {
                        logger.warn(e);
                    }
                }
            }
        }

        map.entrySet().stream().sorted(Map.Entry.<String, String>comparingByKey())
                .forEachOrdered(x -> result.put(x.getKey(), x.getValue()));
        return new JsonRet(result);
    }

    @RequestMapping(value = "/list")
    @ResponseBody
    public JsonRet list(@RequestParam(required = false) Integer montype, PagedModel mo) throws NSException {
        PageContext pCtx = new PageContext(mo);
        MonitorRule.Coll coll = new MonitorRule.Coll();
        MonitorRule.Query query = coll.getQuery();
        query.start = (pCtx.getCurPage() - 1) * pCtx.getCountPerPage();
        query.count = pCtx.getCountPerPage();
        query.setMontype(montype);
        new MonitorRuleBiz().load(coll);
        pCtx.setCollection(coll);
        List<Object> result = new ArrayList<>();
        if (!coll.isEmpty()) {
            coll.forEach(item -> {
                Map<String, Object> map = new HashMap<>();
                map.put("id", item.getId());
                map.put("montype", item.getMontype());
                map.put("montypedes", MonType.getByVal(item.getMontype()) == null ? "other" : MonType.getByVal(item.getMontype()).getDes());
                map.put("datacode", item.getDatacode());
                map.put("servicecodefield", item.getServicecodefield());
                map.put("timefield", item.getTimefield());
                map.put("sourcefield", item.getSourcefield());
                map.put("matchfield", item.getMatchfield());
                map.put("matchvalue", item.getMatchvalue());
                map.put("offsetbegin", item.getOffsetbegin());
                map.put("offsetend", item.getOffsetend());
                result.add(map);
            });
        }

        return new JsonRet(result, pCtx);
    }


    @RequestMapping(value = "/update", method = RequestMethod.POST)
    @ResponseBody
    public JsonRet update(@RequestBody MonitorRule.Entity model, Errors errors) throws NSException {
        if (errors.hasErrors()) {
            return WebHelper.checkParamErrors(errors);
        }

        MonitorRuleBiz biz = new MonitorRuleBiz();
        MonitorRule.Entity exist = null;
        MonitorRule.Entity o = null;
        if (model.getId() > 0) {
            exist = biz.get(model.getId());
            if (exist == null) {
                return new JsonRet(false, "没有找到该记录");
            }
            o = Misc.objectCopy(exist, new MonitorRule.Entity());
        } else {
            o = new MonitorRule.Entity();
        }
        Misc.objectCopy(model, o);
        if (exist == null) {
            biz.insert(o);
        } else {
            biz.update(o);
        }
        return new JsonRet(true);
    }

    @RequestMapping(value = "/erase", method = RequestMethod.POST)
    @ResponseBody
    public JsonRet erase(@RequestBody(required = false) EraseModel m) throws NSException {
        boolean rm = deleteById(Integer.parseInt(m.getId()));
        return new JsonRet(rm);
    }


    private boolean deleteById(int id) throws NSException {
        MonitorRuleBiz biz = new MonitorRuleBiz();
        MonitorRule.Entity exist = new MonitorRule.Entity();
        exist.setId(id);
        return biz.delete(exist);
    }

    @RequestMapping(value = "/batchcmd", method = RequestMethod.POST)
    @ResponseBody
    public JsonRet monitorRuleRuleBatchcmd(@RequestBody BatchUpdateModel m) throws NSException {

        boolean isAllOK = true;
        List<Integer> lstErrors = new ArrayList<>();
        if (m.getCmd() != null) {
            List<Integer> strings = Misc.strToIntList(m.getItem());
            if (!strings.isEmpty()) {
                for (Integer id : strings) {
                    switch (m.getCmd()) {
                        // 勾选删除操作
                        case delete: {
                            boolean rm = deleteById(id);
                            if (!rm) {
                                // 未全部执行成功
                                isAllOK = false;
                                lstErrors.add(id);
                            }
                        }
                        break;
                        default:
                            break;
                    }
                }

            }
        }
        if (isAllOK) {
            return new JsonRet(true);
        } else {
            return new JsonRet(false, String.format("%s 删除失败！",lstErrors.toString()));
        }
    }


}
