package cn.nsoc.bizmon.web.model;

/**
 * Created by Administrator on 2017/7/12.
 */
public class EraseModel {
    private String id;
    private Integer isvalid;
    private String name;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public Integer getIsvalid() {
        return isvalid;
    }

    public void setIsvalid(Integer isvalid) {
        this.isvalid = isvalid;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
}
