package cn.nsoc.bizmon.web.model;

import cn.nsoc.bizmon.biz.SuspectJsonModel;

/**
 * Created by Administrator on 2017/7/12.
 */
public class SuspectUpdateModel {
    private String id;
    private String seqno;
    private String username;
    private String pid;
    private String mobile;
    private String wxgroupid;
    private String wx;
    private String wxid;
    private String qq;
    private String mac;
    private SuspectJsonModel other;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getSeqno() {
        return seqno;
    }

    public void setSeqno(String seqno) {
        this.seqno = seqno;
    }



    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }


    public String getPid() {
        return pid;
    }

    public void setPid(String pid) {
        this.pid = pid;
    }


    public String getMobile() {
        return mobile;
    }

    public void setMobile(String mobile) {
        this.mobile = mobile;
    }

    public String getWxgroupid() {
        return wxgroupid;
    }

    public void setWxgroupid(String wxgroupid) {
        this.wxgroupid = wxgroupid;
    }

    public String getWx() {
        return wx;
    }

    public void setWx(String wx) {
        this.wx = wx;
    }

    public String getWxid() {
        return wxid;
    }

    public void setWxid(String wxid) {
        this.wxid = wxid;
    }

    public String getQq() {
        return qq;
    }

    public void setQq(String qq) {
        this.qq = qq;
    }

    public String getMac() {
        return mac;
    }

    public void setMac(String mac) {
        this.mac = mac;
    }

    public SuspectJsonModel getOther() {
        return other;
    }

    public void setOther(SuspectJsonModel other) {
        this.other = other;
    }
}
