package cn.nsoc.bizmon.web.napi.nprivate;

import cn.nsoc.base.entity.sys.NSException;
import cn.nsoc.bizmon.biz.mysql.MonitorBiz;
import cn.nsoc.bizmon.biz.mysql.PlaceBiz;
import cn.nsoc.bizmon.entity.defines.Constants;
import cn.nsoc.bizmon.entity.defines.MonType;
import cn.nsoc.bizmon.entity.mysql.Monitor;
import cn.nsoc.bizmon.web.model.AlarmSearchModel;
import cn.nsoc.bizmon.web.model.BatchUpdateModel;
import cn.nsoc.bizmon.web.model.EraseModel;
import cn.nsoc.bizmon.web.model.UpdateModel;
import cn.nsoc.common.applib.controller.NController;
import cn.nsoc.common.applib.controls.JsonRet;
import cn.nsoc.common.applib.rights.Right;
import cn.nsoc.common.storer.biz.PageContext;
import cn.nsoc.common.util.ExportHelper;
import cn.nsoc.common.util.IDWorker;
import cn.nsoc.common.util.IntEncoder;
import cn.nsoc.common.util.Misc;
import org.apache.commons.lang3.StringEscapeUtils;
import org.springframework.stereotype.Controller;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.commons.CommonsMultipartFile;

import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.time.LocalDateTime;
import java.util.*;
import java.util.stream.Collectors;


@Controller
@RequestMapping(value = "/napi/private/monitor")
@Right(allowAnonymous = true)
public class MonitorController {

    @RequestMapping(value = "/list")
    @ResponseBody
    public JsonRet list(HttpServletResponse response, AlarmSearchModel mo,
                        @RequestParam(required = false) ExportHelper.ExportType expdata) throws NSException {
        PageContext pCtx = new PageContext(mo);
        Monitor.Coll coll = new Monitor.Coll();
        MonitorBiz monitorBiz = new MonitorBiz();
        Monitor.Query query = coll.getQuery();
        Misc.objectCopy(mo, query);
        if (expdata != null) {
            query.start = 0;
            query.count = ExportHelper.MaxExcelCount;
        } else {
            query.start = (pCtx.getCurPage() - 1) * pCtx.getCountPerPage();
            query.count = pCtx.getCountPerPage();
        }
        query.orderBy = Monitor.OrderByEnum.STARTTIME__DESC_MONTYPE__DESC;
        monitorBiz.selectName(coll);
        pCtx.setCollection(coll);
        if (coll.isEmpty()) {
            return new JsonRet(new Object[0], pCtx);
        }
        List<Object> result = new ArrayList<>();
        if (expdata != null) {
            query.groupBy = null;
            Monitor.Coll exdata = monitorBiz.load(new Monitor.Coll(query));
            buildExcel(exdata, response);
        } else {
            result = monitorBiz.toHtml(coll);
        }
        Map<String, Object> resultMap = new HashMap<>();
        Monitor.Entity re = monitorBiz.countNameKeyword(mo.getMonkey(), mo.getMontype(), mo.getNameIDList());
        resultMap.put("monkey_total", re == null ? 0 : re.monkeycount);
        resultMap.put("monname_total", re == null ? 0 : re.namecount);
        resultMap.put("result_list", result);
        return new JsonRet(resultMap, pCtx);
    }


    @RequestMapping(value = "/update", method = RequestMethod.POST)
    @ResponseBody
    public JsonRet update(@RequestParam(value = "files", required = false) CommonsMultipartFile file,
                          @RequestParam(required = false) String id,
                          @RequestParam(required = false) String monkey,
                          String oldName, String name, Boolean force, String servicecode, Integer montypeval, String starttime, String endtime) throws NSException, IOException {
        if (servicecode != null && servicecode.length() > 400) {
            return new JsonRet(false, "场所过多");
        }
        MonitorBiz biz = new MonitorBiz();
        Monitor.Coll monitorColl = new Monitor.Coll();
        Monitor.Query query = monitorColl.getQuery();
        query.setName(name);
        if (!force) {
            biz.loadPartial(monitorColl);
        }

        Monitor.Entity exist = null;
        Monitor.Entity o = null;
        if (!StringUtils.hasText(id)) {
            o = new Monitor.Entity();
        } else {
            exist = biz.get(id);
            if (exist == null) {
                return new JsonRet(false, "没有找到该记录");
            }
            o = Misc.objectCopy(exist, new Monitor.Entity());
        }

        o.setServicecode(servicecode);
        o.setMontype(montypeval);
        o.setMonkey(monkey);
        o.setName(name);
        o.setStarttime(Misc.parseISODateTime(starttime));
        o.setEndtime(Misc.parseISODateTime(endtime));

        if (exist == null) {
            int count = 0;
            if (StringUtils.hasText(monkey)) {
                List<String> collect = preHandle(monkey);
                if (collect.size() == 1) {
                    if (force == null || !force) {
                        if (!nameIfRepeat(name, monitorColl)) {
                            return new JsonRet(false, "重复的布控名，是否要合并？");
                        }

                    }
                    o.setId(IntEncoder.encode36(IDWorker.NextID()));
                    count = 1;
                    o.setMonkey(collect.get(0));
                    biz.insert(o);
                } else {
                    for (String monkeyval : collect) {
                        if (force == null || !force) {
                            if (!nameIfRepeat(name, monitorColl)) {
                                return new JsonRet(false, "重复的布控名，是否要合并？");
                            }
                        }

                        count++;
                        o.setId(IntEncoder.encode36(IDWorker.NextID()));
                        o.setMonkey(monkeyval);
                        biz.insert(o);
                    }

                }

            } else if (file != null) {
                String monkeys = Misc.readStream(file.getInputStream());
                List<String> collect = preHandle(monkeys);
                for (String monkeyval : collect) {
                    count++;
                    o.setId(IntEncoder.encode36(IDWorker.NextID()));
                    o.setMonkey(monkeyval);
                    biz.insert(o);
                }
            }
            return new JsonRet(true, "本次共录入" + count + "个布控线索");
        } else {
            if (!monitorColl.isEmpty()) {
                if (!name.equalsIgnoreCase(exist.getName()) && !nameIfRepeat(name, monitorColl)) {
                    return new JsonRet(false, "重复的布控名，是否要合并？");
                }
            }
            if (force) {
                biz.loadPartial(monitorColl);
            }

            if (!name.equalsIgnoreCase(exist.getName()) && exist.getMontype() != monitorColl.firstOrDefault().getMontype()) {
                return new JsonRet(false, "线索不一致，不能合并！");
            }
            Monitor.Query idquery = new Monitor.Query();
            idquery.setIdIDList(biz.getIdListbyName(oldName));
            biz.batchUpdate(o, idquery);
            return new JsonRet(true, "更新成功！");
        }

    }

    @RequestMapping(value = "/erase", method = RequestMethod.POST)
    @ResponseBody
    public JsonRet erase(@RequestBody(required = false) EraseModel m) throws NSException {
        boolean flag = true;
        boolean allok = true;
        if (StringUtils.hasText(m.getName())) {
            List<String> idList = new MonitorBiz().getIdListbyName(m.getName());
            for (String id : idList) {
                flag = deleteById(id, m.getIsvalid());
                if (!flag) {
                    allok = false;
                }
            }
        }
        if (allok) {
            return new JsonRet(true, "操作成功！");
        } else {
            return new JsonRet(false, "操作失败！");
        }
    }

    @RequestMapping(value = "/exportexcels", method = RequestMethod.GET)
    @ResponseBody
    public void multiexport(@RequestParam(required = false) String name, HttpServletResponse response) throws NSException {
        MonitorBiz monitorBiz = new MonitorBiz();
        List<String> idList = monitorBiz.getIdListbyName(name);
        Monitor.Coll coll = new Monitor.Coll();
        Monitor.Query query = coll.getQuery();
        query.setIdIDList(idList);
        new MonitorBiz().load(coll);
        buildExcel(coll, response);
    }


    @RequestMapping(value = "/get", method = RequestMethod.GET)
    @ResponseBody
    public JsonRet get(@RequestParam(required = false) String name) throws NSException {
        if (!StringUtils.hasText(name)) {
            return new JsonRet(getDetailedInfo(null));
        } else {
            MonitorBiz biz = new MonitorBiz();
            List<String> list = biz.getIdListbyName(name);
            if (list != null && !list.isEmpty()) {
                return new JsonRet(getDetailedInfo(list.get(0)));
            } else {
                return new JsonRet(new Object[0]);
            }
        }
    }

    private boolean deleteById(String id, Integer flag) throws NSException {
        MonitorBiz biz = new MonitorBiz();
        Monitor.Entity exist = new Monitor.Entity();
        exist.setId(id);
        if (flag == null) {
            return biz.delete(exist);
        }
        return biz.updateIsValid(exist, flag);
    }

    //勾选删除
    @RequestMapping(value = "/batchcmd", method = RequestMethod.POST)
    @ResponseBody
    public JsonRet monitorBatchcmd(@RequestBody BatchUpdateModel m, HttpServletResponse response) throws NSException {

        boolean isAllOK = true;
        List<String> lstErrors = new ArrayList<>();
        if (m.getCmd() != null) {
            List<String> idList = new MonitorBiz().getIdListbyName(m.getItem());
            if (idList != null && !idList.isEmpty()) {
                for (String id : idList) {
                    switch (m.getCmd()) {
                        case unfavorite: {
                            boolean rm = deleteById(id, 0);
                            if (!rm) {
                                // 未全部执行成功
                                isAllOK = false;
                                lstErrors.add(id);
                            }
                        }
                        break;
                        case favorite:
                            boolean rm = deleteById(id, 1);
                            if (!rm) {
                                isAllOK = false;
                                lstErrors.add(id);
                            }
                            break;
                        default:
                            break;
                    }
                }

            }
        }
        if (isAllOK) {
            return new JsonRet(true);
        } else {
            return new JsonRet(false, String.format("%s 操作失败！", lstErrors.toString()));
        }
    }


    public void buildExcel(Monitor.Coll expData, HttpServletResponse response) throws NSException {
        StringBuilder sb = new StringBuilder();
        PlaceBiz placeBiz = new PlaceBiz();
        Map<String, String> service = placeBiz.getDictFromPlace("service");
        //添加表头
        sb.append("<table border=1><tr> " +
                "<th>布控名称</th> " +
                "<th>线索</th> " +
                "<th>线索类别</th> " +
                "<th>布控时间(起始)</th> " +
                "<th>布控时间(结束)</th> " +
                "<th>布控场所</th> </tr>");
        // 添加内容
        for (Monitor.Entity a : expData) {
            String data = "";
            data = String.format("<tr> " +
                            ExportHelper.CELL_COLUMN +
                            ExportHelper.CELL_COLUMN +
                            ExportHelper.CELL_COLUMN +
                            ExportHelper.CELL_COLUMN +
                            ExportHelper.CELL_COLUMN +
                            ExportHelper.CELL_COLUMN +
                            "</tr>",
                    StringEscapeUtils.escapeHtml3(a.getName() == null ? "" : a.getName()),
                    StringEscapeUtils.escapeHtml3(a.getMonkey()),
                    MonType.getByVal(a.getMontype()) == null ? "" : MonType.getByVal(a.getMontype()).getDes(),
                    Misc.toStdString(a.getStarttime()),
                    Misc.toStdString(a.getEndtime()),
                    placeBiz.getServiceNames(a.getServicecode(), service));
            sb.append(data);
        }
        sb.append("</table>");
        String excelData = ExportHelper.BuildDownLoadHtml(sb.toString());
        String fileName = "布控列表";
        NController.exportToExcel(response, excelData, fileName);
    }


    public UpdateModel getDetailedInfo(String id) throws NSException {
        PlaceBiz placeBiz = new PlaceBiz();
        Map<String, String> service = placeBiz.getDictFromPlace("service");
        Monitor.Entity o = null;
        UpdateModel model = new UpdateModel();
        MonitorBiz biz = new MonitorBiz();
        if (StringUtils.hasText(id)) {
            o = biz.get(id);
            //Entity(DB库查出的)赋给model(页面需显示的)
            Misc.objectCopy(o, model);
            model.setMontype(o.getMontype());
            model.setMontypedesc(MonType.getByVal(o.getMontype()).getDes());
            model.setStarttime(Misc.toStdString(o.getStarttime()));
            model.setEndtime(Misc.toStdString(o.getEndtime()));
            model.setServicename(new PlaceBiz().getServiceNames(o.getServicecode(), service));
        } else {
            model.setStarttime((LocalDateTime.now().toString().substring(0, 10) + " 00:00:00"));
            model.setEndtime((LocalDateTime.now().plusYears(1).toString().substring(0, 10) + " 23:59:59"));
            model.setServicecode(Constants.SERVICE_CODE);
            model.setServicename(Constants.SERVICE_NAME);
        }
        return model;
    }

    private boolean ifExist(Monitor.Entity entity, Monitor.Coll monitorColl) throws NSException {
        Monitor.Coll coll = monitorColl.stream().filter(l -> l.getServicecode().compareTo(entity.getServicecode()) == 0
                && l.getName().compareTo(entity.getName()) == 0
                && l.getMontype() == entity.getMontype()
                && l.getMonkey().compareTo(entity.getMonkey()) == 0
                && l.getStarttime().equals(entity.getStarttime())
                && l.getEndtime().equals(entity.getEndtime()))
                .collect(Collectors.toCollection(Monitor.Coll::new));
        return !coll.isEmpty();
    }

    private boolean nameIfRepeat(String detail, Monitor.Coll coll) throws NSException {
        List<Monitor.Entity> sameDetailList = coll.stream().filter(p -> p.getName().compareToIgnoreCase(detail) == 0).collect(Collectors.toList());
        if (!sameDetailList.isEmpty()) {
            return false;
        }
        return true;
    }

    private boolean validate(Monitor.Entity entity, StringBuilder sb) throws NSException {

        List<String> ids = new MonitorBiz().getIdListbyName(entity.getName());
        if (ids == null) {
            return true;
        } else {
            UpdateModel detailedInfo = getDetailedInfo(ids.get(0));
            if (entity.toString().compareToIgnoreCase(detailedInfo.toString()) != 0) {
                sb.append(String.format("该布控名称必须是：%s，%s，%s，%s", detailedInfo.getMontypedesc(), detailedInfo.getStarttime(), detailedInfo.getEndtime(), detailedInfo.getServicename()));
                return false;
            } else {
                return true;
            }
        }
    }

    private List<String> preHandle(String monkey) throws NSException {
        String result = "";
        if (StringUtils.hasText(monkey)) {
            result = monkey.replace("，", "").replace(",", "");
        }
        if (result.contains("\n")) {
            String replace = result.replace("\r", "");
            String[] monkeyArr = replace.split("\n");
            List<String> collect = Arrays.stream(monkeyArr).
                    filter(p -> StringUtils.hasText(p)).
                    distinct().collect(Collectors.toList());
            return collect;
        }
        return Arrays.asList(result);

    }

    @RequestMapping(value = "/namelist/list")
    @ResponseBody
    public JsonRet listAllMonitorNames() throws NSException {
        Monitor.Coll coll = new Monitor.Coll();
        Monitor.Query query = coll.getQuery();
        query.partialMode = true;
        MonitorBiz monitorBiz = new MonitorBiz();
        monitorBiz.selectName(coll);
        List<String> nameList = coll.stream().map(l -> l.getName()).distinct().collect(Collectors.toList());
        return new JsonRet(nameList);
    }


}
