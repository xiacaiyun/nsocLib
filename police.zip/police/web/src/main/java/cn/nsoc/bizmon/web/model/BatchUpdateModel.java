package cn.nsoc.bizmon.web.model;

import cn.nsoc.common.applib.controls.BatchUpdateCmd;

/**
 * Created by Administrator on 2017/7/12.
 */
public class BatchUpdateModel {
    private BatchUpdateCmd cmd;
    private String item;

    public BatchUpdateCmd getCmd() {
        return cmd;
    }

    public void setCmd(BatchUpdateCmd cmd) {
        this.cmd = cmd;
    }

    public String getItem() {
        return item;
    }

    public void setItem(String item) {
        this.item = item;
    }
    
}
