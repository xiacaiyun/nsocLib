package cn.nsoc.bizmon.web.napi.ninternal;

import cn.nsoc.base.entity.sys.NSException;
import cn.nsoc.bizmon.biz.dw.DataWareMgr;
import cn.nsoc.bizmon.biz.mysql.PlaceBiz;
import cn.nsoc.bizmon.entity.mysql.Place;
import cn.nsoc.bizmon.util.Hptimer;
import cn.nsoc.common.applib.controller.NController;
import cn.nsoc.common.applib.controls.JsonRet;
import cn.nsoc.common.applib.controls.PageContext;
import cn.nsoc.common.applib.controls.PagedModel;
import cn.nsoc.common.applib.rights.Right;
import cn.nsoc.common.util.ExportHelper;
import org.apache.commons.lang3.StringUtils;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import javax.servlet.http.HttpServletResponse;
import static java.util.Comparator.comparing;
import static java.util.stream.Collectors.toList;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;
import static cn.nsoc.bizmon.util.Hptimer.format;
import static cn.nsoc.bizmon.util.Hptimer.toSeconds;

@Controller
@RequestMapping(value = "/napi/internal/im")
@Right(allowAnonymous = true)
public class IMController {
    private static final Logger logger = Logger.getLogger(IMController.class);

    @Autowired
    private DataWareMgr dwMgr;

    @RequestMapping(value = "/relations")
    @ResponseBody
    public JsonRet relations(@RequestBody Map<String, List<Map<String, String>>> virtualMap) {
        if (virtualMap.isEmpty()) {
            return new JsonRet(false, "no virtual account");
        }
        List<Map<String, String>> virtuals = virtualMap.get("req");
        if (virtuals.isEmpty()) {
            return new JsonRet(false, "no virtual account");
        }
        List<Map<String, Object>> result = null;
        try {
            result = dwMgr.relation(virtuals);
        } catch (NSException e) {
            logger.error("query failed", e);
        }
        return new JsonRet(result);
    }

    @RequestMapping(value = "/wbonline")
    @ResponseBody
    public JsonRet online(@RequestParam(required = true) String pid, PagedModel model) {
        PageContext pCtx = new PageContext(model);
        int start = (pCtx.getCurPage() - 1) * pCtx.getCountPerPage();
        int limit = pCtx.getCountPerPage();
        List<Map<String, Object>> result = new ArrayList<>();
        try {
            result = dwMgr.findWbonline(pid, start, limit);
            if (result.size() > 0) {
                List<String> scs = result.stream().map(a -> (String) a.get("sc")).distinct()
                        .collect(Collectors.toList());
                PlaceBiz biz = new PlaceBiz();
                Place.Coll coll = new Place.Coll();
                Place.Query query = coll.getQuery();
                query.setServicecodeIDList(scs);
                Map<String, String> snameMap = new HashMap<>();
                Map<String, String> addrMap = new HashMap<>();
                try {
                    coll = biz.loadPartial(coll);
                    coll.forEach(a -> addrMap.put(a.getServicecode(), a.getAddress()));
                    coll.forEach(a -> snameMap.put(a.getServicecode(), a.getServicename()));
                    result.forEach(a -> a.put("service_name", snameMap.get(a.get("sc"))));
                    result.forEach(a -> a.put("service_addr", addrMap.get(a.get("sc"))));
                } catch (NSException e) {
                    logger.error("query place failed", e);
                }
            }
            for (Map<String, Object> iter : result) {
                Long time = (Long) iter.remove("online_time");
                if (time != null)
                    iter.put("online_time", format(time));
                time = (Long) iter.remove("offline_time");
                if (time != null)
                    iter.put("offline_time", format(time));
            }
        } catch (NSException e) {
            logger.error("query failed", e);
        }
        pCtx.setCountPerPage(result.size());
        return new JsonRet(result, pCtx);

    }

    @RequestMapping(value = "/wifionline")
    @ResponseBody
    public JsonRet wifiOnline(@RequestParam String pid, @RequestParam String mobile,
            PagedModel model) {
        PageContext pCtx = new PageContext(model);
        int start = (pCtx.getCurPage() - 1) * pCtx.getCountPerPage();
        int limit = pCtx.getCountPerPage();
        List<Map<String, Object>> result = new ArrayList<>();
        try {
            result = dwMgr.findWifiOnline(pid, mobile, start, limit);
            if (result.size() > 0) {
                LocusController.addPlaceInfo(result);
            }
            for (Map<String, Object> iter : result) {
                Long time = (Long) iter.remove("online_time");
                if (time != null)
                    iter.put("online_time", format(time));
                time = (Long) iter.remove("offline_time");
                if (time != null)
                    iter.put("offline_time", format(time));
            }
        } catch (NSException e) {
            logger.error("query failed", e);
        }
        pCtx.setCountPerPage(result.size());
        return new JsonRet(result, pCtx);
    }

    @RequestMapping(value = "/mail")
    @ResponseBody
    public JsonRet mail(@RequestParam String pid, @RequestParam String mobile, PagedModel model) {
        PageContext pCtx = new PageContext(model);
        int start = (pCtx.getCurPage() - 1) * pCtx.getCountPerPage();
        int limit = pCtx.getCountPerPage();
        List<Map<String, Object>> result = new ArrayList<>();
        try {
            result = dwMgr.findMail(pid, mobile, start, limit);
            if (result.size() > 0) {
                LocusController.addPlaceInfo(result);
            }
            for (Map<String, Object> iter : result) {
                iter.put("send_time", format((long) iter.remove("send_time")));
            }
        } catch (NSException e) {
            logger.error("query failed", e);
        }
        pCtx.setCountPerPage(result.size());
        return new JsonRet(result, pCtx);
    }

    @RequestMapping(value = "/http")
    @ResponseBody
    public JsonRet http(@RequestParam String pid, @RequestParam String mobile, PagedModel model) {
        PageContext pCtx = new PageContext(model);
        int start = (pCtx.getCurPage() - 1) * pCtx.getCountPerPage();
        int limit = pCtx.getCountPerPage();
        List<Map<String, Object>> result = new ArrayList<>();
        try {
            result = dwMgr.findHttp(pid, mobile, start, limit);
            if (result.size() > 0) {
                LocusController.addPlaceInfo(result);
            }
            for (Map<String, Object> iter : result) {
                iter.put("send_time", format((long) iter.remove("send_time")));
            }
        } catch (NSException e) {
            logger.error("query failed", e);
        }
        pCtx.setCountPerPage(result.size());
        return new JsonRet(result, pCtx);
    }

    @RequestMapping(value = "/chat")
    @ResponseBody
    public JsonRet findChat(@RequestBody Map<String, String> map, PagedModel model) {
        if (map.get("fromtime") == null || map.get("totime") == null) {
            return new JsonRet(false, "request missing fromtime/totime");
        }
        if (StringUtils.isBlank((map.get("type"))) || StringUtils.isBlank(map.get("key"))) {
            return new JsonRet(false, "request missing type/key");
        }
        long start = toSeconds(map.get("fromtime"));
        long end = toSeconds(map.get("totime"));
        String type = map.get("type");
        String val = map.get("key");
        if (StringUtils.isNotBlank(map.get("pageId"))) {
            model.setPageId(Integer.parseInt(map.get("pageId")));
        }
        if (StringUtils.isNotBlank(map.get("countPerPage"))) {
            model.setCountPerPage(Integer.parseInt(map.get("countPerPage")));
        }
        PageContext pCtx = new PageContext(model);
        int rowStart = (pCtx.getCurPage() - 1) * pCtx.getCountPerPage();
        int rowCount = pCtx.getCountPerPage();
        List<Map<String, Object>> result = null;
        try {
            if (pCtx.getCurPage() == 1) {
                pCtx.setTotalCount(100);
            }
            result = dwMgr.findChat(type, val, start, end, rowStart, rowCount);
            pCtx.setCountCurPage(result.size());
            if (result.size() > 0) {
                List<String> scs = result.stream().map(a -> a.get("sc").toString()).distinct()
                        .collect(Collectors.toList());
                PlaceBiz biz = new PlaceBiz();
                Place.Coll coll = new Place.Coll();
                Place.Query query = coll.getQuery();
                query.setServicecodeIDList(scs);
                Map<String, String> addrMap;
                addrMap = biz.loadPartial(coll).stream().collect(Collectors
                        .toMap(Place.Entity::getServicecode, Place.Entity::getServicename));
                result = result.stream().distinct().sorted(
                        comparing((Map<String, Object> a) -> (long) a.get("send_time")).reversed())
                        .collect(toList());
                result.forEach(a -> {
                    a.put("service_name", addrMap.get(a.get("sc")));
                    a.put("time", Hptimer.format((long) a.remove("send_time")));
                });
            }
        } catch (NSException e) {
            logger.error("query failed", e);
        }
        return new JsonRet(result, pCtx);
    }

    @RequestMapping(value = "/chatExport")
    @ResponseBody
    public void chatExport(@RequestBody Map<String, String> map, PagedModel model,
            HttpServletResponse response) throws NSException {
        if (model == null) {
            model = new PagedModel();
        }
        model.setPageId(1);
        model.setCountPerPage(100000);
        JsonRet result = findChat(map, model);
        StringBuilder sb = new StringBuilder();
        // 添加表头
        sb.append("<table border=1><tr> " + "<td>发送账号</td> " + "<td>接收账号</td> " + "<td>群账号</td> "
                + "<td>群名称</td> " + "<td>场所名称</td> " + "<td>内容概要</td> " + "<td>时间</td></tr>");
        if (result.isRet()) {
            // 添加内容
            for (Map<String, Object> a : (List<Map<String, Object>>) result.getData()) {
                String data = "";
                data = String.format(
                        "<tr> " + ExportHelper.CELL_COLUMN + ExportHelper.CELL_COLUMN
                                + ExportHelper.CELL_COLUMN + ExportHelper.CELL_COLUMN
                                + ExportHelper.CELL_COLUMN + ExportHelper.CELL_COLUMN
                                + ExportHelper.CELL_COLUMN + "</tr>",
                        a.get("from_id"), a.get("to_id"), a.get("grp_no"), a.get("grp_name"),
                        a.get("service_name"), a.get("msg"), a.get("time"));
                sb.append(data);
            }
        }
        sb.append("</table>");
        String excelData = ExportHelper.BuildDownLoadHtml(sb.toString());
        String fileName = "聊天记录";
        NController.exportToExcel(response, excelData, fileName);
    }

    @RequestMapping(value = "/mailExport")
    @ResponseBody
    public void mailExport(@RequestParam String pid, @RequestParam String mobile, PagedModel model,
            HttpServletResponse response) throws NSException {
        if (model == null) {
            model = new PagedModel();
        }
        model.setPageId(1);
        model.setCountPerPage(100000);
        JsonRet result = mail(pid, mobile, model);
        StringBuilder sb = new StringBuilder();
        // 添加表头
        sb.append("<table border=1><tr> " + "<td>发送者</td> " + "<td>接收者</td> " + "<td>抄送</td> "
                + "<td>邮件主题</td> " + "<td>场所名称</td> " + "<td>时间</td></tr>");
        if (result.isRet()) {
            // 添加内容
            for (Map<String, Object> a : (List<Map<String, Object>>) result.getData()) {
                String data = "";
                data = String.format(
                        "<tr> " + ExportHelper.CELL_COLUMN + ExportHelper.CELL_COLUMN
                                + ExportHelper.CELL_COLUMN + ExportHelper.CELL_COLUMN
                                + ExportHelper.CELL_COLUMN + ExportHelper.CELL_COLUMN + "</tr>",
                        a.get("mail_from"), a.get("mail_to"), a.get("mail_cc"),
                        a.get("mail_subject"), a.get("servicename"), a.get("send_time"));
                sb.append(data);
            }
        }
        sb.append("</table>");
        String excelData = ExportHelper.BuildDownLoadHtml(sb.toString());
        String fileName = "邮件记录";
        NController.exportToExcel(response, excelData, fileName);
    }


    @RequestMapping(value = "/httpExport")
    @ResponseBody
    public void httpExport(@RequestParam String pid, @RequestParam String mobile, PagedModel model,
            HttpServletResponse response) throws NSException {
        if (model == null) {
            model = new PagedModel();
        }
        model.setPageId(1);
        model.setCountPerPage(100000);
        JsonRet result = http(pid, mobile, model);
        StringBuilder sb = new StringBuilder();
        // 添加表头
        sb.append("<table border=1><tr> " + "<td>上网URL</td> " + "<td>认证帐号</td> " + "<td>场所名称</td> "
                + "<td>时间</td></tr>");
        if (result.isRet()) {
            // 添加内容
            for (Map<String, Object> a : (List<Map<String, Object>>) result.getData()) {
                String data = "";
                data = String.format(
                        "<tr> " + ExportHelper.CELL_COLUMN + ExportHelper.CELL_COLUMN
                                + ExportHelper.CELL_COLUMN + ExportHelper.CELL_COLUMN + "</tr>",
                        a.get("url"), a.get("sessionid"), a.get("servicename"), a.get("send_time"));
                sb.append(data);
            }
        }
        sb.append("</table>");
        String excelData = ExportHelper.BuildDownLoadHtml(sb.toString());
        String fileName = "邮件记录";
        NController.exportToExcel(response, excelData, fileName);
    }

}
