package cn.nsoc.bizmon.web.model;

import cn.nsoc.common.applib.controls.PagedModel;

import java.util.List;

/**
 * Created by Administrator on 2017/7/17.
 */
public class PlaceSearchModel extends PagedModel {
    private String servicetype;
    private List<String> policecodeIDList;
    private String keyword;
    private Integer placestatus;
    private String address;
    private List<String> orgnameIDList;

    public String getServicetype() {
        return servicetype;
    }

    public void setServicetype(String servicetype) {
        this.servicetype = servicetype;
    }

    public String getKeyword() {
        return keyword;
    }

    public void setKeyword(String keyword) {
        this.keyword = keyword;
    }


    public Integer getPlacestatus() {
        return placestatus;
    }

    public void setPlacestatus(Integer placestatus) {
        this.placestatus = placestatus;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }


    public List<String> getPolicecodeIDList() {
        return policecodeIDList;
    }

    public void setPolicecodeIDList(List<String> policecodeIDList) {
        this.policecodeIDList = policecodeIDList;
    }

    public List<String> getOrgnameIDList() {
        return orgnameIDList;
    }

    public void setOrgnameIDList(List<String> orgnameIDList) {
        this.orgnameIDList = orgnameIDList;
    }
}
