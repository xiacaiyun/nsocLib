package cn.nsoc.bizmon.web.model;

/**
 * Created by Administrator on 2017/7/14.
 */
public class UpdateModel {
    private String starttime;
    private String endtime;
    private String id;
    private String name;
    private String servicecode;
    private Integer montype;
    private String montypedesc;
    private String monkey;
    private int isvalid;
    private String servicename;
    private String alarmtime;
    private String address;

    public String getStarttime() {
        return starttime;
    }

    public void setStarttime(String starttime) {
        this.starttime = starttime;
    }

    public String getEndtime() {
        return endtime;
    }

    public void setEndtime(String endtime) {
        this.endtime = endtime;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getServicecode() {
        return servicecode;
    }

    public void setServicecode(String servicecode) {
        this.servicecode = servicecode;
    }

    public Integer getMontype() {
        return montype;
    }

    public void setMontype(Integer montype) {
        this.montype = montype;
    }

    public String getMontypedesc() {
        return montypedesc;
    }

    public void setMontypedesc(String montypedesc) {
        this.montypedesc = montypedesc;
    }

    public String getMonkey() {
        return monkey;
    }

    public void setMonkey(String monkey) {
        this.monkey = monkey;
    }

    public int getIsvalid() {
        return isvalid;
    }

    public void setIsvalid(int isvalid) {
        this.isvalid = isvalid;
    }

    public String getServicename() {
        return servicename;
    }

    public void setServicename(String servicename) {
        this.servicename = servicename;
    }

    public String getAlarmtime() {
        return alarmtime;
    }

    public void setAlarmtime(String alarmtime) {
        this.alarmtime = alarmtime;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    @Override
    public String toString() {
        return starttime+" "+endtime+" "+servicecode+" "+montype;
    }
}
