package cn.nsoc.bizmon.web.config;

import org.apache.commons.dbcp2.BasicDataSource;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.annotation.Order;

import javax.sql.DataSource;

@Configuration
@ComponentScan(basePackages = { "cn.nsoc.bizmon.biz", "cn.nsoc.bizmon.biz.dw" })
@Order
public class ExtraAppconfig {
	

}
