package cn.nsoc.bizmon.web.napi.ninternal;

import cn.nsoc.base.entity.sys.NSException;
import cn.nsoc.bizmon.biz.dw.DataWareMgr;
import cn.nsoc.bizmon.biz.mysql.PlaceBiz;
import cn.nsoc.bizmon.entity.api.CollideRequest;
import cn.nsoc.bizmon.entity.mysql.Place;
import cn.nsoc.bizmon.util.Hptimer;
import cn.nsoc.common.applib.controls.JsonRet;
import cn.nsoc.common.applib.rights.Right;

import org.apache.commons.lang3.StringUtils;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.google.gson.Gson;

import javax.validation.constraints.NotNull;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Map;

import static cn.nsoc.bizmon.util.Hptimer.toSeconds;

@Controller
@RequestMapping(value = "/napi/internal/analysis")
@Right(allowAnonymous = true)
public class AnalyzerController {
	private static final Logger logger = Logger.getLogger(AnalyzerController.class);
	private static final int TIME_RANGE = 3*60;
	private static final int FOLLOW_MIN=2;
	
	@Autowired
	private DataWareMgr dwMgr;
	
	static class CollideModel{
		
		@NotNull
		public List<CollideRequest> pram;
		@NotNull
		public int min;

		public List<CollideRequest> getPram() {
			return pram;
		}

		public void setPram(List<CollideRequest> pram) {
			this.pram = pram;
		}

		public int getMin() {
			return min;
		}

		public void setMin(int min) {
			this.min = min;
		}
		
		
		
	}
	
	@RequestMapping(value = "/collision")
	@ResponseBody
	public JsonRet collision(@RequestBody(required=true) CollideModel model){
		if(model.getPram().isEmpty()) {
			return new JsonRet(false, "no pram");
		}
		if (model.getMin() < FOLLOW_MIN) {
			return new JsonRet(false, "min should larger than 1");
		}
		return collide(model.getPram(), model.getMin());
	}
	
	@SuppressWarnings("unchecked")
	@ResponseBody
	public JsonRet collide(@RequestBody List<CollideRequest> models, int min) {
		Gson gson = new Gson();
		logger.info(String.format("\nconditions: %s, min: %s", gson.toJson(models), min));
		List<Map<String, Object>> result;
		try {
			result = dwMgr.collide(models, min);
			for(Map<String, Object> iter : result) {
				List<String> scs = (List<String>)iter.get("s_sc");
				iter.put("s_sc", new PlaceBiz().loadByCodesForNames(scs));
			}
			return new JsonRet(result);
		} catch (NSException e) {
			logger.error("", e);
			return new JsonRet(false, e.getMessage());
		}
	}

	@RequestMapping(value = "/follow")
	@ResponseBody
	public JsonRet follow(@RequestBody Map<String, String> map) {
		if(map.get("fromtime") == null || map.get("totime") == null) {
			return new JsonRet(false, "request missing fromtime/totime");
		}
		long start = toSeconds(map.get("fromtime"));
		long end = toSeconds(map.get("totime"));
		if(!"mac".equals(map.get("keytype"))) {
			return new JsonRet(false, "not a mac");
		}
		String mac = map.get("key");
		List<Map<String, Object>> result = new ArrayList<>();
		List<Map<String, Object>> occurs  = null;
		try {
			occurs = dwMgr.macTrace(start, end, mac);
		} catch (Exception e) {
			logger.error("query failed", e);
		}
		if (occurs == null || occurs.isEmpty()) {
			return new JsonRet(result);
		}
		occurs.sort(Comparator.comparing((Map<String, Object> a) -> (long)a.get("online_time")));
		List<CollideRequest> reqs = new ArrayList<>();
		for(Map<String, Object> m: occurs) {
			CollideRequest req = new CollideRequest();
	
			long occurTime = (long) m.get("online_time");
			if(StringUtils.isBlank((String)m.get("service_code")) ) {
				continue;
			}
			long from = occurTime - TIME_RANGE;
			long to = occurTime + TIME_RANGE;
			req.setFromtime(Hptimer.format(from));
			req.setTotime(Hptimer.format(to));
			req.setPlace(new ArrayList<>());
			req.getPlace().add(m.get("service_code").toString());
			reqs.add(req);
		}
		if(reqs.isEmpty()) {
			return new JsonRet(result);
		}
		return collide(reqs, FOLLOW_MIN);
	}
	
}
