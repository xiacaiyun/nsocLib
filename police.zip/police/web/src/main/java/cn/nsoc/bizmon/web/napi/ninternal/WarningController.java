package cn.nsoc.bizmon.web.napi.ninternal;

import cn.nsoc.base.entity.sys.NSException;
import cn.nsoc.bizmon.biz.SuspectJsonModel;
import cn.nsoc.bizmon.biz.mysql.*;
import cn.nsoc.bizmon.entity.defines.MonType;
import cn.nsoc.bizmon.entity.mysql.*;
import cn.nsoc.bizmon.entity.mysql.Monitor.Entity;
import cn.nsoc.bizmon.util.Hptimer;
import cn.nsoc.common.applib.controls.JsonRet;
import cn.nsoc.common.applib.controls.PageContext;
import cn.nsoc.common.applib.controls.PagedModel;
import cn.nsoc.common.applib.rights.Right;
import cn.nsoc.common.util.Misc;
import org.apache.commons.lang3.StringUtils;
import org.apache.log4j.Logger;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import com.google.common.collect.Lists;
import java.util.*;
import java.util.function.Function;
import java.util.stream.Collectors;

import static cn.nsoc.bizmon.util.Hptimer.format;
import static cn.nsoc.bizmon.util.Hptimer.toSeconds;

@Controller
@RequestMapping(value = "/napi/internal/warning")
@Right(allowAnonymous = true)
public class WarningController {
	private static final Logger logger = Logger.getLogger(WarningController.class);
	private static final String EVTIME = "evtime";
	private static final String MONTYPE = "montype";
	private static final String FROMTIME = "fromtime";

	public enum Status {
		NEW, FIXED, MOVING;
	}

	@RequestMapping(value = "/warnTotal")
	@ResponseBody
	public JsonRet warnTotal() throws NSException {
		PrewarningTraceBiz biz = new PrewarningTraceBiz();
		Map<String, Integer> result = new HashMap<>();
		result.put("total", biz.findTotal());
		return new JsonRet(result);
	}

	@RequestMapping(value = "/monitorTotal")
	@ResponseBody
	public JsonRet monitorTotal() throws NSException {
		MonitorBiz biz = new MonitorBiz();
		Map<String, Integer> result = new HashMap<>();
		result.put("total", biz.findTotal());
		return new JsonRet(result);
	}

	@RequestMapping(value = "/scroll")
	@ResponseBody
	public JsonRet scroll(@RequestBody Map<String, String> map) {
		if (map.get(FROMTIME) == null) {
			return new JsonRet(false, "no fromtime");
		}
		Map<String, Object> result;
		try {
			result = scrollInternal(map);
			return new JsonRet(result);
		} catch (NSException e) {
			logger.error("warning db error", e);
			return new JsonRet(false, "warning service error");
		}
	}

	private Map<String, Object> scrollInternal(Map<String, String> map) throws NSException {
		Prewarning.Coll coll = new Prewarning.Coll();
		Prewarning.Query query = coll.getQuery();
		long start = toSeconds(map.get(FROMTIME));

		query.setFromevtime((int) start);
		query.setIsValid(1);
		query.orderBy = Prewarning.OrderByEnum.EVTIME__DESC;
		String monames = map.get("monames");
		String clues = map.get("cluelist");
		Map<String, Entity> monitors = null;
		if (StringUtils.isNotBlank(monames) || StringUtils.isNotBlank(clues)) {
			monitors = getMonitorsByNameAndClue(monames, clues);
			query.setMonidIDList(new ArrayList<String>(monitors.keySet()));
		}
		String placelist = map.get("placelist");
		query.setServicecodeIDList(StringUtils.isBlank(placelist) ? null : Arrays.asList(placelist.split(",")));

		PrewarningBiz biz = new PrewarningBiz();
		SuspectBiz suspectBiz = new SuspectBiz();
		PhotoBiz photoBiz = new PhotoBiz();
		Photo.Coll photoColl = photoBiz.load(new Photo.Coll());
		biz.load(coll);
		if (!coll.isEmpty() && monitors == null) {
			monitors = getMonitorsById(coll.stream().map(p -> p.getMonid()).collect(Collectors.toList()));
		}
		final Map<String, Entity> monitorMap = monitors;
//        Suspect.Coll suspectColl = SuspectCache.getInstance().search("suspect");
		Suspect.Coll suspectColl = new Suspect.Coll();
		suspectBiz.loadBykeyword(suspectColl,null);
		Map<String, String> places = (new PlaceBiz()).getDictFromPlace("service");
		List<Map<String, Object>> warnResult = coll.stream().filter(l -> monitorMap.get(l.getMonid()) != null).map(l -> {
			HashMap<String, Object> e = new HashMap<String, Object>();
			MonType type = MonType.getByVal(l.getMontype());
			Photo.Entity photo = null;
			boolean flag = false;
            Suspect.Coll sColl = suspectColl.findRelated(type,l.getMonkey());
			if (!sColl.isEmpty()) {
				SuspectJsonModel jsonModel = Misc.fromJson(sColl.get(0).getOther(), SuspectJsonModel.class);
				if (jsonModel != null) {
					if (!StringUtils.isBlank(jsonModel.getImportantperson()) && !jsonModel.getImportantperson().equalsIgnoreCase("0")) {
						flag = true;
					}
				}
				photo = photoColl.findByPid(sColl.get(0).getPid());
			}

			Entity m = monitorMap.get(l.getMonid());
			e.put(EVTIME, Hptimer.format(l.getEvtime()));
			e.put(MONTYPE, type);
			e.put("monkey", l.getMonkey());
			e.put("servicename", places.get(l.getServicecode()));
			e.put("monitorname", m.getName());
			e.put("name", sColl.isEmpty() ? "" : sColl.get(0).getUsername());
			e.put("pid", sColl.isEmpty() ? "" : sColl.get(0).getPid());
			e.put("mac", sColl.isEmpty() ? "" : sColl.get(0).getMac());
			e.put("mobile", sColl.isEmpty() ? "" : sColl.get(0).getMobile());
			e.put("important", flag ? "true" : "false");
			e.put("path", photo == null ? "" : photo.getSrc());
			return e;
		}).collect(Collectors.toList());
		String nameListStr = map.get("namelist");
		if(StringUtils.isNotBlank(nameListStr)) {
		    List<String> nameList = Arrays.asList(nameListStr.split(","));
		    warnResult = warnResult.stream().filter(l->
		        nameList.contains(l.get("name"))
		    ).collect(Collectors.toList());
		}

		Map<String, Object> result = new HashMap<>();
		result.put("warning_total", warnResult.size());
		result.put("ctrl_total", (new MonitorBiz()).findTotal());
		result.put("warning_data", warnResult);
		return result;
		}

	@RequestMapping(value = "/radar")
	@ResponseBody
	public JsonRet radar(@RequestBody Map<String, String> map) throws NSException {
		if (StringUtils.isBlank(map.get(FROMTIME))) {
			return new JsonRet(false, "no fromtime");
		}

		long start = toSeconds(map.get(FROMTIME));

		List<String> monids = new ArrayList<>();
		String monames = map.get("monames");
		String clues = map.get("cluelist");
		Map<String, Entity> monitors = new HashMap<>();
		if (StringUtils.isNotBlank(monames) || StringUtils.isNotBlank(clues)) {
			monitors.putAll(getMonitorsByNameAndClue(monames, clues));
			monids = new ArrayList<String>(monitors.keySet());
		}
		String placelist = map.get("placelist");
		PrewarningTraceBiz biz = new PrewarningTraceBiz();
		PrewarningTrace.Coll coll = new PrewarningTrace.Coll();
		PrewarningTrace.Query query = coll.getQuery();
		query.setMonidIDList(monids);
		query.setServicecodeIDList(StringUtils.isBlank(placelist) ? null : Arrays.asList(placelist.split(",")));

		query.setFromevtime((int) start);
		query.setIsValid(1);
		query.skipTotalCount = true;
		query.orderBy = Prewarning.OrderByEnum.EVTIME__DESC;
		List<Map<String, Object>> result = new ArrayList<>();
		try {
			coll = biz.load(coll);
			for (PrewarningTrace.Entity l : coll) {
				Map<String, Object> m = new HashMap<>();
				m.put(EVTIME, format(l.getEvtime()));
				m.put("monid", l.getMonid());
				m.put("servicecode", l.getServicecode());
				m.put("montype", l.getMontype() == null ? "" : l.getMontype());
				m.put("monkey", l.getMonkey() == null ? "" : l.getMonkey());
				result.add(m);
			}
		} catch (NSException e) {
			logger.error("warning db error", e);
			return new JsonRet(false, "warning service error");
		}
		if (monitors.isEmpty()) {
			monids = result.stream().map(a -> (String) a.get("monid")).collect(Collectors.toList());
			monitors.putAll(getMonitorsById(monids));
		}
		// add monitor name/key
		result.forEach(l -> {
			Entity m = monitors.get(l.get("monid"));
			if (m != null) {
				l.put("monitorname", m.getName() == null ? "" : m.getName());
				l.put("monkey", m.getMonkey() == null ? "" : m.getMonkey());
			}
		});

		// add place info
		LocusController.addPlaceInfo(result);
		// add suspect info
		PhotoBiz photoBiz = new PhotoBiz();
		Photo.Coll photoColl = photoBiz.load(new Photo.Coll());
//        Suspect.Coll sColl = SuspectCache.getInstance().search("suspect");
		Suspect.Coll sColl = new Suspect.Coll();
		new SuspectBiz().loadBykeyword(sColl,null);
		result.forEach(l -> {
            MonType type = MonType.getByVal((int) l.get("montype"));
            Suspect.Coll suspectColl = sColl.findRelated(type,(String) l.get("monkey"));
			boolean flag = false;
			Photo.Entity photo = null;
			if (!suspectColl.isEmpty()) {
				SuspectJsonModel jsonModel = Misc.fromJson(suspectColl.get(0).getOther(), SuspectJsonModel.class);
				if (jsonModel != null) {
					if (!StringUtils.isBlank(jsonModel.getImportantperson()) && !jsonModel.getImportantperson().equalsIgnoreCase("0")) {
						flag = true;
					}
				}
				photo = photoColl.findByPid(suspectColl.get(0).getPid());
			}
			l.put("name", suspectColl.isEmpty() ? "" : suspectColl.get(0).getUsername());
			l.put("pid", suspectColl.isEmpty() ? "" : suspectColl.get(0).getPid());
			l.put("mobile", suspectColl.isEmpty() ? "" : suspectColl.get(0).getMobile());
			l.put("mac", suspectColl.isEmpty() ? "" : suspectColl.get(0).getMac());
			l.put("important", flag ? "true" : "false");
			l.put("path", photo == null ? "" : photo.getSrc());
		});

        String nameListStr = map.get("namelist");
        if(StringUtils.isNotBlank(nameListStr)) {
            List<String> nameList = Arrays.asList(nameListStr.split(","));
            result = result.stream().filter(l->
                nameList.contains(l.get("name"))
            ).collect(Collectors.toList());
        }
		// add status info for realtime
		if (StringUtils.isNotBlank(map.get("observetime"))) {
			long observeStart = toSeconds(map.get("observetime"));
			Map<String, Status> monStat = getStatusById(monids, observeStart);
			result.forEach(a -> {
				a.put("status", monStat.get(a.get("monid")) == null ? "" : monStat.get(a.get("monid")));
			});

		}
		return new JsonRet(result);
	}

	@RequestMapping(value = "/history")
	@ResponseBody
	public JsonRet history(@RequestParam String monid, @RequestParam String fromtime) {
		Prewarning.Coll coll = new Prewarning.Coll();
		Prewarning.Query query = coll.getQuery();
		long start = toSeconds(fromtime);
		query.setFromevtime((int) start);
		query.setMonid(monid);
		query.orderBy = Prewarning.OrderByEnum.EVTIME__DESC;
		PrewarningBiz biz = new PrewarningBiz();
		List<Map<String, Object>> result = new ArrayList<>();
		try {
			biz.load(coll);
			coll.forEach(l -> {
				Map<String, Object> m = new HashMap<>();
				m.put(EVTIME, format(l.getEvtime()));
				m.put("servicecode", l.getServicecode());
				result.add(m);
			});
		} catch (NSException e) {
			logger.error("warning history db error", e);
			return new JsonRet(false, "warning history  db error");
		}

		// add place info
		LocusController.addPlaceInfo(result);

		return new JsonRet(result);

	}

	@RequestMapping(value = "/monitors")
	@ResponseBody
	public JsonRet findMonitors(@RequestParam(required = false) String name) {
		List<String> result = null;
		MonitorBiz biz = new MonitorBiz();
		Monitor.Coll coll = new Monitor.Coll();
		Monitor.Query query = coll.getQuery();
		query.setName(name);
		query.setIsvalid(1);
		query.skipTotalCount = true;
		try {
			coll = biz.load(coll);
			result = coll.stream().map(Entity::getName).distinct().collect(Collectors.toList());
			return new JsonRet(result);
		} catch (NSException e) {
			logger.error("monitor db error", e);
			return new JsonRet(false, "monitor service error");
		}
	}

	private Map<String, Entity> getMonitorsByNameAndClue(String namestr, String cluestr) {
		List<String> monames = StringUtils.isBlank(namestr) ? null : Arrays.asList(namestr.split(","));
		List<String> clues = StringUtils.isBlank(cluestr) ? null : Arrays.asList(cluestr.split(","));
		Map<String, Entity> result = new HashMap<>();
		MonitorBiz biz = new MonitorBiz();
		Monitor.Coll coll = new Monitor.Coll();
		Monitor.Query query = coll.getQuery();
		query.setNameIDList(monames);
		query.setMonkeyIDList(clues);
		query.skipTotalCount = true;
		query.setIsvalid(1);
		try {
			coll = biz.load(coll);
			result = coll.stream().collect(Collectors.toMap(Entity::getId, Function.identity()));
		} catch (NSException e) {
			logger.error("monitor db server error", e);
		}
		return result;
	}

	private Map<String, Monitor.Entity> getMonitorsById(List<String> ids) {
		Map<String, Entity> result = new HashMap<>();
		MonitorBiz biz = new MonitorBiz();
		Monitor.Coll coll = new Monitor.Coll();
		Monitor.Query query = coll.getQuery();
		query.setIdIDList(ids);
		query.setIsvalid(1);
		query.skipTotalCount = true;
		try {
			coll = biz.load(coll);
			result = coll.stream().collect(Collectors.toMap(Entity::getId, Function.identity()));
		} catch (NSException e) {
			logger.error("monitor database error", e);
		}
		return result;
	}

	private Map<String, Status> getStatusById(List<String> ids, long start) {
		Map<String, Status> result = new HashMap<>();
		PrewarningBiz biz = new PrewarningBiz();
		try {
			Prewarning.Coll coll = biz.getStatusById(ids, start);
			coll.forEach(a -> {
				String monid = a.getMonid();
				int count = a.getCount();
				int scs = a.getScs();
				if (count == 1) {
					result.put(monid, Status.NEW);
				} else if (scs == 1) {
					result.put(monid, Status.FIXED);
				} else if (scs > 1) {
					result.put(monid, Status.MOVING);
				}
			});
		} catch (NSException e) {
			logger.error("monitor status db error", e);
		}
		return result;
	}

}
