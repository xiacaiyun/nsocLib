package cn.nsoc.bizmon.web.filter;

import cn.nsoc.base.entity.sys.NSException;
import cn.nsoc.common.applib.entity.config.AppRuntimeConfig;
import cn.nsoc.common.applib.filter.BaseRightCheckInterceptor;

import java.util.UUID;

/**
 * Created by sam on 16-8-9.
 */
public class AppRightCheckInterceptor extends BaseRightCheckInterceptor {

    @Override
    protected String getAppRSAKey(UUID appId)  throws NSException {
        return  AppRuntimeConfig.Current().getRSAKey();
    }
}
