package cn.nsoc.bizmon.web.config;

import org.springframework.security.web.context.AbstractSecurityWebApplicationInitializer;

/**
 * Created by sam on 16-5-26.
 */
public class NsocAppWebApplicationInitializer extends AbstractSecurityWebApplicationInitializer {

}
