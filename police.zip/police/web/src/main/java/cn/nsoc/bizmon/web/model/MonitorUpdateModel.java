package cn.nsoc.bizmon.web.model;


/**
 * Created by Carol on 2017/7/13.
 */
public class MonitorUpdateModel {
    private String id;
    private String name;
    private String servicecode;
    private int montypeval;
    private String monkey;
    private String starttime;
    private String endtime;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getServicecode() {
        return servicecode;
    }

    public void setServicecode(String servicecode) {
        this.servicecode = servicecode;
    }

    public int getMontypeval() {
        return montypeval;
    }

    public void setMontypeval(int montypeval) {
        this.montypeval = montypeval;
    }

    public String getMonkey() {
        return monkey;
    }

    public void setMonkey(String monkey) {
        this.monkey = monkey;
    }

    public String getStarttime() {
        return starttime;
    }

    public void setStarttime(String starttime) {
        this.starttime = starttime;
    }

    public String getEndtime() {
        return endtime;
    }

    public void setEndtime(String endtime) {
        this.endtime = endtime;
    }

}
