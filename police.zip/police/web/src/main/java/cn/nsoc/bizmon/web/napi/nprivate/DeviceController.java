package cn.nsoc.bizmon.web.napi.nprivate;

import cn.nsoc.base.entity.sys.NSException;
import cn.nsoc.bizmon.biz.mysql.DeviceBiz;
import cn.nsoc.bizmon.biz.mysql.DevstatBiz;
import cn.nsoc.bizmon.biz.mysql.PlaceBiz;
import cn.nsoc.bizmon.entity.defines.Constants;
import cn.nsoc.bizmon.entity.mysql.Device;
import cn.nsoc.bizmon.entity.mysql.Devstat;
import cn.nsoc.bizmon.entity.mysql.Place;
import cn.nsoc.bizmon.util.Hptimer;
import cn.nsoc.bizmon.web.model.DeviceSearchModel;
import cn.nsoc.bizmon.web.model.EraseModel;
import cn.nsoc.common.applib.controller.NController;
import cn.nsoc.common.applib.controls.JsonRet;
import cn.nsoc.common.applib.rights.Right;
import cn.nsoc.common.storer.biz.PageContext;
import cn.nsoc.common.util.ExportHelper;
import cn.nsoc.common.util.Misc;
import org.springframework.stereotype.Controller;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletResponse;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;


/**
 * Created by Carol on 2017/7/10.
 */
@Controller
@RequestMapping(value = "/napi/private/device")
@Right(allowAnonymous = true)
public class DeviceController {


    @RequestMapping(value = "/list", method = RequestMethod.GET)
    @ResponseBody
    public JsonRet list(DeviceSearchModel model,
                        HttpServletResponse response,
                        @RequestParam(required = false) ExportHelper.ExportType expdata) throws NSException {

        PageContext pCtx = new PageContext(model);
        Device.Coll coll = new Device.Coll();
        Device.Query query = coll.getQuery();
        if (expdata != null) {
            query.start = 0;
            query.count = ExportHelper.MaxExcelCount;
        } else {
            query.start = (pCtx.getCurPage() - 1) * pCtx.getCountPerPage();
            query.count = pCtx.getCountPerPage();
        }
        Misc.objectCopy(model, query);
        if (StringUtils.hasText(query.getServicetype())) {
            if (Constants.ALL_DEVICES.compareToIgnoreCase(query.getServicetype()) == 0) {
                query.setServicetype(null);
            } else {
                query.setServicetype(query.getServicetype().replace("设备", ""));
            }
        }
        DeviceBiz biz = new DeviceBiz();
        biz.loaddevice(coll, Constants.DEVICE_STATUS_GAP, model.getKeyword());
        if (coll.isEmpty()) {
            return new JsonRet(new Object[0], pCtx);
        }
//        List<String> nos = coll.stream().map(p -> p.getNo()).distinct().collect(Collectors.toList());
        PlaceBiz pbiz = new PlaceBiz();
        Map<String, String> service = pbiz.getDictFromPlace("service");
//        List<String> codes = service.keySet().stream().distinct().collect(Collectors.toList());
        Devstat.Coll en = new Devstat.Coll();
//        Devstat.Query devQuery = en.getQuery();
//        devQuery.setDevnoIDList(nos);
//        devQuery.setServicecodeIDList(codes);
        new DevstatBiz().load(en);
        List<Object> data = new ArrayList<>();
        if (expdata != null) {
            buildExcel(coll, response);
        } else {
            coll.forEach(l -> {
                Devstat.Coll devstat = en.find(l.getNo(), l.getServicecode());
//                if (!devstat.isEmpty() && devstat.size() > 1) {
//                    for (int i = 0; i < devstat.size(); i++) {
//                        if(devstat.get(i) == null){
//                            continue;
//                        }
//                        if(model.getIsonline()!=null && model.getIsonline() && !isOnline(Constants.DEVICE_STATUS_GAP, devstat.get(i).getEvtime())){
//                            continue;
//                        }
//                        DeviceModel mo = new DeviceModel();
//                        mo.no = l.getNo();
//                        mo.mac = l.getMac();
//                        mo.servicename = service.getOrDefault(l.getServicecode(), "");
//                        mo.orgname = l.orgname;
//                        mo.devtype = devstat.get(i) == null ? 0 : devstat.get(i).getDevtype();
//                        mo.status = isOnline(Constants.DEVICE_STATUS_GAP, devstat.get(i).getEvtime());
//                        data.add(mo);
//                    }
//                }else {
                Map<String,Object> map = new HashMap<>();
                map.put("no",l.getNo());
                map.put("mac",l.getMac());
                map.put("servicename",service.getOrDefault(l.getServicecode(), ""));
                map.put("orgname",l.orgname);
                map.put("devtype",devstat.firstOrDefault() == null ? 0 : devstat.firstOrDefault().getDevtype());
                map.put("status",isOnline(Constants.DEVICE_STATUS_GAP, devstat.isEmpty() ? null : devstat));
                data.add(map);
            });
        }
        pCtx.setCollection(coll);
        return new JsonRet(data, pCtx);
    }

    @RequestMapping(value = "/summary/list", method = RequestMethod.GET)
    @ResponseBody
    public JsonRet summary() throws NSException {

        DeviceBiz biz = new DeviceBiz();
        Place.Coll summary = biz.getSummary();
        long sum;
        List<Object> result = new ArrayList<>();
        if (!summary.isEmpty()) {
            sum = summary.stream().mapToLong(e -> e.devicecount).sum();
            Map<String, Object> totalmap = new HashMap<>();
            totalmap.put("servicetype", Constants.ALL_DEVICES);
            totalmap.put("count", sum);
            result.add(totalmap);
            summary.forEach(h -> {
                Map<String, Object> map = new HashMap<>();
                map.put("servicetype", h.getServicetype() + "设备");
                map.put("count", h.devicecount);
                result.add(map);
            });
        }
        return new JsonRet(result);
    }

    @RequestMapping(value = "/erase", method = RequestMethod.POST)
    @ResponseBody
    public JsonRet erase(@RequestBody(required = false) EraseModel m) throws NSException {
        boolean rm = deleteById(m.getId());
        return new JsonRet(rm);
    }


    @RequestMapping(value = "/exportexcel", method = RequestMethod.GET)
    @ResponseBody
    public void export(@RequestParam(required = false) String ids, HttpServletResponse response) throws NSException {
        Device.Coll coll = new Device.Coll();
        Device.Query query = coll.getQuery();
        query.setNoIDList(Misc.strToStrList(ids));
        new DeviceBiz().loaddevice(coll, Constants.DEVICE_STATUS_GAP, null);
        buildExcel(coll, response);
    }

    private boolean deleteById(String id) throws NSException {
        DeviceBiz biz = new DeviceBiz();
        Device.Entity exist = new Device.Entity();
        exist.setNo(id);
        return biz.delete(exist);
    }

    private void buildExcel(Device.Coll expData, HttpServletResponse response) throws NSException {
        Map<String, String> service = new PlaceBiz().getDictFromPlace("service");
//        List<String> nos = expData.stream().map(p -> p.getNo()).distinct().collect(Collectors.toList());
//        List<String> codes = service.keySet().stream().distinct().collect(Collectors.toList());
        Devstat.Coll en = new Devstat.Coll();
//        Devstat.Query devQuery = en.getQuery();
//        devQuery.setDevnoIDList(nos);
//        devQuery.setServicecodeIDList(codes);
        new DevstatBiz().load(en);
        StringBuilder sb = new StringBuilder();
        // 添加表头
        sb.append("<table border=1><tr> " +
                "<th>设备编号</th> " +
                "<th>设备MAC</th> " +
                "<th>所属场所</th> " +
                "<th>所属厂商</th> " +
//                "<td>设备类型</td> " +
                "<th>设备状态</th></tr>");

        // 添加内容
        for (Device.Entity a : expData) {
            Devstat.Coll devstat = en.find(a.getNo(), a.getServicecode());
            String data = "";
            data = String.format("<tr> " +
                            ExportHelper.CELL_COLUMN +
                            ExportHelper.CELL_COLUMN +
                            ExportHelper.CELL_COLUMN +
                            ExportHelper.CELL_COLUMN +
//                            ExportHelper.CELL_COLUMN +
                            ExportHelper.CELL_COLUMN + "</tr>",
                    a.getNo(),
                    a.getMac(),
                    service.getOrDefault(a.getServicecode(), ""),
                    a.orgname == null ? "" : a.orgname,
//                    a.devtype,
                    isOnline(Constants.DEVICE_STATUS_GAP, devstat.isEmpty() ? null : devstat) ? "在线" : "离线");
            sb.append(data);
        }
        sb.append("</table>");
        String excelData = ExportHelper.BuildDownLoadHtml(sb.toString());
        String fileName = "设备列表";
        NController.exportToExcel(response, excelData, fileName);
    }


    public boolean isOnline(int gap, Devstat.Coll coll) {
        if(coll == null){
            return false;
        }
        long now = Hptimer.nowSeconds();
        for (Devstat.Entity item : coll) {
            if ((item.getEvtime() >= (now - gap))){
                return true;
            }
        }
        return false;
    }


}
