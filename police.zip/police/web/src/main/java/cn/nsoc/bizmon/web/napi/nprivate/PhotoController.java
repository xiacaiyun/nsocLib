package cn.nsoc.bizmon.web.napi.nprivate;


import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.util.StringUtils;
import org.springframework.validation.Errors;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.commons.CommonsMultipartFile;
import cn.nsoc.base.entity.sys.NSException;
import cn.nsoc.bizmon.biz.mysql.PhotoBiz;
import cn.nsoc.bizmon.entity.mysql.Photo;
import cn.nsoc.bizmon.web.model.BatchUpdateModel;
import cn.nsoc.bizmon.web.model.EraseModel;
import cn.nsoc.common.applib.controls.JsonRet;
import cn.nsoc.common.applib.controls.WebHelper;
import cn.nsoc.common.applib.rights.Right;
import cn.nsoc.common.provider.UserRightsProvider;
import cn.nsoc.common.storer.biz.PageContext;
import cn.nsoc.common.storer.biz.PagedModel;
import cn.nsoc.common.util.Misc;


@Controller
@RequestMapping(value = "/napi/private/photo")
@Right(allowAnonymous = true)
public class PhotoController extends AttachedHelper {

    static class SetPhotoModel extends PagedModel {
        private String id;
        private CommonsMultipartFile[] file;
        private String name;
        private String username;
        private String pid;

        public CommonsMultipartFile[] getFile() {
            return file;
        }

        public void setFile(CommonsMultipartFile[] file) {
            this.file = file;
        }

        public String getName() {
            return name;
        }

        public void setName(String name) {
            this.name = name;
        }

        public String getUsername() {
            return username;
        }

        public void setUsername(String username) {
            this.username = username;
        }

        public String getId() {
            return id;
        }

        public void setId(String id) {
            this.id = id;
        }

        public String getPid() {
            return pid;
        }

        public void setPid(String pid) {
            this.pid = pid;
        }
    }

    @Autowired
    UserRightsProvider userRightsProvier;

    @RequestMapping(value = "/list")
    @ResponseBody
    public JsonRet list(SetPhotoModel mo, HttpServletResponse response, HttpServletRequest request) throws NSException, IOException {
        PageContext pCtx = new PageContext(mo);
        Photo.Coll coll = new Photo.Coll();
        Photo.Query query = coll.getQuery();
        query.start = (pCtx.getCurPage() - 1) * pCtx.getCountPerPage();
        query.count = pCtx.getCountPerPage();
        Misc.objectCopy(mo, query);
        new PhotoBiz().load(coll);
        pCtx.setCollection(coll);
        List<Object> result = new ArrayList<>();
        for (Photo.Entity entity : coll) {
            String dir = getDir(request, entity.getName());
            File file = new File(dir, trimPath(entity.getSrc()));
            Map<String, Object> map = new HashMap<>();
            map.put("id", entity.getId());
            map.put("name", entity.getName());
            map.put("src", !file.exists() ? "" : entity.getSrc());
            map.put("username", entity.getUsername());
            map.put("pid", entity.getPid());
            result.add(map);
        }
        return new JsonRet(result, pCtx);
    }

    @RequestMapping(value = "/update", method = RequestMethod.POST)
    @ResponseBody
    public JsonRet update(SetPhotoModel model, HttpServletRequest request, Errors errors) throws NSException, IOException {
        if (errors.hasErrors()) {
            return WebHelper.checkParamErrors(errors);
        }
        boolean flag = false;
        PhotoBiz biz = new PhotoBiz();
        Photo.Entity exist = null;
        Photo.Entity o = null;
        if (StringUtils.hasText(model.getId())) {
            exist = biz.get(model.getId());
            if (exist == null) {
                return new JsonRet(false, "没有找到该记录！");
            }
            o = Misc.objectCopy(exist, new Photo.Entity());
            Misc.objectCopy(model, o);
//            String dirPath = getDir(request);
//            deleteByFileName(dirPath,o.getSrc());
//            saveSingleFile(dirPath,model.getFile()[0]);
        } else {
            if (model.getFile() != null) {
                flag = saveFile(model.getFile(), model.getName(), request);
            } else {
                return new JsonRet(false, "照片不能为空！");
            }
        }

        if (exist != null) {
            flag = biz.update(o);
        }
        if (flag) {
            return new JsonRet(flag, "操作成功！");
        } else {
            return new JsonRet(flag, "操作失败！");
        }


    }

    @RequestMapping(value = "/erase", method = RequestMethod.POST)
    @ResponseBody
    public JsonRet erase(@RequestBody(required = true) EraseModel m, HttpServletRequest request) throws NSException {
        Photo.Entity entity = new PhotoBiz().get(m.getId());
        if (entity != null) {
            String dirPath = getDir(request, entity.getName());
            deleteById(m.getId(), dirPath);
            return new JsonRet(true, "删除成功！");
        } else {
            return new JsonRet(false, "删除失败！");
        }
    }

    private boolean deleteById(String id, String path) throws NSException {
        if (StringUtils.hasText(id)) {
            PhotoBiz biz = new PhotoBiz();
            Photo.Entity p = biz.get(id);
            String name = p.getSrc().substring(p.getSrc().lastIndexOf("/") + 1);
            eraseFile(path, name);
            Photo.Entity exist = new Photo.Entity();
            exist.setId(id);
            biz.delete(exist);
            return true;
        }
        return false;
    }

    @RequestMapping(value = "/batchcmd", method = RequestMethod.POST)
    @ResponseBody
    public JsonRet PhotoBatchcmd(@RequestBody BatchUpdateModel m, HttpServletRequest request) throws NSException {

        boolean isAllOK = true;
        List<String> ids = new ArrayList<>();
        if (m.getCmd() != null) {
            List<String> strings = Misc.strToStrList(m.getItem());
            if (!strings.isEmpty()) {
                for (String id : strings) {
                    switch (m.getCmd()) {
                        // 勾选删除操作
                        case delete: {
                            Photo.Entity entity = new PhotoBiz().get(id);
                            boolean rm = deleteById(id, getDir(request, entity.getName()));
                            if (!rm) {
                                // 未全部执行成功
                                isAllOK = false;
                                ids.add(id);
                            }
                        }
                        break;
                        default:
                            break;
                    }
                }

            }
        }
        if (isAllOK) {
            return new JsonRet(true);
        } else {
            return new JsonRet(false, "删除失败！");
        }
    }

    @RequestMapping(value = "/buildzip", method = RequestMethod.GET)
    @ResponseBody
    public JsonRet downloadZip(@RequestParam(required = true) String name, HttpServletRequest request) throws NSException {
        String src = "";
        try {
            src =   buildZip(name, request);
        } catch (FileNotFoundException e) {
            Misc.ignoreException(e);
        }
        return new JsonRet(true, absolutePathToRelativePath(src));

    }

}
