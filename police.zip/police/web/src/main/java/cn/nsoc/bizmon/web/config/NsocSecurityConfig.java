package cn.nsoc.bizmon.web.config;

import cn.nsoc.base.entity.sys.NSException;
import cn.nsoc.common.applib.webconfig.BaseAppConfig;
import cn.nsoc.common.applib.webconfig.BaseNsocWebSecurityConfigurerAdapter;
import cn.nsoc.license.client.AppLicense;
import cn.nsoc.license.client.License;
import cn.nsoc.bizmon.biz.AppAuth;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;

import java.io.IOException;
import java.util.Locale;
import java.util.UUID;

/**
 * Created by sam on 16-5-26.
 */
@Configuration
@EnableWebSecurity
public class NsocSecurityConfig extends BaseNsocWebSecurityConfigurerAdapter {


    @Autowired
    private AppConfig appConfig;

    @Override
    protected UUID getAppId() {
        return AppAuth.AppID;
    }

    @Override
    protected BaseAppConfig getAppConfig() {
        return appConfig;
    }

    @Override
    protected String getFrameworkRoot() {
        return appConfig.getFrameworkRoot();
    }

    @Override
    public boolean checkLicense() throws NSException {
        try {
            License lic = AppLicense.getInstance().getLicense();
            if (lic == null)
                return false;

            return lic.isValidApp(AppAuth.AppID);
        }
        catch (Exception ex){
            throw new NSException(ex);
        }

    }

}
