package cn.nsoc.bizmon.web.napi.nprivate;

import cn.nsoc.base.entity.sys.NSException;
import cn.nsoc.bizmon.biz.SuspectJsonModel;
import cn.nsoc.bizmon.biz.mysql.SuspectBiz;
import cn.nsoc.bizmon.biz.mysql.SuspectinfoBiz;
import cn.nsoc.bizmon.entity.mysql.Suspect;
import cn.nsoc.bizmon.entity.mysql.Suspectinfo;
import cn.nsoc.bizmon.web.model.BatchUpdateModel;
import cn.nsoc.bizmon.web.model.EraseModel;
import cn.nsoc.bizmon.web.model.SuspectUpdateModel;
import cn.nsoc.common.applib.controls.JsonRet;
import cn.nsoc.common.applib.controls.PageContext;
import cn.nsoc.common.applib.controls.PagedModel;
import cn.nsoc.common.applib.controls.WebHelper;
import cn.nsoc.common.applib.rights.Right;
import cn.nsoc.common.util.ExportHelper;
import cn.nsoc.common.util.Misc;
import org.apache.log4j.Logger;
import org.springframework.stereotype.Controller;
import org.springframework.util.StringUtils;
import org.springframework.validation.Errors;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletResponse;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Created by Administrator on 2017/7/11.
 */
@Controller
@RequestMapping(value = "/napi/private/suspect")
@Right(allowAnonymous = true)
public class SuspectController {
    private static final Logger appLogger = Logger.getLogger(SuspectController.class);

    @RequestMapping(value = "/list")
    @ResponseBody
    public JsonRet list(HttpServletResponse response,
                        @RequestParam(required = false) String keyword,
                        @RequestParam(required = false) String infoid,
                        @RequestParam(required = false) ExportHelper.ExportType expdata, PagedModel mo) throws NSException {
        PageContext pCtx = new PageContext(mo);
        Suspect.Coll coll = new Suspect.Coll();
        Suspect.Query query = coll.getQuery();
        query.setInfoid(infoid);
        SuspectBiz biz = new SuspectBiz();
        if (expdata != null) {
            query.start = 0;
            query.count = ExportHelper.MaxExcelCount;
        } else {
            query.start = (pCtx.getCurPage() - 1) * pCtx.getCountPerPage();
            query.count = pCtx.getCountPerPage();
        }
        try {
            SuspectinfoBiz suspectinfoBiz = new SuspectinfoBiz();
            biz.loadBykeyword(coll, keyword);
            pCtx.setCollection(coll);
            List<Object> result = new ArrayList<>();
            if (expdata != null) {
                suspectinfoBiz.buildExcel(coll, response);
            } else {
                for (Suspect.Entity entity : coll) {
                    Suspectinfo.Entity info = suspectinfoBiz.get(entity.getInfoid());
                    Map<String, Object> map = new HashMap<>();
                    map.put("id", entity.getId());
                    map.put("seqno", entity.getSeqno());
                    map.put("username", entity.getUsername());
                    map.put("pid", entity.getPid());
                    map.put("mobile", entity.getMobile());
                    map.put("mac", entity.getMac());
                    map.put("wxgroupid", entity.getWxgroupid());
                    map.put("wx", entity.getWx());
                    map.put("wxid", entity.getWxid());
                    map.put("qq", entity.getQq());
                    map.put("other", entity.getOther());
                    map.put("monitor", info == null?"":info.getName());
                    result.add(map);
                }
            }

            return new JsonRet(result, pCtx);
        } catch (Exception e) {
            appLogger.error("suspect load failed!: " + e);
            return new JsonRet(false, e.getMessage());
        }

    }


    @RequestMapping(value = "/update", method = RequestMethod.POST)
    @ResponseBody
    public JsonRet update(@RequestBody SuspectUpdateModel model, Errors errors) throws NSException {
        if (errors.hasErrors()) {
            return WebHelper.checkParamErrors(errors);
        }
        if (model.getPid().length() > 20) {
            return new JsonRet(false, "证件号长度过长！");
        }
        SuspectBiz biz = new SuspectBiz();
        Suspect.Entity exist = biz.get(model.getId());
        if (exist == null) {
            return new JsonRet(false, "更新失败!");
        }
        SuspectJsonModel other = model.getOther();
        Misc.objectCopy(model, exist);
        exist.setOther(Misc.toJson(other));
        boolean update = biz.update(exist);
        if (update)
            return new JsonRet(true, "更新成功！");
        else
            return new JsonRet(false, "更新失败！");
    }

    @RequestMapping(value = "/erase", method = RequestMethod.POST)
    @ResponseBody
    public JsonRet erase(@RequestBody(required = false) EraseModel m) throws NSException {
        boolean rm = deleteById(m.getId());
        return new JsonRet(rm);
    }


    @RequestMapping(value = "/exportexcel", method = RequestMethod.GET)
    @ResponseBody
    public void export(@RequestParam(required = false) String ids, HttpServletResponse response) throws NSException {
        Suspect.Coll coll = new Suspect.Coll();
        Suspect.Query query = coll.getQuery();
        query.setIdIDList(Misc.strToStrList(ids));
        new SuspectBiz().loadBykeyword(coll, null);
        new SuspectinfoBiz().buildExcel(coll, response);
    }

    private boolean deleteById(String id) throws NSException {
        boolean flag;
        if (StringUtils.hasText(id)) {
            SuspectBiz biz = new SuspectBiz();
            Suspect.Entity exist = new Suspect.Entity();
            exist.setId(id);
            flag = biz.delete(exist);
        } else {
            flag = false;
        }
        return flag;

    }

    @RequestMapping(value = "/batchcmd", method = RequestMethod.POST)
    @ResponseBody
    public JsonRet suspectBatchcmd(@RequestBody BatchUpdateModel m, HttpServletResponse response) throws NSException {

        boolean isAllOK = true;
        List<String> lstErrors = new ArrayList<>();
        if (m.getCmd() != null) {
            List<String> strings = Misc.strToStrList(m.getItem());
            if (!strings.isEmpty()) {
                for (String id : strings) {
                    switch (m.getCmd()) {
                        // 勾选删除操作
                        case delete: {
                            boolean rm = deleteById(id);
                            if (!rm) {
                                // 未全部执行成功
                                isAllOK = false;
                                lstErrors.add(id);
                            }
                        }
                        break;
                        default:
                            break;
                    }
                }

            }
        }
        if (isAllOK) {
            return new JsonRet(true);
        } else {
            return new JsonRet(false, String.format("%s 删除失败！",lstErrors.toString()));
        }
    }

}
