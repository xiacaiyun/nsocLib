package cn.nsoc.bizmon.web.napi.ninternal;

import static cn.nsoc.bizmon.util.Hptimer.format;
import static cn.nsoc.bizmon.util.Hptimer.toSeconds;
import static java.util.Comparator.comparing;
import static java.util.stream.Collectors.toList;
import static java.util.stream.Collectors.toSet;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.function.Function;
import java.util.stream.Collectors;
import javax.servlet.http.HttpServletResponse;
import org.apache.commons.lang3.StringUtils;
import org.apache.hadoop.hbase.util.Base64;
import org.apache.hadoop.io.IOUtils;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import cn.nsoc.base.entity.sys.NSException;
import cn.nsoc.bizmon.biz.dw.DataWareMgr;
import cn.nsoc.bizmon.biz.dw.ESResult;
import cn.nsoc.bizmon.biz.dw.HdfsHelper;
import cn.nsoc.bizmon.biz.dw.entity.DevGreatSearch;
import cn.nsoc.bizmon.entity.api.Person;
import cn.nsoc.bizmon.entity.api.SummaryResponse;
import cn.nsoc.bizmon.web.model.SummaryRequest;
import cn.nsoc.common.applib.controls.IPager;
import cn.nsoc.common.applib.controls.JsonRet;
import cn.nsoc.common.applib.controls.PageContext;
import cn.nsoc.common.applib.controls.PagedModel;
import cn.nsoc.common.applib.rights.Right;
import cn.nsoc.nspider.app.police.entity.objects.ObjDevVirtLookup;
import cn.nsoc.nspider.app.police.entity.rule.AuthenticateType;
import cn.nsoc.nspider.app.police.entity.rule.TrackCatelog;


@Controller
@RequestMapping(value = "/napi/internal/identity")
@Right(allowAnonymous = true)
public class IdentityController {
    private static final Logger logger = Logger.getLogger(IdentityController.class);
    @Autowired
    private DataWareMgr dwMgr;
    @Autowired
    private HdfsHelper hdfsHelper;

    @RequestMapping(value = "/summary")
    @ResponseBody
    public JsonRet summary(@RequestBody SummaryRequest request) {
        long start = toSeconds(request.getFromtime());
        long end = toSeconds(request.getTotime());
        String val = request.getValue();
        String type = request.getType();
        if (StringUtils.isBlank(val) && StringUtils.isNotBlank(type)) {
            return new JsonRet(false, "无查询值");
        }
        PageContext pCtx = new PageContext((IPager) request);
        int rowStart = (pCtx.getCurPage() - 1) * pCtx.getCountPerPage();
        int rowCount = pCtx.getCountPerPage();

        List<SummaryResponse> result = new ArrayList<>();
        try {
            if (("virtual").equalsIgnoreCase(type)) {
                List<Map<String, Object>> certs = dwMgr.findIdFromVirt(val);
                if (certs.size() > 0) {
                    type = "pids";
                    val = certs.stream()
                            .filter(a -> !AuthenticateType.MOBILE
                                    .equals(a.get(ObjDevVirtLookup.FD_CERT_TYPE)))
                            .map(a -> (String) a.get(ObjDevVirtLookup.FD_CERT_ID))
                            .collect(Collectors.joining("','"));
                    if (StringUtils.isNotBlank(val)) {
                        result.addAll(dwMgr.summary(type, String.format("'%s'", val), start, end,
                                rowStart, rowCount));
                    }
                    type = "mobiles";
                    val = certs.stream()
                            .filter(a -> AuthenticateType.MOBILE
                                    .equals(a.get(ObjDevVirtLookup.FD_CERT_TYPE)))
                            .map(a -> (String) a.get(ObjDevVirtLookup.FD_CERT_ID))
                            .collect(Collectors.joining("','"));
                    if (StringUtils.isNotBlank(val)) {
                        result.addAll(dwMgr.summary(type, String.format("'%s'", val), start, end,
                                rowStart, rowCount));
                    }

                }
            } else {
                if (("mac").equalsIgnoreCase(type)) {
                    val = dwMgr.findMobileFromMac(val);
                    type = "mobile";
                }
                if (StringUtils.isNotBlank(val)) {
                    result = dwMgr.summary(type, val, start, end, rowStart, rowCount);
                }
            }
        } catch (Exception e) {
            logger.error("hive db failed", e);
            return new JsonRet(false, "query failed");
        }
        if (result != null) {
            pCtx.setCountCurPage(result.size());
        }
        return new JsonRet(result, pCtx);
    }

    @RequestMapping(value = "/findMac")
    @ResponseBody
    public JsonRet findMac(@RequestParam(required = true) String mobile) {
        Map<String, Object> result = new HashMap<>();
        result.put("mobile", mobile);
        try {
            result.put("mac", dwMgr.findMacFromMobile(mobile));
        } catch (Exception e) {
            logger.error("hive db error", e);
        }
        return new JsonRet(result);
    }

    @RequestMapping(value = "/findVirs")
    @ResponseBody
    public JsonRet findVirs(@RequestParam(required = true) String pid,
            @RequestParam(required = true) String mobile) {
        if (StringUtils.isBlank(pid) && StringUtils.isBlank(mobile)) {
            return new JsonRet(false, "request missing pid/mobile");
        }
        List<Map<String, Object>> result = new ArrayList<>();
        try {
            List<Map<String, Object>> coll = dwMgr.findVirtById(pid, mobile);
            result = coll.stream().map(l -> {
                Map<String, Object> m = new HashMap<>();
                if (!VirtualCodes.codeTable.containsKey((String) l.get("account_type"))) {
                    return null;
                }
                m.put("virtype", l.get("account_type"));
                m.put("virval", l.get("account_code"));
                m.put("virname", VirtualCodes.codeTable.get((String) l.get("account_type")));
                return m;
            }).filter(l -> l != null).collect(toList());
        } catch (Exception e) {
            logger.error("hive db error", e);
        }
        return new JsonRet(result);
    }

    @RequestMapping(value = "/trace")
    @ResponseBody
    public JsonRet trace(@RequestBody Map<String, String> map) {
        long start = toSeconds(map.get("fromtime"));
        long end = toSeconds(map.get("totime"));
        String mac = map.get("mac");
        String pid = map.get("pid");
        String mobile = map.get("mobile");
        List<Map<String, Object>> result = new ArrayList<Map<String, Object>>();
        try {
            if (StringUtils.isNotBlank(mac)) {
                result.addAll(dwMgr.macTrace(start, end, mac));
            }
            if (StringUtils.isNotBlank(pid) || StringUtils.isNotBlank(mobile)) {
                result.addAll(dwMgr.fulTrace(start, end, pid, mobile));

            }
        } catch (Exception e) {
            logger.error("hive db error", e);
        }
        result = result.stream().distinct().sorted(
                comparing((Map<String, Object> a) -> (long) a.get("online_time")).reversed())
                .collect(toList());
        for (Map<String, Object> iter : result) {
            iter.put("time", format((long) iter.remove("online_time")));
            iter.put("servicecode", iter.remove("service_code"));
        }
        LocusController.addPlaceInfo(result);
        return new JsonRet(result);
    }

    @RequestMapping(value = "/icons")
    @ResponseBody
    public JsonRet icons(@RequestBody Map<String, String> map) {
        long start = toSeconds(map.get("fromtime"));
        long end = toSeconds(map.get("totime"));
        String pid = map.get("pid");
        List<String> result = null;
        try {
            result = dwMgr.findImgs(start, end, pid);
        } catch (Exception e) {
            logger.error("hive error", e);
        }
        return new JsonRet(result);
    }

    @RequestMapping(value = "/search")
    @ResponseBody
    public JsonRet search(@RequestBody Map<String, String> map, PagedModel model) {
        String keyword = map.get("value");
        if (StringUtils.isBlank(keyword) && StringUtils.isNotBlank(map.get("type"))) {
            return new JsonRet(false, "未提供查询关键字");
        }
        if (StringUtils.isNotBlank(map.get("pageId"))) {
            model.setPageId(Integer.parseInt(map.get("pageId")));
        }
        if (StringUtils.isNotBlank(map.get("countPerPage"))) {
            model.setCountPerPage(Integer.parseInt(map.get("countPerPage")));
        }
        PageContext pCtx = new PageContext(model);
        int rowStart = (pCtx.getCurPage() - 1) * pCtx.getCountPerPage();
        int rowCount = pCtx.getCountPerPage();

        List<Person> result = new ArrayList<>();
        TrackCatelog type = transType(map.get("type"));
        String subtype = map.get("subtype");
        if (type == TrackCatelog.CERT && "name".equals(map.get("type"))) {
            subtype = map.get("type");
        }
        try {
            ESResult<DevGreatSearch> summarys =
                    dwMgr.search(keyword, type, subtype, rowStart, rowCount);
            pCtx.setTotalCount(summarys.getTotal());
            pCtx.setCountCurPage((int) summarys.getCurrent());
            if (summarys.getCurrent() > 0) {
                List<DevGreatSearch> gs = summarys.getData();
                result = gs.parallelStream().map(l -> dwMgr.findInfo(l.getId())).collect(toList());
                Map<String, DevGreatSearch> gsMap = gs.stream()
                        .collect(Collectors.toMap(DevGreatSearch::getId, Function.identity()));

                result.forEach(l -> {
                    switch (type) {
                        case CERT:
                            l.setPid(gsMap.get(l.getId()).getKeyword());
                            l.setName(gsMap.get(l.getId()).getUsername());
                            break;
                        case MOBILE:
                            l.getMobiles().add(gsMap.get(l.getId()).getKeyword());
                            break;
                        case MAC:
                            l.getMacs().add(gsMap.get(l.getId()).getKeyword());
                            break;
                        case VIRTUAL:
                            Map<String, String> m = new HashMap<String, String>();
                            m.put("virval", gsMap.get(l.getId()).getKeyword());
                            m.put("virtype", gsMap.get(l.getId()).getSubCatelog());
                            l.getVirtuals().add(m);
                            break;
                        default:
                            break;
                    }
                });

                result.parallelStream().forEach(l -> {
                    Set<Map<String, String>> virtuals = l.getVirtuals().stream()
                            .filter(m -> VirtualCodes.codeTable.containsKey(m.get("virtype")))
                            .map(m -> {
                                m.put("virname", VirtualCodes.codeTable.get(m.get("virtype")));
                                return m;
                            }).collect(toSet());
                    l.setVirtuals(virtuals);
                });
            }
        } catch (Exception e) {
            logger.error("es failed", e);
            return new JsonRet(false, "query failed");
        }
        return new JsonRet(result, pCtx);
    }
    
    @RequestMapping(value = "/img")
    public void downloadImg(@RequestParam(required = true) String file,
            HttpServletResponse response) throws IOException {
        String image = null;
        if (StringUtils.isBlank(file) || StringUtils.isBlank(image = dwMgr.findImgByVK(file))) {
            response.sendError(HttpServletResponse.SC_NOT_FOUND);
            return;
        }

        OutputStream out = response.getOutputStream();
        out.write(Base64.decode(image));
        response.setContentType("image/*");// 设置强制下载不打开
        response.setHeader("content-disposition", "attachment;fileName=" + file + ".jpg");
    }
    
    @RequestMapping(value = "/icon")
    public void downloadIcon(@RequestParam(required = true) String pid,
            HttpServletResponse response) throws IOException {
        String image = null;
        if (StringUtils.isBlank(pid) || StringUtils.isBlank(image = dwMgr.findIconByPid(pid))) {
            response.sendError(HttpServletResponse.SC_NOT_FOUND);
            return;
        }

        OutputStream out = response.getOutputStream();
        out.write(Base64.decode(image));
        response.setContentType("image/*");// 设置强制下载不打开
        response.setHeader("content-disposition", "attachment;fileName=" + pid + ".jpg");
    }

    private TrackCatelog transType(String type) {
        switch (type) {
            case "pid":
            case "name":
                return TrackCatelog.CERT;
            case "mobile":
                return TrackCatelog.MOBILE;
            case "mac":
                return TrackCatelog.MAC;
            case "virtual":
                return TrackCatelog.VIRTUAL;
            default:
                return TrackCatelog.UNKNOWN;
        }
    }

}
