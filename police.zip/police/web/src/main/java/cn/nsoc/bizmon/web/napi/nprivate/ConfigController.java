package cn.nsoc.bizmon.web.napi.nprivate;


import cn.nsoc.base.entity.sys.NSException;
import cn.nsoc.bizmon.biz.mysql.ConfigBiz;
import cn.nsoc.bizmon.biz.mysql.SuspectinfoBiz;
import cn.nsoc.bizmon.entity.mysql.Config;
import cn.nsoc.bizmon.entity.mysql.Suspectinfo;
import cn.nsoc.bizmon.web.model.BatchUpdateModel;
import cn.nsoc.bizmon.web.model.EraseModel;
import cn.nsoc.common.applib.controls.JsonRet;
import cn.nsoc.common.applib.controls.PageContext;
import cn.nsoc.common.applib.controls.PagedModel;
import cn.nsoc.common.applib.controls.WebHelper;
import cn.nsoc.common.applib.rights.Right;
import cn.nsoc.common.util.Misc;
import org.springframework.stereotype.Controller;
import org.springframework.validation.Errors;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

/**
 * Created by Carol on 2017/9/7.
 */
@Controller
@RequestMapping(value = "/napi/private/config")
@Right(allowAnonymous = true)
public class ConfigController {


    @RequestMapping(value = "/list")
    @ResponseBody
    public JsonRet list(PagedModel mo) throws NSException {
        PageContext pCtx = new PageContext(mo);
        Config.Coll coll = new Config.Coll();
        Config.Query query = coll.getQuery();
        query.start = (pCtx.getCurPage() - 1) * pCtx.getCountPerPage();
        query.count = pCtx.getCountPerPage();
        new ConfigBiz().load(coll);
        pCtx.setCollection(coll);
        return new JsonRet(coll, pCtx);
    }

    @RequestMapping(value = "/update", method = RequestMethod.POST)
    @ResponseBody
    public JsonRet update(@RequestBody Config.Entity model, Errors errors) throws NSException {
        if (errors.hasErrors()) {
            return WebHelper.checkParamErrors(errors);
        }

        ConfigBiz biz = new ConfigBiz();
        Config.Entity exist = null;
        Config.Entity o = null;
        //修改时
        if (model.getId() > 0) {  //id主键自增 > 0   有4个对象(页面接收参数的model,DB库存储的对象exist,
            exist = biz.get(model.getId());
            if(exist == null) {
                return new JsonRet(false, "没有找到该记录");
            }
            if(model.getDetail().compareToIgnoreCase(exist.getDetail())!=0){ //编辑某id时输入新的detail
                if(!detailIfRepeat(model.getDetail())){ //编辑某id时对应的detail跟其他所有的detail比是否重复
                    return new JsonRet(false,"此案件类型已存在!");
                }
            }
            o = Misc.objectCopy(exist, new Config.Entity()); //exist替换掉Config.Entity
        } else {
         //新增时
            o = new Config.Entity();
            if(!detailIfRepeat(model.getDetail())){
                return new JsonRet(false,"此案件类型已存在!");
            }
        }
        Misc.objectCopy(model, o); //把model接收的所有前台传来的参数 赋给o
        if (exist == null) {
            biz.insert(o);
        } else {
            biz.update(o);
        }
        return new JsonRet(true);
    }

    @RequestMapping(value = "/erase", method = RequestMethod.POST)
    @ResponseBody
    public JsonRet erase(@RequestBody(required = true) EraseModel m) throws NSException {
        boolean rm = deleteById(Integer.parseInt(m.getId()));
        if(!rm){
            return new JsonRet(rm,"该类别被使用中，不能删除"); //config表里的id和suspect_info的configid若相同，不能删除
        }
        return new JsonRet(rm);
    }

    private boolean deleteById(int id) throws NSException {
        boolean sameIdNotExist = configIdifnotexist(id);
        if(sameIdNotExist) {
            ConfigBiz biz = new ConfigBiz();
            Config.Entity exist = new Config.Entity();
            exist.setId(id);
            return biz.delete(exist);
        }
        return false;
    }

    @RequestMapping(value = "/batchcmd", method = RequestMethod.POST)
    @ResponseBody
    public JsonRet ConfigBatchcmd(@RequestBody BatchUpdateModel m) throws NSException {

        boolean isAllOK = true;
        List<Integer> ids = new ArrayList<>();
        if (m.getCmd() != null) {
            List<Integer> strings = Misc.strToIntList(m.getItem());
            if (!strings.isEmpty()) {
                for (Integer id : strings) {
                    switch (m.getCmd()) {
                        // 勾选删除操作
                        case delete: {
                            boolean rm = deleteById(id);
                            if (!rm) {
                                // 未全部执行成功
                                isAllOK = false;
                                ids.add(id);
                            }
                        }
                        break;
                        default:
                            break;
                    }
                }

            }
        }
        if (isAllOK) {
            return new JsonRet(true);
        } else {
            return new JsonRet(false, String.format("%s 类别使用中，不能删除！",ids.toString()));
        }
    }

    private boolean configIdifnotexist(int id) throws NSException{
        Suspectinfo.Coll coll = new Suspectinfo.Coll();
        new SuspectinfoBiz().load(coll);
        List<Suspectinfo.Entity> sameIdList = coll.stream().filter(l -> l.getConfigid() == id).collect(Collectors.toList());
        if(!sameIdList.isEmpty()){
            return false;
        }else{
            return true;
        }
    }

    private boolean detailIfRepeat(String detail) throws NSException{ //传入的detail和config表内所有的detail比较是否重复
        Config.Coll coll = new Config.Coll();
        new ConfigBiz().load(coll);
        List<Config.Entity> sameDetailList = coll.stream().filter(p -> p.getDetail().compareToIgnoreCase(detail) == 0).collect(Collectors.toList());
        if(!sameDetailList.isEmpty()){
            return false;
        }
        return true;
    }


}
