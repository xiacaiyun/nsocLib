package cn.nsoc.bizmon.web.config;

import cn.nsoc.bizmon.biz.AppAuth;
import cn.nsoc.bizmon.web.filter.AppRightCheckInterceptor;
import cn.nsoc.bizmon.web.schedule.PolicehpScheduler;
import cn.nsoc.common.applib.filter.ExceptionInterceptor;
import cn.nsoc.common.applib.webconfig.BaseNsocWebMvcConfigurerAdapter;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.ImportResource;
import org.springframework.http.CacheControl;
import org.springframework.scheduling.annotation.EnableScheduling;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.web.servlet.config.annotation.EnableWebMvc;
import org.springframework.web.servlet.config.annotation.InterceptorRegistry;
import org.springframework.web.servlet.config.annotation.ResourceHandlerRegistry;

/**
 * Created by sam on 16-5-26.
 */
@Configuration
@EnableWebMvc
@EnableScheduling
@ComponentScan(basePackages = {"cn.nsoc.bizmon.web"})
@ImportResource({"WEB-INF/applicationContext.xml"})
public class NsocAppConfig extends BaseNsocWebMvcConfigurerAdapter {

    private static final Log logger = LogFactory.getLog(NsocAppConfig.class);

    @Autowired
    private AppConfig appConfig;

    @Override
    public AppConfig getAppConfig() {
        return appConfig;
    }


    @Override
    public void addResourceHandlers(ResourceHandlerRegistry registry) {
        super.addResourceHandlers(registry);
        registry.addResourceHandler("/file/**")
                .addResourceLocations("/file/")
                .setCacheControl(CacheControl.noStore());
    }


    @Override
    public void addInterceptors(InterceptorRegistry registry) {
        super.addInterceptors(registry);
        registry.addInterceptor(new AppRightCheckInterceptor());
        registry.addInterceptor(new ExceptionInterceptor(AppAuth.SZPRODUCTSHORTNAME));
    }

    
    
	@Autowired
	PolicehpScheduler policehpScheduler;
	
    @Scheduled(cron="0 0 0 * * *")
    public void clearExpiredPrewarn() {
    	policehpScheduler.clearExpiredPrewarn();
    }
    
    @Scheduled(cron="10 0 0 * * *")
    public void clearExpiredDevstat() {
    	policehpScheduler.clearExpiredDevstat();
    }
    
    @Scheduled(cron="20 0 0 * * *")
    public void clearExpiredHotstat() {
    	policehpScheduler.clearExpiredHotstat();
    }
    
    @Scheduled(cron="30 0 0 * * *")
    public void clearExpiredPlace() {
    	policehpScheduler.clearExpiredPlace();
    }
}
