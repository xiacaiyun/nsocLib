package cn.nsoc.bizmon.web.model;


import cn.nsoc.common.storer.biz.PagedModel;

import java.util.List;

public class AlarmSearchModel extends PagedModel {
    private String monkey;
    private Integer montype;
    private List<String> nameIDList;
    private List<String> monkeyIDList;
    private Integer isvalid;
    private String Fromevtime;
    private String Toevtime;


    public Integer getMontype() {
        return montype;
    }

    public void setMontype(Integer montype) {
        this.montype = montype;
    }

    public List<String> getNameIDList() {
        return nameIDList;
    }

    public void setNameIDList(List<String> nameIDList) {
        this.nameIDList = nameIDList;
    }

    public Integer getIsvalid() {
        return isvalid;
    }

    public void setIsvalid(Integer isvalid) {
        this.isvalid = isvalid;
    }

    public String getFromevtime() {
        return Fromevtime;
    }

    public void setFromevtime(String fromevtime) {
        Fromevtime = fromevtime;
    }

    public String getToevtime() {
        return Toevtime;
    }

    public void setToevtime(String toevtime) {
        Toevtime = toevtime;
    }

    public List<String> getMonkeyIDList() {
        return monkeyIDList;
    }

    public void setMonkeyIDList(List<String> monkeyIDList) {
        this.monkeyIDList = monkeyIDList;
    }

    public String getMonkey() {
        return monkey;
    }

    public void setMonkey(String monkey) {
        this.monkey = monkey;
    }
}
