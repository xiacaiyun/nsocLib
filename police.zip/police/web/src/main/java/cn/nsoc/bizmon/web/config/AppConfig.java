package cn.nsoc.bizmon.web.config;

import cn.nsoc.common.applib.webconfig.BaseAppConfig;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.PropertySource;
import org.springframework.stereotype.Component;
import org.springframework.util.Assert;
import org.springframework.util.StringUtils;

/**
 * Created by sam on 16-5-28.
 */
@Component
@PropertySource("classpath:appConfig.properties")
public class AppConfig extends BaseAppConfig {

    private String frameworkRoot;

    public String getFrameworkRoot() {
        return frameworkRoot;
    }

    @Value("${frameworkRoot}")
    public void setFrameworkRoot(String frameworkRoot) {
        Assert.hasText(frameworkRoot,"AppConfig.frameworkRoot 不能为空！");

        this.frameworkRoot = StringUtils.trimTrailingCharacter(frameworkRoot.trim(),'/');
    }

    /* 更改处理成功的文件名 */
    @Value("${app.renameDoneFile:true}")
    public boolean renameDoneFile;
}
