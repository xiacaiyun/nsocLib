package cn.nsoc.bizmon.web.napi.nprivate;

import cn.nsoc.base.entity.sys.NSException;
import cn.nsoc.bizmon.biz.excel.FileUpload;
import cn.nsoc.bizmon.biz.mysql.ConfigBiz;
import cn.nsoc.bizmon.biz.mysql.SuspectBiz;
import cn.nsoc.bizmon.biz.mysql.SuspectinfoBiz;
import cn.nsoc.bizmon.entity.defines.Constants;
import cn.nsoc.bizmon.entity.mysql.Suspect;
import cn.nsoc.bizmon.entity.mysql.Suspectinfo;
import cn.nsoc.bizmon.web.model.BatchUpdateModel;
import cn.nsoc.bizmon.web.model.EraseModel;
import cn.nsoc.bizmon.web.model.SuspectInfoModel;
import cn.nsoc.common.applib.controls.JsonRet;
import cn.nsoc.common.applib.controls.PageContext;
import cn.nsoc.common.applib.controls.PagedModel;
import cn.nsoc.common.applib.controls.WebHelper;
import cn.nsoc.common.applib.rights.Right;
import cn.nsoc.common.auth.NsocUser;
import cn.nsoc.common.provider.NUserInfoProvider;
import cn.nsoc.common.util.ExportHelper;
import cn.nsoc.common.util.IDWorker;
import cn.nsoc.common.util.IntEncoder;
import cn.nsoc.common.util.Misc;
import org.apache.commons.collections.map.HashedMap;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.util.StringUtils;
import org.springframework.validation.Errors;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.commons.CommonsMultipartFile;

import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

/**
 * Created by Administrator on 2017/7/11.
 */
@Controller
@RequestMapping(value = "/napi/private/suspectinfo")
@Right(allowAnonymous = true)
public class SuspectInfoController {

    private static final Logger logger = Logger.getLogger(SuspectInfoController.class);
    @Autowired
    private FileUpload fileupload;

    @RequestMapping(value = "/uploadexcel", method = RequestMethod.POST)
    @ResponseBody
    public JsonRet uploadExcel(@RequestParam(value = "files", required = false) CommonsMultipartFile[] files,
                               @RequestParam String name, @RequestParam Integer configid) throws NSException, IOException {
        boolean isallok = true;
        String infoId = "";
        if (files == null) {
            return new JsonRet(false, "上传文件为空！");
        }
        Suspectinfo.Entity info = new Suspectinfo.Entity();
        info.setConfigid(configid);
        info.setId(IntEncoder.encode36(IDWorker.NextID()));
        info.setName(name);
        info.setCreatetime(LocalDateTime.now());
        info.setUpdatetime(info.getCreatetime());
        info.setUserid(NsocUser.getCurrentUser().getUserId());
        ReturnModel model = suspectInfoIfNotRepeat(info.getName());
        if (model != null) {
            Map<Integer, String> configDict = new ConfigBiz().getConfigDict();
            if (configid.compareTo(model.configId) != 0) {
                return new JsonRet(false, String.format("类别应该为%s", configDict.getOrDefault(model.configId, "")));
            }
            infoId = model.infoId;
        } else {
            new SuspectinfoBiz().insert(info);
            infoId = info.getId();
        }

        StringBuilder sb = new StringBuilder();
        for (CommonsMultipartFile file : files) {
            if (!Misc.isPattern(file.getOriginalFilename(), Constants.UPLOAD_ALLOW_EXTS)) {
                return new JsonRet(false, "上传文件格式错误！");
            }
            Map<String, Integer> columMap = new HashedMap();
            List<List<String>> lists = fileupload.readXls(file, columMap, 1);
            if (lists.isEmpty()) {
                return new JsonRet(false, "文件内容为空或表头有误！");
            }
            boolean ret = fileupload.save(lists, columMap, infoId, sb);
            if (!ret) {
                isallok = false;
            }
        }
        if (isallok) {
            return new JsonRet(true, "上传成功！");
        } else {
            return new JsonRet(false, "上传失败，" + sb.toString());
        }


    }


    @RequestMapping(value = "/list")
    @ResponseBody
    public JsonRet list(HttpServletResponse response,
                        @RequestParam(required = false) String name,
                        @RequestParam(required = false) String keyword,
                        @RequestParam(required = false) Integer configid,
                        @RequestParam(required = false) ExportHelper.ExportType expdata, PagedModel mo) throws NSException {
        PageContext pCtx = new PageContext(mo);
        Suspectinfo.Coll coll = new Suspectinfo.Coll();
        Suspectinfo.Query query = coll.getQuery();
        query.setName(name);
        query.setConfigid(configid);
        SuspectinfoBiz biz = new SuspectinfoBiz();
        ConfigBiz configBiz = new ConfigBiz();
        Map<Integer, String> configDict = configBiz.getConfigDict();
        if (expdata != null) {
            query.start = 0;
            query.count = ExportHelper.MaxExcelCount;
        } else {
            query.start = (pCtx.getCurPage() - 1) * pCtx.getCountPerPage();
            query.count = pCtx.getCountPerPage();
        }
        query.orderBy = Suspectinfo.Query.OroupByEnum.createtime__desc;
        biz.loadByKeyword(coll, keyword);
        pCtx.setCollection(coll);
        NUserInfoProvider provider = new NUserInfoProvider();
        List<Object> result = new ArrayList<>();
        if (expdata != null && expdata == ExportHelper.ExportType.Excel) {
            List<String> infoIdList = coll.stream().map(hm -> hm.getId()).distinct().collect(Collectors.toList());
            Suspect.Coll suspectColl = new Suspect.Coll();
            Suspect.Query suspectQ = suspectColl.getQuery();
            suspectQ.setInfoidIDList(infoIdList);
            new SuspectBiz().loadBykeyword(suspectColl, keyword);
            biz.buildExcel(suspectColl, response);
        } else if (!coll.isEmpty()) {
            Map<String, Integer> countMap = new SuspectBiz().fetchCount(new Suspect.Coll(new Suspect.Query()));
            coll.forEach(p -> {
                Map<String, Object> map = new HashMap<>();
                map.put("id", p.getId());
                map.put("configid", p.getConfigid());
                map.put("config", configDict.getOrDefault(p.getConfigid(), ""));
                map.put("name", p.getName());
                map.put("createtime", Misc.toStdString(p.getCreatetime()));
                map.put("updatetime", Misc.toStdString(p.getUpdatetime()));
                try {
                    if (provider.getUserByid(p.getUserid()) != null) {
                        map.put("username", provider.getUserByid(p.getUserid()).FullName);
                    } else {
                        map.put("username", "");
                    }
                } catch (NSException e) {
                    logger.error("find userName failed!: " + e);
                }
                map.put("count", countMap.getOrDefault(p.getId(), 0));
                result.add(map);
            });
        }
        return new JsonRet(result, pCtx);
    }


    @RequestMapping(value = "/update", method = RequestMethod.POST)
    @ResponseBody
    public JsonRet update(@RequestBody SuspectInfoModel model, Errors errors) throws NSException {
        if (errors.hasErrors()) {
            return WebHelper.checkParamErrors(errors);
        }

        SuspectinfoBiz biz = new SuspectinfoBiz();
        if (StringUtils.hasText(model.getId())) {
            Suspectinfo.Entity exist = biz.get(model.getId());
            if (exist == null) {
                return new JsonRet(false, "更新失败!");
            }
//            if (!model.getName().equalsIgnoreCase(exist.getName())) {
//                if (!suspectInfoIfNotRepeat(model.getName())) {
//                    return new JsonRet(false, "名单有重复！");
//                }
//            }
            exist.setName(model.getName());
            exist.setConfigid(model.getConfigid());
            exist.setUpdatetime(LocalDateTime.now());
            exist.setUserid(NsocUser.getCurrentUser().getUserId());

            if (biz.update(exist))
                return new JsonRet(true, "更新成功！");
            else {
                return new JsonRet(false, "更新失败！");
            }
        } else
            return new JsonRet(false, "更新失败！");
    }

    @RequestMapping(value = "/erase", method = RequestMethod.POST)
    @ResponseBody
    public JsonRet erase(@RequestBody(required = false) EraseModel m) throws NSException {
        if (m != null) {
            boolean rm = deleteById(m.getId());
            return new JsonRet(rm);
        } else {
            return new JsonRet(false, "删除失败！");
        }
    }


    @RequestMapping(value = "/exportexcel", method = RequestMethod.GET)
    @ResponseBody
    public void export(@RequestParam(required = false) String ids, HttpServletResponse response) throws NSException {
        SuspectinfoBiz biz = new SuspectinfoBiz();
        Suspect.Coll coll = new Suspect.Coll();
        Suspect.Query query = coll.getQuery();
        query.setInfoidIDList(Misc.strToStrList(ids));
        new SuspectBiz().loadBykeyword(coll, null);
        biz.buildExcel(coll, response);
    }

    private boolean deleteById(String id) throws NSException {
        if (StringUtils.hasText(id)) {
            SuspectinfoBiz biz = new SuspectinfoBiz();
            SuspectBiz suspectBiz = new SuspectBiz();
            Suspectinfo.Entity exist = new Suspectinfo.Entity();
            exist.setId(id);
            if (biz.delete(exist)) {
                return suspectBiz.deleteByInfoid(id);
            } else {
                return false;
            }
        } else {
            return false;
        }

    }

    @RequestMapping(value = "/batchcmd", method = RequestMethod.POST)
    @ResponseBody
    public JsonRet suspectInfoBatchcmd(@RequestBody BatchUpdateModel m) throws NSException {

        boolean isAllOK = true;
        List<String> lstErrors = new ArrayList<>();
        if (m.getCmd() != null) {
            List<String> strings = Misc.strToStrList(m.getItem());
            if (!strings.isEmpty()) {
                for (String id : strings) {
                    switch (m.getCmd()) {
                        // 勾选删除操作
                        case delete: {
                            boolean rm = deleteById(id);
                            if (!rm) {
                                // 未全部执行成功
                                isAllOK = false;
                                lstErrors.add(id);
                            }
                        }
                        break;
                        default:
                            break;
                    }
                }

            }
        }
        if (isAllOK) {
            return new JsonRet(true);
        } else {
            return new JsonRet(false, String.format("%s 删除失败！", lstErrors.toString()));
        }
    }


    private ReturnModel suspectInfoIfNotRepeat(String name) throws NSException {
        Suspectinfo.Coll coll = new Suspectinfo.Coll();
        ReturnModel model = new ReturnModel();
        new SuspectinfoBiz().load(coll);
        List<Suspectinfo.Entity> sameIdList = coll.stream().filter(l -> l.getName().equalsIgnoreCase(name)).collect(Collectors.toList());
        if (sameIdList.isEmpty()) {
            return null;
        } else {
            int configid = sameIdList.get(0).getConfigid();
            String infoId = sameIdList.get(0).getId();
            model.configId = configid;
            model.infoId = infoId;
            return model;
        }
    }

    static class ReturnModel {
        Integer configId;
        String infoId;
    }


}
