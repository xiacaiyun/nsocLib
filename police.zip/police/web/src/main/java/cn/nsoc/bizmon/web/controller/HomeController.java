package cn.nsoc.bizmon.web.controller;

import cn.nsoc.common.applib.error.ErrorType;
import cn.nsoc.common.applib.rights.Right;
import cn.nsoc.bizmon.web.config.AppConfig;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Created by sam on 16-5-8.
 */
@Controller
@RequestMapping("/")
@Right
public class HomeController {

    @Autowired
    public AppConfig appConfig;



    @RequestMapping()
    public  ModelAndView index(HttpServletRequest request) throws Exception
    {
        return redirectTo("index",request);
    }

    @RequestMapping("/license")
    @Right(allowAnonymous = true)
    public ModelAndView license(HttpServletRequest request){
        return redirectTo("license",request);
    }

    @RequestMapping("/error")
    @Right(allowAnonymous = true)
    public String error(@RequestParam(required = false) String type, HttpServletRequest request, HttpServletResponse response) throws Exception
    {
        response.sendRedirect(String.format("%s/error?type=%s",
                appConfig.getFrameworkRoot(),type));

        return null;
    }


    private ModelAndView redirectTo(String name,HttpServletRequest request){
        ModelAndView mv = new ModelAndView(name);
        mv.addObject("fwroot", appConfig.getFrameworkRoot());
        mv.addObject("root", request.getContextPath());

        return mv;
    }

}
