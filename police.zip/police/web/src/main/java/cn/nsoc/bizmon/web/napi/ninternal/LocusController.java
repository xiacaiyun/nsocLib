package cn.nsoc.bizmon.web.napi.ninternal;

import cn.nsoc.base.entity.sys.NSException;
import cn.nsoc.bizmon.biz.mysql.DeviceBiz;
import cn.nsoc.bizmon.biz.mysql.DevstatBiz;
import cn.nsoc.bizmon.biz.mysql.PlaceBiz;
import cn.nsoc.bizmon.entity.defines.Constants;
import cn.nsoc.bizmon.entity.defines.PlaceStatus;
import cn.nsoc.bizmon.entity.mysql.Device;
import cn.nsoc.bizmon.entity.mysql.Devstat;
import cn.nsoc.bizmon.entity.mysql.Place;
import cn.nsoc.bizmon.web.model.PlaceSearchModel;
import cn.nsoc.common.applib.controls.JsonRet;
import cn.nsoc.common.applib.controls.PageContext;
import cn.nsoc.common.applib.rights.Right;
import cn.nsoc.common.util.Misc;
import org.springframework.stereotype.Controller;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

@Controller
@RequestMapping(value = "/napi/internal/placeex")
@Right(allowAnonymous = true)
public class LocusController {

    @RequestMapping(value = "/list")
    @ResponseBody
    public JsonRet list(PlaceSearchModel model) throws NSException {
        Place.Coll coll = new Place.Coll();
        Place.Query query = coll.getQuery();
        Misc.objectCopy(model, query);
        if (query.getServicetype() != null && Constants.ALL_SERVICES.equalsIgnoreCase(query.getServicetype())) {
            query.setServicetype(null);
        }
        PlaceBiz biz = new PlaceBiz();
        coll.setQuery(query);
        Place.Coll placeSummary = new Place.Coll();
        placeSummary.setQuery(query);
        biz.loadForFront(coll, model.getKeyword());
        if (coll.isEmpty()) {
            return new JsonRet(new Object[0]);
        }
        biz.loadPlaceSummaryForFront(placeSummary, model.getKeyword());
        DeviceBiz deviceBiz = new DeviceBiz();
        int devTotal;
        int devOnlineTotal;
        Map<String, Integer> total = new HashMap<>();
        Map<String, Integer> devStatMap = new HashMap<>();
        List<String> scCodeList = coll.stream().map(h -> h.getServicecode()).distinct().collect(Collectors.toList());
        Device.Coll dcoll = new Device.Coll();
        Device.Query deviceQuery = dcoll.getQuery();
        deviceQuery.setServicecodeIDList(scCodeList);
        deviceBiz.loadDevCount(dcoll);
        Device.Coll deviceColl = deviceBiz.loadByServiceCodes(scCodeList);
        Devstat.Coll dscoll = new Devstat.Coll();
        if (deviceColl.isEmpty()) {
            devTotal = 0;
            devOnlineTotal = 0;
        } else {
            List<String> nos = deviceColl.stream().map(p -> p.getNo()).distinct().collect(Collectors.toList());
            total = dcoll.stream().collect(Collectors.toMap(Device.Entity::getServicecode, Device.Entity::getDevcount));
            devTotal = dcoll.stream().collect(Collectors.summingInt(Device.Entity::getDevcount));
            DevstatBiz dsbiz = new DevstatBiz();
            dscoll = dsbiz.loadDevOnlineCount(nos,scCodeList);
            if (dscoll.isEmpty()) {
                devOnlineTotal = 0;
            } else {
                devOnlineTotal = dscoll.stream().collect(Collectors.summingInt(Devstat.Entity::getDevcount));
                devStatMap = dscoll.stream().collect(Collectors.toMap(Devstat.Entity::getServicecode, Devstat.Entity::getDevcount));
            }
        }
        Devstat.Coll statColl = new DevstatBiz().loadDevOnlineCount(null,scCodeList);
        List<Object> result = new ArrayList<>();
        int intactPlace = 0;
        int partialPlace = 0;
        int damagedPlace = 0;

        for (Place.Entity s : coll) {
            int placeStatus = biz.getPlaceStatus(s.getServicecode(), dcoll, statColl);
            if (placeStatus == PlaceStatus.INTACT.getVal()) {
                intactPlace++;
            }
            if (placeStatus == (PlaceStatus.PARTIAL.getVal())) {
                partialPlace++;
            }
            if (placeStatus == (PlaceStatus.DAMAGED.getVal())) {
                damagedPlace++;
            }
            Map<String, Object> map = new HashMap<>();
            map.put("place_name", s.getServicename());
            map.put("place_code", s.getServicecode());
            map.put("place_type", s.getServicetype());
            map.put("addr", s.getAddress());
            map.put("place_status", placeStatus);
            map.put("dev_total", total.getOrDefault(s.getServicecode(), 0));
            map.put("dev_online", devStatMap.getOrDefault(s.getServicecode(), 0));
            map.put("service_code", s.getServicecode());
            map.put("lng", s.getLng());
            map.put("lat", s.getLat());
            map.put("police_code", s.getPolicecode());
            map.put("police_name", s.getPolicename());
            result.add(map);
        }
        Map<String, Object> resultMap = new HashMap<>();
        resultMap.put("place_total", placeSummary.stream().mapToLong(e -> e.placecount).sum());
        resultMap.put("place_summary", placeSummary);
        resultMap.put("intact_place", intactPlace);
        resultMap.put("partial_place", partialPlace);
        resultMap.put("damaged_place", damagedPlace);
        resultMap.put("dev_total", devTotal);
        resultMap.put("dev_onlinetotal", devOnlineTotal);
        resultMap.put("place_item", result);
        return new JsonRet(true, "ok", resultMap);
    }


    @RequestMapping(value = "/minlist")
    @ResponseBody
    public JsonRet minlist(PlaceSearchModel model) throws NSException {
        PageContext pCtx = new PageContext(model);
        Place.Coll coll = new Place.Coll();
        Place.Query query = coll.getQuery();
        Misc.objectCopy(model, query);
        if (query.getServicetype() != null && Constants.ALL_SERVICES.equalsIgnoreCase(query.getServicetype())) {
            query.setServicetype(null);
        }
        query.start = (pCtx.getCurPage() - 1) * pCtx.getCountPerPage();
        query.count = pCtx.getCountPerPage();
        PlaceBiz biz = new PlaceBiz();
        biz.loadForFront(coll, model.getKeyword());
        pCtx.setCollection(coll);
        List<Object> result = new ArrayList<>();
        if (!coll.isEmpty()) {
            for (Place.Entity s : coll) {
                Map<String, Object> map = new HashMap<>();
                map.put("place_name", s.getServicename());
                map.put("place_code", s.getServicecode());
                map.put("addr", s.getAddress());
                map.put("lng", s.getLng());
                map.put("lat", s.getLat());
                result.add(map);
            }
        }
        return new JsonRet(result, pCtx);
    }

    @RequestMapping("/police_dict")
    @ResponseBody
    public JsonRet getAllPolices() throws NSException {
        Place.Coll coll = new Place.Coll();
        new PlaceBiz().loadpolicedict(coll);
        return new JsonRet(coll);
    }


    @RequestMapping("/places")
    @ResponseBody
    public JsonRet fetchPlaces() throws NSException {
        Place.Coll coll = new Place.Coll();
        new PlaceBiz().load(coll);
        if(coll.isEmpty()){
            return new JsonRet(new Object[0]);
        }
        List<Map<String, Object>> result = coll.stream().map(p -> {
            Map<String, Object> map = new HashMap<>();
            map.put("servicecode", p.getServicecode());
            map.put("type", p.getType());
            return map;
        }).collect(Collectors.toList());
        return new JsonRet(result);
    }

    @RequestMapping("/orgname")
    @ResponseBody
    public JsonRet getOrgNames() throws NSException {
        Place.Coll coll = new Place.Coll();
        new PlaceBiz().load(coll);
        List<String> names = coll.stream().filter(l-> StringUtils.hasText(l.getOrgname())).map(l -> l.getOrgname()).distinct().collect(Collectors.toList());
        return new JsonRet(names);
    }
    
	static void addPlaceInfo(List<Map<String, Object>> result) {
		// add place info
		List<String> scs = result.stream().map(a -> (String) a.get("servicecode")).distinct()
				.collect(Collectors.toList());
		Map<String, Place.Entity> addrMap = new PlaceBiz().loadByCodes(scs);
		result.forEach(l -> {
			Place.Entity m = addrMap.get(l.get("servicecode"));
			if (m != null) {
				l.put("servicename", m.getServicename());
				l.put("address", m.getAddress());
				l.put("lng", m.getLng());
				l.put("lat", m.getLat());
			}
		});
	}


}
