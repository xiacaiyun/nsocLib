package cn.nsoc.bizmon.web.napi.npublic;


import cn.nsoc.base.entity.sys.NSException;
import cn.nsoc.bizmon.biz.AppAuth;
import cn.nsoc.common.applib.controls.JsonRet;
import cn.nsoc.common.applib.controls.WebHelper;
import cn.nsoc.common.applib.entity.config.AppRuntimeConfig;
import cn.nsoc.common.applib.framework.exchange.ExchangeUrl;
import cn.nsoc.common.applib.framework.exchange.UpdateAppInfoRequest;
import cn.nsoc.common.applib.framework.exchange.UpdateAppInfoResult;
import cn.nsoc.common.applib.rights.Right;
import cn.nsoc.common.util.Misc;
import cn.nsoc.common.util.NApiProxy;
import cn.nsoc.license.client.AppLicense;
import cn.nsoc.license.client.License;
import org.apache.log4j.Logger;
import org.hibernate.validator.constraints.NotBlank;
import org.springframework.stereotype.Controller;
import org.springframework.util.StringUtils;
import org.springframework.validation.Errors;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.commons.CommonsMultipartFile;

import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

@Controller
@RequestMapping(value = "/napi/public/setting")
@Right(allowAnonymous = true)
public class SettingController {
    private static final Logger logger = Logger.getLogger(SettingController.class);
    static class SetFrameworkModel
    {
        @NotBlank(message = "用户名不能为空！")
        private String               Username;
        @NotBlank(message = "密码不能为空！")
        private String               Password;
        @NotBlank(message = "应用首页不能为空！")
        private String               AppUrl;
        private boolean              UpdateLicense;
        private boolean              SynKey;
        private boolean              ChangeKey;

        private CommonsMultipartFile LicenseFile;

        public String getUsername() {
            return Username;
        }

        public void setUsername(String username) {
            Username = username;
        }

        public String getPassword() {
            return Password;
        }

        public void setPassword(String password) {
            Password = password;
        }

        public String getAppUrl() {
            return AppUrl;
        }

        public void setAppUrl(String appUrl) {
            AppUrl = appUrl;
        }

        public boolean isUpdateLicense() {
            return UpdateLicense;
        }

        public void setUpdateLicense(boolean updateLicense) {
            UpdateLicense = updateLicense;
        }

        public boolean isSynKey() {
            return SynKey;
        }

        public void setSynKey(boolean synKey) {
            SynKey = synKey;
        }

        public boolean isChangeKey() {
            return ChangeKey;
        }

        public void setChangeKey(boolean changeKey) {
            ChangeKey = changeKey;
        }

        public CommonsMultipartFile getLicenseFile() {
            return LicenseFile;
        }

        public void setLicenseFile(CommonsMultipartFile licenseFile) {
            LicenseFile = licenseFile;
        }
    }

    static class  FrameworkResp{
        public String AppUrl;
        public String LicenseStatus;
        public String Status;

        public FrameworkResp(String appUrl){
            AppUrl = appUrl;
        }
    }

    @RequestMapping(value ="/setFramework", method = RequestMethod.POST)
    @ResponseBody
    public JsonRet setFramework(@Valid SetFrameworkModel m, HttpServletRequest request, Errors errors) throws Exception{

        if (errors.hasErrors()) {
            return WebHelper.checkParamErrors(errors);
        }

        if (m.UpdateLicense && ((m.LicenseFile == null) || m.LicenseFile.isEmpty())) {
            return new JsonRet(false, "许可证文件不能为空！");
        }


        License lic = null;
        List<String> msgList = new ArrayList<>();


        AppRuntimeConfig config = AppRuntimeConfig.Current();
        UpdateAppInfoRequest req = new UpdateAppInfoRequest();

        req.setAppUrl(m.AppUrl);
        req.setUsername(m.Username);
        req.setPassword(m.Password);
        req.setUpdateLicense(m.UpdateLicense);
        req.setSynKey(m.SynKey);
        req.setChangeKey(m.ChangeKey);
        req.setAppID(AppAuth.AppID);
        req.setAppName(AppAuth.SZPRODUCTNAME);
        req.setAppShortName(AppAuth.SZPRODUCTSHORTNAME);

        String newLicXml = null;
        if (m.UpdateLicense)  {
            try {
                newLicXml = Misc.readStream(m.LicenseFile.getInputStream(),"UTF-8");
                lic = AppLicense.parseLicense(newLicXml);
                if (!lic.isValidApp(AppAuth.AppID)) {
                    lic = null;
                }
            }
            catch(Exception ignored) {
                lic = null;
                logger.info(ignored.getLocalizedMessage());
            }
            if (lic == null) {
                return new JsonRet(false, "无效的许可证文件！");
            }

            req.setLic(Misc.toJson(lic));
            msgList.add("更新许可证信息。");

            req.setUpdateLicense(true);
            if (!StringUtils.hasText(config.getRSAKey())) {
                req.setChangeKey(true);
            }
        }

        req.setAppUrl(StringUtils.trimTrailingCharacter(req.getAppUrl(),'/') + "/");

        String html = NApiProxy.getInstance().post(ExchangeUrl.UPDATE_APP_INFO, Misc.toJson(req));
        UpdateAppInfoResult result = Misc.fromJson(html,UpdateAppInfoResult.class);

        if (result == null) {
            return new JsonRet(false, "操作失败！");
        }

        if (result.isRet()) {
            config.setAppUrl(req.getAppUrl());

            msgList.add(String.format("更新应用首页为：%s", req.getAppUrl()));

            if (req.isChangeKey() || req.isSynKey())                {
                config.setRSAKey(result.getRSAKey());
                msgList.add("更新APPKEY。");
            }

            config.Save();
            if (req.isUpdateLicense() &&  StringUtils.hasText(newLicXml)) {

                AppLicense.saveLicenseFile(request.getServletContext().getRealPath("/"),newLicXml);
                AppLicense.getInstance().resetLicense();
            }
        }

        return new JsonRet(result.isRet(), result.getMessage());

    }
    @RequestMapping(value ="/getFramework")
    @ResponseBody
    public JsonRet getFramework(HttpServletRequest request) throws NSException
    {
        try {
            AppRuntimeConfig config = AppRuntimeConfig.Current();
            SetFrameworkModel m = new SetFrameworkModel();
            m.AppUrl = config.getAppUrl();

            if (!StringUtils.hasText(m.AppUrl)) {
                m.AppUrl = request.getContextPath();
            }

            FrameworkResp o = new FrameworkResp(m.AppUrl);
            License lic = AppLicense.getInstance().getLicense();
            if (lic == null) {
                o.Status = "notInstalled";
                o.LicenseStatus = "未安装";
            } else if (lic.isExpired(LocalDateTime.now())) {
                o.Status = "expired";
                o.LicenseStatus = "已过期";
            } else {
                o.Status = "installed";
                o.LicenseStatus = "已安装";
            }

            return new JsonRet(o);
        }
        catch (Exception ex){
            throw new NSException(ex);
        }
    }
}
