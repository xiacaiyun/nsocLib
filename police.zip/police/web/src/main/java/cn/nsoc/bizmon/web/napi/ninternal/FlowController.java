package cn.nsoc.bizmon.web.napi.ninternal;

import static cn.nsoc.bizmon.entity.defines.Constants.SECONDS_OF_ONE_DAY;
import java.util.ArrayList;
import java.util.EnumMap;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;
import org.apache.commons.lang3.StringUtils;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import cn.nsoc.base.entity.sys.NSException;
import cn.nsoc.bizmon.biz.dw.DataWareMgr;
import cn.nsoc.bizmon.biz.mysql.HotstatBiz;
import cn.nsoc.bizmon.biz.mysql.PlaceBiz;
import cn.nsoc.bizmon.entity.mysql.Hotstat;
import cn.nsoc.bizmon.entity.mysql.Place;
import cn.nsoc.bizmon.util.Hptimer;
import cn.nsoc.bizmon.web.model.FlowModel;
import cn.nsoc.common.applib.controls.JsonRet;
import cn.nsoc.common.applib.rights.Right;

@Controller
@RequestMapping(value = "/napi/internal/flow")
@Right(allowAnonymous = true)
public class FlowController {
    private static final Logger logger = Logger.getLogger(FlowController.class);
    private static final String GAP_TIME = "gaptime";
    @Autowired
    private DataWareMgr dwMgr;
    @Value("${expired.warn.days}")
    private int days;
    private static EnumMap<FlowModel.FlowType, String> TYPES =
            new EnumMap<>(FlowModel.FlowType.class);
    static {
        TYPES.put(FlowModel.FlowType.WB, "网吧");
        TYPES.put(FlowModel.FlowType.WIFI, "无线wifi");
        TYPES.put(FlowModel.FlowType.BG, "宾馆");
        TYPES.put(FlowModel.FlowType.ZD, "终端采集");

    }

    @RequestMapping(value = "/search")
    @ResponseBody
    public JsonRet search(@RequestBody FlowModel model) {

        Map<String, Object> result;
        try {
            if((Hptimer.nowSeconds() - model.getStart()) / SECONDS_OF_ONE_DAY >= days) {
                result = searchHistory(model);
            } else {
                result = searchInternal(model);
            }
            
            return new JsonRet(result);
        } catch (NSException e) {
            logger.error("warning db error", e);
            return new JsonRet(false, "warning service error");
        }

    }

    private Map<String, Object> searchInternal(FlowModel model) throws NSException {
        Map<String, Object> result = new HashMap<>();
        HotstatBiz biz = new HotstatBiz();
        Hotstat.Coll coll = biz.getTotal(model.getStart(), model.getEnd(), model.getScs(),
                model.getPolices(), TYPES.get(model.getType()));
        List<Map<String, Object>> totals = new ArrayList<>();
        coll.forEach(l -> {
            Map<String, Object> element = new HashMap<>();
            element.put(GAP_TIME, Hptimer.format(l.getGaptime()));
            element.put("value", l.getTotal());
            totals.add(element);
        });
        result.put("total", totals);
        coll = biz.getRealtime(model.getEnd() - model.getDuration(), model.getEnd(), model.getScs(),
                model.getPolices(), TYPES.get(model.getType()));
        List<Map<String, Object>> realtimes = new ArrayList<>();
        coll.forEach(l -> {
            Map<String, Object> element = new HashMap<>();
            element.put("servicecode", l.getServicecode());
            element.put(GAP_TIME, Hptimer.format(l.getGaptime()));
            element.put("value", l.getTotal());
            realtimes.add(element);
        });
        LocusController.addPlaceInfo(realtimes);
        result.put("realtime", realtimes);
        return result;
    }

    private Map<String, Object> searchHistory(FlowModel model) throws NSException {
        Map<String, Object> result = new HashMap<>();
        PlaceBiz biz = new PlaceBiz();
        Place.Coll coll = new Place.Coll();
        if (model.getScs() != null && model.getScs().isEmpty()) {
            coll.getQuery().setServicecodeIDList(model.getScs());
        } else if (model.getPolices() != null && model.getPolices().isEmpty()) {
            coll.getQuery().setPolicecodeIDList(model.getPolices());
        }
        coll = biz.loadPartial(coll);
        String type = TYPES.get(model.getType());
        List<Place.Entity> places = new ArrayList<>();
        coll.forEach(l -> {
            if (StringUtils.isBlank(type) || type.equals(l.getServicetype())) {
                places.add(l);
            }
        });
        long start = model.getStart();
        if (start % 300 != 0) {
            start = start / 300 * 300 + 300;
        }
        long end =  model.getEnd() / 300 * 300;

        List<Map<String, Object>> totals = new ArrayList<>();
        for(;start < end; start+=300) {
            final long time = start;
            Map<String, Object> element = new HashMap<>();
            
            element.put(GAP_TIME, Hptimer.format(start));
            element.put("value", places.parallelStream().map(l-> dwMgr.findHotstat(l.getServicecode(), time)).reduce(0L, (a, b)-> a+b));
            totals.add(element);
        }
        result.put("total", totals);
        List<Map<String, Object>> realtimes = new ArrayList<>();
        places.parallelStream().forEach(l -> {
            Map<String, Object> element = new HashMap<>();
            element.put("servicecode", l.getServicecode());
            element.put(GAP_TIME, Hptimer.format(end));
            element.put("value", dwMgr.findHotstat(l.getServicecode(), end));
            realtimes.add(element);
        });
        Map<String, Object> element = new HashMap<>();
        element.put(GAP_TIME, Hptimer.format(end));
        element.put("value", realtimes.parallelStream().map(l-> (long)l.get("value")).reduce(0L, (a,b)-> a+b));
        totals.add(element);
        LocusController.addPlaceInfo(realtimes);
        result.put("realtime", realtimes);
        return result;
    }
}
