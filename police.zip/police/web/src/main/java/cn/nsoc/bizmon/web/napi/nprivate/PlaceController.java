package cn.nsoc.bizmon.web.napi.nprivate;

import cn.nsoc.base.entity.sys.NSException;
import cn.nsoc.bizmon.biz.excel.FileUpload;
import cn.nsoc.bizmon.biz.mysql.DeviceBiz;
import cn.nsoc.bizmon.biz.mysql.DevstatBiz;
import cn.nsoc.bizmon.biz.mysql.PlaceBiz;
import cn.nsoc.bizmon.entity.defines.Constants;
import cn.nsoc.bizmon.entity.defines.PlaceStatus;
import cn.nsoc.bizmon.entity.mysql.Device;
import cn.nsoc.bizmon.entity.mysql.Devstat;
import cn.nsoc.bizmon.entity.mysql.Place;
import cn.nsoc.bizmon.web.model.EraseModel;
import cn.nsoc.bizmon.web.model.PlaceModel;
import cn.nsoc.bizmon.web.model.PlaceSearchModel;
import cn.nsoc.common.applib.controller.NController;
import cn.nsoc.common.applib.controls.JsonRet;
import cn.nsoc.common.applib.controls.PageContext;
import cn.nsoc.common.applib.controls.WebHelper;
import cn.nsoc.common.applib.rights.Right;
import cn.nsoc.common.util.ExportHelper;
import cn.nsoc.common.util.Misc;
import org.apache.commons.collections.map.HashedMap;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.util.StringUtils;
import org.springframework.validation.Errors;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.commons.CommonsMultipartFile;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

/**
 * Created by Administrator on 2017/7/11.
 */
@Controller
@RequestMapping(value = "/napi/private/place")
@Right(allowAnonymous = true)
public class PlaceController {
    @Autowired
    private FileUpload fileupload;


    @RequestMapping(value = "/list")
    @ResponseBody
    public JsonRet list(PlaceSearchModel model, @RequestParam(required = false) ExportHelper.ExportType expdata, HttpServletResponse response) throws NSException {
        PageContext pCtx = new PageContext(model);
        Place.Coll coll = new Place.Coll();
        Place.Query query = coll.getQuery();
        Misc.objectCopy(model, query);
        if (Constants.ALL_SERVICES.equalsIgnoreCase(query.getServicetype())) {
            query.setServicetype(null);
        }
        PlaceBiz biz = new PlaceBiz();
        if (expdata != null) {
            query.start = 0;
            query.count = ExportHelper.MaxExcelCount;
        } else {
            query.start = (pCtx.getCurPage() - 1) * pCtx.getCountPerPage();
            query.count = pCtx.getCountPerPage();
        }
        query.setDeleted(0);
        biz.loadByKeyword(coll, model.getKeyword());
        pCtx.setCollection(coll);
        if (coll.isEmpty()) {
            return new JsonRet(new Object[0], pCtx);
        }
        List<String> scCodeList = coll.stream().map(h -> h.getServicecode()).distinct().collect(Collectors.toList());
        Device.Coll dcoll = new Device.Coll();
        Device.Query deviceQuery = dcoll.getQuery();
        deviceQuery.setServicecodeIDList(scCodeList);
        new DeviceBiz().loadDevCount(dcoll);

        Devstat.Coll devcoll = new Devstat.Coll();
        if (!dcoll.isEmpty()) {
            List<String> nos = dcoll.stream().map(p -> p.getNo()).distinct().collect(Collectors.toList());
            devcoll= new DevstatBiz().loadDevOnlineCount(nos,scCodeList);
        }
        Devstat.Coll statColl = new DevstatBiz().loadDevOnlineCount(null,scCodeList);
        List<Object> result = new ArrayList<>();
        if (expdata != null) {
            buildExcel(coll, dcoll, statColl, response);
        } else {
            for (Place.Entity s : coll) {
                Map<String, Object> map = new HashMap<>();
                map.put("servicename", s.getServicename());
                map.put("servicetype", s.getServicetype());
                map.put("placestatus", model.getPlacestatus() != null ? model.getPlacestatus() : biz.getPlaceStatus(s.getServicecode(), dcoll, statColl));
                map.put("servicecode", s.getServicecode());
                map.put("policename", s.getPolicename());
                map.put("policecode", s.getPolicecode());
                map.put("lng", s.getLng());
                map.put("lat", s.getLat());
                map.put("orgname", s.getOrgname());
                map.put("contact", s.getName() + " " + s.getContact());
                map.put("submittime", Misc.toStdString(s.getUpdatetime()));
                result.add(map);
            }
        }
        return new JsonRet(result, pCtx);
    }

    @RequestMapping(value = "/summary/list", method = RequestMethod.GET)
    @ResponseBody
    public JsonRet summary() throws NSException {
        Place.Coll coll = new Place.Coll();
        PlaceBiz biz = new PlaceBiz();
        biz.loadPlaceSummary(coll, null);
        List<Map<String, Object>> result = new ArrayList<>();
        long sum = 0;
        if (!coll.isEmpty()) {
            sum = coll.stream().mapToLong(e -> e.placecount).sum();
            Map<String, Object> totalmap = new HashMap<>();
            totalmap.put("servicetype", Constants.ALL_SERVICES);
            totalmap.put("count", sum);
            result.add(totalmap);
            coll.forEach(h -> {
                Map<String, Object> map = new HashMap<>();
                map.put("servicetype", h.getServicetype());
                map.put("count", h.placecount);
                result.add(map);
            });
        }
        return new JsonRet(result);
    }

    @RequestMapping(value = "/get", method = RequestMethod.GET)
    @ResponseBody
    public JsonRet get(@RequestParam(required = false) String id) throws NSException {

        Place.Entity o = null;
        PlaceModel model = new PlaceModel();
        PlaceBiz biz = new PlaceBiz();
        if (StringUtils.hasText(id)) {
            o = biz.get(id);
            Misc.objectCopy(o, model);
        } else {
            model.setServicetype("网吧");
            model.setPlacestatus(PlaceStatus.INTACT.getVal());
        }
        return new JsonRet(model);
    }

    @RequestMapping(value = "/update", method = RequestMethod.POST)
    @ResponseBody
    public JsonRet update(@RequestBody PlaceModel model, Errors errors) throws NSException {
        if (errors.hasErrors()) {
            return WebHelper.checkParamErrors(errors);
        }
        Map<String, String> policeDictFromDb = new PlaceBiz().getDictFromPlace("police");
        PlaceBiz biz = new PlaceBiz();
        Place.Entity exist = null;
        Place.Entity o = new Place.Entity();
        if (!StringUtils.hasText(model.getServicecode())) { //if主键servicecode为空
            return new JsonRet(false, "场所code不能为空！");
        } else {
            exist = biz.get(model.getServicecode());
            if (exist != null) {
                Misc.objectCopy(exist, o); //exist赋给o
            }
        }
        Misc.objectCopy(model, o); //model赋给o(model为页面传来的新值包括主键servicecode值)
        if (exist == null) {
            if (!serviceNameIfNotExist((model.getServicename()))) {
                return new JsonRet(false, "场所名称已存在!");
            }
            o.setCreatetime(LocalDateTime.now());
            o.setUpdatetime(LocalDateTime.now());
            o.setPolicename(policeDictFromDb.getOrDefault(o.getPolicecode(), ""));
            biz.insert(o);
        } else {
            if (model.getServicename().compareToIgnoreCase(exist.getServicename()) != 0) {
                if (!serviceNameIfNotExist((model.getServicename()))) {
                    return new JsonRet(false, "场所名称已存在!");
                }
            }
            o.setUpdatetime(LocalDateTime.now());
            biz.update(o);
        }
        return new JsonRet(true);
    }

    @RequestMapping(value = "/erase", method = RequestMethod.POST)
    @ResponseBody
    public JsonRet erase(@RequestBody(required = false) EraseModel m) throws NSException {
        boolean rm = deleteById(m.getId());
        return new JsonRet(rm);
    }

    @RequestMapping(value = "/exportexcel", method = RequestMethod.GET)
    @ResponseBody
    public void export(@RequestParam(required = false) String ids, HttpServletResponse response) throws NSException {
        Place.Coll coll = new Place.Coll();
        Place.Query query = coll.getQuery();
        List<String> scCodeList = Misc.strToStrList(ids);
        query.setServicecodeIDList(scCodeList);
        Device.Coll dcoll = new Device.Coll();
        Device.Query deviceQuery = dcoll.getQuery();
        deviceQuery.setServicecodeIDList(scCodeList);
        new DeviceBiz().loadDevCount(dcoll);
        List<String> nos = dcoll.stream().map(h -> h.getNo()).distinct().collect(Collectors.toList());

        Devstat.Coll devcoll = new DevstatBiz().loadDevOnlineCount(nos, scCodeList);
        new PlaceBiz().loadByKeyword(coll, null);
        buildExcel(coll, dcoll, devcoll, response);
    }


    @RequestMapping("placedict/list")
    @ResponseBody
    public JsonRet getAllPlaces() throws NSException {
        Map<String, String> serviceDictFromDb = new PlaceBiz().getDictFromPlace("service");
        serviceDictFromDb.put(Constants.SERVICE_CODE, Constants.SERVICE_NAME);
        return new JsonRet(serviceDictFromDb);
    }


    @RequestMapping(value = "/uploadexcel", method = RequestMethod.POST)
    @ResponseBody
    public JsonRet uploadExcel(@RequestParam(value = "files", required = false) CommonsMultipartFile[] files,
                               HttpServletRequest request) throws NSException, IOException {
        boolean isallok = true;
        if (files == null) {
            return new JsonRet(false, "上传文件为空！");
        }
        for (CommonsMultipartFile file : files) {
            if (!Misc.isPattern(file.getOriginalFilename(), Constants.UPLOAD_ALLOW_EXTS)) {
                return new JsonRet(false, "上传文件格式错误！");
            }
            Map<String, Integer> columMap = new HashedMap();
            List<List<String>> lists = fileupload.readXls(file, columMap, 2);
            boolean ret = fileupload.batchUpdatePlace(lists, columMap);
            if (!ret) {
                isallok = false;
            }
        }
        if (isallok) {
            return new JsonRet(true, "上传成功！");
        } else {
            return new JsonRet(false, "上传失败！");
        }
    }

    private boolean deleteById(String id) throws NSException {
        PlaceBiz biz = new PlaceBiz();
        Place.Entity exist = new Place.Entity();
        exist.setServicecode(id);
        return biz.fakeDelete(exist);
    }


    private void buildExcel(Place.Coll expData, Device.Coll dcoll, Devstat.Coll devcoll, HttpServletResponse response) throws NSException {
        StringBuilder sb = new StringBuilder();
        // 添加表头
        PlaceBiz biz = new PlaceBiz();
        sb.append("<table border=1><tr> " +
                "<th>场所名称</th> " +
                "<th>场所类型</th> " +
                "<th>场所状态</th> " +
                "<th>场所代码</th> " +
                "<th>属地网安部门</th> " +
                "<th>单位负责人</th> " +
                "<th>提交时间</th></tr>");

        // 添加内容
        for (Place.Entity a : expData) {
            String data = "";
            int status = biz.getPlaceStatus(a.getServicecode(), dcoll, devcoll);
            data = String.format("<tr> " +
                            ExportHelper.CELL_COLUMN +
                            ExportHelper.CELL_COLUMN +
                            ExportHelper.CELL_COLUMN +
                            ExportHelper.CELL_COLUMN +
                            ExportHelper.CELL_COLUMN +
                            ExportHelper.CELL_COLUMN +
                            ExportHelper.CELL_COLUMN + "</tr>",
                    a.getServicename(),
                    a.getServicetype(),
                    PlaceStatus.getByVal(status, null) == null?"":PlaceStatus.getByVal(status,null).getDes(),
                    a.getServicecode(),
                    a.getPolicename(),
                    a.getName() + " " + a.getContact(),
                    Misc.toStdString(a.getUpdatetime()));
            sb.append(data);
        }
        sb.append("</table>");
        String excelData = ExportHelper.BuildDownLoadHtml(sb.toString());
        String fileName = "场所列表";
        NController.exportToExcel(response, excelData, fileName);
    }


    private boolean serviceNameIfNotExist(String name) throws NSException {
        Place.Coll collection = new Place.Coll();
        new PlaceBiz().load(collection);
        Place.Coll coll = collection.stream().filter(l -> l.getServicename().compareToIgnoreCase(name) == 0).collect(Collectors.toCollection(Place.Coll::new));
        return coll.isEmpty();
    }


}

