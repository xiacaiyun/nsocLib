package cn.nsoc.bizmon.web.napi.nprivate;

import cn.nsoc.base.entity.sys.NSException;
import cn.nsoc.common.applib.controls.JsonRet;
import cn.nsoc.common.applib.controls.MenuItem;
import cn.nsoc.common.applib.rights.RightsContext;
import cn.nsoc.common.applib.rights.RightsValEnum;
import cn.nsoc.common.auth.NsocUser;
import cn.nsoc.common.provider.UserRightsProvider;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by sam on 17-3-3.
 */

@Controller
@RequestMapping(value = "/napi/private/menu")
public class MenuController {
    @Autowired
    UserRightsProvider userRightsProvier;
    @ResponseBody
    @RequestMapping()
    public JsonRet list() throws NSException {
        RightsContext rightsContext = this.userRightsProvier.getUserRights(NsocUser.getCurrentUser());
        List<MenuItem> list = new ArrayList<>();
        if(rightsContext.checkRight(RightsValEnum.ViewData.getVal())){
            MenuItem temp = new MenuItem("黄浦公安", null);
            temp.addSubMenu(new MenuItem("场所管理", "placeList"));
            temp.addSubMenu(new MenuItem("设备管理", "deviceList"));
            temp.addSubMenu(new MenuItem("布控管理", "monitorList"));
            temp.addSubMenu(new MenuItem("预警管理", "alarmList"));
            temp.addSubMenu(new MenuItem("库管理", "suspectInfoList"));
            temp.addSubMenu(new MenuItem("照片管理", "photoList"));
            temp.addSubMenu(new MenuItem("规则管理", "monitorRuleList"));
            temp.addSubMenu(new MenuItem("需求栏", "noticeList"));
            temp.addSubMenu(new MenuItem("配置", "configList"));
            list.add(temp);
        }

        return new JsonRet(list);
    }
}
