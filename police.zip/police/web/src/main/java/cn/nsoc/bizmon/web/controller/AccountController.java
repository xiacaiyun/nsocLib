package cn.nsoc.bizmon.web.controller;

import cn.nsoc.base.entity.sys.NSException;
import cn.nsoc.common.applib.controls.JsonRet;
import cn.nsoc.common.applib.rights.Right;
import cn.nsoc.common.auth.NsocUser;
import cn.nsoc.license.client.AppLicense;
import cn.nsoc.license.client.License;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import java.util.HashMap;

/*
 * Created by sam on 16-5-24.
*/

@Controller
@RequestMapping(value = "/account")
public class AccountController{

    @RequestMapping("/curuser")
    @ResponseBody
    @Right(allowAnonymous = false)
    public JsonRet curUser() throws NSException {

        NsocUser user = NsocUser.getCurrentUser();

        HashMap<String,String> data = new HashMap<>();
        data.put("user",user.getDisplayName());

        License lic = AppLicense.getInstance().getLicense();
        if (lic != null){
            data.put("companyname",lic.CustomerName);
        }
        return new JsonRet(data);
    }
}
