package cn.nsoc.bizmon.web.model;

import javax.validation.constraints.NotNull;
import java.util.List;

import static cn.nsoc.bizmon.util.Hptimer.toSeconds;


public class FlowModel{
	@NotNull
	String fromtime;
	@NotNull
	String totime;
	int duration = 6*5*60;
	@NotNull
	FlowType type;
	List<String> polices;
	List<String> scs;
	
	public String getFromtime() {
		return fromtime;
	}
	public void setFromtime(String fromtime) {
		this.fromtime = fromtime;
	}
	public String getTotime() {
		return totime;
	}
	public void setTotime(String totime) {
		this.totime = totime;
	}
	public FlowType getType() {
		return type;
	}
	public void setType(FlowType type) {
		this.type = type;
	}
	
	public List<String> getPolices() {
		return polices;
	}
	public void setPolices(List<String> polices) {
		this.polices = polices;
	}
	public List<String> getScs() {
		return scs;
	}
	public void setScs(List<String> scs) {
		this.scs = scs;
	}
	public long getStart() {
		return toSeconds(fromtime);
	}
	
	public long getEnd() {
		return toSeconds(totime);
	}
	
	public int getDuration() {
		return duration;
	}
	public void setDuration(int duration) {
		this.duration = duration;
	}

	public enum FlowType{
		TOTAL,WIFI,WB,BG,ZD
	}
}

