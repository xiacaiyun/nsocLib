package cn.nsoc.bizmon.web.napi.nprivate;


import cn.nsoc.base.entity.sys.NSException;
import cn.nsoc.bizmon.biz.mysql.NoticeBiz;
import cn.nsoc.bizmon.entity.mysql.Notice;
import cn.nsoc.bizmon.web.model.BatchUpdateModel;
import cn.nsoc.bizmon.web.model.EraseModel;
import cn.nsoc.common.applib.controls.JsonRet;
import cn.nsoc.common.applib.controls.WebHelper;
import cn.nsoc.common.applib.rights.Right;
import cn.nsoc.common.applib.rights.RightsContext;
import cn.nsoc.common.applib.rights.RightsValEnum;
import cn.nsoc.common.auth.NsocUser;
import cn.nsoc.common.provider.NUserInfoProvider;
import cn.nsoc.common.provider.UserRightsProvider;
import cn.nsoc.common.storer.biz.PageContext;
import cn.nsoc.common.storer.biz.PagedModel;
import cn.nsoc.common.util.IDWorker;
import cn.nsoc.common.util.IntEncoder;
import cn.nsoc.common.util.Misc;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.util.StringUtils;
import org.springframework.validation.Errors;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.commons.CommonsMultipartFile;

import javax.servlet.http.HttpServletRequest;
import java.io.File;
import java.io.IOException;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;


@Controller
@RequestMapping(value = "/napi/private/notice")
@Right(allowAnonymous = true)
public class NoticeController extends AttachedHelper{

    static class SetNoticeModel {
        private String id;
        private String createtime;
        private String detail;
        private String src;
        private String username;
        private int userid;
        private CommonsMultipartFile image;


        public SetNoticeModel toNoticeModel(Notice.Entity g, NUserInfoProvider provider) throws NSException {
            this.setUserid(g.getUserid());
            this.setCreatetime(Misc.toStdString(g.getCreatetime()));
            this.setUsername(provider.getUserByid(getUserid()) == null?"":provider.getUserByid(getUserid()).FullName);
            this.setDetail(g.getDetail());
            this.setSrc(g.getSrc());
            this.setId(g.getId());
            return this;
        }

        public String getId() {
            return id;
        }

        public void setId(String id) {
            this.id = id;
        }

        public String getCreatetime() {
            return createtime;
        }

        public void setCreatetime(String createtime) {
            this.createtime = createtime;
        }

        public String getDetail() {
            return detail;
        }

        public void setDetail(String detail) {
            this.detail = detail;
        }

        public String getSrc() {
            return src;
        }

        public void setSrc(String src) {
            this.src = src;
        }

        public String getUsername() {
            return username;
        }

        public void setUsername(String username) {
            this.username = username;
        }

        public int getUserid() {
            return userid;
        }

        public void setUserid(int userid) {
            this.userid = userid;
        }

        public CommonsMultipartFile getImage() {
            return image;
        }

        public void setImage(CommonsMultipartFile image) {
            this.image = image;
        }
    }
    @Autowired
    UserRightsProvider userRightsProvier;

    @RequestMapping(value = "/list")
    @ResponseBody
    public JsonRet list(PagedModel mo) throws NSException {
        PageContext pCtx = new PageContext(mo);
        Notice.Coll coll = new Notice.Coll();
        Notice.Query query = coll.getQuery();
        query.start = (pCtx.getCurPage() - 1) * pCtx.getCountPerPage();
        query.count = pCtx.getCountPerPage();
        RightsContext rightsContext = this.userRightsProvier.getUserRights(NsocUser.getCurrentUser());
        if(!rightsContext.checkRight(RightsValEnum.AllRights.getVal())){
            query.setUserid(NsocUser.getCurrentUser().getUserId());
        }
        new NoticeBiz().load(coll);
        pCtx.setCollection(coll);
        NUserInfoProvider provider = new NUserInfoProvider();
        List<Object> result = coll.stream().map(p -> {
            try {
                return new SetNoticeModel().toNoticeModel(p, provider);
            } catch (NSException e) {
                return new JsonRet(false, e.getMessage());
            }
        }).collect(Collectors.toList());
        return new JsonRet(result, pCtx);
    }

    @RequestMapping(value = "/update", method = RequestMethod.POST)
    @ResponseBody
    public JsonRet update(SetNoticeModel model, HttpServletRequest request, Errors errors) throws NSException, IOException {
        if (errors.hasErrors()) {
            return WebHelper.checkParamErrors(errors);
        }

        NoticeBiz biz = new NoticeBiz();
        Notice.Entity exist = null;
        Notice.Entity o = null;
        //修改时
        if (StringUtils.hasText(model.getId())) {
            exist = biz.get(model.getId());
            if (exist == null) {
                return new JsonRet(false, "没有找到该记录");
            }
            o = Misc.objectCopy(exist, new Notice.Entity());
            o.setDetail(model.getDetail());
            biz.update(o);
        } else {
            String src = "";
            if (model.getImage() != null) {
                File savefile = saveSingleFile(getDir(request, model.getImage()), model.getImage());
                if (savefile == null) {
                    return new JsonRet(false, "上传目录不存在！");
                }
                src = absolutePathToRelativePath(savefile.getAbsolutePath());
            }
            o = new Notice.Entity();
            o.setSrc(src);
            o.setId(IntEncoder.encode36(IDWorker.NextID()));
            o.setCreatetime(LocalDateTime.now());
            o.setUserid(NsocUser.getCurrentUser().getUserId());
            o.setDetail(model.getDetail());
            biz.insert(o);
        }
        return new JsonRet(true);
    }

    @RequestMapping(value = "/erase", method = RequestMethod.POST)
    @ResponseBody
    public JsonRet erase(@RequestBody(required = true) EraseModel m) throws NSException {
        boolean rm = deleteById((m.getId()));
        if (!rm) {
            return new JsonRet(rm, "删除失败！");
        }
        return new JsonRet(rm);
    }

    private boolean deleteById(String id) throws NSException {
        NoticeBiz biz = new NoticeBiz();
        Notice.Entity exist = new Notice.Entity();
        exist.setId(id);
        return biz.delete(exist);
    }

    @RequestMapping(value = "/batchcmd", method = RequestMethod.POST)
    @ResponseBody
    public JsonRet NoticeBatchcmd(@RequestBody BatchUpdateModel m) throws NSException {

        boolean isAllOK = true;
        List<String> ids = new ArrayList<>();
        if (m.getCmd() != null) {
            List<String> strings = Misc.strToStrList(m.getItem());
            if (!strings.isEmpty()) {
                for (String id : strings) {
                    switch (m.getCmd()) {
                        // 勾选删除操作
                        case delete: {
                            boolean rm = deleteById(id);
                            if (!rm) {
                                // 未全部执行成功
                                isAllOK = false;
                                ids.add(id);
                            }
                        }
                        break;
                        default:
                            break;
                    }
                }

            }
        }
        if (isAllOK) {
            return new JsonRet(true);
        } else {
            return new JsonRet(false, "删除失败！");
        }
    }


    public static String getDir(HttpServletRequest request, CommonsMultipartFile file) {
        return request.getSession().getServletContext().getRealPath("file/upload/img");
    }


}
