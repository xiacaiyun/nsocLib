package cn.nsoc.bizmon.web.napi.nprivate;

import cn.nsoc.base.entity.sys.NSException;
import cn.nsoc.bizmon.biz.SuspectJsonModel;
import cn.nsoc.bizmon.biz.mysql.*;
import cn.nsoc.bizmon.entity.defines.Constants;
import cn.nsoc.bizmon.entity.defines.MonType;
import cn.nsoc.bizmon.entity.mysql.Monitor;
import cn.nsoc.bizmon.entity.mysql.Place;
import cn.nsoc.bizmon.entity.mysql.Prewarning;
import cn.nsoc.bizmon.entity.mysql.Suspect;
import cn.nsoc.bizmon.util.Hptimer;
import cn.nsoc.bizmon.web.model.AlarmSearchModel;
import cn.nsoc.bizmon.web.model.UpdateModel;
import cn.nsoc.common.applib.controller.NController;
import cn.nsoc.common.applib.controls.JsonRet;
import cn.nsoc.common.applib.rights.Right;
import cn.nsoc.common.storer.biz.PageContext;
import cn.nsoc.common.util.ExportHelper;
import cn.nsoc.common.util.Misc;
import org.springframework.stereotype.Controller;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import javax.servlet.http.HttpServletResponse;
import java.util.*;
import java.util.stream.Collectors;

@Controller
@RequestMapping(value = "/napi/private/alarm")
@Right(allowAnonymous = true)
public class AlarmController {


    @RequestMapping(value = "/list")
    @ResponseBody
    public JsonRet list(AlarmSearchModel model) throws NSException {
        PageContext pCtx = new PageContext(model);
        Prewarning.Coll coll = new Prewarning.Coll();
        Monitor.Coll monitors = new Monitor.Coll();
        Place.Coll placeColl = new Place.Coll();
        Prewarning.Query query = coll.getQuery();
        Misc.objectCopy(model, query);
        if (StringUtils.hasText(model.getFromevtime())) {
            query.setFromevtime((int) Hptimer.toSeconds(model.getFromevtime()));
        }
        if (StringUtils.hasText(model.getToevtime())) {
            query.setToevtime((int) Hptimer.toSeconds(model.getToevtime()));
        }
        PrewarningBiz biz = new PrewarningBiz();
        MonitorBiz monitorBiz = new MonitorBiz();
        PlaceBiz placeBiz = new PlaceBiz();
        int count = 0;
        List<String> ids;
        if (model.getNameIDList() != null) {
            monitors = monitorBiz.getMonitorsbyName(model.getNameIDList());
            if (monitors.isEmpty()) {
                return new JsonRet(new Object[0], pCtx);
            }
            ids = monitors.stream().map(p -> p.getId()).distinct().collect(Collectors.toList());
            query.setMonidIDList(ids);
            count = biz.countMonkey(query);
        }else {
            monitorBiz.loadValid(monitors);
        }
        query.orderBy = Prewarning.OrderByEnum.EVTIME__DESC;
        query.start = (pCtx.getCurPage() - 1) * pCtx.getCountPerPage();
        query.count = pCtx.getCountPerPage();
        query.selectFields = null;
        biz.loadAll(coll, null);
        if (coll.isEmpty()) {
            return new JsonRet(new Object[0], pCtx);
        }
        placeBiz.loadForAlarm(placeColl);
        pCtx.setCollection(coll);
        List<Map<String, Object>> result = new ArrayList<>();
        for (Prewarning.Entity l : coll) {
            Map<String, Object> e = new HashMap<>();
            Monitor.Entity entity = monitors.findById(l.getMonid());
            Place.Entity place = placeColl.find(l.getServicecode());
            e.put("monid", l.getMonid());
            e.put("auid", l.getAuid());
            e.put("monname", entity != null ? entity.getName() : "");
            e.put("servicename", place == null ? "" : place.getServicename());
            e.put("address", place == null ? "" : place.getAddress());
            e.put("evtime", Hptimer.format(l.getEvtime()));
            e.put("montype", MonType.getByVal(l.getMontype()) == null ? "" : MonType.getByVal(l.getMontype()).getDes());
            e.put("monkey", l.getMonkey());
            result.add(e);
        }
        Map<String, Object> resultMap = new HashMap<>();
        resultMap.put("monkey_total", count);
        resultMap.put("result_list", result);
        return new JsonRet(resultMap, pCtx);
    }

    @RequestMapping(value = "/exportexcel", method = RequestMethod.GET)
    @ResponseBody
    public void export(@RequestParam(required = false) List<String> ids,
                       @RequestParam(required = false) String Fromevtime,
                       @RequestParam(required = false) String Toevtime,
                       @RequestParam(required = false) List<String> nameIDList,
                       @RequestParam(required = false) Integer montype,
                       @RequestParam(required = false) String monkey,
                       @RequestParam(required = false) String fields, HttpServletResponse response) throws NSException {
        Prewarning.Coll coll = new Prewarning.Coll();
        Prewarning.Query query = coll.getQuery();
        query.setAuidIDList(ids);
        query.setMonkey(monkey);
        query.setMontype(montype);
        if (StringUtils.hasText(Fromevtime)) {
            query.setFromevtime((int) Hptimer.toSeconds(Fromevtime));
        }
        if (StringUtils.hasText(Toevtime)) {
            query.setToevtime((int) Hptimer.toSeconds(Toevtime));
        }
        MonitorBiz monitorBiz = new MonitorBiz();
        Monitor.Coll monitors = new Monitor.Coll();
        if (nameIDList != null) {
            monitors = monitorBiz.getMonitorsbyName(nameIDList);
            if (monitors.isEmpty()) {
                return;
            }
            query.setMonidIDList(monitors.stream().map(p -> p.getId()).distinct().collect(Collectors.toList()));
        }else {
            monitorBiz.loadValid(monitors);
        }
        new PrewarningBiz().loadAll(coll, null);
        Place.Coll placeColl = new Place.Coll();
        if (!coll.isEmpty()) {
            new PlaceBiz().loadForAlarm(placeColl);
        }
        buildSuspExcel(coll, monitors, placeColl, fields, response);
    }

    private void buildSuspExcel(Prewarning.Coll alarmColl, Monitor.Coll monitorColl, Place.Coll placeColl, String fields, HttpServletResponse response) throws NSException {

        if (!StringUtils.hasText(fields)) {
            StringBuilder sb = new StringBuilder();
            sb.append("<table border=1><tr> " +
                    "<th>布控名称</th> " +
                    "<th>布控类型</th> " +
                    "<th>布控线索</th> " +
                    "<th>报警时间</th> " +
                    "<th>场所名称</th> " +
                    "<th>场所地址</th> </tr>");
            for (Prewarning.Entity alarm : alarmColl) {
                String data = "";
                UpdateModel detailedInfo = getDetailedInfo(alarm.getAuid(), alarmColl, monitorColl, placeColl);
                if (detailedInfo == null) {
                    continue;
                }

                data = String.format("<tr>" +
                                ExportHelper.CELL_COLUMN +
                                ExportHelper.CELL_COLUMN +
                                ExportHelper.CELL_COLUMN +
                                ExportHelper.CELL_COLUMN +
                                ExportHelper.CELL_COLUMN +
                                ExportHelper.CELL_COLUMN,
                        detailedInfo.getName(),
                        detailedInfo.getMontypedesc(),
                        detailedInfo.getMonkey(),
                        detailedInfo.getAlarmtime(),
                        detailedInfo.getServicename(),
                        detailedInfo.getAddress());
                sb.append(data);
            }
            sb.append("</table>");
            String excelData = ExportHelper.BuildDownLoadHtml(sb.toString());
            String fileName = "预警列表";
            NController.exportToExcel(response, excelData, fileName);
        } else {
            StringBuilder sb = new StringBuilder();
            List<String> fieldList = Arrays.asList(fields.split(","));
            sb.append("<table border=1><tr> " +
                    "<th>布控名称</th> " +
                    "<th>布控类型</th> " +
                    "<th>布控线索</th> " +
                    "<th>报警时间</th> " +
                    "<th>场所名称</th> " +
                    "<th>场所地址</th>");
            for (String field : fieldList) {
                sb.append("<th>" + field + "</th>");
            }
            sb.append("</tr>");

            Suspect.Coll sColl = SuspectCache.getInstance().search("suspect");
            for (Prewarning.Entity alarm : alarmColl) {
                UpdateModel detailedInfo = getDetailedInfo(alarm.getAuid(), alarmColl, monitorColl, placeColl);
                if (detailedInfo == null) {
                    continue;
                }
                MonType type = MonType.getByVal(detailedInfo.getMontype());
//                SuspectCache.getInstance().search(type,detailedInfo.getMonkey());
                Suspect.Coll coll = sColl.findRelated(type, detailedInfo.getMonkey());
                if (coll.isEmpty()) {
                    StringBuilder temp = new StringBuilder();
                    temp.append(toBasicHtml(detailedInfo));
                    temp.append("</tr>");
                    sb.append(temp);
                } else {
                    for (Suspect.Entity entity : coll) {
                        StringBuilder temp = new StringBuilder();
                        temp.append(toBasicHtml(detailedInfo));
                        String other = entity == null ? "" : entity.getOther();
                        SuspectJsonModel jsonModel = Misc.fromJson(other, SuspectJsonModel.class);
                        if (jsonModel == null) {
                            jsonModel = new SuspectJsonModel();
                        }

                        if (fieldList.contains(Constants.SuspectFields.DISTRICT)) {
                            temp.append(String.format(ExportHelper.CELL_COLUMN, jsonModel.getDistrict() != null ? jsonModel.getDistrict() : ""));
                        }
                        if (fieldList.contains(Constants.SuspectFields.USERNAME)) {
                            String re = entity == null ? "" : entity.getUsername();
                            temp.append(String.format(ExportHelper.CELL_COLUMN, re));
                        }
                        if (fieldList.contains(Constants.SuspectFields.GENDER)) {
                            temp.append(String.format(ExportHelper.CELL_COLUMN, jsonModel.getGender() != null ? jsonModel.getGender() : ""));
                        }
                        if (fieldList.contains(Constants.SuspectFields.PID)) {
                            String re = entity == null ? "" : entity.getPid();
                            temp.append(String.format(ExportHelper.CELL_COLUMN, re));
                        }
                        if (fieldList.contains(Constants.SuspectFields.BORN_PLACE)) {
                            temp.append(String.format(ExportHelper.CELL_COLUMN, jsonModel.getBornplace() != null ? jsonModel.getBornplace() : ""));
                        }
                        if (fieldList.contains(Constants.SuspectFields.RESIDENCE_PLACE)) {
                            temp.append(String.format(ExportHelper.CELL_COLUMN, jsonModel.getResidenceplace() != null ? jsonModel.getResidenceplace() : ""));
                        }
                        if (fieldList.contains(Constants.SuspectFields.ADDR_BOOK_NAME)) {
                            temp.append(String.format(ExportHelper.CELL_COLUMN, jsonModel.getAddrbookname() != null ? jsonModel.getAddrbookname() : ""));
                        }
                        if (fieldList.contains(Constants.SuspectFields.MOBILE)) {
                            String re = entity == null ? "" : entity.getMobile();
                            temp.append(String.format(ExportHelper.CELL_COLUMN, re));
                        }

                        if (fieldList.contains(Constants.SuspectFields.MAC)) {
                            String re = entity == null ? "" : entity.getMac();
                            temp.append(String.format(ExportHelper.CELL_COLUMN, re));
                        }


                        if (fieldList.contains(Constants.SuspectFields.WX_GROUP_ID)) {
                            String re = entity == null ? "" : entity.getWxgroupid();
                            temp.append(String.format(ExportHelper.CELL_COLUMN, re));
                        }
                        if (fieldList.contains(Constants.SuspectFields.WX_GROUP_NAME)) {
                            temp.append(String.format(ExportHelper.CELL_COLUMN, jsonModel.getWxgroupname() != null ? jsonModel.getWxgroupname() : ""));
                        }

                        if (fieldList.contains(Constants.SuspectFields.WX)) {
                            String re = entity == null ? "" : entity.getWx();
                            temp.append(String.format(ExportHelper.CELL_COLUMN, re));
                        }
                        if (fieldList.contains(Constants.SuspectFields.WX_ID)) {
                            String re = entity == null ? "" : entity.getWxid();
                            temp.append(String.format(ExportHelper.CELL_COLUMN, re));
                        }
                        if (fieldList.contains(Constants.SuspectFields.WX_NAME)) {
                            temp.append(String.format(ExportHelper.CELL_COLUMN, jsonModel.getWxname() != null ? jsonModel.getWxname() : ""));
                        }
                        if (fieldList.contains(Constants.SuspectFields.QQ)) {
                            String re = entity == null ? "" : entity.getQq();
                            temp.append(String.format(ExportHelper.CELL_COLUMN, re));
                        }
                        if (fieldList.contains(Constants.SuspectFields.NICKNAME)) {
                            temp.append(String.format(ExportHelper.CELL_COLUMN, jsonModel.getNickname() != null ? jsonModel.getNickname() : ""));
                        }
                        if (fieldList.contains(Constants.SuspectFields.QQ_GROUP)) {
                            temp.append(String.format(ExportHelper.CELL_COLUMN, jsonModel.getQqgroup() != null ? jsonModel.getQqgroup() : ""));
                        }
                        if (fieldList.contains(Constants.SuspectFields.GROUP)) {
                            temp.append(String.format(ExportHelper.CELL_COLUMN, jsonModel.getGroup() != null ? jsonModel.getGroup() : ""));
                        }
                        if (fieldList.contains(Constants.SuspectFields.GROUP_NICKNAME)) {
                            temp.append(String.format(ExportHelper.CELL_COLUMN, jsonModel.getGroupnickname() != null ? jsonModel.getGroupnickname() : ""));
                        }

                        if (fieldList.contains(Constants.SuspectFields.IMPORTANT_PERSON)) {
                            temp.append(String.format(ExportHelper.CELL_COLUMN, jsonModel.getImportantperson() != null ? jsonModel.getImportantperson() : ""));
                        }

                        if (fieldList.contains(Constants.SuspectFields.REMARK1)) {
                            temp.append(String.format(ExportHelper.CELL_COLUMN, jsonModel.getRemark1() != null ? jsonModel.getRemark1() : ""));
                        }
                        if (fieldList.contains(Constants.SuspectFields.REMARK2)) {
                            temp.append(String.format(ExportHelper.CELL_COLUMN, jsonModel.getRemark2() != null ? jsonModel.getRemark2() : ""));
                        }
                        if (fieldList.contains(Constants.SuspectFields.REMARK3)) {
                            temp.append(String.format(ExportHelper.CELL_COLUMN, jsonModel.getRemark3() != null ? jsonModel.getRemark3() : ""));
                        }
                        temp.append("</tr>");
                        sb.append(temp);
                    }
                }

            }
            sb.append("</table>");
            String excelData = ExportHelper.BuildDownLoadHtml(sb.toString());
            String fileName = "预警关联库列表";
            NController.exportToExcel(response, excelData, fileName);
        }
    }


    @RequestMapping(value = "/get", method = RequestMethod.GET)
    @ResponseBody
    public JsonRet get(@RequestParam(required = false) String id) throws NSException {
        Prewarning.Coll coll = new Prewarning.Coll();
        Prewarning.Query query = coll.getQuery();
        query.setAuid(id);
        new PrewarningBiz().loadAll(coll, null);
        Monitor.Coll monitorcoll = new Monitor.Coll();
        Place.Coll placeColl = new Place.Coll();
        if (!coll.isEmpty()) {

            Monitor.Query monquery = monitorcoll.getQuery();
            monquery.setIdIDList(coll.stream().map(p -> p.getMonid()).distinct().collect(Collectors.toList()));
            (new MonitorBiz()).load(monitorcoll);

            new PlaceBiz().loadForAlarm(placeColl);
        }
        return new JsonRet(getDetailedInfo(id, coll, monitorcoll, placeColl));
    }

    @RequestMapping(value = "/isrelatesuspect", method = RequestMethod.GET)
    @ResponseBody
    public JsonRet relateSuspect(@RequestParam(required = false) List<String> idList,
                                 @RequestParam(required = false) String monkey,
                                 @RequestParam(required = false) String Fromevtime,
                                 @RequestParam(required = false) String Toevtime,
                                 @RequestParam(required = false) List<String> nameIDList,
                                 @RequestParam(required = false) Integer montype) throws NSException {
        Prewarning.Coll coll = new Prewarning.Coll();
        if (idList == null) {
            Prewarning.Query query = coll.getQuery();
            query.setMonkey(monkey);
            query.setMontype(montype);
            if (StringUtils.hasText(Fromevtime)) {
                query.setFromevtime((int) Hptimer.toSeconds(Fromevtime));
            }
            if (StringUtils.hasText(Toevtime)) {
                query.setToevtime((int) Hptimer.toSeconds(Toevtime));
            }
            PrewarningBiz biz = new PrewarningBiz();
            biz.loadAll(coll, nameIDList);
        }
        Map<String, Object> map = new HashMap<>();
        map.put("isrelated", isRelateSuspect(coll));
        return new JsonRet(map);
    }

    private UpdateModel getDetailedInfo(String id, Prewarning.Coll alarmColl, Monitor.Coll monitorColl, Place.Coll placeColl) throws NSException {
        Prewarning.Entity o = null;
        UpdateModel model = new UpdateModel();
        if (StringUtils.hasText(id)) {
            o = alarmColl.find(id);
            if (o != null) {
                Monitor.Entity mo = monitorColl.findById(o.getMonid());
                Place.Entity place = placeColl.find(o.getServicecode());
                model.setName(mo != null ? mo.getName() : "");
                model.setMontype(o.getMontype());
                model.setMontypedesc(MonType.getByVal(o.getMontype()).getDes());
                model.setMonkey(o.getMonkey());
                model.setAlarmtime(Hptimer.format(o.getEvtime()));
                model.setServicename(place != null ? place.getServicename() : "");
                model.setAddress(place != null ? place.getAddress() : "");
            } else {
                return null;
            }
        }
        return model;
    }

    public boolean isRelateSuspect(Prewarning.Coll coll) throws NSException {
        boolean flag = false;
        SuspectBiz biz = new SuspectBiz();
        for (Prewarning.Entity pre : coll) {
            if (biz.isRelatedSuspect(pre.getMontype(), pre.getMonkey())) {
                flag = true;
                break;
            }
        }
        return flag;
    }

    @RequestMapping(value = "/monkeylist/list")
    @ResponseBody
    public JsonRet listAllMonkeys() throws NSException {
        return new JsonRet(new PrewarningBiz().getMonkeyList());
    }

    public String toBasicHtml(UpdateModel detailedInfo) {
        String data = String.format("<tr>" +
                        ExportHelper.CELL_COLUMN +
                        ExportHelper.CELL_COLUMN +
                        ExportHelper.CELL_COLUMN +
                        ExportHelper.CELL_COLUMN +
                        ExportHelper.CELL_COLUMN +
                        ExportHelper.CELL_COLUMN,
                detailedInfo.getName(),
                detailedInfo.getMontypedesc(),
                detailedInfo.getMonkey(),
                detailedInfo.getAlarmtime(),
                detailedInfo.getServicename(),
                detailedInfo.getAddress());
        return data;
    }

}
