package cn.nsoc.bizmon.web.napi.nprivate;

import cn.nsoc.base.entity.sys.NSException;
import cn.nsoc.bizmon.biz.mysql.PhotoBiz;
import cn.nsoc.bizmon.entity.mysql.Photo;
import cn.nsoc.bizmon.web.config.AppConfig;
import cn.nsoc.common.applib.biz.AppLogBiz;
import cn.nsoc.common.provider.UserRightsProvider;
import cn.nsoc.common.storer.EntityCollection;
import cn.nsoc.common.storer.EntityQuery;
import cn.nsoc.common.storer.Storer;
import cn.nsoc.common.storer.biz.CommonBaseBiz;
import cn.nsoc.common.storer.db.DbStorer;
import cn.nsoc.common.storer.db.DbUpdateBuilder;
import cn.nsoc.common.util.IDWorker;
import cn.nsoc.common.util.IntEncoder;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.util.StringUtils;
import org.springframework.web.multipart.commons.CommonsMultipartFile;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.*;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.regex.Pattern;
import java.util.stream.Collectors;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;

public class AttachedHelper {
    private static final Logger log = LoggerFactory.getLogger(AttachedHelper.class);

    protected boolean saveFile(CommonsMultipartFile[] files, String name, HttpServletRequest request) throws NSException {
        PhotoBiz biz = new PhotoBiz();
        boolean insert = false;
        for (CommonsMultipartFile file : files) {
            Photo.Entity o = new Photo.Entity();
            String dir = getDir(request, name);
            File savefile = saveSingleFile(dir, file);
            o.setPid(file.getOriginalFilename().split("\\.")[0]);
            o.setId(IntEncoder.encode36(IDWorker.NextID()));
            o.setSrc(absolutePathToRelativePath(savefile.getAbsolutePath()));
            o.setName(name);
            o.setTime(LocalDateTime.now());
            insert = biz.insert(o);
        }
        return insert;
    }

    public <T> boolean partUpdate(T me) throws NSException {
        Storer storer = new CommonBaseBiz().getStorer();
        DbUpdateBuilder updateBuilder = new DbUpdateBuilder((DbStorer) storer);
        updateBuilder.include("src", "username", "name");
        return storer.update(me, updateBuilder);
    }


    public File saveSingleFile(String dirPath, CommonsMultipartFile file) {
        if (dirPath == null) {
            return null;
        }
        File dir = new File(dirPath);
        if (!dir.exists()) {
            dir.mkdirs();
        }
        String fileName = file.getOriginalFilename();
        File savefile = new File(dirPath, fileName);
        if (!savefile.exists()) {
            savefile.mkdirs();
        }
        try {
            file.transferTo(savefile);
        } catch (IOException e) {
            new AppLogBiz().log(this.getClass().getSimpleName(), e.toString());
        }
        return savefile;
    }

    public String getDir(HttpServletRequest request, String name) {
        String dir = request.getSession().getServletContext().getRealPath("file/upload/photo");
        if (StringUtils.hasText(name)) {
            dir += "/" + name.trim();
        }
        return dir;
    }


    protected boolean eraseFile(String dirPath, String name) {
        if (!StringUtils.hasText(dirPath)) {
            return false;
        }
        boolean ret = false;
        if (StringUtils.hasText(name)) {
            File f = new File(dirPath, name);
            if (f.exists() && f.isFile()) {
                ret = f.delete();
            }
        } else {
            File f = new File(dirPath);
            if (f.exists() && f.isDirectory()) {
                f.delete();
            }
        }
        return ret;
    }

    public void eraseFile(String dirPath) {
        eraseFile(dirPath, null);
    }


    public String buildZip(String name, HttpServletRequest request) throws FileNotFoundException {
        String dirPath = getDir(request, name);
        return createZip(dirPath, dirPath + "/" + name + ".zip");
    }

    public static String createZip(String sourcePath, String zipPath) {
        FileOutputStream fos = null;
        ZipOutputStream zos = null;
        try {
            fos = new FileOutputStream(zipPath);
            zos = new ZipOutputStream(fos);
            writeZip(new File(sourcePath), "", zos);
        } catch (FileNotFoundException e) {
            log.error("创建ZIP文件失败", e);
        } finally {
            try {
                if (zos != null) {
                    zos.close();
                }
            } catch (IOException e) {
                log.error("创建ZIP文件失败", e);
            }

        }
        return zipPath;
    }

    private static void writeZip(File file, String parentPath, ZipOutputStream zos) {
        if (file.exists()) {
            if (file.isDirectory()) {//处理文件夹
                parentPath += file.getName() + File.separator;
                File[] files = file.listFiles();
                if (files.length != 0) {
                    for (int i = 0; i < files.length - 1; i++) {
                        writeZip(files[i], parentPath, zos);
                    }
                } else {
                    try {
                        zos.putNextEntry(new ZipEntry(parentPath));
                    } catch (IOException e) {
                        // TODO Auto-generated catch block
                        e.printStackTrace();
                    }
                }
            } else {
                FileInputStream fis = null;
                try {
                    fis = new FileInputStream(file);
                    ZipEntry ze = new ZipEntry(file.getName());
                    zos.putNextEntry(ze);
                    byte[] content = new byte[1024];
                    int len;
                    while ((len = fis.read(content)) != -1) {
                        zos.write(content, 0, len);
                        zos.flush();
                    }

                } catch (FileNotFoundException e) {
                    log.error("创建ZIP文件失败", e);
                } catch (IOException e) {
                    log.error("创建ZIP文件失败", e);
                } finally {
                    try {
                        if (fis != null) {
                            fis.close();
                        }
                    } catch (IOException e) {
                        log.error("创建ZIP文件失败", e);
                    }
                }
            }
        }
    }


    public String trimPath(String absolutePath) {
        if (StringUtils.hasText(absolutePath)) {
            return absolutePath.substring(absolutePath.lastIndexOf("/") + 1);
        }
        return "";
    }

    public String absolutePathToRelativePath(String absolutePath) {
        if (StringUtils.hasText(absolutePath)) {
            String src = "/biz/" + absolutePath.substring(absolutePath.indexOf("file"), absolutePath.length());
            return src.replaceAll("\\\\", "/");
        }
        return "";
    }


}
