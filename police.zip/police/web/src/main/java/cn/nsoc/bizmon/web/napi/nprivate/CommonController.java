package cn.nsoc.bizmon.web.napi.nprivate;

import cn.nsoc.base.entity.sys.NSException;
import cn.nsoc.bizmon.biz.mysql.ConfigBiz;
import cn.nsoc.bizmon.biz.mysql.PlaceBiz;
import cn.nsoc.bizmon.entity.defines.MonType;
import cn.nsoc.bizmon.entity.defines.PlaceStatus;
import cn.nsoc.bizmon.entity.mysql.Config;
import cn.nsoc.bizmon.entity.mysql.Place;
import cn.nsoc.common.applib.controls.JsonRet;
import cn.nsoc.common.applib.controls.PairResult;
import cn.nsoc.common.applib.rights.Right;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Map;

/**
 * Created by Administrator on 2017/7/14.
 */
@Controller
@RequestMapping(value = "/napi/private/common")
@Right(allowAnonymous = true)
public class CommonController {
    @RequestMapping("placestatusenum/list")
    @ResponseBody
    public JsonRet getPlaceStatus() throws NSException {

        List result = new ArrayList();
        Arrays.stream(PlaceStatus.values()).forEach(p -> {
            result.add(new PairResult(p.getVal(),p.getDes()));
        });
        return new JsonRet(result);
    }

    @RequestMapping("montypeenum/list")
    @ResponseBody
    public JsonRet getMonType() throws NSException {

        List result = new ArrayList();
        Arrays.stream(MonType.values()).forEach(p -> {
            result.add(new PairResult(p.getVal(),p.getDes()));
        });
        return new JsonRet(result);
    }


    @RequestMapping("police/list")
    @ResponseBody
    public JsonRet getAllpolices() throws NSException {
        Map<String, String> policeDictFromDb = new PlaceBiz().getDictFromPlace("police");
        return new JsonRet(policeDictFromDb);
    }

    @RequestMapping("servicetype/list")
    @ResponseBody
    public JsonRet getservicetypes() throws NSException {
        Place.Coll coll = new Place.Coll();
        new PlaceBiz().loadservicetype(coll);
        return new JsonRet(coll);
    }

    @RequestMapping("config/list")
    @ResponseBody
    public JsonRet getConfigList() throws NSException {
        Config.Coll coll = new Config.Coll();
        new ConfigBiz().load(coll);
        return new JsonRet(coll);
    }
}
