package cn.nsoc.bizmon.web.config;

import cn.nsoc.common.applib.webconfig.BaseNsocMvcInitializer;

/**
 * Created by sam on 16-5-26.
 */
public class NsocAppMvcInitializer extends BaseNsocMvcInitializer {
    @Override
    protected Class<?>[] getRootConfigClasses() {
        return new Class<?>[]{ NsocAppConfig.class,NsocSecurityConfig.class};
    }
}
