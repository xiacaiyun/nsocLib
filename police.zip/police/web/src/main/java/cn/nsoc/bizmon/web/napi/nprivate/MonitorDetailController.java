package cn.nsoc.bizmon.web.napi.nprivate;

import cn.nsoc.base.entity.sys.NSException;
import cn.nsoc.bizmon.biz.mysql.MonitorBiz;
import cn.nsoc.bizmon.entity.mysql.Monitor;
import cn.nsoc.bizmon.web.model.AlarmSearchModel;
import cn.nsoc.bizmon.web.model.BatchUpdateModel;
import cn.nsoc.bizmon.web.model.EraseModel;
import cn.nsoc.bizmon.web.model.MonitorUpdateModel;
import cn.nsoc.common.applib.controls.JsonRet;
import cn.nsoc.common.applib.rights.Right;
import cn.nsoc.common.storer.biz.PageContext;
import cn.nsoc.common.util.Misc;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;


@Controller
@RequestMapping(value = "/napi/private/monitordetail")
@Right(allowAnonymous = true)
public class MonitorDetailController {


    @Autowired
    private MonitorController monCtrl;

    @RequestMapping(value = "/list")
    @ResponseBody
    public JsonRet listDetails(AlarmSearchModel mo) throws NSException {
        PageContext pCtx = new PageContext(mo);
        Monitor.Coll coll = new Monitor.Coll();
        MonitorBiz monBiz = new MonitorBiz();
        Monitor.Query query = coll.getQuery();
        Misc.objectCopy(mo,query);
        query.start = (pCtx.getCurPage() - 1) * pCtx.getCountPerPage();
        query.count = pCtx.getCountPerPage();
        query.orderBy = Monitor.OrderByEnum.STARTTIME__DESC_MONTYPE__DESC;
        monBiz.load(coll);
        pCtx.setCollection(coll);
        if (coll.isEmpty()) {
            return new JsonRet(new Object[0], pCtx);
        }
        return new JsonRet(monBiz.toHtml(coll),pCtx);

}


    @RequestMapping(value = "/update", method = RequestMethod.POST)
    @ResponseBody
    public JsonRet update(@RequestBody MonitorUpdateModel model) throws NSException, IOException {
        if (model.getServicecode() != null && model.getServicecode().length() > 400) {
            return new JsonRet(false, "场所过多");
        }
        MonitorBiz biz = new MonitorBiz();
        Monitor.Entity exist = null;
        Monitor.Entity o = null;
        if (StringUtils.hasText(model.getId())) {
            exist = biz.get(model.getId());
            if (exist == null) {
                return new JsonRet(false, "没有找到该记录");
            }
            o = Misc.objectCopy(exist, new Monitor.Entity());
            Misc.objectCopy(model,o);
            o.setMontype(model.getMontypeval());
            o.setStarttime(Misc.parseISODateTime(model.getStarttime()));
            o.setEndtime(Misc.parseISODateTime(model.getEndtime()));
            biz.update(o);
            return new JsonRet(true, "更新成功！");
        }else {
            return new JsonRet(false, "更新失败！");
        }

    }

    @RequestMapping(value = "/erase", method = RequestMethod.POST)
    @ResponseBody
    public JsonRet erase(@RequestBody(required = false) EraseModel m) throws NSException {
        if (StringUtils.hasText(m.getId())) {
            m.setId(m.getId().trim());
            deleteById(m.getId(), m.getIsvalid());
            return new JsonRet(true, "操作成功！");
        }else {
            return new JsonRet(false, "操作失败！");
        }

    }

    @RequestMapping(value = "/exportexcel", method = RequestMethod.GET)
    @ResponseBody
    public void export(@RequestParam(required = false) String ids, HttpServletResponse response) throws NSException {
        Monitor.Coll coll = new Monitor.Coll();
        Monitor.Query query = coll.getQuery();
        query.setIdIDList(Misc.strToStrList(ids));
        new MonitorBiz().load(coll);
        monCtrl.buildExcel(coll, response);
    }

    @RequestMapping(value = "/get", method = RequestMethod.GET)
    @ResponseBody
    public JsonRet get(@RequestParam(required = false) String id) throws NSException {
        return new JsonRet(monCtrl.getDetailedInfo(id));
    }

    private boolean deleteById(String id, Integer flag) throws NSException {
        MonitorBiz biz = new MonitorBiz();
        Monitor.Entity exist = new Monitor.Entity();
        exist.setId(id);
        return biz.updateIsValid(exist, flag);
    }

    //勾选删除
    @RequestMapping(value = "/batchcmd", method = RequestMethod.POST)
    @ResponseBody
    public JsonRet suspectBatchcmd(@RequestBody BatchUpdateModel m, HttpServletResponse response) throws NSException {

        boolean isAllOK = true;
        List<String> lstErrors = new ArrayList<>();
        if (m.getCmd() != null) {
            List<String> strings = Misc.strToStrList(m.getItem());
            if (!strings.isEmpty()) {
                for (String id : strings) {
                    switch (m.getCmd()) {
                        // 勾选删除操作
                        case unfavorite: {
                            boolean rm = deleteById(id, 0);
                            if (!rm) {
                                // 未全部执行成功
                                isAllOK = false;
                                lstErrors.add(id);
                            }
                        }
                        break;
                        case favorite:
                            boolean rm = deleteById(id, 1);
                            if (!rm) {
                                isAllOK = false;
                                lstErrors.add(id);
                            }
                            break;
                        default:
                            break;
                    }
                }

            }
        }
        if (isAllOK) {
            return new JsonRet(true);
        } else {
            return new JsonRet(false, String.format("%s 删除失败！",lstErrors.toString()));
        }
    }


}
