var gulp = require('gulp');
var sass = require('gulp-sass');
var uglify = require('gulp-uglify');
var livereload = require('gulp-livereload');
var sourcemaps = require('gulp-sourcemaps');

var COMMON_CSS_DIR = 'static/app/css/';

gulp.task('sass', function () {
    return gulp.src(COMMON_CSS_DIR + 'index.scss')
        .pipe(sass().on('error',sass.logError))
        .pipe(sourcemaps.init())
        .pipe(sourcemaps.write('map', {
            includeContent: false,
            sourceRoot: '../'
        }))
        .pipe(gulp.dest(COMMON_CSS_DIR + 'dist'));
    // return sass(COMMON_CSS_DIR + 'index.scss',{
    //         sourcemap: true
    //     }).on('error', sass.logError)
    //     // .pipe(sourcemaps.write())
    //     .pipe(sourcemaps.write('map', {
    //         includeContent: false,
    //         sourceRoot: '../'
    //     }))
    //     .pipe(gulp.dest(COMMON_CSS_DIR + 'dist'));
        // .pipe(livereload());
});

gulp.task('watch', function () {
    // livereload.listen();
    gulp.watch(COMMON_CSS_DIR + '*.scss', ['sass']);
});