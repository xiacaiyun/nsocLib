require(commonDeps.concat([

	mySrvDir+'nsoc.authService.js',
    myCtrlDir+'nsoc.controller.mainCtrl.js',
    myDir + 'js/multi.min.js'
]), function (angular) {

	angular.element(document).ready(function () {

		angular.bootstrap(document, ['app']);
		angular.element(document).find('html').addClass('ng-app');

	});

    window.getDateTime = function (days, isEnd, init) {
        isEnd = isEnd || false;
        var miliseconds = init ? (new Date(init)).getTime() : Date.now();
        return (new Date(miliseconds - (days - 1) * 24 * 3600 * 1000)).Format('yyyy-MM-dd') + (isEnd ? ' 23:59:59' : ' 00:00:00');
    };
    window.getDate = function (days, init) {
        var miliseconds = init ? (new Date(init)).getTime() : Date.now();
        return (new Date(miliseconds - (days - 1) * 24 * 3600 * 1000)).Format('yyyy-MM-dd');
    };

    window.suspectFields = [
        {memVal: '区号'},
        {memVal: '姓名'},
        {memVal: '性别'},
        {memVal: '证件号'},
        {memVal: '户籍地址'},
        {memVal: '暂住地'},
        {memVal: '通讯录备注昵称'},
        {memVal: '手机号'},
        {memVal: 'MAC号'},
        {memVal: '微信群号'},
        {memVal: '微信群名'},
        {memVal: '微信号'},
        {memVal: '微信ID'},
        {memVal: '微信名'},
        {memVal: 'QQ号'},
        {memVal: 'QQ昵称'},
        {memVal: 'QQ群号'},
        {memVal: '所属群体'},
        {memVal: '群内昵称'},
        {memVal: '重点人员'},
        {memVal: '备注1'},
        {memVal: '备注2'},
        {memVal: '备注3'}];



});