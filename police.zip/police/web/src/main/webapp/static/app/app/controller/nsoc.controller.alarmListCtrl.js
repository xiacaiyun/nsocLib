define(function (require) {
    'use strict';
    var app = require("nApp");
    app.controller("alarmListCtrl", [
        '$scope', 'ngDialog', '$controller', 'napi',
        function ($scope, ngDialog, $controller, napi) {

            $scope.searchupdateListView = function () {
                $scope.flag = true;
                $scope.updateListView();
            }
            $scope.calcPerPage = 10;
            $scope.listName = "alarm";
            $scope.name = "预警管理";
            $scope.listSearch = {
                Fromevtime: window.getDateTime(1, false),
                Toevtime: window.getDateTime(1, true)
            }

            napi.getList('common/montypeenum').then(function (json) {
                if (json.ret) {
                    $scope.montypelist = json.data;
                } else {
                    alert(json.msg || '获取montypelist数据失败', ngDialog);
                }
            });
            napi.getList('monitor/namelist').then(function (json) {
                if (json.ret) {
                    $scope.monitorNameList = json.data;
                } else {
                    alert(json.msg || '获取montypelist数据失败', ngDialog);
                }
            });
            napi.getList('alarm/monkeylist').then(function (json) {
                if (json.ret) {
                    $scope.monkeyList = json.data;
                } else {
                    alert(json.msg || '获取montypelist数据失败', ngDialog);
                }
            });
            var scope = $scope;
            $scope.selectNames = function () {
                ngDialog.open({
                    template: myViewDir + 'dlg/monitorNameDlg.html',
                    className: 'ngdialog-theme-default',
                    controller: function ($scope) {
                        $scope.title = '选择布控名称';
                        $scope.detail = '布控名称';
                        setTimeout(function () {
                            var select = document.getElementById('name-multi-select');
                            var nameList = scope.monitorNameList;
                            var selectedList = (scope.listSearch.nameIDList || '').split(',');
                            nameList.forEach(function (value) {
                                var option = document.createElement('option');
                                option.value = value;
                                option.textContent = value;
                                if (selectedList.includes(value)) {
                                    option.selected = true;
                                }
                                select.appendChild(option);
                            });

                            multi(select, {
                                search_placeholder: '搜索布控名称...'
                            });
                        }, 50);
                        $scope.emptyChecked = function () {
                            var selected = document.getElementById('name-multi-select').nextElementSibling.querySelector('.selected-wrapper');
                            while (selected.childElementCount) {
                                selected.children[0].click();
                            }
                        };
                        $scope.itemSubmit = function () {
                            var select = document.getElementById('name-multi-select');
                            scope.listSearch.nameIDList = Array.from(select.selectedOptions).map(function (opt) {
                                return opt.value;
                            }).toString();
                            $scope.closeThisDialog();
                        }
                    }
                });
            };
            $scope.selectMonkeys = function () {
                ngDialog.open({
                    template: myViewDir + 'dlg/monitorNameDlg.html',
                    className: 'ngdialog-theme-default',
                    controller: function ($scope) {
                        $scope.title = '选择布控线索';
                        $scope.detail = '布控线索';
                        setTimeout(function () {
                            var select = document.getElementById('name-multi-select');
                            var nameList = scope.monkeyList;
                            var selectedList = (scope.listSearch.monkeyIDList || '').split(',');
                            nameList.forEach(function (value) {
                                var option = document.createElement('option');
                                option.value = value;
                                option.textContent = value;
                                if (selectedList.includes(value)) {
                                    option.selected = true;
                                }
                                select.appendChild(option);
                            });

                            multi(select, {
                                search_placeholder: '搜索布控线索...'
                            });
                        }, 50);
                        $scope.emptyChecked = function () {
                            var selected = document.getElementById('name-multi-select').nextElementSibling.querySelector('.selected-wrapper');
                            while (selected.childElementCount) {
                                selected.children[0].click();
                            }
                        };
                        $scope.itemSubmit = function () {
                            var select = document.getElementById('name-multi-select');
                            scope.listSearch.monkeyIDList = Array.from(select.selectedOptions).map(function (opt) {
                                return opt.value;
                            }).toString();
                            $scope.closeThisDialog();
                        }
                    }
                });
            };
            $scope.export = function (id) {
                ngDialog.open({
                    template: myViewDir + 'dlg/alarmExportDlg.html?t=12312',
                    className: 'ngdialog-theme-default alarmExportDlg',
                    controller: function ($scope) {
                        $scope.hasCheckbox = false;
                        napi.getItem("alarm", id).then(function (json) {
                            if (json.ret) {
                                $scope.exportinfo = json.data;
                            } else {
                                alert(json.msg || '获取数据失败', ngDialog);
                            }
                        });
                        $scope.relateSuspect = function () {
                            if ($scope.isrelated) {
                                $scope.montypelist = $.extend(true, [], suspectFields);
                                napi.get("alarm/isrelatesuspect", {idList: id}).then(function (json) {
                                    $scope.hasCheckbox = json.data.isrelated;
                                });
                            }
                        };
                        $scope.export = function () {
                            $scope.item = {ids: id, fields: $scope.eventLevelResult.toString()};
                            window.open('napi/private/alarm/exportexcel?' + napi.objToUrlParams($scope.item));
                            $scope.closeThisDialog();
                        }
                    }
                });
            }
            var scope = $scope;
            $scope.exportDlg = function () {
                ngDialog.open({
                    template: myViewDir + 'dlg/alarmDlg.html?t=12312',
                    className: 'ngdialog-theme-default alarmDlg',
                    controller: function ($scope, $controller) {
                        $scope.hasCheckbox = "";
                        $scope.montypelist = $.extend(true, [], suspectFields);
                        $scope.relateSuspect = function () {
                            if ($scope.isrelated) {
                                napi.get("alarm/isrelatesuspect", scope.listSearch).then(function (json) {
                                    $scope.hasCheckbox = json.data.isrelated;
                                });
                            }
                        };
                        $scope.export = function () {
                            var search = $.extend(true, {fields: $scope.eventLevelResult.toString()}, scope.listSearch);
                            window.open('napi/private/alarm/exportexcel?' + napi.objToUrlParams(search));
                            $scope.closeThisDialog();
                        }
                    }
                });
            }
            $scope.opt = {
                batch: [{
                    command: 'export',
                    key: 'auid',
                    name: '批量导出'
                }],
                afterGetList: function (data, json) {
                    $scope.monkey_total = data.monkey_total;
                    json.data = json.data.result_list;
                }
            };
            $scope.flage = false;
            $scope.batchOperation = function (bat, data) {
                if (bat.command === 'export') {
                    window.open('napi/private/alarm/exportexcel?ids=' + data);
                    return false;
                }
                return true;
            };

            $controller("baseListTableCtrl", {$scope: $scope});
            $scope.batch = function () {
                var ids = $scope.listTable.tbody.filter(function (n, i) {
                    return $scope.listTable.itemsChecks[i]
                }).map(function (n) {
                    return n.auid;
                }).join(',');
                if (ids === '') {
                    alert("请先选择内容", ngDialog);
                    return;
                }
                ngDialog.open({
                    template: myViewDir + 'dlg/alarmDlg.html?t=12312',
                    className: 'ngdialog-theme-default alarmDlg',
                    controller: function ($scope, $controller) {
                        $scope.eventLevelResult = [];
                        $scope.hasCheckbox = "";
                        $scope.montypelist = $.extend(true, [], suspectFields);
                        $scope.relateSuspect = function () {
                            if ($scope.isrelated) {
                                napi.get("alarm/isrelatesuspect", $.extend(true, {idList: ids}, scope.listSearch)).then(function (json) {
                                    $scope.hasCheckbox = json.data.isrelated;
                                });
                            }
                        };
                        $scope.export = function () {
                            $scope.item = {ids: ids, fields: $scope.eventLevelResult.toString()};
                            window.open('napi/private/alarm/exportexcel?' + napi.objToUrlParams($scope.item));
                            $scope.closeThisDialog();
                        }
                    }
                });
            };

            $scope.listTable.thead = ["布控名称", "布控类型", "布控线索", "报警时间", "场所名称", "场所地址", "操作"];
        }
    ]);

});