define(function (require) {
    'use strict';
    var app = require("nApp");
    app.controller("configCtrl", [
            '$scope', 'ngDialog', '$controller', 'napi', '$timeout',
            function ($scope, ngDialog, $controller, napi, $timeout) {
                $scope.calcPerPage = 10;
                $scope.title = "案件类别";
                $scope.HideCheckBox = false;
                $scope.listName = "config";
                $scope.opt = {
                    dlgClass: "configDlg",
                    batch: [{
                        command: 'delete',
                        key: 'id',
                        name: '勾选删除'
                    }]
                };
                $scope.detailTemplate = myViewDir + 'dlg/configDlg.html';
                $controller("baseListTableCtrl", {$scope: $scope});
                $scope.listTable.thead = ['编号', '案件类型', '操作'];

            }
        ]
    );

});
