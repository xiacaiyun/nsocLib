define(function (require) {
    'use strict';
    var app = require("nApp");
    app.controller("deviceListCtrl", [
        '$scope', 'ngDialog', '$controller', 'napi',
        function ($scope, ngDialog, $controller, napi) {
            var servicecode = napi.getUrlParams().servicecode;
            $scope.calcPerPage = 20;
            $scope.listName = "device";
            $scope.name = "设备管理";
            $scope.listSearch = {
                servicetype: "全部设备",
                servicecode:servicecode
            }
            $scope.opt = {
                batch: [{
                //     command: 'delete',
                //     key: 'no',
                //     name: '勾选删除'
                // }, {
                    command: 'export',
                    key: 'no',
                    name: '批量导出'
                }],
            };

            $scope.batchOperation = function (bat, data) {
                if (bat.command === 'export') {
                    window.open('napi/private/device/exportexcel?ids=' + data);
                    return false;
                }
                return true;
            };
            napi.getList("device/summary").then(function (json) {
                if (json.ret) {
                    $scope.summary = json.data;
                } else {
                    alert(json.msg || '获取总数据失败', ngDialog);
                }
            });
            $controller("baseListTableCtrl", {$scope: $scope});
            $scope.listTable.thead = ["设备编号", "设备MAC", "所属场所", "所属厂商","设备状态","操作"];
        }
    ]);

});