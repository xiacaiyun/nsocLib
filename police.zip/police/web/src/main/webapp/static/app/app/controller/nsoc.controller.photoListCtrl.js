define(function (require) {
    'use strict';
    var app = require("nApp");
    app.controller("photoListCtrl", [
            '$scope', 'ngDialog', '$controller', 'napi', '$timeout',
            function ($scope, ngDialog, $controller, napi, $timeout) {
                $scope.calcPerPage = 10;
                $scope.title = "重点人员照片管理";
                $scope.HideCheckBox = false;
                $scope.listName = "photo";
                $scope.opt = {
                    dlgClass: "photoDlg",
                    batch: [{
                        command: 'delete',
                        key: 'id',
                        name: '勾选删除'
                    }],
                    onEdit: function (scope) {
                        scope.formSubmit = function () {
                            var item = scope.item;
                            var file = $("#upload_photo")[0].files;
                            // if (file.length === 0) {
                            //     alert("必须选择上传照片！", ngDialog);
                            //     return true;
                            // }
                            // if (file)
                            //     item.file = file;
                            var formData = new FormData();
                            for (var i in item) {
                                if (item.hasOwnProperty(i) && item[i] !== false) {
                                    formData.append(i, item[i]);
                                }
                            }
                            if (file.length > 0) {
                                for (var i = 0; i < file.length; i++) {
                                    formData.append('file', file[i]);
                                }
                            }


                            $.ajax({
                                url: 'napi/private/photo/update',
                                type: 'POST',
                                data: formData,
                                contentType: false,
                                processData: false,
                                xhrFields: {withCredentials: true},
                                success: function (json) {
                                    if (json.ret) {
                                        alert('提交成功', ngDialog);
                                        scope.closeThisDialog();
                                        $scope.updateListView();
                                    } else {
                                        alert(json.msg || '提交失败', ngDialog);
                                    }
                                },
                                error: function () {
                                    alert('网络错误', ngDialog);
                                }
                            });
                        };
                    }
                };

                $scope.buildZip = function () {
                    if (!$scope.listSearch.name) {
                        alert("名称不能为空！", ngDialog);
                        return;
                    }
                    napi.get($scope.listName + "/buildzip", {name: $scope.listSearch.name}).then(function (json) {
                        if (json.ret) {
                            var a = document.createElement('a');
                            a.href = json.msg;
                            a.download = '';
                            a.click();
                            // window.open(json.msg);
                        } else {
                            alert("下载zip失败", ngDialog);
                        }
                    });
                }

                $scope.detailTemplate = myViewDir + 'dlg/photoDlg.html';
                $controller("baseListTableCtrl", {$scope: $scope});
                $scope.listTable.thead = ['名称', '证件号', '姓名', '图片地址', '操作'];
            }
        ]
    );

});
