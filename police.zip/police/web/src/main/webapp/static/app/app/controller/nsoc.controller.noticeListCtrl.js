define(function (require) {
    'use strict';
    var app = require("nApp");
    app.controller("noticeListCtrl", [
            '$scope', 'ngDialog', '$controller', 'napi', '$timeout',
            function ($scope, ngDialog, $controller, napi, $timeout) {
                $scope.calcPerPage = 10;
                $scope.title = "用户消息";
                $scope.HideCheckBox = false;
                $scope.listName = "notice";
                $scope.opt = {
                    dlgClass: "noticeDlg",
                    batch: [{
                        command: 'delete',
                        key: 'id',
                        name: '勾选删除'
                    }],
                    onEdit:function (scope) {
                        scope.formSubmit = function () {
                            var item = scope.item;
                            var file = $("#upload_notice")[0].files[0];
                            if (file)
                                item.image = file;
                            var formData = new FormData();
                            for (var i in item) {
                                if (item.hasOwnProperty(i) && item[i] !== false) {
                                    formData.append(i, item[i]);
                                }
                            }

                            $.ajax({
                                url: 'napi/private/notice/update',
                                type: 'POST',
                                data: formData,
                                contentType: false,
                                processData: false,
                                xhrFields: { withCredentials: true },
                                success: function (json) {
                                    if (json.ret) {
                                        alert('提交成功', ngDialog);
                                        scope.closeThisDialog();
                                        $scope.updateListView();
                                    } else {
                                        alert(json.msg || '提交失败', ngDialog);
                                    }
                                },
                                error: function () {
                                    alert('网络错误', ngDialog);
                                }
                            });
                        };
                    }
                };

                $scope.detailTemplate = myViewDir + 'dlg/noticeDlg.html';
                $controller("baseListTableCtrl", {$scope: $scope});
                $scope.listTable.thead = ['提出人','创建时间','详细内容','图片地址', '操作'];
            }
        ]
    );

});
