define(function (require) {
    'use strict';
    var app = require("nApp");
    app.controller("suspectInfoListCtrl", [
        '$scope', 'ngDialog', '$controller', 'napi', '$timeout',
        function ($scope, ngDialog, $controller, napi, $timeout) {

            $scope.calcPerPage = 10;
            $scope.name = "库录入";
            $scope.HideCheckBox = false;
            $scope.listName = "suspectinfo";

            $scope.opt = {
                dlgClass: "suspectDlg",
                batch: [{
                    command: 'delete',
                    key: 'id',
                    name: '勾选删除'
                }, {
                    command: 'export',
                    key: 'id',
                    name: '批量导出'
                }],
                beforeSubmit: function (item, $scope) {
                    $scope.item = {'configid': item.configid, 'name': item.name, 'id': item.id};
                }
            };
            var configList;
            napi.getList('common/config').then(function (json) {
                if (json.ret) {
                    $scope.configList = json.data;
                    configList = json.data;
                } else {
                    alert(json.msg || '获取configList数据失败', ngDialog);
                }
            });

            $scope.linkToPage = function () {
                if ($scope.listSearch.keyword) {
                    window.open('#/suspectList?keyword=' + $scope.listSearch.keyword);
                }
                $scope.updateListView();
            }


            var scope = $scope;
            $scope.uploadExcel = function () {
                ngDialog.open({
                    template: myViewDir + 'dlg/suspectUploadDlg.html?t=12312',
                    className: 'ngdialog-theme-default suspectUploadDlg',
                    // showClose: false,
                    controller: function ($scope, $controller) {
                        $scope.configList = configList;
                        var $input;
                        var fileNames;
                        $scope.chooseExcel = function () {
                            if (!$input) {
                                $input = $('#upload-file');
                                $input.on('change', function (e) {
                                    $scope.filenames = Array.from(e.target.files).map(function (file) {
                                        return file.name;
                                    }).join('; ');
                                    fileNames = $scope.filenames;
                                    $scope.$apply();
                                });
                            }
                            $input[0].click();
                        };

                        $scope.itemSubmit = function () {
                            if (!fileNames || fileNames.length == 0) {
                                alert('上传文件为空！', ngDialog);
                                return true;
                            }
                            $.ajax({
                                url: 'napi/private/suspectinfo/uploadexcel',
                                type: 'POST',
                                data: new FormData($input.parent().parent()[0]),
                                contentType: false,
                                processData: false,
                                xhrFields: {withCredentials: true},
                                success: function (json) {
                                    if (json.ret) {
                                        alert('上传成功', ngDialog);
                                        $scope.closeThisDialog();
                                        scope.updateListView();
                                    } else {
                                        alert(json.msg || '上传失败', ngDialog);
                                    }
                                },
                                error: function () {
                                    alert('上传失败', ngDialog);
                                }
                            });
                        }
                    }
                });
            };


            $scope.batchOperation = function (bat, data) {
                if (bat.command === 'export') {
                    window.open('napi/private/suspectinfo/exportexcel?ids=' + data);
                    return false;
                }
                return true;
            };
            $scope.detailTemplate = myViewDir + 'dlg/suspectInfoDlg.html';
            $controller("baseListTableCtrl", {$scope: $scope});
            $scope.listTable.thead = ['布控名称(数量)', '类别', '上传时间', '更新时间', '上传人', '操作'];
        }
    ]);
});