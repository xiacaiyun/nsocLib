define(function(require){
	var app = require("nApp")
	.value('AUTH_ENDPOINT','auth')
	.value('LOGOUT_ENDPOINT','exit')
	.service('authService',[
		'AUTH_ENDPOINT','LOGOUT_ENDPOINT','$http',
		function(AUTH_ENDPOINT,LOGOUT_ENDPOINT,$http){
			this.auth = {};
			this.login = function(username,passsword){
				var serviceAuth = this.auth;
 			 	return $http.post(AUTH_ENDPOINT,{username:username,passsword:passsword}).then(function(response,status){
					serviceAuth.user = username;
				});
			};
			this.logout = function(){
				return $http.post(LOGOUT_ENDPOINT).then(function(response){
				});
			};
	}]);
});