define(function (require) {
    'use strict';
    var app = require("nApp");
    app.controller('mainCtrl', [
        '$scope', '$controller', '$state', 'authService', 'napi',
        function ($scope, $controller, $state, authService, napi) {
            $scope.myNav = "BizMon";
            $scope.navOpt = {
                toggleMode: "only",
                subOpen: false
            };
            $controller('mainBaseCtrl', {$scope: $scope});

            napi.get('../../../nfw/napi/private/menu').then(function (json) {
                if (json && json.data && json.data.length === 0) {
                    $('#wrapper').addClass('hide-apps');
                }
            })
        }
    ]);
});

