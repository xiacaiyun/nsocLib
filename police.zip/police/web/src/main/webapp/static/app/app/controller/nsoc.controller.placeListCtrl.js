define(function (require) {
    'use strict';
    var app = require("nApp");
    app.controller("placeListCtrl", [
        '$scope', 'ngDialog', '$controller', 'napi', '$timeout',
        function ($scope, ngDialog, $controller, napi, $timeout) {

            $scope.calcPerPage = 10;
            $scope.name = "场所管理";
            $scope.HideCheckBox = false;
            $scope.listName = "place";
            $scope.listSearch = {
                servicetype: "全部场所"
            }
            napi.getList('common/placestatusenum').then(function (json) {
                if (json.ret) {
                    $scope.placeStatusList = json.data;
                } else {
                    alert(json.msg || '获取placeStatusList数据失败', ngDialog);
                }
            });

            var getSummary = function () {
                napi.getList("place/summary").then(function (json) {
                    if (json.ret) {
                        $scope.summary = json.data;
                    } else {
                        alert(json.msg || '获取总数据失败', ngDialog);
                    }
                });
            };
            getSummary();

            napi.getList("common/police").then(function (json) {
                if (json.ret) {
                    $scope.policeList = json.data;
                } else {
                    alert(json.msg || '获取policeList失败', ngDialog);
                }
            });
            napi.getList("common/servicetype").then(function (json) {
                if (json.ret) {
                    $scope.servicetypeList = json.data;
                } else {
                    alert(json.msg || '获取servicetypeList失败', ngDialog);
                }
            });
            $scope.opt = {
                dlgClass: "placeDlg",
                batch: [{
                    // command: 'delete',
                    // key: 'servicecode',
                    // name: '勾选删除'
                    // }, {
                    command: 'export',
                    key: 'servicecode',
                    name: '批量导出'
                }],
                onEdit: function (scope) {
                    scope.item.placestatus = $scope.placeStatusList[0].memKey + '';

                },
                afterSubmit: function () {
                    getSummary();
                }
            };

            var scope = $scope;
            $scope.uploadExcel = function () {
                ngDialog.open({
                    template: myViewDir + 'dlg/placeUploadDlg.html?t=12312',
                    className: 'ngdialog-theme-default placeUploadDlg',
                    controller: function ($scope, $controller) {
                        var $input;
                        $scope.chooseExcel = function () {
                            if (!$input) {
                                $input = $('#upload-file');
                                $input.on('change', function (e) {
                                    $scope.filenames = Array.from(e.target.files).map(function (file) {
                                        return file.name;
                                    }).join('; ');
                                    $scope.$apply();
                                });
                            }
                            $input[0].click();
                        };

                        $scope.itemSubmit = function () {
                            $.ajax({
                                url: 'napi/private/place/uploadexcel',
                                type: 'POST',
                                data: new FormData($input.parent().parent()[0]),
                                contentType: false,
                                processData: false,
                                xhrFields: {withCredentials: true},
                                success: function (json) {
                                    if (json.ret) {
                                        alert('上传成功', ngDialog);
                                        $scope.closeThisDialog();
                                        scope.updateListView();
                                    } else {
                                        alert(json.msg || '上传失败', ngDialog);
                                    }
                                },
                                error: function () {
                                    alert('上传失败', ngDialog);
                                }
                            });
                        }
                    }
                });
            };

            $scope.batchOperation = function (bat, data) {
                if (bat.command === 'export') {
                    window.open('napi/private/place/exportexcel?ids=' + data);
                    return false;
                }
                return true;
            };
            $scope.detailTemplate = myViewDir + 'dlg/placeDlg.html';
            $controller("baseListTableCtrl", {$scope: $scope});
            $scope.listTable.thead = ['名称', '类型', '状态', '场所代码', '属地网安部门', '厂商','经度', '纬度', '单位负责人', '更新时间', '操作'];
        }
    ]);
});