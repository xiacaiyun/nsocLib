define(function (require) {
	var dir = 'app';
    require('nApp').config([
		'$stateProvider', '$urlRouterProvider', '$locationProvider','napiProvider',
		function ($stateProvider, $urlRouterProvider, $locationProvider,napiProvider) {
			napiProvider.setModuleName("bizmon");
			$stateProvider
                .state('deviceList', {
                    url: '/deviceList',
                    controller: 'deviceListCtrl',
                    templateUrl: myViewDir+'deviceList.html',
                    dependencies: [
                        myCtrlDir+'nsoc.controller.deviceListCtrl.js'
                    ]
                })
                .state('suspectList', {
                    url: '/suspectList',
                    controller: 'suspectListCtrl',
                    templateUrl: myViewDir+'suspectList.html',
                    dependencies: [
                        myCtrlDir+'nsoc.controller.suspectListCtrl.js'
                    ]
                })
                .state('suspectInfoList', {
                    url: '/suspectInfoList',
                    controller: 'suspectInfoListCtrl',
                    templateUrl: myViewDir+'suspectInfoList.html',
                    dependencies: [
                        myCtrlDir+'nsoc.controller.suspectInfoListCtrl.js'
                    ]
                })
                .state('monitorList', {
                    url: '/monitorList',
                    controller: 'monitorListCtrl',
                    templateUrl: myViewDir+'monitorList.html',
                    dependencies: [
                        myCtrlDir+'nsoc.controller.monitorListCtrl.js'
                    ]
                })
                .state('monitorDetailList', {
                    url: '/monitorDetailList',
                    controller: 'monitorDetailListCtrl',
                    templateUrl: myViewDir+'monitorDetailList.html',
                    dependencies: [
                        myCtrlDir+'nsoc.controller.monitorDetailListCtrl.js'
                    ]
                })
                .state('alarmList', {
                    url: '/alarmList',
                    controller: 'alarmListCtrl',
                    templateUrl: myViewDir+'alarmList.html',
                    dependencies: [
                        myCtrlDir+'nsoc.controller.alarmListCtrl.js'
                    ]
                })
                .state('monitorRuleList', {
                    url: '/monitorRuleList',
                    controller: 'monitorRuleListCtrl',
                    templateUrl: myViewDir+'monitorRuleList.html',
                    dependencies: [
                        myCtrlDir+'nsoc.controller.monitorRuleListCtrl.js'
                    ]
                })
                .state('placeList', {
                    url: '/placeList', //等于Browser的显示的url  AngularJS用/#/placeList防止走后端controller的url
                    controller: 'placeListCtrl',
                    templateUrl: myViewDir+'placeList.html',
                    dependencies: [
                        myCtrlDir+'nsoc.controller.placeListCtrl.js'
                    ]
                })
                .state('configList',{
                    url:'/configList',
                    controller: 'configCtrl',
                    templateUrl: myViewDir+'configList.html',
                    dependencies:[
                        myCtrlDir+'nsoc.controller.configCtrl.js'
                    ]
                })
                .state('photoList',{
                    url:'/photoList',
                    controller: 'photoListCtrl',
                    templateUrl: myViewDir+'photoList.html',
                    dependencies:[
                        myCtrlDir+'nsoc.controller.photoListCtrl.js'
                    ]
                })
                .state('noticeList',{
                    url:'/noticeList',
                    controller: 'noticeListCtrl',
                    templateUrl: myViewDir+'noticeList.html',
                    dependencies:[
                        myCtrlDir+'nsoc.controller.noticeListCtrl.js'
                    ]
                })
            ;

		}]);
});