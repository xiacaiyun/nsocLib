define(function (require, exports, module) {
    var angular = require('angular');
    var asyncLoader = require('angular-async-loader');
    require('ng-modules-for-nsoc');
	var app = angular.module('app', ['ui.router', 'ngProgress', 'ui.bootstrap',  'ngDialog']);
	asyncLoader.configure(app);
	app.run([
		'$state', '$stateParams', '$rootScope',
		function ($state, $stateParams, $rootScope) {
			$rootScope.$state = $state;
			$rootScope.$stateParams = $stateParams;
		}]);
	module.exports = app;
});