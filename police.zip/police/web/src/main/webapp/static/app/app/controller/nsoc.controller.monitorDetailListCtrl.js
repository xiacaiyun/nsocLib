define(function (require) {
    'use strict';
    var app = require("nApp");
    app.controller("monitorDetailListCtrl", [
        '$scope', 'ngDialog', '$controller', 'napi','$state',
        function ($scope, ngDialog, $controller, napi,$state) {

            var name = napi.getUrlParams().nameIDList;
            $scope.listSearch = {
                nameIDList: name
            }
            $scope.calcPerPage = 10;
            $scope.name = "布控详情";
            $scope.HideCheckBox = false;
            $scope.listName = "monitordetail";

            napi.getList('common/montypeenum').then(function (json) {
                if (json.ret) {
                    $scope.montypelist = json.data;
                } else {
                    alert(json.msg || '获取montypelist数据失败', ngDialog);
                }
            });

            napi.getList('place/placedict').then(function (json) {
                if (json.ret) {
                    $scope.servicelist = json.data;
                } else {
                    alert(json.msg || '获取servicelist数据失败', ngDialog);
                }
            });


            $scope.export = function (id) {
                ngDialog.open({
                    template: myViewDir + 'dlg/monitorExportDlg.html?t=12312',
                    className: 'ngdialog-theme-default monitorExportDlg',
                    controller: function ($scope, $controller) {
                        $scope.singleExport = true;
                        $scope.hasCheckbox = false;
                        $scope.montypelist = $.extend(true, [], suspectFields);
                        napi.getItem("monitordetail", id).then(function (json) {
                            if (json.ret) {
                                $scope.exportinfo = json.data;
                            } else {
                                alert(json.msg || '获取数据失败', ngDialog);
                            }
                        });
                        $scope.relateSuspect = function () {
                            if ($scope.isrelated) {
                                napi.get("monitordetail/isrelatesuspect", {id: id}).then(function (json) {
                                    $scope.hasCheckbox = json.data.isrelated;
                                });
                            }
                        };
                        $scope.export = function () {
                            $scope.item = {ids: id};
                            window.open('napi/private/monitordetail/exportexcel?' + napi.objToUrlParams($scope.item));
                            $scope.eventLevelResult = [];
                            $scope.closeThisDialog();
                        }
                    }
                });
            }

            $scope.opt = {
                dlgClass: "monitorDlg",
                batch: [{
                    command: 'unfavorite',
                    key: 'id',
                    name: '批量撤销'
                }, {
                    command: 'favorite',
                    key: 'id',
                    name: '批量恢复'
                }, {
                    command: 'export',
                    key: 'id',
                    name: '批量导出'
                }],
                onEdit: function (scope) {
                    scope.singleEdit = true;
                    scope.updateFileType = function (type) {
                        scope.keywordType = type;
                    };

                    scope.keywordType = 'text';
                    setTimeout(function () {
                        var select = document.getElementById('service-multi-select');
                        var serviceList = scope.item.servicecode.split(',');

                        Object.keys($scope.servicelist).forEach(function (key, index) {
                            var option = document.createElement('option');
                            option.value = key;
                            option.textContent = $scope.servicelist[key];
                            if (serviceList.includes(key)) {
                                option.selected = true;
                            }
                            select.appendChild(option);
                        });
                        multi(select, {
                            search_placeholder: '搜索场所...'
                        });
                    }, 50);

                    scope.inputCheck = function () {
                        if (scope.keywordType === 'file' || !scope.isAddItem) return false;

                        switch (scope.item.montypeval) {
                            case 202:
                                return !scope.item.monkey.match(/^\d{11}(\n\d{11})*$/ig);  //*$表示\n后d{11}可多次
                            case 101:
                                return !scope.item.monkey.match(/^(\d{18}|\d{17}x)(\n(\d{18}|\d{17}x))*$/ig);
                            default:
                                return false;
                        }
                    }
                },
                beforeSubmit: function (item, scope) {
                    var select = document.getElementById('service-multi-select');
                    var options = Array.from(select.selectedOptions);

                    if (options.some(function (item) {
                            return item.value === '00000';
                        }) && options.length > 1) {
                        alert("“全黄浦区”不能与其他场所共存！", ngDialog);
                        return true;
                    }

                    if (options.length <= 0) {
                        alert("必须选择布控场所！", ngDialog);
                        return true;
                    }

                    item.servicecode = options.map(function (item) {
                        return item.value;
                    }).join(',');

                    // return true;
                }
            };
            $scope.updateIsValid = function (id, isValid) {
                var msg = isValid == 1 ? "确认撤销?" : "确认恢复?";
                confirm(msg, ngDialog, function () {
                    napi.rmItem($scope.listName, {id: id, isvalid: 1 - isValid}).then(function (json) {
                        if (json) {
                            alert(json.msg, ngDialog);
                        }
                        $scope.updateListView();
                    });
                });

            };
            $scope.batchOperation = function (bat, data) {
                if (bat.command === 'export') {
                    window.open('napi/private/monitordetail/exportexcel?ids=' + data);
                    return false;
                }
                return true;
            };
            $scope.flag = false;
            $scope.detailTemplate = myViewDir + 'dlg/monitorDlg.html';
            $controller("baseListTableCtrl", {$scope: $scope});
            $scope.listTable.thead = ['布控名称', '线索', '线索类别', '布控时间(起始)', '布控时间(结束)', '布控场所', '操作'];
        }
    ]);
});