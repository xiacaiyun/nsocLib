define(function (require) {
    'use strict';
    var app = require("nApp");
    app.controller("suspectListCtrl", [
        '$scope', 'ngDialog', '$controller', 'napi', '$timeout',
        function ($scope, ngDialog, $controller, napi, $timeout) {

            $scope.calcPerPage = 10;
            $scope.name = "库录入";
            $scope.HideCheckBox = false;
            $scope.listName = "suspect";
            var infoid = napi.getUrlParams().id;
            var keyword = napi.getUrlParams().keyword;
            $scope.listSearch = {
                infoid: infoid,
                keyword: keyword
            };
            $scope.opt = {
                dlgClass: "suspectDlg",
                batch: [{
                    command: 'delete',
                    key: 'id',
                    name: '勾选删除'
                }, {
                    command: 'export',
                    key: 'id',
                    name: '批量导出'
                }],
                afterGetList: function (data) {
                    data.forEach(function (row) {
                        row.other = JSON.parse(row.other || '{}');
                    });
                }
            };

            var scope = $scope;

            $scope.batchOperation = function (bat, data) {
                if (bat.command === 'export') {
                    window.open('napi/private/suspect/exportexcel?ids=' + data);
                    return false;
                }
                return true;
            };

            $scope.seeDetail = function (e) {
                var tr = e.currentTarget.parentNode.parentNode.nextElementSibling;
                $(tr).toggle();
            };

            $scope.detailTemplate = myViewDir + 'dlg/suspectDlg.html';
            $controller("baseListTableCtrl", {$scope: $scope});
            $controller("mainCtrl", {$scope: $scope});
            $scope.listTable.thead = ['布控名称', '姓名', '证件号', '手机号', 'MAC号', '微信群号', '微信号', '微信ID', 'QQ号', '操作'];
        }
    ]);
});