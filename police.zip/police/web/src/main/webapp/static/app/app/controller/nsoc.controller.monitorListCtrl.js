define(function (require) {
    'use strict';
    var app = require("nApp");
    app.controller("monitorListCtrl", [
        '$scope', 'ngDialog', '$controller', 'napi',
        function ($scope, ngDialog, $controller, napi) {

            $scope.searchupdateListView = function () {
                $scope.flag = true;
                $scope.updateListView();
            };

            $scope.calcPerPage = 10;
            $scope.name = "布控管理";
            $scope.HideCheckBox = false;
            $scope.listName = "monitor";

            napi.getList('common/montypeenum').then(function (json) {
                if (json.ret) {
                    $scope.montypelist = json.data;
                } else {
                    alert(json.msg || '获取montypelist数据失败', ngDialog);
                }
            });
            napi.getList('monitor/namelist').then(function (json) {
                if (json.ret) {
                    $scope.monitorNameList = json.data;
                } else {
                    alert(json.msg || '获取montypelist数据失败', ngDialog);
                }
            });
            var scope = $scope;
            $scope.selectNames = function () {
                ngDialog.open({
                    template: myViewDir + 'dlg/monitorNameDlg.html',
                    className: 'ngdialog-theme-default',
                    controller: function ($scope) {
                        $scope.title = '选择布控名称';
                        $scope.detail = '布控名称';
                        setTimeout(function () {
                            var select = document.getElementById('name-multi-select');
                            var nameList = scope.monitorNameList;
                            var selectedList = (scope.listSearch.nameIDList || '').split(',');
                            nameList.forEach(function (value) {
                                var option = document.createElement('option');
                                option.value = value;
                                option.textContent = value;
                                if (selectedList.includes(value)) {
                                    option.selected = true;
                                }
                                select.appendChild(option);
                            });
                            multi(select, {
                                search_placeholder: '搜索布控名称...'
                            });
                        }, 50);
                        $scope.emptyChecked = function () {
                            var selected = document.getElementById('name-multi-select').nextElementSibling.querySelector('.selected-wrapper');
                            while (selected.childElementCount) {
                                selected.children[0].click();
                            }
                        };

                        $scope.itemSubmit = function () {
                            var select = document.getElementById('name-multi-select');
                            scope.listSearch.nameIDList = Array.from(select.selectedOptions).map(function (opt) {
                                return opt.value;
                            }).toString();
                            $scope.closeThisDialog();
                        }
                    }
                });
            };

            napi.getList('place/placedict').then(function (json) {
                if (json.ret) {
                    $scope.servicelist = json.data;
                } else {
                    alert(json.msg || '获取servicelist数据失败', ngDialog);
                }
            });


            $scope.export = function (name) {
                ngDialog.open({
                    template: myViewDir + 'dlg/monitorExportDlg.html?t=12312',
                    className: 'ngdialog-theme-default monitorExportDlg',
                    controller: function ($scope, $controller) {
                        $scope.hasCheckbox = false;
                        $scope.montypelist = $.extend(true, [], suspectFields);
                        napi.get("monitor/get", {name: name}).then(function (json) {
                            if (json.ret) {
                                $scope.exportinfo = json.data;
                            } else {
                                alert(json.msg || '获取数据失败', ngDialog);
                            }
                        });
                        $scope.relateSuspect = function () {
                            if ($scope.isrelated) {
                                napi.get("monitor/isrelatesuspect", {name: name}).then(function (json) {
                                    $scope.hasCheckbox = json.data.isrelated;
                                });
                            }
                        };
                        $scope.export = function () {
                            $scope.item = {name: name};
                            window.open('napi/private/monitor/exportexcels?' + napi.objToUrlParams($scope.item));
                            $scope.eventLevelResult = [];
                            $scope.closeThisDialog();
                        }
                    }
                });
            }

            $scope.opt = {
                dlgClass: "monitorDlg",
                batch: [{
                    command: 'unfavorite',
                    key: 'name',
                    name: '批量撤销'
                }, {
                    command: 'favorite',
                    key: 'name',
                    name: '批量恢复'
                }, {
                    command: 'export',
                    key: 'name',
                    name: '批量导出'
                }],
                afterGetList: function (data, json) {
                    $scope.monkey_total = data.monkey_total;
                    $scope.monname_total = data.monname_total;
                    json.data = json.data.result_list;
                },
                onEdit: function (scope) {
                    scope.updateFileType = function (type) {
                        scope.keywordType = type;
                    };
                    if (!scope.isAddItem) {
                        scope.item.oldName = scope.item.name;
                    }
                    scope.keywordType = 'text';
                    setTimeout(function () {
                        var select = document.getElementById('service-multi-select');
                        var serviceList = scope.item.servicecode.split(',');

                        Object.keys($scope.servicelist).forEach(function (key, index) {
                            var option = document.createElement('option');
                            option.value = key;
                            option.textContent = $scope.servicelist[key];
                            if (serviceList.includes(key)) {
                                option.selected = true;
                            }
                            select.appendChild(option);
                        });
                        multi(select, {
                            search_placeholder: '搜索场所...'
                        });
                    }, 50);
                    scope.inputCheck = function () {
                        if (scope.keywordType === 'file' || !scope.isAddItem) return false;

                        switch (scope.item.montypeval) {
                            case 202:
                                return !scope.item.monkey.match(/^\d{11}(\n\d{11})*$/ig);  //*$表示\n后d{11}可多次
                            case 101:
                                return !scope.item.monkey.match(/^(\d{18}|\d{17}x)(\n(\d{18}|\d{17}x))*$/ig);
                            default:
                                return false;
                        }
                    }
                },
                beforeSubmit: function (item, scope) {
                    var select = document.getElementById('service-multi-select');
                    var options = Array.from(select.selectedOptions);

                    if (options.some(function (item) {
                            return item.value === '00000';
                        }) && options.length > 1) {
                        alert("“全黄浦区”不能与其他场所共存！", ngDialog);
                        return true;
                    }

                    if (options.length <= 0) {
                        alert("必须选择布控场所！", ngDialog);
                        return true;
                    }

                    item.servicecode = options.map(function (item) {
                        return item.value;
                    }).join(',');

                    var data = new FormData();
                    for (var key in item) {
                        if (item.hasOwnProperty(key)) data.set(key, item[key]);
                    }
                    if (scope.isAddItem) {
                        data.delete("id");
                    }
                    if (scope.keywordType === 'file') {
                        var fileInput = document.getElementById('upload-file-monitor');
                        if (fileInput.files.length === 0) {
                            alert("必须选择上传文件！", ngDialog);
                            return true;
                        }
                        data.set('files', fileInput.files[0]);
                        data.delete("monkey");
                    }

                    (function postForm(force) {
                        data.set('force', force || false);
                        $.ajax({
                            url: 'napi/private/monitor/update',
                            type: 'POST',
                            data: data,
                            contentType: false,
                            processData: false,
                            xhrFields: {withCredentials: true},
                            success: function (json) {
                                if (json.ret) {
                                    alert(json.msg, ngDialog);
                                    scope.closeThisDialog();
                                    $scope.updateListView();
                                } else {
                                    if (json.msg === '重复的布控名，是否要合并？') {
                                        confirm(json.msg, ngDialog, function () {
                                            postForm(true);
                                        });
                                    } else if (json.msg === '线索不一致，不能合并！') {
                                        alert(json.msg || '操作失败', ngDialog);
                                    } else {
                                        alert(json.msg || '操作失败', ngDialog);
                                    }

                                }
                            },
                            error: function () {
                                alert('操作失败', ngDialog);
                            }
                        });
                    })();

                    return true;
                }
            };
            $scope.updateIsValid = function (name, isValid) {
                var msg = isValid == 1 ? "确认撤销?" : "确认恢复?";
                confirm(msg, ngDialog, function () {
                    napi.rmItem($scope.listName, {name: name, isvalid: 1 - isValid}).then(function (json) {
                        if (json) {
                            alert(json.msg, ngDialog);
                        }
                        $scope.updateListView();
                    });
                });

            };
            $scope.batchOperation = function (bat, data) {
                if (bat.command === 'export') {
                    window.open('napi/private/monitor/exportexcels?name=' + data);
                    return false;
                }
                return true;
            };
            $scope.flag = false;
            $scope.detailTemplate = myViewDir + 'dlg/monitorDlg.html';
            $controller("baseListTableCtrl", {$scope: $scope});
            $scope.listTable.thead = ['布控名称(线索数量)', '线索类别', '布控起始时间', '布控结束时间', '布控场所', '操作'];
        }
    ]);
});