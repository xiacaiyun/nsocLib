define(function (require) {
    'use strict';
    var app = require("nApp");  //app被定义为AngularJS的对象
    app.controller("monitorRuleListCtrl", [
        '$scope', 'ngDialog', '$controller', 'napi', '$timeout',
        function ($scope, ngDialog, $controller, napi, $timeout) {

            $scope.calcPerPage = 10;
            $scope.name = "规则管理";
            $scope.HideCheckBox = false;
            $scope.listName = "monitorrule";
            napi.getList('common/montypeenum').then(function (json) {
                if (json.ret) {
                    $scope.montypelist = json.data;
                } else {
                    alert(json.msg || '获取montypelist数据失败', ngDialog);
                }
            });
            napi.getList('monitorrule/datacode').then(function (json) {
                if (json.ret) {
                    $scope.dataCodeList = json.data;
                } else {
                    alert(json.msg || '获取dataCodeList数据失败', ngDialog);
                }
            });
            $scope.opt = {
                dlgClass: "monitorRuleDlg",
                batch: [{
                    command: 'delete',
                    key: 'id',
                    name: '勾选删除'
                }],
                onEdit: function ($scope) {
                    $scope.getValue = function (item, flag) {
                        if (flag) return;
                        napi.getItemByQuery("monitorrule/matchvalue", {key: item}).then(function (json) {
                            if (json.ret) {
                                $scope.item.matchvalue = json.data;
                            }
                        });
                    };
                    $scope.dataFileTypeChange = function () {
                        $scope.item.datacode  = "";
                        $scope.item.servicecodefield  = "";
                        $scope.item.timefield  = "";
                        $scope.item.sourcefield  = "";
                        $scope.item.matchfield  = "";
                        $scope.item.matchvalue  = "";
                    };
                    if($scope.isAddItem){
                        $scope.dataFileType = 'select';
                    }else{
                        if($scope.dataCodeList.includes($scope.item.datacode)){
                            $scope.dataFileType = 'select';
                        }else {
                            $scope.dataFileType = 'input';
                        }
                    };
                    $scope.loadFields = function (item, flag) {
                        napi.getList("monitorrule/constant", {objectName: item}).then(function (json) {
                            if (json.ret) {
                                if (!flag) {
                                    $scope.item.servicecodefield = '';
                                    $scope.item.timefield = '';
                                    $scope.item.matchfield = '';
                                    $scope.item.sourcefield = '';
                                }

                                $scope.fields = json.data;
                            }
                        });
                    };
                    $scope.loadFields($scope.item.datacode, true);
                    $scope.getValue($scope.item.montype, true);
                },
                beforeSubmit:function (item) {
                    if(+item.offsetbegin > +item.offsetend){
                        alert("偏移量开始不能大于结束！",ngDialog);
                        return true;
                    }
                }
            };


            $scope.detailTemplate = myViewDir + 'dlg/monitorRuleDlg.html';
            $controller("baseListTableCtrl", {$scope: $scope});
            $controller("mainCtrl", {$scope: $scope});
            $scope.listTable.thead = ['类型', '数据文件', '场所', '时间', '来源', '比较字段', '比较字段值', '偏移量开始', '偏移量结束', '操作'];
        }
    ]);
});