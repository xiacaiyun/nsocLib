CREATE TABLE `db_bizmon`.`po_schedule_log` (
  `id` BIGINT NOT NULL  AUTO_INCREMENT,
  `name` VARCHAR(45) NULL,
  `success` BIT(1) NULL,
  `starttime` DATETIME NULL,
  `endtime` DATETIME NULL,
  `msg` VARCHAR(2000) NULL,
  PRIMARY KEY (`id`));


  --- 2017 9.12   updated by xiacaiyun  start
  CREATE TABLE `po_suspect_info` (
  `id` char(18) NOT NULL,
  `configid` int(11) NOT NULL COMMENT '案件类别(如维稳、吸毒、卖淫、赌博、斗殴、其他)',
  `name` varchar(300) NOT NULL COMMENT '名单名称',
  `createtime` datetime DEFAULT NULL,
  `userid` int(11) DEFAULT NULL,
  `updatetime` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;
SELECT * FROM db_bizmon.po_place;


CREATE TABLE `po_suspect` (
  `id` char(18) NOT NULL,
  `infoid` char(18) NOT NULL,
  `seqno` varchar(20) NOT NULL COMMENT '序号',
  `username` varchar(45) NOT NULL COMMENT '姓名',
  `pid` char(20) DEFAULT NULL COMMENT '证件号',
  `mobile` varchar(20) DEFAULT NULL COMMENT '手机号',
  `mac` varchar(18) DEFAULT NULL COMMENT 'MAC号',
  `wxgroupid` varchar(45) DEFAULT NULL COMMENT '微信群号',
  `wx` varchar(45) DEFAULT NULL COMMENT '微信号',
  `wxid` varchar(45) DEFAULT NULL COMMENT '微信ID',
  `qq` varchar(45) DEFAULT NULL COMMENT 'QQ号',
  `other` json DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

CREATE TABLE `po_config` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `detail` varchar(100) NOT NULL COMMENT '案件类别(维安,卖淫,嫖娼,赌博,吸毒)',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8;

  --- 2017 9.12   updated by xiacaiyun  end