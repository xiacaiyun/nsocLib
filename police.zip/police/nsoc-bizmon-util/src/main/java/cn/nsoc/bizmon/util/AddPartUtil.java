package cn.nsoc.bizmon.util;
import java.io.IOException;
import java.io.InputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Properties;
import java.util.Set;

import org.apache.log4j.Logger;


public class AddPartUtil {
	private static final Logger logger = Logger.getLogger(AddPartUtil.class);

	public static void main(String[] args) throws ClassNotFoundException {
		if (args.length < 2) {
			System.out.println("commad like: AddPartUtil 2017 7 [12]");
			System.exit(-1);
		}
		String year = args[0];
		int start = Integer.parseInt(args[1]);
		int end = start;
		if (args.length == 3) {
			end = Integer.parseInt(args[2]);
		}
		if (start < 1 || start > 12 || end < 1 || end > 12 || start > end) {
			System.out.println("month is illegal");
			System.exit(-1);
		}
		List<String> parts = new ArrayList<>();
		for (int i = start; i <= end; i++) {
			parts.add(String.format("%s%02d", year, i));
		}
		
		//load properties
		InputStream in = AddPartUtil.class.getClassLoader().getResourceAsStream("conf.properties");
		Properties conf = new Properties();
		try {
			conf.load(in);
		} catch (IOException e) {
			logger.error("loading properties error", e);
			System.exit(-1);
		}
		
		//db init
		Class.forName(conf.getProperty("driver"));
		Connection conn = null;
		try {
			conn = DriverManager.getConnection(conf.getProperty("url"), conf.getProperty("username"),
					conf.getProperty("password"));
		} catch (SQLException e) {
			logger.error("hive connect error", e);
			System.exit(-1);
		}

		
		//execute
		Statement stmt = null;
		ResultSet res = null;
		String[] tables = conf.getProperty("tables").split(",");
		for (String table : tables) {
			Set<String> exists = new HashSet<>();
			try {
				stmt = conn.createStatement();
				String sql = String.format("show partitions %s", table);
				res = stmt.executeQuery(sql);
				while (res.next()) {
					String result = res.getString(1);
					exists.add(result.substring(result.indexOf('=') + 1));
				}
				for (String part : parts) {
					if (exists.contains(part))
						continue;
					sql = String.format("alter table %s add partition (pvday='%s')", table, part);
					stmt.execute(sql);
				}
				sql = String.format("show partitions %s", table);
				res = stmt.executeQuery(sql);
				while (res.next()) {
					System.out.println(String.format("Added partitions: %s", res.getString(1)));
				}
			} catch (SQLException e) {
				logger.error("hive db error", e);
				System.exit(-1);
			} finally {
				if (conn != null){
					try {
						conn.close();
					} catch (SQLException e) {
						logger.error("hive db error", e);
					}
				}
			}
		}
	}

}
