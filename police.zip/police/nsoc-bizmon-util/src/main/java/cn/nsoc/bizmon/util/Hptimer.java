package cn.nsoc.bizmon.util;

import java.time.Duration;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.HashMap;
import java.util.Map;

public class Hptimer {
    public static final LocalDateTime BASE_DT = LocalDateTime.of(1970, 1, 1, 8, 0, 0);
    // public static final DateTimeFormatter DTF =
    // DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm");
    public static final DateTimeFormatter SDTF = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
    public static final int SECONDS_OF_DAY = 3600 * 24;

    private Hptimer() {}

    public static boolean isNdayBefore(long seconds, int days) {
        return Duration.between(BASE_DT.plusSeconds(seconds), LocalDateTime.now())
                .getSeconds() > SECONDS_OF_DAY * days;
    }

    public static long nowSeconds() {
        return Duration.between(BASE_DT, LocalDateTime.now()).getSeconds();
    }

    public static long toSeconds(String timeStr) {
        LocalDateTime time = LocalDateTime.parse(timeStr, SDTF);
        return Duration.between(BASE_DT, time).getSeconds();

    }

    public static String format(long seconds) {
        if (seconds == 0) {
            return "";
        }
        return BASE_DT.plusSeconds(seconds).format(SDTF);
    }

}
