package cn.nsoc.bizmon.util;

import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

public class RSHelper {
	
	public static Map<String, Object> toDict(ResultSet res) throws SQLException {
		Map<String, Object> vals = new HashMap<>();
		ResultSetMetaData rsMeta = res.getMetaData();
		int colSize = rsMeta.getColumnCount();
		for (int colIndex = 1; colIndex <= colSize; ++colIndex) {
			String fdText = rsMeta.getColumnLabel(colIndex);
			String fdClsType = rsMeta.getColumnClassName(colIndex);
			if (fdClsType.compareToIgnoreCase(String.class.getName()) == 0) {
				String val = res.getString(colIndex);
				vals.put(fdText, val);
				if ("array".equals(rsMeta.getColumnTypeName(colIndex))) {
					Gson gson = new Gson();
					vals.put(fdText, gson.fromJson(val, new TypeToken<List<String>>() {
					}.getType()));
				}
			} else if (fdClsType.compareToIgnoreCase(Integer.class.getName()) == 0) {
				vals.put(fdText, res.getInt(colIndex));
			} else if (fdClsType.compareToIgnoreCase(Long.class.getName()) == 0) {
				vals.put(fdText, res.getLong(colIndex));
			} else if (fdClsType.compareToIgnoreCase(Double.class.getName()) == 0) {
				vals.put(fdText, res.getDouble(colIndex));
			}
		}
		return vals;
	}
}
