package cn.nsoc.bizmon.entity.api;

import java.util.List;
import java.util.Map;

public class DetailResponse {
	String name;
	String pid;
	String mobile;
	String mac;
	List<String> icons;
	List<Map<String, String>> virtuals;
	
	
	public DetailResponse(String name, String pid, String mobile) {
		super();
		this.name = name;
		this.pid = pid;
		this.mobile = mobile;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getPid() {
		return pid;
	}
	public void setPid(String pid) {
		this.pid = pid;
	}
	public String getMobile() {
		return mobile;
	}
	public void setMobile(String mobile) {
		this.mobile = mobile;
	}
	public String getMac() {
		return mac;
	}
	public void setMac(String mac) {
		this.mac = mac;
	}
	public List<String> getIcons() {
		return icons;
	}
	public void setIcons(List<String> icons) {
		this.icons = icons;
	}
	public List<Map<String, String>> getVirtuals() {
		return virtuals;
	}
	public void setVirtuals(List<Map<String, String>> virtuals) {
		this.virtuals = virtuals;
	}
	
}
