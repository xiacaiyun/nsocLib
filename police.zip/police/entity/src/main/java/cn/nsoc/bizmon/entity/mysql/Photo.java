package cn.nsoc.bizmon.entity.mysql;

import cn.nsoc.common.storer.EntityCollection;
import cn.nsoc.common.storer.EntityQuery;
import cn.nsoc.common.storer.annotation.DbField;
import cn.nsoc.common.storer.annotation.DbQuery;
import cn.nsoc.common.storer.annotation.DbTable;
import cn.nsoc.common.storer.annotation.QueryOperator;

import java.time.LocalDateTime;

/**
 * Created by Carol on 2017/9/7.
 */
public class Photo {
    @DbTable(name = "po_photo")
    public static class Entity{
        @DbField(isKey = true, isAutoIncrement = false)
        private String id;
        private String name;
        private String src;
        private String username;
        private String pid;
        private LocalDateTime time;


        public String getId() {
            return id;
        }

        public void setId(String id) {
            this.id = id;
        }

        public String getName() {
            return name;
        }

        public void setName(String name) {
            this.name = name;
        }

        public String getSrc() {
            return src;
        }

        public void setSrc(String src) {
            this.src = src;
        }

        public String getUsername() {
            return username;
        }

        public void setUsername(String username) {
            this.username = username;
        }

        public String getPid() {
            return pid;
        }

        public void setPid(String pid) {
            this.pid = pid;
        }

        public LocalDateTime getTime() {
            return time;
        }

        public void setTime(LocalDateTime time) {
            this.time = time;
        }
    }

    public static class Coll extends EntityCollection<Entity,Query> {
        public Coll() {
            super(Photo.Entity.class, Query.class);
        }

        public Coll(Query query) {
            this();
            this.setQuery(query);
        }
        public Entity findByPid(String pid) {
            return this.stream().filter(l -> l.getPid().equalsIgnoreCase(pid)).findFirst().orElse(null);
        }
    }

    public static class Query extends EntityQuery {
        private String id;
        private String name;
        private String pid;
        public String getId() { return id; }

        public enum OrderBy{
            time__desc;
        }
        public void setId(String id) { this.id = id; }

        public String getName() {
            return name;
        }

        public void setName(String name) {
            this.name = name;
        }

        public String getPid() {
            return pid;
        }

        public void setPid(String pid) {
            this.pid = pid;
        }

    }






}
