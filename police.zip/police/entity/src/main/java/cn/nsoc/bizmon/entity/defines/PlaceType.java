package cn.nsoc.bizmon.entity.defines;

/**
 * Created by Administrator on 2017/7/10.
 */
public enum PlaceType {
    CYBER(1,"网吧"),
    HOTEL(2,"宾馆"),
    WIFI(3,"无线WIFI"),
    SNIFF(4,"终端采集");

    private final int val;
    private final String des;

    private PlaceType(int val,String des) {
        this.val = val;
        this.des = des;
    }

    public int getVal() {
        return val;
    }
    public String getDes() { return des;}

    public static PlaceType getByVal(int val, PlaceType defaultItem) {
        PlaceType[] var2 = values();
        int var3 = var2.length;

        for (int var4 = 0; var4 < var3; ++var4) {
            PlaceType iter = var2[var4];
            if (iter.getVal() == val) {
                return iter;
            }
        }

        return defaultItem;
    }
}
