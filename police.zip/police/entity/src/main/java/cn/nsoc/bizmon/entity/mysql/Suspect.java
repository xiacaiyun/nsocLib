package cn.nsoc.bizmon.entity.mysql;

import cn.nsoc.bizmon.entity.defines.MonType;
import cn.nsoc.common.storer.EntityCollection;
import cn.nsoc.common.storer.EntityQuery;
import cn.nsoc.common.storer.annotation.DbField;
import cn.nsoc.common.storer.annotation.DbQuery;
import cn.nsoc.common.storer.annotation.DbTable;
import cn.nsoc.common.storer.annotation.QueryOperator;
import cn.nsoc.common.storer.entity.QueryMap;
import org.apache.commons.lang3.tuple.ImmutablePair;

import java.math.BigDecimal;
import java.util.List;
import java.util.stream.Collectors;

public class Suspect {
    @DbTable(name = "po_suspect")
    public static class Entity {
        @DbField(isKey = true, isAutoIncrement = false)
        private String id;
        private String infoid;
        private String seqno;
        private String username;
        private String pid;
        private String mobile;
        private String mac;
        private String wxgroupid;
        private String wx;
        private String wxid;
        private String qq;
        private String other;

        @DbField(isRequired = false)
        public int count;


        @Override
        public String toString() {
            return getSeqno() + getPid() + getUsername() + getOther() + getMobile()
                    + getWxgroupid() + getWx() + getWxid() + getQq() + getMac();
        }

        public String getId() {
            return id;
        }

        public void setId(String id) {
            this.id = id;
        }

        public String getSeqno() {
            return seqno;
        }

        public void setSeqno(String seqno) {
            this.seqno = seqno;
        }


        public String getUsername() {
            return username;
        }

        public void setUsername(String username) {
            this.username = username;
        }

        public String getPid() {
            return pid;
        }

        public void setPid(String pid) {
            this.pid = pid;
        }


        public String getMobile() {
            return mobile;
        }

        public void setMobile(String mobile) {
            this.mobile = mobile;
        }

        public String getMac() {
            return mac;
        }

        public void setMac(String mac) {
            this.mac = mac;
        }

        public String getWxgroupid() {
            return wxgroupid;
        }

        public void setWxgroupid(String wxgroupid) {
            this.wxgroupid = wxgroupid;
        }


        public String getWx() {
            return wx;
        }

        public void setWx(String wx) {
            this.wx = wx;
        }

        public String getWxid() {
            return wxid;
        }

        public void setWxid(String wxid) {
            this.wxid = wxid;
        }

        public String getQq() {
            return qq;
        }

        public void setQq(String qq) {
            this.qq = qq;
        }


        public String getInfoid() {
            return infoid;
        }

        public void setInfoid(String infoid) {
            this.infoid = infoid;
        }

        public String getOther() {
            return other;
        }

        public void setOther(String other) {
            this.other = other;
        }
    }

    @SuppressWarnings("serial")
    public static class Coll extends EntityCollection<Entity, Query>{
        public Coll() {
            super(Entity.class, Query.class);
        }

        public Coll(Query query) {
            this();
            this.setQuery(query);
        }

        public Entity findById(String suspectid) {
            return this.stream().filter(l -> l.getId().equalsIgnoreCase(suspectid)).findFirst().orElse(null);
        }

        public Coll findRelated(MonType type, String monkey) {
            if (type != null) {
                switch (type) {
                    case PID:
                        return this.stream().filter(l -> l.getPid().contains(monkey)).collect(Collectors.toCollection(Coll::new));
                    case USERNAME:
                        return this.stream().filter(l -> l.getUsername().equalsIgnoreCase(monkey)).collect(Collectors.toCollection(Coll::new));
                    case MOBILE:
                        return this.stream().filter(l -> l.getMobile().contains(monkey)).collect(Collectors.toCollection(Coll::new));
                    case WXGROUPID:
                        return this.stream().filter(l -> l.getWxgroupid().equalsIgnoreCase(monkey)).collect(Collectors.toCollection(Coll::new));
                    case WXID:
                        return this.stream().filter(l -> l.getWxid().equalsIgnoreCase(monkey)).collect(Collectors.toCollection(Coll::new));
                    case WX:
                        return this.stream().filter(l -> l.getWx().equalsIgnoreCase(monkey)).collect(Collectors.toCollection(Coll::new));
                    case QQ:
                        return this.stream().filter(l -> l.getQq().equalsIgnoreCase(monkey)).collect(Collectors.toCollection(Coll::new));
                    case MAC:
                        return this.stream().filter(l -> l.getMac().contains(monkey)).collect(Collectors.toCollection(Coll::new));
                    default:
                        break;
                }
            }
            return new Coll();


        }


    }

    public static class Query extends EntityQuery {
        @DbQuery(Operator = QueryOperator.In, valueType = String.class)
        private List<String> idIDList;

        @DbQuery(Operator = QueryOperator.In, valueType = String.class)
        private List<String> infoidIDList;

        private String id;
        private String infoid;


        @DbQuery(isJsonType = true)
        private QueryMap other;

        public String getId() {
            return id;
        }

        public void setId(String id) {
            this.id = id;
        }

        @DbQuery(Operator = QueryOperator.Like,valueType = String.class)
        private String mobile;
        @DbQuery(Operator = QueryOperator.Like,valueType = String.class)
        private String pid;
        @DbQuery(Operator = QueryOperator.Like,valueType = String.class)
        private String mac;
        @DbQuery(Operator = QueryOperator.Equal,valueType = String.class)
        private String username;
        @DbQuery(Operator = QueryOperator.Equal,valueType = String.class)
        private String wxgroupid;
        @DbQuery(Operator = QueryOperator.Equal,valueType = String.class)
        private String wx;
        @DbQuery(Operator = QueryOperator.Equal,valueType = String.class)
        private String wxid;
        @DbQuery(Operator = QueryOperator.Equal,valueType = String.class)
        private String qq;

        public List<String> getIdIDList() {
            return idIDList;
        }

        public void setIdIDList(List<String> idIDList) {
            this.idIDList = idIDList;
        }

        public String getMobile() {
            return mobile;
        }

        public void setMobile(String mobile) {
            this.mobile = mobile;
        }

        public String getPid() {
            return pid;
        }

        public void setPid(String pid) {
            this.pid = pid;
        }

        public String getMac() {
            return mac;
        }

        public void setMac(String mac) {
            this.mac = mac;
        }

        public String getUsername() {
            return username;
        }

        public void setUsername(String username) {
            this.username = username;
        }

        public String getWxgroupid() {
            return wxgroupid;
        }

        public void setWxgroupid(String wxgroupid) {
            this.wxgroupid = wxgroupid;
        }

        public String getWx() {
            return wx;
        }

        public void setWx(String wx) {
            this.wx = wx;
        }

        public String getWxid() {
            return wxid;
        }

        public void setWxid(String wxid) {
            this.wxid = wxid;
        }

        public String getQq() {
            return qq;
        }

        public void setQq(String qq) {
            this.qq = qq;
        }

        public String getInfoid() {
            return infoid;
        }

        public void setInfoid(String infoid) {
            this.infoid = infoid;
        }

        public QueryMap getOther() {
            return other;
        }

        public void setOther(QueryMap other) {
            this.other = other;
        }


        public List<String> getInfoidIDList() {
            return infoidIDList;
        }

        public void setInfoidIDList(List<String> infoidIDList) {
            this.infoidIDList = infoidIDList;
        }
    }

    public enum OrderBy {
        seqno
    }
    public enum GroupBy {
        INFOID
    }

}
