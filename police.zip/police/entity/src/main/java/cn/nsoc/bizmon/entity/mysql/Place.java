package cn.nsoc.bizmon.entity.mysql;

import cn.nsoc.common.storer.EntityCollection;
import cn.nsoc.common.storer.EntityQuery;
import cn.nsoc.common.storer.annotation.DbField;
import cn.nsoc.common.storer.annotation.DbQuery;
import cn.nsoc.common.storer.annotation.DbTable;
import cn.nsoc.common.storer.annotation.QueryOperator;

import java.time.LocalDateTime;
import java.util.List;

public class Place {
	@DbTable(name = "po_place")
	public static class Entity {
		@DbField(isKey = true,isAutoIncrement = false)
		private String servicecode;
		private String servicename;
		private String servicetype;
		private String area;
		private String vertify;
		private String recordnumber;
		private String address;
		private String email;
		private String name;
		private String contact;
		private String cardtype;
		private String identity;
		private String management;
		private String policename;
		private String practicable;
		private String orgcode;
		private String orgname;
		private String multiple;
		private String property;
		private LocalDateTime createtime;
		private String ip;
		private String policecode;
		private String lng;
		private String lat;
		private String starttime;
		private String stoptime;
		private int type;
		private LocalDateTime updatetime;
		private int deleted;

		@DbField(isRequired = false)
		public long devicecount;

		public long getDevicecount() {
			return devicecount;
		}

		@DbField(isRequired = false)
		public long placecount;

		public void setDevicecount(long devicecount) {
			this.devicecount = devicecount;
		}

		public long getPlacecount() {
			return placecount;
		}

		public void setPlacecount(long placecount) {
			this.placecount = placecount;
		}

		public String getServicecode() {
			return servicecode;
		}

		public void setServicecode(String servicecode) {
			this.servicecode = servicecode;
		}

		public String getServicename() {
			return servicename;
		}

		public void setServicename(String servicename) {
			this.servicename = servicename;
		}

		public String getServicetype() {
			return servicetype;
		}

		public void setServicetype(String servicetype) {
			this.servicetype = servicetype;
		}

		public String getArea() {
			return area;
		}

		public void setArea(String area) {
			this.area = area;
		}

		public String getVertify() {
			return vertify;
		}

		public void setVertify(String vertify) {
			this.vertify = vertify;
		}

		public String getRecordnumber() {
			return recordnumber;
		}

		public void setRecordnumber(String recordnumber) {
			this.recordnumber = recordnumber;
		}

		public String getAddress() {
			return address;
		}

		public void setAddress(String address) {
			this.address = address;
		}

		public String getEmail() {
			return email;
		}

		public void setEmail(String email) {
			this.email = email;
		}

		public String getName() {
			return name;
		}

		public void setName(String name) {
			this.name = name;
		}

		public String getContact() {
			return contact;
		}

		public void setContact(String contact) {
			this.contact = contact;
		}

		public String getCardtype() {
			return cardtype;
		}

		public void setCardtype(String cardtype) {
			this.cardtype = cardtype;
		}

		public String getIdentity() {
			return identity;
		}

		public void setIdentity(String identity) {
			this.identity = identity;
		}

		public String getManagement() {
			return management;
		}

		public void setManagement(String management) {
			this.management = management;
		}

		public String getPolicename() {
			return policename;
		}

		public void setPolicename(String policename) {
			this.policename = policename;
		}

		public String getPracticable() {
			return practicable;
		}

		public void setPracticable(String practicable) {
			this.practicable = practicable;
		}

		public String getOrgcode() {
			return orgcode;
		}

		public void setOrgcode(String orgcode) {
			this.orgcode = orgcode;
		}

		public String getOrgname() {
			return orgname;
		}

		public void setOrgname(String orgname) {
			this.orgname = orgname;
		}

		public String getMultiple() {
			return multiple;
		}

		public void setMultiple(String multiple) {
			this.multiple = multiple;
		}

		public String getProperty() {
			return property;
		}

		public void setProperty(String property) {
			this.property = property;
		}

		public LocalDateTime getCreatetime() {
			return createtime;
		}

		public void setCreatetime(LocalDateTime createtime) {
			this.createtime = createtime;
		}

		public String getIp() {
			return ip;
		}

		public void setIp(String ip) {
			this.ip = ip;
		}

		public String getPolicecode() {
			return policecode;
		}

		public void setPolicecode(String policecode) {
			this.policecode = policecode;
		}

		public String getLng() {
			return lng;
		}

		public void setLng(String lng) {
			this.lng = lng;
		}

		public String getLat() {
			return lat;
		}

		public void setLat(String lat) {
			this.lat = lat;
		}

		public String getStarttime() {
			return starttime;
		}

		public void setStarttime(String starttime) {
			this.starttime = starttime;
		}

		public String getStoptime() {
			return stoptime;
		}

		public void setStoptime(String stoptime) {
			this.stoptime = stoptime;
		}

		public int getType() {
			return type;
		}

		public void setType(int type) {
			this.type = type;
		}

		public LocalDateTime getUpdatetime() {
			return updatetime;
		}

		public void setUpdatetime(LocalDateTime updatetime) {
			this.updatetime = updatetime;
		}

		public int getDeleted() {
			return deleted;
		}

		public void setDeleted(int deleted) {
			this.deleted = deleted;
		}
	}

	@SuppressWarnings("serial")
	public static class Coll extends EntityCollection<Place.Entity,Query> {
		public Coll() {
			super(Place.Entity.class,Query.class);
		}

		public Coll(Query query) {
			this();
			this.setQuery(query);
		}
		public Entity find(String servicecode){
			return this.stream().filter(e -> e.getServicecode().equalsIgnoreCase(servicecode)).findFirst().orElse(null);
		}
	}

	public static class Query extends EntityQuery {
		private String servicecode;
		@DbQuery(Operator = QueryOperator.Like,valueType = String.class)
		private String servicename;
		@DbQuery(Operator = QueryOperator.IsOrNotNull,valueType = Boolean.class)
		private Boolean policecodeIsOrNotNull;
		@DbQuery(Operator = QueryOperator.In,valueType = String.class)
		private List<String> policecodeIDList;
		@DbQuery(Operator = QueryOperator.Like,valueType = String.class)
		private String address;

		private String policecode;
		private String servicetype;
		@DbQuery(Operator = QueryOperator.In,valueType = String.class)
		private List<String> orgnameIDList;
		private Integer placestatus;
		
		@DbQuery(Operator = QueryOperator.GreatEqual, valueType = LocalDateTime.class)
		private LocalDateTime Fromupdatetime;
		
		@DbQuery(Operator = QueryOperator.LessEqual, name="updatetime", valueType = Long.class)
		private String expiredTime;
		
		@DbQuery(Operator = QueryOperator.GreatEqual,valueType = Long.class)
		private Long evtime;
		
		@DbQuery(Operator = QueryOperator.In,valueType = String.class)
		private List<String> servicecodeIDList;

		private Integer deleted;

		public String getServicename() {
			return servicename;
		}

		public void setServicename(String servicename) {
			this.servicename = servicename;
		}

		public Boolean getPolicecodeIsOrNotNull() {
			return policecodeIsOrNotNull;
		}

		public void setPolicecodeIsOrNotNull(Boolean policecodeIsOrNotNull) {
			this.policecodeIsOrNotNull = policecodeIsOrNotNull;
		}

		public String getAddress() {
			return address;
		}

		public void setAddress(String address) {
			this.address = address;
		}

		public String getPolicecode() {
			return policecode;
		}

		public void setPolicecode(String policecode) {
			this.policecode = policecode;
		}

		public String getServicetype() {
			return servicetype;
		}

		public void setServicetype(String servicetype) {
			this.servicetype = servicetype;
		}

		public Integer getPlacestatus() {
			return placestatus;
		}

		public void setPlacestatus(Integer placestatus) {
			this.placestatus = placestatus;
		}

		public LocalDateTime getFromupdatetime() {
			return Fromupdatetime;
		}

		public void setFromupdatetime(LocalDateTime fromupdatetime) {
			Fromupdatetime = fromupdatetime;
		}

		public String getExpiredTime() {
			return expiredTime;
		}

		public void setExpiredTime(String expiredTime) {
			this.expiredTime = expiredTime;
		}

		public Long getEvtime() {
			return evtime;
		}

		public void setEvtime(Long evtime) {
			this.evtime = evtime;
		}

		public List<String> getServicecodeIDList() {
			return servicecodeIDList;
		}

		public void setServicecodeIDList(List<String> servicecodeIDList) {
			this.servicecodeIDList = servicecodeIDList;
		}

		public List<String> getPolicecodeIDList() {
			return policecodeIDList;
		}

		public void setPolicecodeIDList(List<String> policecodeIDList) {
			this.policecodeIDList = policecodeIDList;
		}

		public List<String> getOrgnameIDList() {
			return orgnameIDList;
		}

		public void setOrgnameIDList(List<String> orgnameIDList) {
			this.orgnameIDList = orgnameIDList;
		}

		public Integer getDeleted() {
			return deleted;
		}

		public void setDeleted(Integer deleted) {
			this.deleted = deleted;
		}

		public static enum GroupByEnum {
			TYPE,
			SERVICETYPE,
			SERVICECODE;
		}
		public static enum orderByEnum {
			SERVICENAME__ASC
		}
		public String getServicecode() {
			return servicecode;
		}

		public void setServicecode(String servicecode) {
			this.servicecode = servicecode;
		}

	}

}
