package cn.nsoc.bizmon.entity.mysql;

import cn.nsoc.common.storer.EntityCollection;
import cn.nsoc.common.storer.EntityQuery;
import cn.nsoc.common.storer.annotation.DbField;
import cn.nsoc.common.storer.annotation.DbQuery;
import cn.nsoc.common.storer.annotation.DbTable;
import cn.nsoc.common.storer.annotation.QueryOperator;

import java.util.List;

public class PrewarningTrace {
	@DbTable(name = "po_prewarning_trace")
	public static class Entity {
		private Integer montype;
		private String monkey;
		private String suspectid;
		@DbField(isKey = true,isAutoIncrement = false)
		private String monid;
        @DbField(isKey = true, isAutoIncrement = false)
        private long   evtime;
        @DbField(isKey = true, isAutoIncrement = false)
        private String servicecode;
		@DbField(isRequired=false)
		private Integer total; 
		
		public Integer getTotal() {
			return total;
		}

		public void setTotal(Integer total) {
			this.total = total;
		}


		public Integer getMontype() {
			return montype;
		}

		public void setMontype(Integer montype) {
			this.montype = montype;
		}

		public String getMonkey() {
			return monkey;
		}

		public void setMonkey(String monkey) {
			this.monkey = monkey;
		}

		public long getEvtime() {
			return evtime;
		}

		public void setEvtime(long evtime) {
			this.evtime = evtime;
		}

		public String getServicecode() {
			return servicecode;
		}

		public void setServicecode(String servicecode) {
			this.servicecode = servicecode;
		}

		public String getSuspectid() {
			return suspectid;
		}

		public void setSuspectid(String suspectid) {
			this.suspectid = suspectid;
		}

		public String getMonid() {
			return monid;
		}

		public void setMonid(String monid) {
			this.monid = monid;
		}

	}

	@SuppressWarnings("serial")
	public static class Coll extends EntityCollection<PrewarningTrace.Entity,Query> {
		public Coll() {
			super(PrewarningTrace.Entity.class,Query.class);
		}

		public Coll(Query query) {
			this();
			this.setQuery(query);
		}
	}

	public static class Query extends EntityQuery {
		private Integer montype;
		@DbQuery(Operator = QueryOperator.Like,valueType = String.class)
		private String monkey;
		@DbQuery(Operator = QueryOperator.In)
		private List<String> monidIDList;
		private String monid;
		@DbQuery(Operator = QueryOperator.In)
		private List<String> servicecodeIDList;
		@DbQuery(Operator = QueryOperator.GreatEqual)
		private Integer Fromevtime;
		
		@DbQuery(Operator = QueryOperator.SubQuery, express = "exists (select * from po_monitor p where p.id = monid and %s = %s ) ")
		private Integer isValid;


		public List<String> getServicecodeIDList() {
			return servicecodeIDList;
		}

		public void setServicecodeIDList(List<String> servicecodeIDList) {
			this.servicecodeIDList = servicecodeIDList;
		}

		public Integer getMontype() {
			return montype;
		}

		public void setMontype(Integer montype) {
			this.montype = montype;
		}

		public String getMonkey() {
			return monkey;
		}

		public void setMonkey(String monkey) {
			this.monkey = monkey;
		}

		public List<String> getMonidIDList() {
			return monidIDList;
		}

		public void setMonidIDList(List<String> monidIDList) {
			this.monidIDList = monidIDList;
		}

		public String getMonid() {
			return monid;
		}

		public void setMonid(String monid) {
			this.monid = monid;
		}

		public Integer getFromevtime() {
			return Fromevtime;
		}

		public void setFromevtime(Integer fromevtime) {
			Fromevtime = fromevtime;
		}

		public int getIsValid() {
			return isValid;
		}

		public void setIsValid(int isValid) {
			this.isValid = isValid;
		}
		
		
	}

	public  enum OrderByEnum{
		EVTIME__desc;
	}

}
