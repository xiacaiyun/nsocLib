package cn.nsoc.bizmon.entity.mysql;

import cn.nsoc.common.storer.EntityCollection;
import cn.nsoc.common.storer.EntityQuery;
import cn.nsoc.common.storer.annotation.DbField;
import cn.nsoc.common.storer.annotation.DbQuery;
import cn.nsoc.common.storer.annotation.DbTable;
import cn.nsoc.common.storer.annotation.QueryOperator;

import java.time.LocalDateTime;
import java.util.List;

public class Suspectinfo {
	@DbTable(name = "po_suspect_info")
	public static class Entity {
		@DbField(isKey = true,isAutoIncrement = false)
		private String id;
		private int configid;
		private String name;
		private LocalDateTime createtime;
		private LocalDateTime updatetime;
		private int userid;



		public int getConfigid() {
			return configid;
		}

		public void setConfigid(int configid) {
			this.configid = configid;
		}

		public String getName() {
			return name;
		}

		public void setName(String name) {
			this.name = name;
		}

		public String getId() {
			return id;
		}

		public void setId(String id) {
			this.id = id;
		}

		public LocalDateTime getCreatetime() {
			return createtime;
		}

		public void setCreatetime(LocalDateTime createtime) {
			this.createtime = createtime;
		}

		public LocalDateTime getUpdatetime() {
			return updatetime;
		}

		public void setUpdatetime(LocalDateTime updatetime) {
			this.updatetime = updatetime;
		}

		public int getUserid() {
			return userid;
		}

		public void setUserid(int userid) {
			this.userid = userid;
		}
	}

	@SuppressWarnings("serial")
	public static class Coll extends EntityCollection<Entity,Query> {
		public Coll() {
			super(Entity.class,Query.class);
		}

		public Coll(Query query) {
			this();
			this.setQuery(query);
		}

		public Entity find(String id){
			return this.stream().filter(p->p.getId().compareToIgnoreCase(id) == 0).findFirst().orElse(null);
		}

	}

	public static class Query extends EntityQuery {
		private String id;
		private Integer configid;
		@DbQuery(Operator = QueryOperator.Like,valueType = String.class)
		private String name;
		@DbQuery(Operator = QueryOperator.In, valueType = String.class)
		private List<String> idIDList;

		public String getId() {
			return id;
		}

		public void setId(String id) {
			this.id = id;
		}


		public String getName() {
			return name;
		}

		public void setName(String name) {
			this.name = name;
		}

		public Integer getConfigid() {
			return configid;
		}

		public void setConfigid(Integer configid) {
			this.configid = configid;
		}

		public List<String> getIdIDList() {
			return idIDList;
		}

		public void setIdIDList(List<String> idIDList) {
			this.idIDList = idIDList;
		}

		public enum GroupByEnum {
			NAME
		}
		public enum OroupByEnum {
			createtime__desc
		}
	}

}
