package cn.nsoc.bizmon.entity.mysql;

import cn.nsoc.common.storer.EntityCollection;
import cn.nsoc.common.storer.EntityQuery;
import cn.nsoc.common.storer.annotation.DbField;
import cn.nsoc.common.storer.annotation.DbQuery;
import cn.nsoc.common.storer.annotation.DbTable;
import cn.nsoc.common.storer.annotation.QueryOperator;

import java.util.List;
import java.util.stream.Collectors;

public class Devstat {
	@DbTable(name = "po_devstat")
	public static class Entity {
		@DbField(isKey = true,isAutoIncrement = false)
		private String devno;
		@DbField(isKey = true,isAutoIncrement = false)
		private String servicecode;
		private int evtime;
		private int devtype;
		private int payload;
		@DbField(isRequired = false) //不是此表数据库字段，只用作返回
		public Integer devcount;

		public Integer getDevcount() {
			return devcount;
		}

		public void setDevcount(Integer devcount) {
			this.devcount = devcount;
		}

		public String getDevno() {
			return devno;
		}

		public void setDevno(String devno) {
			this.devno = devno;
		}

		public String getServicecode() {
			return servicecode;
		}

		public void setServicecode(String servicecode) {
			this.servicecode = servicecode;
		}

		public int getEvtime() {
			return evtime;
		}

		public void setEvtime(int evtime) {
			this.evtime = evtime;
		}

		public int getDevtype() {
			return devtype;
		}

		public void setDevtype(int devtype) {
			this.devtype = devtype;
		}

		public int getPayload() {
			return payload;
		}

		public void setPayload(int payload) {
			this.payload = payload;
		}

	}

	@SuppressWarnings("serial")
	public static class Coll extends EntityCollection<Devstat.Entity,Query> {
		public Coll() {
			super(Devstat.Entity.class,Query.class);
		}

		public Coll(Query query) {
			this();
			this.setQuery(query);
		}
		public Devstat.Coll findByServiceCode(String serviceCode){
			return this.stream().filter(h->h.getServicecode().compareToIgnoreCase(serviceCode) == 0).distinct().collect(Collectors.toCollection(Devstat.Coll::new));
		}
		public Devstat.Coll find(String no,String sc){
			return this.stream().filter(h->h.getDevno().compareToIgnoreCase(no) == 0
					&& h.getServicecode().compareToIgnoreCase(sc) == 0).distinct().collect(Collectors.toCollection(Devstat.Coll::new));
		}
	}

	public static class Query extends EntityQuery {
		private String devno;
		private String servicecode;
		
		public String getDevno() {
			return devno;
		}

		public void setDevno(String devno) {
			this.devno = devno;
		}

		public String getServicecode() {
			return servicecode;
		}

		public void setServicecode(String servicecode) {
			this.servicecode = servicecode;
		}
		@DbQuery(Operator = QueryOperator.In,valueType = String.class)
		private List<String> servicecodeIDList;

		@DbQuery(Operator = QueryOperator.In,valueType = String.class)
		private List<String> devnoIDList;

		@DbQuery(Operator = QueryOperator.GreatEqual)
		private Integer Fromevtime;
		
		@DbQuery(Operator = QueryOperator.LessEqual, name="evtime")
		private Integer expiredTime;

		public List<String> getServicecodeIDList() {
			return servicecodeIDList;
		}

		public void setServicecodeIDList(List<String> servicecodeIDList) {
			this.servicecodeIDList = servicecodeIDList;
		}

		public Integer getFromevtime() {
			return Fromevtime;
		}

		public void setFromevtime(Integer fromevtime) {
			Fromevtime = fromevtime;
		}

		public Integer getExpiredTime() {
			return expiredTime;
		}

		public void setExpiredTime(Integer expiredTime) {
			this.expiredTime = expiredTime;
		}

		public List<String> getDevnoIDList() {
			return devnoIDList;
		}

		public void setDevnoIDList(List<String> devnoIDList) {
			this.devnoIDList = devnoIDList;
		}


		public enum GroupByEnum {
			SERVICECODE
		}

	}

}
