package cn.nsoc.bizmon.entity.api;

import java.util.Map;
import java.util.Set;

public class Person {
	String id;
	String pid="";
	String name="";
	String icon;
	Set<String> mobiles;
	Set<String> macs;
	Set<Map<String, String>> virtuals;

	
	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getPid() {
		return pid;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public void setPid(String pid) {
		this.pid = pid;
	}


	public String getIcon() {
		return icon;
	}

	public void setIcon(String icon) {
		this.icon = icon;
	}

	public Set<String> getMobiles() {
		return mobiles;
	}

	public void setMobiles(Set<String> mobiles) {
		this.mobiles = mobiles;
	}

	public Set<String> getMacs() {
		return macs;
	}

	public void setMacs(Set<String> macs) {
		this.macs = macs;
	}

	public Set<Map<String, String>> getVirtuals() {
		return virtuals;
	}

	public void setVirtuals(Set<Map<String, String>> virtuals) {
		this.virtuals = virtuals;
	}


}
