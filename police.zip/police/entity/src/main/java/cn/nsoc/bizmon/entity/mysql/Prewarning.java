package cn.nsoc.bizmon.entity.mysql;

import cn.nsoc.common.storer.EntityCollection;
import cn.nsoc.common.storer.EntityQuery;
import cn.nsoc.common.storer.annotation.DbField;
import cn.nsoc.common.storer.annotation.DbQuery;
import cn.nsoc.common.storer.annotation.DbTable;
import cn.nsoc.common.storer.annotation.QueryOperator;

import java.util.List;

public class Prewarning {
	@DbTable(name = "po_prewarning")
	public static class Entity {
		@DbField(isKey = true,isAutoIncrement = false)
		private String auid;
		private int evtime;
		private String servicecode;
		private int montype;
		private String monkey;
		private String suspectid;
		private String monid;
		private int gapbasetime;
		private int firsttime;

		@DbField(isRequired = false)
		private int count;
		
		@DbField(isRequired = false)
		private int scs;

		public String getAuid() {
			return auid;
		}

		public void setAuid(String auid) {
			this.auid = auid;
		}

		public int getEvtime() {
			return evtime;
		}

		public void setEvtime(int evtime) {
			this.evtime = evtime;
		}

		public String getServicecode() {
			return servicecode;
		}

		public void setServicecode(String servicecode) {
			this.servicecode = servicecode;
		}

		public int getMontype() {
			return montype;
		}

		public void setMontype(int montype) {
			this.montype = montype;
		}

		public String getMonkey() {
			return monkey;
		}

		public void setMonkey(String monkey) {
			this.monkey = monkey;
		}

		public String getSuspectid() {
			return suspectid;
		}

		public void setSuspectid(String suspectid) {
			this.suspectid = suspectid;
		}

		public String getMonid() {
			return monid;
		}

		public void setMonid(String monid) {
			this.monid = monid;
		}

		public int getGapbasetime() {
			return gapbasetime;
		}

		public void setGapbasetime(int gapbasetime) {
			this.gapbasetime = gapbasetime;
		}

		public int getFirsttime() {
			return firsttime;
		}

		public void setFirsttime(int firsttime) {
			this.firsttime = firsttime;
		}

		public int getCount() {
			return count;
		}

		public void setCount(int count) {
			this.count = count;
		}

		public int getScs() {
			return scs;
		}

		public void setScs(int scs) {
			this.scs = scs;
		}
		
		
	}

	@SuppressWarnings("serial")
	public static class Coll extends EntityCollection<Prewarning.Entity,Query> {
		public Coll() {
			super(Prewarning.Entity.class,Query.class);
		}

		public Coll(Query query) {
			this();
			this.setQuery(query);
		}

		public Entity find(String id){
			return this.stream().filter(p->p.getAuid().compareToIgnoreCase(id) == 0).findFirst().orElse(null);
		}
	}

	public static class Query extends EntityQuery {
		private String auid;
		private Integer montype;
		@DbQuery(Operator = QueryOperator.Like,valueType = String.class)
		private String monkey;
		@DbQuery(Operator = QueryOperator.In,valueType = String.class)
		private List<String> auidIDList;
		@DbQuery(Operator = QueryOperator.In,valueType = String.class)
		private List<String> monidIDList;
		@DbQuery(Operator = QueryOperator.In,valueType = String.class)
		private List<String> monkeyIDList;
		@DbQuery(Operator = QueryOperator.In,valueType = String.class)
		private List<String> servicecodeIDList;
		private String monid;
		@DbQuery(Operator = QueryOperator.GreatEqual)
		private Integer Fromevtime;
		@DbQuery(Operator = QueryOperator.LessEqual)
		private Integer Toevtime;

		private String name;

		@DbQuery(Operator = QueryOperator.SubQuery, express = "exists (select * from po_monitor p where p.id = monid and %s = %s ) ")
		private Integer isValid;
		
		public String getAuid() {
			return auid;
		}

		public void setAuid(String auid) {
			this.auid = auid;
		}

		public Integer getMontype() {
			return montype;
		}

		public void setMontype(Integer montype) {
			this.montype = montype;
		}

		public String getMonkey() {
			return monkey;
		}

		public void setMonkey(String monkey) {
			this.monkey = monkey;
		}

		public List<String> getAuidIDList() {
			return auidIDList;
		}

		public void setAuidIDList(List<String> auidIDList) {
			this.auidIDList = auidIDList;
		}

		public List<String> getMonidIDList() {
			return monidIDList;
		}

		public void setMonidIDList(List<String> monidIDList) {
			this.monidIDList = monidIDList;
		}

		public String getMonid() {
			return monid;
		}

		public void setMonid(String monid) {
			this.monid = monid;
		}

		public String getName() {
			return name;
		}

		public void setName(String name) {
			this.name = name;
		}

		public Integer getFromevtime() {
			return Fromevtime;
		}

		public void setFromevtime(Integer fromevtime) {
			Fromevtime = fromevtime;
		}

		public Integer getToevtime() {
			return Toevtime;
		}

		public void setToevtime(Integer toevtime) {
			Toevtime = toevtime;
		}

		public int getIsValid() {
			return isValid;
		}

		public void setIsValid(int isValid) {
			this.isValid = isValid;
		}


		public List<String> getMonkeyIDList() {
			return monkeyIDList;
		}

		public void setMonkeyIDList(List<String> monkeyIDList) {
			this.monkeyIDList = monkeyIDList;
		}

		public List<String> getServicecodeIDList() {
			return servicecodeIDList;
		}

		public void setServicecodeIDList(List<String> servicecodeIDList) {
			this.servicecodeIDList = servicecodeIDList;
		}
		
		
	}
	
	public static enum OrderByEnum {
		EVTIME__DESC;
	}

	public static enum GroupByEnum {
		MONID;
	}

}
