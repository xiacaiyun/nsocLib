package cn.nsoc.bizmon.entity.defines;

import java.time.LocalDateTime;

/**
 * Created by Administrator on 2017/7/20.
 */
public class Constants {

    private Constants() {
    }

    public static final int SECONDS_OF_ONE_DAY = 24 * 60 * 60;
    public static final int DEVICE_STATUS_GAP = 24 * 60 * 60;
    public static final String SERVICE_NAME = "全黄浦区";
    public static final String SERVICE_CODE = "00000";
    public static final String ALL_DEVICES = "全部设备";
    public static final String ALL_SERVICES = "全部场所";
    public static final String UPLOAD_ALLOW_EXTS = ".*\\.(csv|xls|xlsx)";
    public static final LocalDateTime UPDATE_TIME = LocalDateTime.of(2017, 8, 18, 0, 0, 0);


    public static class SuspectFields {
        public static final String SEQ_NO = "序号";
        public static final String PID = "证件号";
        public static final String DISTRICT = "区号";
        public static final String USERNAME = "姓名";
        public static final String GENDER = "性别";
        public static final String BORN_PLACE = "户籍地址";
        public static final String RESIDENCE_PLACE = "暂住地";
        public static final String MOBILE = "手机号";
        public static final String MAC = "MAC号";
        public static final String WX_GROUP_ID = "微信群号";
        public static final String WX_GROUP_NAME = "微信群名";
        public static final String WX = "微信号";
        public static final String WX_ID = "微信ID";
        public static final String WX_NAME = "微信名";
        public static final String QQ = "QQ号";
        public static final String NICKNAME = "QQ昵称";
        public static final String QQ_GROUP = "QQ群号";
        public static final String GROUP = "所属群体";
        public static final String GROUP_NICKNAME = "群内昵称";
        public static final String REMARK1 = "备注1";
        public static final String REMARK2 = "备注2";
        public static final String REMARK3 = "备注3";
        public static final String ADDR_BOOK_NAME = "通讯录备注昵称";
        public static final String IMPORTANT_PERSON = "重点人员";
    }

    public static class PlaceFields {
        public static final String POLICENAME = "派出所编码";
        public static final String SERVICCODE = "场所代码";
        public static final String PROPERTY = "场所子类型";
        public static final String ORGNAME = "安全软件厂商编码";

    }


}
