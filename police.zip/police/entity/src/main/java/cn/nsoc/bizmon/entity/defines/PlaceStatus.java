package cn.nsoc.bizmon.entity.defines;

/**
 * Created by Administrator on 2017/7/10.
 */
public enum PlaceStatus {
    INTACT(0,"全部正常"),
    PARTIAL(1,"部分正常"),
    DAMAGED(2,"异常");

    private final int val;
    private final String des;

    private PlaceStatus(int val, String des) {
        this.val = val;
        this.des = des;
    }

    public int getVal() {
        return val;
    }
    public String getDes() { return des;}

    public static PlaceStatus getByVal(int val, PlaceStatus defaultItem) {
        PlaceStatus[] var2 = values();
        int var3 = var2.length;

        for (int var4 = 0; var4 < var3; ++var4) {
            PlaceStatus iter = var2[var4];
            if (iter.getVal() == val) {
                return iter;
            }
        }

        return defaultItem;
    }
}
