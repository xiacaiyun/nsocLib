package cn.nsoc.bizmon.entity.mysql;

import cn.nsoc.common.storer.EntityCollection;
import cn.nsoc.common.storer.EntityQuery;
import cn.nsoc.common.storer.annotation.DbField;
import cn.nsoc.common.storer.annotation.DbTable;

/**
 * Created by Carol on 2017/9/7.
 */
public class Config {
    @DbTable(name = "po_config")
    public static class Entity{
        @DbField(isKey = true, isAutoIncrement = true)
        private int id;
        private String detail;

        public int getId() { return id; }
        public void setId(int id) { this.id = id; }

        public String getDetail() { return detail; }
        public void setDetail(String detail) { this.detail = detail; }

    }

    public static class Coll extends EntityCollection<Entity,Query> {
        public Coll() {
            super(Config.Entity.class, Query.class);
        }

        public Coll(Query query) {
            this();
            this.setQuery(query);
        }
        public Entity findById(int id) { // 查询单条
            return this.stream().filter(l -> l.getId()== id).findFirst().orElse(null);
        }
    }

    public static class Query extends EntityQuery {
        private Integer id;
        public Integer getId() { return id; }
        public void setId(Integer id) { this.id = id; }
    }






}
