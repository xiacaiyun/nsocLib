package cn.nsoc.bizmon.entity.mysql;

import cn.nsoc.common.storer.EntityCollection;
import cn.nsoc.common.storer.EntityQuery;
import cn.nsoc.common.storer.annotation.DbField;
import cn.nsoc.common.storer.annotation.DbTable;

public class MonitorRule {
	@DbTable(name = "po_monitor_rule")
	public static class Entity {
		@DbField(isKey = true,isAutoIncrement = true)
		private int id;
		private int montype;
		private String datacode;
		private String servicecodefield;
		private String timefield;
		private String sourcefield;
		private String matchfield;
		private String matchvalue;
		private Integer offsetbegin;
		private Integer offsetend;

		public int getId() {
			return id;
		}

		public void setId(int id) {
			this.id = id;
		}

		public int getMontype() {
			return montype;
		}

		public void setMontype(int montype) {
			this.montype = montype;
		}

		public String getDatacode() {
			return datacode;
		}

		public void setDatacode(String datacode) {
			this.datacode = datacode;
		}

		public String getServicecodefield() {
			return servicecodefield;
		}

		public void setServicecodefield(String servicecodefield) {
			this.servicecodefield = servicecodefield;
		}

		public String getTimefield() {
			return timefield;
		}

		public void setTimefield(String timefield) {
			this.timefield = timefield;
		}

		public String getSourcefield() {
			return sourcefield;
		}

		public void setSourcefield(String sourcefield) {
			this.sourcefield = sourcefield;
		}

		public String getMatchfield() {
			return matchfield;
		}

		public void setMatchfield(String matchfield) {
			this.matchfield = matchfield;
		}

		public String getMatchvalue() {
			return matchvalue;
		}

		public void setMatchvalue(String matchvalue) {
			this.matchvalue = matchvalue;
		}

		public Integer getOffsetbegin() {
			return offsetbegin;
		}

		public void setOffsetbegin(Integer offsetbegin) {
			this.offsetbegin = offsetbegin;
		}

		public Integer getOffsetend() {
			return offsetend;
		}

		public void setOffsetend(Integer offsetend) {
			this.offsetend = offsetend;
		}
	}

	@SuppressWarnings("serial")
	public static class Coll extends EntityCollection<MonitorRule.Entity,Query> {
		public Coll() {
			super(MonitorRule.Entity.class,Query.class);
		}

		public Coll(Query query) {
			this();
			this.setQuery(query);
		}
	}

	public static class Query extends EntityQuery {
		private Integer id;
		private Integer montype;

		public Integer getId() {
			return id;
		}

		public void setId(Integer id) {
			this.id = id;
		}

		public Integer getMontype() {
			return montype;
		}

		public void setMontype(Integer montype) {
			this.montype = montype;
		}
	}


}
