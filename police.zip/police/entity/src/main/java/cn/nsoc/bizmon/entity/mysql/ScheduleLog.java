package cn.nsoc.bizmon.entity.mysql;

import java.time.LocalDateTime;

import cn.nsoc.common.storer.EntityCollection;
import cn.nsoc.common.storer.EntityQuery;
import cn.nsoc.common.storer.annotation.DbField;
import cn.nsoc.common.storer.annotation.DbTable;

public class ScheduleLog {

	public enum ClearName {
		HOTSTAT, PLACE, WARN, DEVSTAT
	}

	@DbTable(name = "po_schedule_log")
	public static class Entity {
		@DbField(isKey = true, isAutoIncrement = true)
		private long id;
		private ClearName name;
		private boolean success = true;
		private LocalDateTime starttime;
		private LocalDateTime endtime;
		@DbField(isRequired = false)
		private String msg;

		public Entity() {
			super();
		}

		public Entity(ClearName name, LocalDateTime starttime) {
			super();
			this.name = name;
			this.starttime = starttime;
		}

		public long getId() {
			return id;
		}

		public void setId(long id) {
			this.id = id;
		}

		public ClearName getName() {
			return name;
		}

		public void setName(ClearName name) {
			this.name = name;
		}

		public boolean isSuccess() {
			return success;
		}

		public void setSuccess(boolean success) {
			this.success = success;
		}

		public LocalDateTime getStarttime() {
			return starttime;
		}

		public void setStarttime(LocalDateTime starttime) {
			this.starttime = starttime;
		}


		public LocalDateTime getEndtime() {
			return endtime;
		}

		public void setEndtime(LocalDateTime endtime) {
			this.endtime = endtime;
		}

		public String getMsg() {
			return msg;
		}

		public void setMsg(String msg) {
			this.msg = msg;
		}

	}

	@SuppressWarnings("serial")
	public static class Coll extends EntityCollection<ScheduleLog.Entity, Query> {
		public Coll() {
			super(ScheduleLog.Entity.class, Query.class);
		}

		public Coll(Query query) {
			this();
			this.setQuery(query);
		}

	}

	public static class Query extends EntityQuery {
		private long id;

		public long getId() {
			return id;
		}

		public void setId(long id) {
			this.id = id;
		}
		
		
	}


}
