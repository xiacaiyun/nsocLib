package cn.nsoc.bizmon.entity.defines;

import java.util.Arrays;

/**
 * Created by Carol on 2017/7/10.
 */
public enum MonType {
    PID(101, "身份证号"),
    OFFICER(102, "军官证"),
    PASSPORT(103, "护照号"),
    HK(104, "香港回乡证"),
    TW(105, "台胞证"),
    USERNAME(201, "被布控人名"),
    MOBILE(202, "手机号"),
    MAC(301, "MAC号"),
    QQ(302, "QQ号"),
    WX(303, "微信号"),
    WEIBO(304, "微博号"),
    SHOP_ACCOUNT(305, "购物账号"),
    SHOP_NICKNAME(306, "购物昵称"),
    WXGROUPID(307, "微信群ID"),
    WXID(308, "微信ID");

    private final int val;
    private final String des;

    private MonType(int val, String des) {
        this.val = val;
        this.des = des;
    }

    public int getVal() {
        return val;
    }

    public String getDes() {
        return des;
    }

    public static MonType getByVal(int val) {
        return Arrays.asList(values()).stream().filter(m -> m.val == val).findFirst().orElse(null);
    }
}
