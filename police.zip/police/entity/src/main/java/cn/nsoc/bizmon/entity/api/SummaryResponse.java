package cn.nsoc.bizmon.entity.api;

import java.util.ArrayList;
import java.util.List;

public class SummaryResponse {
	String name;
	String pid;
	String mobile;
	String icon;
	
	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getPid() {
		return pid;
	}

	public void setPid(String pid) {
		this.pid = pid;
	}

	public String getMobile() {
		return mobile;
	}

	public void setMobile(String mobile) {
		this.mobile = mobile;
	}

	public String getIcon() {
		return icon;
	}

	public void setIcon(String icon) {
		this.icon = icon;
	}


	public static class PathPoint{
		String time;
		String address;
		
		public PathPoint(String time, String address) {
			super();
			this.time = time;
			this.address = address;
		}
		
		public String getTime() {
			return time;
		}
		public void setTime(String time) {
			this.time = time;
		}
		public String getAddress() {
			return address;
		}
		public void setAddress(String address) {
			this.address = address;
		}
		
	}

}
