package cn.nsoc.bizmon.entity.api;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.List;

public class CollideRequest {
	public static final DateTimeFormatter SDTF = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
	private String fromtime;
	private String totime;
	private List<String> place;


	public String getFromtime() {
		return fromtime;
	}

	public void setFromtime(String fromtime) {
		this.fromtime = fromtime;
	}

	public LocalDateTime getStart() {
		return  LocalDateTime.parse(fromtime, SDTF);
	}

	public String getTotime() {
		return totime;
	}

	public void setTotime(String totime) {
		this.totime = totime;
	}
	
	public LocalDateTime getEnd(){
		return  LocalDateTime.parse(totime, SDTF);
	}
	

	public List<String> getPlace() {
		return place;
	}

	public void setPlace(List<String> place) {
		this.place = place;
	}

	@Override
	public String toString() {
		return "CollideModel [fromtime=" + fromtime + ", totime=" + totime + ", places=" + place + "]";
	}

}
