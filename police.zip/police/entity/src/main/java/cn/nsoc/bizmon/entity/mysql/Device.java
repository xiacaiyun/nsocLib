package cn.nsoc.bizmon.entity.mysql;

import cn.nsoc.common.storer.EntityCollection;
import cn.nsoc.common.storer.EntityQuery;
import cn.nsoc.common.storer.annotation.DbField;
import cn.nsoc.common.storer.annotation.DbQuery;
import cn.nsoc.common.storer.annotation.DbTable;
import cn.nsoc.common.storer.annotation.QueryOperator;

import java.time.Duration;
import java.time.LocalDateTime;
import java.util.List;
import java.util.stream.Collectors;

public class Device {
	@DbTable(name = "po_device")
	public static class Entity {
		@DbField(isKey = true,isAutoIncrement = false)
		private String no;
		private String mac;
		private int source;
		private String servicecode;
		private double longitude;
		private double latitude;
		private String floor;
		private String metro;
		private String line;
		private String train;
		private String compartment;
		private String vehicle;

		@DbField(isRequired = false) //不是此表数据库字段，只用作返回
		public Integer evtime;
		@DbField(isRequired = false) //不是此表数据库字段，只用作返回
		public int devtype;
		@DbField(isRequired = false) //不是此表数据库字段，只用作返回
		public String orgname;



		public Integer getDevcount() {
			return devcount;
		}

		public void setDevcount(Integer devcount) {
			this.devcount = devcount;
		}

		@DbField(isRequired = false) //不是此表数据库字段，只用作返回
		public Integer devcount;

		public boolean isOnline(int gap){
//			long now = Duration.between(LocalDateTime.of(1970, 1, 1, 8, 0, 0), LocalDateTime.now()).toMillis() / 1000;
			long now = Duration.between(LocalDateTime.of(1970, 1, 1, 8, 0, 0), LocalDateTime.now()).getSeconds();
			if ((evtime == null) || evtime < (now - gap))  //long  int ??
				return false;
			return true;

		}

		public String getNo() {
			return no;
		}

		public void setNo(String no) {
			this.no = no;
		}

		public String getMac() {
			return mac;
		}

		public void setMac(String mac) {
			this.mac = mac;
		}

		public int getSource() {
			return source;
		}

		public void setSource(int source) {
			this.source = source;
		}

		public String getServicecode() {
			return servicecode;
		}

		public void setServicecode(String servicecode) {
			this.servicecode = servicecode;
		}

		public double getLongitude() {
			return longitude;
		}

		public void setLongitude(double longitude) {
			this.longitude = longitude;
		}

		public double getLatitude() {
			return latitude;
		}

		public void setLatitude(double latitude) {
			this.latitude = latitude;
		}

		public String getFloor() {
			return floor;
		}

		public void setFloor(String floor) {
			this.floor = floor;
		}

		public String getMetro() {
			return metro;
		}

		public void setMetro(String metro) {
			this.metro = metro;
		}

		public String getLine() {
			return line;
		}

		public void setLine(String line) {
			this.line = line;
		}

		public String getTrain() {
			return train;
		}

		public void setTrain(String train) {
			this.train = train;
		}

		public String getCompartment() {
			return compartment;
		}

		public void setCompartment(String compartment) {
			this.compartment = compartment;
		}

		public String getVehicle() {
			return vehicle;
		}

		public void setVehicle(String vehicle) {
			this.vehicle = vehicle;
		}

	}

	@SuppressWarnings("serial")
	public static class Coll extends EntityCollection<Device.Entity,Query> {
		public Coll() {
			super(Device.Entity.class,Query.class);
		}

		public Coll(Query query) {
			this();
			this.setQuery(query);
		}

		public Device.Coll find(String serviceCode){  //以下过滤出根据唯一的serviceCode对应的一条devcount
			return this.stream().filter(h->h.servicecode.compareToIgnoreCase(serviceCode) == 0).distinct().collect(Collectors.toCollection(Device.Coll::new));
		}
	}

	public static class Query extends EntityQuery {
		private String no;
		@DbQuery(Operator = QueryOperator.In,valueType = String.class)
		private List<String> noIDList;
		@DbQuery(Operator = QueryOperator.NotIn)
		private List<String> noNotInIDList;

		public String getNo() {
			return no;
		}

		public void setNo(String no) {
			this.no = no;
		}

		@DbQuery(Operator = QueryOperator.SubQuery, express = "servicecode in (select distinct servicecode from po_place where %s = %s ) ")
		private String policename;

		@DbQuery(Operator = QueryOperator.SubQuery, express = "servicecode in (select distinct servicecode from po_place where %s = %s ) ")
		private String servicename;

		@DbQuery(Operator = QueryOperator.SubQuery, express = "servicecode in (select distinct servicecode from po_place where %s = %s ) ")
		private String servicetype;

		private Boolean isonline;
		private String mac;

		@DbQuery(Operator = QueryOperator.In,valueType = String.class)
		private List<String> servicecodeIDList;

		private String servicecode;

		public List<String> getNoIDList() {
			return noIDList;
		}

		public void setNoIDList(List<String> noIDList) {
			this.noIDList = noIDList;
		}

		public List<String> getNoNotInIDList() {
			return noNotInIDList;
		}

		public void setNoNotInIDList(List<String> noNotInIDList) {
			this.noNotInIDList = noNotInIDList;
		}

		public String getPolicename() {
			return policename;
		}

		public void setPolicename(String policename) {
			this.policename = policename;
		}

		public String getServicename() {
			return servicename;
		}

		public void setServicename(String servicename) {
			this.servicename = servicename;
		}

		public String getServicetype() {
			return servicetype;
		}

		public void setServicetype(String servicetype) {
			this.servicetype = servicetype;
		}

		public Boolean getIsonline() {
			return isonline;
		}

		public void setIsonline(Boolean isonline) {
			this.isonline = isonline;
		}

		public String getMac() {
			return mac;
		}

		public void setMac(String mac) {
			this.mac = mac;
		}

		public List<String> getServicecodeIDList() {
			return servicecodeIDList;
		}

		public void setServicecodeIDList(List<String> servicecodeIDList) {
			this.servicecodeIDList = servicecodeIDList;
		}

		public String getServicecode() {
			return servicecode;
		}

		public void setServicecode(String servicecode) {
			this.servicecode = servicecode;
		}

		public enum GroupByEnum {
			SERVICECODE
		}

	}

}
