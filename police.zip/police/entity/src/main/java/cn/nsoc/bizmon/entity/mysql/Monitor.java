package cn.nsoc.bizmon.entity.mysql;

import cn.nsoc.common.storer.EntityCollection;
import cn.nsoc.common.storer.EntityQuery;
import cn.nsoc.common.storer.annotation.DbField;
import cn.nsoc.common.storer.annotation.DbQuery;
import cn.nsoc.common.storer.annotation.DbTable;
import cn.nsoc.common.storer.annotation.QueryOperator;
import cn.nsoc.common.util.Misc;

import java.time.LocalDateTime;
import java.util.List;

public class Monitor {
	@DbTable(name = "po_monitor")
	public static class Entity {
		@DbField(isKey = true,isAutoIncrement = false)
		private String id;
		private String name;
		private String servicecode;
		private int montype;
		private String monkey;
		private int isvalid;
		private LocalDateTime starttime;
		private LocalDateTime endtime;

		@DbField(isRequired = false)
		public String servicename;

		@DbField(isRequired=false)
		private Integer total;

		@DbField(isRequired = false)
		public int namecount;

		@DbField(isRequired = false)
		public int monkeycount;

		@DbField(isRequired = false)
		public int count;
		
		public Integer getTotal() {
			return total;
		}

		public void setTotal(Integer total) {
			this.total = total;
		}

		public String getId() {
			return id;
		}

		public void setId(String id) {
			this.id = id;
		}

		public String getName() { return name; }

		public void setName(String name) { this.name = name; }

		public String getServicecode() {
			return servicecode;
		}

		public void setServicecode(String servicecode) {
			this.servicecode = servicecode;
		}

		public int getMontype() { return montype; }

		public void setMontype(int montype) { this.montype = montype;}

		public String getMonkey() {
			return monkey;
		}

		public void setMonkey(String monkey) {
			this.monkey = monkey;
		}

		public int getIsvalid() {
			return isvalid;
		}

		public void setIsvalid(int isvalid) {
			this.isvalid = isvalid;
		}

		public LocalDateTime getStarttime() {
			return starttime;
		}

		public void setStarttime(LocalDateTime starttime) {
			this.starttime = starttime;
		}

		public LocalDateTime getEndtime() {
			return endtime;
		}

		public void setEndtime(LocalDateTime endtime) {
			this.endtime = endtime;
		}

		public String toString() {
			return Misc.toStdString(starttime)+" "+Misc.toStdString(endtime)+" "+servicecode+" "+montype;
		}

	}

	@SuppressWarnings("serial")
	public static class Coll extends EntityCollection<Monitor.Entity,Query> {
		public Coll() {
			super(Monitor.Entity.class,Query.class);
		}

		public Coll(Query query) {
			this();
			this.setQuery(query);
		}

		public Entity findById(String monid) {
			return this.stream().filter(l->l.getId().equals(monid)).findFirst().orElse(null);
		}

	}

	public static class Query extends EntityQuery {

		@DbQuery(Operator = QueryOperator.In,valueType = String.class)
		private List<String> idIDList;
		
		@DbQuery(Operator = QueryOperator.In,valueType = String.class)
		private List<String> nameIDList;

		private String id;

		@DbQuery(Operator = QueryOperator.Like,valueType = String.class)
		private String monkey;
		@DbQuery(Operator = QueryOperator.In,valueType = String.class)
		private List<String> monkeyIDList;
		private Integer isvalid;
		private Integer montype;
		private String name;

		public String getId() {
			return id;
		}
		public void setId(String id) { this.id = id; }

		public List<String> getIdIDList() {
			return idIDList;
		}

		public void setIdIDList(List<String> idIDList) {
			this.idIDList = idIDList;
		}

		public List<String> getNameIDList() {
			return nameIDList;
		}

		public void setNameIDList(List<String> nameIDList) {
			this.nameIDList = nameIDList;
		}

		public String getMonkey() {
			return monkey;
		}

		public void setMonkey(String monkey) {
			this.monkey = monkey;
		}

		public Integer getIsvalid() {
			return isvalid;
		}

		public void setIsvalid(Integer isvalid) {
			this.isvalid = isvalid;
		}

		public Integer getMontype() {
			return montype;
		}

		public void setMontype(Integer montype) {
			this.montype = montype;
		}

		public String getName() {
			return name;
		}

		public void setName(String name) {
			this.name = name;
		}
		public List<String> getMonkeyIDList() {
			return monkeyIDList;
		}
		public void setMonkeyIDList(List<String> monkeyIDList) {
			this.monkeyIDList = monkeyIDList;
		}
		
		
	}

	public enum OrderByEnum {
		STARTTIME__DESC_MONTYPE__DESC,
	}
	public enum GroupByEnum {
		NAME
	}




}
