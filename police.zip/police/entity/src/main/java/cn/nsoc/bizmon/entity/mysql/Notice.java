package cn.nsoc.bizmon.entity.mysql;

import cn.nsoc.common.storer.EntityCollection;
import cn.nsoc.common.storer.EntityQuery;
import cn.nsoc.common.storer.annotation.DbField;
import cn.nsoc.common.storer.annotation.DbTable;

import java.time.LocalDateTime;

public class Notice {
    @DbTable(name = "po_notice")
    public static class Entity{
        @DbField(isKey = true, isAutoIncrement = false)
        private String id;
        private int userid;
        private LocalDateTime createtime;
        private String detail;
        private String src;


        public String getId() {
            return id;
        }

        public void setId(String id) {
            this.id = id;
        }

        public int getUserid() {
            return userid;
        }

        public void setUserid(int userid) {
            this.userid = userid;
        }

        public LocalDateTime getCreatetime() {
            return createtime;
        }

        public void setCreatetime(LocalDateTime createtime) {
            this.createtime = createtime;
        }

        public String getDetail() {
            return detail;
        }

        public void setDetail(String detail) {
            this.detail = detail;
        }

        public String getSrc() {
            return src;
        }

        public void setSrc(String src) {
            this.src = src;
        }
    }

    public static class Coll extends EntityCollection<Entity,Query> {
        public Coll() {
            super(Notice.Entity.class, Query.class);
        }

        public Coll(Query query) {
            this();
            this.setQuery(query);
        }
    }

    public static class Query extends EntityQuery {
        private String id;
        private Integer userid;
        public String getId() { return id; }
        public void setId(String id) { this.id = id; }

        public Integer getUserid() {
            return userid;
        }

        public void setUserid(Integer userid) {
            this.userid = userid;
        }
    }






}
