package cn.nsoc.bizmon.entity.mysql;

import java.util.List;

import cn.nsoc.common.storer.EntityCollection;
import cn.nsoc.common.storer.EntityQuery;
import cn.nsoc.common.storer.annotation.DbField;
import cn.nsoc.common.storer.annotation.DbQuery;
import cn.nsoc.common.storer.annotation.DbTable;
import cn.nsoc.common.storer.annotation.QueryOperator;

public class Hotstat {
	@DbTable(name = "po_hotstat")
	public static class Entity {
		@DbField()
		private int gaptime;
		private String servicecode;
		private int wbcount;
		private int wificount;
		private int auditcount;
		private int total;
		
		@DbField(isRequired = false)
		private String policename;


		public int getGaptime() {
			return gaptime;
		}

		public void setGaptime(int gaptime) {
			this.gaptime = gaptime;
		}

		public String getServicecode() {
			return servicecode;
		}

		public void setServicecode(String servicecode) {
			this.servicecode = servicecode;
		}

		public int getWbcount() {
			return wbcount;
		}

		public void setWbcount(int wbcount) {
			this.wbcount = wbcount;
		}

		public int getWificount() {
			return wificount;
		}

		public void setWificount(int wificount) {
			this.wificount = wificount;
		}

		public int getAuditcount() {
			return auditcount;
		}

		public void setAuditcount(int auditcount) {
			this.auditcount = auditcount;
		}

		public int getTotal() {
			return total;
		}

		public void setTotal(int total) {
			this.total = total;
		}

		public String getPolicename() {
			return policename;
		}

		public void setPolicename(String policename) {
			this.policename = policename;
		}

	}

	@SuppressWarnings("serial")
	public static class Coll extends EntityCollection<Hotstat.Entity,Query> {
		public Coll() {
			super(Hotstat.Entity.class,Query.class);
		}

		public Coll(Query query) {
			this();
			this.setQuery(query);
		}
	}

	public static class Query extends EntityQuery {
		
		private Long gaptime;
		public Long getGaptime() {
			return gaptime;
		}

		public void setGaptime(long gaptime) {
			this.gaptime = gaptime;
		}
		@DbQuery( Operator=QueryOperator.GreatEqual)
		private Long fromgaptime;
		@DbQuery(Operator=QueryOperator.LessEqual)
		private Long togaptime;
		
		@DbQuery(Operator = QueryOperator.LessEqual, name="gaptime")
		public Integer expiredTime;
		
		private String servicecode;

		public String getServicecode() {
			return servicecode;
		}

		public void setServicecode(String servicecode) {
			this.servicecode = servicecode;
		}

		public long getFromgaptime() {
			return fromgaptime;
		}

		public void setFromgaptime(long fromGaptime) {
			this.fromgaptime = fromGaptime;
		}

		public long getTogaptime() {
			return togaptime;
		}

		public void setTogaptime(long toGaptime) {
			this.togaptime = toGaptime;
		}

		public enum GroupByEnum{
			GAPTIME, GAPTIME__DESC, SERVICECODE;
		}
		
	}

}
