package cn.nsoc.bizmon.biz.dw.entity;

import com.google.gson.annotations.SerializedName;

import cn.nsoc.nspider.app.police.entity.objects.ObjDevFulSearch;

public class DevFulsearch {
	String name;
	String pid;
	String mobile;
	@SerializedName(ObjDevFulSearch.FD_SERVICE_CODE) 
	String serviceCode;

	@SerializedName(ObjDevFulSearch.FD_ONLINE_TIME) 
	String onlineTime;
	
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getPid() {
		return pid;
	}
	public void setPid(String pid) {
		this.pid = pid;
	}
	public String getMobile() {
		return mobile;
	}
	public void setMobile(String mobile) {
		this.mobile = mobile;
	}
	public String getServiceCode() {
		return serviceCode;
	}
	public void setServiceCode(String serviceCode) {
		this.serviceCode = serviceCode;
	}
	public String getOnlineTime() {
		return onlineTime;
	}
	public void setOnlineTime(String onlineTime) {
		this.onlineTime = onlineTime;
	}
	
}
