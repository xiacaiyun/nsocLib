package cn.nsoc.bizmon.biz.dw;

import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import cn.nsoc.base.entity.sys.NSException;
import cn.nsoc.bizmon.biz.dw.entity.DevGreatSearch;
import cn.nsoc.bizmon.entity.api.CollideRequest;
import cn.nsoc.bizmon.entity.api.Person;
import cn.nsoc.bizmon.entity.api.SummaryResponse;
import cn.nsoc.nspider.app.police.entity.objects.ObjDevPhoto;
import cn.nsoc.nspider.app.police.entity.rule.TrackCatelog;

@Service("dwMgr")
public class DataWareMgrImpl implements DataWareMgr {
	public static int ONE_DAY_SECONDS = 24 * 60 * 60;
	@Autowired
	HiveMgr hiveMgr;
	@Autowired
	HBaseMgr hbaseMgr;
	@Autowired
	ElasticSearchMgr esMgr;

	@Override
	public List<SummaryResponse> summary(String type, String val, long start, long end, int rowStart, int rowCount)
			throws NSException {
		return hiveMgr.summary(type, val, start, end, rowStart, rowCount);
	}
	
	@Override
	public List<String> findImgs(long start, long end, String pid) throws NSException {
		List<Map<String, Object>> icons = hiveMgr.findImgs(pid, start - ONE_DAY_SECONDS, end + ONE_DAY_SECONDS * 2);
		return icons.stream()
				.map(l -> String.format("/user/img/%s/%s/%s", l.get(ObjDevPhoto.FD_RELATE_PATH),
						l.get(ObjDevPhoto.FD_SERVICE_CODE), l.get(ObjDevPhoto.FD_MIME_NAME)))
				.collect(Collectors.toList());
	}
	
	public String findImgPath(String[] infos) throws NSException {
		String pid = infos[1];
		int time = Integer.parseInt(infos[2]);
		List<Map<String, Object>> ds = hiveMgr.findImgs(pid, time - ONE_DAY_SECONDS, time + ONE_DAY_SECONDS);
		if (ds.size() == 0)
			return null;
		Map<String, Object> photo = ds.get(0);
		return String.format("/user/img/%s/%s/%s", photo.get(ObjDevPhoto.FD_RELATE_PATH),
				photo.get(ObjDevPhoto.FD_SERVICE_CODE), photo.get(ObjDevPhoto.FD_MIME_NAME));

	}

	@Override
	public List<Map<String, Object>> findIdFromVirt(String account) throws NSException {
		return hiveMgr.findIdFromVirt(account);
	}

	@Override
	public String findMacFromMobile(String mobile) throws NSException {
		return hiveMgr.findMacFromMobile(mobile);
	}
	
	@Override
	public String findMobileFromMac(String val) throws NSException {
		return hiveMgr.findMobileFromMac(val);
	}

	@Override
	public List<Map<String, Object>> macTrace(long start, long end, String mac) throws NSException {
		return esMgr.macTrace(start, end, mac);
	}

	@Override
	public List<Map<String, Object>> fulTrace(long start, long end, String pid, String mobile) throws NSException {
		return hiveMgr.fulTrace(start, end, pid, mobile);
	}

	@Override
	public List<Map<String, Object>> collide(List<CollideRequest> models, int min) throws NSException {
		return hiveMgr.collide(models, min);
	}

	@Override
	public List<Map<String, Object>> relation(List<Map<String, String>> virtuals) throws NSException {
		return hiveMgr.relation(virtuals);
	}

	@Override
	public List<Map<String, Object>> findChat(String type, String val, long start, long end, int rowStart, int rowCount)
			throws NSException {
		return hiveMgr.findChat(type, val, start, end, rowStart, rowCount);
	}

	@Override
	public List<Map<String, Object>> findVirtById(String pid, String mobile) throws NSException {
		return hiveMgr.findVirtById(pid, mobile);
	}


	@Override
	public List<Map<String, Object>> findWbonline(String pid, int start, int limit) throws NSException {
		return hiveMgr.findWbonline(pid, start, limit);
	}

	@Override
	public List<Map<String, Object>> findWifiOnline(String pid, String mobile, int start, int limit) throws NSException {
		return hiveMgr.findWifiOnline(pid, mobile, start, limit);
	}

	@Override
	public List<Map<String, Object>> findMail(String pid, String mobile, int start, int limit) throws NSException {
		return hiveMgr.findMail(pid, mobile, start, limit);
	}

	@Override
	public List<Map<String, Object>> findHttp(String pid, String mobile, int start, int limit) throws NSException {
		return hiveMgr.findHttp(pid, mobile, start, limit);
	}

	@Override
	public ESResult<DevGreatSearch> search(String keyword, TrackCatelog type, String subtype, int rowStart, int rowCount) {
		return esMgr.search(keyword, type, subtype, rowStart, rowCount);
	}

	@Override
	public  Person findInfo(String searchid) {
		return esMgr.findInfo(searchid);
	}

	@Override
	public String findIconByPid(String pid) {
		return hbaseMgr.findIconByPid(pid);
	}


}
