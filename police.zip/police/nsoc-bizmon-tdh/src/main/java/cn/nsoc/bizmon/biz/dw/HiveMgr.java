package cn.nsoc.bizmon.biz.dw;

import cn.nsoc.base.entity.sys.NSException;
import cn.nsoc.bizmon.entity.api.CollideRequest;
import cn.nsoc.bizmon.entity.api.DetailResponse;
import cn.nsoc.bizmon.entity.api.SummaryResponse;
import cn.nsoc.nspider.app.police.entity.objects.ObjDevHotStat;
import cn.nsoc.nspider.app.police.entity.objects.ObjDevMobile;
import cn.nsoc.nspider.app.police.entity.objects.ObjDevPhoto;
import cn.nsoc.nspider.app.police.entity.objects.ObjDevVirtLookup;
import cn.nsoc.nspider.app.police.entity.objects.ObjDevFulSearch;
import cn.nsoc.nspider.app.police.entity.rule.AuthenticateType;

import org.apache.commons.lang3.StringUtils;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.OptionalLong;
import java.util.stream.Collectors;

import static cn.nsoc.bizmon.biz.dw.HiveSqlBuilder.*;
import static cn.nsoc.bizmon.util.Hptimer.format;

@Service("hiveMgr")
public class HiveMgr {

	private static final Logger appLogger = Logger.getLogger(DataWareMgr.class);

	@Autowired
	HiveRepository repo;

	public List<SummaryResponse> summary(String type, String val, long start, long end, int rowStart, int rowCount)
			throws NSException {
		Map<String, SummaryResponse> result = new HashMap<>();
		List<Map<String, Object>> ds = null;
		try {
			ds = repo.getDataSet(buildSummarySql(type, val, start, end, rowStart, rowCount));
		} catch (Exception e) {
			appLogger.warn(String.format("query failed. msg:%s", e.getMessage()));
			throw new NSException(e);
		}
		for (Map<String, Object> iter : ds) {

			String key = null;
			switch (type) {
			case "pid":
			case "pids":
				key = (String) iter.get("pid");
				break;
			case "mobile":
			case "mobiles":
				key = (String) iter.get("mobile");
				break;
			case "name":
				key = (String) iter.get("name");
				break;
			}
			SummaryResponse resp = null;
			if (!result.containsKey(key)) {
				resp = new SummaryResponse();
				if (iter.get("pid") != null) {
					resp.setPid((String) iter.get("pid"));
				}
				if (!StringUtils.isNumeric((String) iter.get("name"))) {
					resp.setName((String) iter.get("name"));
				}
				resp.setMobile((String) iter.get("mobile"));
				result.put(key, resp);
			} else {
				resp = result.get(key);
				if (resp.getPid() == null && iter.get("pid") != null) {
					resp.setPid((String) iter.get("pid"));
				}
				if (resp.getName() == null && !StringUtils.isNumeric((String) iter.get("name"))) {
					resp.setName((String) iter.get("name"));
				}
				if (resp.getMobile() == null && iter.get("mobile") != null) {
					resp.setMobile((String) iter.get("mobile"));
				}
			}
			if (resp.getIcon() == null && iter.get("pid") != null && iter.get("service_code") != null
					&& iter.get("online_time") != null) {
				resp.setIcon(
						String.format("%s-%s-%s", iter.get("service_code"), iter.get("pid"), iter.get("online_time")));
			}
		}
		return new ArrayList<SummaryResponse>(result.values());
	}

	public String findMacFromMobile(String mobile) throws NSException {
		String sql = String.format("SELECT %s FROM %s WHERE %s='%s' limit 1", ObjDevMobile.FD_MAC,
				ObjDevMobile.OBJECT_NAME, ObjDevMobile.FD_MOBILE, mobile);
		List<Map<String, Object>> ds = null;
		try {
			ds = repo.getDataSet(sql);
		} catch (Exception e) {
			appLogger.warn(String.format("query failed. msg:%s", e.getMessage()));
			throw new NSException(e);
		}
		if (ds.size() > 0)
			return ds.get(0).get(ObjDevMobile.FD_MAC).toString();
		else
			return "";
	}

	public String findMobileFromMac(String val) throws NSException {
		String sql = String.format("SELECT %s FROM %s WHERE %s='%s' limit 1", ObjDevMobile.FD_MOBILE,
				ObjDevMobile.OBJECT_NAME, ObjDevMobile.FD_MAC, val);
		List<Map<String, Object>> ds = null;
		try {
			ds = repo.getDataSet(sql);
		} catch (Exception e) {
			appLogger.warn(String.format("query failed. msg:%s", e.getMessage()));
			throw new NSException(e);
		}
		if (ds.size() > 0)
			return ds.get(0).get(ObjDevMobile.FD_MOBILE).toString();
		else
			return "";
	}

	public List<Map<String, Object>> findImgs(String pid, long start, long end) throws NSException {
		StringBuilder builder = new StringBuilder();
		builder.append(String.format("SELECT * FROM %s", ObjDevPhoto.OBJECT_NAME));
		builder.append(String.format(" WHERE %s > %s", ObjDevPhoto.FD_ONLINE_TIME, start));
		builder.append(String.format(" AND %s < %s", ObjDevPhoto.FD_ONLINE_TIME, end));
		builder.append(String.format(" AND %s = '%s' ", ObjDevPhoto.FD_PID, pid));
		builder.append(String.format(" order by %s desc", ObjDevPhoto.FD_ONLINE_TIME));
		List<Map<String, Object>> ds = null;
		try {
			ds = repo.getDataSet(builder.toString());
			return ds;
		} catch (Exception e) {
			appLogger.warn(String.format("query failed. msg:%s", e.getMessage()));
			throw new NSException(e);
		}
	}

	public List<Map<String, Object>> flowStat(long start, long end, String place) throws NSException {
		StringBuilder builder = new StringBuilder();
		builder.append(String.format("SELECT * FROM %s where", ObjDevHotStat.OBJECT_NAME));
		builder.append(String.format(" %s >= %d and %1$s <= %d ", ObjDevHotStat.FD_GAP_TIME, start, end));
		if (!StringUtils.isBlank(place)) {
			builder.append(String.format(" and %s = '%s' ", ObjDevHotStat.FD_SERVICE_CODE, place));
		}
		List<Map<String, Object>> ds = null;
		try {
			ds = repo.getDataSet(builder.toString());
		} catch (Exception e) {
			appLogger.warn(String.format("query failed. msg:%s", e.getMessage()));
			throw new NSException(e);
		}
		for (Map<String, Object> iter : ds) {
			iter.remove("auid");
			String time = format(Integer.parseInt(iter.get(ObjDevHotStat.FD_GAP_TIME).toString()));
			iter.put(ObjDevHotStat.FD_GAP_TIME, time);
		}
		return ds;
	}

	public List<Map<String, Object>> flowTotal(long start, long end) throws NSException {
		StringBuilder builder = new StringBuilder();
		builder.append(String.format(
				" SELECT %s, sum(%s) as gap_total, sum(%s) as gap_wb_count, sum(%s) as gap_wifi_count, sum(%s) as gap_audit_count ",
				ObjDevHotStat.FD_GAP_TIME, ObjDevHotStat.FD_GAP_TOTAL, ObjDevHotStat.FD_GAP_WB_COUNT,
				ObjDevHotStat.FD_GAP_WIFI_COUNT, ObjDevHotStat.FD_GAP_AUDIT_COUNT));
		builder.append(String.format(" FROM %s where %s >= %d ", ObjDevHotStat.OBJECT_NAME,
				ObjDevHotStat.FD_GAP_TIME, start));
		builder.append(String.format(" AND %s <= %d ", ObjDevHotStat.FD_GAP_TIME, start, end));
		builder.append(String.format(" GROUP BY %s", ObjDevHotStat.FD_GAP_TIME));

		List<Map<String, Object>> ds = null;
		try {
			ds = repo.getDataSet(builder.toString());
		} catch (Exception e) {
			appLogger.warn(String.format("query failed. msg:%s", e.getMessage()));
			throw new NSException(e);
		}
		for (Map<String, Object> iter : ds) {
			long time = (long) (iter.get(ObjDevHotStat.FD_GAP_TIME));
			iter.put(ObjDevHotStat.FD_GAP_TIME, format(time));
		}
		return ds;
	}

	public List<Map<String, Object>> findIdFromVirt(String account) throws NSException {
		StringBuilder builder = new StringBuilder();
		builder.append(String.format("SELECT cert_type, cert_id FROM %s where", ObjDevVirtLookup.OBJECT_NAME));
		builder.append(String.format(" %s like '%%%s%%' ", ObjDevVirtLookup.FD_ACCOUNT_CODE, account));
		List<Map<String, Object>> ds = null;
		try {
			ds = repo.getDataSet(builder.toString());
		} catch (Exception e) {
			appLogger.warn(String.format("query failed. msg:%s", e.getMessage()));
			throw new NSException(e);
		}
		return ds;
	}

	public List<Map<String, Object>> findVirtById(String pid, String mobile) throws NSException {
		StringBuilder builder = new StringBuilder();
		boolean hasPid = false;
		if (StringUtils.isNotBlank(pid)) {
			hasPid = true;
			builder.append(
					String.format("SELECT account_type, account_code FROM %s where", ObjDevVirtLookup.OBJECT_NAME));
			builder.append(String.format(" cert_id = '%s' and cert_type != '%s' ", pid, AuthenticateType.MOBILE));
		}
		if (StringUtils.isNotBlank(mobile)) {
			if (hasPid) {
				builder.append(" UNION ");
			}
			builder.append(
					String.format("SELECT account_type, account_code FROM %s where", ObjDevVirtLookup.OBJECT_NAME));
			builder.append(String.format(" cert_id = '%s' and cert_type = '%s' ", mobile, AuthenticateType.MOBILE));
		}
		List<Map<String, Object>> ds = null;
		try {
			ds = repo.getDataSet(builder.toString());
		} catch (Exception e) {
			appLogger.warn(String.format("query failed. msg:%s", e.getMessage()));
			throw new NSException(e);
		}
		return ds;
	}

	public List<Map<String, Object>> collide(List<CollideRequest> models, int min) throws NSException {
		List<Map<String, Object>> ds = null;
		try {
			ds = repo.getDataSet(buildCollisionSql(models, min));
		} catch (Exception e) {
			appLogger.warn(String.format("query failed. msg:%s", e.getMessage()));
			throw new NSException(e);
		}
		return ds;
	}

	public List<Map<String, Object>> macTrace(long start, long end, String mac) throws NSException {

		StringBuilder builder = new StringBuilder();
		builder.append("SELECT online_time, service_code FROM dev_mac where");
		builder.append(String.format(" online_time >= %d and online_time <= %d ", start, end));
		builder.append(String.format(" and mac = '%s' ", mac));
		List<Map<String, Object>> ds = null;
		try {
			ds = repo.getDataSet(builder.toString());
		} catch (Exception e) {
			appLogger.warn(String.format("query failed. msg:%s", e.getMessage()));
			throw new NSException(e);
		}
		return ds;

	}

	public List<Map<String, Object>> fulTrace(long start, long end, String pid, String mobile) throws NSException {

		StringBuilder builder = new StringBuilder();

		boolean hasPid = false;

		if (StringUtils.isNotBlank(pid)) {
			hasPid = true;
			builder.append("SELECT online_time, service_code FROM dev_fulsearch where");
			builder.append(String.format(" online_time >= %d and online_time <= %d and pid = '%s'", start, end, pid));
		}
		if (StringUtils.isNotBlank(mobile)) {
			if (hasPid) {
				builder.append(" UNION ");
			}
			builder.append("SELECT online_time, service_code FROM dev_fulsearch where");
			builder.append(
					String.format(" online_time >= %d and online_time <= %d and mobile = '%s'", start, end, mobile));
		}

		List<Map<String, Object>> ds = null;
		try {
			ds = repo.getDataSet(builder.toString());
		} catch (Exception e) {
			appLogger.warn(String.format("query failed. msg:%s", e.getMessage()));
			throw new NSException(e);
		}
		return ds;

	}

	public List<Map<String, Object>> relation(List<Map<String, String>> virtuals) throws NSException {
		List<Map<String, Object>> ds = null;
		try {
			ds = repo.getDataSet(buildRelationSql(virtuals));
		} catch (Exception e) {
			appLogger.warn(String.format("query failed. msg:%s", e.getMessage()));
			throw new NSException(e);
		}
		return ds;
	}

	public List<Map<String, Object>> findChat(String type, String val, long start, long end, int rowStart, int rowCount)
			throws NSException {
		List<Map<String, Object>> ds = null;
		try {
			ds = repo.getDataSet(buildChatSql(type, val, start, end, rowStart, rowCount));
		} catch (Exception e) {
			appLogger.warn(String.format("query failed. msg:%s", e.getMessage()));
			throw new NSException(e);
		}
		return ds;
	}

	// public long findChatTotal(String type, String val, long start, long end)
	// throws NSException {
	// List<Map<String, Object>> ds = null;
	// try {
	// ds = repo.getDataSet(buildChatTotalSql(type, val, start, end));
	// } catch (Exception e) {
	// appLogger.warn(String.format("query failed. msg:%s", e.getMessage()));
	// throw new NSException(e);
	// }
	// if (!ds.isEmpty()) {
	// return (long) ds.get(0).get("total");
	// }
	// return 0;
	// }

	public List<Map<String, Object>> findWbonline(String pid, int start, int limit) throws NSException {
		List<Map<String, Object>> ds = null;
		String sql = String.format("select ont as online_time, oft as offline_time, sc, ter as terminal_id "
				+ " from dev_term_track where vk like '%s%%' and acc='%<s' limit %s, %s", pid, start, limit);

		try {
			ds = repo.getDataSet(sql);
		} catch (Exception e) {
			appLogger.warn(String.format("query failed. msg:%s", e.getMessage()));
			throw new NSException(e);
		}
		return ds;
	}

	public List<Map<String, Object>> findWifiOnline(String pid, String mobile, int start, int limit)
			throws NSException {
		List<Map<String, Object>> ds = null;
		String pidsql = String.format(
				"select ont as online_time, oft as offline_time, sc as servicecode, ap  from dev_wifi_track where vk like '%s%%' and acc='%<s'",
				pid);
		String mobilesql = String.format(
				"select ont as online_time, oft as offline_time, sc as servicecode, ap  from dev_wifi_track where vk like '%s%%' and acc='%<s'",
				mobile);
		String sql = null;
		if (StringUtils.isNotBlank(pid) && StringUtils.isNotBlank(mobile)) {
			sql = String.format("select * from ((%s) UNION (%s)) as tmp limit %s, %s", pidsql, mobilesql, start, limit);
		} else if (StringUtils.isNotBlank(pid)) {
			sql = String.format("%s limit %s, %s", pidsql, start, limit);
		} else if (StringUtils.isNotBlank(mobile)) {
			sql = String.format("%s limit %s, %s", mobilesql, start, limit);
		}
		try {
			ds = repo.getDataSet(sql);
		} catch (Exception e) {
			appLogger.warn(String.format("query failed. msg:%s", e.getMessage()));
			throw new NSException(e);
		}
		return ds;
	}

	public List<Map<String, Object>> findMail(String pid, String mobile, int start, int limit) throws NSException {
		List<Map<String, Object>> ds = null;
		String pidsql = String.format("select mfr as mail_from, rp as mail_to, cc as mail_cc, "
				+ " sub as mail_subject, sc as servicecode, cpt as send_time "
				+ " from dev_mail_track where vk like '%s%%' and acc='%1$s'", pid);
		String mobilesql = String.format("select mfr as mail_from, rp as mail_to, cc as mail_cc, "
				+ " sub as mail_subject, sc as servicecode, cpt as send_time "
				+ " from dev_mail_track where vk like '%s%%' and acc='%1$s'", mobile);
		String sql = null;
		if (StringUtils.isNotBlank(pid) && StringUtils.isNotBlank(mobile)) {
			sql = String.format("select * from ((%s) UNION (%s)) as tmp limit %s, %s", pidsql, mobilesql, start, limit);
		} else if (StringUtils.isNotBlank(pid)) {
			sql = String.format("%s limit %s, %s", pidsql, start, limit);
		} else if (StringUtils.isNotBlank(mobile)) {
			sql = String.format("%s limit %s, %s", mobilesql, start, limit);
		}
		try {
			ds = repo.getDataSet(sql);
		} catch (Exception e) {
			appLogger.warn(String.format("query failed. msg:%s", e.getMessage()));
			throw new NSException(e);
		}
		return ds;
	}

	public List<Map<String, Object>> findHttp(String pid, String mobile, int start, int limit) throws NSException {
		List<Map<String, Object>> ds = null;
		String pidsql = String.format(
				"select mo as sessionid, url, sc as servicecode, cpt as send_time from dev_http_track where vk like '%s%%' and acc='%1$s'",
				pid);
		String mobilesql = String.format(
				"select mo as sessionid, url, sc as servicecode, cpt as send_time from dev_http_track where vk like '%s%%' and acc='%1$s'",
				mobile);
		String sql = null;
		if (StringUtils.isNotBlank(pid) && StringUtils.isNotBlank(mobile)) {
			sql = String.format("select * from ((%s) UNION (%s)) as tmp limit %s, %s", pidsql, mobilesql, start, limit);
		} else if (StringUtils.isNotBlank(pid)) {
			sql = String.format("%s limit %s, %s", pidsql, start, limit);
		} else if (StringUtils.isNotBlank(mobile)) {
			sql = String.format("%s limit %s, %s", mobilesql, start, limit);
		}

		try {
			ds = repo.getDataSet(sql);
		} catch (Exception e) {
			appLogger.warn(String.format("query failed. msg:%s", e.getMessage()));
			throw new NSException(e);
		}
		return ds;
	}

}
