package cn.nsoc.bizmon.biz.dw;

import cn.nsoc.base.entity.define.NSExceptionCode;
import cn.nsoc.base.entity.sys.NSException;
import cn.nsoc.bizmon.util.RSHelper;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

import java.sql.*;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.sql.DataSource;

@Component
public class HiveRepository {

	private static final Logger logger = Logger.getLogger(HiveRepository.class);
	
	@Autowired
	private DataSource hiveDataSource;



	public List<Map<String, Object>> getDataSet(String sql) throws NSException {
		logger.debug(String.format("hivesql is: %s", sql));
		long startTime = System.nanoTime();
		Statement stmt = null;
		ResultSet res = null;
		Connection conn = null;
		List<Map<String, Object>> rows = new ArrayList<>();
		try {
			conn = hiveDataSource.getConnection();
			stmt = conn.createStatement();
			stmt.execute("set ngmr.exec.mode=local");
			res = stmt.executeQuery(sql);
			while (res.next()) {
				rows.add(RSHelper.toDict(res));
			}
			logger.debug(String.format("hivesql used: %d ms", (System.nanoTime() - startTime) / 1_000_000));

		} catch (SQLException exp) {
			logger.error(String.format("exception. sql: %s", sql, exp));
			throw new NSException(NSExceptionCode.Runtime_Error, exp.getMessage());
		} finally {
			if (res != null) {
				try {
					res.close();
				} catch (SQLException e) {
					logger.error("hive db error", e);
				}
			}
			if (stmt != null) {
				try {
					stmt.close();
				} catch (SQLException e) {
					logger.error("hive db error", e);
				}
			}
			if (conn != null) {
				try {
					conn.close();
				} catch (SQLException e) {
					logger.error("hive db error", e);
				}
			}
		}
		return rows;
	}

}
