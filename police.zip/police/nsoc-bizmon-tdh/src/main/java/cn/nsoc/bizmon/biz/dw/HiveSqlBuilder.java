package cn.nsoc.bizmon.biz.dw;

import java.util.List;
import java.util.Map;
import java.util.stream.IntStream;
import java.util.stream.Stream;

import static java.util.stream.Collectors.joining;
import static java.util.stream.Collectors.toList;

import java.time.format.DateTimeFormatter;

import cn.nsoc.bizmon.entity.api.CollideRequest;

public class HiveSqlBuilder {
	public static final DateTimeFormatter yyDTF = DateTimeFormatter.ofPattern("yyMMddHHmmss");

	private HiveSqlBuilder() {
	}

	static String buildSummarySql(String type, String val, long start, long end, int rowStart, int rowCount) {
		StringBuilder builder = new StringBuilder();
		builder.append("SELECT pid, name, mobile, service_code, online_time FROM dev_fulsearch");
		builder.append(String.format(" where online_time >= %d and online_time <= %d ", start, end));
		boolean frontMatch = false;
		if (val.endsWith("*")) {
			frontMatch = true;
			val = val.substring(0, val.length() - 1);
		}
		if (("mobile").equalsIgnoreCase(type)) {
			if (val.length() == 11) {
				builder.append(String.format(" and mobile = '%s' ", val));
			} else if (frontMatch) {
				builder.append(String.format(" and mobile like '%s%%' ", val));
			} else {
				builder.append(String.format(" and mobile like '%%%s%%' ", val));
			}
		} else if (("mobiles").equalsIgnoreCase(type)) {
			builder.append(String.format(" and mobile in (%s) ", val));
		}else if (("name").equalsIgnoreCase(type)) {
			if (frontMatch) {
				builder.append(String.format(" and name like '%s%%' ", val));
			} else {
				builder.append(String.format(" and name like '%%%s%%' ", val));
			}
		} else if (("pid").equalsIgnoreCase(type)) {
			if (val.length() == 15 || val.length() == 18) {
				builder.append(String.format(" and pid = '%s' ", val));
			} else if (frontMatch) {
				builder.append(String.format(" and pid like '%s%%' ", val));
			} else {
				builder.append(String.format(" and pid like '%%%s%%' ", val));
			}
		} else if (("pids").equalsIgnoreCase(type)) {
			builder.append(String.format(" and pid in (%s) ", val));
		}
		builder.append(String.format(" limit %d, %d", rowStart, rowCount));
		return builder.toString();
	}

	static String buildSummarySqlByMac(String val, long start, long end, int rowStart, int rowCount) {
		StringBuilder builder = new StringBuilder();
		builder.append("SELECT fs.pid, fs.name, fs.online_time, fs.mobile, fs.service_code FROM dev_fulsearch fs");
		builder.append(", dev_mobile mo where fs.mobile=mo.mobile");
		builder.append(String.format(" and mo.mac = '%s' ", val));
		builder.append(String.format(" and fs.online_time >= %d and fs.online_time <= %d ", start, end));
		builder.append(String.format(" limit %d, %d", rowStart, rowCount));
		return builder.toString();
	}

	static String buildDetailSql(String pid, long start, long end) {
		StringBuilder builder = new StringBuilder();
		builder.append("SELECT pid, service_code, online_time FROM dev_fulsearch");
		builder.append(String.format(" where online_time >= %d and online_time <= %d ", start, end));
		builder.append(String.format(" and pid = '%s' ", pid));
		return builder.toString();
	}

	static String buildCollisionSql(List<CollideRequest> reqs, int min) {
		String front = "SELECT c_sc, s_sc, collect_set(mac) AS s_mac FROM "
				+ "     (SELECT  mac,  size(s_sc) AS c_sc,  s_sc FROM "
				+ "     (SELECT mac,collect_set(sc) AS s_sc  FROM ( ";
		StringBuilder end = new StringBuilder();
		end.append(" ) tmpA ").append("     GROUP BY mac ").append("    ) tmpB").append("	   ) tmpC ")
				.append(" WHERE tmpC.c_sc >= ").append(min).append(" GROUP BY c_sc, s_sc ORDER BY c_sc DESC");
		List<String> bwts = reqs.stream().flatMap(l -> subUnion(l)).collect(toList());

		return String.format("%s%s%s", front, bwts.stream().collect(joining(" UNION ")), end);
	}

	static Stream<String> subUnion(CollideRequest req) {
		String twelveZero = IntStream.rangeClosed(1, 12).mapToObj(l -> "0").collect(joining());
		return req.getPlace().stream().map(HiveSqlBuilder::transPlace)
				.map(a -> String.format(" (select mac, sc FROM dev_mac_hit WHERE vk >= '%s%s%s' AND vk < '%1$s%s%3$s')",
						a, req.getStart().format(yyDTF), twelveZero, req.getEnd().plusSeconds(1).format(yyDTF)));
	}

	static String transPlace(String place) {
		final int SC_SIZE = 10;
		String code = place.trim().toLowerCase();
		final int len = code.length();
		if (len >= SC_SIZE)
			return new StringBuilder(code.substring(len - SC_SIZE)).reverse().toString();
		else {
			StringBuilder builder = new StringBuilder(SC_SIZE);
			for (int i = SC_SIZE; i > len; i--) {
				builder.append("#");
			}
			return builder.append(code).reverse().toString();
		}
	}

	static String buildRelationSql(List<Map<String, String>> virtuals) {
		String front = "SELECT im_type AS virtype, self_id AS virval,  collect_set(contact_id) AS relations FROM dev_im_relate WHERE ";
		String end = "GROUP by self_id, im_type;";
		return String.format("%s%s%s", front, virtuals.stream().map(a -> {
			return String.format(" (im_type='%s' AND self_id='%s')", a.get("virtype"), a.get("virval"));
		}).collect(joining(" OR ")), end);
	}

	static String buildChatSql(String type, String val, long start, long end, int rowStart, int rowCount) {
		String front = "SELECT send_time, from_id, to_id, grp_no, grp_name, service_code as sc, content as msg FROM dev_im_msg ";
		String limit = String.format(" limit %s, %s", rowStart, rowCount);
		String sql = String.format("%s%s%s", front, chatWhereClause(type, val, start, end), limit);
		if ("person".equalsIgnoreCase(type)) {
			String fromsql = sql.replace("TOBEREPLACE", "from_id");
			String tosql = sql.replace("TOBEREPLACE", "to_id");
			sql = String.format("(%s) UNION (%s)", fromsql, tosql);
		}
		return sql;
	}

	static String buildChatTotalSql(String type, String val, long start, long end) {
		String front = "SELECT count(1) as total FROM dev_im_msg ";
		return String.format("%s%s", front, chatWhereClause(type, val, start, end));
	}

	static String chatWhereClause(String type, String val, long start, long end) {
		String time = String.format(" WHERE  send_time >= %s AND send_time <= %s  ", start, end);
		String where = null;
		if ("person".equalsIgnoreCase(type)) {
			where = String.format(" AND TOBEREPLACE like '%%%s%%'", val);
		} else if ("group".equalsIgnoreCase(type)) {
			where = String.format(" AND grp_no like '%%%s%%'", val);
		} else if ("msg".equalsIgnoreCase(type)) {
			where = String.format(" AND content like '%%%s%%'", val);
		} else
			where = "";
		return String.format("%s%s", time, where);
	}
	
}
