package cn.nsoc.bizmon.biz.dw;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import javax.annotation.PostConstruct;
import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.hbase.HBaseConfiguration;
import org.apache.hadoop.hbase.TableName;
import org.apache.hadoop.hbase.client.Connection;
import org.apache.hadoop.hbase.client.ConnectionFactory;
import org.apache.hadoop.hbase.client.Result;
import org.apache.hadoop.hbase.client.ResultScanner;
import org.apache.hadoop.hbase.client.Scan;
import org.apache.hadoop.hbase.client.Table;
import org.apache.hadoop.hbase.filter.Filter;
import org.apache.hadoop.hbase.filter.PrefixFilter;
import org.apache.hadoop.hbase.util.Bytes;
import org.apache.log4j.Logger;
import org.springframework.stereotype.Service;
import cn.nsoc.bizmon.util.Hptimer;
import cn.nsoc.nspider.app.police.entity.objects.ObjDevCertImg;

@Service("hbaseMgr")
public class HBaseMgr {
    private static final Logger logger = Logger.getLogger(HBaseMgr.class);
    private Configuration conf = null;

    @PostConstruct
    public void init() {
        conf = HBaseConfiguration.create();
    }


    public List<Map<String, Object>> findWbonline(String pid, int start, int limit) {
        List<Map<String, Object>> result = new ArrayList<>();
        try (Connection connection = ConnectionFactory.createConnection(conf);
                Table table = connection.getTable(TableName.valueOf("police.dev_term_track"))) {
            Scan scan = new Scan();
            Filter prefix = new PrefixFilter(Bytes.toBytes(pid));
            scan.setFilter(prefix);
            scan.setBatch(1000);
            byte[] fam = Bytes.toBytes("f");
            ResultScanner rs = table.getScanner(scan);
            Result val = null;
            while ((val = rs.next()) != null) {
                if (start-- > 0) {
                    continue;
                }
                if (--limit < 0) {
                    break;
                }
                String ter = Bytes.toString((val.getValue(fam, Bytes.toBytes("ter"))));
                String sc = Bytes.toString(val.getValue(fam, Bytes.toBytes("sc")));
                String ontStr = Bytes.toString(val.getValue(fam, Bytes.toBytes("ont")));
                String oftStr = Bytes.toString(val.getValue(fam, Bytes.toBytes("oft")));

                Map<String, Object> pair = new HashMap<>();
                if (ontStr != null) {
                    pair.put("online_time", Hptimer.format(Long.parseLong(ontStr)));
                }
                if (oftStr != null) {
                    pair.put("offline_time", Hptimer.format(Long.parseLong(oftStr)));
                }
                pair.put("sc", sc);
                pair.put("terminal_id", ter);
                result.add(pair);
            }
            rs.close();
        } catch (Exception e) {
            logger.error("hbase error", e);
        }
        return result;

    }

    public List<Map<String, Object>> findWifiOnline(String acc, int start, int limit) {
        List<Map<String, Object>> result = new ArrayList<>();
        try (Connection connection = ConnectionFactory.createConnection(conf);
                Table table = connection.getTable(TableName.valueOf("police.dev_wifi_track"))) {
            Scan scan = new Scan();
            Filter prefix = new PrefixFilter(Bytes.toBytes(acc));
            scan.setFilter(prefix);
            scan.setBatch(1000);
            byte[] fam = Bytes.toBytes("f");
            ResultScanner rs = table.getScanner(scan);
            Result val = null;
            while ((val = rs.next()) != null) {
                if (start-- > 0) {
                    continue;
                }
                if (--limit < 0) {
                    break;
                }

                String ap = Bytes.toString((val.getValue(fam, Bytes.toBytes("ap"))));
                String sc = Bytes.toString(val.getValue(fam, Bytes.toBytes("sc")));
                String ontStr = Bytes.toString(val.getValue(fam, Bytes.toBytes("ont")));
                String oftStr = Bytes.toString(val.getValue(fam, Bytes.toBytes("oft")));

                Map<String, Object> pair = new HashMap<>();
                if (ontStr != null) {
                    pair.put("online_time", Hptimer.format(Long.parseLong(ontStr)));
                }
                if (oftStr != null) {
                    pair.put("offline_time", Hptimer.format(Long.parseLong(oftStr)));
                }
                pair.put("servicecode", sc);
                pair.put("ap", ap);
                result.add(pair);
            }
        } catch (Exception e) {
            logger.error("hbase error", e);
        }
        return result;
    }

    public List<Map<String, Object>> findMail(String acc, int start, int limit) {
        List<Map<String, Object>> result = new ArrayList<>();
        try (Connection connection = ConnectionFactory.createConnection(conf);
                Table table = connection.getTable(TableName.valueOf("police.dev_mail_track"))) {
            Scan scan = new Scan();
            Filter prefix = new PrefixFilter(Bytes.toBytes(acc));
            scan.setFilter(prefix);
            scan.setBatch(1000);
            byte[] fam = Bytes.toBytes("f");
            ResultScanner rs = table.getScanner(scan);
            Result val = null;
            while ((val = rs.next()) != null) {
                if (start-- > 0) {
                    continue;
                }
                if (--limit < 0) {
                    break;
                }

                String sc = Bytes.toString(val.getValue(fam, Bytes.toBytes("sc")));
                String mfr = Bytes.toString(val.getValue(fam, Bytes.toBytes("mfr")));
                String rp = Bytes.toString(val.getValue(fam, Bytes.toBytes("rp")));
                String cc = Bytes.toString(val.getValue(fam, Bytes.toBytes("cc")));
                String sub = Bytes.toString(val.getValue(fam, Bytes.toBytes("sub")));
                String cptStr = Bytes.toString(val.getValue(fam, Bytes.toBytes("cpt")));

                Map<String, Object> element = new HashMap<>();
                if (cptStr != null) {
                    element.put("send_time", Hptimer.format(Long.parseLong(cptStr)));
                }
                element.put("mail_from", mfr);
                element.put("mail_to", rp);
                element.put("mail_cc", cc);
                element.put("mail_subject", sub);
                element.put("servicecode", sc);
                result.add(element);
            }
        } catch (Exception e) {
            logger.error("hbase error", e);
        }
        return result;
    }

    public List<Map<String, Object>> findHttp(String acc, int start, int limit) {
        List<Map<String, Object>> result = new ArrayList<>();
        try (Connection connection = ConnectionFactory.createConnection(conf);
                Table table = connection.getTable(TableName.valueOf("police.dev_http_track"))) {
            Scan scan = new Scan();
            Filter prefix = new PrefixFilter(Bytes.toBytes(acc));
            scan.setFilter(prefix);
            scan.setBatch(1000);
            byte[] fam = Bytes.toBytes("f");
            ResultScanner rs = table.getScanner(scan);
            Result val = null;
            while ((val = rs.next()) != null) {
                if (start-- > 0) {
                    continue;
                }
                if (--limit < 0) {
                    break;
                }

                String sc = Bytes.toString(val.getValue(fam, Bytes.toBytes("sc")));
                String mo = Bytes.toString(val.getValue(fam, Bytes.toBytes("mo")));
                String url = Bytes.toString(val.getValue(fam, Bytes.toBytes("url")));
                String cptStr = Bytes.toString(val.getValue(fam, Bytes.toBytes("cpt")));

                Map<String, Object> element = new HashMap<>();
                if (cptStr != null) {
                    element.put("send_time", Hptimer.format(Long.parseLong(cptStr)));
                }
                element.put("sessionid", mo);
                element.put("url", url);
                element.put("servicecode", sc);
                result.add(element);
            }
        } catch (Exception e) {
            logger.error("hbase error", e);
        }
        return result;
    }

    public String findIconByPid(String acc) {
        String image = null;
        try (Connection connection = ConnectionFactory.createConnection(conf);
                Table table = connection.getTable(TableName.valueOf("dev_cert_img"))) {
            Scan scan = new Scan();
            Filter prefix = new PrefixFilter(Bytes.toBytes(acc));
            scan.setFilter(prefix);
            scan.setBatch(10);
            byte[] fam = Bytes.toBytes("f");
            ResultScanner rs = table.getScanner(scan);
            Result val = rs.next();
            if (val != null) {
                image = Bytes.toString(val.getValue(fam, Bytes.toBytes(ObjDevCertImg.FD_IMG)));
            }
        } catch (Exception e) {
            logger.error("hbase error", e);
        }
        return image;
    }
}
