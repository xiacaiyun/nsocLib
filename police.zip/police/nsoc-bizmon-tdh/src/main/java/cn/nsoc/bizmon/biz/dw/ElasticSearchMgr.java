package cn.nsoc.bizmon.biz.dw;

import static java.util.stream.Collectors.groupingBy;
import static java.util.stream.Collectors.toList;
import static java.util.stream.Collectors.toSet;
import static cn.nsoc.bizmon.util.Hptimer.format;
import java.net.InetAddress;
import java.net.UnknownHostException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;
import javax.annotation.PostConstruct;
import javax.annotation.PreDestroy;
import org.apache.commons.lang.StringUtils;
import org.elasticsearch.action.search.SearchResponse;
import org.elasticsearch.client.transport.TransportClient;
import org.elasticsearch.common.settings.Settings;
import org.elasticsearch.common.transport.InetSocketTransportAddress;
import org.elasticsearch.index.query.BoolQueryBuilder;
import org.elasticsearch.index.query.QueryBuilder;
import org.elasticsearch.index.query.QueryBuilders;
import org.elasticsearch.index.query.TermQueryBuilder;
import org.elasticsearch.search.sort.SortOrder;
import org.elasticsearch.transport.client.PreBuiltTransportClient;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import cn.nsoc.base.entity.sys.NSException;
import cn.nsoc.bizmon.biz.dw.entity.*;
import cn.nsoc.bizmon.entity.api.Person;
import cn.nsoc.bizmon.entity.api.SummaryResponse;
import cn.nsoc.nspider.app.police.entity.objects.ObjDevMac;
import cn.nsoc.nspider.app.police.entity.objects.ObjDevMobile;
import cn.nsoc.nspider.app.police.entity.objects.ObjDevPhoto;
import cn.nsoc.nspider.app.police.entity.objects.ObjDevTrack;
import cn.nsoc.nspider.app.police.entity.objects.ObjDevVirtLookup;
import cn.nsoc.nspider.app.police.entity.objects.ObjDevFulSearch;
import cn.nsoc.nspider.app.police.entity.objects.ObjDevGreatSearch;
import cn.nsoc.nspider.app.police.entity.objects.ObjIMMsg;
import cn.nsoc.nspider.app.police.entity.objects.ObjIMRelate;
import cn.nsoc.nspider.app.police.entity.rule.AuthenticateType;
import cn.nsoc.nspider.app.police.entity.rule.TrackCatelog;

@Service("esMgr")
public class ElasticSearchMgr {
    private static int ONE_DAY_SECONDS = 24 * 60 * 60;

    TransportClient client;
    @Value("${es.name}")
    String clusterName;
    @Value("${es.hosts}")
    String hosts;

    @PostConstruct
    public void init() throws UnknownHostException {
        Settings settings = Settings.builder().put("cluster.name", clusterName).put("client.transport.sniff", false)
                .build();
        client = new PreBuiltTransportClient(settings);
        for (String host : hosts.split(",")) {
            client.addTransportAddress(new InetSocketTransportAddress(InetAddress.getByName(host), 9300));
        }
    }

    @PreDestroy
    public void destroy() {
        client.close();
    }


    private static BoolQueryBuilder initRangeBoolQB(Object start, Object end, String fieldName) {
        BoolQueryBuilder qb = QueryBuilders.boolQuery();
        qb.must(QueryBuilders.rangeQuery(fieldName).gte(start).lte(end));
        return qb;
    }

    public ESResult<DevGreatSearch> search(String keyword, TrackCatelog type, String subtype,
            int rowStart, int rowCount) {
        BoolQueryBuilder qb = QueryBuilders.boolQuery();
        if (type != TrackCatelog.UNKNOWN) {
            qb.must(QueryBuilders.termQuery(ObjDevGreatSearch.FD_CATELOG, type.getIndex()));
        }

        if (type == TrackCatelog.VIRTUAL && StringUtils.isNotBlank(subtype)) {
            qb.must(QueryBuilders.termQuery(ObjDevGreatSearch.FD_SORT, subtype));
        }

        boolean isKeyAdd = false;
        boolean termQuery = false;
        if (keyword.endsWith("*")) {
            qb.must(QueryBuilders.prefixQuery(ObjDevGreatSearch.FD_WORD,
                    keyword.substring(0, keyword.length() - 1)));
            isKeyAdd = true;
        }
        if (type == TrackCatelog.CERT && subtype != null) {
            qb.must(QueryBuilders.wildcardQuery(ObjDevGreatSearch.FD_NAME,
                    String.format("*%s*", keyword)));
            isKeyAdd = true;
        }
        if (!isKeyAdd) {
            switch (type) {
                case CERT:
                    if (keyword.length() == 18 || (keyword.length() == 15)) {
                        termQuery = true;
                    }
                    break;
                case MAC:
                    if (keyword.length() == 17) {
                        termQuery = true;
                    }
                    break;
                case MOBILE:
                    if (keyword.length() == 11) {
                        termQuery = true;
                    }
                    break;
                default:
                    break;
            }
            if (termQuery) {
                qb.must(QueryBuilders.termQuery(ObjDevGreatSearch.FD_WORD, keyword));
            } else {
                qb.must(QueryBuilders.wildcardQuery(ObjDevGreatSearch.FD_WORD,
                        String.format("*%s*", keyword)));
            }

        }

        SearchResponse response = client.prepareSearch("police." + ObjDevGreatSearch.OBJECT_NAME)
                .setTypes(ObjDevGreatSearch.OBJECT_NAME).setQuery(qb).setFrom(rowStart)
                .setSize(rowCount).get();
        ESResult<DevGreatSearch> result = ESUtil.fetch(response, DevGreatSearch.class);
        return result;
    }


    public Person findInfo(String searchid) {
        Person p = new Person();
        p.setId(searchid);
        SearchResponse response = client.prepareSearch("police." + ObjDevTrack.OBJECT_NAME)
                .setTypes(ObjDevTrack.OBJECT_NAME)
                .setQuery(QueryBuilders.termQuery(ObjDevTrack.FD_SEARCH_ID, searchid)).setSize(20).get();
        ESResult<DevTrack> result = ESUtil.fetch(response, DevTrack.class);
        List<DevTrack> tracks = result.getData();
        tracks.stream().filter(l -> TrackCatelog.CERT.getIndex() == l.getCatelog()).limit(1)
                .forEach(t -> {
                    p.setPid(t.getKeyword());
                    p.setName(t.getUsername());
                });
        p.setMobiles(tracks.stream().filter(l -> TrackCatelog.MOBILE.getIndex() == l.getCatelog())
                .map(DevTrack::getKeyword).collect(toSet()));
        p.setMacs(tracks.stream().filter(l -> TrackCatelog.MAC.getIndex() == l.getCatelog())
                .map(DevTrack::getKeyword).collect(toSet()));
        p.setVirtuals(tracks.stream().filter(l -> TrackCatelog.VIRTUAL.getIndex() == l.getCatelog())
                .map(l -> {
                    Map<String, String> m = new HashMap<>();
                    m.put("virtype", l.getSubCatelog());
                    m.put("virval", l.getKeyword());
                    return m;
                }).collect(toSet()));
        return p;
    }

    public List<Map<String, Object>> macTrace(long start, long end, String mac) {
        List<DevMac> result = findTraceInternal(start, end, mac);
        return result.stream().map(a -> {
            Map<String, Object> m = new HashMap<>();
            m.put("online_time", a.getOnlineTime());
            m.put("service_code", a.getServiceCode());
            return m;
        }).collect(Collectors.toList());
    }

    private List<DevMac> findTraceInternal(long start, long end, String mac) {
        BoolQueryBuilder qb = initRangeBoolQB(start, end, ObjDevMac.FD_ONLINE_TIME);
        qb.must(QueryBuilders.termQuery(ObjDevMac.FD_MAC, mac));
        SearchResponse response = client.prepareSearch("police.dev_mac")
                .setTypes(ObjDevMac.OBJECT_NAME).setQuery(qb).get();
        ESResult<DevMac> result = ESUtil.fetch(response, DevMac.class);
        if(result.getTotal() > result.getCurrent()) {
            response = client.prepareSearch("police.dev_mac")
                    .setTypes(ObjDevMac.OBJECT_NAME).setQuery(qb).setSize((int) result.getTotal()).get();
            result = ESUtil.fetch(response, DevMac.class);
        }
        return result.getData();
    }


    public List<Map<String, Object>> fulTrace(long start, long end, String pid, String mobile)
            throws NSException {
        BoolQueryBuilder qb = initRangeBoolQB(start, end, ObjDevFulSearch.FD_ONLINE_TIME);
        qb.must(QueryBuilders.boolQuery()
                .should(QueryBuilders.termQuery(ObjDevFulSearch.FD_MOBILE, mobile))
                .should(QueryBuilders.termQuery(ObjDevFulSearch.FD_PID, pid)));
        SearchResponse response = client.prepareSearch("police.dev_fulsearch")
                .setTypes(ObjDevMac.OBJECT_NAME).setQuery(qb).get();
        ESResult<DevFulsearch> result = ESUtil.fetch(response, DevFulsearch.class);
        return result.getData().stream().map(a -> {
            Map<String, Object> m = new HashMap<>();
            m.put("online_time", format(Long.parseLong(a.getOnlineTime())));
            m.put("service_code", a.getServiceCode());
            return m;
        }).collect(Collectors.toList());
    }


    public String findMacFromMobile(String mobile) throws NSException {
        QueryBuilder qb = QueryBuilders.termQuery(ObjDevMobile.FD_MOBILE, mobile);
        SearchResponse response = client.prepareSearch("police.dev_mobile")
                .setTypes(ObjDevMobile.OBJECT_NAME).setQuery(qb).get();
        ESResult<DevMobile> result = ESUtil.fetch(response, DevMobile.class);

        if (!result.getData().isEmpty()) {
            return result.getData().get(0).getMac();
        } else {
            return null;
        }
    }



    public String findImgPath(String[] infos) throws NSException {
        String pid = infos[1];
        int time = Integer.parseInt(infos[2]);
        List<DevPhoto> ds = findImgs(pid, time);
        if (ds.size() == 0)
            return null;
        DevPhoto photo = ds.get(0);
        return String.format("/user/img/%s/%s/%s", photo.getRelatePath(), photo.getServiceCode(),
                photo.getMimeName());
    }

    private List<DevPhoto> findImgs(String pid, long time) {
        BoolQueryBuilder qb = initRangeBoolQB(time - 24 * 60 * 60, time + 2 * 24 * 60 * 60,
                ObjDevPhoto.FD_ONLINE_TIME);
        qb.must(QueryBuilders.termQuery(ObjDevPhoto.FD_PID, pid));
        SearchResponse response =
                client.prepareSearch("police.dev_photo").setTypes(ObjDevPhoto.OBJECT_NAME)
                        .setQuery(qb).addSort(ObjDevPhoto.FD_ONLINE_TIME, SortOrder.DESC).get();
        ESResult<DevPhoto> result = ESUtil.fetch(response, DevPhoto.class);
        return result.getData();
    }



    public List<Map<String, Object>> relation(List<Map<String, String>> virtuals)
            throws NSException {
        BoolQueryBuilder qb = QueryBuilders.boolQuery();
        for (Map<String, String> virtual : virtuals) {
            BoolQueryBuilder sub = QueryBuilders.boolQuery();
            sub.must(QueryBuilders.termQuery(ObjIMRelate.FD_IM_TYPE, virtual.get("virtype")));
            sub.must(QueryBuilders.termQuery(ObjIMRelate.FD_SELF_ID, virtual.get("virval")));
            qb.should(sub);
        }
        SearchResponse response = client.prepareSearch("police.dev_im_relate")
                .setTypes(ObjIMRelate.OBJECT_NAME).setQuery(qb).get();
        List<DevImRelate> list = ESUtil.<DevImRelate>fetch(response, DevImRelate.class).getData();
        Map<String, Map<String, List<DevImRelate>>> rels = list.stream()
                .collect(groupingBy(DevImRelate::getSelfId, groupingBy(DevImRelate::getImType)));
        List<Map<String, Object>> result = rels.entrySet().stream().map(a -> {
            String selfId = a.getKey();
            Map<String, List<DevImRelate>> subMap = a.getValue();
            List<Map<String, Object>> res = subMap.entrySet().stream().map(b -> {
                String imType = b.getKey();
                List<DevImRelate> relList = b.getValue();
                Map<String, Object> e = new HashMap<>();
                e.put("virval", selfId);
                e.put("virtype", imType);
                e.put("relations",
                        relList.stream().map(DevImRelate::getContactId).collect(toList()));
                return e;
            }).collect(toList());
            return res;
        }).flatMap(Collection::stream).collect(toList());
        return result;
    }


    public List<Map<String, Object>> findChat(String type, String val, long start, long end,
            int rowStart, int rowCount) throws NSException {
        BoolQueryBuilder qb = buildChatCommonQB(type, val, start, end);

        SearchResponse response =
                client.prepareSearch("police.dev_im_msg").setTypes(ObjIMMsg.OBJECT_NAME)
                        .setQuery(qb).setFrom(rowStart).setSize(rowCount).get();
        ESResult<DevImMsg> esresult = ESUtil.fetch(response, DevImMsg.class);
        return esresult.getData().stream().map(l -> {
            Map<String, Object> m = new HashMap<>();
            m.put("from_id", l.getFromId());
            m.put("to_id", l.getToId());
            m.put("grp_no", l.getGrpNo());
            m.put("sc", l.getServiceCode());
            m.put("send_time", l.getSendTime());
            m.put("msg", l.getContent());
            return m;
        }).collect(toList());
    }


    public long findChatTotal(String type, String val, long start, long end) throws NSException {
        BoolQueryBuilder qb = buildChatCommonQB(type, val, start, end);

        SearchResponse response = client.prepareSearch("police.dev_im_msg")
                .setTypes(ObjIMMsg.OBJECT_NAME).setQuery(qb).setSize(0).get();
        ESResult<DevImMsg> esresult = ESUtil.fetch(response, DevImMsg.class);
        return esresult.getTotal();
    }

    private BoolQueryBuilder buildChatCommonQB(String type, String val, long start, long end) {
        BoolQueryBuilder qb = initRangeBoolQB("" + start, "" + end, ObjIMMsg.FD_SEND_TIME);
        switch (type) {
            case "person":
                BoolQueryBuilder sub = QueryBuilders.boolQuery();
                sub.should(QueryBuilders.wildcardQuery(ObjIMMsg.FD_FROM_ID,
                        String.format("*%s*", val)));
                sub.should(QueryBuilders.wildcardQuery(ObjIMMsg.FD_TO_ID,
                        String.format("*%s*", val)));
                qb.must(sub);
                break;
            case "group":
                qb.must(QueryBuilders.wildcardQuery(ObjIMMsg.FD_GRP_NO,
                        String.format("*%s*", val)));
                break;
            case "content":
                qb.must(QueryBuilders.wildcardQuery(ObjIMMsg.FD_CONTENT,
                        String.format("*%s*", val)));
                break;
            default:;
        }
        return qb;
    }


    public List<Map<String, Object>> findVirtById(String pid, String mobile) throws NSException {
        BoolQueryBuilder qb = QueryBuilders.boolQuery();
        if (StringUtils.isNotBlank(mobile)) {
            BoolQueryBuilder subqb = QueryBuilders.boolQuery()
                    .must(QueryBuilders.termQuery(ObjDevVirtLookup.FD_ACCOUNT_CODE, mobile))
                    .must(QueryBuilders.termQuery(ObjDevVirtLookup.FD_ACCOUNT_TYPE,
                            AuthenticateType.MOBILE));
            if (StringUtils.isNotBlank(mobile)) {
                qb = subqb;
            } else {
                qb.should(subqb);
            }
        }
        if (StringUtils.isNotBlank(pid)) {
            BoolQueryBuilder subqb = QueryBuilders.boolQuery()
                    .must(QueryBuilders.termQuery(ObjDevVirtLookup.FD_ACCOUNT_CODE, pid))
                    .mustNot(QueryBuilders.termQuery(ObjDevVirtLookup.FD_ACCOUNT_TYPE,
                            AuthenticateType.MOBILE));
            qb.should(subqb);
        }

        SearchResponse response = client.prepareSearch("police.dev_virt_lookup")
                .setTypes(ObjDevVirtLookup.OBJECT_NAME).setQuery(qb).get();
        ESResult<DevVirtLookup> result = ESUtil.fetch(response, DevVirtLookup.class);

        return result.getData().stream().map(l -> {
            Map<String, Object> m = new HashMap<>();
            m.put("cert_type", l.getCertType());
            m.put("cert_id", l.getCertId());
            return m;
        }).collect(Collectors.toList());
    }


    public List<String> findImgs(long start, long end, String pid) throws NSException {
        List<DevPhoto> icons = findImgs(pid, start - ONE_DAY_SECONDS);
        return icons.stream().map(l -> String.format("/user/img/%s/%s/%s", l.getRelatePath(),
                l.getServiceCode(), l.getMimeName())).collect(Collectors.toList());
    }

    public List<DevGreatSearch> findGSInternal(String keyword) {
        TermQueryBuilder qb = QueryBuilders.termQuery(ObjDevGreatSearch.FD_WORD, keyword);
        SearchResponse response = client.prepareSearch("police.dev_greatsearch")
                .setTypes(ObjDevGreatSearch.OBJECT_NAME).setQuery(qb).get();
        ESResult<DevGreatSearch> result = ESUtil.fetch(response, DevGreatSearch.class);
        return result.getData();
    }

 // TODO delete in future
    public List<SummaryResponse> summary(String type, String val, long start, long end,
            int rowStart, int rowCount) {
        ESResult<DevFulsearch> esresult = null;
        if ("mac".equals(type)) {
            val = findMobileFromMac(val);
            if (StringUtils.isNotBlank(val)) {
                type = "mobile";
            } else {
                return null;
            }
        }
        switch (type) {
            case "pid":
                esresult = summaryByPid(val, start, end, rowStart, rowCount);
                break;
            case "mobile":
                esresult = summaryByMobile(val, start, end, rowStart, rowCount);
                break;
            case "name":
                esresult = summaryByName(val, start, end, rowStart, rowCount);
                break;
            case "pids":
                esresult = summaryByPids(val, start, end, rowStart, rowCount);
                break;
            default:
                return null;
        }
        Map<String, SummaryResponse> result = new HashMap<>();

        for (DevFulsearch e : esresult.getData()) {
            String key = null;
            switch (type) {
                case "pid":
                case "pids":
                    key = e.getPid();
                    break;
                case "mobile":
                    key = e.getMobile();
                    break;
                case "name":
                    key = e.getName();
                    break;
            }
            SummaryResponse resp;
            if (!result.containsKey(key)) {
                resp = new SummaryResponse();
                resp.setPid(e.getPid());
                resp.setName(e.getName());
                resp.setMobile(e.getMobile());
                result.put(key, resp);
            } else {
                resp = result.get(key);
            }
            if (resp.getIcon() == null && e.getPid() != null) {
                resp.setIcon(String.format("%s-%s-%s", e.getServiceCode(), e.getPid(),
                        e.getOnlineTime()));
            }
        }
        return new ArrayList<SummaryResponse>(result.values());
    }

    private ESResult<DevFulsearch> summaryByPid(String val, long start, long end, int rowStart,
            int rowCount) {
        BoolQueryBuilder qb =
                initRangeBoolQB("" + start, "" + end, ObjDevFulSearch.FD_ONLINE_TIME);
        if (val.length() == 15 || val.length() == 18) {
            qb.must(QueryBuilders.termQuery(ObjDevFulSearch.FD_PID, val));
        } else if (val.endsWith("*")) {
            qb.must(QueryBuilders.prefixQuery(ObjDevFulSearch.FD_PID,
                    val.substring(0, val.length() - 1)));
        } else {
            qb.must(QueryBuilders.wildcardQuery(ObjDevFulSearch.FD_PID,
                    String.format("*%s*", val)));
        }
        return fetchFromFulSearch(qb, rowStart, rowCount);
    }

    private ESResult<DevFulsearch> summaryByMobile(String val, long start, long end, int rowStart,
            int rowCount) {
        BoolQueryBuilder qb =
                initRangeBoolQB("" + start, "" + end, ObjDevFulSearch.FD_ONLINE_TIME);
        if (val.length() == 11) {
            qb.must(QueryBuilders.termQuery(ObjDevFulSearch.FD_MOBILE, val));
        } else if (val.endsWith("*")) {
            qb.must(QueryBuilders.prefixQuery(ObjDevFulSearch.FD_MOBILE,
                    val.substring(0, val.length() - 1)));
        } else {
            qb.must(QueryBuilders.wildcardQuery(ObjDevFulSearch.FD_MOBILE,
                    String.format("*%s*", val)));
        }
        return fetchFromFulSearch(qb, rowStart, rowCount);
    }

    private ESResult<DevFulsearch> summaryByName(String val, long start, long end, int rowStart,
            int rowCount) {
        BoolQueryBuilder qb =
                initRangeBoolQB("" + start, "" + end, ObjDevFulSearch.FD_ONLINE_TIME);
        if (val.endsWith("*")) {
            qb.must(QueryBuilders.prefixQuery(ObjDevFulSearch.FD_NAME,
                    val.substring(0, val.length() - 1)));
        } else {
            qb.must(QueryBuilders.wildcardQuery(ObjDevFulSearch.FD_NAME,
                    String.format("*%s*", val)));
        }

        return fetchFromFulSearch(qb, rowStart, rowCount);
    }

    private ESResult<DevFulsearch> summaryByPids(String val, long start, long end, int rowStart,
            int rowCount) {
        BoolQueryBuilder qb =
                initRangeBoolQB("" + start, "" + end, ObjDevFulSearch.FD_ONLINE_TIME);
        String[] pids = val.split(",");
        BoolQueryBuilder qbOfPid = QueryBuilders.boolQuery();
        for (String pid : pids) {
            qbOfPid.should(QueryBuilders.termQuery(ObjDevFulSearch.FD_PID, pid));
        }
        qb.must(qbOfPid);
        return fetchFromFulSearch(qb, rowStart, rowCount);
    }

    private ESResult<DevFulsearch> fetchFromFulSearch(QueryBuilder qb, int rowStart, int rowCount) {
        SearchResponse response =
                client.prepareSearch("police.dev_fulsearch").setTypes(ObjDevFulSearch.OBJECT_NAME)
                        .setQuery(qb).setFrom(rowStart).setSize(rowCount).get();
        return ESUtil.fetch(response, DevFulsearch.class);
    }

    public List<Map<String, Object>> findIdFromVirt(String account) throws NSException {
        QueryBuilder qb = QueryBuilders.wildcardQuery(ObjDevVirtLookup.FD_ACCOUNT_CODE,
                String.format("*%s*", account));
        SearchResponse response = client.prepareSearch("police.dev_virt_lookup")
                .setTypes(ObjDevVirtLookup.OBJECT_NAME).setQuery(qb).get();
        ESResult<DevVirtLookup> result = ESUtil.fetch(response, DevVirtLookup.class);

        return result.getData().stream().map(l -> {
            Map<String, Object> m = new HashMap<>();
            m.put("cert_type", l.getCertType());
            m.put("cert_id", l.getCertId());
            return m;
        }).collect(Collectors.toList());
    }
    
    public String findMobileFromMac(String mac) {
        QueryBuilder qb = QueryBuilders.termQuery(ObjDevMobile.FD_MAC, mac);
        SearchResponse response = client.prepareSearch("police.dev_mobile")
                .setTypes(ObjDevMobile.OBJECT_NAME).setQuery(qb).setFrom(0).setSize(1).get();
        ESResult<DevMobile> result = ESUtil.fetch(response, DevMobile.class);

        if (!result.getData().isEmpty()) {
            return result.getData().get(0).getMobile();
        } else {
            return null;
        }
    }
}
