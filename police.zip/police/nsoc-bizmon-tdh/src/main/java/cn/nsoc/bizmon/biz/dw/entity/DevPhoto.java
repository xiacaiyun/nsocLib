package cn.nsoc.bizmon.biz.dw.entity;

import com.google.gson.annotations.SerializedName;

import cn.nsoc.nspider.app.police.entity.objects.ObjDevPhoto;


public class DevPhoto {
	
	@SerializedName(ObjDevPhoto.FD_SERVICE_CODE) 
	private String serviceCode;
	@SerializedName(ObjDevPhoto.FD_MIME_NAME) 
	private String mimeName;
	@SerializedName(ObjDevPhoto.FD_RELATE_PATH) 
	private String relatePath;
	public String getServiceCode() {
		return serviceCode;
	}
	public void setServiceCode(String serviceCode) {
		this.serviceCode = serviceCode;
	}
	public String getMimeName() {
		return mimeName;
	}
	public void setMimeName(String mimeName) {
		this.mimeName = mimeName;
	}
	public String getRelatePath() {
		return relatePath;
	}
	public void setRelatePath(String relatePath) {
		this.relatePath = relatePath;
	}
	
}
