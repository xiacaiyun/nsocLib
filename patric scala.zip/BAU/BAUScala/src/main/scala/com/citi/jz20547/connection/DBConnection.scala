package com.citi.jz20547.connection

import java.sql.{Connection, DriverManager, ResultSet, Statement}
import java.util.ResourceBundle


object DBConnection {
  val ORACLE_DEV = "oracle_dev"
  val ORACLE_SIT = "oracle_sit"
  val ORACLE_UAT2 = "oracle_uat2"
  val TERADATA_DEV = "teradata_dev"

  def close(conn: Connection): Unit = {
    if (conn != null) {
      conn.close()
    }
  }

  def close(conn: Connection, stat: Statement, rs: ResultSet): Unit = {

    if (rs != null) {
      rs.close()
    }
    if (stat != null) {
      stat.close()
    }
    if (conn != null) {
      conn.close()
    }
  }

  def getConnection(filename: String): Connection = {
    val reader = ResourceBundle.getBundle(filename)
    //oracle_dev=>oracle.dev.
    val prefix = filename.replace("_", ".") + "."

    val driver = reader.getString(prefix + "driver")
    val url = reader.getString(prefix + "url")
    val username = reader.getString(prefix + "username")
    val password = reader.getString(prefix + "password")
    Class.forName(driver)
    DriverManager.getConnection(url, username, password)
  }

}