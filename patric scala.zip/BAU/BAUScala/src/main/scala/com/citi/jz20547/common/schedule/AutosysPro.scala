package com.citi.jz20547.common.schedule

import java.io.{File, PrintWriter}
import java.sql.Connection

import com.citi.jz20547.connection.DBConnection

import scala.collection.mutable
import scala.collection.mutable.ArrayBuffer
import scala.io.Source

object AutosysPro {

  val devConn: Connection = DBConnection.getConnection(DBConnection.ORACLE_DEV)
  val uatConn: Connection = DBConnection.getConnection(DBConnection.ORACLE_UAT2)

  def main(args: Array[String]): Unit = {
    val path = "C:\\Users\\zw03211\\Code\\TWS_Pro.txt"
    // read input file
    val lines = Source.fromFile(path).getLines()
    // convert file into lines
    var plist = ArrayBuffer[List[String]]()
    for (line <- lines) {
      val list = line.split("\t").toList
      plist += list
    }

    // i stands for 0-10 position for countries
    // TH	VN	SG	PH	GU	MY	ID	AU	CN	HK	MO
    for (i <- 0 to 10) {

      val country = findCountry(i)
      // UAT2 for now
      val devSql = s"SELECT V_PARAM_CODE,V_PARAM_VALUE FROM TEST_AUTOSYS_PARAMS WHERE S_ENV_CDE='UAT2' AND S_CNTRY_CDE='$country'"
      val map = queryForParameters(devSql)
      // server name eg:mwgtc-dwhlc03u.nam.nsroot.net
      val machine = map("machine")
      // pbrun user eg:udwcnap1
      val owner = map("owner")
      // country full name eg:china
      val fullCountry = map("country")
      // job number eg:166880
      val number = map("number")

      val w = new PrintWriter(new File(s"C:\\Users\\zw03211\\Code\\Result1\\$country.txt"))

      for (p <- plist) {
        if (p(i) == "Y") {
          mainFactory(w, p.drop(11), country, machine, owner, fullCountry, number)
        }
      }
      w.flush()
      w.close()
    }
    devConn.close()
    uatConn.close()
  }

  def mainFactory(w: PrintWriter, p: List[String], country: String, machine: String, owner: String, fullCountry: String, number: String): Unit = {
    // mode y file watch eg: .ACK and several conditions
    // mode n no file watch, >=0 conditions
    val mode = p.head
    // segment code eg:DWH, ORP
    val seg = p(1)
    // pgm code eg:BMF677
    val pgm = p(2)
    // schedule name eg:LX_DWH_D5
    val schedule = p(3)
    // job name eg:LX_DWH-GC_BK_SB_BMF677
    val job = p(4)
    // table name eg:DRI_MF_SAA_D
    val table = p(5)
    val jobList = p.drop(6)

    // country code eg:156
    val code = findCode(country)
    val uatSql = s"SELECT V_DPND_FILE_NAM FROM RAW_INFO_DRIVER WHERE I_PASS_NO=(SELECT I_PASS_NO FROM JOB_MASTER WHERE V_PGM_CDE='$pgm' AND S_SEG_CDE='$seg' AND S_CNTRY_CDE=$code)AND S_SEG_CDE='$seg' AND S_CNTRY_CDE=$code AND ROWNUM=1"
    // dependency file name eg:/vietnam/workpath/daily/current/RMVN.BMF.DNLOAD.DWHSAA.ACK
    val head = "U" + country
    val boxName = s"${number}_$head$schedule"
    val fullName = s"$boxName.$head$job"

    var followJobs = new String()
    if (jobList.nonEmpty) {
      if (jobList.size % 2 != 0) {
        println("!!!!!!!!!!!!!! missing job or schedule")
        System.exit(-1)
      }
      for (i <- jobList.indices if i % 2 == 0) {
        val fSchedule = jobList(i)
        val fJob = jobList(i + 1)
        followJobs += s" & s(${number}_$head$fSchedule.$head$fJob)"
      }
    }

    var condition = new String()
    var file = new String()
    if ("y".equals(mode)) {
      file = queryForDependencyFile(uatSql)
      condition = s"\ncondition: s(${fullName}_FW)$followJobs"
    }
    if ("n".equals(mode) && jobList.nonEmpty) {
      condition = "\ncondition: " + followJobs.substring(3)
    }


    val fileWatcherJob =
      s"""
         |/* ----------------- ${fullName}_FW ----------------- */ \n
         |insert_job: ${fullName}_FW   job_type: FW
         |box_name: ${boxName}_BOX
         |machine: $machine
         |owner: $owner
         |permission:
         |date_conditions: 0
         |alarm_if_fail: 1
         |watch_file: \"$file\"
         |watch_interval: 60
         |
         |""".stripMargin

    val commandJob =
      s"""
         |/* ----------------- $fullName ----------------- */ \n
         |insert_job: $fullName   job_type: CMD
         |box_name: ${boxName}_BOX
         |command: \"/application/dwh/devfid/dw_schdinvctr.sh $code $seg $pgm\"
         |machine: $machine
         |owner: $owner
         |permission:
         |date_conditions: 0$condition
         |description: \"$table\"
         |std_out_file: \"/$fullCountry/logs/dwh/$${AUTO_JOB_NAME}.$${AUTORUN}.out\"
         |std_err_file: \"/$fullCountry/logs/dwh/$${AUTO_JOB_NAME}.$${AUTORUN}.err\"
         |alarm_if_fail: 1
         |
         |""".stripMargin

    if ("y".equals(mode)) {
      w.write(fileWatcherJob)
      print(fileWatcherJob)
      w.write(commandJob)
      print(commandJob)
    }
    if ("n".equals(mode)) {
      w.write(commandJob)
      print(commandJob)
    }
  }


  def queryForDependencyFile(sql: String): String = {
    val rs = uatConn.createStatement().executeQuery(sql)
    rs.next()
    rs.getObject(1).toString
  }

  def findCountry(x: Int): String = x match {
    case 0 => "TH"
    case 1 => "VN"
    case 2 => "SG"
    case 3 => "PH"
    case 4 => "GU"
    case 5 => "MY"
    case 6 => "ID"
    case 7 => "AU"
    case 8 => "CN"
    case 9 => "HK"
    case 10 => "MO"
  }

  def findCode(x: String): String = x match {
    case "CN" => "156"
    case "HK" => "344"
    case "MO" => "446"
    case "ID" => "360"
    case "AU" => "036"
    case "MY" => "458"
    case "PH" => "680"
    case "SG" => "702"
    case "VN" => "704"
    case "TH" => "764"
    case "GU" => "840"
  }


  def queryForParameters(sql: String): mutable.HashMap[String, String] = {
    var map: mutable.HashMap[String, String] = new mutable.HashMap
    val stat = devConn.createStatement()
    val rs = stat.executeQuery(sql)
    val md = rs.getMetaData
    val columnCount = md.getColumnCount
    while (rs.next()) {
      for (i <- 1 to columnCount if i % 2 == 1) {
        val name = rs.getObject(i).toString
        val value = rs.getObject(i + 1).toString
        map += (name -> value)
      }
    }
    map
  }

}
