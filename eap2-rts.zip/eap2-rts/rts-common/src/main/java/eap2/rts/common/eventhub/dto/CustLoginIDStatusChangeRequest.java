package eap2.rts.common.eventhub.dto;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonProperty;

public class CustLoginIDStatusChangeRequest implements Serializable {
	private static final long serialVersionUID = -6577178006846246774L;
	
	@JsonProperty("Event")
	private EventCustLoginIDStatusChange event;
	
	public EventCustLoginIDStatusChange getEvent() {
		return event;
	}
	public void setEvent(EventCustLoginIDStatusChange event) {
		this.event = event;
	}
	@Override
	public String toString() {
		return "CustLoginIDStatusChangeRequest [event=" + event + "]";
	}
}
