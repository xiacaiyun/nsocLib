package eap2.rts.common.eventhub.dto;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonProperty;

public class RewardRedemptionRequestRequest implements Serializable {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 596509938262677473L;
	@JsonProperty("Event")
	private EventRewardRedemptionRequest event;
	
	public EventRewardRedemptionRequest getEvent() {
		return event;
	}
	public void setEvent(EventRewardRedemptionRequest event) {
		this.event = event;
	}
	@Override
	public String toString() {
		return "RewardRedemptionRequestRequest [event=" + event + "]";
	}
}
