package eap2.rts.common.eventhub.dto;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonProperty;

public class EventChequeBounce implements Serializable {
	private static final long serialVersionUID = -3333418710921501173L;
	
	@JsonProperty("Standard")
	private StandardChequeBounce Standard;
	@JsonProperty("CustomerAccess")
    private CustomerAccessChequeBounce CustomerAccess;
	@JsonProperty("Extended")
    private ExtendedChequeBounce Extended;
	@JsonProperty("Metadata")
    private MetadataChequeBounce Metadata;

    public StandardChequeBounce getStandard ()
    {
        return Standard;
    }

    public void setStandard (StandardChequeBounce Standard)
    {
        this.Standard = Standard;
    }

    public CustomerAccessChequeBounce getCustomerAccess ()
    {
        return CustomerAccess;
    }

    public void setCustomerAccess (CustomerAccessChequeBounce CustomerAccess)
    {
        this.CustomerAccess = CustomerAccess;
    }

    public ExtendedChequeBounce getExtended ()
    {
        return Extended;
    }

    public void setExtended (ExtendedChequeBounce Extended)
    {
        this.Extended = Extended;
    }

    public MetadataChequeBounce getMetadata ()
    {
        return Metadata;
    }

    public void setMetadata (MetadataChequeBounce Metadata)
    {
        this.Metadata = Metadata;
    }

    @Override
    public String toString()
    {
        return "ClassPojo [Standard = "+Standard+", CustomerAccess = "+CustomerAccess+", Extended = "+Extended+", Metadata = "+Metadata+"]";
    }
}
