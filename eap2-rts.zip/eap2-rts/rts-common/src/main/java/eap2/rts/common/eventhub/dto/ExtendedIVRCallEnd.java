package eap2.rts.common.eventhub.dto;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonProperty;

public class ExtendedIVRCallEnd implements Serializable {
	private static final long serialVersionUID = -7155642666356461785L;
	
	@JsonProperty("CallDisposition")
    private String CallDisposition;

	public String getCallDisposition() {
		return CallDisposition;
	}

	public void setCallDisposition(String callDisposition) {
		CallDisposition = callDisposition;
	}

	@Override
	public String toString() {
		return "ClassPojo [CallDisposition=" + CallDisposition + "]";
	}
}
