package eap2.rts.common.eventhub.dto;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonProperty;

public class EventReportLostStolen implements Serializable {
	private static final long serialVersionUID = -8188320421703912065L;
	
	@JsonProperty("Standard")
	private StandardReportLostStolen Standard;
	@JsonProperty("CustomerAccess")
    private CustomerAccessReportLostStolen CustomerAccess;
	@JsonProperty("Extended")
    private ExtendedReportLostStolen Extended;
	@JsonProperty("Metadata")
    private MetadataReportLostStolen Metadata;
	public StandardReportLostStolen getStandard() {
		return Standard;
	}
	public void setStandard(StandardReportLostStolen standard) {
		Standard = standard;
	}
	public CustomerAccessReportLostStolen getCustomerAccess() {
		return CustomerAccess;
	}
	public void setCustomerAccess(CustomerAccessReportLostStolen customerAccess) {
		CustomerAccess = customerAccess;
	}
	public ExtendedReportLostStolen getExtended() {
		return Extended;
	}
	public void setExtended(ExtendedReportLostStolen extended) {
		Extended = extended;
	}
	public MetadataReportLostStolen getMetadata() {
		return Metadata;
	}
	public void setMetadata(MetadataReportLostStolen metadata) {
		Metadata = metadata;
	}
	@Override
	public String toString() {
		return "EventReportLostStolen [Standard=" + Standard + ", CustomerAccess=" + CustomerAccess + ", Extended="
				+ Extended + ", Metadata=" + Metadata + "]";
	}
	
	
}
