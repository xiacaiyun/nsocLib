package eap2.rts.common.eventhub.dto;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonProperty;

public class APINChangeRequest implements Serializable {
	private static final long serialVersionUID = -4682214610374571228L;
	
	@JsonProperty("Event")
	private EventAPINChange event;
	
	public EventAPINChange getEvent() {
		return event;
	}
	public void setEvent(EventAPINChange event) {
		this.event = event;
	}
	@Override
	public String toString() {
		return "APINChangeRequest [event=" + event + "]";
	}
}
