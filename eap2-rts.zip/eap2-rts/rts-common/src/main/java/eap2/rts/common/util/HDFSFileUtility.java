package eap2.rts.common.util;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.FSDataInputStream;
import org.apache.hadoop.fs.FileStatus;
import org.apache.hadoop.fs.FileSystem;
import org.apache.hadoop.fs.FileUtil;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.security.UserGroupInformation;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import eap2.rts.common.SysConstants;

/**
 * @author bs34500
 */
public class HDFSFileUtility {
	protected static final Logger logger = LoggerFactory.getLogger(HDFSFileUtility.class);
	private static HDFSFileUtility _instance = null;
	private Configuration conf = null;
	private FileSystem hdfs = null;
	private Map<String, String> hdfsConfig = null;

	private HDFSFileUtility(Map<String, String> hdfsConfig) throws IOException {
		logger.info("Inside HDFSFileUtility-->HDFSFileUtility.....");
		this.hdfsConfig = hdfsConfig;
		init();
	}

	private void init() throws IOException {
		logger.info("Inside HDFSFileUtility-->init.....");
		conf = new Configuration();
		conf.set(SysConstants.HDFS_MASTER_URL, hdfsConfig.get(SysConstants.HDFS_MASTER_URL));
		conf.addResource(new Path(hdfsConfig.get(SysConstants.HDFS_CORE_SITE_XML_LOCATION)));
		conf.addResource(new Path(hdfsConfig.get(SysConstants.HDFS_SITE_XML_LOCATION)));
		conf.set("fs.hdfs.impl", "org.apache.hadoop.hdfs.DistributedFileSystem");
		conf.set("fs.file.impl", "org.apache.hadoop.fs.LocalFileSystem");
		conf.set("hadoop.security.authentication", "kerberos");
		conf.set("hadoop.security.authorization", "true");
		UserGroupInformation.setConfiguration(conf);
		hdfs = FileSystem.get(conf);
	}

	public static HDFSFileUtility getInstance(Map<String, String> hdfsConfig) throws IOException {
		logger.info("Inside HDFSFileUtility-->getInstance.....");
		if (_instance == null) {
			_instance = new HDFSFileUtility(hdfsConfig);
		}
		return _instance;
	}

	synchronized public String copyFile(String sourcePath, String destPath, String fileType) throws Exception {
		logger.info("Inside HDFSFileUtility-->copyFile.....");
		// create destination path
		Date now = new Date();
		String newDestPath = destPath + "/" + now.getTime();
		createDir(newDestPath);

		if (!sourcePath.contains("*")) {
			sourcePath += "*";
		}

		logger.info(">>>>>>>>> Source Path=" + sourcePath);
		logger.info(">>>>>>>>> New Dest Path =" + newDestPath);

		FileStatus contents[] = hdfs.globStatus(new Path(sourcePath));

		if (contents == null || contents.length == 0) {
			throw new Exception("File Not Found. " + sourcePath);
		}

		for (int i = 0; i < contents.length; i++) {
			FileStatus fs = contents[i];
			if (!fs.isDir()) {
				String destFileName = newDestPath + "/" + fileType + "_" + i + ".avro";
				logger.info(">>>>>>>>>>>>>>>>>>>>>>> Source Path found: " + fs.getPath());
				FileUtil.copy(hdfs, fs.getPath(), hdfs, new Path(destFileName), false, true, conf);
				logger.info(">>>>>>>>>>>>>>>>>>>>>>> Destination path created: " + destFileName);
			}
		}

		return newDestPath;
	}

	synchronized public String copyFile(List<String> sourcePathList, String destPath, String fileType) throws Exception {
		logger.info("Inside HDFSFileUtility-->copyFile.....");
		// create destination path
		Date now = new Date();
		String newDestPath = destPath + "/" + now.getTime();
		createDir(newDestPath);

		if (sourcePathList != null && !sourcePathList.isEmpty()) {
			int count = 1;
			for (String sourcePath : sourcePathList) {

				if (!sourcePath.contains("*")) {
					sourcePath += "*";
				}

				logger.info(">>>>>>>>> Starting Copy from Source Path=" + sourcePath);
				logger.info(">>>>>>>>> Starting Copy in New Dest Path =" + newDestPath);

				FileStatus contents[] = hdfs.globStatus(new Path(sourcePath));

				if (contents == null || contents.length == 0) {
					// throw new Exception("File Not Found. " + sourcePath);
					continue;
				}

				for (int i = 0; i < contents.length; i++) {
					FileStatus fs = contents[i];
					if (!fs.isDir()) {
						logger.info(">>>>>>>>>>>>>>>>>>>>>>> Source Path found: " + fs.getPath());
						String destFileName = newDestPath + "/" + fileType + "_" + count + "_" + i + ".avro";
						logger.info(">>>>>>>>>>>>>>>>>>>>>>> Destination path created: " + destFileName);
						boolean isSuccess = FileUtil.copy(hdfs, fs.getPath(), hdfs, new Path(destFileName), false, false, conf);
						logger.info(">>>>>>>>>>>>>>>>>>>>>>> Copy Source Path Sucess (True/False): " + isSuccess);
						count++;
					} else {
						logger.info(">>>>>>>>>>>>>>>>>>>>>>> Skipping copy as source path is a directry: " + fs.getPath());
					}
				}
			}
		}

		return newDestPath;
	}

	/**
	 * @param dirName
	 * @return
	 * @throws IOException
	 */
	@SuppressWarnings("deprecation")
	synchronized public boolean IsDirExist(String dirName) throws IOException {
		return hdfs.isDirectory(new Path(dirName));
	}

	/**
	 * @param dirName
	 * @throws IOException
	 */
	synchronized public void createDir(String dirName) throws IOException {
		if (!IsDirExist(dirName)) {
			hdfs.mkdirs(new Path(dirName));
		}
	}

	/**
	 * @param dirName
	 * @throws IOException
	 */
	@SuppressWarnings("deprecation")
	synchronized public void deleteDir(String dirName) throws IOException {
		if (IsDirExist(dirName)) {
			hdfs.delete(new Path(dirName));
		}
	}

	/**
	 * @param datasetSourceDir
	 * @param datasetArchiveDir
	 * @throws IOException
	 */
	synchronized public void moveDir(String datasetSourceDir, String datasetArchiveDir) throws IOException {
		hdfs.rename(new Path(datasetSourceDir), new Path(datasetArchiveDir));
	}

	synchronized public List<String> renameAVROFiles(String fromPath, String toPath, String datasetName, String asOfDate, String procExecId)
			throws IOException {
		logger.info(">>>>>>>>>>>Inside HDFSFileUtility-->renameAVROFiles.....");
		List<String> fileList = new ArrayList<String>();
		String datasetFolder = toPath + "/" + datasetName + ".avro";
		String asOfDatePartition = datasetFolder + "/GBL_ASOFDATE=" + asOfDate;
		String procExecIdPartition = asOfDatePartition + "/GBL_PROCEXEC_ID=" + procExecId;
		createDir(toPath);
		createDir(datasetFolder);
		createDir(asOfDatePartition);
		createDir(procExecIdPartition);

		logger.info("Moving from temp location " + fromPath + " to " + procExecIdPartition);

		String avrofileName = datasetName + "." + procExecId + ".avro";

		FileStatus contents[] = hdfs.globStatus(new Path(fromPath + "/*.avro"));

		if (contents == null || contents.length == 0) {
			System.out.println("No avro file found at location: " + fromPath);
			return fileList;
		}

		for (int i = 0; i < contents.length; i++) {
			FileStatus fs = contents[i];
			if (!fs.isDir()) {
				String newPathName = procExecIdPartition + "/" + avrofileName + "_" + System.nanoTime();
				hdfs.rename(fs.getPath(), new Path(newPathName));
				fileList.add(newPathName);
				logger.info("Avro File created : " + newPathName);
			}
		}
		return fileList;
	}

	public String readHDFSFileAsString(String hdfsFileNameWithPath) throws IOException {
		StringBuilder aString = new StringBuilder();
		FSDataInputStream is = hdfs.open(new Path(hdfsFileNameWithPath));
		BufferedReader br = new BufferedReader(new InputStreamReader(is));
		String line = br.readLine();
		while (line != null) {
			aString.append(line);
			line = br.readLine();
		}
		return aString.toString();
	}
}