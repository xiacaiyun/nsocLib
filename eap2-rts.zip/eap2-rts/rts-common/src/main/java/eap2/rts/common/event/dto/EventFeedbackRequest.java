package eap2.rts.common.event.dto;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonProperty;

public class EventFeedbackRequest implements Serializable {

	private static final long serialVersionUID = -1711178992842851343L;

	private String TimeStamp;
	private String CustomerID;
	private String CoutryCode;
	private String ReasonCode;
	private String ReasonDescription;
	private String SourceSystemId;
	private String OrganizationCode;
	private String MisDate;

	@JsonProperty("feedback_time")
	public String getTimeStamp() {
		return TimeStamp;
	}

	@JsonIgnore
	public void setTimeStamp(String timeStamp) {
		TimeStamp = timeStamp;
	}

	@JsonProperty("clnt_nbr")
	public String getClnt_Nbr() {
		return CustomerID;
	}

	@JsonProperty("CustomerID")
	public void setCustomerID(String customerID) {
		CustomerID = customerID;
	}

	@JsonProperty("cntry_cde")
	public String getCntry_Cde() {
		return CoutryCode;
	}

	@JsonProperty("CoutryCode")
	public void setCoutryCode(String coutryCode) {
		CoutryCode = coutryCode;
	}

	@JsonProperty("feedback_rsn_cde")
	public String getFeedback_Rsn_Cde() {
		return ReasonCode;
	}

	@JsonProperty("ReasonCode")
	public void setReasonCode(String reasonCode) {
		ReasonCode = reasonCode;
	}

	@JsonProperty("feedback_rsn")
	public String getFeedback_Rsn() {
		return ReasonDescription;
	}

	@JsonProperty("ReasonDescription")
	public void setReasonDescription(String reasonDescription) {
		ReasonDescription = reasonDescription;
	}

	@JsonProperty("src_sys_id")
	public String getSrc_Sys_Id() {
		return SourceSystemId;
	}

	@JsonIgnore
	public void setSourceSystemId(String sourceSystemId) {
		SourceSystemId = sourceSystemId;
	}

	@JsonProperty("biz_org_cde")
	public String getBiz_Org_Cde() {
		return OrganizationCode;
	}

	@JsonIgnore
	public void setOrganizationCode(String organizationCode) {
		OrganizationCode = organizationCode;
	}

	@JsonProperty("mis_dt")
	public String getMis_Dt() {
		return MisDate;
	}

	@JsonIgnore
	public void setMisDate(String misDate) {
		MisDate = misDate;
	}

	@Override
	public String toString() {
		return "EventFeedbackRequest [CustomerID=" + CustomerID + ", CoutryCode=" + CoutryCode + ", ReasonCode=" + ReasonCode + ", ReasonDescription="
				+ ReasonDescription + ", TimeStamp=" + TimeStamp + ", SourceSystemId=" + SourceSystemId + ", OrganizationCode=" + OrganizationCode
				+ ", MisDate=" + MisDate + "]";
	}
}
