package eap2.rts.common.eventhub.dto;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonProperty;

public class ChequeStopPaymentRequest implements Serializable {
	private static final long serialVersionUID = -1162955202048286270L;
	
	@JsonProperty("Event")
	private EventChequeStopPayment event;
	
	public EventChequeStopPayment getEvent() {
		return event;
	}
	public void setEvent(EventChequeStopPayment event) {
		this.event = event;
	}
	@Override
	public String toString() {
		return "ChequeStopPaymentRequest [event=" + event + "]";
	}
}
