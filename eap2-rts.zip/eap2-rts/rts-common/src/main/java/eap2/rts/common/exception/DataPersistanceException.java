package eap2.rts.common.exception;

public class DataPersistanceException extends Exception {
	private static final long serialVersionUID = 2779204538253767033L;

	public DataPersistanceException() {

	}

	public DataPersistanceException(String arg0) {
		super(arg0);
	}

	public DataPersistanceException(Throwable arg0) {
		super(arg0);
	}

	public DataPersistanceException(String arg0, Throwable arg1) {
		super(arg0, arg1);
	}

	public DataPersistanceException(String arg0, Throwable arg1, boolean arg2, boolean arg3) {
		super(arg0, arg1, arg2, arg3);
	}

}
