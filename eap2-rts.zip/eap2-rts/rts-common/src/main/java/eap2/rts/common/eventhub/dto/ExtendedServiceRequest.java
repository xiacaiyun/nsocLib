package eap2.rts.common.eventhub.dto;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonProperty;

public class ExtendedServiceRequest implements Serializable{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = -5472847420608376195L;
	@JsonProperty("Subject")
    private String Subject;
	@JsonProperty("ESMSUDPprocesscode")
    private String ESMSUDPprocesscode;
	@JsonProperty("MISGroupDescription")
    private String MISGroupDescription;
	@JsonProperty("MISTypeDescription")
    private String MISTypeDescription;
	
	public String getSubject() {
		return Subject;
	}
	public void setSubject(String subject) {
		Subject = subject;
	}
	public String getESMSUDPprocesscode() {
		return ESMSUDPprocesscode;
	}
	public void setESMSUDPprocesscode(String eSMSUDPprocesscode) {
		ESMSUDPprocesscode = eSMSUDPprocesscode;
	}
	public String getMISGroupDescription() {
		return MISGroupDescription;
	}
	public void setMISGroupDescription(String mISGroupDescription) {
		MISGroupDescription = mISGroupDescription;
	}
	public String getMISTypeDescription() {
		return MISTypeDescription;
	}
	public void setMISTypeDescription(String mISTypeDescription) {
		MISTypeDescription = mISTypeDescription;
	}
	@Override
	public String toString() {
		return "ExtendedServiceRequest [Subject=" + Subject + ", ESMSUDPprocesscode=" + ESMSUDPprocesscode
				+ ", MISGroupDescription=" + MISGroupDescription + ", MISTypeDescription=" + MISTypeDescription + "]";
	}


}
