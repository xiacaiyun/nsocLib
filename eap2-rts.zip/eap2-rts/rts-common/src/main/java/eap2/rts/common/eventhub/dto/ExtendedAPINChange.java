package eap2.rts.common.eventhub.dto;

import java.io.Serializable;

public class ExtendedAPINChange implements Serializable {
	private static final long serialVersionUID = -7793388978819005754L;
	
	
}
