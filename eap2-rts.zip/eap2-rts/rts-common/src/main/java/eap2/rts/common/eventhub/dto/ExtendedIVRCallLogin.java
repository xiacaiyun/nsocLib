package eap2.rts.common.eventhub.dto;

import java.io.Serializable;

public class ExtendedIVRCallLogin implements Serializable {
	private static final long serialVersionUID = 2316409634871163884L;
	
}
