package eap2.rts.common.eventhub.dto;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonProperty;

public class CpoCallEndRequest implements Serializable {
	private static final long serialVersionUID = -845815555404374810L;
	
	@JsonProperty("Event")
	private EventCpoCallEnd event;
	
	public EventCpoCallEnd getEvent() {
		return event;
	}
	public void setEvent(EventCpoCallEnd event) {
		this.event = event;
	}
	@Override
	public String toString() {
		return "CpoCallEndRequest [event=" + event + "]";
	}
}
