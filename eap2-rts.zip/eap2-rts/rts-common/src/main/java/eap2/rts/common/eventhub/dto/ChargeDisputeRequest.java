package eap2.rts.common.eventhub.dto;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonProperty;

public class ChargeDisputeRequest implements Serializable {
	private static final long serialVersionUID = 8280504254279738037L;
	
	@JsonProperty("Event")
	private EventChargeDispute event;
	
	public EventChargeDispute getEvent() {
		return event;
	}
	public void setEvent(EventChargeDispute event) {
		this.event = event;
	}
	@Override
	public String toString() {
		return "ChargeDisputeRequest [event=" + event + "]";
	}
}
