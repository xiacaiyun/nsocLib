package eap2.rts.common.eventhub.dto;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonProperty;

public class EventTPINCreateResetChangeIssuance implements Serializable {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 5548754712949376402L;
	@JsonProperty("Standard")
	private StandardTPINCreateResetChangeIssuance Standard;
	@JsonProperty("CustomerAccess")
    private CustomerAccessTPINCreateResetChangeIssuance CustomerAccess;
	@JsonProperty("Extended")
    private ExtendedTPINCreateResetChangeIssuance Extended;
	@JsonProperty("Metadata")
    private MetadataTPINCreateResetChangeIssuance Metadata;
	public StandardTPINCreateResetChangeIssuance getStandard() {
		return Standard;
	}
	public void setStandard(StandardTPINCreateResetChangeIssuance standard) {
		Standard = standard;
	}
	public CustomerAccessTPINCreateResetChangeIssuance getCustomerAccess() {
		return CustomerAccess;
	}
	public void setCustomerAccess(CustomerAccessTPINCreateResetChangeIssuance customerAccess) {
		CustomerAccess = customerAccess;
	}
	public ExtendedTPINCreateResetChangeIssuance getExtended() {
		return Extended;
	}
	public void setExtended(ExtendedTPINCreateResetChangeIssuance extended) {
		Extended = extended;
	}
	public MetadataTPINCreateResetChangeIssuance getMetadata() {
		return Metadata;
	}
	public void setMetadata(MetadataTPINCreateResetChangeIssuance metadata) {
		Metadata = metadata;
	}
	@Override
	public String toString() {
		return "EventTPINCreateResetChangeIssuance [Standard=" + Standard + ", CustomerAccess=" + CustomerAccess
				+ ", Extended=" + Extended + ", Metadata=" + Metadata + "]";
	}
	
	
}