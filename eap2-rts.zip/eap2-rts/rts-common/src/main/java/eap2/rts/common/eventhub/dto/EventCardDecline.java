package eap2.rts.common.eventhub.dto;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonProperty;

public class EventCardDecline implements Serializable {
	private static final long serialVersionUID = 5857290586820495366L;
	
	@JsonProperty("Standard")
	private StandardCardDecline Standard;
	@JsonProperty("CustomerAccess")
    private CustomerAccessCardDecline CustomerAccess;
	@JsonProperty("Extended")
    private ExtendedCardDecline Extended;
	@JsonProperty("Metadata")
    private MetadataCardDecline Metadata;

    public StandardCardDecline getStandard ()
    {
        return Standard;
    }

    public void setStandard (StandardCardDecline Standard)
    {
        this.Standard = Standard;
    }

    public CustomerAccessCardDecline getCustomerAccess ()
    {
        return CustomerAccess;
    }

    public void setCustomerAccess (CustomerAccessCardDecline CustomerAccess)
    {
        this.CustomerAccess = CustomerAccess;
    }

    public ExtendedCardDecline getExtended ()
    {
        return Extended;
    }

    public void setExtended (ExtendedCardDecline Extended)
    {
        this.Extended = Extended;
    }

    public MetadataCardDecline getMetadata ()
    {
        return Metadata;
    }

    public void setMetadata (MetadataCardDecline Metadata)
    {
        this.Metadata = Metadata;
    }

    @Override
    public String toString()
    {
        return "ClassPojo [Standard = "+Standard+", CustomerAccess = "+CustomerAccess+", Extended = "+Extended+", Metadata = "+Metadata+"]";
    }
}
