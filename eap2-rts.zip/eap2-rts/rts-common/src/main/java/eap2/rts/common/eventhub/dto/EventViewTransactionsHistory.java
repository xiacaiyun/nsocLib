package eap2.rts.common.eventhub.dto;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonProperty;

public class EventViewTransactionsHistory implements Serializable {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 4943310874946634823L;
	@JsonProperty("Standard")
	private StandardViewTransactionsHistory Standard;
	@JsonProperty("CustomerAccess")
    private CustomerAccessViewTransactionsHistory CustomerAccess;
	@JsonProperty("Extended")
    private ExtendedViewTransactionsHistory Extended;
	@JsonProperty("Metadata")
    private MetadataViewTransactionsHistory Metadata;
	public StandardViewTransactionsHistory getStandard() {
		return Standard;
	}
	public void setStandard(StandardViewTransactionsHistory standard) {
		Standard = standard;
	}
	public CustomerAccessViewTransactionsHistory getCustomerAccess() {
		return CustomerAccess;
	}
	public void setCustomerAccess(CustomerAccessViewTransactionsHistory customerAccess) {
		CustomerAccess = customerAccess;
	}
	public ExtendedViewTransactionsHistory getExtended() {
		return Extended;
	}
	public void setExtended(ExtendedViewTransactionsHistory extended) {
		Extended = extended;
	}
	public MetadataViewTransactionsHistory getMetadata() {
		return Metadata;
	}
	public void setMetadata(MetadataViewTransactionsHistory metadata) {
		Metadata = metadata;
	}
	@Override
	public String toString() {
		return "EventViewTransactionsHistory [Standard=" + Standard + ", CustomerAccess=" + CustomerAccess
				+ ", Extended=" + Extended + ", Metadata=" + Metadata + "]";
	}
	
	
	
}
