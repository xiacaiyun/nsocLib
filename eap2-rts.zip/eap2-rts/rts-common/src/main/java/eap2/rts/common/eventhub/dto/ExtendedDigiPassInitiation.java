package eap2.rts.common.eventhub.dto;

import java.io.Serializable;

public class ExtendedDigiPassInitiation implements Serializable {
	private static final long serialVersionUID = 6663193466205326208L;
	
	
}
