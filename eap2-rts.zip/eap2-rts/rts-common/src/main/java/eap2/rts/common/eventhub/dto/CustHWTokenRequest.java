package eap2.rts.common.eventhub.dto;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonProperty;

public class CustHWTokenRequest implements Serializable {
	private static final long serialVersionUID = 3473434736300801812L;
	
	@JsonProperty("Event")
	private EventCustHWToken event;
	
	public EventCustHWToken getEvent() {
		return event;
	}
	public void setEvent(EventCustHWToken event) {
		this.event = event;
	}
	@Override
	public String toString() {
		return "CustHWTokenRequest [event=" + event + "]";
	}
}
