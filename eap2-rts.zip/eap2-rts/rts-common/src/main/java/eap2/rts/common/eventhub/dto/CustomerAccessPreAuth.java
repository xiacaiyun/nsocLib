package eap2.rts.common.eventhub.dto;

import java.io.Serializable;

//import com.cloudera.com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonProperty;

public class CustomerAccessPreAuth implements Serializable{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 5904059575024129493L;
	@JsonProperty("ChannelSessionId")
    private String ChannelSessionId;
	@JsonProperty("DeviceType")
    private String DeviceType;
	@JsonProperty("DeviceID")
	private String DeviceID;
	@JsonProperty("DeviceOS")
    private String DeviceOS;
	@JsonProperty("GeoLocLatitude")
    private String GeoLocLatitude;
	@JsonProperty("GeoLocLongitude")
    private String GeoLocLongitude;
	@JsonProperty("BrowserName")
    private String BrowserName;
	@JsonProperty("ClientIPAddress")
    private String ClientIPAddress;
	
    public String getDeviceID ()
    {
        return DeviceID;
    }

    public void setDeviceID (String DeviceID)
    {
        this.DeviceID = DeviceID;
    }

    public String getChannelSessionId ()
    {
        return ChannelSessionId;
    }

    public void setChannelSessionId (String ChannelSessionId)
    {
        this.ChannelSessionId = ChannelSessionId;
    }

    public String getGeoLocLongitude ()
    {
        return GeoLocLongitude;
    }

    public void setGeoLocLongitude (String GeoLocLongitude)
    {
        this.GeoLocLongitude = GeoLocLongitude;
    }

    public String getClientIPAddress ()
    {
        return ClientIPAddress;
    }

    public void setClientIPAddress (String ClientIPAddress)
    {
        this.ClientIPAddress = ClientIPAddress;
    }

    public String getDeviceOS ()
    {
        return DeviceOS;
    }

    public void setDeviceOS (String DeviceOS)
    {
        this.DeviceOS = DeviceOS;
    }

    public String getGeoLocLatitude ()
    {
        return GeoLocLatitude;
    }

    public void setGeoLocLatitude (String GeoLocLatitude)
    {
        this.GeoLocLatitude = GeoLocLatitude;
    }

    public String getBrowserName ()
    {
        return BrowserName;
    }

    public void setBrowserName (String BrowserName)
    {
        this.BrowserName = BrowserName;
    }

    public String getDeviceType ()
    {
        return DeviceType;
    }

    public void setDeviceType (String DeviceType)
    {
        this.DeviceType = DeviceType;
    }

    @Override
    public String toString()
    {
        return "ClassPojo [DeviceID = "+DeviceID+", ChannelSessionId = "+ChannelSessionId+", GeoLocLongitude = "+GeoLocLongitude+", ClientIPAddress = "+ClientIPAddress+", DeviceOS = "+DeviceOS+", GeoLocLatitude = "+GeoLocLatitude+", BrowserName = "+BrowserName+", DeviceType = "+DeviceType+"]";
    }
}
