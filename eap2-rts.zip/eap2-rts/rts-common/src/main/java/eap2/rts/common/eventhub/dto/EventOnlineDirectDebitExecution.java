package eap2.rts.common.eventhub.dto;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonProperty;

public class EventOnlineDirectDebitExecution implements Serializable {
	private static final long serialVersionUID = -4511371558149390143L;
	
	@JsonProperty("Standard")
	private StandardOnlineDirectDebitExecution Standard;
	@JsonProperty("CustomerAccess")
    private CustomerAccessOnlineDirectDebitExecution CustomerAccess;
	@JsonProperty("Extended")
    private ExtendedOnlineDirectDebitExecution Extended;
	@JsonProperty("Metadata")
    private MetadataOnlineDirectDebitExecution Metadata;

    public StandardOnlineDirectDebitExecution getStandard ()
    {
        return Standard;
    }

    public void setStandard (StandardOnlineDirectDebitExecution Standard)
    {
        this.Standard = Standard;
    }

    public CustomerAccessOnlineDirectDebitExecution getCustomerAccess ()
    {
        return CustomerAccess;
    }

    public void setCustomerAccess (CustomerAccessOnlineDirectDebitExecution CustomerAccess)
    {
        this.CustomerAccess = CustomerAccess;
    }

    public ExtendedOnlineDirectDebitExecution getExtended ()
    {
        return Extended;
    }

    public void setExtended (ExtendedOnlineDirectDebitExecution Extended)
    {
        this.Extended = Extended;
    }

    public MetadataOnlineDirectDebitExecution getMetadata ()
    {
        return Metadata;
    }

    public void setMetadata (MetadataOnlineDirectDebitExecution Metadata)
    {
        this.Metadata = Metadata;
    }

    @Override
    public String toString()
    {
        return "ClassPojo [Standard = "+Standard+", CustomerAccess = "+CustomerAccess+", Extended = "+Extended+", Metadata = "+Metadata+"]";
    }
}
