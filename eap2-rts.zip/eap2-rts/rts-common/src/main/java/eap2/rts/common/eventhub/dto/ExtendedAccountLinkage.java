package eap2.rts.common.eventhub.dto;

import java.io.Serializable;

public class ExtendedAccountLinkage implements Serializable {
	private static final long serialVersionUID = -1373889575403398200L;
	
	
	
}
