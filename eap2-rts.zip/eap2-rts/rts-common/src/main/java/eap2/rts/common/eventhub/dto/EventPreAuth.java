package eap2.rts.common.eventhub.dto;

import java.io.Serializable;

//import com.cloudera.com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonProperty;

public class EventPreAuth implements Serializable {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 2029665451028365320L;
	@JsonProperty("Standard")
	private StandardPreAuth Standard;
	@JsonProperty("CustomerAccess")
    private CustomerAccessPreAuth CustomerAccess;
	@JsonProperty("Extended")
    private ExtendedPreAuth Extended;
	@JsonProperty("Metadata")
    private MetadataPreAuth Metadata;
	public StandardPreAuth getStandard() {
		return Standard;
	}
	public void setStandard(StandardPreAuth standard) {
		Standard = standard;
	}
	public CustomerAccessPreAuth getCustomerAccess() {
		return CustomerAccess;
	}
	public void setCustomerAccess(CustomerAccessPreAuth customerAccess) {
		CustomerAccess = customerAccess;
	}
	public ExtendedPreAuth getExtended() {
		return Extended;
	}
	public void setExtended(ExtendedPreAuth extended) {
		Extended = extended;
	}
	public MetadataPreAuth getMetadata() {
		return Metadata;
	}
	public void setMetadata(MetadataPreAuth metadata) {
		Metadata = metadata;
	}
	@Override
	public String toString() {
		return "EventPreAuth [Standard=" + Standard + ", CustomerAccess=" + CustomerAccess + ", Extended=" + Extended
				+ ", Metadata=" + Metadata + "]";
	}
	
	
	
}
