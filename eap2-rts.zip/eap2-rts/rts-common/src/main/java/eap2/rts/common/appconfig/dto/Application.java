package eap2.rts.common.appconfig.dto;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import eap2.rts.common.SysConstants;

public class Application implements java.io.Serializable {

	private static final long serialVersionUID = 1L;

	private Integer id;
	private String name;
	private Integer tenantId;
	private String description;
	private String voidInd;
	private Map<String, Map<String, String>> appParams = new HashMap<String, Map<String, String>>();
	private List<AppDS> appDS;

	/**
	 * @return the id
	 */
	public Integer getId() {
		return id;
	}

	/**
	 * @param id
	 *            the id to set
	 */
	public void setId(Integer id) {
		this.id = id;
	}

	/**
	 * @return the name
	 */
	public String getName() {
		return name;
	}

	/**
	 * @param name
	 *            the name to set
	 */
	public void setName(String name) {
		this.name = name;
	}
	

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	/**
	 * @return the tenantId
	 */
	public Integer getTenantId() {
		return tenantId;
	}

	/**
	 * @param tenantId
	 *            the tenantId to set
	 */
	public void setTenantId(Integer tenantId) {
		this.tenantId = tenantId;
	}

	/**
	 * @return the voidInd
	 */
	public String getVoidInd() {
		return voidInd;
	}

	/**
	 * @param voidInd
	 *            the voidInd to set
	 */
	public void setVoidInd(String voidInd) {
		this.voidInd = voidInd;
	}

	/**
	 * @return the appParams
	 */
	public Map<String, Map<String, String>> getAppParams() {
		return appParams;
	}

	/**
	 * @param appParams
	 *            the appParams to set
	 */
	public void setAppParams(Map<String, Map<String, String>> appParams) {
		this.appParams = appParams;
	}

	public List<AppDS> getAppDS() {
		return appDS;
	}

	public void setAppDS(List<AppDS> appDS) {
		this.appDS = appDS;
	}

	public Map<String, String> getAppParamsByType(String paramType) {
		Map<String, String> paramMap = getAppParams().get(paramType);
		return paramMap;
	}

	public String getAppConf(String key) {
		Map<String, String> appConfParams = getAppParams().get(SysConstants.PARAM_TYPE_APP_CONF);
		return appConfParams.get(key);
	}

	@Override
	public String toString() {
		return "Application [id=" + id + ", name=" + name + ", tenantId=" + tenantId + ", description=" + description
				+ ", voidInd=" + voidInd + ", appParams=" + appParams + ", appDS=" + appDS + "]";
	}

}