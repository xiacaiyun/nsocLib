package eap2.rts.common.eventhub.dto;

import java.io.Serializable;

public class ExtendedRewardRedemptionAccess implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 3456767817229035190L;
	
	
}
