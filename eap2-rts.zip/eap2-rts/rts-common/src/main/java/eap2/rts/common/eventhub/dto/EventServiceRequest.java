package eap2.rts.common.eventhub.dto;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonProperty;

public class EventServiceRequest implements Serializable {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = -1352605097979784950L;
	@JsonProperty("Standard")
	private StandardServiceRequest Standard;
	@JsonProperty("CustomerAccess")
    private CustomerAccessServiceRequest CustomerAccess;
	@JsonProperty("Extended")
    private ExtendedServiceRequest Extended;
	@JsonProperty("Metadata")
    private MetadataServiceRequest Metadata;
	public StandardServiceRequest getStandard() {
		return Standard;
	}
	public void setStandard(StandardServiceRequest standard) {
		Standard = standard;
	}
	public CustomerAccessServiceRequest getCustomerAccess() {
		return CustomerAccess;
	}
	public void setCustomerAccess(CustomerAccessServiceRequest customerAccess) {
		CustomerAccess = customerAccess;
	}
	public ExtendedServiceRequest getExtended() {
		return Extended;
	}
	public void setExtended(ExtendedServiceRequest extended) {
		Extended = extended;
	}
	public MetadataServiceRequest getMetadata() {
		return Metadata;
	}
	public void setMetadata(MetadataServiceRequest metadata) {
		Metadata = metadata;
	}
	@Override
	public String toString() {
		return "EventServiceRequest [Standard=" + Standard + ", CustomerAccess=" + CustomerAccess + ", Extended="
				+ Extended + ", Metadata=" + Metadata + "]";
	}
	
	
	
}
