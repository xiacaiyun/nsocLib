package eap2.rts.common.eventhub.dto;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonProperty;

public class EventRewardRedemptionRequest implements Serializable {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = -2819475215385513303L;
	@JsonProperty("Standard")
	private StandardRewardRedemptionRequest Standard;
	@JsonProperty("CustomerAccess")
    private CustomerAccessRewardRedemptionRequest CustomerAccess;
	@JsonProperty("Extended")
    private ExtendedRewardRedemptionRequest Extended;
	@JsonProperty("Metadata")
    private MetadataRewardRedemptionRequest Metadata;
	public StandardRewardRedemptionRequest getStandard() {
		return Standard;
	}
	public void setStandard(StandardRewardRedemptionRequest standard) {
		Standard = standard;
	}
	public CustomerAccessRewardRedemptionRequest getCustomerAccess() {
		return CustomerAccess;
	}
	public void setCustomerAccess(CustomerAccessRewardRedemptionRequest customerAccess) {
		CustomerAccess = customerAccess;
	}
	public ExtendedRewardRedemptionRequest getExtended() {
		return Extended;
	}
	public void setExtended(ExtendedRewardRedemptionRequest extended) {
		Extended = extended;
	}
	public MetadataRewardRedemptionRequest getMetadata() {
		return Metadata;
	}
	public void setMetadata(MetadataRewardRedemptionRequest metadata) {
		Metadata = metadata;
	}
	@Override
	public String toString() {
		return "EventRewardRedemptionRequest [Standard=" + Standard + ", CustomerAccess=" + CustomerAccess
				+ ", Extended=" + Extended + ", Metadata=" + Metadata + "]";
	}
	
	
}
