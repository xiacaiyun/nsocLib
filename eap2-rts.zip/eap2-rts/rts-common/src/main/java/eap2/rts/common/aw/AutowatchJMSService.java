package eap2.rts.common.aw;

import java.util.Hashtable;
import java.util.Map;

import javax.jms.JMSException;
import javax.jms.Session;
import javax.jms.TextMessage;
import javax.jms.Topic;
import javax.jms.TopicConnection;
import javax.jms.TopicConnectionFactory;
import javax.jms.TopicPublisher;
import javax.jms.TopicSession;
import javax.naming.Context;
import javax.naming.InitialContext;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import eap2.rts.common.SysConstants;

/**
 * This class implements functions to publish the message response back to SCM.
 * 
 * @author bs34500
 */
public class AutowatchJMSService {

	private static final Logger logger = LoggerFactory.getLogger(AutowatchJMSService.class);
	private static Map<String, String> _appConfig = null;
	private static AutowatchJMSService _instance = null;

	private TopicConnectionFactory _topicConnectionFactory = null;
	private static TopicConnection _topicConnection = null;
	private Topic _topic = null;

	private AutowatchJMSService() {
		// do nothing, ist singleton
	}

	public static AutowatchJMSService getInstance(final Map<String, String> appConfig) throws Exception {
		logger.info("Inside TibcoJMSPublisherService->>>>>getInstance->>>>>");
		if (_instance == null) {
			_instance = new AutowatchJMSService();
			_appConfig = appConfig;
			_instance.open();
		}
		return _instance;
	}

	public void open() throws Exception {
		logger.info("Inside TibcoJMSPublisherService->>>>>open->>>>>");
		try {
			Hashtable<String, String> env = new Hashtable<String, String>();
			env.put(Context.INITIAL_CONTEXT_FACTORY, _appConfig.get(SysConstants.TIBCO_JMS_CONTEXT_FACTORY));
			env.put(Context.PROVIDER_URL, _appConfig.get(SysConstants.TIBCO_JMS_JNDI_CONN_URL));
			Context jndiContext = new InitialContext(env);
			_topicConnectionFactory = (TopicConnectionFactory) jndiContext
					.lookup(_appConfig.get(SysConstants.TIBCO_JMS_CONTEXT_FACTORY_NAME_EAP2_ER_OUTBOUND));
			_topicConnection = _topicConnectionFactory.createTopicConnection(_appConfig.get(SysConstants.TIBCO_JMS_TOPIC_USERNAME),
					_appConfig.get(SysConstants.TIBCO_JMS_TOPIC_PASSWORD));
			_topic = (Topic) jndiContext.lookup(_appConfig.get(SysConstants.TIBCO_JMS_OUTBOUND_TOPIC_NAME));
		} catch (Exception e) {
			logger.error("Inside TibcoJMSPublisherService->>>>>open->>>>>error>>starts");
			logger.error("An error has occured.", e);
			logger.error("Inside TibcoJMSPublisherService->>>>>open->>>>>error>>ends");
			throw e;
		}
	}

	/**
	 * @param messages
	 * @throws JMSException
	 */
	public void publish(String message) throws JMSException {
		logger.info("Inside TibcoJMSPublisherService->>>>>publish->>>>>");
		if (message == null) {
			return;
		}

		/*
		 * Create connection. Create session from connection. Create sender. Create text message. Send messages. Send
		 * non text message to end text messages. Close connection.
		 */
		try {
			TopicSession topicSession = _topicConnection.createTopicSession(false, Session.AUTO_ACKNOWLEDGE);
			TopicPublisher topicPublisher = topicSession.createPublisher(_topic);
			TextMessage textMessage = topicSession.createTextMessage();
			textMessage.setText(message);
			topicPublisher.send(textMessage);
			topicPublisher.close();
			topicSession.close();
		} catch (JMSException e) {
			logger.error("Inside TibcoJMSPublisherService->>>>>publish->>>>>error>>starts");
			logger.error("An error has occured.", e);
			logger.error("Inside TibcoJMSPublisherService->>>>>publish->>>>>error>>ends");
			throw e;
		}
	}

	@Override
	protected void finalize() throws Throwable {
		try {
			if (_topicConnection != null) {
				_topicConnection.close();
			}
		} catch (Throwable throwable) {
			logger.error("Inside TibcoJMSPublisherService->>>>>finalize->>>>>error>>starts");
			logger.error(throwable.getMessage());
			logger.error("Inside TibcoJMSPublisherService->>>>>finalize->>>>>error>>ends");
			throw throwable;
		}
	}
}