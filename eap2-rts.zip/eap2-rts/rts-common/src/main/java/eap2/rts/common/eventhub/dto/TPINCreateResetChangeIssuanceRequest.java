package eap2.rts.common.eventhub.dto;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonProperty;

public class TPINCreateResetChangeIssuanceRequest implements Serializable {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 7623133742406748810L;
	@JsonProperty("Event")
	private EventTPINCreateResetChangeIssuance event;
	
	public EventTPINCreateResetChangeIssuance getEvent() {
		return event;
	}
	public void setEvent(EventTPINCreateResetChangeIssuance event) {
		this.event = event;
	}
	@Override
	public String toString() {
		return "TPINCreateResetChangeIssuanceRequest [event=" + event + "]";
	}
}
