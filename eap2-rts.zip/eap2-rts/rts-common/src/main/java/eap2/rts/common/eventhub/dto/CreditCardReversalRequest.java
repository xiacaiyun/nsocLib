package eap2.rts.common.eventhub.dto;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonProperty;

public class CreditCardReversalRequest implements Serializable {
	private static final long serialVersionUID = -7951364024219033342L;
	
	@JsonProperty("Event")
	private EventCreditCardReversal event;
	
	public EventCreditCardReversal getEvent() {
		return event;
	}
	public void setEvent(EventCreditCardReversal event) {
		this.event = event;
	}
	@Override
	public String toString() {
		return "CreditCardReversalRequest [event=" + event + "]";
	}
}
