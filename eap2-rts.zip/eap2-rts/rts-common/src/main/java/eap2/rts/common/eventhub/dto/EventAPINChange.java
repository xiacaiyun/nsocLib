package eap2.rts.common.eventhub.dto;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonProperty;

public class EventAPINChange implements Serializable {
	private static final long serialVersionUID = 1953313392331964083L;
	
	@JsonProperty("Standard")
	private StandardAPINChange Standard;
	@JsonProperty("CustomerAccess")
    private CustomerAccessAPINChange CustomerAccess;
	@JsonProperty("Extended")
    private ExtendedAPINChange Extended;
	@JsonProperty("Metadata")
    private MetadataAPINChange Metadata;

    public StandardAPINChange getStandard ()
    {
        return Standard;
    }

    public void setStandard (StandardAPINChange Standard)
    {
        this.Standard = Standard;
    }

    public CustomerAccessAPINChange getCustomerAccess ()
    {
        return CustomerAccess;
    }

    public void setCustomerAccess (CustomerAccessAPINChange CustomerAccess)
    {
        this.CustomerAccess = CustomerAccess;
    }

    public ExtendedAPINChange getExtended ()
    {
        return Extended;
    }

    public void setExtended (ExtendedAPINChange Extended)
    {
        this.Extended = Extended;
    }

    public MetadataAPINChange getMetadata ()
    {
        return Metadata;
    }

    public void setMetadata (MetadataAPINChange Metadata)
    {
        this.Metadata = Metadata;
    }

    @Override
    public String toString()
    {
        return "ClassPojo [Standard = "+Standard+", CustomerAccess = "+CustomerAccess+", Extended = "+Extended+", Metadata = "+Metadata+"]";
    }
}
