package eap2.rts.common.eventhub.dto;

import java.io.Serializable;

public class ExtendedChequeStopPayment implements Serializable {
	private static final long serialVersionUID = -474827212925596319L;
	
}
