package eap2.rts.common.eventhub.dto;

import java.io.Serializable;

public class ExtendedCBOLMBOLRegistration implements Serializable {
	private static final long serialVersionUID = -5724208307136639199L;
	
	
}
