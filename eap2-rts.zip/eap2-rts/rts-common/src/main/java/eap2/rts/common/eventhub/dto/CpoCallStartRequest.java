package eap2.rts.common.eventhub.dto;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonProperty;

public class CpoCallStartRequest implements Serializable {
	private static final long serialVersionUID = 7852042960744166752L;
	
	@JsonProperty("Event")
	private EventCpoCallStart event;
	
	public EventCpoCallStart getEvent() {
		return event;
	}
	public void setEvent(EventCpoCallStart event) {
		this.event = event;
	}
	@Override
	public String toString() {
		return "CpoCallStartRequest [event=" + event + "]";
	}
}
