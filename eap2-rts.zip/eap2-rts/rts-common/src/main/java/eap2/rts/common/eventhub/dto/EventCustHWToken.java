package eap2.rts.common.eventhub.dto;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonProperty;

public class EventCustHWToken implements Serializable {
	private static final long serialVersionUID = -2148000113154265318L;
	
	@JsonProperty("Standard")
	private StandardCustHWToken Standard;
	@JsonProperty("CustomerAccess")
    private CustomerAccessCustHWToken CustomerAccess;
	@JsonProperty("Extended")
    private ExtendedCustHWToken Extended;
	@JsonProperty("Metadata")
    private MetadataCustHWToken Metadata;

    public StandardCustHWToken getStandard ()
    {
        return Standard;
    }

    public void setStandard (StandardCustHWToken Standard)
    {
        this.Standard = Standard;
    }

    public CustomerAccessCustHWToken getCustomerAccess ()
    {
        return CustomerAccess;
    }

    public void setCustomerAccess (CustomerAccessCustHWToken CustomerAccess)
    {
        this.CustomerAccess = CustomerAccess;
    }

    public ExtendedCustHWToken getExtended ()
    {
        return Extended;
    }

    public void setExtended (ExtendedCustHWToken Extended)
    {
        this.Extended = Extended;
    }

    public MetadataCustHWToken getMetadata ()
    {
        return Metadata;
    }

    public void setMetadata (MetadataCustHWToken Metadata)
    {
        this.Metadata = Metadata;
    }

    @Override
    public String toString()
    {
        return "ClassPojo [Standard = "+Standard+", CustomerAccess = "+CustomerAccess+", Extended = "+Extended+", Metadata = "+Metadata+"]";
    }
}
