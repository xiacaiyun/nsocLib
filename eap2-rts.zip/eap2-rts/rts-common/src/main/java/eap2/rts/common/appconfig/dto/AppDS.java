package eap2.rts.common.appconfig.dto;

import java.util.List;

public class AppDS implements java.io.Serializable {

	private static final long serialVersionUID = 1L;
	
	private Integer id;
	private String name;
	private Integer appId;
	private String dsTypeCode;
	private String description;
	private String defaultEvent;
	
	private List<AppDSDetail> appDSDetails;
	private List<AppDSEvent> AppDSEvents;
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public Integer getAppId() {
		return appId;
	}
	public void setAppId(Integer appId) {
		this.appId = appId;
	}
	public String getDsTypeCode() {
		return dsTypeCode;
	}
	public void setDsTypeCode(String dsTypeCode) {
		this.dsTypeCode = dsTypeCode;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public String getDefaultEvent() {
		return defaultEvent;
	}
	public void setDefaultEvent(String defaultEvent) {
		this.defaultEvent = defaultEvent;
	}
	public List<AppDSDetail> getAppDSDetails() {
		return appDSDetails;
	}
	public void setAppDSDetails(List<AppDSDetail> appDSDetails) {
		this.appDSDetails = appDSDetails;
	}
	public List<AppDSEvent> getAppDSEvents() {
		return AppDSEvents;
	}
	public void setAppDSEvents(List<AppDSEvent> appDSEvents) {
		AppDSEvents = appDSEvents;
	}
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((AppDSEvents == null) ? 0 : AppDSEvents.hashCode());
		result = prime * result + ((appDSDetails == null) ? 0 : appDSDetails.hashCode());
		result = prime * result + ((appId == null) ? 0 : appId.hashCode());
		result = prime * result + ((description == null) ? 0 : description.hashCode());
		result = prime * result + ((dsTypeCode == null) ? 0 : dsTypeCode.hashCode());
		result = prime * result + ((id == null) ? 0 : id.hashCode());
		result = prime * result + ((name == null) ? 0 : name.hashCode());
		return result;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		AppDS other = (AppDS) obj;
		if (AppDSEvents == null) {
			if (other.AppDSEvents != null)
				return false;
		} else if (!AppDSEvents.equals(other.AppDSEvents))
			return false;
		if (appDSDetails == null) {
			if (other.appDSDetails != null)
				return false;
		} else if (!appDSDetails.equals(other.appDSDetails))
			return false;
		if (appId == null) {
			if (other.appId != null)
				return false;
		} else if (!appId.equals(other.appId))
			return false;
		if (description == null) {
			if (other.description != null)
				return false;
		} else if (!description.equals(other.description))
			return false;
		if (dsTypeCode == null) {
			if (other.dsTypeCode != null)
				return false;
		} else if (!dsTypeCode.equals(other.dsTypeCode))
			return false;
		if (id == null) {
			if (other.id != null)
				return false;
		} else if (!id.equals(other.id))
			return false;
		if (name == null) {
			if (other.name != null)
				return false;
		} else if (!name.equals(other.name))
			return false;
		return true;
	}
	@Override
	public String toString() {
		return "AppDS [id=" + id + ", name=" + name + ", appId=" + appId + ", dsTypeCode=" + dsTypeCode
				+ ", description=" + description + ", defaultEvent=" + defaultEvent + ", appDSDetails=" + appDSDetails
				+ ", AppDSEvents=" + AppDSEvents + "]";
	}
}
