package eap2.rts.common.eventhub.dto;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonProperty;

public class ExtendedCardActivation implements Serializable {
	
	private static final long serialVersionUID = 1133524819520275537L;
	
	@JsonProperty("ProductType")
	private String ProductType;
	@JsonProperty("MerchantName")
	private String MerchantName;
	@JsonProperty("TransactionAmount")
	private String TransactionAmount;
	@JsonProperty("TransactionCurrency")
	private String TransactionCurrency;

    public String getProductType ()
    {
        return ProductType;
    }

    public void setProductType (String ProductType)
    {
        this.ProductType = ProductType;
    }

    public String getMerchantName() {
		return MerchantName;
	}

	public void setMerchantName(String merchantName) {
		MerchantName = merchantName;
	}

	public String getTransactionAmount() {
		return TransactionAmount;
	}

	public void setTransactionAmount(String transactionAmount) {
		TransactionAmount = transactionAmount;
	}

	public String getTransactionCurrency() {
		return TransactionCurrency;
	}

	public void setTransactionCurrency(String transactionCurrency) {
		TransactionCurrency = transactionCurrency;
	}

	@Override
    public String toString()
    {
        return "ClassPojo [ProductType = "+ProductType+"]";
    }
}
