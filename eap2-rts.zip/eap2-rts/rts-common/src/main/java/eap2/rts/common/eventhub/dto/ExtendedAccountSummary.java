package eap2.rts.common.eventhub.dto;

import java.io.Serializable;

public class ExtendedAccountSummary implements Serializable {
	private static final long serialVersionUID = 4614142565492010387L;
	
	
}
