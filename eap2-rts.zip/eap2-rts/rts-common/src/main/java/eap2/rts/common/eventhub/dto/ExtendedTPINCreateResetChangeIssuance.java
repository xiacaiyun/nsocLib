package eap2.rts.common.eventhub.dto;

import java.io.Serializable;

public class ExtendedTPINCreateResetChangeIssuance implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 6790782555314919483L;

}
