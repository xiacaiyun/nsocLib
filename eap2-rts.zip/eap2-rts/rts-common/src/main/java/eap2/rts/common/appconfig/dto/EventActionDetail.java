package eap2.rts.common.appconfig.dto;

import java.io.Serializable;

public class EventActionDetail implements Serializable {
	private static final long serialVersionUID = 1493286873403650619L;

	private Integer id;
	private Integer eventActionId;
	private String paramName;
	private String paramValue;
	private String valueEncrypted;
	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public Integer getEventActionId() {
		return eventActionId;
	}

	public void setEventActionId(Integer eventActionId) {
		this.eventActionId = eventActionId;
	}

	public String getParamName() {
		return paramName;
	}

	public void setParamName(String paramName) {
		this.paramName = paramName;
	}

	public String getParamValue() {
		return paramValue;
	}

	public void setParamValue(String paramValue) {
		this.paramValue = paramValue;
	}
	public String getValueEncrypted() {
		return valueEncrypted;
	}
	public void setValueEncrypted(String valueEncrypted) {
		this.valueEncrypted = valueEncrypted;
	}

	@Override
	public String toString() {
		return "EventActionDetail [id=" + id + ", eventActionId=" + eventActionId + ", paramName=" + paramName
				+ ", paramValue=" + paramValue + "]";
	}
}