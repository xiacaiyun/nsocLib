package eap2.rts.common.aw;

import java.io.ByteArrayInputStream;
import java.io.InputStream;
import java.io.StringWriter;
import java.nio.charset.StandardCharsets;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.Marshaller;
import javax.xml.bind.Unmarshaller;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import eap2.cda.common.aw.EAPEvent;

/**
 * Helper class to parse XML using JaxB
 * 
 * @author sd79271
 */
public class JAXBHelper {

	private static final Object lock = new Object();
	protected static Logger logger = LoggerFactory.getLogger(JAXBHelper.class);
	private static JAXBHelper jaxBHelper = null;
	private static Unmarshaller jaxbUnMarshaller = null;
	private static Marshaller jaxbMarshaller = null;

	public static JAXBHelper getInstance() {
		if (jaxBHelper == null) {
			synchronized (lock) {
				jaxBHelper = new JAXBHelper();
				init();
			}
		}

		return jaxBHelper;
	}

	private static void init() {
		try {
			JAXBContext jaxbContext = JAXBContext.newInstance(EAPEvent.class);
			jaxbUnMarshaller = jaxbContext.createUnmarshaller();
			jaxbMarshaller = jaxbContext.createMarshaller();
			jaxbMarshaller.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, true);
		} catch (Exception excep) {
			logger.error("JaxbHelperFunction->>>>>call->>>>>Debug->>>>>starts->>>>>");
			logger.error("An error has occured", excep);
			logger.error("JaxbHelperFunction->>>>>call->>>>>Debug->>>>>ends->>>>>");
			System.exit(1);

		}

	}

	public String marshal(EAPEvent emapEvent) throws Exception {
		logger.info("Inside JAXBHelper --> marshal");
		StringWriter stringWriter = new StringWriter();
		String xmlresponse = null;
		try {
			jaxbMarshaller.marshal(emapEvent, stringWriter);
			xmlresponse = stringWriter.getBuffer().toString();
		} catch (Exception excep) {
			logger.error("JaxbHelperFunction->>>>>call->>>>>Debug->>>>>starts->>>>>");
			logger.error("An error has occured", excep);
			logger.error("JaxbHelperFunction->>>>>call->>>>>Debug->>>>>ends->>>>>");
			throw excep;
		}
		return xmlresponse;
	}

	/**
	 * @param awTriggerXML
	 * @return
	 * @throws Exception
	 */
	public EAPEvent unMarshal(String awTriggerXML) throws Exception {
		EAPEvent eapEvent = null;
		try {
			InputStream is = new ByteArrayInputStream(awTriggerXML.getBytes(StandardCharsets.UTF_8));
			eapEvent = (EAPEvent) jaxbUnMarshaller.unmarshal(is);
		} catch (Exception e) {
			logger.error("JaxbHelper->>>>>unMarshal->>>>>Debug->>>>>starts->>>>>");
			logger.error("An error has occured", e);
			logger.error("JaxbHelper->>>>>unMarshal->>>>>Debug->>>>>ends->>>>>");
			throw e;
		}
		return eapEvent;
	}

}
