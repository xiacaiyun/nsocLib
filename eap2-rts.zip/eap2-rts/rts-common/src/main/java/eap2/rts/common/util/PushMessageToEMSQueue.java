package eap2.rts.common.util;

import java.io.File;
import java.io.IOException;
import java.util.Properties;

import javax.jms.JMSException;
import javax.jms.Queue;
import javax.jms.QueueConnection;
import javax.jms.QueueConnectionFactory;
import javax.jms.QueueSender;
import javax.jms.QueueSession;
import javax.jms.Session;
import javax.jms.TextMessage;
import javax.naming.Context;
import javax.naming.InitialContext;

import org.apache.commons.io.FileUtils;
import org.apache.log4j.Logger;

public class PushMessageToEMSQueue {
	
	//private static final Logger log = Logger.getLogger(PushMessageToQueue.class);

	public static void main(String[] args) throws IOException {

		// String p12_certificate_path = args[0];
		QueueConnectionFactory queueConnectionFactory = null;
		Queue queue = null;
		QueueSender queueSender = null;
		QueueConnection queueConnection = null;
		QueueSession queueSession = null;
		
		
		//UAT
		/*
		String messageTxt = args[0];
		String _sslIdentity = "C:/Users/SS36531/Desktop/IVR/UAT_EAP_USR.ca1.p12";
		String _brokerURL = "ssl://eventclouduat2jndigc.nam.nsroot.net:7243";
		String _password = "citi1234";  
		String _username = "UAT_EAP_USR";
		String _queueCF = "G2C_EC_EAP2QueueConnectionFactory";
		String _queueName = "citi.gcg.apac.eventcloud.consumer.my.eap";
		*/
	/*	
		String messageTxt = args[0];
		String _sslIdentity = args[1];
		String _brokerURL = args[2];
		String _password = args[3];
		String _username = args[4];
		String _queueCF = args[5];
		String _queueName = args[6];
		String Event_Name = args[7];
		
		*/
		
		//RTS DEV EHHH
				String _sslIdentity = "C:/Users/ss36531/xml/DIT_EAP_USR.ca1.p12";
				String _brokerURL = "ssl://mwgtc-tibla16s.nam.nsroot.net:7243";
				String messageTxt = "C:/Users/ss36531/ivr/ivr.json";
				String _password = "citi1234";  
				String _username = "SIT_EAP_USR";
				String _queueCF = "G2C_EC_EAPQueueConnectionFactory";
				String _queueName = "citi.gcg.apac.eventcloud.consumer.eap";
				String Event_Name = "IVRCallLogin";
		
	//	C:/Users/ss36531/ivr/ivr.json C:/Users/ss36531/xml/DIT_EAP_USR.ca1.p12 ssl://mwgtc-tibla16s.nam.nsroot.net:7243 citi1234 SIT_EAP_USR G2C_EC_EAPQueueConnectionFactory citi.gcg.apac.eventcloud.consumer.eap 
		
		//String messageTxt = "C:/Users/ss36489/svn/rts/eap2-rts/rts-spark-engine/sample-requests/sampleProdOffer.xml";
		//String messageTxt = "./xmls/RealTimeDataProcessingMessage.xml";
		//String messageTxt = "C:/Users/ss36531/UPDATEOfferFulfillmnetEAPrequest.xml";
		//String messageTxt = "C:/Users/ss36531/ivr/ivr.json";
		
		//String messageTxt = "I:/SendToEAP.XML";
		//String messageTxt = "C:/Users/ss36489/Documents/crdp jars/PaymentRiskScoreResponse_FromCrdp.xml";
		//String messageTxt = "C:/Users/ss36489/Documents/crdp jars/RiskInvestigatorDecision_FromCD.xml";
		String xmlDataStr = FileUtils.readFileToString(new File(messageTxt));
		TextMessage message = null;
		//ssl://eventclouduat2jndigc.nam.nsroot.net:7243 UAT_EAP_USR.ca1.p12
		//	citi1234 UAT_EAP_USR G2C_EC_EAP1QueueConnectionFactory citi.gcg.apac.eventcloud.consumer.my.eap
		
		
		
		
		//String _brokerURL = "ssl://gtstibemssit.nam.nsroot.net:50643";
		//String _sslIdentity = "/home/gfcrdsnsg/crdp/IMASS_9990.p12";
		//String _sslIdentity = "C:/Users/ss36531/xml/DIT_EAP_USR.ca1.p12";
		
		
	
/*		String _brokerURL = "ssl://gpd-f1e-9b87.nam.nsroot.net:41143";
		String _sslIdentity = "/tmp/gcgdmasg_p12Cert/DIT_EAP_USR.ca1.p12";
		String _password = "citi1234";
		String _username = "SIT_EAP_USR";
		String _queueCF = "G2C_ESB_EAPQueueConnectionFactory";
		String _queueName = "citi.gcg.gom.esb_159515.my.eap.possiblereason.Rq";*/
		
/*		String _brokerURL = "ssl://mwgtc-tibla16s.nam.nsroot.net:7243";
		String _sslIdentity = "/tmp/gcgdmasg_p12Cert/DIT_EAP_USR.ca1.p12";
		String _password = "citi1234";
		String _username = "SIT_EAP_USR";
		String _queueCF = "G2C_EC_EAPQueueConnectionFactory";
		String _queueName = "citi.gcg.apac.eventcloud.consumer.eap";
*/		
		/*String _brokerURL = "ssl://gpd-ed9-5c7e.nam.nsroot.net:7243";
		String _sslIdentity = "C:/Users/ss36489/svn/rts/eap2-rts/rts-spark-engine/src/main/resources/DIT_EAP_USR.ca1.p12.pem";
		String _password = "citi1234";
		String _username = "SIT_EAP_USR";
		String _queueCF = "G2C_EAPCOPHKBatchQueueConnectionFactory";
		String _queueName = "citi.gcg.gomhk.cop_163124.hk_card.epp.prodoffertemplate.update"; 
		*/
		/*String _brokerURL = "ssl://gpd-ed9-5c7e.nam.nsroot.net:7243";
		String _queueCF = "G2C_EAPCOPSGIDVNBatchQueueConnectionFactory";
		String _sslIdentity = "C:/Users/ss36489/DIT_EAP_USR.ca1.p12";
		String _password = "citi1234";
		String _username = "SIT_EAP_USR"; */
		//String _brokerURL = "ssl://gpd-ed9-5c7e.nam.nsroot.net:7243";
		
		/*String _sslIdentity="/home/gfcrdnsg/crdp/IMASS_9990.p12";
		String _sslIdentity = "/data/1/gfcrdn/data/CRDP_PANKAJ/IMASS_9990.p12";
		*/
		//String _queueName ="citi.gcg.gom.cop_163124.sg_card.mre.transaction.request";
		/*String _password = "citi1234";  
		String _username = "SIT_EAP_USR";
		String _queueCF = "G2C_EAPCOPSGIDVNBatchQueueConnectionFactory";
		String _queueName = "citi.gcg.gomvn.cop_163124.vn_card.offerfulfillment.modelrequest";
		*/
		
		
		
		
		
		//String _queueName = "cmb.gts.na.giw_169944.CRDP_RESPONSE_QUEUE";
		//String _queueName = "cmb.gts.na.giw_169944.CRDP_REQUEST_QUEUE";
		

		System.out.println("Configuring the Properties for TIBCO connection");
		Properties properties = new Properties();

		properties.put(Context.INITIAL_CONTEXT_FACTORY, "com.tibco.tibjms.naming.TibjmsInitialContextFactory");
		properties.put(Context.PROVIDER_URL, _brokerURL);
		
		properties.put(Context.SECURITY_PRINCIPAL, _username);
		properties.put(Context.SECURITY_CREDENTIALS, _password);
		properties.put("com.tibco.tibjms.naming.ssl_identity", _sslIdentity);
		properties.put("com.tibco.tibjms.naming.ssl_password", _password);
		properties.put("tibco.jms.inbound.queue.name",_queueName);
		properties.put("tibco.jms.queue.queueCF",_queueCF);
		
		properties.put("com.tibco.tibjms.naming.security_protocol", "ssl");
		properties.put("com.tibco.tibjms.naming.ssl_enable_verify_host", "false");
		properties.put("com.tibco.tibjms.naming.ssl_vendor", "j2se-default");
		properties.put("com.sun.net.ssl.internal.ssl.Provider", "j2se-default");
		properties.put("com.tibco.tibjms.naming.ssl_auth_only", true);
		properties.put("java.property.TIBCO_SECURITY_VENDOR", "j2se-default");
		properties.put("java.property.TIBCO_SECURITY_TRACE", true);
		properties.put("com.tibco.tibjms.naming.ssl_debug_trace", true);
		properties.put("com.tibco.tibjms.naming.ssl_trace", true);
		properties.put("com.tibco.datagrid.EventType","IVRCallLogin");
		

		System.out.println("Context Creation Start using proerpties.");

		
		try {
			Context ctx = new InitialContext(properties);

			
			
			queueConnectionFactory = (QueueConnectionFactory) ctx.lookup(_queueCF);
			 queue = (Queue) ctx.lookup(_queueName);

			queueConnection = queueConnectionFactory.createQueueConnection(_username, _password);

			// queueConnection.start();

			queueSession = queueConnection.createQueueSession(false, Session.AUTO_ACKNOWLEDGE);

			queueSender = queueSession.createSender(queue);
			
			

			message = queueSession.createTextMessage(xmlDataStr);
			message.setStringProperty("EventID", Event_Name);
			//use this to set your property. Whats the property name?this will work. thanks
		
		/*	message.setStringProperty("eventProducer", "Eclipse");
			message.setStringProperty("countryCode", "MY");
			message.setStringProperty("bussinessID", "3");
			message.setStringProperty("bizFunctionID", "sample");
			message.setStringProperty("transactionStatus", "");
			message.setStringProperty("touchPoint", "Eclipse");
			message.setStringProperty("eventUUID", "2546f1f9-0c7a-49a2-a62d-3fc1d44a8a5a"); */
			message.setText(xmlDataStr);
			
			while (true){
				
				System.out.println("Producing message: " + message.getText());
				queueSender.send(message);
				Thread.sleep(15000);
			}
			
		} catch (Exception e) {
			e.printStackTrace();
			System.out.println("Exception occurred: " + e.toString());
		} finally {
			if (queueConnection != null) {
				try {
					queueConnection.close();
				} catch (JMSException e) {
					System.out.println("Closing error: " + e.toString());
				}
			}
		}
	}
}
