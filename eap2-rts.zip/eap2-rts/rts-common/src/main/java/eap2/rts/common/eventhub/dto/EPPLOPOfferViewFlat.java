package eap2.rts.common.eventhub.dto;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonProperty;

public class EPPLOPOfferViewFlat  implements Serializable{

	
	private static final long serialVersionUID = 1L;
	
	//Standard
	@JsonProperty("CorrelationID")
    private String CorrelationID;
	@JsonProperty("EventID")
    private String EventID;
	@JsonProperty("EventUUID")
    private String EventUUID;
	@JsonProperty("EventProducer")
    private String EventProducer;
	@JsonProperty("EventTransmitter")
    private String EventTransmitter;
	@JsonProperty("CountryCode")
    private String CountryCode;
	@JsonProperty("BusinessID")
    private String BusinessID;
	@JsonProperty("UUID_UniqueID")
    private String UUID_UniqueID;
	@JsonProperty("ESBUUID")
    private String ESBUUID;
	@JsonProperty("BizFunctionID")
    private String BizFunctionID;
	@JsonProperty("CustomerID")
    private String CustomerID;
	@JsonProperty("CustomerType")
    private String CustomerType;
	@JsonProperty("CardNumber")
	private String CardNumber;
	@JsonProperty("AccountNumber")
    private String AccountNumber;
	@JsonProperty("IsCustomerPrimary")
    private String IsCustomerPrimary;
	@JsonProperty("TransactionStatus")
    private String TransactionStatus;
	@JsonProperty("TransactionType")
    private String TransactionType;
	@JsonProperty("RespStatusCode")
    private String RespStatusCode;
	@JsonProperty("RespStatusMsg")
    private String RespStatusMsg;
	@JsonProperty("ServerDateTime")
    private String ServerDateTime;
	@JsonProperty("TouchPoint")
    private String TouchPoint;
	@JsonProperty("AssistedChannelUserID")
    private String AssistedChannelUserID;
	
	//Metadata
	@JsonProperty("OriginatorFunctionID")
    private String OriginatorFunctionID;
	@JsonProperty("OriginatorSubFunctionID")
    private String OriginatorSubFunctionID;
	@JsonProperty("OriginatorFunctionType")
    private String OriginatorFunctionType;
	@JsonProperty("OriginatorFunctionSubType")
	private String OriginatorFunctionSubType;
	
	//Customer Access
	@JsonProperty("ChannelSessionId")
    private String ChannelSessionId;
	@JsonProperty("DeviceType")
    private String DeviceType;
	@JsonProperty("DeviceID")
	private String DeviceID;
	@JsonProperty("DeviceOS")
    private String DeviceOS;
	@JsonProperty("GeoLocLatitude")
    private String GeoLocLatitude;
	@JsonProperty("GeoLocLongitude")
    private String GeoLocLongitude;
	@JsonProperty("BrowserName")
    private String BrowserName;
	@JsonProperty("ClientIPAddress")
    private String ClientIPAddress;
	
	
	public String getCorrelationID() {
		return CorrelationID;
	}
	public void setCorrelationID(String correlationID) {
		CorrelationID = correlationID;
	}
	public String getEventID() {
		return EventID;
	}
	public void setEventID(String eventID) {
		EventID = eventID;
	}
	public String getEventUUID() {
		return EventUUID;
	}
	public void setEventUUID(String eventUUID) {
		EventUUID = eventUUID;
	}
	public String getEventProducer() {
		return EventProducer;
	}
	public void setEventProducer(String eventProducer) {
		EventProducer = eventProducer;
	}
	public String getEventTransmitter() {
		return EventTransmitter;
	}
	public void setEventTransmitter(String eventTransmitter) {
		EventTransmitter = eventTransmitter;
	}
	public String getCountryCode() {
		return CountryCode;
	}
	public void setCountryCode(String countryCode) {
		CountryCode = countryCode;
	}
	public String getBusinessID() {
		return BusinessID;
	}
	public void setBusinessID(String businessID) {
		BusinessID = businessID;
	}
	public String getUUID_UniqueID() {
		return UUID_UniqueID;
	}
	public void setUUID_UniqueID(String uUID_UniqueID) {
		UUID_UniqueID = uUID_UniqueID;
	}
	public String getESBUUID() {
		return ESBUUID;
	}
	public void setESBUUID(String eSBUUID) {
		ESBUUID = eSBUUID;
	}
	public String getBizFunctionID() {
		return BizFunctionID;
	}
	public void setBizFunctionID(String bizFunctionID) {
		BizFunctionID = bizFunctionID;
	}
	public String getCustomerID() {
		return CustomerID;
	}
	public void setCustomerID(String customerID) {
		CustomerID = customerID;
	}
	public String getCustomerType() {
		return CustomerType;
	}
	public void setCustomerType(String customerType) {
		CustomerType = customerType;
	}
	public String getCardNumber() {
		return CardNumber;
	}
	public void setCardNumber(String cardNumber) {
		CardNumber = cardNumber;
	}
	public String getAccountNumber() {
		return AccountNumber;
	}
	public void setAccountNumber(String accountNumber) {
		AccountNumber = accountNumber;
	}
	public String getIsCustomerPrimary() {
		return IsCustomerPrimary;
	}
	public void setIsCustomerPrimary(String isCustomerPrimary) {
		IsCustomerPrimary = isCustomerPrimary;
	}
	public String getTransactionStatus() {
		return TransactionStatus;
	}
	public void setTransactionStatus(String transactionStatus) {
		TransactionStatus = transactionStatus;
	}
	public String getTransactionType() {
		return TransactionType;
	}
	public void setTransactionType(String transactionType) {
		TransactionType = transactionType;
	}
	public String getRespStatusCode() {
		return RespStatusCode;
	}
	public void setRespStatusCode(String respStatusCode) {
		RespStatusCode = respStatusCode;
	}
	public String getRespStatusMsg() {
		return RespStatusMsg;
	}
	public void setRespStatusMsg(String respStatusMsg) {
		RespStatusMsg = respStatusMsg;
	}
	public String getServerDateTime() {
		return ServerDateTime;
	}
	public void setServerDateTime(String serverDateTime) {
		ServerDateTime = serverDateTime;
	}
	public String getTouchPoint() {
		return TouchPoint;
	}
	public void setTouchPoint(String touchPoint) {
		TouchPoint = touchPoint;
	}
	public String getAssistedChannelUserID() {
		return AssistedChannelUserID;
	}
	public void setAssistedChannelUserID(String assistedChannelUserID) {
		AssistedChannelUserID = assistedChannelUserID;
	}
	public String getOriginatorFunctionID() {
		return OriginatorFunctionID;
	}
	public void setOriginatorFunctionID(String originatorFunctionID) {
		OriginatorFunctionID = originatorFunctionID;
	}
	public String getOriginatorSubFunctionID() {
		return OriginatorSubFunctionID;
	}
	public void setOriginatorSubFunctionID(String originatorSubFunctionID) {
		OriginatorSubFunctionID = originatorSubFunctionID;
	}
	public String getOriginatorFunctionType() {
		return OriginatorFunctionType;
	}
	public void setOriginatorFunctionType(String originatorFunctionType) {
		OriginatorFunctionType = originatorFunctionType;
	}
	public String getOriginatorFunctionSubType() {
		return OriginatorFunctionSubType;
	}
	public void setOriginatorFunctionSubType(String originatorFunctionSubType) {
		OriginatorFunctionSubType = originatorFunctionSubType;
	}
	public String getChannelSessionId() {
		return ChannelSessionId;
	}
	public void setChannelSessionId(String channelSessionId) {
		ChannelSessionId = channelSessionId;
	}
	public String getDeviceType() {
		return DeviceType;
	}
	public void setDeviceType(String deviceType) {
		DeviceType = deviceType;
	}
	public String getDeviceID() {
		return DeviceID;
	}
	public void setDeviceID(String deviceID) {
		DeviceID = deviceID;
	}
	public String getDeviceOS() {
		return DeviceOS;
	}
	public void setDeviceOS(String deviceOS) {
		DeviceOS = deviceOS;
	}
	public String getGeoLocLatitude() {
		return GeoLocLatitude;
	}
	public void setGeoLocLatitude(String geoLocLatitude) {
		GeoLocLatitude = geoLocLatitude;
	}
	public String getGeoLocLongitude() {
		return GeoLocLongitude;
	}
	public void setGeoLocLongitude(String geoLocLongitude) {
		GeoLocLongitude = geoLocLongitude;
	}
	public String getBrowserName() {
		return BrowserName;
	}
	public void setBrowserName(String browserName) {
		BrowserName = browserName;
	}
	public String getClientIPAddress() {
		return ClientIPAddress;
	}
	public void setClientIPAddress(String clientIPAddress) {
		ClientIPAddress = clientIPAddress;
	}
	@Override
	public String toString() {
		return "EPPLOPOfferViewFlat [CorrelationID=" + CorrelationID + ", EventID=" + EventID + ", EventUUID="
				+ EventUUID + ", EventProducer=" + EventProducer + ", EventTransmitter=" + EventTransmitter
				+ ", CountryCode=" + CountryCode + ", BusinessID=" + BusinessID + ", UUID_UniqueID=" + UUID_UniqueID
				+ ", ESBUUID=" + ESBUUID + ", BizFunctionID=" + BizFunctionID + ", CustomerID=" + CustomerID
				+ ", CustomerType=" + CustomerType + ", CardNumber=" + CardNumber + ", AccountNumber=" + AccountNumber
				+ ", IsCustomerPrimary=" + IsCustomerPrimary + ", TransactionStatus=" + TransactionStatus
				+ ", TransactionType=" + TransactionType + ", RespStatusCode=" + RespStatusCode + ", RespStatusMsg="
				+ RespStatusMsg + ", ServerDateTime=" + ServerDateTime + ", TouchPoint=" + TouchPoint
				+ ", AssistedChannelUserID=" + AssistedChannelUserID + ", OriginatorFunctionID=" + OriginatorFunctionID
				+ ", OriginatorSubFunctionID=" + OriginatorSubFunctionID + ", OriginatorFunctionType="
				+ OriginatorFunctionType + ", OriginatorFunctionSubType=" + OriginatorFunctionSubType
				+ ", ChannelSessionId=" + ChannelSessionId + ", DeviceType=" + DeviceType + ", DeviceID=" + DeviceID
				+ ", DeviceOS=" + DeviceOS + ", GeoLocLatitude=" + GeoLocLatitude + ", GeoLocLongitude="
				+ GeoLocLongitude + ", BrowserName=" + BrowserName + ", ClientIPAddress=" + ClientIPAddress + "]";
	}
	
	

	
}
