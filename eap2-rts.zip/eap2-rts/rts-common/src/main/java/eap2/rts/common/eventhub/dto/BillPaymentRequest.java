package eap2.rts.common.eventhub.dto;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonProperty;

public class BillPaymentRequest implements Serializable {
	
	private static final long serialVersionUID = -4177229586029727900L;
	@JsonProperty("Event")
	private EventBillPayment event;
	
	public EventBillPayment getEvent() {
		return event;
	}
	public void setEvent(EventBillPayment event) {
		this.event = event;
	}
	@Override
	public String toString() {
		return "BillPaymentRequest [event=" + event + "]";
	}
}
