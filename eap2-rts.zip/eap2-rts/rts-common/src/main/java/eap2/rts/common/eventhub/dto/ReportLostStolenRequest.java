package eap2.rts.common.eventhub.dto;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonProperty;

public class ReportLostStolenRequest implements Serializable {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = -2593784859418165788L;
	@JsonProperty("Event")
	private EventReportLostStolen event;
	
	public EventReportLostStolen getEvent() {
		return event;
	}
	public void setEvent(EventReportLostStolen event) {
		this.event = event;
	}
	@Override
	public String toString() {
		return "EventReportLostStolen [event=" + event + "]";
	}


}
