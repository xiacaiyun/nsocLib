package eap2.rts.common.eventhub.dto;

import java.io.Serializable;

public class ExtendedCreditCardClosure implements Serializable {
	private static final long serialVersionUID = -8099604809855746379L;
	
	
}
