package eap2.rts.common.eventhub.dto;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonProperty;

public class ExtendedEstatementView implements Serializable {
	private static final long serialVersionUID = -1511092499335056693L;
	
	@JsonProperty("StatementAccountNo")
	private String StatementAccountNo;
	@JsonProperty("StatementMonth")
	private String StatementMonth;
	public String getStatementAccountNo() {
		return StatementAccountNo;
	}
	public void setStatementAccountNo(String statementAccountNo) {
		StatementAccountNo = statementAccountNo;
	}
	public String getStatementMonth() {
		return StatementMonth;
	}
	public void setStatementMonth(String statementMonth) {
		StatementMonth = statementMonth;
	}
	@Override
	public String toString() {
		return "ClassPojo [StatementAccountNo=" + StatementAccountNo + ", StatementMonth=" + StatementMonth
				+ "]";
	}

}
