package eap2.rts.common.eventhub.dto;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonProperty;

public class IVRCallLogin implements Serializable {
	private static final long serialVersionUID = 3208233030206698253L;
	
	@JsonProperty("Event")
	private EventIVRCallLogin event;
	
	public EventIVRCallLogin getEvent() {
		return event;
	}
	public void setEvent(EventIVRCallLogin event) {
		this.event = event;
	}
	@Override
	public String toString() {
		return "IVRCallLogin [event=" + event + "]";
	}
}
