package eap2.rts.common.eventhub.dto;

import java.io.Serializable;

public class ExtendedCustomerLogin implements Serializable {
	private static final long serialVersionUID = 7464496789523851902L;
	
	
}
