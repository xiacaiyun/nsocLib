package eap2.rts.common.eventhub.dto;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonProperty;

public class EventCardActivation implements Serializable {
	
	private static final long serialVersionUID = -7030702635654278542L;
	
	@JsonProperty("Standard")
	private StandardCardActivation Standard;
	@JsonProperty("CustomerAccess")
    private CustomerAccessCardActivation CustomerAccess;
	@JsonProperty("Extended")
    private ExtendedCardActivation Extended;
	@JsonProperty("Metadata")
    private MetadataCardActivation Metadata;

    public StandardCardActivation getStandard ()
    {
        return Standard;
    }

    public void setStandard (StandardCardActivation Standard)
    {
        this.Standard = Standard;
    }

    public CustomerAccessCardActivation getCustomerAccess ()
    {
        return CustomerAccess;
    }

    public void setCustomerAccess (CustomerAccessCardActivation CustomerAccess)
    {
        this.CustomerAccess = CustomerAccess;
    }

    public ExtendedCardActivation getExtended ()
    {
        return Extended;
    }

    public void setExtended (ExtendedCardActivation Extended)
    {
        this.Extended = Extended;
    }

    public MetadataCardActivation getMetadata ()
    {
        return Metadata;
    }

    public void setMetadata (MetadataCardActivation Metadata)
    {
        this.Metadata = Metadata;
    }

    @Override
    public String toString()
    {
        return "ClassPojo [Standard = "+Standard+", CustomerAccess = "+CustomerAccess+", Extended = "+Extended+", Metadata = "+Metadata+"]";
    }
}
