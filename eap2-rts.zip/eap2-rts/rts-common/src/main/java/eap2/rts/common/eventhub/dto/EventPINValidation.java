package eap2.rts.common.eventhub.dto;

import java.io.Serializable;

//import com.cloudera.com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonProperty;

public class EventPINValidation implements Serializable {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = -6947978232773289424L;
	@JsonProperty("Standard")
	private StandardPINValidation Standard;
	@JsonProperty("CustomerAccess")
    private CustomerAccessPINValidation CustomerAccess;
	@JsonProperty("Extended")
    private ExtendedPINValidation Extended;
	@JsonProperty("Metadata")
    private MetadataPINValidation Metadata;
	public StandardPINValidation getStandard() {
		return Standard;
	}
	public void setStandard(StandardPINValidation standard) {
		Standard = standard;
	}
	public CustomerAccessPINValidation getCustomerAccess() {
		return CustomerAccess;
	}
	public void setCustomerAccess(CustomerAccessPINValidation customerAccess) {
		CustomerAccess = customerAccess;
	}
	public ExtendedPINValidation getExtended() {
		return Extended;
	}
	public void setExtended(ExtendedPINValidation extended) {
		Extended = extended;
	}
	public MetadataPINValidation getMetadata() {
		return Metadata;
	}
	public void setMetadata(MetadataPINValidation metadata) {
		Metadata = metadata;
	}
	@Override
	public String toString() {
		return "EventPINValidation [Standard=" + Standard + ", CustomerAccess=" + CustomerAccess + ", Extended="
				+ Extended + ", Metadata=" + Metadata + "]";
	}
	
	
	
}
