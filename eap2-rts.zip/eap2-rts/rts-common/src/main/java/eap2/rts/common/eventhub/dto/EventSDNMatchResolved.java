package eap2.rts.common.eventhub.dto;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonProperty;

public class EventSDNMatchResolved implements Serializable {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 895843842889145033L;
	@JsonProperty("Standard")
	private StandardSDNMatchResolved Standard;
	@JsonProperty("CustomerAccess")
    private CustomerAccessSDNMatchResolved CustomerAccess;
	@JsonProperty("Extended")
    private ExtendedSDNMatchResolved Extended;
	@JsonProperty("Metadata")
    private MetadataSDNMatchResolved Metadata;
	public StandardSDNMatchResolved getStandard() {
		return Standard;
	}
	public void setStandard(StandardSDNMatchResolved standard) {
		Standard = standard;
	}
	public CustomerAccessSDNMatchResolved getCustomerAccess() {
		return CustomerAccess;
	}
	public void setCustomerAccess(CustomerAccessSDNMatchResolved customerAccess) {
		CustomerAccess = customerAccess;
	}
	public ExtendedSDNMatchResolved getExtended() {
		return Extended;
	}
	public void setExtended(ExtendedSDNMatchResolved extended) {
		Extended = extended;
	}
	public MetadataSDNMatchResolved getMetadata() {
		return Metadata;
	}
	public void setMetadata(MetadataSDNMatchResolved metadata) {
		Metadata = metadata;
	}
	@Override
	public String toString() {
		return "EventSDNMatchResolved [Standard=" + Standard + ", CustomerAccess=" + CustomerAccess + ", Extended="
				+ Extended + ", Metadata=" + Metadata + "]";
	}
	
	
}
