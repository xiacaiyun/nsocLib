package eap2.rts.common.eventhub.dto;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonProperty;

public class EventCustLoginIDStatusChange implements Serializable {
	private static final long serialVersionUID = -5110472946862912498L;
	
	@JsonProperty("Standard")
	private StandardCustLoginIDStatusChange Standard;
	@JsonProperty("CustomerAccess")
    private CustomerAccessCustLoginIDStatusChange CustomerAccess;
	@JsonProperty("Extended")
    private ExtendedCustLoginIDStatusChange Extended;
	@JsonProperty("Metadata")
    private MetadataCustLoginIDStatusChange Metadata;

    public StandardCustLoginIDStatusChange getStandard ()
    {
        return Standard;
    }

    public void setStandard (StandardCustLoginIDStatusChange Standard)
    {
        this.Standard = Standard;
    }

    public CustomerAccessCustLoginIDStatusChange getCustomerAccess ()
    {
        return CustomerAccess;
    }

    public void setCustomerAccess (CustomerAccessCustLoginIDStatusChange CustomerAccess)
    {
        this.CustomerAccess = CustomerAccess;
    }

    public ExtendedCustLoginIDStatusChange getExtended ()
    {
        return Extended;
    }

    public void setExtended (ExtendedCustLoginIDStatusChange Extended)
    {
        this.Extended = Extended;
    }

    public MetadataCustLoginIDStatusChange getMetadata ()
    {
        return Metadata;
    }

    public void setMetadata (MetadataCustLoginIDStatusChange Metadata)
    {
        this.Metadata = Metadata;
    }

    @Override
    public String toString()
    {
        return "ClassPojo [Standard = "+Standard+", CustomerAccess = "+CustomerAccess+", Extended = "+Extended+", Metadata = "+Metadata+"]";
    }
}
