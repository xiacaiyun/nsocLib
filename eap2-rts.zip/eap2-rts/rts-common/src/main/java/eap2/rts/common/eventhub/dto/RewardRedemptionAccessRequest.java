package eap2.rts.common.eventhub.dto;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonProperty;

public class RewardRedemptionAccessRequest implements Serializable {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 4880982583648269345L;
	@JsonProperty("Event")
	private EventRewardRedemptionAccess event;
	
	public EventRewardRedemptionAccess getEvent() {
		return event;
	}
	public void setEvent(EventRewardRedemptionAccess event) {
		this.event = event;
	}
	@Override
	public String toString() {
		return "RewardRedemptionAccessRequest [event=" + event + "]";
	}
}
