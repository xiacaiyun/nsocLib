package eap2.rts.common.eventhub.dto;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonProperty;

public class EventSMSEmailOffers implements Serializable {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = -170183146202073441L;
	@JsonProperty("Standard")
	private StandardSMSEmailOffers Standard;
	@JsonProperty("CustomerAccess")
    private CustomerAccessSMSEmailOffers CustomerAccess;
	@JsonProperty("Extended")
    private ExtendedSMSEmailOffers Extended;
	@JsonProperty("Metadata")
    private MetadataSMSEmailOffers Metadata;
	public StandardSMSEmailOffers getStandard() {
		return Standard;
	}
	public void setStandard(StandardSMSEmailOffers standard) {
		Standard = standard;
	}
	public CustomerAccessSMSEmailOffers getCustomerAccess() {
		return CustomerAccess;
	}
	public void setCustomerAccess(CustomerAccessSMSEmailOffers customerAccess) {
		CustomerAccess = customerAccess;
	}
	public ExtendedSMSEmailOffers getExtended() {
		return Extended;
	}
	public void setExtended(ExtendedSMSEmailOffers extended) {
		Extended = extended;
	}
	public MetadataSMSEmailOffers getMetadata() {
		return Metadata;
	}
	public void setMetadata(MetadataSMSEmailOffers metadata) {
		Metadata = metadata;
	}
	@Override
	public String toString() {
		return "EventSMSEmailOffers [Standard=" + Standard + ", CustomerAccess=" + CustomerAccess + ", Extended="
				+ Extended + ", Metadata=" + Metadata + "]";
	}
	
	
	
	
}
