package eap2.rts.common.eventhub.dto;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonProperty;

public class AccountLinkageRequest implements Serializable {
	private static final long serialVersionUID = 3030868315406244705L;
	
	@JsonProperty("Event")
	private EventAccountLinkage event;
	
	public EventAccountLinkage getEvent() {
		return event;
	}
	public void setEvent(EventAccountLinkage event) {
		this.event = event;
	}
	@Override
	public String toString() {
		return "AccountLinkageRequest [event=" + event + "]";
	}
}
