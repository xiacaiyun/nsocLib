package eap2.rts.common.eventhub.dto;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonProperty;

public class EventPaymentAndTransfer implements Serializable {
	
	private static final long serialVersionUID = -1330694778600296705L;
	@JsonProperty("Standard")
	private StandardPaymentAndTransfer Standard;
	@JsonProperty("CustomerAccess")
    private CustomerAccessPaymentAndTransfer CustomerAccess;
	@JsonProperty("Extended")
    private ExtendedPaymentAndTransfer Extended;
	@JsonProperty("Metadata")
    private MetadataPaymentAndTransfer Metadata;
	public StandardPaymentAndTransfer getStandard() {
		return Standard;
	}
	public void setStandard(StandardPaymentAndTransfer standard) {
		Standard = standard;
	}
	public CustomerAccessPaymentAndTransfer getCustomerAccess() {
		return CustomerAccess;
	}
	public void setCustomerAccess(CustomerAccessPaymentAndTransfer customerAccess) {
		CustomerAccess = customerAccess;
	}
	public ExtendedPaymentAndTransfer getExtended() {
		return Extended;
	}
	public void setExtended(ExtendedPaymentAndTransfer extended) {
		Extended = extended;
	}
	public MetadataPaymentAndTransfer getMetadata() {
		return Metadata;
	}
	public void setMetadata(MetadataPaymentAndTransfer metadata) {
		Metadata = metadata;
	}
	@Override
	public String toString() {
		return "EventPaymentAndTransfer [Standard=" + Standard + ", CustomerAccess=" + CustomerAccess + ", Extended="
				+ Extended + ", Metadata=" + Metadata + "]";
	}
	

}
