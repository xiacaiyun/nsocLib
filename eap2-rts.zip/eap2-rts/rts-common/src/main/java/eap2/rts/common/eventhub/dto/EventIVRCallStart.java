package eap2.rts.common.eventhub.dto;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonProperty;

public class EventIVRCallStart implements Serializable {
	private static final long serialVersionUID = 5318901469142517374L;
	
	@JsonProperty("Standard")
	private StandardIVRCallStart Standard;
	@JsonProperty("CustomerAccess")
    private CustomerAccessIVRCallStart CustomerAccess;
	@JsonProperty("Extended")
    private ExtendedIVRCallStart Extended;
	@JsonProperty("Metadata")
    private MetadataIVRCallStart Metadata;

    public StandardIVRCallStart getStandard ()
    {
        return Standard;
    }

    public void setStandard (StandardIVRCallStart Standard)
    {
        this.Standard = Standard;
    }

    public CustomerAccessIVRCallStart getCustomerAccess ()
    {
        return CustomerAccess;
    }

    public void setCustomerAccess (CustomerAccessIVRCallStart CustomerAccess)
    {
        this.CustomerAccess = CustomerAccess;
    }

    public ExtendedIVRCallStart getExtended ()
    {
        return Extended;
    }

    public void setExtended (ExtendedIVRCallStart Extended)
    {
        this.Extended = Extended;
    }

    public MetadataIVRCallStart getMetadata ()
    {
        return Metadata;
    }

    public void setMetadata (MetadataIVRCallStart Metadata)
    {
        this.Metadata = Metadata;
    }

    @Override
    public String toString()
    {
        return "ClassPojo [Standard = "+Standard+", CustomerAccess = "+CustomerAccess+", Extended = "+Extended+", Metadata = "+Metadata+"]";
    }
}
