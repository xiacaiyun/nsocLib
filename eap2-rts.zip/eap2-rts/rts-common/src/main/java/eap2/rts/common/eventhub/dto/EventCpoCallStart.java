package eap2.rts.common.eventhub.dto;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonProperty;

public class EventCpoCallStart implements Serializable {
	private static final long serialVersionUID = -627201760948598815L;
	
	@JsonProperty("Standard")
	private StandardCpoCallStart Standard;
	@JsonProperty("CustomerAccess")
    private CustomerAccessCpoCallStart CustomerAccess;
	@JsonProperty("Extended")
    private ExtendedCpoCallStart Extended;
	@JsonProperty("Metadata")
    private MetadataCpoCallStart Metadata;

    public StandardCpoCallStart getStandard ()
    {
        return Standard;
    }

    public void setStandard (StandardCpoCallStart Standard)
    {
        this.Standard = Standard;
    }

    public CustomerAccessCpoCallStart getCustomerAccess ()
    {
        return CustomerAccess;
    }

    public void setCustomerAccess (CustomerAccessCpoCallStart CustomerAccess)
    {
        this.CustomerAccess = CustomerAccess;
    }

    public ExtendedCpoCallStart getExtended ()
    {
        return Extended;
    }

    public void setExtended (ExtendedCpoCallStart Extended)
    {
        this.Extended = Extended;
    }

    public MetadataCpoCallStart getMetadata ()
    {
        return Metadata;
    }

    public void setMetadata (MetadataCpoCallStart Metadata)
    {
        this.Metadata = Metadata;
    }

    @Override
    public String toString()
    {
        return "ClassPojo [Standard = "+Standard+", CustomerAccess = "+CustomerAccess+", Extended = "+Extended+", Metadata = "+Metadata+"]";
    }
}
