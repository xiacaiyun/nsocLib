package eap2.rts.common.eventhub.dto;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonProperty;

public class SDNMatchFoundRequest implements Serializable {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = -9168665134918054333L;
	@JsonProperty("Event")
	private EventSDNMatchFound event;
	
	public EventSDNMatchFound getEvent() {
		return event;
	}
	public void setEvent(EventSDNMatchFound event) {
		this.event = event;
	}
	@Override
	public String toString() {
		return "SDNMatchFoundRequest [event=" + event + "]";
	}
}
