package eap2.rts.common.appconfig.dto;

public class JobStatus {

}
