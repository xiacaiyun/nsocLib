package eap2.rts.common.eventhub.dto;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonProperty;

public class MetadataEPPLOPOfferView implements Serializable {
	
	private static final long serialVersionUID = 7996500457572784147L;
	
	@JsonProperty("OriginatorFunctionID")
    private String OriginatorFunctionID;
	@JsonProperty("OriginatorSubFunctionID")
    private String OriginatorSubFunctionID;
	@JsonProperty("OriginatorFunctionType")
    private String OriginatorFunctionType;
	@JsonProperty("OriginatorFunctionSubType")
	private String OriginatorFunctionSubType;
	
	
	public String getOriginatorFunctionID() {
		return OriginatorFunctionID;
	}
	public void setOriginatorFunctionID(String originatorFunctionID) {
		OriginatorFunctionID = originatorFunctionID;
	}
	public String getOriginatorSubFunctionID() {
		return OriginatorSubFunctionID;
	}
	public void setOriginatorSubFunctionID(String originatorSubFunctionID) {
		OriginatorSubFunctionID = originatorSubFunctionID;
	}
	public String getOriginatorFunctionType() {
		return OriginatorFunctionType;
	}
	public void setOriginatorFunctionType(String originatorFunctionType) {
		OriginatorFunctionType = originatorFunctionType;
	}
	public String getOriginatorFunctionSubType() {
		return OriginatorFunctionSubType;
	}
	public void setOriginatorFunctionSubType(String originatorFunctionSubType) {
		OriginatorFunctionSubType = originatorFunctionSubType;
	}
	@Override
	public String toString() {
		return "MetadataEPPLOPOfferView [OriginatorFunctionID=" + OriginatorFunctionID + ", OriginatorSubFunctionID="
				+ OriginatorSubFunctionID + ", OriginatorFunctionType=" + OriginatorFunctionType
				+ ", OriginatorFunctionSubType=" + OriginatorFunctionSubType + "]";
	}
	
	
	
}
