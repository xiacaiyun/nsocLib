package eap2.rts.common.appconfig.dto;

import java.io.Serializable;
import java.util.List;

public class EventAction implements Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = -1076576186325964244L;
	private Integer id;
	private Integer appEventId;
	private String actionTypeCode;
	private Integer execOrder;
	
	private List<EventActionDetail> eventActionDetails;

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public Integer getAppEventId() {
		return appEventId;
	}

	public void setAppEventId(Integer appEventId) {
		this.appEventId = appEventId;
	}

	public String getActionTypeCode() {
		return actionTypeCode;
	}

	public void setActionTypeCode(String actionTypeCode) {
		this.actionTypeCode = actionTypeCode;
	}

	public Integer getExecOrder() {
		return execOrder;
	}

	public void setExecOrder(Integer execOrder) {
		this.execOrder = execOrder;
	}

	public List<EventActionDetail> getEventActionDetails() {
		return eventActionDetails;
	}

	public void setEventActionDetails(List<EventActionDetail> eventActionDetails) {
		this.eventActionDetails = eventActionDetails;
	}

	@Override
	public String toString() {
		return "EventAction [id=" + id + ", appEventId=" + appEventId + ", actionTypeCode=" + actionTypeCode + ", execOrder=" + execOrder
				+ ", eventActionDetails=" + eventActionDetails + "]";
	}

	
}
