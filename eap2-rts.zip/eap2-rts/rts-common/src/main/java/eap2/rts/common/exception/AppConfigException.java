package eap2.rts.common.exception;

public class AppConfigException extends Exception {

	private static final long serialVersionUID = 8773220066096781899L;

	public AppConfigException() {
		super();
	}

	public AppConfigException(String arg0, Throwable arg1, boolean arg2, boolean arg3) {
		super(arg0, arg1, arg2, arg3);
	}

	public AppConfigException(String arg0, Throwable arg1) {
		super(arg0, arg1);
	}

	public AppConfigException(String arg0) {
		super(arg0);
	}

	public AppConfigException(Throwable arg0) {
		super(arg0);
	}

}
