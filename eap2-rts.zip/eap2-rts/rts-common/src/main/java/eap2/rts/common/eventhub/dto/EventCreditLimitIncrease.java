package eap2.rts.common.eventhub.dto;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonProperty;

public class EventCreditLimitIncrease implements Serializable {
	private static final long serialVersionUID = -1745832439899143429L;
	
	@JsonProperty("Standard")
	private StandardCreditLimitIncrease Standard;
	@JsonProperty("CustomerAccess")
    private CustomerAccessCreditLimitIncrease CustomerAccess;
	@JsonProperty("Extended")
    private ExtendedCreditLimitIncrease Extended;
	@JsonProperty("Metadata")
    private MetadataCreditLimitIncrease Metadata;

    public StandardCreditLimitIncrease getStandard ()
    {
        return Standard;
    }

    public void setStandard (StandardCreditLimitIncrease Standard)
    {
        this.Standard = Standard;
    }

    public CustomerAccessCreditLimitIncrease getCustomerAccess ()
    {
        return CustomerAccess;
    }

    public void setCustomerAccess (CustomerAccessCreditLimitIncrease CustomerAccess)
    {
        this.CustomerAccess = CustomerAccess;
    }

    public ExtendedCreditLimitIncrease getExtended ()
    {
        return Extended;
    }

    public void setExtended (ExtendedCreditLimitIncrease Extended)
    {
        this.Extended = Extended;
    }

    public MetadataCreditLimitIncrease getMetadata ()
    {
        return Metadata;
    }

    public void setMetadata (MetadataCreditLimitIncrease Metadata)
    {
        this.Metadata = Metadata;
    }

    @Override
    public String toString()
    {
        return "ClassPojo [Standard = "+Standard+", CustomerAccess = "+CustomerAccess+", Extended = "+Extended+", Metadata = "+Metadata+"]";
    }
}
