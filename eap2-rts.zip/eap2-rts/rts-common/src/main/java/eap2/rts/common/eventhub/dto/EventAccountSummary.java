package eap2.rts.common.eventhub.dto;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonProperty;

public class EventAccountSummary implements Serializable {
	private static final long serialVersionUID = 1862613073637734010L;
	
	@JsonProperty("Standard")
	private StandardAccountSummary Standard;
	@JsonProperty("CustomerAccess")
    private CustomerAccessAccountSummary CustomerAccess;
	@JsonProperty("Extended")
    private ExtendedAccountSummary Extended;
	@JsonProperty("Metadata")
    private MetadataAccountSummary Metadata;

    public StandardAccountSummary getStandard ()
    {
        return Standard;
    }

    public void setStandard (StandardAccountSummary Standard)
    {
        this.Standard = Standard;
    }

    public CustomerAccessAccountSummary getCustomerAccess ()
    {
        return CustomerAccess;
    }

    public void setCustomerAccess (CustomerAccessAccountSummary CustomerAccess)
    {
        this.CustomerAccess = CustomerAccess;
    }

    public ExtendedAccountSummary getExtended ()
    {
        return Extended;
    }

    public void setExtended (ExtendedAccountSummary Extended)
    {
        this.Extended = Extended;
    }

    public MetadataAccountSummary getMetadata ()
    {
        return Metadata;
    }

    public void setMetadata (MetadataAccountSummary Metadata)
    {
        this.Metadata = Metadata;
    }

    @Override
    public String toString()
    {
        return "ClassPojo [Standard = "+Standard+", CustomerAccess = "+CustomerAccess+", Extended = "+Extended+", Metadata = "+Metadata+"]";
    }
}
