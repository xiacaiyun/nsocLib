package eap2.rts.common.eventhub.dto;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonProperty;

public class ExtendedCardDecline implements Serializable {
	private static final long serialVersionUID = -2465569924123793L;
	
	@JsonProperty("ProductType")
	private String ProductType;

    public String getProductType ()
    {
        return ProductType;
    }

    public void setProductType (String ProductType)
    {
        this.ProductType = ProductType;
    }

    @Override
    public String toString()
    {
        return "ClassPojo [ProductType = "+ProductType+"]";
    }
}
