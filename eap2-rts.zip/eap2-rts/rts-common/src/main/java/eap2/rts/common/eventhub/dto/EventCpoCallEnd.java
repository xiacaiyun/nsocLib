package eap2.rts.common.eventhub.dto;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonProperty;

public class EventCpoCallEnd implements Serializable {
	private static final long serialVersionUID = 8482511807284347507L;
	
	@JsonProperty("Standard")
	private StandardCpoCallEnd Standard;
	@JsonProperty("CustomerAccess")
    private CustomerAccessCpoCallEnd CustomerAccess;
	@JsonProperty("Extended")
    private ExtendedCpoCallEnd Extended;
	@JsonProperty("Metadata")
    private MetadataCpoCallEnd Metadata;

    public StandardCpoCallEnd getStandard ()
    {
        return Standard;
    }

    public void setStandard (StandardCpoCallEnd Standard)
    {
        this.Standard = Standard;
    }

    public CustomerAccessCpoCallEnd getCustomerAccess ()
    {
        return CustomerAccess;
    }

    public void setCustomerAccess (CustomerAccessCpoCallEnd CustomerAccess)
    {
        this.CustomerAccess = CustomerAccess;
    }

    public ExtendedCpoCallEnd getExtended ()
    {
        return Extended;
    }

    public void setExtended (ExtendedCpoCallEnd Extended)
    {
        this.Extended = Extended;
    }

    public MetadataCpoCallEnd getMetadata ()
    {
        return Metadata;
    }

    public void setMetadata (MetadataCpoCallEnd Metadata)
    {
        this.Metadata = Metadata;
    }

    @Override
    public String toString()
    {
        return "ClassPojo [Standard = "+Standard+", CustomerAccess = "+CustomerAccess+", Extended = "+Extended+", Metadata = "+Metadata+"]";
    }
}
