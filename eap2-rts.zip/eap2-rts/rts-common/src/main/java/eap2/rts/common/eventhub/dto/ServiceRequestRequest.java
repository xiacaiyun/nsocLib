package eap2.rts.common.eventhub.dto;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonProperty;

public class ServiceRequestRequest implements Serializable {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 7266193016448157933L;
	@JsonProperty("Event")
	private EventServiceRequest event;
	
	public EventServiceRequest getEvent() {
		return event;
	}
	public void setEvent(EventServiceRequest event) {
		this.event = event;
	}
	@Override
	public String toString() {
		return "ServiceRequestRequest [event=" + event + "]";
	}
}
