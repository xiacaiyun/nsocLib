package eap2.rts.common.eventhub.dto;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonProperty;

public class EventChargeDispute implements Serializable {
	private static final long serialVersionUID = -537537146963278586L;
	
	@JsonProperty("Standard")
	private StandardChargeDispute Standard;
	@JsonProperty("CustomerAccess")
    private CustomerAccessChargeDispute CustomerAccess;
	@JsonProperty("Extended")
    private ExtendedChargeDispute Extended;
	@JsonProperty("Metadata")
    private MetadataChargeDispute Metadata;

    public StandardChargeDispute getStandard ()
    {
        return Standard;
    }

    public void setStandard (StandardChargeDispute Standard)
    {
        this.Standard = Standard;
    }

    public CustomerAccessChargeDispute getCustomerAccess ()
    {
        return CustomerAccess;
    }

    public void setCustomerAccess (CustomerAccessChargeDispute CustomerAccess)
    {
        this.CustomerAccess = CustomerAccess;
    }

    public ExtendedChargeDispute getExtended ()
    {
        return Extended;
    }

    public void setExtended (ExtendedChargeDispute Extended)
    {
        this.Extended = Extended;
    }

    public MetadataChargeDispute getMetadata ()
    {
        return Metadata;
    }

    public void setMetadata (MetadataChargeDispute Metadata)
    {
        this.Metadata = Metadata;
    }

    @Override
    public String toString()
    {
        return "ClassPojo [Standard = "+Standard+", CustomerAccess = "+CustomerAccess+", Extended = "+Extended+", Metadata = "+Metadata+"]";
    }
}
