package eap2.rts.common.event.dto;

import java.io.Serializable;
import java.util.List;

public class PossibleReasonResponseLog implements Serializable {
	private static final long serialVersionUID = 6228149926925428307L;
	private String request_dt_time;
	private String response_dt_time;
	private String request_queue;
	private String response_queue;
	private String message_id;
	private String errorcode;
	private String errordescription;
	private String clnt_nbr;
	private String cntry_cde;
	private List<PredictReason> predicted_reason;

	public String getErrorcode() {
		return errorcode;
	}

	public void setErrorcode(String errorcode) {
		this.errorcode = errorcode;
	}

	public String getErrordescription() {
		return errordescription;
	}

	public void setErrordescription(String errordescription) {
		this.errordescription = errordescription;
	}

	public String getRequest_dt_time() {
		return request_dt_time;
	}

	public void setRequest_dt_time(String request_dt_time) {
		this.request_dt_time = request_dt_time;
	}

	public String getResponse_dt_time() {
		return response_dt_time;
	}

	public void setResponse_dt_time(String response_dt_time) {
		this.response_dt_time = response_dt_time;
	}

	public String getRequest_queue() {
		return request_queue;
	}

	public void setRequest_queue(String request_queue) {
		this.request_queue = request_queue;
	}

	public String getResponse_queue() {
		return response_queue;
	}

	public void setResponse_queue(String response_queue) {
		this.response_queue = response_queue;
	}

	public String getMessage_id() {
		return message_id;
	}

	public void setMessage_id(String message_id) {
		this.message_id = message_id;
	}

	public String getClnt_nbr() {
		return clnt_nbr;
	}

	public void setClnt_nbr(String clnt_nbr) {
		this.clnt_nbr = clnt_nbr;
	}

	public String getCntry_cde() {
		return cntry_cde;
	}

	public void setCntry_cde(String cntry_cde) {
		this.cntry_cde = cntry_cde;
	}

	public List<PredictReason> getPredicted_reason() {
		return predicted_reason;
	}

	public void setPredicted_reason(List<PredictReason> predicted_reason) {
		this.predicted_reason = predicted_reason;
	}

	@Override
	public String toString() {
		return "PossibleReasonResponseLog [request_dt_time=" + request_dt_time + ", response_dt_time=" + response_dt_time + ", request_queue="
				+ request_queue + ", response_queue=" + response_queue + ", message_id=" + message_id + ", errorcode=" + errorcode
				+ ", errordescription=" + errordescription + ", clnt_nbr=" + clnt_nbr + ", cntry_cde=" + cntry_cde + ", predicted_reason="
				+ predicted_reason + "]";
	}

}
