package eap2.rts.common.eventhub.dto;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonProperty;

public class EventCreditCardReversal implements Serializable {
	private static final long serialVersionUID = 449742926700615924L;
	
	@JsonProperty("Standard")
	private StandardCreditCardReversal Standard;
	@JsonProperty("CustomerAccess")
    private CustomerAccessCreditCardReversal CustomerAccess;
	@JsonProperty("Extended")
    private ExtendedCreditCardReversal Extended;
	@JsonProperty("Metadata")
    private MetadataCreditCardReversal Metadata;

    public StandardCreditCardReversal getStandard ()
    {
        return Standard;
    }

    public void setStandard (StandardCreditCardReversal Standard)
    {
        this.Standard = Standard;
    }

    public CustomerAccessCreditCardReversal getCustomerAccess ()
    {
        return CustomerAccess;
    }

    public void setCustomerAccess (CustomerAccessCreditCardReversal CustomerAccess)
    {
        this.CustomerAccess = CustomerAccess;
    }

    public ExtendedCreditCardReversal getExtended ()
    {
        return Extended;
    }

    public void setExtended (ExtendedCreditCardReversal Extended)
    {
        this.Extended = Extended;
    }

    public MetadataCreditCardReversal getMetadata ()
    {
        return Metadata;
    }

    public void setMetadata (MetadataCreditCardReversal Metadata)
    {
        this.Metadata = Metadata;
    }

    @Override
    public String toString()
    {
        return "ClassPojo [Standard = "+Standard+", CustomerAccess = "+CustomerAccess+", Extended = "+Extended+", Metadata = "+Metadata+"]";
    }
}
