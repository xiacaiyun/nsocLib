package eap2.rts.common.eventhub.dto;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonProperty;

public class ExtendedCpoCallEnd implements Serializable {
	private static final long serialVersionUID = -6848955982782521859L;
	
	@JsonProperty("CPOAgentID")
	private String CPOAgentID;

	public String getCPOAgentID() {
		return CPOAgentID;
	}

	public void setCPOAgentID(String cPOAgentID) {
		CPOAgentID = cPOAgentID;
	}

	@Override
	public String toString() {
		return "ExtendedCpoCallEnd [CPOAgentID=" + CPOAgentID + "]";
	}
}
