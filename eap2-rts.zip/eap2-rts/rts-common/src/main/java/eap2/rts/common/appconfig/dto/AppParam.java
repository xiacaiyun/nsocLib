package eap2.rts.common.appconfig.dto;

public class AppParam implements java.io.Serializable {

	private static final long serialVersionUID = 1L;
	private Integer id;
	private Integer appId;
	private String paramTypeCode;
	private String paramName;
	private String paramValue;
	private String description;

	public AppParam() {
		super();
	}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public Integer getAppId() {
		return appId;
	}

	public void setAppId(Integer appId) {
		this.appId = appId;
	}

	public String getParamTypeCode() {
		return paramTypeCode;
	}

	public void setParamTypeCode(String paramTypeCode) {
		this.paramTypeCode = paramTypeCode;
	}

	public String getParamName() {
		return paramName;
	}

	public void setParamName(String paramName) {
		this.paramName = paramName;
	}

	public String getParamValue() {
		return paramValue;
	}

	public void setParamValue(String paramValue) {
		this.paramValue = paramValue;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	@Override
	public String toString() {
		return "AppParam [id=" + id + ", appId=" + appId + ", paramTypeCode=" + paramTypeCode + ", paramName=" + paramName + ", paramValue="
				+ paramValue + ", description=" + description + "]";
	}

}
