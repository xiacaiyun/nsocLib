package eap2.rts.common.event.dto;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonProperty;

public class PredictReason implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -2317171132955718997L;
	private String ReasonCode;
	private String ReasonDescription;
	private String Context;

	public String getReasoncode() {
		return ReasonCode;
	}

	@JsonProperty("ReasonCode")
	public void setReasoncode(String reasoncode) {
		this.ReasonCode = reasoncode;
	}

	public String getReasondescription() {
		return ReasonDescription;
	}

	@JsonProperty("ReasonDescription")
	public void setReasondescription(String reasondescription) {
		this.ReasonDescription = reasondescription;
	}

	public String getContext() {
		return Context;
	}

	@JsonProperty("Context")
	public void setContext(String context) {
		this.Context = context;
	}

}
