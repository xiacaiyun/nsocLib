package eap2.rts.common.eventhub.dto;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonProperty;

public class EPPLOPOfferViewRequest implements Serializable {
	
	private static final long serialVersionUID = -2074959952617216041L;
	
	@JsonProperty("Event")
	private EventEPPLOPOfferView event;
	
	public EventEPPLOPOfferView getEvent() {
		return event;
	}
	public void setEvent(EventEPPLOPOfferView event) {
		this.event = event;
	}
	@Override
	public String toString() {
		return "EventEPPLOPOfferViewRequest [event=" + event + "]";
	}
}
