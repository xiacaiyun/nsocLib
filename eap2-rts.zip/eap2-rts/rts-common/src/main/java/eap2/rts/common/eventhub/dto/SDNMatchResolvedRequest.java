package eap2.rts.common.eventhub.dto;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonProperty;

public class SDNMatchResolvedRequest implements Serializable {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 5151768060722688704L;
	@JsonProperty("Event")
	private EventSDNMatchResolved event;
	
	public EventSDNMatchResolved getEvent() {
		return event;
	}
	public void setEvent(EventSDNMatchResolved event) {
		this.event = event;
	}
	@Override
	public String toString() {
		return "SDNMatchResolvedRequest [event=" + event + "]";
	}
}
