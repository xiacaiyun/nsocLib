package eap2.rts.common.appconfig.dto;

import java.io.Serializable;

public class TenantAppParam implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = -2225713737545331997L;
	private Integer id;
	private Integer tenantId;
	private String paramTypeCode;
	private String paramName;
	private String paramValue;

	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public Integer getTenantId() {
		return tenantId;
	}
	public void setTenantId(Integer tenantId) {
		this.tenantId = tenantId;
	}
	public String getParamTypeCode() {
		return paramTypeCode;
	}
	public void setParamTypeCode(String paramTypeCode) {
		this.paramTypeCode = paramTypeCode;
	}
	public String getParamName() {
		return paramName;
	}
	public void setParamName(String paramName) {
		this.paramName = paramName;
	}
	public String getParamValue() {
		return paramValue;
	}
	public void setParamValue(String paramValue) {
		this.paramValue = paramValue;
	}
	@Override
	public String toString() {
		return "TenantAppParam [id=" + id + ", tenantId=" + tenantId + ", paramTypeCode=" + paramTypeCode
				+ ", paramName=" + paramName + ", paramValue=" + paramValue + "]";
	}
}
