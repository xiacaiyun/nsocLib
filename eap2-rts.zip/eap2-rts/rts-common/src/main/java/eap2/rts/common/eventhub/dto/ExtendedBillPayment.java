package eap2.rts.common.eventhub.dto;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonProperty;

public class ExtendedBillPayment implements Serializable {
	
	private static final long serialVersionUID = 3240617709628444666L;
	@JsonProperty("MerchantName")
	private String MerchantName;
	@JsonProperty("MerchantNo")
	private String MerchantNo;
	@JsonProperty("ReferenceNo")
	private String ReferenceNo;
	@JsonProperty("SourceAccountNo")
	private String SourceAccountNo;
	@JsonProperty("PaymentAmount")
	private String PaymentAmount;
	@JsonProperty("Currency")
	private String Currency;
	public String getMerchantName() {
		return MerchantName;
	}
	public void setMerchantName(String merchantName) {
		MerchantName = merchantName;
	}
	public String getMerchantNo() {
		return MerchantNo;
	}
	public void setMerchantNo(String merchantNo) {
		MerchantNo = merchantNo;
	}
	public String getReferenceNo() {
		return ReferenceNo;
	}
	public void setReferenceNo(String referenceNo) {
		ReferenceNo = referenceNo;
	}
	public String getSourceAccountNo() {
		return SourceAccountNo;
	}
	public void setSourceAccountNo(String sourceAccountNo) {
		SourceAccountNo = sourceAccountNo;
	}
	public String getPaymentAmount() {
		return PaymentAmount;
	}
	public void setPaymentAmount(String paymentAmount) {
		PaymentAmount = paymentAmount;
	}
	public String getCurrency() {
		return Currency;
	}
	public void setCurrency(String currency) {
		Currency = currency;
	}
}
