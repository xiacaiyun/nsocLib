/**
 * 
 */
package eap2.rts.common.event.dto;
import java.io.Serializable;
import java.math.BigInteger;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.datatype.XMLGregorianCalendar;
/**
 * @author as35686
 *
 */
/*@XmlAccessorType(XmlAccessType.FIELD)
@XmlRootElement(name = "TransactionMREReq")*/
public class TransactionMREFlatRes implements Serializable{
	
	@XmlElement(name = "Status")
    protected String status;
	private final static long serialVersionUID = 12343L;
    @XmlElement(name = "COPTransactionID", required = true)
    protected String copTransactionID;
    @XmlElement(name = "CountryCode", required = true)
    protected String countryCode;
    @XmlElement(name = "CustomerNo")
    protected String customerNo;
    @XmlElement(name = "AccountNo")
    protected String accountNo;
    @XmlElement(name = "CardNo")
    protected String cardNo;
    @XmlElement(name = "GeoRecommendation")
    protected String geoRecommendation;
    @XmlElement(name = "NonGeoRecommendation")
    protected String nonGeoRecommendation;
	@XmlElement(name = "GeoMerchantID")
    protected String geoMerchantID;
    @XmlElement(name = "NonGeoGeoMerchantID")
    protected String nonGeoGeoMerchantID;
    @XmlElement(name = "AccountCountryCode")
    protected String accountCountryCode;
    @XmlElement(name = "ProductCode")
    protected String productCode;
    @XmlElement(name = "ProductProcessorCode")
    protected String productProcessorCode;
    @XmlElement(name = "AccountNumber")
    protected String accountNumber;
    @XmlElement(name = "AccountCurrencyCode")
    protected String accountCurrencyCode;
    @XmlElement(name = "CustomerProf")
    protected String customerProf;
    @XmlElement(name = "AccountCurrency")
    protected String accountCurrency;
    @XmlElement(name = "BranchCode")
    protected String branchCode;
    @XmlElement(name = "AcqID")
    protected String acqID;
    @XmlElement(name = "MerchantCity")
    protected String merchantCity;
    @XmlElement(name = "MerchantCtry")
    protected String merchantCtry;
    @XmlElement(name = "TermID")
    protected String termID;
    @XmlElement(name = "MCC")
    protected String mcc;
    @XmlElement(name = "PoseMode")
    protected String poseMode;
    @XmlElement(name = "TDMaturityDate")
    @XmlSchemaType(name = "date")
    protected XMLGregorianCalendar tdMaturityDate;
    @XmlElement(name = "ExpDate")
    protected String expDate;
    @XmlElement(name = "OtherAcctNbr")
    protected String otherAcctNbr;
    @XmlElement(name = "OtherProdCode")
    protected String otherProdCode;
    @XmlElement(name = "OtherBankCode")
    protected String otherBankCode;
    @XmlElement(name = "OtherBranchCode")
    protected String otherBranchCode;
    @XmlElement(name = "OtherAcctName")
    protected String otherAcctName;
    @XmlElement(name = "OtherAcctAdd1")
    protected String otherAcctAdd1;
    @XmlElement(name = "OtherAcctAdd2")
    protected String otherAcctAdd2;
    @XmlElement(name = "OtherAcctCity")
    protected String otherAcctCity;
    @XmlElement(name = "OtherAcctState")
    protected String otherAcctState;
    @XmlElement(name = "OtherAcctCtry")
    protected String otherAcctCtry;
    @XmlElement(name = "OtherAcctZip")
    protected String otherAcctZip;
    @XmlElement(name = "ChequeNumber")
    protected BigInteger chequeNumber;
    @XmlElement(name = "ChequeStatus")
    protected String chequeStatus;
    @XmlElement(name = "DuplicateChequeFlag")
    protected String duplicateChequeFlag;
    @XmlElement(name = "FloatDays")
    protected String floatDays;
    @XmlElement(name = "AcctBal")
    protected String acctBal;
    @XmlElement(name = "AcctLedgBal")
    protected String acctLedgBal;
    @XmlElement(name = "PersonalAmountThresholds")
    protected String personalAmountThresholds;
    @XmlElement(name = "UniqRefNbr")
    protected String uniqRefNbr;
    @XmlElement(name = "AccountStatus")
    protected String accountStatus;
    @XmlElement(name = "AccountCloseRSN")
    protected String accountCloseRSN;
    @XmlElement(name = "TrmDepMatDate")
    protected String trmDepMatDate;
    @XmlElement(name = "Org")
    protected String org;
    @XmlElement(name = "CashWithdrawalDays")
    protected String cashWithdrawalDays;
    @XmlElement(name = "CashWithdrawalPeriod")
    protected String cashWithdrawalPeriod;
    @XmlElement(name = "CashWithdrawalPercent")
    protected String cashWithdrawalPercent;
    @XmlElement(name = "PayeeBankCode")
    protected String payeeBankCode;
    @XmlElement(name = "PayeeBankName")
    protected String payeeBankName;
    @XmlElement(name = "PayeeBranchCode")
    protected String payeeBranchCode;
    @XmlElement(name = "PayeeAccountNumber")
    protected String payeeAccountNumber;
    @XmlElement(name = "PayeeName")
    protected String payeeName;
    @XmlElement(name = "PaymentMode")
    protected String paymentMode;
    @XmlElement(name = "BeginningCheckSerialNumber")
    protected String beginningCheckSerialNumber;
    @XmlElement(name = "EndCheckSerialNumber")
    protected String endCheckSerialNumber;
    @XmlElement(name = "DCEMVFlag")
    protected String dcemvFlag;
    @XmlElement(name = "DCFallBackCount")
    protected String dcFallBackCount;
    @XmlElement(name = "TSTransactionCode")
    protected String tsTransactionCode;
    @XmlElement(name = "LogOnCountry")
    protected String logOnCountry;
    @XmlElement(name = "FundTransferType")
    protected String fundTransferType;
    @XmlElement(name = "ReversalIndicator")
    protected String reversalIndicator;
    @XmlElement(name = "SourceApplication")
    protected String sourceApplication;
    @XmlElement(name = "BlockCode")
    protected String blockCode;
    @XmlElement(name = "FirstTxnFlag")
    protected String firstTxnFlag;
    @XmlElement(name = "DCExpiryDate")
    protected String dcExpiryDate;
    @XmlElement(name = "FillerField1")
    protected String fillerField1;
    @XmlElement(name = "FillerField2")
    protected String fillerField2;
    @XmlElement(name = "FillerField3")
    protected String fillerField3;
    @XmlElement(name = "FillerField4")
    protected String fillerField4;
    @XmlElement(name = "FillerField5")
    protected String fillerField5;
    @XmlElement(name = "UniqueId")
    protected String uniqueId;
    @XmlElement(name = "AuthText")
    protected String authText;
    @XmlElement(name = "TxnCntryDate")
    @XmlSchemaType(name = "dateTime")
    protected XMLGregorianCalendar txnCntryDate;
    @XmlElement(name = "TxnSubChannel")
    protected String txnSubChannel;
    @XmlElement(name = "TxnCntryTime")
    @XmlSchemaType(name = "dateTime")
    protected XMLGregorianCalendar txnCntryTime;
    @XmlElement(name = "BizSegment")
    protected String bizSegment;
    @XmlElement(name = "SrcAcctStaffInd")
    protected String srcAcctStaffInd;
    @XmlElement(name = "DestAcctStaffInd")
    protected String destAcctStaffInd;
    @XmlElement(name = "DomicileCntryCD")
    protected String domicileCntryCD;
    @XmlElement(name = "AcctZipCD")
    protected String acctZipCD;
    @XmlElement(name = "BranchNbr")
    protected String branchNbr;
    @XmlElement(name = "TxnEffDate")
    @XmlSchemaType(name = "dateTime")
    protected XMLGregorianCalendar txnEffDate;
    @XmlElement(name = "TxnEffTime")
    @XmlSchemaType(name = "dateTime")
    protected XMLGregorianCalendar txnEffTime;
    @XmlElement(name = "AvgAcctBal")
    protected String avgAcctBal;
    @XmlElement(name = "ConsolidateAcctBal")
    protected String consolidateAcctBal;
    @XmlElement(name = "PhoneNum")
    protected String phoneNum;
    @XmlElement(name = "TPinConf")
    protected String tPinConf;
    @XmlElement(name = "CpoId")
    protected String cpoId;
    @XmlElement(name = "EnrollPhInd")
    protected String enrollPhInd;
    @XmlElement(name = "VerifyQuesIndF")
    protected String verifyQuesIndF;
    @XmlElement(name = "VerifyQuesInd")
    protected String verifyQuesInd;
    @XmlElement(name = "MerchIpAddress")
    protected String merchIpAddress;
    @XmlElement(name = "UserTyp")
    protected String userTyp;
    @XmlElement(name = "AtmLocation")
    protected String atmLocation;
    @XmlElement(name = "EmvChipInd")
    protected String emvChipInd;
    @XmlElement(name = "CustSsnNric")
    protected String custSsnNric;
    @XmlElement(name = "BarcdInfo")
    protected String barcdInfo;
    @XmlElement(name = "DebitType")
    protected String debitType;
    @XmlElement(name = "LsnCode")
    protected String lsnCode;
    @XmlElement(name = "CenterCode")
    protected String centerCode;
    @XmlElement(name = "RetnCode")
    protected String retnCode;
    @XmlElement(name = "RetnMsg")
    protected String retnMsg;
    @XmlElement(name = "MerchantKey")
    protected String merchantKey;
    @XmlElement(name = "MerchantOrg")
    protected String merchantOrg;
    @XmlElement(name = "MerchantNumber")
    protected String merchantNumber;
    @XmlElement(name = "OperatorID")
    protected String operatorID;
    @XmlElement(name = "ApprovalID")
    protected String approvalID;
    @XmlElement(name = "OASATC")
    protected String oasatc;
    @XmlElement(name = "ApprovalTC")
    protected String approvalTC;
    @XmlElement(name = "VisaDeclineReferralTC")
    protected String visaDeclineReferralTC;
    //Records
    @XmlElement(name = "amountType")
    protected String amountType;
    @XmlElement(name = "additionalAmount")
    protected String additionalAmount;
    @XmlElement(name = "currencyCode")
    protected String recordCurrencyCode;
    @XmlElement(name = "accountType")
    protected String recordAccountType;
    //**********************************************/
    @XmlElement(name = "MasterApprovalTC")
    protected String masterApprovalTC;
    @XmlElement(name = "MasterDeclineTC")
    protected String masterDeclineTC;
    @XmlElement(name = "JCBApprovalTC")
    protected String jcbApprovalTC;
    @XmlElement(name = "FromAccountCode")
    protected String fromAccountCode;
    @XmlElement(name = "ToAccountCode")
    protected String toAccountCode;
    @XmlElement(name = "ChBlngAmt")
    protected String chBlngAmt;
    @XmlElement(name = "GMTDateTime")
    @XmlSchemaType(name = "date")
    protected XMLGregorianCalendar gmtDateTime;
    @XmlElement(name = "ChRateConversion")
    protected String chRateConversion;
    @XmlElement(name = "CDCAmount")
    protected String cdcAmount;
    @XmlElement(name = "ExpiryDate")
    @XmlSchemaType(name = "date")
    protected XMLGregorianCalendar expiryDate;
    @XmlElement(name = "ExpiryDateMM")
    @XmlSchemaType(name = "date")
    protected XMLGregorianCalendar expiryDateMM;
    @XmlElement(name = "ExpiryDateYY")
    @XmlSchemaType(name = "date")
    protected XMLGregorianCalendar expiryDateYY;
    @XmlElement(name = "CountryCode")
    protected String transactionCardCountryCode;
    @XmlElement(name = "MerchantType")
    protected String merchantType;    
    @XmlElement(name = "PosEntryMode")
    protected String posEntryMode;
    @XmlElement(name = "PinCAP")
    protected String pinCAP;
    @XmlElement(name = "AcquirerID")
    protected String acquirerID;
    @XmlElement(name = "ForwardID")
    protected String forwardID;
    @XmlElement(name = "AuthorizationCode")
    protected String authorizationCode;
    @XmlElement(name = "SvcRestCode")
    protected String svcRestCode;
    @XmlElement(name = "CardAcceptRec")
    protected String cardAcceptRec;
    @XmlElement(name = "CardAcceptStore")
    protected String cardAcceptStore;
    @XmlElement(name = "MerchantID")
    protected String merchantID;
    @XmlElement(name = "AcceptorIDCode")
    protected String acceptorIDCode;
    @XmlElement(name = "ChbCurrencyCode")
    protected String chbCurrencyCode;
    @XmlElement(name = "ForceFlag")
    protected String forceFlag;
    @XmlElement(name = "InputSource")
    protected String inputSource;
    @XmlElement(name = "CardType")
    protected String cardType;
    @XmlElement(name = "RevCode")
    protected String revCode;
    @XmlElement(name = "UnderMerchFloor")
    protected String underMerchFloor;
    @XmlElement(name = "SourceTerminal")
    protected String sourceTerminal;
    @XmlElement(name = "TimeSent")
    protected String timeSent;
    @XmlElement(name = "ABSTimeSent")
    @XmlSchemaType(name = "date")
    protected XMLGregorianCalendar absTimeSent;
    @XmlElement(name = "TimeReceived")
    @XmlSchemaType(name = "date")
    protected XMLGregorianCalendar timeReceived;
    @XmlElement(name = "ABSTimeReceived")
    @XmlSchemaType(name = "date")
    protected XMLGregorianCalendar absTimeReceived;
    @XmlElement(name = "DeclineReason")
    protected String declineReason;
    @XmlElement(name = "SourceTransID")
    protected String sourceTransID;
    @XmlElement(name = "MerchantName")
    protected String merchantName;
    @XmlElement(name = "CardSequenceNumber")
    protected String cardSequenceNumber;
    @XmlElement(name = "ReferralReason")
    protected String referralReason;
    @XmlElement(name = "SuspiciousInd")
    protected String suspiciousInd;
    @XmlElement(name = "CMRiskLevel")
    protected String cmRiskLevel;
    @XmlElement(name = "CRLimit")
    protected String crLimit;
    @XmlElement(name = "AvailCredit")
    protected String availCredit;
    @XmlElement(name = "CommitAmount")
    protected String commitAmount;
    @XmlElement(name = "TotalApprovalCount")
    protected String totalApprovalCount;
    @XmlElement(name = "TotalDeclineCount")
    protected String totalDeclineCount;
    @XmlElement(name = "XdaysApprCount")
    protected String xdaysApprCount;
    @XmlElement(name = "TrackDataInd")
    protected String trackDataInd;
    @XmlElement(name = "SeltDate")
    @XmlSchemaType(name = "date")
    protected XMLGregorianCalendar seltDate;
    @XmlElement(name = "CRDAcceptRec")
    protected String crdAcceptRec;
    @XmlElement(name = "ReferralCode")
    protected String referralCode;
    @XmlElement(name = "RCCheckNumber")
    protected String rcCheckNumber;
    @XmlElement(name = "SettleIndicator")
    protected String settleIndicator;
    @XmlElement(name = "TransactionSource")
    protected String transactionSource;
    @XmlElement(name = "TransactionAdvice")
    protected String transactionAdvice;
    @XmlElement(name = "FullChipTransaction")
    protected String fullChipTransaction;
    @XmlElement(name = "AcquirerIndicator")
    protected String acquirerIndicator;
    @XmlElement(name = "TermEntCap")
    protected String termEntCap;
    @XmlElement(name = "CHIPConditionCode")
    protected String chipConditionCode;
    @XmlElement(name = "CCPSTransIndicator")
    protected String ccpsTransIndicator;
    @XmlElement(name = "ICCIsaCBAFlag")
    protected String iccIsaCBAFlag;
    @XmlElement(name = "ICCOPTIssCurrency")
    protected String iccoptIssCurrency;
    @XmlElement(name = "ICCOPTIssExpiry")
    protected String iccoptIssExpiry;
    @XmlElement(name = "CurrencyBehaviorScore")
    protected String currencyBehaviorScore;
    @XmlElement(name = "AuthScenID")
    protected String authScenID;
    @XmlElement(name = "AuthStgyID")
    protected String authStgyID;
    @XmlElement(name = "AuthorDigitGroup")
    protected String authorDigitGroup;
    @XmlElement(name = "ReturnMsgDecline")
    protected String returnMsgDecline;
    @XmlElement(name = "VisaAuthData")
    protected String visaAuthData;
    @XmlElement(name = "VisaPosCondCode")
    protected String visaPosCondCode;
    @XmlElement(name = "VisaStipRespCode")
    protected String visaStipRespCode;
    @XmlElement(name = "VisaIssuRetCode")
    protected String visaIssuRetCode;
    @XmlElement(name = "VisaStipRetCode")
    protected String visaStipRetCode;
    @XmlElement(name = "VisaAvsResult")
    protected String visaAvsResult;
    @XmlElement(name = "StateCode")
    protected String stateCode;
    @XmlElement(name = "CountyCode")
    protected String countyCode;
    @XmlElement(name = "Zip9")
    protected String zip9;
    @XmlElement(name = "Zip5")
    protected String zip5;
    @XmlElement(name = "TransactionID")
    protected String transactionID;
    @XmlElement(name = "RepeatTransaction")
    protected String repeatTransaction;
    @XmlElement(name = "VisaMerchantGroup")
    protected String visaMerchantGroup;
    @XmlElement(name = "VisaSourceStationID")
    protected String visaSourceStationID;
    @XmlElement(name = "VisaVisaphoneCode")
    protected String visaVisaphoneCode;
    @XmlElement(name = "VisaAutoSvcCode")
    protected String visaAutoSvcCode;
    @XmlElement(name = "VisaCWDenialRSN")
    protected String visaCWDenialRSN;
    @XmlElement(name = "VisaPacmDvrLevel")
    protected String visaPacmDvrLevel;
    @XmlElement(name = "VisaPacmDvrRSN")
    protected String visaPacmDvrRSN;
    @XmlElement(name = "VisaCaResult")
    protected String visaCaResult;
    @XmlElement(name = "VisaDebitOrg")
    protected String visaDebitOrg;
    @XmlElement(name = "VisaDebitType")
    protected String visaDebitType;
    @XmlElement(name = "VisaDebitAccount")
    protected String visaDebitAccount;
    @XmlElement(name = "VisaDebitRiskLevel")
    protected String visaDebitRiskLevel;
    @XmlElement(name = "VisaDebitTipAmount")
    protected String visaDebitTipAmount;
    @XmlElement(name = "VisaTermCountryCode")
    protected String visaTermCountryCode;
    @XmlElement(name = "VisatTermTransactionDate")
    @XmlSchemaType(name = "date")
    protected XMLGregorianCalendar visatTermTransactionDate;
    @XmlElement(name = "MasterTCType")
    protected String masterTCType;
    @XmlElement(name = "MasterSpecialTCFlag")
    protected String masterSpecialTCFlag;
    @XmlElement(name = "MasterStateCode")
    protected String masterStateCode;
    @XmlElement(name = "MasterPosDevice")
    protected String masterPosDevice;
    @XmlElement(name = "MasterAvsOptionCode")
    protected String masterAvsOptionCode;
    @XmlElement(name = "MasterAvsResult")
    protected String masterAvsResult;
    @XmlElement(name = "MasterAuthAgentOld")
    protected String masterAuthAgentOld;
    @XmlElement(name = "MasterPaymentSvcIndicator")
    protected String masterPaymentSvcIndicator;
    @XmlElement(name = "MasterValidationCode")
    protected String masterValidationCode;
    @XmlElement(name = "MasterDownGrade")
    protected String masterDownGrade;
    @XmlElement(name = "MasterReptRteConversion")
    protected String masterReptRteConversion;
    @XmlElement(name = "MasterAuthAgentID")
    protected String masterAuthAgentID;
    @XmlElement(name = "DinersResponseCode")
    protected String dinersResponseCode;
    @XmlElement(name = "DinersStandingCode")
    protected String dinersStandingCode;
    @XmlElement(name = "DinersMerchantGroup")
    protected String dinersMerchantGroup;
    @XmlElement(name = "DinersReqFranchise")
    protected String dinersReqFranchise;
    @XmlElement(name = "DinersOwnFranchise")
    protected String dinersOwnFranchise;
    @XmlElement(name = "DinersErrorCode")
    protected String dinersErrorCode;
    @XmlElement(name = "FullAuthReasonCode")
    protected String fullAuthReasonCode;
    @XmlElement(name = "DinersReferralResponse")
    protected String dinersReferralResponse;
    @XmlElement(name = "DinersTimer")
    protected String dinersTimer;
    @XmlElement(name = "CardProduct")
    protected String cardProduct;
    @XmlElement(name = "ResponseCode")
    protected String responseCode;
    @XmlElement(name = "RegionCodes")
    protected String regionCodes;
    @XmlElement(name = "OldOverridePurgeDate")
    @XmlSchemaType(name = "date")
    protected XMLGregorianCalendar oldOverridePurgeDate;
    @XmlElement(name = "NewOverridePurgeDate")
    @XmlSchemaType(name = "date")
    protected XMLGregorianCalendar newOverridePurgeDate;
    @XmlElement(name = "OldOverrideCode")
    protected String oldOverrideCode;
    @XmlElement(name = "NewOverrideCode")
    protected String newOverrideCode;
    @XmlElement(name = "OldInstantUpgrade")
    protected String oldInstantUpgrade;
    @XmlElement(name = "NewInstantUpdade")
    protected String newInstantUpdade;
    @XmlElement(name = "InstantUpgradeVerifyID")
    protected String instantUpgradeVerifyID;
    @XmlElement(name = "PinCustomerNumber")
    protected String pinCustomerNumber;
    @XmlElement(name = "OldPinOffset")
    protected String oldPinOffset;
    @XmlElement(name = "NewPinOffset")
    protected String newPinOffset;
    @XmlElement(name = "NewPinKey")
    protected String newPinKey;
    @XmlElement(name = "OldPinRetryCount")
    protected String oldPinRetryCount;
    @XmlElement(name = "NewPinRetryCount")
    protected String newPinRetryCount;
    @XmlElement(name = "OldSetStatus")
    protected String oldSetStatus;
    @XmlElement(name = "NewSetStatus")
    protected String newSetStatus;
    @XmlElement(name = "OldSetReason")
    protected String oldSetReason;
    @XmlElement(name = "NewSetReason")
    protected String newSetReason;
    @XmlElement(name = "OldSetDateProc")
    protected String oldSetDateProc;
    @XmlElement(name = "NewSetDateProc")
    protected String newSetDateProc;
    @XmlElement(name = "OfflineBlock")
    protected String offlineBlock;
    @XmlElement(name = "OldEmvCardUse")
    protected String oldEmvCardUse;
    @XmlElement(name = "PreviousEmvCardUseIndicator")
    protected String previousEmvCardUseIndicator;
    @XmlElement(name = "NewEmvCardUse")
    protected String newEmvCardUse;
    @XmlElement(name = "SettAmount")
    protected String settAmount;
    @XmlElement(name = "SettDate")
    protected String settDate;
    @XmlElement(name = "CardAcceptTerm")
    protected String cardAcceptTerm;
    @XmlElement(name = "SettCurrencyCode")
    protected String settCurrencyCode;
    @XmlElement(name = "ConsCommitAmount")
    protected String consCommitAmount;
    @XmlElement(name = "DciIntfAmount")
    protected String dciIntfAmount;
    @XmlElement(name = "DciIntfCurrencyCode")
    protected String dciIntfCurrencyCode;
    @XmlElement(name = "DinersActionCode")
    protected String dinersActionCode;
    @XmlElement(name = "DinersCardCurrency")
    protected String dinersCardCurrency;
    @XmlElement(name = "EdcIndicator")
    protected String edcIndicator;
    @XmlElement(name = "ExceptionResponseCode")
    protected String exceptionResponseCode;
    @XmlElement(name = "FromOldCardIndicator")
    protected String fromOldCardIndicator;
    @XmlElement(name = "InstUpgChangeType")
    protected String instUpgChangeType;
    @XmlElement(name = "InstUpgLimit")
    protected String instUpgLimit;
    @XmlElement(name = "InstUpgPurgeDate")
    @XmlSchemaType(name = "date")
    protected XMLGregorianCalendar instUpgPurgeDate;
    @XmlElement(name = "ISOResponseCode")
    protected String isoResponseCode;
    @XmlElement(name = "OverrideCodePurgeDate")
    @XmlSchemaType(name = "date")
    protected XMLGregorianCalendar overrideCodePurgeDate;
    @XmlElement(name = "PhoneCardResponseCode")
    protected String phoneCardResponseCode;
    @XmlElement(name = "PinTermID")
    protected String pinTermID;
    @XmlElement(name = "TPinResetIndicator")
    protected String tPinResetIndicator;
    @XmlElement(name = "MasterSetlementDate")
    @XmlSchemaType(name = "date")
    protected XMLGregorianCalendar masterSetlementDate;
    @XmlElement(name = "CardAuthorRI")
    protected String cardAuthorRI;
    @XmlElement(name = "ProcessCode")
    protected String processCode;
    @XmlElement(name = "ChBilingAmount")
    protected String chBilingAmount;
    @XmlElement(name = "CRCDecSep")
    protected String crcDecSep;
    @XmlElement(name = "ExpiryDatePresence")
    protected String expiryDatePresence;
    @XmlElement(name = "PosEmPan")
    protected String posEmPan;
    @XmlElement(name = "CardSeqNbr")
    protected String cardSeqNbr;
    @XmlElement(name = "TypeBMerchantID")
    protected String typeBMerchantID;
    @XmlElement(name = "ICCpseudoTerm")
    protected String icCpseudoTerm;
    @XmlElement(name = "CMBlockCode")
    protected String cmBlockCode;
    @XmlElement(name = "CW2CVC2")
    protected String cw2CVC2;
    @XmlElement(name = "CW2Presence")
    protected String cw2Presence;
    @XmlElement(name = "ExceptionPurgeDate")
    @XmlSchemaType(name = "date")
    protected XMLGregorianCalendar exceptionPurgeDate;
    @XmlElement(name = "IccIsaCCAAmount")
    protected String iccIsaCCAAmount;
    @XmlElement(name = "IccIsaCCASettlement")
    protected String iccIsaCCASettlement;
    @XmlElement(name = "ICCOIFCBAAmount")
    protected String iccoifcbaAmount;
    @XmlElement(name = "ICCOptIssAmount")
    protected String iccOptIssAmount;
    @XmlElement(name = "InvCWCVC2Indicator")
    protected String invCWCVC2Indicator;
    @XmlElement(name = "InvCWCVCIndicator")
    protected String invCWCVCIndicator;
    @XmlElement(name = "JetcoAcquirerBin")
    protected String jetcoAcquirerBin;
    @XmlElement(name = "MasterSettlementAmount")
    protected String masterSettlementAmount;
    @XmlElement(name = "MasterRRCAmount")
    protected String masterRRCAmount;
    @XmlElement(name = "MasterRRCDecSep")
    protected String masterRRCDecSep;
    @XmlElement(name = "MasterRetrivalNumber")
    protected String masterRetrivalNumber;
    @XmlElement(name = "MasterResponseCode")
    protected String masterResponseCode;
    @XmlElement(name = "MasterECI")
    protected String masterECI;
    @XmlElement(name = "MasterInvoiceCvcIndicator")
    protected String masterInvoiceCvcIndicator;
    @XmlElement(name = "MasterTRK2ErrorIndicator")
    protected String masterTRK2ErrorIndicator;
    @XmlElement(name = "MasterTrk2TfmIndicator")
    protected String masterTrk2TfmIndicator;
    @XmlElement(name = "MasterTransactionIndicator")
    protected String masterTransactionIndicator;
    @XmlElement(name = "MasterUCAF")
    protected String masterUCAF;
    @XmlElement(name = "MasterUCAFData")
    protected String masterUCAFData;
    @XmlElement(name = "MasterCardTermIndicator")
    protected String masterCardTermIndicator;
    @XmlElement(name = "MasterPosData")
    protected String masterPosData;
    @XmlElement(name = "MasterPosDataLen")
    protected String masterPosDataLen;
    @XmlElement(name = "MasterBnkntDataRec")
    protected String masterBnkntDataRec;
    @XmlElement(name = "MasterBnkntRefNumber")
    protected String masterBnkntRefNumber;
    @XmlElement(name = "MasterFnclNetworkCode")
    protected String masterFnclNetworkCode;
    @XmlElement(name = "MasterChipData")
    protected String masterChipData;
    @XmlElement(name = "MasterDownOption")
    protected String masterDownOption;
    @XmlElement(name = "MasterDownReason")
    protected String masterDownReason;
    @XmlElement(name = "MasterOptional0130")
    protected String masterOptional0130;
    @XmlElement(name = "MasterOptional3160")
    protected String masterOptional3160;
    @XmlElement(name = "MasterOptionalData")
    protected String masterOptionalData;
    @XmlElement(name = "MasterOptionalDataLen")
    protected String masterOptionalDataLen;
    @XmlElement(name = "NewAltBlockCodeR")
    protected String newAltBlockCodeR;
    @XmlElement(name = "TerminalID")
    protected String terminalID;
    @XmlElement(name = "TraceNbr")
    protected String traceNbr;
    @XmlElement(name = "TrackData")
    protected String trackData;
    @XmlElement(name = "ValidCAWIndicator")
    protected String validCAWIndicator;
    @XmlElement(name = "VisaSystemAuditTrace")
    protected String visaSystemAuditTrace;
    @XmlElement(name = "VisaB044CAW")
    protected String visaB044CAW;
    @XmlElement(name = "VisaCAWReturnCode")
    protected String visaCAWReturnCode;
    @XmlElement(name = "VisaPacmRsn")
    protected String visaPacmRsn;
    @XmlElement(name = "VisaAdditional0130")
    protected String visaAdditional0130;
    @XmlElement(name = "VisaAdditional3160")
    protected String visaAdditional3160;
    @XmlElement(name = "VisaAdditionalData")
    protected String visaAdditionalData;
    @XmlElement(name = "VisaAdditionalDataLength")
    protected String visaAdditionalDataLength;
    @XmlElement(name = "VisaCountryCodeX")
    protected String visaCountryCodeX;
    @XmlElement(name = "VisaPosGeoDataLength")
    protected String visaPosGeoDataLength;
    @XmlElement(name = "VisaPosGeoDataRecord")
    protected String visaPosGeoDataRecord;
    @XmlElement(name = "VisaStateCodeX")
    protected String visaStateCodeX;
    @XmlElement(name = "VisaPosEntryCode")
    protected String visaPosEntryCode;
    @XmlElement(name = "VisaPosEntryLength")
    protected String visaPosEntryLength;
    @XmlElement(name = "VisaAmountLength")
    protected String visaAmountLength;
    @XmlElement(name = "VisaAmountSub01")
    protected String visaAmountSub01;
    @XmlElement(name = "VisaAmountSub02")
    protected String visaAmountSub02;
    @XmlElement(name = "VisaAmountSub03")
    protected String visaAmountSub03;
    @XmlElement(name = "VisaPaymentSvcIndicator")
    protected String visaPaymentSvcIndicator;
    @XmlElement(name = "VisaPaymentSvcLength")
    protected String visaPaymentSvcLength;
    @XmlElement(name = "VisaValidationCode")
    protected String visaValidationCode;
    @XmlElement(name = "VisaAccountTransactionAmount")
    protected String visaAccountTransactionAmount;
    @XmlElement(name = "VisaB126CAW")
    protected String visaB126CAW;
    @XmlElement(name = "VisaXid")
    protected String visaXid;
    @XmlElement(name = "VisaTermCapProf")
    protected String visaTermCapProf;
    @XmlElement(name = "VisaTermVerificationRS")
    protected String visaTermVerificationRS;
    @XmlElement(name = "VisaUnpredictNumber")
    protected String visaUnpredictNumber;
    @XmlElement(name = "VisaTermSerialNumber")
    protected String visaTermSerialNumber;
    @XmlElement(name = "VisaDiscrData")
    protected String visaDiscrData;
    @XmlElement(name = "VisaDiscrLength")
    protected String visaDiscrLength;
    @XmlElement(name = "VisaIssDiscrData")
    protected String visaIssDiscrData;
    @XmlElement(name = "VisaIssDiscrLength")
    protected String visaIssDiscrLength;
    @XmlElement(name = "VisaCryptogram")
    protected String visaCryptogram;
    @XmlElement(name = "VisaAppTransactionCounter")
    protected String visaAppTransactionCounter;
    @XmlElement(name = "VisaAppIntegProf")
    protected String visaAppIntegProf;
    @XmlElement(name = "VisaArpcData")
    protected String visaArpcData;
    @XmlElement(name = "VisaIssAuthData")
    protected String visaIssAuthData;
    @XmlElement(name = "VisaIssAuthLength")
    protected String visaIssAuthLength;
    @XmlElement(name = "VisaIssScriptData")
    protected String visaIssScriptData;
    @XmlElement(name = "VisaIssScriptLength")
    protected String visaIssScriptLength;
    @XmlElement(name = "VisaIssScriptr")
    protected String visaIssScriptr;
    @XmlElement(name = "VisaIssScriptrLength")
    protected String visaIssScriptrLength;
    @XmlElement(name = "VisaCrytoTransactionType")
    protected String visaCrytoTransactionType;
    @XmlElement(name = "VisaCryptoAmount")
    protected String visaCryptoAmount;
    @XmlElement(name = "VisaCryptoCurrencyCode")
    protected String visaCryptoCurrencyCode;
    @XmlElement(name = "VisaCryptoCashback")
    protected String visaCryptoCashback;
    @XmlElement(name = "VisaDebitTipAmountV99")
    protected String visaDebitTipAmountV99;
    @XmlElement(name = "TransactionAmountV99")
    protected String transactionAmountV99;
    @XmlElement(name = "AccountType")
    protected String accountType;
    @XmlElement(name = "CurrencyCode")
    protected String currencyCode;
    @XmlElement(name = "Batchnumber")
    protected String batchnumber;
    @XmlElement(name = "BlockMaintFlag")
    protected String blockMaintFlag;
    @XmlElement(name = "CardMaintOperatorID")
    protected String cardMaintOperatorID;
    @XmlElement(name = "CardMaintType")
    protected String cardMaintType;
    @XmlElement(name = "ICCOrigB051")
    protected String iccOrigB051;
    @XmlElement(name = "NewBlockCode")
    protected String newBlockCode;
    @XmlElement(name = "NewBlockCodeDate")
    @XmlSchemaType(name = "date")
    protected XMLGregorianCalendar newBlockCodeDate;
    @XmlElement(name = "NewBlockCodeR")
    protected String newBlockCodeR;
    @XmlElement(name = "NewBlockCodeTime")
    @XmlSchemaType(name = "date")
    protected XMLGregorianCalendar newBlockCodeTime;
    @XmlElement(name = "OldBlockCode")
    protected String oldBlockCode;
    @XmlElement(name = "OldBlockCodeR")
    protected String oldBlockCodeR;
    @XmlElement(name = "OnlinePrint")
    protected String onlinePrint;
    @XmlElement(name = "OptionalDataIndicator")
    protected String optionalDataIndicator;
   
    @XmlElement(name = "PinDataPresent")
    protected String pinDataPresent;
    @XmlElement(name = "PinKey")
    protected String pinKey;
    @XmlElement(name = "PinOffset")
    protected String pinOffset;
    @XmlElement(name = "PrevBlockCode")
    protected String prevBlockCode;
    @XmlElement(name = "PrevBlockCodeR")
    protected String prevBlockCodeR;
    @XmlElement(name = "RecordType")
    protected String recordType;
    @XmlElement(name = "RefNumber")
    protected String refNumber;
    @XmlElement(name = "RefNumberX")
    protected String refNumberX;
    @XmlElement(name = "ReplaceDigit")
    protected String replaceDigit;
    @XmlElement(name = "SpeicalHandlingFile")
    protected String speicalHandlingFile;
    @XmlElement(name = "SuppIndicator")
    protected String suppIndicator;
    @XmlElement(name = "VisaB060910")
    protected String visaB060910;
    @XmlElement(name = "TerminalIDX")
    protected String terminalIDX;
    @XmlElement(name = "TFC0005CWSPID")
    protected String tfc0005CWSPID;
    @XmlElement(name = "KeyEOD")
    protected String keyEOD;
    @XmlElement(name = "KeyTieBreak")
    protected String keyTieBreak;
    @XmlElement(name = "KeyFileSeg")
    protected String keyFileSeg;
    @XmlElement(name = "EODIndicator")
    protected String eodIndicator;
    @XmlElement(name = "ActivityData")
    protected String activityData;
    @XmlElement(name = "MessageArea")
    protected String messageArea;
    @XmlElement(name = "SpecialRecordType")
    protected String specialRecordType;
    @XmlElement(name = "MaintenanceRecord")
    protected String maintenanceRecord;
    @XmlElement(name = "LocalTxnTime")
    protected String localTxnTime;
    @XmlElement(name = "LocalTxnDate")
    protected String localTxnDate;
    @XmlElement(name = "RetrievalNumber")
    protected String retrievalNumber;
    @XmlElement(name = "AMEDCrLimit")
    protected String amedCrLimit;
    @XmlElement(name = "AMBSCrLimit")
    protected String ambsCrLimit;
    @XmlElement(name = "AMRMCrLimit")
    protected String amrmCrLimit;
    @XmlElement(name = "AMEDAvailCrLimit")
    protected String amedAvailCrLimit;
    @XmlElement(name = "AMBSAvailCrLimit")
    protected String ambsAvailCrLimit;
    @XmlElement(name = "AMRMAvailCrLimit")
    protected String amrmAvailCrLimit;
    @XmlElement(name = "AMEDCommitAmount")
    protected String amedCommitAmount;
    @XmlElement(name = "AMBSCommitAmount")
    protected String ambsCommitAmount;
    @XmlElement(name = "AMRMCommitAmount")
    protected String amrmCommitAmount;
    @XmlElement(name = "AMEDEWSBlockCode")
    protected String amedewsBlockCode;
    @XmlElement(name = "AMBSEWSBlockCode1")
    protected String ambsewsBlockCode1;
    @XmlElement(name = "AMBSEWSBlockCode2")
    protected String ambsewsBlockCode2;
    @XmlElement(name = "AMRMEWSBlockCode")
    protected String amrmewsBlockCode;
    @XmlElement(name = "EWSRiskLevel")
    protected String ewsRiskLevel;
    @XmlElement(name = "EWSActivationInd")
    protected String ewsActivationInd;
    @XmlElement(name = "EWSActivationDate")
    protected String ewsActivationDate;
    @XmlElement(name = "EWSBSScore")
    protected String ewsbsScore;
    @XmlElement(name = "EWSAmountAuthToday")
    protected String ewsAmountAuthToday;
    @XmlElement(name = "DailyRTLNumber")
    protected String dailyRTLNumber;
    @XmlElement(name = "DailyRTLAmount")
    protected String dailyRTLAmount;
    @XmlElement(name = "DailyCashNumber")
    protected String dailyCashNumber;
    @XmlElement(name = "DailyCashAmount")
    protected String dailyCashAmount;
    @XmlElement(name = "DailyMCCNumber")
    protected String dailyMCCNumber;
    @XmlElement(name = "DailyMCCAmount")
    protected String dailyMCCAmount;
    @XmlElement(name = "XDaysRTLNumber")
    protected String xDaysRTLNumber;
    @XmlElement(name = "XDaysRTLAmount")
    protected String xDaysRTLAmount;
    @XmlElement(name = "XDaysCashNumber")
    protected String xDaysCashNumber;
    @XmlElement(name = "XDaysCashAmount")
    protected String xDaysCashAmount;
    @XmlElement(name = "XDaysMCCAmount")
    protected String xDaysMCCAmount;
    @XmlElement(name = "DeclRSN")
    protected String declRSN;
    @XmlElement(name = "MatchedInd")
    protected String matchedInd;
    @XmlElement(name = "AuthorisationClass")
    protected String authorisationClass;
    @XmlElement(name = "AMBSAccount")
    protected String ambsAccount;
    @XmlElement(name = "AMRMRelOrg")
    protected String amrmRelOrg;
    @XmlElement(name = "AMRMRelNumber")
    protected String amrmRelNumber;
    @XmlElement(name = "BlockRSNAMED")
    protected String blockRSNAMED;
    @XmlElement(name = "BlockRSNAMBS1")
    protected String blockRSNAMBS1;
    @XmlElement(name = "BlockRSNAMBS2")
    protected String blockRSNAMBS2;
    @XmlElement(name = "AMBSDateOpened")
    protected String ambsDateOpened;
    @XmlElement(name = "InvalidPinTries")
    protected String invalidPinTries;
    @XmlElement(name = "CLOGRecType")
    protected String clogRecType;
    @XmlElement(name = "FISpid")
    protected String fiSpid;
    @XmlElement(name = "FITestDigits")
    protected String fiTestDigits;
    @XmlElement(name = "FIAuthDigitGroup")
    protected String fiAuthDigitGroup;
    @XmlElement(name = "FIAuthStragegyID")
    protected String fiAuthStragegyID;
    @XmlElement(name = "CLOGAuthReport")
    protected String clogAuthReport;
    @XmlElement(name = "CLOGAuthDecision")
    protected String clogAuthDecision;
    @XmlElement(name = "PMTCycleDue")
    protected String pmtCycleDue;
    @XmlElement(name = "CLOGTransType")
    protected String clogTransType;
    @XmlElement(name = "AmtCTDCash")
    protected String amtCTDCash;
    @XmlElement(name = "CashCRLIM")
    protected String cashCRLIM;
    @XmlElement(name = "CLOGAmountOutStd")
    protected String clogAmountOutStd;
    @XmlElement(name = "ICCInstId")
    protected String iccInstId;
    @XmlElement(name = "ICCISSNetwID")
    protected String iccissNetwID;
    @XmlElement(name = "ICCAcqNetwID")
    protected String iccAcqNetwID;
    @XmlElement(name = "FICurrBehaviorScore")
    protected String fiCurrBehaviorScore;
    @XmlElement(name = "FIAuthScnID")
    protected String fiAuthScnID;
    @XmlElement(name = "FraudCPInd")
    protected String fraudCPInd;
    @XmlElement(name = "FraudOrigPosEntry")
    protected String fraudOrigPosEntry;
    @XmlElement(name = "RecurringInd")
    protected String recurringInd;
    @XmlElement(name = "InstlInd")
    protected String instlInd;
    @XmlElement(name = "UtilityInd")
    protected String utilityInd;
    @XmlElement(name = "MotoInd")
    protected String motoInd;
    @XmlElement(name = "CallCardInd")
    protected String callCardInd;
    @XmlElement(name = "ATIAOrgNumber")
    protected String atiaOrgNumber;
    @XmlElement(name = "LocalCurrencyCode")
    protected String localCurrencyCode;
    @XmlElement(name = "ATIAAuthAmount")
    protected String atiaAuthAmount;
    @XmlElement(name = "OrigTypeMessageId")
    protected String origTypeMessageId;
    @XmlElement(name = "JetcoAcqBin")
    protected String jetcoAcqBin;
    @XmlElement(name = "ODLYCashAmount")
    protected String odlyCashAmount;
    @XmlElement(name = "OMLYCashAmount")
    protected String omlyCashAmount;
    @XmlElement(name = "Month6CashAmount")
    protected String month6CashAmount;
    @XmlElement(name = "Month12CashAmount")
    protected String month12CashAmount;
    @XmlElement(name = "ExchangeTxn")
    protected String exchangeTxn;
    @XmlElement(name = "OVSPurchaseLimit")
    protected String ovsPurchaseLimit;
    @XmlElement(name = "OVSPurchaseAvail")
    protected String ovsPurchaseAvail;
    @XmlElement(name = "OVSCashLimit")
    protected String ovsCashLimit;
    @XmlElement(name = "OVSInternetLimit")
    protected String ovsInternetLimit;
    @XmlElement(name = "OVSInternetAvail")
    protected String ovsInternetAvail;
    @XmlElement(name = "AMBSCashAvail")
    protected String ambsCashAvail;
    @XmlElement(name = "AMEDCashAvail")
    protected String amedCashAvail;
    @XmlElement(name = "AMEDPostToAcc")
    protected String amedPostToAcc;
    @XmlElement(name = "ICCCBAFlag")
    protected String icccbaFlag;
    @XmlElement(name = "CCASettlementFee")
    protected String ccaSettlementFee;
    @XmlElement(name = "MasterDebitOrg")
    protected String masterDebitOrg;
    @XmlElement(name = "MasterDebitType")
    protected String masterDebitType;
    @XmlElement(name = "MasterDebitAcct")
    protected String masterDebitAcct;
    @XmlElement(name = "MasterDebitRiskLevel")
    protected String masterDebitRiskLevel;
    @XmlElement(name = "MasterDebitCardInd")
    protected String masterDebitCardInd;
    @XmlElement(name = "MasterDebitTipAmt")
    protected String masterDebitTipAmt;
    @XmlElement(name = "AfewsOnlineMode")
    protected String afewsOnlineMode;
    @XmlElement(name = "AfewsOnlineRC1")
    protected String afewsOnlineRC1;
    @XmlElement(name = "RefrlQSTN1")
    protected String refrlQSTN1;
    @XmlElement(name = "RefrlQSTN2")
    protected String refrlQSTN2;
    @XmlElement(name = "RefrlQSTN3")
    protected String refrlQSTN3;
    @XmlElement(name = "GlobalCountryCode")
    protected String globalCountryCode;
    @XmlElement(name = "AfewsFalconDSCN")
    protected String afewsFalconDSCN;
    @XmlElement(name = "MasterInvCVC2")
    protected String masterInvCVC2;
    @XmlElement(name = "MasterPOSCondCode")
    protected String masterPOSCondCode;
    @XmlElement(name = "MasterFNCLCode")
    protected String masterFNCLCode;
    @XmlElement(name = "MasterBNKNTREFNumber")
    protected String masterBNKNTREFNumber;
    @XmlElement(name = "DinersSYSTrace")
    protected String dinersSYSTrace;
    @XmlElement(name = "ISORespCode")
    protected String isoRespCode;
    @XmlElement(name = "CardRespCode")
    protected String cardRespCode;
    @XmlElement(name = "DinersCVVInd")
    protected String dinersCVVInd;
    @XmlElement(name = "DinersDupInd")
    protected String dinersDupInd;
    @XmlElement(name = "DinersRecurInd")
    protected String dinersRecurInd;
    @XmlElement(name = "EppTenor")
    protected String eppTenor;
    @XmlElement(name = "EppPromoId")
    protected String eppPromoId;
    @XmlElement(name = "AltOrgId")
    protected String altOrgId;
    @XmlElement(name = "AmexTCType")
    protected String amexTCType;
    @XmlElement(name = "AmexResCode")
    protected String amexResCode;
    @XmlElement(name = "AmexISOResCode")
    protected String amexISOResCode;
    @XmlElement(name = "AmexLclTxnDTTime")
    protected String amexLclTxnDTTime;
    @XmlElement(name = "AmexEffDate")
    protected String amexEffDate;
    @XmlElement(name = "AmexPosDataCode")
    protected String amexPosDataCode;
    @XmlElement(name = "AmexFunCode")
    protected String amexFunCode;
    @XmlElement(name = "AmexMsgRsnCode")
    protected String amexMsgRsnCode;
    @XmlElement(name = "AmexCardBusCode")
    protected String amexCardBusCode;
    @XmlElement(name = "AmexOrigAmntData01To12")
    protected String amexOrigAmntData01To12;
    @XmlElement(name = "AmexOrigAmntData13To24")
    protected String amexOrigAmntData13To24;
    @XmlElement(name = "AmexAcqRefNbr")
    protected String amexAcqRefNbr;
    @XmlElement(name = "AmexActionCode")
    protected String amexActionCode;
    @XmlElement(name = "AmexCardAcceptName")
    protected String amexCardAcceptName;
    @XmlElement(name = "AmexAdtlResLen")
    protected String amexAdtlResLen;
    @XmlElement(name = "AmexAdtlResDat")
    protected String amexAdtlResDat;
    @XmlElement(name = "AmexAvsResult")
    protected String amexAvsResult;
    @XmlElement(name = "AmexSecCtlResult")
    protected String amexSecCtlResult;
    @XmlElement(name = "AmexAdtlDataLen")
    protected String amexAdtlDataLen;
    @XmlElement(name = "AmexAdtlData")
    protected String amexAdtlData;
    @XmlElement(name = "AmexStipendSent")
    protected String amexStipendSent;
    @XmlElement(name = "AmexStipendParm")
    protected String amexStipendParm;
    @XmlElement(name = "AmexStipendSeType")
    protected String amexStipendSeType;
    @XmlElement(name = "AmexStipendMerType")
    protected String amexStipendMerType;
    @XmlElement(name = "AmexStipendHstIndi")
    protected String amexStipendHstIndi;
    @XmlElement(name = "AmexStiprSent")
    protected String amexStiprSent;
    @XmlElement(name = "AmexStiprParm")
    protected String amexStiprParm;
    @XmlElement(name = "AmexOrigDataLen")
    protected String amexOrigDataLen;
    @XmlElement(name = "AmexODMsgType")
    protected String amexODMsgType;
    @XmlElement(name = "AmexODSysTrace")
    protected String amexODSysTrace;
    @XmlElement(name = "AmexODLclDateTime")
    protected String amexODLclDateTime;
    @XmlElement(name = "AmexODAcqId")
    protected String amexODAcqId;
    @XmlElement(name = "AmexVli")
    protected String amexVli;
    @XmlElement(name = "AmexPriId")
    protected String amexPriId;
    @XmlElement(name = "AmexSecId")
    protected String amexSecId;
    @XmlElement(name = "AmexEci")
    protected String amexEci;
    @XmlElement(name = "AmexAevvRstl")
    protected String amexAevvRstl;
    @XmlElement(name = "AmexAevvId")
    protected String amexAevvId;
    @XmlElement(name = "AmexSub1")
    protected String amexSub1;
    @XmlElement(name = "AmexSub2")
    protected String amexSub2;
    @XmlElement(name = "XID")
    protected String xid;
    @XmlElement(name = "XIDValue")
    protected String xidValue;
    @XmlElement(name = "AmexFraudIndLen")
    protected String amexFraudIndLen;
    @XmlElement(name = "AmexFraudInd")
    protected String amexFraudInd;
    @XmlElement(name = "AmexPrivUseLen")
    protected String amexPrivUseLen;
    @XmlElement(name = "AmexPrivUseData")
    protected String amexPrivUseData;
    @XmlElement(name = "AmexEadSvcId")
    protected String amexEadSvcId;
    @XmlElement(name = "AmexEadReq")
    protected String amexEadReq;
    @XmlElement(name = "AmexEadPostlCd")
    protected String amexEadPostlCd;
    @XmlElement(name = "AmexEadAddrNbrs")
    protected String amexEadAddrNbrs;
    @XmlElement(name = "AmexOptionalDataLen")
    protected String amexOptionalDataLen;
    @XmlElement(name = "AmexOptionalData")
    protected String amexOptionalData;
    @XmlElement(name = "AmexOptional01To30")
    protected String amexOptional01To30;
    @XmlElement(name = "AmexOptional31To60")
    protected String amexOptional31To60;
    @XmlElement(name = "AmexAdtlData2")
    protected String amexAdtlData2;
    @XmlElement(name = "AuthAdtlDataLen")
    protected String authAdtlDataLen;
    @XmlElement(name = "AmexIccVerHdrName")
    protected String amexIccVerHdrName;
    @XmlElement(name = "AmexIccVerHdrNbr")
    protected String amexIccVerHdrNbr;
    @XmlElement(name = "AmexApplCrytData")
    protected String amexApplCrytData;
    @XmlElement(name = "AmexIssApplLng")
    protected String amexIssApplLng;
    @XmlElement(name = "AmexIssApplData")
    protected String amexIssApplData;
    @XmlElement(name = "AmexUnpredNbr")
    protected String amexUnpredNbr;
    @XmlElement(name = "AmexAppTranCntr")
    protected String amexAppTranCntr;
    @XmlElement(name = "AmexTvrData")
    protected String amexTvrData;
    @XmlElement(name = "AmexTranDate")
    protected String amexTranDate;
    @XmlElement(name = "AmexTranType")
    protected String amexTranType;
    @XmlElement(name = "AmexAmtAuth")
    protected String amexAmtAuth;
    @XmlElement(name = "AmexTranCurrCode")
    protected String amexTranCurrCode;
    @XmlElement(name = "AmexTermCntryCd")
    protected String amexTermCntryCd;
    @XmlElement(name = "AmexAppIntrData")
    protected String amexAppIntrData;
    @XmlElement(name = "AmexAmtOth")
    protected String amexAmtOth;
    @XmlElement(name = "AmexPanSeqNbr")
    protected String amexPanSeqNbr;
    @XmlElement(name = "AmexCrytInfoDat")
    protected String amexCrytInfoDat;
    @XmlElement(name = "AmexRspAuthTag")
    protected String amexRspAuthTag;
    @XmlElement(name = "AmexRspAuthlen")
    protected String amexRspAuthlen;
    @XmlElement(name = "AmexRspAuthData")
    protected String amexRspAuthData;
    @XmlElement(name = "AmexRspScriptTag")
    protected String amexRspScriptTag;
    @XmlElement(name = "AmexRspScriptLen")
    protected String amexRspScriptLen;
    @XmlElement(name = "AmexRspScriptData")
    protected String amexRspScriptData;
    @XmlElement(name = "PINVerifyIndicator")
    protected String pinVerifyIndicator;
    @XmlElement(name = "AfewsTransactionType")
    protected String afewsTransactionType;
    @XmlElement(name = "NFCAssociatedFlag")
    protected String nfcAssociatedFlag;
    @XmlElement(name = "TransactionChannelType")
    protected String transactionChannelType;
    @XmlElement(name = "TransactionOriginID")
    protected String transactionOriginID;
    @XmlElement(name = "CUPCheck")
    protected String cupCheck;
    @XmlElement(name = "CUPTaxID")
    protected String cupTaxID;
    @XmlElement(name = "SafetyNetIndicator")
    protected String safetyNetIndicator;
    @XmlElement(name = "TransactionStatus")
    protected String transactionStatus;
    @XmlElement(name = "TransactionAmount")
    protected Double transactionAmount;
    @XmlElement(name = "TransactionCurrencyCode")
    protected String transactionCurrencyCode;
    @XmlElement(name = "TransactionDate")
    @XmlSchemaType(name = "dateTime")
    protected String transactionDate;
    @XmlElement(name = "TransactionTime")
    @XmlSchemaType(name = "dateTime")
    protected String transactionTime;
    @XmlElement(name = "TransactionChannel")
    protected String transactionChannel;
    @XmlElement(name = "TransactionType")
    protected String transactionType;
    @XmlElement(name = "CreditOrDebitIndicator")
    protected String creditOrDebitIndicator;
    @XmlElement(name = "TransactionCode")
    protected String transactionCode;
    @XmlElement(name = "GRBCustomerNumber")
    protected String grbCustomerNumber;
    @XmlElement(name = "GRBRelationshipNumber")
    protected String grbRelationshipNumber;
    @XmlElement(name = "TransactionCountry")
    protected String transactionCountry;
    @XmlElement(name = "TransactionState")
    protected String transactionState;
    @XmlElement(name = "TransactionCity")
    protected String transactionCity;
    
    @XmlElement(name = "DeclineReasonCode")
    protected String declineReasonCode;
    @XmlElement(name = "IPAddressInternetTxn")
    protected String ipAddressInternetTxn;
    @XmlElement(name = "MACAddress")
    protected String macAddress;
    @XmlElement(name = "BlockReasonCode")
    protected String blockReasonCode;
    @XmlElement(name = "BAFESTransactionCode")
    protected String bafesTransactionCode;
    @XmlElement(name = "AuthorizationDescription")
    protected String authorizationDescription;
    @XmlElement(name = "ApprovalCode")
    protected String approvalCode;
    @XmlElement(name = "OnlineErrorReturnMsg")
    protected String onlineErrorReturnMsg;
    @XmlElement(name = "AdditionalTnxDescription1")
    protected String additionalTnxDescription1;
    @XmlElement(name = "AdditionalTnxDescription2")
    protected String additionalTnxDescription2;
    @XmlElement(name = "AdditionalTnxDescription3")
    protected String additionalTnxDescription3;
    @XmlElement(name = "AdditionalTnxDescription4")
    protected String additionalTnxDescription4;
    @XmlElement(name = "UserDataField1")
    protected String userDataField1;
    @XmlElement(name = "UserDataField2")
    protected String userDataField2;
    @XmlElement(name = "CardNumber")
    protected String cardNumber;
    
    @XmlElement(name = "ResponseDateTime")
    protected String responseDateTime;
    
    @XmlElement(name = "RequestDateTime")
    protected String requestDateTime;
    
    //**********************Additional Parameters*************************************
    
    @XmlElement(name = "Family")
    protected String family;
    @XmlElement(name = "FinancialTX")
    protected String financialTX;
    @XmlElement(name = "SituationValue")
    protected String situationValue;
    @XmlElement(name = "AfewsBillPayChannel")
    protected String aFewsBillPayChannel;
    @XmlElement(name = "Bearer_Mob_Num")
    protected String bearer_Mob_Num;
    @XmlElement(name = "txnMode")
    protected String TxnMode;
    @XmlElement(name = "DefBalInq")
    protected String defBalInq;
    @XmlElement(name = "WalletDPAN")
    protected String walletDPAN;
    @XmlElement(name = "WalletServInd")
    protected String walletServInd;
    @XmlElement(name = "WalletTxnInd")
    protected String walletTxnInd;
    @XmlElement(name = "PinFlag")
    protected String pinFlag;
    @XmlElement(name = "P2PTxnId")
    protected String p2PTxnId;
    @XmlElement(name = "CardTransactionType")
    protected String cardTransactionType;
    @XmlElement(name = "FirstUsageFlag")
    protected String firstUsageFlag;
    @XmlElement(name = "MasterAuthResponseCode")
    protected String masterAuthResponseCode;
    @XmlElement(name = "PinBypass")
    protected String pinBypass;
    @XmlElement(name = "DomesticTransaction")
    protected String domesticTransaction;
    @XmlElement(name = "PaymentType")
    protected String paymentType;
    @XmlElement(name = "ReasonMessage")
    protected String reasonMessage;
    @XmlElement(name = "Recipientnameerence")
    protected String recipientnameerence;
    @XmlElement(name = "Transactionnameerence")
    protected String transactionnameerence;
    @XmlElement(name = "ApplePayInd")
    protected String applePayInd;
    
    
    
    public String getFamily() {
		return family;
	}
	public void setFamily(String family) {
		this.family = family;
	}
	public String getFinancialTX() {
		return financialTX;
	}
	public void setFinancialTX(String financialTX) {
		this.financialTX = financialTX;
	}
	public String getSituationValue() {
		return situationValue;
	}
	public void setSituationValue(String situationValue) {
		this.situationValue = situationValue;
	}
	public String getaFewsBillPayChannel() {
		return aFewsBillPayChannel;
	}
	public void setaFewsBillPayChannel(String aFewsBillPayChannel) {
		this.aFewsBillPayChannel = aFewsBillPayChannel;
	}
	public String getBearer_Mob_Num() {
		return bearer_Mob_Num;
	}
	public void setBearer_Mob_Num(String bearer_Mob_Num) {
		this.bearer_Mob_Num = bearer_Mob_Num;
	}
	public String getTxnMode() {
		return TxnMode;
	}
	public void setTxnMode(String txnMode) {
		TxnMode = txnMode;
	}
	public String getDefBalInq() {
		return defBalInq;
	}
	public void setDefBalInq(String defBalInq) {
		this.defBalInq = defBalInq;
	}
	public String getWalletDPAN() {
		return walletDPAN;
	}
	public void setWalletDPAN(String walletDPAN) {
		this.walletDPAN = walletDPAN;
	}
	public String getWalletServInd() {
		return walletServInd;
	}
	public void setWalletServInd(String walletServInd) {
		this.walletServInd = walletServInd;
	}
	public String getWalletTxnInd() {
		return walletTxnInd;
	}
	public void setWalletTxnInd(String walletTxnInd) {
		this.walletTxnInd = walletTxnInd;
	}
	public String getPinFlag() {
		return pinFlag;
	}
	public void setPinFlag(String pinFlag) {
		this.pinFlag = pinFlag;
	}
	public String getP2PTxnId() {
		return p2PTxnId;
	}
	public void setP2PTxnId(String p2pTxnId) {
		p2PTxnId = p2pTxnId;
	}
	public String getCardTransactionType() {
		return cardTransactionType;
	}
	public void setCardTransactionType(String cardTransactionType) {
		this.cardTransactionType = cardTransactionType;
	}
	public String getFirstUsageFlag() {
		return firstUsageFlag;
	}
	public void setFirstUsageFlag(String firstUsageFlag) {
		this.firstUsageFlag = firstUsageFlag;
	}
	public String getMasterAuthResponseCode() {
		return masterAuthResponseCode;
	}
	public void setMasterAuthResponseCode(String masterAuthResponseCode) {
		this.masterAuthResponseCode = masterAuthResponseCode;
	}
	public String getPinBypass() {
		return pinBypass;
	}
	public void setPinBypass(String pinBypass) {
		this.pinBypass = pinBypass;
	}
	public String getDomesticTransaction() {
		return domesticTransaction;
	}
	public void setDomesticTransaction(String domesticTransaction) {
		this.domesticTransaction = domesticTransaction;
	}
	public String getPaymentType() {
		return paymentType;
	}
	public void setPaymentType(String paymentType) {
		this.paymentType = paymentType;
	}
	public String getReasonMessage() {
		return reasonMessage;
	}
	public void setReasonMessage(String reasonMessage) {
		this.reasonMessage = reasonMessage;
	}
	public String getRecipientnameerence() {
		return recipientnameerence;
	}
	public void setRecipientnameerence(String recipientnameerence) {
		this.recipientnameerence = recipientnameerence;
	}
	public String getTransactionnameerence() {
		return transactionnameerence;
	}
	public void setTransactionnameerence(String transactionnameerence) {
		this.transactionnameerence = transactionnameerence;
	}
	public String getApplePayInd() {
		return applePayInd;
	}
	public void setApplePayInd(String applePayInd) {
		this.applePayInd = applePayInd;
	}
	public String getResponseDateTime() {
		return responseDateTime;
	}
	public void setResponseDateTime(String responseDateTime) {
		this.responseDateTime = responseDateTime;
	}
	public String getRequestDateTime() {
		return requestDateTime;
	}
	public void setRequestDateTime(String requestDateTime) {
		this.requestDateTime = requestDateTime;
	}
	
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String getGeoRecommendation() {
		return geoRecommendation;
	}
	public void setGeoRecommendation(String geoRecommendation) {
		this.geoRecommendation = geoRecommendation;
	}
	public String getNonGeoRecommendation() {
		return nonGeoRecommendation;
	}
	public void setNonGeoRecommendation(String nonGeoRecommendation) {
		this.nonGeoRecommendation = nonGeoRecommendation;
	}
	public String getCopTransactionID() {
		return copTransactionID;
	}
	public void setCopTransactionID(String copTransactionID) {
		this.copTransactionID = copTransactionID;
	}
	public String getCountryCode() {
		return countryCode;
	}
	public void setCountryCode(String countryCode) {
		this.countryCode = countryCode;
	}
	public String getCustomerNo() {
		return customerNo;
	}
	public void setCustomerNo(String customerNo) {
		this.customerNo = customerNo;
	}
	public String getAccountNo() {
		return accountNo;
	}
	public void setAccountNo(String accountNo) {
		this.accountNo = accountNo;
	}
	public String getCardNo() {
		return cardNo;
	}
	public void setCardNo(String cardNo) {
		this.cardNo = cardNo;
	}
	public String getGeoMerchantID() {
		return geoMerchantID;
	}
	public void setGeoMerchantID(String geoMerchantID) {
		this.geoMerchantID = geoMerchantID;
	}
	public String getNonGeoGeoMerchantID() {
		return nonGeoGeoMerchantID;
	}
	public void setNonGeoGeoMerchantID(String nonGeoGeoMerchantID) {
		this.nonGeoGeoMerchantID = nonGeoGeoMerchantID;
	}
	public String getAccountCountryCode() {
		return accountCountryCode;
	}
	public void setAccountCountryCode(String accountCountryCode) {
		this.accountCountryCode = accountCountryCode;
	}
	public String getProductCode() {
		return productCode;
	}
	public void setProductCode(String productCode) {
		this.productCode = productCode;
	}
	public String getProductProcessorCode() {
		return productProcessorCode;
	}
	public void setProductProcessorCode(String productProcessorCode) {
		this.productProcessorCode = productProcessorCode;
	}
	public String getAccountNumber() {
		return accountNumber;
	}
	public void setAccountNumber(String accountNumber) {
		this.accountNumber = accountNumber;
	}
	public String getAccountCurrencyCode() {
		return accountCurrencyCode;
	}
	public void setAccountCurrencyCode(String accountCurrencyCode) {
		this.accountCurrencyCode = accountCurrencyCode;
	}
	public String getCustomerProf() {
		return customerProf;
	}
	public void setCustomerProf(String customerProf) {
		this.customerProf = customerProf;
	}
	public String getAccountCurrency() {
		return accountCurrency;
	}
	public void setAccountCurrency(String accountCurrency) {
		this.accountCurrency = accountCurrency;
	}
	public String getBranchCode() {
		return branchCode;
	}
	public void setBranchCode(String branchCode) {
		this.branchCode = branchCode;
	}
	public String getAcqID() {
		return acqID;
	}
	public void setAcqID(String acqID) {
		this.acqID = acqID;
	}
	public String getMerchantCity() {
		return merchantCity;
	}
	public void setMerchantCity(String merchantCity) {
		this.merchantCity = merchantCity;
	}
	public String getMerchantCtry() {
		return merchantCtry;
	}
	public void setMerchantCtry(String merchantCtry) {
		this.merchantCtry = merchantCtry;
	}
	public String getTermID() {
		return termID;
	}
	public void setTermID(String termID) {
		this.termID = termID;
	}
	public String getMcc() {
		return mcc;
	}
	public void setMcc(String mcc) {
		this.mcc = mcc;
	}
	public String getPoseMode() {
		return poseMode;
	}
	public void setPoseMode(String poseMode) {
		this.poseMode = poseMode;
	}
	public XMLGregorianCalendar getTdMaturityDate() {
		return tdMaturityDate;
	}
	public void setTdMaturityDate(XMLGregorianCalendar tdMaturityDate) {
		this.tdMaturityDate = tdMaturityDate;
	}
	public String getExpDate() {
		return expDate;
	}
	public void setExpDate(String expDate) {
		this.expDate = expDate;
	}
	public String getOtherAcctNbr() {
		return otherAcctNbr;
	}
	public void setOtherAcctNbr(String otherAcctNbr) {
		this.otherAcctNbr = otherAcctNbr;
	}
	public String getOtherProdCode() {
		return otherProdCode;
	}
	public void setOtherProdCode(String otherProdCode) {
		this.otherProdCode = otherProdCode;
	}
	public String getOtherBankCode() {
		return otherBankCode;
	}
	public void setOtherBankCode(String otherBankCode) {
		this.otherBankCode = otherBankCode;
	}
	public String getOtherBranchCode() {
		return otherBranchCode;
	}
	public void setOtherBranchCode(String otherBranchCode) {
		this.otherBranchCode = otherBranchCode;
	}
	public String getOtherAcctName() {
		return otherAcctName;
	}
	public void setOtherAcctName(String otherAcctName) {
		this.otherAcctName = otherAcctName;
	}
	public String getOtherAcctAdd1() {
		return otherAcctAdd1;
	}
	public void setOtherAcctAdd1(String otherAcctAdd1) {
		this.otherAcctAdd1 = otherAcctAdd1;
	}
	public String getOtherAcctAdd2() {
		return otherAcctAdd2;
	}
	public void setOtherAcctAdd2(String otherAcctAdd2) {
		this.otherAcctAdd2 = otherAcctAdd2;
	}
	public String getOtherAcctCity() {
		return otherAcctCity;
	}
	public void setOtherAcctCity(String otherAcctCity) {
		this.otherAcctCity = otherAcctCity;
	}
	public String getOtherAcctState() {
		return otherAcctState;
	}
	public void setOtherAcctState(String otherAcctState) {
		this.otherAcctState = otherAcctState;
	}
	public String getOtherAcctCtry() {
		return otherAcctCtry;
	}
	public void setOtherAcctCtry(String otherAcctCtry) {
		this.otherAcctCtry = otherAcctCtry;
	}
	public String getOtherAcctZip() {
		return otherAcctZip;
	}
	public void setOtherAcctZip(String otherAcctZip) {
		this.otherAcctZip = otherAcctZip;
	}
	public BigInteger getChequeNumber() {
		return chequeNumber;
	}
	public void setChequeNumber(BigInteger chequeNumber) {
		this.chequeNumber = chequeNumber;
	}
	public String getChequeStatus() {
		return chequeStatus;
	}
	public void setChequeStatus(String chequeStatus) {
		this.chequeStatus = chequeStatus;
	}
	public String getDuplicateChequeFlag() {
		return duplicateChequeFlag;
	}
	public void setDuplicateChequeFlag(String duplicateChequeFlag) {
		this.duplicateChequeFlag = duplicateChequeFlag;
	}
	public String getFloatDays() {
		return floatDays;
	}
	public void setFloatDays(String floatDays) {
		this.floatDays = floatDays;
	}
	public String getAcctBal() {
		return acctBal;
	}
	public void setAcctBal(String acctBal) {
		this.acctBal = acctBal;
	}
	public String getAcctLedgBal() {
		return acctLedgBal;
	}
	public void setAcctLedgBal(String acctLedgBal) {
		this.acctLedgBal = acctLedgBal;
	}
	public String getPersonalAmountThresholds() {
		return personalAmountThresholds;
	}
	public void setPersonalAmountThresholds(String personalAmountThresholds) {
		this.personalAmountThresholds = personalAmountThresholds;
	}
	public String getUniqRefNbr() {
		return uniqRefNbr;
	}
	public void setUniqRefNbr(String uniqRefNbr) {
		this.uniqRefNbr = uniqRefNbr;
	}
	public String getAccountStatus() {
		return accountStatus;
	}
	public void setAccountStatus(String accountStatus) {
		this.accountStatus = accountStatus;
	}
	public String getAccountCloseRSN() {
		return accountCloseRSN;
	}
	public void setAccountCloseRSN(String accountCloseRSN) {
		this.accountCloseRSN = accountCloseRSN;
	}
	public String getTrmDepMatDate() {
		return trmDepMatDate;
	}
	public void setTrmDepMatDate(String trmDepMatDate) {
		this.trmDepMatDate = trmDepMatDate;
	}
	public String getOrg() {
		return org;
	}
	public void setOrg(String org) {
		this.org = org;
	}
	public String getCashWithdrawalDays() {
		return cashWithdrawalDays;
	}
	public void setCashWithdrawalDays(String cashWithdrawalDays) {
		this.cashWithdrawalDays = cashWithdrawalDays;
	}
	public String getCashWithdrawalPeriod() {
		return cashWithdrawalPeriod;
	}
	public void setCashWithdrawalPeriod(String cashWithdrawalPeriod) {
		this.cashWithdrawalPeriod = cashWithdrawalPeriod;
	}
	public String getCashWithdrawalPercent() {
		return cashWithdrawalPercent;
	}
	public void setCashWithdrawalPercent(String cashWithdrawalPercent) {
		this.cashWithdrawalPercent = cashWithdrawalPercent;
	}
	public String getPayeeBankCode() {
		return payeeBankCode;
	}
	public void setPayeeBankCode(String payeeBankCode) {
		this.payeeBankCode = payeeBankCode;
	}
	public String getPayeeBankName() {
		return payeeBankName;
	}
	public void setPayeeBankName(String payeeBankName) {
		this.payeeBankName = payeeBankName;
	}
	public String getPayeeBranchCode() {
		return payeeBranchCode;
	}
	public void setPayeeBranchCode(String payeeBranchCode) {
		this.payeeBranchCode = payeeBranchCode;
	}
	public String getPayeeAccountNumber() {
		return payeeAccountNumber;
	}
	public void setPayeeAccountNumber(String payeeAccountNumber) {
		this.payeeAccountNumber = payeeAccountNumber;
	}
	public String getPayeeName() {
		return payeeName;
	}
	public void setPayeeName(String payeeName) {
		this.payeeName = payeeName;
	}
	public String getPaymentMode() {
		return paymentMode;
	}
	public void setPaymentMode(String paymentMode) {
		this.paymentMode = paymentMode;
	}
	public String getBeginningCheckSerialNumber() {
		return beginningCheckSerialNumber;
	}
	public void setBeginningCheckSerialNumber(String beginningCheckSerialNumber) {
		this.beginningCheckSerialNumber = beginningCheckSerialNumber;
	}
	public String getEndCheckSerialNumber() {
		return endCheckSerialNumber;
	}
	public void setEndCheckSerialNumber(String endCheckSerialNumber) {
		this.endCheckSerialNumber = endCheckSerialNumber;
	}
	public String getDcemvFlag() {
		return dcemvFlag;
	}
	public void setDcemvFlag(String dcemvFlag) {
		this.dcemvFlag = dcemvFlag;
	}
	public String getDcFallBackCount() {
		return dcFallBackCount;
	}
	public void setDcFallBackCount(String dcFallBackCount) {
		this.dcFallBackCount = dcFallBackCount;
	}
	public String getTsTransactionCode() {
		return tsTransactionCode;
	}
	public void setTsTransactionCode(String tsTransactionCode) {
		this.tsTransactionCode = tsTransactionCode;
	}
	public String getLogOnCountry() {
		return logOnCountry;
	}
	public void setLogOnCountry(String logOnCountry) {
		this.logOnCountry = logOnCountry;
	}
	public String getFundTransferType() {
		return fundTransferType;
	}
	public void setFundTransferType(String fundTransferType) {
		this.fundTransferType = fundTransferType;
	}
	public String getReversalIndicator() {
		return reversalIndicator;
	}
	public void setReversalIndicator(String reversalIndicator) {
		this.reversalIndicator = reversalIndicator;
	}
	public String getSourceApplication() {
		return sourceApplication;
	}
	public void setSourceApplication(String sourceApplication) {
		this.sourceApplication = sourceApplication;
	}
	public String getBlockCode() {
		return blockCode;
	}
	public void setBlockCode(String blockCode) {
		this.blockCode = blockCode;
	}
	public String getFirstTxnFlag() {
		return firstTxnFlag;
	}
	public void setFirstTxnFlag(String firstTxnFlag) {
		this.firstTxnFlag = firstTxnFlag;
	}
	public String getDcExpiryDate() {
		return dcExpiryDate;
	}
	public void setDcExpiryDate(String dcExpiryDate) {
		this.dcExpiryDate = dcExpiryDate;
	}
	public String getFillerField1() {
		return fillerField1;
	}
	public void setFillerField1(String fillerField1) {
		this.fillerField1 = fillerField1;
	}
	public String getFillerField2() {
		return fillerField2;
	}
	public void setFillerField2(String fillerField2) {
		this.fillerField2 = fillerField2;
	}
	public String getFillerField3() {
		return fillerField3;
	}
	public void setFillerField3(String fillerField3) {
		this.fillerField3 = fillerField3;
	}
	public String getFillerField4() {
		return fillerField4;
	}
	public void setFillerField4(String fillerField4) {
		this.fillerField4 = fillerField4;
	}
	public String getFillerField5() {
		return fillerField5;
	}
	public void setFillerField5(String fillerField5) {
		this.fillerField5 = fillerField5;
	}
	public String getUniqueId() {
		return uniqueId;
	}
	public void setUniqueId(String uniqueId) {
		this.uniqueId = uniqueId;
	}
	public String getAuthText() {
		return authText;
	}
	public void setAuthText(String authText) {
		this.authText = authText;
	}
	public XMLGregorianCalendar getTxnCntryDate() {
		return txnCntryDate;
	}
	public void setTxnCntryDate(XMLGregorianCalendar txnCntryDate) {
		this.txnCntryDate = txnCntryDate;
	}
	public String getTxnSubChannel() {
		return txnSubChannel;
	}
	public void setTxnSubChannel(String txnSubChannel) {
		this.txnSubChannel = txnSubChannel;
	}
	public XMLGregorianCalendar getTxnCntryTime() {
		return txnCntryTime;
	}
	public void setTxnCntryTime(XMLGregorianCalendar txnCntryTime) {
		this.txnCntryTime = txnCntryTime;
	}
	public String getBizSegment() {
		return bizSegment;
	}
	public void setBizSegment(String bizSegment) {
		this.bizSegment = bizSegment;
	}
	public String getSrcAcctStaffInd() {
		return srcAcctStaffInd;
	}
	public void setSrcAcctStaffInd(String srcAcctStaffInd) {
		this.srcAcctStaffInd = srcAcctStaffInd;
	}
	public String getDestAcctStaffInd() {
		return destAcctStaffInd;
	}
	public void setDestAcctStaffInd(String destAcctStaffInd) {
		this.destAcctStaffInd = destAcctStaffInd;
	}
	public String getDomicileCntryCD() {
		return domicileCntryCD;
	}
	public void setDomicileCntryCD(String domicileCntryCD) {
		this.domicileCntryCD = domicileCntryCD;
	}
	public String getAcctZipCD() {
		return acctZipCD;
	}
	public void setAcctZipCD(String acctZipCD) {
		this.acctZipCD = acctZipCD;
	}
	public String getBranchNbr() {
		return branchNbr;
	}
	public void setBranchNbr(String branchNbr) {
		this.branchNbr = branchNbr;
	}
	public XMLGregorianCalendar getTxnEffDate() {
		return txnEffDate;
	}
	public void setTxnEffDate(XMLGregorianCalendar txnEffDate) {
		this.txnEffDate = txnEffDate;
	}
	public XMLGregorianCalendar getTxnEffTime() {
		return txnEffTime;
	}
	public void setTxnEffTime(XMLGregorianCalendar txnEffTime) {
		this.txnEffTime = txnEffTime;
	}
	public String getAvgAcctBal() {
		return avgAcctBal;
	}
	public void setAvgAcctBal(String avgAcctBal) {
		this.avgAcctBal = avgAcctBal;
	}
	public String getConsolidateAcctBal() {
		return consolidateAcctBal;
	}
	public void setConsolidateAcctBal(String consolidateAcctBal) {
		this.consolidateAcctBal = consolidateAcctBal;
	}
	public String getPhoneNum() {
		return phoneNum;
	}
	public void setPhoneNum(String phoneNum) {
		this.phoneNum = phoneNum;
	}
	public String gettPinConf() {
		return tPinConf;
	}
	public void settPinConf(String tPinConf) {
		this.tPinConf = tPinConf;
	}
	public String getCpoId() {
		return cpoId;
	}
	public void setCpoId(String cpoId) {
		this.cpoId = cpoId;
	}
	public String getEnrollPhInd() {
		return enrollPhInd;
	}
	public void setEnrollPhInd(String enrollPhInd) {
		this.enrollPhInd = enrollPhInd;
	}
	public String getVerifyQuesIndF() {
		return verifyQuesIndF;
	}
	public void setVerifyQuesIndF(String verifyQuesIndF) {
		this.verifyQuesIndF = verifyQuesIndF;
	}
	public String getVerifyQuesInd() {
		return verifyQuesInd;
	}
	public void setVerifyQuesInd(String verifyQuesInd) {
		this.verifyQuesInd = verifyQuesInd;
	}
	public String getMerchIpAddress() {
		return merchIpAddress;
	}
	public void setMerchIpAddress(String merchIpAddress) {
		this.merchIpAddress = merchIpAddress;
	}
	public String getUserTyp() {
		return userTyp;
	}
	public void setUserTyp(String userTyp) {
		this.userTyp = userTyp;
	}
	public String getAtmLocation() {
		return atmLocation;
	}
	public void setAtmLocation(String atmLocation) {
		this.atmLocation = atmLocation;
	}
	public String getEmvChipInd() {
		return emvChipInd;
	}
	public void setEmvChipInd(String emvChipInd) {
		this.emvChipInd = emvChipInd;
	}
	public String getCustSsnNric() {
		return custSsnNric;
	}
	public void setCustSsnNric(String custSsnNric) {
		this.custSsnNric = custSsnNric;
	}
	public String getBarcdInfo() {
		return barcdInfo;
	}
	public void setBarcdInfo(String barcdInfo) {
		this.barcdInfo = barcdInfo;
	}
	public String getDebitType() {
		return debitType;
	}
	public void setDebitType(String debitType) {
		this.debitType = debitType;
	}
	public String getLsnCode() {
		return lsnCode;
	}
	public void setLsnCode(String lsnCode) {
		this.lsnCode = lsnCode;
	}
	public String getCenterCode() {
		return centerCode;
	}
	public void setCenterCode(String centerCode) {
		this.centerCode = centerCode;
	}
	public String getRetnCode() {
		return retnCode;
	}
	public void setRetnCode(String retnCode) {
		this.retnCode = retnCode;
	}
	public String getRetnMsg() {
		return retnMsg;
	}
	public void setRetnMsg(String retnMsg) {
		this.retnMsg = retnMsg;
	}
	public String getMerchantKey() {
		return merchantKey;
	}
	public void setMerchantKey(String merchantKey) {
		this.merchantKey = merchantKey;
	}
	public String getMerchantOrg() {
		return merchantOrg;
	}
	public void setMerchantOrg(String merchantOrg) {
		this.merchantOrg = merchantOrg;
	}
	public String getMerchantNumber() {
		return merchantNumber;
	}
	public void setMerchantNumber(String merchantNumber) {
		this.merchantNumber = merchantNumber;
	}
	public String getOperatorID() {
		return operatorID;
	}
	public void setOperatorID(String operatorID) {
		this.operatorID = operatorID;
	}
	public String getApprovalID() {
		return approvalID;
	}
	public void setApprovalID(String approvalID) {
		this.approvalID = approvalID;
	}
	public String getOasatc() {
		return oasatc;
	}
	public void setOasatc(String oasatc) {
		this.oasatc = oasatc;
	}
	public String getApprovalTC() {
		return approvalTC;
	}
	public void setApprovalTC(String approvalTC) {
		this.approvalTC = approvalTC;
	}
	public String getVisaDeclineReferralTC() {
		return visaDeclineReferralTC;
	}
	public void setVisaDeclineReferralTC(String visaDeclineReferralTC) {
		this.visaDeclineReferralTC = visaDeclineReferralTC;
	}
	
	public String getMasterApprovalTC() {
		return masterApprovalTC;
	}
	public void setMasterApprovalTC(String masterApprovalTC) {
		this.masterApprovalTC = masterApprovalTC;
	}
	public String getMasterDeclineTC() {
		return masterDeclineTC;
	}
	public void setMasterDeclineTC(String masterDeclineTC) {
		this.masterDeclineTC = masterDeclineTC;
	}
	public String getJcbApprovalTC() {
		return jcbApprovalTC;
	}
	public void setJcbApprovalTC(String jcbApprovalTC) {
		this.jcbApprovalTC = jcbApprovalTC;
	}
	public String getFromAccountCode() {
		return fromAccountCode;
	}
	public void setFromAccountCode(String fromAccountCode) {
		this.fromAccountCode = fromAccountCode;
	}
	public String getToAccountCode() {
		return toAccountCode;
	}
	public void setToAccountCode(String toAccountCode) {
		this.toAccountCode = toAccountCode;
	}
	public String getChBlngAmt() {
		return chBlngAmt;
	}
	public void setChBlngAmt(String chBlngAmt) {
		this.chBlngAmt = chBlngAmt;
	}
	public XMLGregorianCalendar getGmtDateTime() {
		return gmtDateTime;
	}
	public void setGmtDateTime(XMLGregorianCalendar gmtDateTime) {
		this.gmtDateTime = gmtDateTime;
	}
	public String getChRateConversion() {
		return chRateConversion;
	}
	public void setChRateConversion(String chRateConversion) {
		this.chRateConversion = chRateConversion;
	}
	public String getCdcAmount() {
		return cdcAmount;
	}
	public void setCdcAmount(String cdcAmount) {
		this.cdcAmount = cdcAmount;
	}
	public XMLGregorianCalendar getExpiryDate() {
		return expiryDate;
	}
	public void setExpiryDate(XMLGregorianCalendar expiryDate) {
		this.expiryDate = expiryDate;
	}
	public XMLGregorianCalendar getExpiryDateMM() {
		return expiryDateMM;
	}
	public void setExpiryDateMM(XMLGregorianCalendar expiryDateMM) {
		this.expiryDateMM = expiryDateMM;
	}
	public XMLGregorianCalendar getExpiryDateYY() {
		return expiryDateYY;
	}
	public void setExpiryDateYY(XMLGregorianCalendar expiryDateYY) {
		this.expiryDateYY = expiryDateYY;
	}
	public String getMerchantType() {
		return merchantType;
	}
	public void setMerchantType(String merchantType) {
		this.merchantType = merchantType;
	}
	public String getPosEntryMode() {
		return posEntryMode;
	}
	public void setPosEntryMode(String posEntryMode) {
		this.posEntryMode = posEntryMode;
	}
	public String getPinCAP() {
		return pinCAP;
	}
	public void setPinCAP(String pinCAP) {
		this.pinCAP = pinCAP;
	}
	public String getAcquirerID() {
		return acquirerID;
	}
	public void setAcquirerID(String acquirerID) {
		this.acquirerID = acquirerID;
	}
	public String getForwardID() {
		return forwardID;
	}
	public void setForwardID(String forwardID) {
		this.forwardID = forwardID;
	}
	public String getAuthorizationCode() {
		return authorizationCode;
	}
	public void setAuthorizationCode(String authorizationCode) {
		this.authorizationCode = authorizationCode;
	}
	public String getSvcRestCode() {
		return svcRestCode;
	}
	public void setSvcRestCode(String svcRestCode) {
		this.svcRestCode = svcRestCode;
	}
	public String getCardAcceptRec() {
		return cardAcceptRec;
	}
	public void setCardAcceptRec(String cardAcceptRec) {
		this.cardAcceptRec = cardAcceptRec;
	}
	public String getCardAcceptStore() {
		return cardAcceptStore;
	}
	public void setCardAcceptStore(String cardAcceptStore) {
		this.cardAcceptStore = cardAcceptStore;
	}
	public String getMerchantID() {
		return merchantID;
	}
	public void setMerchantID(String merchantID) {
		this.merchantID = merchantID;
	}
	public String getAcceptorIDCode() {
		return acceptorIDCode;
	}
	public void setAcceptorIDCode(String acceptorIDCode) {
		this.acceptorIDCode = acceptorIDCode;
	}
	public String getChbCurrencyCode() {
		return chbCurrencyCode;
	}
	public void setChbCurrencyCode(String chbCurrencyCode) {
		this.chbCurrencyCode = chbCurrencyCode;
	}
	public String getForceFlag() {
		return forceFlag;
	}
	public void setForceFlag(String forceFlag) {
		this.forceFlag = forceFlag;
	}
	public String getInputSource() {
		return inputSource;
	}
	public void setInputSource(String inputSource) {
		this.inputSource = inputSource;
	}
	public String getCardType() {
		return cardType;
	}
	public void setCardType(String cardType) {
		this.cardType = cardType;
	}
	public String getRevCode() {
		return revCode;
	}
	public void setRevCode(String revCode) {
		this.revCode = revCode;
	}
	public String getUnderMerchFloor() {
		return underMerchFloor;
	}
	public void setUnderMerchFloor(String underMerchFloor) {
		this.underMerchFloor = underMerchFloor;
	}
	public String getSourceTerminal() {
		return sourceTerminal;
	}
	public void setSourceTerminal(String sourceTerminal) {
		this.sourceTerminal = sourceTerminal;
	}
	public String getTimeSent() {
		return timeSent;
	}
	public void setTimeSent(String timeSent) {
		this.timeSent = timeSent;
	}
	public XMLGregorianCalendar getAbsTimeSent() {
		return absTimeSent;
	}
	public void setAbsTimeSent(XMLGregorianCalendar absTimeSent) {
		this.absTimeSent = absTimeSent;
	}
	public XMLGregorianCalendar getTimeReceived() {
		return timeReceived;
	}
	public void setTimeReceived(XMLGregorianCalendar timeReceived) {
		this.timeReceived = timeReceived;
	}
	public XMLGregorianCalendar getAbsTimeReceived() {
		return absTimeReceived;
	}
	public void setAbsTimeReceived(XMLGregorianCalendar absTimeReceived) {
		this.absTimeReceived = absTimeReceived;
	}
	public String getDeclineReason() {
		return declineReason;
	}
	public void setDeclineReason(String declineReason) {
		this.declineReason = declineReason;
	}
	public String getSourceTransID() {
		return sourceTransID;
	}
	public void setSourceTransID(String sourceTransID) {
		this.sourceTransID = sourceTransID;
	}
	public String getMerchantName() {
		return merchantName;
	}
	public void setMerchantName(String merchantName) {
		this.merchantName = merchantName;
	}
	public String getCardSequenceNumber() {
		return cardSequenceNumber;
	}
	public void setCardSequenceNumber(String cardSequenceNumber) {
		this.cardSequenceNumber = cardSequenceNumber;
	}
	public String getReferralReason() {
		return referralReason;
	}
	public void setReferralReason(String referralReason) {
		this.referralReason = referralReason;
	}
	public String getSuspiciousInd() {
		return suspiciousInd;
	}
	public void setSuspiciousInd(String suspiciousInd) {
		this.suspiciousInd = suspiciousInd;
	}
	public String getCmRiskLevel() {
		return cmRiskLevel;
	}
	public void setCmRiskLevel(String cmRiskLevel) {
		this.cmRiskLevel = cmRiskLevel;
	}
	public String getCrLimit() {
		return crLimit;
	}
	public void setCrLimit(String crLimit) {
		this.crLimit = crLimit;
	}
	public String getAvailCredit() {
		return availCredit;
	}
	public void setAvailCredit(String availCredit) {
		this.availCredit = availCredit;
	}
	public String getCommitAmount() {
		return commitAmount;
	}
	public void setCommitAmount(String commitAmount) {
		this.commitAmount = commitAmount;
	}
	public String getTotalApprovalCount() {
		return totalApprovalCount;
	}
	public void setTotalApprovalCount(String totalApprovalCount) {
		this.totalApprovalCount = totalApprovalCount;
	}
	public String getTotalDeclineCount() {
		return totalDeclineCount;
	}
	public void setTotalDeclineCount(String totalDeclineCount) {
		this.totalDeclineCount = totalDeclineCount;
	}
	public String getXdaysApprCount() {
		return xdaysApprCount;
	}
	public void setXdaysApprCount(String xdaysApprCount) {
		this.xdaysApprCount = xdaysApprCount;
	}
	public String getTrackDataInd() {
		return trackDataInd;
	}
	public void setTrackDataInd(String trackDataInd) {
		this.trackDataInd = trackDataInd;
	}
	public XMLGregorianCalendar getSeltDate() {
		return seltDate;
	}
	public void setSeltDate(XMLGregorianCalendar seltDate) {
		this.seltDate = seltDate;
	}
	public String getCrdAcceptRec() {
		return crdAcceptRec;
	}
	public void setCrdAcceptRec(String crdAcceptRec) {
		this.crdAcceptRec = crdAcceptRec;
	}
	public String getReferralCode() {
		return referralCode;
	}
	public void setReferralCode(String referralCode) {
		this.referralCode = referralCode;
	}
	public String getRcCheckNumber() {
		return rcCheckNumber;
	}
	public void setRcCheckNumber(String rcCheckNumber) {
		this.rcCheckNumber = rcCheckNumber;
	}
	public String getSettleIndicator() {
		return settleIndicator;
	}
	public void setSettleIndicator(String settleIndicator) {
		this.settleIndicator = settleIndicator;
	}
	public String getTransactionSource() {
		return transactionSource;
	}
	public void setTransactionSource(String transactionSource) {
		this.transactionSource = transactionSource;
	}
	public String getTransactionAdvice() {
		return transactionAdvice;
	}
	public void setTransactionAdvice(String transactionAdvice) {
		this.transactionAdvice = transactionAdvice;
	}
	public String getFullChipTransaction() {
		return fullChipTransaction;
	}
	public void setFullChipTransaction(String fullChipTransaction) {
		this.fullChipTransaction = fullChipTransaction;
	}
	public String getAcquirerIndicator() {
		return acquirerIndicator;
	}
	public void setAcquirerIndicator(String acquirerIndicator) {
		this.acquirerIndicator = acquirerIndicator;
	}
	public String getTermEntCap() {
		return termEntCap;
	}
	public void setTermEntCap(String termEntCap) {
		this.termEntCap = termEntCap;
	}
	public String getChipConditionCode() {
		return chipConditionCode;
	}
	public void setChipConditionCode(String chipConditionCode) {
		this.chipConditionCode = chipConditionCode;
	}
	public String getCcpsTransIndicator() {
		return ccpsTransIndicator;
	}
	public void setCcpsTransIndicator(String ccpsTransIndicator) {
		this.ccpsTransIndicator = ccpsTransIndicator;
	}
	public String getIccIsaCBAFlag() {
		return iccIsaCBAFlag;
	}
	public void setIccIsaCBAFlag(String iccIsaCBAFlag) {
		this.iccIsaCBAFlag = iccIsaCBAFlag;
	}
	public String getIccoptIssCurrency() {
		return iccoptIssCurrency;
	}
	public void setIccoptIssCurrency(String iccoptIssCurrency) {
		this.iccoptIssCurrency = iccoptIssCurrency;
	}
	public String getIccoptIssExpiry() {
		return iccoptIssExpiry;
	}
	public void setIccoptIssExpiry(String iccoptIssExpiry) {
		this.iccoptIssExpiry = iccoptIssExpiry;
	}
	public String getCurrencyBehaviorScore() {
		return currencyBehaviorScore;
	}
	public void setCurrencyBehaviorScore(String currencyBehaviorScore) {
		this.currencyBehaviorScore = currencyBehaviorScore;
	}
	public String getAuthScenID() {
		return authScenID;
	}
	public void setAuthScenID(String authScenID) {
		this.authScenID = authScenID;
	}
	public String getAuthStgyID() {
		return authStgyID;
	}
	public void setAuthStgyID(String authStgyID) {
		this.authStgyID = authStgyID;
	}
	public String getAuthorDigitGroup() {
		return authorDigitGroup;
	}
	public void setAuthorDigitGroup(String authorDigitGroup) {
		this.authorDigitGroup = authorDigitGroup;
	}
	public String getReturnMsgDecline() {
		return returnMsgDecline;
	}
	public void setReturnMsgDecline(String returnMsgDecline) {
		this.returnMsgDecline = returnMsgDecline;
	}
	public String getVisaAuthData() {
		return visaAuthData;
	}
	public void setVisaAuthData(String visaAuthData) {
		this.visaAuthData = visaAuthData;
	}
	public String getVisaPosCondCode() {
		return visaPosCondCode;
	}
	public void setVisaPosCondCode(String visaPosCondCode) {
		this.visaPosCondCode = visaPosCondCode;
	}
	public String getVisaStipRespCode() {
		return visaStipRespCode;
	}
	public void setVisaStipRespCode(String visaStipRespCode) {
		this.visaStipRespCode = visaStipRespCode;
	}
	public String getVisaIssuRetCode() {
		return visaIssuRetCode;
	}
	public void setVisaIssuRetCode(String visaIssuRetCode) {
		this.visaIssuRetCode = visaIssuRetCode;
	}
	public String getVisaStipRetCode() {
		return visaStipRetCode;
	}
	public void setVisaStipRetCode(String visaStipRetCode) {
		this.visaStipRetCode = visaStipRetCode;
	}
	public String getVisaAvsResult() {
		return visaAvsResult;
	}
	public void setVisaAvsResult(String visaAvsResult) {
		this.visaAvsResult = visaAvsResult;
	}
	public String getStateCode() {
		return stateCode;
	}
	public void setStateCode(String stateCode) {
		this.stateCode = stateCode;
	}
	public String getCountyCode() {
		return countyCode;
	}
	public void setCountyCode(String countyCode) {
		this.countyCode = countyCode;
	}
	public String getZip9() {
		return zip9;
	}
	public void setZip9(String zip9) {
		this.zip9 = zip9;
	}
	public String getZip5() {
		return zip5;
	}
	public void setZip5(String zip5) {
		this.zip5 = zip5;
	}
	public String getTransactionID() {
		return transactionID;
	}
	public void setTransactionID(String transactionID) {
		this.transactionID = transactionID;
	}
	public String getRepeatTransaction() {
		return repeatTransaction;
	}
	public void setRepeatTransaction(String repeatTransaction) {
		this.repeatTransaction = repeatTransaction;
	}
	public String getVisaMerchantGroup() {
		return visaMerchantGroup;
	}
	public void setVisaMerchantGroup(String visaMerchantGroup) {
		this.visaMerchantGroup = visaMerchantGroup;
	}
	public String getVisaSourceStationID() {
		return visaSourceStationID;
	}
	public void setVisaSourceStationID(String visaSourceStationID) {
		this.visaSourceStationID = visaSourceStationID;
	}
	public String getVisaVisaphoneCode() {
		return visaVisaphoneCode;
	}
	public void setVisaVisaphoneCode(String visaVisaphoneCode) {
		this.visaVisaphoneCode = visaVisaphoneCode;
	}
	public String getVisaAutoSvcCode() {
		return visaAutoSvcCode;
	}
	public void setVisaAutoSvcCode(String visaAutoSvcCode) {
		this.visaAutoSvcCode = visaAutoSvcCode;
	}
	public String getVisaCWDenialRSN() {
		return visaCWDenialRSN;
	}
	public void setVisaCWDenialRSN(String visaCWDenialRSN) {
		this.visaCWDenialRSN = visaCWDenialRSN;
	}
	public String getVisaPacmDvrLevel() {
		return visaPacmDvrLevel;
	}
	public void setVisaPacmDvrLevel(String visaPacmDvrLevel) {
		this.visaPacmDvrLevel = visaPacmDvrLevel;
	}
	public String getVisaPacmDvrRSN() {
		return visaPacmDvrRSN;
	}
	public void setVisaPacmDvrRSN(String visaPacmDvrRSN) {
		this.visaPacmDvrRSN = visaPacmDvrRSN;
	}
	public String getVisaCaResult() {
		return visaCaResult;
	}
	public void setVisaCaResult(String visaCaResult) {
		this.visaCaResult = visaCaResult;
	}
	public String getVisaDebitOrg() {
		return visaDebitOrg;
	}
	public void setVisaDebitOrg(String visaDebitOrg) {
		this.visaDebitOrg = visaDebitOrg;
	}
	public String getVisaDebitType() {
		return visaDebitType;
	}
	public void setVisaDebitType(String visaDebitType) {
		this.visaDebitType = visaDebitType;
	}
	public String getVisaDebitAccount() {
		return visaDebitAccount;
	}
	public void setVisaDebitAccount(String visaDebitAccount) {
		this.visaDebitAccount = visaDebitAccount;
	}
	public String getVisaDebitRiskLevel() {
		return visaDebitRiskLevel;
	}
	public void setVisaDebitRiskLevel(String visaDebitRiskLevel) {
		this.visaDebitRiskLevel = visaDebitRiskLevel;
	}
	public String getVisaDebitTipAmount() {
		return visaDebitTipAmount;
	}
	public void setVisaDebitTipAmount(String visaDebitTipAmount) {
		this.visaDebitTipAmount = visaDebitTipAmount;
	}
	public String getVisaTermCountryCode() {
		return visaTermCountryCode;
	}
	public void setVisaTermCountryCode(String visaTermCountryCode) {
		this.visaTermCountryCode = visaTermCountryCode;
	}
	public XMLGregorianCalendar getVisatTermTransactionDate() {
		return visatTermTransactionDate;
	}
	public void setVisatTermTransactionDate(XMLGregorianCalendar visatTermTransactionDate) {
		this.visatTermTransactionDate = visatTermTransactionDate;
	}
	public String getMasterTCType() {
		return masterTCType;
	}
	public void setMasterTCType(String masterTCType) {
		this.masterTCType = masterTCType;
	}
	public String getMasterSpecialTCFlag() {
		return masterSpecialTCFlag;
	}
	public void setMasterSpecialTCFlag(String masterSpecialTCFlag) {
		this.masterSpecialTCFlag = masterSpecialTCFlag;
	}
	public String getMasterStateCode() {
		return masterStateCode;
	}
	public void setMasterStateCode(String masterStateCode) {
		this.masterStateCode = masterStateCode;
	}
	public String getMasterPosDevice() {
		return masterPosDevice;
	}
	public void setMasterPosDevice(String masterPosDevice) {
		this.masterPosDevice = masterPosDevice;
	}
	public String getMasterAvsOptionCode() {
		return masterAvsOptionCode;
	}
	public void setMasterAvsOptionCode(String masterAvsOptionCode) {
		this.masterAvsOptionCode = masterAvsOptionCode;
	}
	public String getMasterAvsResult() {
		return masterAvsResult;
	}
	public void setMasterAvsResult(String masterAvsResult) {
		this.masterAvsResult = masterAvsResult;
	}
	public String getMasterAuthAgentOld() {
		return masterAuthAgentOld;
	}
	public void setMasterAuthAgentOld(String masterAuthAgentOld) {
		this.masterAuthAgentOld = masterAuthAgentOld;
	}
	public String getMasterPaymentSvcIndicator() {
		return masterPaymentSvcIndicator;
	}
	public void setMasterPaymentSvcIndicator(String masterPaymentSvcIndicator) {
		this.masterPaymentSvcIndicator = masterPaymentSvcIndicator;
	}
	public String getMasterValidationCode() {
		return masterValidationCode;
	}
	public void setMasterValidationCode(String masterValidationCode) {
		this.masterValidationCode = masterValidationCode;
	}
	public String getMasterDownGrade() {
		return masterDownGrade;
	}
	public void setMasterDownGrade(String masterDownGrade) {
		this.masterDownGrade = masterDownGrade;
	}
	public String getMasterReptRteConversion() {
		return masterReptRteConversion;
	}
	public void setMasterReptRteConversion(String masterReptRteConversion) {
		this.masterReptRteConversion = masterReptRteConversion;
	}
	public String getMasterAuthAgentID() {
		return masterAuthAgentID;
	}
	public void setMasterAuthAgentID(String masterAuthAgentID) {
		this.masterAuthAgentID = masterAuthAgentID;
	}
	public String getDinersResponseCode() {
		return dinersResponseCode;
	}
	public void setDinersResponseCode(String dinersResponseCode) {
		this.dinersResponseCode = dinersResponseCode;
	}
	public String getDinersStandingCode() {
		return dinersStandingCode;
	}
	public void setDinersStandingCode(String dinersStandingCode) {
		this.dinersStandingCode = dinersStandingCode;
	}
	public String getDinersMerchantGroup() {
		return dinersMerchantGroup;
	}
	public void setDinersMerchantGroup(String dinersMerchantGroup) {
		this.dinersMerchantGroup = dinersMerchantGroup;
	}
	public String getDinersReqFranchise() {
		return dinersReqFranchise;
	}
	public void setDinersReqFranchise(String dinersReqFranchise) {
		this.dinersReqFranchise = dinersReqFranchise;
	}
	public String getDinersOwnFranchise() {
		return dinersOwnFranchise;
	}
	public void setDinersOwnFranchise(String dinersOwnFranchise) {
		this.dinersOwnFranchise = dinersOwnFranchise;
	}
	public String getDinersErrorCode() {
		return dinersErrorCode;
	}
	public void setDinersErrorCode(String dinersErrorCode) {
		this.dinersErrorCode = dinersErrorCode;
	}
	public String getFullAuthReasonCode() {
		return fullAuthReasonCode;
	}
	public void setFullAuthReasonCode(String fullAuthReasonCode) {
		this.fullAuthReasonCode = fullAuthReasonCode;
	}
	public String getDinersReferralResponse() {
		return dinersReferralResponse;
	}
	public void setDinersReferralResponse(String dinersReferralResponse) {
		this.dinersReferralResponse = dinersReferralResponse;
	}
	public String getDinersTimer() {
		return dinersTimer;
	}
	public void setDinersTimer(String dinersTimer) {
		this.dinersTimer = dinersTimer;
	}
	public String getCardProduct() {
		return cardProduct;
	}
	public void setCardProduct(String cardProduct) {
		this.cardProduct = cardProduct;
	}
	public String getResponseCode() {
		return responseCode;
	}
	public void setResponseCode(String responseCode) {
		this.responseCode = responseCode;
	}
	public String getRegionCodes() {
		return regionCodes;
	}
	public void setRegionCodes(String regionCodes) {
		this.regionCodes = regionCodes;
	}
	public XMLGregorianCalendar getOldOverridePurgeDate() {
		return oldOverridePurgeDate;
	}
	public void setOldOverridePurgeDate(XMLGregorianCalendar oldOverridePurgeDate) {
		this.oldOverridePurgeDate = oldOverridePurgeDate;
	}
	public XMLGregorianCalendar getNewOverridePurgeDate() {
		return newOverridePurgeDate;
	}
	public void setNewOverridePurgeDate(XMLGregorianCalendar newOverridePurgeDate) {
		this.newOverridePurgeDate = newOverridePurgeDate;
	}
	public String getOldOverrideCode() {
		return oldOverrideCode;
	}
	public void setOldOverrideCode(String oldOverrideCode) {
		this.oldOverrideCode = oldOverrideCode;
	}
	public String getNewOverrideCode() {
		return newOverrideCode;
	}
	public void setNewOverrideCode(String newOverrideCode) {
		this.newOverrideCode = newOverrideCode;
	}
	public String getOldInstantUpgrade() {
		return oldInstantUpgrade;
	}
	public void setOldInstantUpgrade(String oldInstantUpgrade) {
		this.oldInstantUpgrade = oldInstantUpgrade;
	}
	public String getNewInstantUpdade() {
		return newInstantUpdade;
	}
	public void setNewInstantUpdade(String newInstantUpdade) {
		this.newInstantUpdade = newInstantUpdade;
	}
	public String getInstantUpgradeVerifyID() {
		return instantUpgradeVerifyID;
	}
	public void setInstantUpgradeVerifyID(String instantUpgradeVerifyID) {
		this.instantUpgradeVerifyID = instantUpgradeVerifyID;
	}
	public String getPinCustomerNumber() {
		return pinCustomerNumber;
	}
	public void setPinCustomerNumber(String pinCustomerNumber) {
		this.pinCustomerNumber = pinCustomerNumber;
	}
	public String getOldPinOffset() {
		return oldPinOffset;
	}
	public void setOldPinOffset(String oldPinOffset) {
		this.oldPinOffset = oldPinOffset;
	}
	public String getNewPinOffset() {
		return newPinOffset;
	}
	public void setNewPinOffset(String newPinOffset) {
		this.newPinOffset = newPinOffset;
	}
	public String getNewPinKey() {
		return newPinKey;
	}
	public void setNewPinKey(String newPinKey) {
		this.newPinKey = newPinKey;
	}
	public String getOldPinRetryCount() {
		return oldPinRetryCount;
	}
	public void setOldPinRetryCount(String oldPinRetryCount) {
		this.oldPinRetryCount = oldPinRetryCount;
	}
	public String getNewPinRetryCount() {
		return newPinRetryCount;
	}
	public void setNewPinRetryCount(String newPinRetryCount) {
		this.newPinRetryCount = newPinRetryCount;
	}
	public String getOldSetStatus() {
		return oldSetStatus;
	}
	public void setOldSetStatus(String oldSetStatus) {
		this.oldSetStatus = oldSetStatus;
	}
	public String getNewSetStatus() {
		return newSetStatus;
	}
	public void setNewSetStatus(String newSetStatus) {
		this.newSetStatus = newSetStatus;
	}
	public String getOldSetReason() {
		return oldSetReason;
	}
	public void setOldSetReason(String oldSetReason) {
		this.oldSetReason = oldSetReason;
	}
	public String getNewSetReason() {
		return newSetReason;
	}
	public void setNewSetReason(String newSetReason) {
		this.newSetReason = newSetReason;
	}
	public String getOldSetDateProc() {
		return oldSetDateProc;
	}
	public void setOldSetDateProc(String oldSetDateProc) {
		this.oldSetDateProc = oldSetDateProc;
	}
	public String getNewSetDateProc() {
		return newSetDateProc;
	}
	public void setNewSetDateProc(String newSetDateProc) {
		this.newSetDateProc = newSetDateProc;
	}
	public String getOfflineBlock() {
		return offlineBlock;
	}
	public void setOfflineBlock(String offlineBlock) {
		this.offlineBlock = offlineBlock;
	}
	public String getOldEmvCardUse() {
		return oldEmvCardUse;
	}
	public void setOldEmvCardUse(String oldEmvCardUse) {
		this.oldEmvCardUse = oldEmvCardUse;
	}
	public String getPreviousEmvCardUseIndicator() {
		return previousEmvCardUseIndicator;
	}
	public void setPreviousEmvCardUseIndicator(String previousEmvCardUseIndicator) {
		this.previousEmvCardUseIndicator = previousEmvCardUseIndicator;
	}
	public String getNewEmvCardUse() {
		return newEmvCardUse;
	}
	public void setNewEmvCardUse(String newEmvCardUse) {
		this.newEmvCardUse = newEmvCardUse;
	}
	public String getSettAmount() {
		return settAmount;
	}
	public void setSettAmount(String settAmount) {
		this.settAmount = settAmount;
	}
	public String getSettDate() {
		return settDate;
	}
	public void setSettDate(String settDate) {
		this.settDate = settDate;
	}
	public String getCardAcceptTerm() {
		return cardAcceptTerm;
	}
	public void setCardAcceptTerm(String cardAcceptTerm) {
		this.cardAcceptTerm = cardAcceptTerm;
	}
	public String getSettCurrencyCode() {
		return settCurrencyCode;
	}
	public void setSettCurrencyCode(String settCurrencyCode) {
		this.settCurrencyCode = settCurrencyCode;
	}
	public String getConsCommitAmount() {
		return consCommitAmount;
	}
	public void setConsCommitAmount(String consCommitAmount) {
		this.consCommitAmount = consCommitAmount;
	}
	public String getDciIntfAmount() {
		return dciIntfAmount;
	}
	public void setDciIntfAmount(String dciIntfAmount) {
		this.dciIntfAmount = dciIntfAmount;
	}
	public String getDciIntfCurrencyCode() {
		return dciIntfCurrencyCode;
	}
	public void setDciIntfCurrencyCode(String dciIntfCurrencyCode) {
		this.dciIntfCurrencyCode = dciIntfCurrencyCode;
	}
	public String getDinersActionCode() {
		return dinersActionCode;
	}
	public void setDinersActionCode(String dinersActionCode) {
		this.dinersActionCode = dinersActionCode;
	}
	public String getDinersCardCurrency() {
		return dinersCardCurrency;
	}
	public void setDinersCardCurrency(String dinersCardCurrency) {
		this.dinersCardCurrency = dinersCardCurrency;
	}
	public String getEdcIndicator() {
		return edcIndicator;
	}
	public void setEdcIndicator(String edcIndicator) {
		this.edcIndicator = edcIndicator;
	}
	public String getExceptionResponseCode() {
		return exceptionResponseCode;
	}
	public void setExceptionResponseCode(String exceptionResponseCode) {
		this.exceptionResponseCode = exceptionResponseCode;
	}
	public String getFromOldCardIndicator() {
		return fromOldCardIndicator;
	}
	public void setFromOldCardIndicator(String fromOldCardIndicator) {
		this.fromOldCardIndicator = fromOldCardIndicator;
	}
	public String getInstUpgChangeType() {
		return instUpgChangeType;
	}
	public void setInstUpgChangeType(String instUpgChangeType) {
		this.instUpgChangeType = instUpgChangeType;
	}
	public String getInstUpgLimit() {
		return instUpgLimit;
	}
	public void setInstUpgLimit(String instUpgLimit) {
		this.instUpgLimit = instUpgLimit;
	}
	public XMLGregorianCalendar getInstUpgPurgeDate() {
		return instUpgPurgeDate;
	}
	public void setInstUpgPurgeDate(XMLGregorianCalendar instUpgPurgeDate) {
		this.instUpgPurgeDate = instUpgPurgeDate;
	}
	public String getIsoResponseCode() {
		return isoResponseCode;
	}
	public void setIsoResponseCode(String isoResponseCode) {
		this.isoResponseCode = isoResponseCode;
	}
	public XMLGregorianCalendar getOverrideCodePurgeDate() {
		return overrideCodePurgeDate;
	}
	public void setOverrideCodePurgeDate(XMLGregorianCalendar overrideCodePurgeDate) {
		this.overrideCodePurgeDate = overrideCodePurgeDate;
	}
	public String getPhoneCardResponseCode() {
		return phoneCardResponseCode;
	}
	public void setPhoneCardResponseCode(String phoneCardResponseCode) {
		this.phoneCardResponseCode = phoneCardResponseCode;
	}
	public String getPinTermID() {
		return pinTermID;
	}
	public void setPinTermID(String pinTermID) {
		this.pinTermID = pinTermID;
	}
	public String gettPinResetIndicator() {
		return tPinResetIndicator;
	}
	public void settPinResetIndicator(String tPinResetIndicator) {
		this.tPinResetIndicator = tPinResetIndicator;
	}
	public XMLGregorianCalendar getMasterSetlementDate() {
		return masterSetlementDate;
	}
	public void setMasterSetlementDate(XMLGregorianCalendar masterSetlementDate) {
		this.masterSetlementDate = masterSetlementDate;
	}
	public String getCardAuthorRI() {
		return cardAuthorRI;
	}
	public void setCardAuthorRI(String cardAuthorRI) {
		this.cardAuthorRI = cardAuthorRI;
	}
	public String getProcessCode() {
		return processCode;
	}
	public void setProcessCode(String processCode) {
		this.processCode = processCode;
	}
	public String getChBilingAmount() {
		return chBilingAmount;
	}
	public void setChBilingAmount(String chBilingAmount) {
		this.chBilingAmount = chBilingAmount;
	}
	public String getCrcDecSep() {
		return crcDecSep;
	}
	public void setCrcDecSep(String crcDecSep) {
		this.crcDecSep = crcDecSep;
	}
	public String getExpiryDatePresence() {
		return expiryDatePresence;
	}
	public void setExpiryDatePresence(String expiryDatePresence) {
		this.expiryDatePresence = expiryDatePresence;
	}
	public String getPosEmPan() {
		return posEmPan;
	}
	public void setPosEmPan(String posEmPan) {
		this.posEmPan = posEmPan;
	}
	public String getCardSeqNbr() {
		return cardSeqNbr;
	}
	public void setCardSeqNbr(String cardSeqNbr) {
		this.cardSeqNbr = cardSeqNbr;
	}
	public String getTypeBMerchantID() {
		return typeBMerchantID;
	}
	public void setTypeBMerchantID(String typeBMerchantID) {
		this.typeBMerchantID = typeBMerchantID;
	}
	public String getIcCpseudoTerm() {
		return icCpseudoTerm;
	}
	public void setIcCpseudoTerm(String icCpseudoTerm) {
		this.icCpseudoTerm = icCpseudoTerm;
	}
	public String getCmBlockCode() {
		return cmBlockCode;
	}
	public void setCmBlockCode(String cmBlockCode) {
		this.cmBlockCode = cmBlockCode;
	}
	public String getCw2CVC2() {
		return cw2CVC2;
	}
	public void setCw2CVC2(String cw2cvc2) {
		cw2CVC2 = cw2cvc2;
	}
	public String getCw2Presence() {
		return cw2Presence;
	}
	public void setCw2Presence(String cw2Presence) {
		this.cw2Presence = cw2Presence;
	}
	public XMLGregorianCalendar getExceptionPurgeDate() {
		return exceptionPurgeDate;
	}
	public void setExceptionPurgeDate(XMLGregorianCalendar exceptionPurgeDate) {
		this.exceptionPurgeDate = exceptionPurgeDate;
	}
	public String getIccIsaCCAAmount() {
		return iccIsaCCAAmount;
	}
	public void setIccIsaCCAAmount(String iccIsaCCAAmount) {
		this.iccIsaCCAAmount = iccIsaCCAAmount;
	}
	public String getIccIsaCCASettlement() {
		return iccIsaCCASettlement;
	}
	public void setIccIsaCCASettlement(String iccIsaCCASettlement) {
		this.iccIsaCCASettlement = iccIsaCCASettlement;
	}
	public String getIccoifcbaAmount() {
		return iccoifcbaAmount;
	}
	public void setIccoifcbaAmount(String iccoifcbaAmount) {
		this.iccoifcbaAmount = iccoifcbaAmount;
	}
	public String getIccOptIssAmount() {
		return iccOptIssAmount;
	}
	public void setIccOptIssAmount(String iccOptIssAmount) {
		this.iccOptIssAmount = iccOptIssAmount;
	}
	public String getInvCWCVC2Indicator() {
		return invCWCVC2Indicator;
	}
	public void setInvCWCVC2Indicator(String invCWCVC2Indicator) {
		this.invCWCVC2Indicator = invCWCVC2Indicator;
	}
	public String getInvCWCVCIndicator() {
		return invCWCVCIndicator;
	}
	public void setInvCWCVCIndicator(String invCWCVCIndicator) {
		this.invCWCVCIndicator = invCWCVCIndicator;
	}
	public String getJetcoAcquirerBin() {
		return jetcoAcquirerBin;
	}
	public void setJetcoAcquirerBin(String jetcoAcquirerBin) {
		this.jetcoAcquirerBin = jetcoAcquirerBin;
	}
	public String getMasterSettlementAmount() {
		return masterSettlementAmount;
	}
	public void setMasterSettlementAmount(String masterSettlementAmount) {
		this.masterSettlementAmount = masterSettlementAmount;
	}
	public String getMasterRRCAmount() {
		return masterRRCAmount;
	}
	public void setMasterRRCAmount(String masterRRCAmount) {
		this.masterRRCAmount = masterRRCAmount;
	}
	public String getMasterRRCDecSep() {
		return masterRRCDecSep;
	}
	public void setMasterRRCDecSep(String masterRRCDecSep) {
		this.masterRRCDecSep = masterRRCDecSep;
	}
	public String getMasterRetrivalNumber() {
		return masterRetrivalNumber;
	}
	public void setMasterRetrivalNumber(String masterRetrivalNumber) {
		this.masterRetrivalNumber = masterRetrivalNumber;
	}
	public String getMasterResponseCode() {
		return masterResponseCode;
	}
	public void setMasterResponseCode(String masterResponseCode) {
		this.masterResponseCode = masterResponseCode;
	}
	public String getMasterECI() {
		return masterECI;
	}
	public void setMasterECI(String masterECI) {
		this.masterECI = masterECI;
	}
	public String getMasterInvoiceCvcIndicator() {
		return masterInvoiceCvcIndicator;
	}
	public void setMasterInvoiceCvcIndicator(String masterInvoiceCvcIndicator) {
		this.masterInvoiceCvcIndicator = masterInvoiceCvcIndicator;
	}
	public String getMasterTRK2ErrorIndicator() {
		return masterTRK2ErrorIndicator;
	}
	public void setMasterTRK2ErrorIndicator(String masterTRK2ErrorIndicator) {
		this.masterTRK2ErrorIndicator = masterTRK2ErrorIndicator;
	}
	public String getMasterTrk2TfmIndicator() {
		return masterTrk2TfmIndicator;
	}
	public void setMasterTrk2TfmIndicator(String masterTrk2TfmIndicator) {
		this.masterTrk2TfmIndicator = masterTrk2TfmIndicator;
	}
	public String getMasterTransactionIndicator() {
		return masterTransactionIndicator;
	}
	public void setMasterTransactionIndicator(String masterTransactionIndicator) {
		this.masterTransactionIndicator = masterTransactionIndicator;
	}
	public String getMasterUCAF() {
		return masterUCAF;
	}
	public void setMasterUCAF(String masterUCAF) {
		this.masterUCAF = masterUCAF;
	}
	public String getMasterUCAFData() {
		return masterUCAFData;
	}
	public void setMasterUCAFData(String masterUCAFData) {
		this.masterUCAFData = masterUCAFData;
	}
	public String getMasterCardTermIndicator() {
		return masterCardTermIndicator;
	}
	public void setMasterCardTermIndicator(String masterCardTermIndicator) {
		this.masterCardTermIndicator = masterCardTermIndicator;
	}
	public String getMasterPosData() {
		return masterPosData;
	}
	public void setMasterPosData(String masterPosData) {
		this.masterPosData = masterPosData;
	}
	public String getMasterPosDataLen() {
		return masterPosDataLen;
	}
	public void setMasterPosDataLen(String masterPosDataLen) {
		this.masterPosDataLen = masterPosDataLen;
	}
	public String getMasterBnkntDataRec() {
		return masterBnkntDataRec;
	}
	public void setMasterBnkntDataRec(String masterBnkntDataRec) {
		this.masterBnkntDataRec = masterBnkntDataRec;
	}
	public String getMasterBnkntRefNumber() {
		return masterBnkntRefNumber;
	}
	public void setMasterBnkntRefNumber(String masterBnkntRefNumber) {
		this.masterBnkntRefNumber = masterBnkntRefNumber;
	}
	public String getMasterFnclNetworkCode() {
		return masterFnclNetworkCode;
	}
	public void setMasterFnclNetworkCode(String masterFnclNetworkCode) {
		this.masterFnclNetworkCode = masterFnclNetworkCode;
	}
	public String getMasterChipData() {
		return masterChipData;
	}
	public void setMasterChipData(String masterChipData) {
		this.masterChipData = masterChipData;
	}
	public String getMasterDownOption() {
		return masterDownOption;
	}
	public void setMasterDownOption(String masterDownOption) {
		this.masterDownOption = masterDownOption;
	}
	public String getMasterDownReason() {
		return masterDownReason;
	}
	public void setMasterDownReason(String masterDownReason) {
		this.masterDownReason = masterDownReason;
	}
	public String getMasterOptional0130() {
		return masterOptional0130;
	}
	public void setMasterOptional0130(String masterOptional0130) {
		this.masterOptional0130 = masterOptional0130;
	}
	public String getMasterOptional3160() {
		return masterOptional3160;
	}
	public void setMasterOptional3160(String masterOptional3160) {
		this.masterOptional3160 = masterOptional3160;
	}
	public String getMasterOptionalData() {
		return masterOptionalData;
	}
	public void setMasterOptionalData(String masterOptionalData) {
		this.masterOptionalData = masterOptionalData;
	}
	public String getMasterOptionalDataLen() {
		return masterOptionalDataLen;
	}
	public void setMasterOptionalDataLen(String masterOptionalDataLen) {
		this.masterOptionalDataLen = masterOptionalDataLen;
	}
	public String getNewAltBlockCodeR() {
		return newAltBlockCodeR;
	}
	public void setNewAltBlockCodeR(String newAltBlockCodeR) {
		this.newAltBlockCodeR = newAltBlockCodeR;
	}
	public String getTerminalID() {
		return terminalID;
	}
	public void setTerminalID(String terminalID) {
		this.terminalID = terminalID;
	}
	public String getTraceNbr() {
		return traceNbr;
	}
	public void setTraceNbr(String traceNbr) {
		this.traceNbr = traceNbr;
	}
	public String getTrackData() {
		return trackData;
	}
	public void setTrackData(String trackData) {
		this.trackData = trackData;
	}
	public String getValidCAWIndicator() {
		return validCAWIndicator;
	}
	public void setValidCAWIndicator(String validCAWIndicator) {
		this.validCAWIndicator = validCAWIndicator;
	}
	public String getVisaSystemAuditTrace() {
		return visaSystemAuditTrace;
	}
	public void setVisaSystemAuditTrace(String visaSystemAuditTrace) {
		this.visaSystemAuditTrace = visaSystemAuditTrace;
	}
	public String getVisaB044CAW() {
		return visaB044CAW;
	}
	public void setVisaB044CAW(String visaB044CAW) {
		this.visaB044CAW = visaB044CAW;
	}
	public String getVisaCAWReturnCode() {
		return visaCAWReturnCode;
	}
	public void setVisaCAWReturnCode(String visaCAWReturnCode) {
		this.visaCAWReturnCode = visaCAWReturnCode;
	}
	public String getVisaPacmRsn() {
		return visaPacmRsn;
	}
	public void setVisaPacmRsn(String visaPacmRsn) {
		this.visaPacmRsn = visaPacmRsn;
	}
	public String getVisaAdditional0130() {
		return visaAdditional0130;
	}
	public void setVisaAdditional0130(String visaAdditional0130) {
		this.visaAdditional0130 = visaAdditional0130;
	}
	public String getVisaAdditional3160() {
		return visaAdditional3160;
	}
	public void setVisaAdditional3160(String visaAdditional3160) {
		this.visaAdditional3160 = visaAdditional3160;
	}
	public String getVisaAdditionalData() {
		return visaAdditionalData;
	}
	public void setVisaAdditionalData(String visaAdditionalData) {
		this.visaAdditionalData = visaAdditionalData;
	}
	public String getVisaAdditionalDataLength() {
		return visaAdditionalDataLength;
	}
	public void setVisaAdditionalDataLength(String visaAdditionalDataLength) {
		this.visaAdditionalDataLength = visaAdditionalDataLength;
	}
	public String getVisaCountryCodeX() {
		return visaCountryCodeX;
	}
	public void setVisaCountryCodeX(String visaCountryCodeX) {
		this.visaCountryCodeX = visaCountryCodeX;
	}
	public String getVisaPosGeoDataLength() {
		return visaPosGeoDataLength;
	}
	public void setVisaPosGeoDataLength(String visaPosGeoDataLength) {
		this.visaPosGeoDataLength = visaPosGeoDataLength;
	}
	public String getVisaPosGeoDataRecord() {
		return visaPosGeoDataRecord;
	}
	public void setVisaPosGeoDataRecord(String visaPosGeoDataRecord) {
		this.visaPosGeoDataRecord = visaPosGeoDataRecord;
	}
	public String getVisaStateCodeX() {
		return visaStateCodeX;
	}
	public void setVisaStateCodeX(String visaStateCodeX) {
		this.visaStateCodeX = visaStateCodeX;
	}
	public String getVisaPosEntryCode() {
		return visaPosEntryCode;
	}
	public void setVisaPosEntryCode(String visaPosEntryCode) {
		this.visaPosEntryCode = visaPosEntryCode;
	}
	public String getVisaPosEntryLength() {
		return visaPosEntryLength;
	}
	public void setVisaPosEntryLength(String visaPosEntryLength) {
		this.visaPosEntryLength = visaPosEntryLength;
	}
	public String getVisaAmountLength() {
		return visaAmountLength;
	}
	public void setVisaAmountLength(String visaAmountLength) {
		this.visaAmountLength = visaAmountLength;
	}
	public String getVisaAmountSub01() {
		return visaAmountSub01;
	}
	public void setVisaAmountSub01(String visaAmountSub01) {
		this.visaAmountSub01 = visaAmountSub01;
	}
	public String getVisaAmountSub02() {
		return visaAmountSub02;
	}
	public void setVisaAmountSub02(String visaAmountSub02) {
		this.visaAmountSub02 = visaAmountSub02;
	}
	public String getVisaAmountSub03() {
		return visaAmountSub03;
	}
	public void setVisaAmountSub03(String visaAmountSub03) {
		this.visaAmountSub03 = visaAmountSub03;
	}
	public String getVisaPaymentSvcIndicator() {
		return visaPaymentSvcIndicator;
	}
	public void setVisaPaymentSvcIndicator(String visaPaymentSvcIndicator) {
		this.visaPaymentSvcIndicator = visaPaymentSvcIndicator;
	}
	public String getVisaPaymentSvcLength() {
		return visaPaymentSvcLength;
	}
	public void setVisaPaymentSvcLength(String visaPaymentSvcLength) {
		this.visaPaymentSvcLength = visaPaymentSvcLength;
	}
	public String getVisaValidationCode() {
		return visaValidationCode;
	}
	public void setVisaValidationCode(String visaValidationCode) {
		this.visaValidationCode = visaValidationCode;
	}
	public String getVisaAccountTransactionAmount() {
		return visaAccountTransactionAmount;
	}
	public void setVisaAccountTransactionAmount(String visaAccountTransactionAmount) {
		this.visaAccountTransactionAmount = visaAccountTransactionAmount;
	}
	public String getVisaB126CAW() {
		return visaB126CAW;
	}
	public void setVisaB126CAW(String visaB126CAW) {
		this.visaB126CAW = visaB126CAW;
	}
	public String getVisaXid() {
		return visaXid;
	}
	public void setVisaXid(String visaXid) {
		this.visaXid = visaXid;
	}
	public String getVisaTermCapProf() {
		return visaTermCapProf;
	}
	public void setVisaTermCapProf(String visaTermCapProf) {
		this.visaTermCapProf = visaTermCapProf;
	}
	public String getVisaTermVerificationRS() {
		return visaTermVerificationRS;
	}
	public void setVisaTermVerificationRS(String visaTermVerificationRS) {
		this.visaTermVerificationRS = visaTermVerificationRS;
	}
	public String getVisaUnpredictNumber() {
		return visaUnpredictNumber;
	}
	public void setVisaUnpredictNumber(String visaUnpredictNumber) {
		this.visaUnpredictNumber = visaUnpredictNumber;
	}
	public String getVisaTermSerialNumber() {
		return visaTermSerialNumber;
	}
	public void setVisaTermSerialNumber(String visaTermSerialNumber) {
		this.visaTermSerialNumber = visaTermSerialNumber;
	}
	public String getVisaDiscrData() {
		return visaDiscrData;
	}
	public void setVisaDiscrData(String visaDiscrData) {
		this.visaDiscrData = visaDiscrData;
	}
	public String getVisaDiscrLength() {
		return visaDiscrLength;
	}
	public void setVisaDiscrLength(String visaDiscrLength) {
		this.visaDiscrLength = visaDiscrLength;
	}
	public String getVisaIssDiscrData() {
		return visaIssDiscrData;
	}
	public void setVisaIssDiscrData(String visaIssDiscrData) {
		this.visaIssDiscrData = visaIssDiscrData;
	}
	public String getVisaIssDiscrLength() {
		return visaIssDiscrLength;
	}
	public void setVisaIssDiscrLength(String visaIssDiscrLength) {
		this.visaIssDiscrLength = visaIssDiscrLength;
	}
	public String getVisaCryptogram() {
		return visaCryptogram;
	}
	public void setVisaCryptogram(String visaCryptogram) {
		this.visaCryptogram = visaCryptogram;
	}
	public String getVisaAppTransactionCounter() {
		return visaAppTransactionCounter;
	}
	public void setVisaAppTransactionCounter(String visaAppTransactionCounter) {
		this.visaAppTransactionCounter = visaAppTransactionCounter;
	}
	public String getVisaAppIntegProf() {
		return visaAppIntegProf;
	}
	public void setVisaAppIntegProf(String visaAppIntegProf) {
		this.visaAppIntegProf = visaAppIntegProf;
	}
	public String getVisaArpcData() {
		return visaArpcData;
	}
	public void setVisaArpcData(String visaArpcData) {
		this.visaArpcData = visaArpcData;
	}
	public String getVisaIssAuthData() {
		return visaIssAuthData;
	}
	public void setVisaIssAuthData(String visaIssAuthData) {
		this.visaIssAuthData = visaIssAuthData;
	}
	public String getVisaIssAuthLength() {
		return visaIssAuthLength;
	}
	public void setVisaIssAuthLength(String visaIssAuthLength) {
		this.visaIssAuthLength = visaIssAuthLength;
	}
	public String getVisaIssScriptData() {
		return visaIssScriptData;
	}
	public void setVisaIssScriptData(String visaIssScriptData) {
		this.visaIssScriptData = visaIssScriptData;
	}
	public String getVisaIssScriptLength() {
		return visaIssScriptLength;
	}
	public void setVisaIssScriptLength(String visaIssScriptLength) {
		this.visaIssScriptLength = visaIssScriptLength;
	}
	public String getVisaIssScriptr() {
		return visaIssScriptr;
	}
	public void setVisaIssScriptr(String visaIssScriptr) {
		this.visaIssScriptr = visaIssScriptr;
	}
	public String getVisaIssScriptrLength() {
		return visaIssScriptrLength;
	}
	public void setVisaIssScriptrLength(String visaIssScriptrLength) {
		this.visaIssScriptrLength = visaIssScriptrLength;
	}
	public String getVisaCrytoTransactionType() {
		return visaCrytoTransactionType;
	}
	public void setVisaCrytoTransactionType(String visaCrytoTransactionType) {
		this.visaCrytoTransactionType = visaCrytoTransactionType;
	}
	public String getVisaCryptoAmount() {
		return visaCryptoAmount;
	}
	public void setVisaCryptoAmount(String visaCryptoAmount) {
		this.visaCryptoAmount = visaCryptoAmount;
	}
	public String getVisaCryptoCurrencyCode() {
		return visaCryptoCurrencyCode;
	}
	public void setVisaCryptoCurrencyCode(String visaCryptoCurrencyCode) {
		this.visaCryptoCurrencyCode = visaCryptoCurrencyCode;
	}
	public String getVisaCryptoCashback() {
		return visaCryptoCashback;
	}
	public void setVisaCryptoCashback(String visaCryptoCashback) {
		this.visaCryptoCashback = visaCryptoCashback;
	}
	public String getVisaDebitTipAmountV99() {
		return visaDebitTipAmountV99;
	}
	public void setVisaDebitTipAmountV99(String visaDebitTipAmountV99) {
		this.visaDebitTipAmountV99 = visaDebitTipAmountV99;
	}
	public String getTransactionAmountV99() {
		return transactionAmountV99;
	}
	public void setTransactionAmountV99(String transactionAmountV99) {
		this.transactionAmountV99 = transactionAmountV99;
	}
	public String getAccountType() {
		return accountType;
	}
	public void setAccountType(String accountType) {
		this.accountType = accountType;
	}
	public String getCurrencyCode() {
		return currencyCode;
	}
	public void setCurrencyCode(String currencyCode) {
		this.currencyCode = currencyCode;
	}
	public String getBatchnumber() {
		return batchnumber;
	}
	public void setBatchnumber(String batchnumber) {
		this.batchnumber = batchnumber;
	}
	public String getBlockMaintFlag() {
		return blockMaintFlag;
	}
	public void setBlockMaintFlag(String blockMaintFlag) {
		this.blockMaintFlag = blockMaintFlag;
	}
	public String getCardMaintOperatorID() {
		return cardMaintOperatorID;
	}
	public void setCardMaintOperatorID(String cardMaintOperatorID) {
		this.cardMaintOperatorID = cardMaintOperatorID;
	}
	public String getCardMaintType() {
		return cardMaintType;
	}
	public void setCardMaintType(String cardMaintType) {
		this.cardMaintType = cardMaintType;
	}
	public String getIccOrigB051() {
		return iccOrigB051;
	}
	public void setIccOrigB051(String iccOrigB051) {
		this.iccOrigB051 = iccOrigB051;
	}
	public String getNewBlockCode() {
		return newBlockCode;
	}
	public void setNewBlockCode(String newBlockCode) {
		this.newBlockCode = newBlockCode;
	}
	public XMLGregorianCalendar getNewBlockCodeDate() {
		return newBlockCodeDate;
	}
	public void setNewBlockCodeDate(XMLGregorianCalendar newBlockCodeDate) {
		this.newBlockCodeDate = newBlockCodeDate;
	}
	public String getNewBlockCodeR() {
		return newBlockCodeR;
	}
	public void setNewBlockCodeR(String newBlockCodeR) {
		this.newBlockCodeR = newBlockCodeR;
	}
	public XMLGregorianCalendar getNewBlockCodeTime() {
		return newBlockCodeTime;
	}
	public void setNewBlockCodeTime(XMLGregorianCalendar newBlockCodeTime) {
		this.newBlockCodeTime = newBlockCodeTime;
	}
	public String getOldBlockCode() {
		return oldBlockCode;
	}
	public void setOldBlockCode(String oldBlockCode) {
		this.oldBlockCode = oldBlockCode;
	}
	public String getOldBlockCodeR() {
		return oldBlockCodeR;
	}
	public void setOldBlockCodeR(String oldBlockCodeR) {
		this.oldBlockCodeR = oldBlockCodeR;
	}
	public String getOnlinePrint() {
		return onlinePrint;
	}
	public void setOnlinePrint(String onlinePrint) {
		this.onlinePrint = onlinePrint;
	}
	public String getOptionalDataIndicator() {
		return optionalDataIndicator;
	}
	public void setOptionalDataIndicator(String optionalDataIndicator) {
		this.optionalDataIndicator = optionalDataIndicator;
	}
	public String getPinDataPresent() {
		return pinDataPresent;
	}
	public void setPinDataPresent(String pinDataPresent) {
		this.pinDataPresent = pinDataPresent;
	}
	public String getPinKey() {
		return pinKey;
	}
	public void setPinKey(String pinKey) {
		this.pinKey = pinKey;
	}
	public String getPinOffset() {
		return pinOffset;
	}
	public void setPinOffset(String pinOffset) {
		this.pinOffset = pinOffset;
	}
	public String getPrevBlockCode() {
		return prevBlockCode;
	}
	public void setPrevBlockCode(String prevBlockCode) {
		this.prevBlockCode = prevBlockCode;
	}
	public String getPrevBlockCodeR() {
		return prevBlockCodeR;
	}
	public void setPrevBlockCodeR(String prevBlockCodeR) {
		this.prevBlockCodeR = prevBlockCodeR;
	}
	public String getRecordType() {
		return recordType;
	}
	public void setRecordType(String recordType) {
		this.recordType = recordType;
	}
	public String getRefNumber() {
		return refNumber;
	}
	public void setRefNumber(String refNumber) {
		this.refNumber = refNumber;
	}
	public String getRefNumberX() {
		return refNumberX;
	}
	public void setRefNumberX(String refNumberX) {
		this.refNumberX = refNumberX;
	}
	public String getReplaceDigit() {
		return replaceDigit;
	}
	public void setReplaceDigit(String replaceDigit) {
		this.replaceDigit = replaceDigit;
	}
	public String getSpeicalHandlingFile() {
		return speicalHandlingFile;
	}
	public void setSpeicalHandlingFile(String speicalHandlingFile) {
		this.speicalHandlingFile = speicalHandlingFile;
	}
	public String getSuppIndicator() {
		return suppIndicator;
	}
	public void setSuppIndicator(String suppIndicator) {
		this.suppIndicator = suppIndicator;
	}
	public String getVisaB060910() {
		return visaB060910;
	}
	public void setVisaB060910(String visaB060910) {
		this.visaB060910 = visaB060910;
	}
	public String getTerminalIDX() {
		return terminalIDX;
	}
	public void setTerminalIDX(String terminalIDX) {
		this.terminalIDX = terminalIDX;
	}
	public String getTfc0005CWSPID() {
		return tfc0005CWSPID;
	}
	public void setTfc0005CWSPID(String tfc0005cwspid) {
		tfc0005CWSPID = tfc0005cwspid;
	}
	public String getKeyEOD() {
		return keyEOD;
	}
	public void setKeyEOD(String keyEOD) {
		this.keyEOD = keyEOD;
	}
	public String getKeyTieBreak() {
		return keyTieBreak;
	}
	public void setKeyTieBreak(String keyTieBreak) {
		this.keyTieBreak = keyTieBreak;
	}
	public String getKeyFileSeg() {
		return keyFileSeg;
	}
	public void setKeyFileSeg(String keyFileSeg) {
		this.keyFileSeg = keyFileSeg;
	}
	public String getEodIndicator() {
		return eodIndicator;
	}
	public void setEodIndicator(String eodIndicator) {
		this.eodIndicator = eodIndicator;
	}
	public String getActivityData() {
		return activityData;
	}
	public void setActivityData(String activityData) {
		this.activityData = activityData;
	}
	public String getMessageArea() {
		return messageArea;
	}
	public void setMessageArea(String messageArea) {
		this.messageArea = messageArea;
	}
	public String getSpecialRecordType() {
		return specialRecordType;
	}
	public void setSpecialRecordType(String specialRecordType) {
		this.specialRecordType = specialRecordType;
	}
	public String getMaintenanceRecord() {
		return maintenanceRecord;
	}
	public void setMaintenanceRecord(String maintenanceRecord) {
		this.maintenanceRecord = maintenanceRecord;
	}
	public String getLocalTxnTime() {
		return localTxnTime;
	}
	public void setLocalTxnTime(String localTxnTime) {
		this.localTxnTime = localTxnTime;
	}
	public String getLocalTxnDate() {
		return localTxnDate;
	}
	public void setLocalTxnDate(String localTxnDate) {
		this.localTxnDate = localTxnDate;
	}
	public String getRetrievalNumber() {
		return retrievalNumber;
	}
	public void setRetrievalNumber(String retrievalNumber) {
		this.retrievalNumber = retrievalNumber;
	}
	public String getAmedCrLimit() {
		return amedCrLimit;
	}
	public void setAmedCrLimit(String amedCrLimit) {
		this.amedCrLimit = amedCrLimit;
	}
	public String getAmbsCrLimit() {
		return ambsCrLimit;
	}
	public void setAmbsCrLimit(String ambsCrLimit) {
		this.ambsCrLimit = ambsCrLimit;
	}
	public String getAmrmCrLimit() {
		return amrmCrLimit;
	}
	public void setAmrmCrLimit(String amrmCrLimit) {
		this.amrmCrLimit = amrmCrLimit;
	}
	public String getAmedAvailCrLimit() {
		return amedAvailCrLimit;
	}
	public void setAmedAvailCrLimit(String amedAvailCrLimit) {
		this.amedAvailCrLimit = amedAvailCrLimit;
	}
	public String getAmbsAvailCrLimit() {
		return ambsAvailCrLimit;
	}
	public void setAmbsAvailCrLimit(String ambsAvailCrLimit) {
		this.ambsAvailCrLimit = ambsAvailCrLimit;
	}
	public String getAmrmAvailCrLimit() {
		return amrmAvailCrLimit;
	}
	public void setAmrmAvailCrLimit(String amrmAvailCrLimit) {
		this.amrmAvailCrLimit = amrmAvailCrLimit;
	}
	public String getAmedCommitAmount() {
		return amedCommitAmount;
	}
	public void setAmedCommitAmount(String amedCommitAmount) {
		this.amedCommitAmount = amedCommitAmount;
	}
	public String getAmbsCommitAmount() {
		return ambsCommitAmount;
	}
	public void setAmbsCommitAmount(String ambsCommitAmount) {
		this.ambsCommitAmount = ambsCommitAmount;
	}
	public String getAmrmCommitAmount() {
		return amrmCommitAmount;
	}
	public void setAmrmCommitAmount(String amrmCommitAmount) {
		this.amrmCommitAmount = amrmCommitAmount;
	}
	public String getAmedewsBlockCode() {
		return amedewsBlockCode;
	}
	public void setAmedewsBlockCode(String amedewsBlockCode) {
		this.amedewsBlockCode = amedewsBlockCode;
	}
	public String getAmbsewsBlockCode1() {
		return ambsewsBlockCode1;
	}
	public void setAmbsewsBlockCode1(String ambsewsBlockCode1) {
		this.ambsewsBlockCode1 = ambsewsBlockCode1;
	}
	public String getAmbsewsBlockCode2() {
		return ambsewsBlockCode2;
	}
	public void setAmbsewsBlockCode2(String ambsewsBlockCode2) {
		this.ambsewsBlockCode2 = ambsewsBlockCode2;
	}
	public String getAmrmewsBlockCode() {
		return amrmewsBlockCode;
	}
	public void setAmrmewsBlockCode(String amrmewsBlockCode) {
		this.amrmewsBlockCode = amrmewsBlockCode;
	}
	public String getEwsRiskLevel() {
		return ewsRiskLevel;
	}
	public void setEwsRiskLevel(String ewsRiskLevel) {
		this.ewsRiskLevel = ewsRiskLevel;
	}
	public String getEwsActivationInd() {
		return ewsActivationInd;
	}
	public void setEwsActivationInd(String ewsActivationInd) {
		this.ewsActivationInd = ewsActivationInd;
	}
	public String getEwsActivationDate() {
		return ewsActivationDate;
	}
	public void setEwsActivationDate(String ewsActivationDate) {
		this.ewsActivationDate = ewsActivationDate;
	}
	public String getEwsbsScore() {
		return ewsbsScore;
	}
	public void setEwsbsScore(String ewsbsScore) {
		this.ewsbsScore = ewsbsScore;
	}
	public String getEwsAmountAuthToday() {
		return ewsAmountAuthToday;
	}
	public void setEwsAmountAuthToday(String ewsAmountAuthToday) {
		this.ewsAmountAuthToday = ewsAmountAuthToday;
	}
	public String getDailyRTLNumber() {
		return dailyRTLNumber;
	}
	public void setDailyRTLNumber(String dailyRTLNumber) {
		this.dailyRTLNumber = dailyRTLNumber;
	}
	public String getDailyRTLAmount() {
		return dailyRTLAmount;
	}
	public void setDailyRTLAmount(String dailyRTLAmount) {
		this.dailyRTLAmount = dailyRTLAmount;
	}
	public String getDailyCashNumber() {
		return dailyCashNumber;
	}
	public void setDailyCashNumber(String dailyCashNumber) {
		this.dailyCashNumber = dailyCashNumber;
	}
	public String getDailyCashAmount() {
		return dailyCashAmount;
	}
	public void setDailyCashAmount(String dailyCashAmount) {
		this.dailyCashAmount = dailyCashAmount;
	}
	public String getDailyMCCNumber() {
		return dailyMCCNumber;
	}
	public void setDailyMCCNumber(String dailyMCCNumber) {
		this.dailyMCCNumber = dailyMCCNumber;
	}
	public String getDailyMCCAmount() {
		return dailyMCCAmount;
	}
	public void setDailyMCCAmount(String dailyMCCAmount) {
		this.dailyMCCAmount = dailyMCCAmount;
	}
	public String getxDaysRTLNumber() {
		return xDaysRTLNumber;
	}
	public void setxDaysRTLNumber(String xDaysRTLNumber) {
		this.xDaysRTLNumber = xDaysRTLNumber;
	}
	public String getxDaysRTLAmount() {
		return xDaysRTLAmount;
	}
	public void setxDaysRTLAmount(String xDaysRTLAmount) {
		this.xDaysRTLAmount = xDaysRTLAmount;
	}
	public String getxDaysCashNumber() {
		return xDaysCashNumber;
	}
	public void setxDaysCashNumber(String xDaysCashNumber) {
		this.xDaysCashNumber = xDaysCashNumber;
	}
	public String getxDaysCashAmount() {
		return xDaysCashAmount;
	}
	public void setxDaysCashAmount(String xDaysCashAmount) {
		this.xDaysCashAmount = xDaysCashAmount;
	}
	public String getxDaysMCCAmount() {
		return xDaysMCCAmount;
	}
	public void setxDaysMCCAmount(String xDaysMCCAmount) {
		this.xDaysMCCAmount = xDaysMCCAmount;
	}
	public String getDeclRSN() {
		return declRSN;
	}
	public void setDeclRSN(String declRSN) {
		this.declRSN = declRSN;
	}
	public String getMatchedInd() {
		return matchedInd;
	}
	public void setMatchedInd(String matchedInd) {
		this.matchedInd = matchedInd;
	}
	public String getAuthorisationClass() {
		return authorisationClass;
	}
	public void setAuthorisationClass(String authorisationClass) {
		this.authorisationClass = authorisationClass;
	}
	public String getAmbsAccount() {
		return ambsAccount;
	}
	public void setAmbsAccount(String ambsAccount) {
		this.ambsAccount = ambsAccount;
	}
	public String getAmrmRelOrg() {
		return amrmRelOrg;
	}
	public void setAmrmRelOrg(String amrmRelOrg) {
		this.amrmRelOrg = amrmRelOrg;
	}
	public String getAmrmRelNumber() {
		return amrmRelNumber;
	}
	public void setAmrmRelNumber(String amrmRelNumber) {
		this.amrmRelNumber = amrmRelNumber;
	}
	public String getBlockRSNAMED() {
		return blockRSNAMED;
	}
	public void setBlockRSNAMED(String blockRSNAMED) {
		this.blockRSNAMED = blockRSNAMED;
	}
	public String getBlockRSNAMBS1() {
		return blockRSNAMBS1;
	}
	public void setBlockRSNAMBS1(String blockRSNAMBS1) {
		this.blockRSNAMBS1 = blockRSNAMBS1;
	}
	public String getBlockRSNAMBS2() {
		return blockRSNAMBS2;
	}
	public void setBlockRSNAMBS2(String blockRSNAMBS2) {
		this.blockRSNAMBS2 = blockRSNAMBS2;
	}
	public String getAmbsDateOpened() {
		return ambsDateOpened;
	}
	public void setAmbsDateOpened(String ambsDateOpened) {
		this.ambsDateOpened = ambsDateOpened;
	}
	public String getInvalidPinTries() {
		return invalidPinTries;
	}
	public void setInvalidPinTries(String invalidPinTries) {
		this.invalidPinTries = invalidPinTries;
	}
	public String getClogRecType() {
		return clogRecType;
	}
	public void setClogRecType(String clogRecType) {
		this.clogRecType = clogRecType;
	}
	public String getFiSpid() {
		return fiSpid;
	}
	public void setFiSpid(String fiSpid) {
		this.fiSpid = fiSpid;
	}
	public String getFiTestDigits() {
		return fiTestDigits;
	}
	public void setFiTestDigits(String fiTestDigits) {
		this.fiTestDigits = fiTestDigits;
	}
	public String getFiAuthDigitGroup() {
		return fiAuthDigitGroup;
	}
	public void setFiAuthDigitGroup(String fiAuthDigitGroup) {
		this.fiAuthDigitGroup = fiAuthDigitGroup;
	}
	public String getFiAuthStragegyID() {
		return fiAuthStragegyID;
	}
	public void setFiAuthStragegyID(String fiAuthStragegyID) {
		this.fiAuthStragegyID = fiAuthStragegyID;
	}
	public String getClogAuthReport() {
		return clogAuthReport;
	}
	public void setClogAuthReport(String clogAuthReport) {
		this.clogAuthReport = clogAuthReport;
	}
	public String getClogAuthDecision() {
		return clogAuthDecision;
	}
	public void setClogAuthDecision(String clogAuthDecision) {
		this.clogAuthDecision = clogAuthDecision;
	}
	public String getPmtCycleDue() {
		return pmtCycleDue;
	}
	public void setPmtCycleDue(String pmtCycleDue) {
		this.pmtCycleDue = pmtCycleDue;
	}
	public String getClogTransType() {
		return clogTransType;
	}
	public void setClogTransType(String clogTransType) {
		this.clogTransType = clogTransType;
	}
	public String getAmtCTDCash() {
		return amtCTDCash;
	}
	public void setAmtCTDCash(String amtCTDCash) {
		this.amtCTDCash = amtCTDCash;
	}
	public String getCashCRLIM() {
		return cashCRLIM;
	}
	public void setCashCRLIM(String cashCRLIM) {
		this.cashCRLIM = cashCRLIM;
	}
	public String getClogAmountOutStd() {
		return clogAmountOutStd;
	}
	public void setClogAmountOutStd(String clogAmountOutStd) {
		this.clogAmountOutStd = clogAmountOutStd;
	}
	public String getIccInstId() {
		return iccInstId;
	}
	public void setIccInstId(String iccInstId) {
		this.iccInstId = iccInstId;
	}
	public String getIccissNetwID() {
		return iccissNetwID;
	}
	public void setIccissNetwID(String iccissNetwID) {
		this.iccissNetwID = iccissNetwID;
	}
	public String getIccAcqNetwID() {
		return iccAcqNetwID;
	}
	public void setIccAcqNetwID(String iccAcqNetwID) {
		this.iccAcqNetwID = iccAcqNetwID;
	}
	public String getFiCurrBehaviorScore() {
		return fiCurrBehaviorScore;
	}
	public void setFiCurrBehaviorScore(String fiCurrBehaviorScore) {
		this.fiCurrBehaviorScore = fiCurrBehaviorScore;
	}
	public String getFiAuthScnID() {
		return fiAuthScnID;
	}
	public void setFiAuthScnID(String fiAuthScnID) {
		this.fiAuthScnID = fiAuthScnID;
	}
	public String getFraudCPInd() {
		return fraudCPInd;
	}
	public void setFraudCPInd(String fraudCPInd) {
		this.fraudCPInd = fraudCPInd;
	}
	public String getFraudOrigPosEntry() {
		return fraudOrigPosEntry;
	}
	public void setFraudOrigPosEntry(String fraudOrigPosEntry) {
		this.fraudOrigPosEntry = fraudOrigPosEntry;
	}
	public String getRecurringInd() {
		return recurringInd;
	}
	public void setRecurringInd(String recurringInd) {
		this.recurringInd = recurringInd;
	}
	public String getInstlInd() {
		return instlInd;
	}
	public void setInstlInd(String instlInd) {
		this.instlInd = instlInd;
	}
	public String getUtilityInd() {
		return utilityInd;
	}
	public void setUtilityInd(String utilityInd) {
		this.utilityInd = utilityInd;
	}
	public String getMotoInd() {
		return motoInd;
	}
	public void setMotoInd(String motoInd) {
		this.motoInd = motoInd;
	}
	public String getCallCardInd() {
		return callCardInd;
	}
	public void setCallCardInd(String callCardInd) {
		this.callCardInd = callCardInd;
	}
	public String getAtiaOrgNumber() {
		return atiaOrgNumber;
	}
	public void setAtiaOrgNumber(String atiaOrgNumber) {
		this.atiaOrgNumber = atiaOrgNumber;
	}
	public String getLocalCurrencyCode() {
		return localCurrencyCode;
	}
	public void setLocalCurrencyCode(String localCurrencyCode) {
		this.localCurrencyCode = localCurrencyCode;
	}
	public String getAtiaAuthAmount() {
		return atiaAuthAmount;
	}
	public void setAtiaAuthAmount(String atiaAuthAmount) {
		this.atiaAuthAmount = atiaAuthAmount;
	}
	public String getOrigTypeMessageId() {
		return origTypeMessageId;
	}
	public void setOrigTypeMessageId(String origTypeMessageId) {
		this.origTypeMessageId = origTypeMessageId;
	}
	public String getJetcoAcqBin() {
		return jetcoAcqBin;
	}
	public void setJetcoAcqBin(String jetcoAcqBin) {
		this.jetcoAcqBin = jetcoAcqBin;
	}
	public String getOdlyCashAmount() {
		return odlyCashAmount;
	}
	public void setOdlyCashAmount(String odlyCashAmount) {
		this.odlyCashAmount = odlyCashAmount;
	}
	public String getOmlyCashAmount() {
		return omlyCashAmount;
	}
	public void setOmlyCashAmount(String omlyCashAmount) {
		this.omlyCashAmount = omlyCashAmount;
	}
	public String getMonth6CashAmount() {
		return month6CashAmount;
	}
	public void setMonth6CashAmount(String month6CashAmount) {
		this.month6CashAmount = month6CashAmount;
	}
	public String getMonth12CashAmount() {
		return month12CashAmount;
	}
	public void setMonth12CashAmount(String month12CashAmount) {
		this.month12CashAmount = month12CashAmount;
	}
	public String getExchangeTxn() {
		return exchangeTxn;
	}
	public void setExchangeTxn(String exchangeTxn) {
		this.exchangeTxn = exchangeTxn;
	}
	public String getOvsPurchaseLimit() {
		return ovsPurchaseLimit;
	}
	public void setOvsPurchaseLimit(String ovsPurchaseLimit) {
		this.ovsPurchaseLimit = ovsPurchaseLimit;
	}
	public String getOvsPurchaseAvail() {
		return ovsPurchaseAvail;
	}
	public void setOvsPurchaseAvail(String ovsPurchaseAvail) {
		this.ovsPurchaseAvail = ovsPurchaseAvail;
	}
	public String getOvsCashLimit() {
		return ovsCashLimit;
	}
	public void setOvsCashLimit(String ovsCashLimit) {
		this.ovsCashLimit = ovsCashLimit;
	}
	public String getOvsInternetLimit() {
		return ovsInternetLimit;
	}
	public void setOvsInternetLimit(String ovsInternetLimit) {
		this.ovsInternetLimit = ovsInternetLimit;
	}
	public String getOvsInternetAvail() {
		return ovsInternetAvail;
	}
	public void setOvsInternetAvail(String ovsInternetAvail) {
		this.ovsInternetAvail = ovsInternetAvail;
	}
	public String getAmbsCashAvail() {
		return ambsCashAvail;
	}
	public void setAmbsCashAvail(String ambsCashAvail) {
		this.ambsCashAvail = ambsCashAvail;
	}
	public String getAmedCashAvail() {
		return amedCashAvail;
	}
	public void setAmedCashAvail(String amedCashAvail) {
		this.amedCashAvail = amedCashAvail;
	}
	public String getAmedPostToAcc() {
		return amedPostToAcc;
	}
	public void setAmedPostToAcc(String amedPostToAcc) {
		this.amedPostToAcc = amedPostToAcc;
	}
	public String getIcccbaFlag() {
		return icccbaFlag;
	}
	public void setIcccbaFlag(String icccbaFlag) {
		this.icccbaFlag = icccbaFlag;
	}
	public String getCcaSettlementFee() {
		return ccaSettlementFee;
	}
	public void setCcaSettlementFee(String ccaSettlementFee) {
		this.ccaSettlementFee = ccaSettlementFee;
	}
	public String getMasterDebitOrg() {
		return masterDebitOrg;
	}
	public void setMasterDebitOrg(String masterDebitOrg) {
		this.masterDebitOrg = masterDebitOrg;
	}
	public String getMasterDebitType() {
		return masterDebitType;
	}
	public void setMasterDebitType(String masterDebitType) {
		this.masterDebitType = masterDebitType;
	}
	public String getMasterDebitAcct() {
		return masterDebitAcct;
	}
	public void setMasterDebitAcct(String masterDebitAcct) {
		this.masterDebitAcct = masterDebitAcct;
	}
	public String getMasterDebitRiskLevel() {
		return masterDebitRiskLevel;
	}
	public void setMasterDebitRiskLevel(String masterDebitRiskLevel) {
		this.masterDebitRiskLevel = masterDebitRiskLevel;
	}
	public String getMasterDebitCardInd() {
		return masterDebitCardInd;
	}
	public void setMasterDebitCardInd(String masterDebitCardInd) {
		this.masterDebitCardInd = masterDebitCardInd;
	}
	public String getMasterDebitTipAmt() {
		return masterDebitTipAmt;
	}
	public void setMasterDebitTipAmt(String masterDebitTipAmt) {
		this.masterDebitTipAmt = masterDebitTipAmt;
	}
	public String getAfewsOnlineMode() {
		return afewsOnlineMode;
	}
	public void setAfewsOnlineMode(String afewsOnlineMode) {
		this.afewsOnlineMode = afewsOnlineMode;
	}
	public String getAfewsOnlineRC1() {
		return afewsOnlineRC1;
	}
	public void setAfewsOnlineRC1(String afewsOnlineRC1) {
		this.afewsOnlineRC1 = afewsOnlineRC1;
	}
	public String getRefrlQSTN1() {
		return refrlQSTN1;
	}
	public void setRefrlQSTN1(String refrlQSTN1) {
		this.refrlQSTN1 = refrlQSTN1;
	}
	public String getRefrlQSTN2() {
		return refrlQSTN2;
	}
	public void setRefrlQSTN2(String refrlQSTN2) {
		this.refrlQSTN2 = refrlQSTN2;
	}
	public String getRefrlQSTN3() {
		return refrlQSTN3;
	}
	public void setRefrlQSTN3(String refrlQSTN3) {
		this.refrlQSTN3 = refrlQSTN3;
	}
	public String getGlobalCountryCode() {
		return globalCountryCode;
	}
	public void setGlobalCountryCode(String globalCountryCode) {
		this.globalCountryCode = globalCountryCode;
	}
	public String getAfewsFalconDSCN() {
		return afewsFalconDSCN;
	}
	public void setAfewsFalconDSCN(String afewsFalconDSCN) {
		this.afewsFalconDSCN = afewsFalconDSCN;
	}
	public String getMasterInvCVC2() {
		return masterInvCVC2;
	}
	public void setMasterInvCVC2(String masterInvCVC2) {
		this.masterInvCVC2 = masterInvCVC2;
	}
	public String getMasterPOSCondCode() {
		return masterPOSCondCode;
	}
	public void setMasterPOSCondCode(String masterPOSCondCode) {
		this.masterPOSCondCode = masterPOSCondCode;
	}
	public String getMasterFNCLCode() {
		return masterFNCLCode;
	}
	public void setMasterFNCLCode(String masterFNCLCode) {
		this.masterFNCLCode = masterFNCLCode;
	}
	public String getMasterBNKNTREFNumber() {
		return masterBNKNTREFNumber;
	}
	public void setMasterBNKNTREFNumber(String masterBNKNTREFNumber) {
		this.masterBNKNTREFNumber = masterBNKNTREFNumber;
	}
	public String getDinersSYSTrace() {
		return dinersSYSTrace;
	}
	public void setDinersSYSTrace(String dinersSYSTrace) {
		this.dinersSYSTrace = dinersSYSTrace;
	}
	public String getIsoRespCode() {
		return isoRespCode;
	}
	public void setIsoRespCode(String isoRespCode) {
		this.isoRespCode = isoRespCode;
	}
	public String getCardRespCode() {
		return cardRespCode;
	}
	public void setCardRespCode(String cardRespCode) {
		this.cardRespCode = cardRespCode;
	}
	public String getDinersCVVInd() {
		return dinersCVVInd;
	}
	public void setDinersCVVInd(String dinersCVVInd) {
		this.dinersCVVInd = dinersCVVInd;
	}
	public String getDinersDupInd() {
		return dinersDupInd;
	}
	public void setDinersDupInd(String dinersDupInd) {
		this.dinersDupInd = dinersDupInd;
	}
	public String getDinersRecurInd() {
		return dinersRecurInd;
	}
	public void setDinersRecurInd(String dinersRecurInd) {
		this.dinersRecurInd = dinersRecurInd;
	}
	public String getEppTenor() {
		return eppTenor;
	}
	public void setEppTenor(String eppTenor) {
		this.eppTenor = eppTenor;
	}
	public String getEppPromoId() {
		return eppPromoId;
	}
	public void setEppPromoId(String eppPromoId) {
		this.eppPromoId = eppPromoId;
	}
	public String getAltOrgId() {
		return altOrgId;
	}
	public void setAltOrgId(String altOrgId) {
		this.altOrgId = altOrgId;
	}
	public String getAmexTCType() {
		return amexTCType;
	}
	public void setAmexTCType(String amexTCType) {
		this.amexTCType = amexTCType;
	}
	public String getAmexResCode() {
		return amexResCode;
	}
	public void setAmexResCode(String amexResCode) {
		this.amexResCode = amexResCode;
	}
	public String getAmexISOResCode() {
		return amexISOResCode;
	}
	public void setAmexISOResCode(String amexISOResCode) {
		this.amexISOResCode = amexISOResCode;
	}
	public String getAmexLclTxnDTTime() {
		return amexLclTxnDTTime;
	}
	public void setAmexLclTxnDTTime(String amexLclTxnDTTime) {
		this.amexLclTxnDTTime = amexLclTxnDTTime;
	}
	public String getAmexEffDate() {
		return amexEffDate;
	}
	public void setAmexEffDate(String amexEffDate) {
		this.amexEffDate = amexEffDate;
	}
	public String getAmexPosDataCode() {
		return amexPosDataCode;
	}
	public void setAmexPosDataCode(String amexPosDataCode) {
		this.amexPosDataCode = amexPosDataCode;
	}
	public String getAmexFunCode() {
		return amexFunCode;
	}
	public void setAmexFunCode(String amexFunCode) {
		this.amexFunCode = amexFunCode;
	}
	public String getAmexMsgRsnCode() {
		return amexMsgRsnCode;
	}
	public void setAmexMsgRsnCode(String amexMsgRsnCode) {
		this.amexMsgRsnCode = amexMsgRsnCode;
	}
	public String getAmexCardBusCode() {
		return amexCardBusCode;
	}
	public void setAmexCardBusCode(String amexCardBusCode) {
		this.amexCardBusCode = amexCardBusCode;
	}
	public String getAmexOrigAmntData01To12() {
		return amexOrigAmntData01To12;
	}
	public void setAmexOrigAmntData01To12(String amexOrigAmntData01To12) {
		this.amexOrigAmntData01To12 = amexOrigAmntData01To12;
	}
	public String getAmexOrigAmntData13To24() {
		return amexOrigAmntData13To24;
	}
	public void setAmexOrigAmntData13To24(String amexOrigAmntData13To24) {
		this.amexOrigAmntData13To24 = amexOrigAmntData13To24;
	}
	public String getAmexAcqRefNbr() {
		return amexAcqRefNbr;
	}
	public void setAmexAcqRefNbr(String amexAcqRefNbr) {
		this.amexAcqRefNbr = amexAcqRefNbr;
	}
	public String getAmexActionCode() {
		return amexActionCode;
	}
	public void setAmexActionCode(String amexActionCode) {
		this.amexActionCode = amexActionCode;
	}
	public String getAmexCardAcceptName() {
		return amexCardAcceptName;
	}
	public void setAmexCardAcceptName(String amexCardAcceptName) {
		this.amexCardAcceptName = amexCardAcceptName;
	}
	public String getAmexAdtlResLen() {
		return amexAdtlResLen;
	}
	public void setAmexAdtlResLen(String amexAdtlResLen) {
		this.amexAdtlResLen = amexAdtlResLen;
	}
	public String getAmexAdtlResDat() {
		return amexAdtlResDat;
	}
	public void setAmexAdtlResDat(String amexAdtlResDat) {
		this.amexAdtlResDat = amexAdtlResDat;
	}
	public String getAmexAvsResult() {
		return amexAvsResult;
	}
	public void setAmexAvsResult(String amexAvsResult) {
		this.amexAvsResult = amexAvsResult;
	}
	public String getAmexSecCtlResult() {
		return amexSecCtlResult;
	}
	public void setAmexSecCtlResult(String amexSecCtlResult) {
		this.amexSecCtlResult = amexSecCtlResult;
	}
	public String getAmexAdtlDataLen() {
		return amexAdtlDataLen;
	}
	public void setAmexAdtlDataLen(String amexAdtlDataLen) {
		this.amexAdtlDataLen = amexAdtlDataLen;
	}
	public String getAmexAdtlData() {
		return amexAdtlData;
	}
	public void setAmexAdtlData(String amexAdtlData) {
		this.amexAdtlData = amexAdtlData;
	}
	public String getAmexStipendSent() {
		return amexStipendSent;
	}
	public void setAmexStipendSent(String amexStipendSent) {
		this.amexStipendSent = amexStipendSent;
	}
	public String getAmexStipendParm() {
		return amexStipendParm;
	}
	public void setAmexStipendParm(String amexStipendParm) {
		this.amexStipendParm = amexStipendParm;
	}
	public String getAmexStipendSeType() {
		return amexStipendSeType;
	}
	public void setAmexStipendSeType(String amexStipendSeType) {
		this.amexStipendSeType = amexStipendSeType;
	}
	public String getAmexStipendMerType() {
		return amexStipendMerType;
	}
	public void setAmexStipendMerType(String amexStipendMerType) {
		this.amexStipendMerType = amexStipendMerType;
	}
	public String getAmexStipendHstIndi() {
		return amexStipendHstIndi;
	}
	public void setAmexStipendHstIndi(String amexStipendHstIndi) {
		this.amexStipendHstIndi = amexStipendHstIndi;
	}
	public String getAmexStiprSent() {
		return amexStiprSent;
	}
	public void setAmexStiprSent(String amexStiprSent) {
		this.amexStiprSent = amexStiprSent;
	}
	public String getAmexStiprParm() {
		return amexStiprParm;
	}
	public void setAmexStiprParm(String amexStiprParm) {
		this.amexStiprParm = amexStiprParm;
	}
	public String getAmexOrigDataLen() {
		return amexOrigDataLen;
	}
	public void setAmexOrigDataLen(String amexOrigDataLen) {
		this.amexOrigDataLen = amexOrigDataLen;
	}
	public String getAmexODMsgType() {
		return amexODMsgType;
	}
	public void setAmexODMsgType(String amexODMsgType) {
		this.amexODMsgType = amexODMsgType;
	}
	public String getAmexODSysTrace() {
		return amexODSysTrace;
	}
	public void setAmexODSysTrace(String amexODSysTrace) {
		this.amexODSysTrace = amexODSysTrace;
	}
	public String getAmexODLclDateTime() {
		return amexODLclDateTime;
	}
	public void setAmexODLclDateTime(String amexODLclDateTime) {
		this.amexODLclDateTime = amexODLclDateTime;
	}
	public String getAmexODAcqId() {
		return amexODAcqId;
	}
	public void setAmexODAcqId(String amexODAcqId) {
		this.amexODAcqId = amexODAcqId;
	}
	public String getAmexVli() {
		return amexVli;
	}
	public void setAmexVli(String amexVli) {
		this.amexVli = amexVli;
	}
	public String getAmexPriId() {
		return amexPriId;
	}
	public void setAmexPriId(String amexPriId) {
		this.amexPriId = amexPriId;
	}
	public String getAmexSecId() {
		return amexSecId;
	}
	public void setAmexSecId(String amexSecId) {
		this.amexSecId = amexSecId;
	}
	public String getAmexEci() {
		return amexEci;
	}
	public void setAmexEci(String amexEci) {
		this.amexEci = amexEci;
	}
	public String getAmexAevvRstl() {
		return amexAevvRstl;
	}
	public void setAmexAevvRstl(String amexAevvRstl) {
		this.amexAevvRstl = amexAevvRstl;
	}
	public String getAmexAevvId() {
		return amexAevvId;
	}
	public void setAmexAevvId(String amexAevvId) {
		this.amexAevvId = amexAevvId;
	}
	public String getAmexSub1() {
		return amexSub1;
	}
	public void setAmexSub1(String amexSub1) {
		this.amexSub1 = amexSub1;
	}
	public String getAmexSub2() {
		return amexSub2;
	}
	public void setAmexSub2(String amexSub2) {
		this.amexSub2 = amexSub2;
	}
	public String getXid() {
		return xid;
	}
	public void setXid(String xid) {
		this.xid = xid;
	}
	public String getXidValue() {
		return xidValue;
	}
	public void setXidValue(String xidValue) {
		this.xidValue = xidValue;
	}
	public String getAmexFraudIndLen() {
		return amexFraudIndLen;
	}
	public void setAmexFraudIndLen(String amexFraudIndLen) {
		this.amexFraudIndLen = amexFraudIndLen;
	}
	public String getAmexFraudInd() {
		return amexFraudInd;
	}
	public void setAmexFraudInd(String amexFraudInd) {
		this.amexFraudInd = amexFraudInd;
	}
	public String getAmexPrivUseLen() {
		return amexPrivUseLen;
	}
	public void setAmexPrivUseLen(String amexPrivUseLen) {
		this.amexPrivUseLen = amexPrivUseLen;
	}
	public String getAmexPrivUseData() {
		return amexPrivUseData;
	}
	public void setAmexPrivUseData(String amexPrivUseData) {
		this.amexPrivUseData = amexPrivUseData;
	}
	public String getAmexEadSvcId() {
		return amexEadSvcId;
	}
	public void setAmexEadSvcId(String amexEadSvcId) {
		this.amexEadSvcId = amexEadSvcId;
	}
	public String getAmexEadReq() {
		return amexEadReq;
	}
	public void setAmexEadReq(String amexEadReq) {
		this.amexEadReq = amexEadReq;
	}
	public String getAmexEadPostlCd() {
		return amexEadPostlCd;
	}
	public void setAmexEadPostlCd(String amexEadPostlCd) {
		this.amexEadPostlCd = amexEadPostlCd;
	}
	public String getAmexEadAddrNbrs() {
		return amexEadAddrNbrs;
	}
	public void setAmexEadAddrNbrs(String amexEadAddrNbrs) {
		this.amexEadAddrNbrs = amexEadAddrNbrs;
	}
	public String getAmexOptionalDataLen() {
		return amexOptionalDataLen;
	}
	public void setAmexOptionalDataLen(String amexOptionalDataLen) {
		this.amexOptionalDataLen = amexOptionalDataLen;
	}
	public String getAmexOptionalData() {
		return amexOptionalData;
	}
	public void setAmexOptionalData(String amexOptionalData) {
		this.amexOptionalData = amexOptionalData;
	}
	public String getAmexOptional01To30() {
		return amexOptional01To30;
	}
	public void setAmexOptional01To30(String amexOptional01To30) {
		this.amexOptional01To30 = amexOptional01To30;
	}
	public String getAmexOptional31To60() {
		return amexOptional31To60;
	}
	public void setAmexOptional31To60(String amexOptional31To60) {
		this.amexOptional31To60 = amexOptional31To60;
	}
	public String getAmexAdtlData2() {
		return amexAdtlData2;
	}
	public void setAmexAdtlData2(String amexAdtlData2) {
		this.amexAdtlData2 = amexAdtlData2;
	}
	public String getAuthAdtlDataLen() {
		return authAdtlDataLen;
	}
	public void setAuthAdtlDataLen(String authAdtlDataLen) {
		this.authAdtlDataLen = authAdtlDataLen;
	}
	public String getAmexIccVerHdrName() {
		return amexIccVerHdrName;
	}
	public void setAmexIccVerHdrName(String amexIccVerHdrName) {
		this.amexIccVerHdrName = amexIccVerHdrName;
	}
	public String getAmexIccVerHdrNbr() {
		return amexIccVerHdrNbr;
	}
	public void setAmexIccVerHdrNbr(String amexIccVerHdrNbr) {
		this.amexIccVerHdrNbr = amexIccVerHdrNbr;
	}
	public String getAmexApplCrytData() {
		return amexApplCrytData;
	}
	public void setAmexApplCrytData(String amexApplCrytData) {
		this.amexApplCrytData = amexApplCrytData;
	}
	public String getAmexIssApplLng() {
		return amexIssApplLng;
	}
	public void setAmexIssApplLng(String amexIssApplLng) {
		this.amexIssApplLng = amexIssApplLng;
	}
	public String getAmexIssApplData() {
		return amexIssApplData;
	}
	public void setAmexIssApplData(String amexIssApplData) {
		this.amexIssApplData = amexIssApplData;
	}
	public String getAmexUnpredNbr() {
		return amexUnpredNbr;
	}
	public void setAmexUnpredNbr(String amexUnpredNbr) {
		this.amexUnpredNbr = amexUnpredNbr;
	}
	public String getAmexAppTranCntr() {
		return amexAppTranCntr;
	}
	public void setAmexAppTranCntr(String amexAppTranCntr) {
		this.amexAppTranCntr = amexAppTranCntr;
	}
	public String getAmexTvrData() {
		return amexTvrData;
	}
	public void setAmexTvrData(String amexTvrData) {
		this.amexTvrData = amexTvrData;
	}
	public String getAmexTranDate() {
		return amexTranDate;
	}
	public void setAmexTranDate(String amexTranDate) {
		this.amexTranDate = amexTranDate;
	}
	public String getAmexTranType() {
		return amexTranType;
	}
	public void setAmexTranType(String amexTranType) {
		this.amexTranType = amexTranType;
	}
	public String getAmexAmtAuth() {
		return amexAmtAuth;
	}
	public void setAmexAmtAuth(String amexAmtAuth) {
		this.amexAmtAuth = amexAmtAuth;
	}
	public String getAmexTranCurrCode() {
		return amexTranCurrCode;
	}
	public void setAmexTranCurrCode(String amexTranCurrCode) {
		this.amexTranCurrCode = amexTranCurrCode;
	}
	public String getAmexTermCntryCd() {
		return amexTermCntryCd;
	}
	public void setAmexTermCntryCd(String amexTermCntryCd) {
		this.amexTermCntryCd = amexTermCntryCd;
	}
	public String getAmexAppIntrData() {
		return amexAppIntrData;
	}
	public void setAmexAppIntrData(String amexAppIntrData) {
		this.amexAppIntrData = amexAppIntrData;
	}
	public String getAmexAmtOth() {
		return amexAmtOth;
	}
	public void setAmexAmtOth(String amexAmtOth) {
		this.amexAmtOth = amexAmtOth;
	}
	public String getAmexPanSeqNbr() {
		return amexPanSeqNbr;
	}
	public void setAmexPanSeqNbr(String amexPanSeqNbr) {
		this.amexPanSeqNbr = amexPanSeqNbr;
	}
	public String getAmexCrytInfoDat() {
		return amexCrytInfoDat;
	}
	public void setAmexCrytInfoDat(String amexCrytInfoDat) {
		this.amexCrytInfoDat = amexCrytInfoDat;
	}
	public String getAmexRspAuthTag() {
		return amexRspAuthTag;
	}
	public void setAmexRspAuthTag(String amexRspAuthTag) {
		this.amexRspAuthTag = amexRspAuthTag;
	}
	public String getAmexRspAuthlen() {
		return amexRspAuthlen;
	}
	public void setAmexRspAuthlen(String amexRspAuthlen) {
		this.amexRspAuthlen = amexRspAuthlen;
	}
	public String getAmexRspAuthData() {
		return amexRspAuthData;
	}
	public void setAmexRspAuthData(String amexRspAuthData) {
		this.amexRspAuthData = amexRspAuthData;
	}
	public String getAmexRspScriptTag() {
		return amexRspScriptTag;
	}
	public void setAmexRspScriptTag(String amexRspScriptTag) {
		this.amexRspScriptTag = amexRspScriptTag;
	}
	public String getAmexRspScriptLen() {
		return amexRspScriptLen;
	}
	public void setAmexRspScriptLen(String amexRspScriptLen) {
		this.amexRspScriptLen = amexRspScriptLen;
	}
	public String getAmexRspScriptData() {
		return amexRspScriptData;
	}
	public void setAmexRspScriptData(String amexRspScriptData) {
		this.amexRspScriptData = amexRspScriptData;
	}
	public String getPinVerifyIndicator() {
		return pinVerifyIndicator;
	}
	public void setPinVerifyIndicator(String pinVerifyIndicator) {
		this.pinVerifyIndicator = pinVerifyIndicator;
	}
	public String getAfewsTransactionType() {
		return afewsTransactionType;
	}
	public void setAfewsTransactionType(String afewsTransactionType) {
		this.afewsTransactionType = afewsTransactionType;
	}
	public String getNfcAssociatedFlag() {
		return nfcAssociatedFlag;
	}
	public void setNfcAssociatedFlag(String nfcAssociatedFlag) {
		this.nfcAssociatedFlag = nfcAssociatedFlag;
	}
	public String getTransactionChannelType() {
		return transactionChannelType;
	}
	public void setTransactionChannelType(String transactionChannelType) {
		this.transactionChannelType = transactionChannelType;
	}
	public String getTransactionOriginID() {
		return transactionOriginID;
	}
	public void setTransactionOriginID(String transactionOriginID) {
		this.transactionOriginID = transactionOriginID;
	}
	public String getCupCheck() {
		return cupCheck;
	}
	public void setCupCheck(String cupCheck) {
		this.cupCheck = cupCheck;
	}
	public String getCupTaxID() {
		return cupTaxID;
	}
	public void setCupTaxID(String cupTaxID) {
		this.cupTaxID = cupTaxID;
	}
	public String getSafetyNetIndicator() {
		return safetyNetIndicator;
	}
	public void setSafetyNetIndicator(String safetyNetIndicator) {
		this.safetyNetIndicator = safetyNetIndicator;
	}
	public String getTransactionStatus() {
		return transactionStatus;
	}
	public void setTransactionStatus(String transactionStatus) {
		this.transactionStatus = transactionStatus;
	}
	public Double getTransactionAmount() {
		return transactionAmount;
	}
	public void setTransactionAmount(Double transactionAmount) {
		this.transactionAmount = transactionAmount;
	}
	public String getTransactionCurrencyCode() {
		return transactionCurrencyCode;
	}
	public void setTransactionCurrencyCode(String transactionCurrencyCode) {
		this.transactionCurrencyCode = transactionCurrencyCode;
	}
	public String getTransactionDate() {
		return transactionDate;
	}
	public void setTransactionDate(String string) {
		this.transactionDate = string;
	}
	public String getTransactionTime() {
		return transactionTime;
	}
	public void setTransactionTime(String string) {
		this.transactionTime = string;
	}
	public String getTransactionChannel() {
		return transactionChannel;
	}
	public void setTransactionChannel(String transactionChannel) {
		this.transactionChannel = transactionChannel;
	}
	public String getTransactionType() {
		return transactionType;
	}
	public void setTransactionType(String transactionType) {
		this.transactionType = transactionType;
	}
	public String getCreditOrDebitIndicator() {
		return creditOrDebitIndicator;
	}
	public void setCreditOrDebitIndicator(String creditOrDebitIndicator) {
		this.creditOrDebitIndicator = creditOrDebitIndicator;
	}
	public String getTransactionCode() {
		return transactionCode;
	}
	public void setTransactionCode(String transactionCode) {
		this.transactionCode = transactionCode;
	}
	public String getGrbCustomerNumber() {
		return grbCustomerNumber;
	}
	public void setGrbCustomerNumber(String grbCustomerNumber) {
		this.grbCustomerNumber = grbCustomerNumber;
	}
	public String getGrbRelationshipNumber() {
		return grbRelationshipNumber;
	}
	public void setGrbRelationshipNumber(String grbRelationshipNumber) {
		this.grbRelationshipNumber = grbRelationshipNumber;
	}
	public String getTransactionCountry() {
		return transactionCountry;
	}
	public void setTransactionCountry(String transactionCountry) {
		this.transactionCountry = transactionCountry;
	}
	public String getTransactionState() {
		return transactionState;
	}
	public void setTransactionState(String transactionState) {
		this.transactionState = transactionState;
	}
	public String getTransactionCity() {
		return transactionCity;
	}
	public void setTransactionCity(String transactionCity) {
		this.transactionCity = transactionCity;
	}
	public String getDeclineReasonCode() {
		return declineReasonCode;
	}
	public void setDeclineReasonCode(String declineReasonCode) {
		this.declineReasonCode = declineReasonCode;
	}
	public String getIpAddressInternetTxn() {
		return ipAddressInternetTxn;
	}
	public void setIpAddressInternetTxn(String ipAddressInternetTxn) {
		this.ipAddressInternetTxn = ipAddressInternetTxn;
	}
	public String getMacAddress() {
		return macAddress;
	}
	public void setMacAddress(String macAddress) {
		this.macAddress = macAddress;
	}
	public String getBlockReasonCode() {
		return blockReasonCode;
	}
	public void setBlockReasonCode(String blockReasonCode) {
		this.blockReasonCode = blockReasonCode;
	}
	public String getBafesTransactionCode() {
		return bafesTransactionCode;
	}
	public void setBafesTransactionCode(String bafesTransactionCode) {
		this.bafesTransactionCode = bafesTransactionCode;
	}
	public String getAuthorizationDescription() {
		return authorizationDescription;
	}
	public void setAuthorizationDescription(String authorizationDescription) {
		this.authorizationDescription = authorizationDescription;
	}
	public String getApprovalCode() {
		return approvalCode;
	}
	public void setApprovalCode(String approvalCode) {
		this.approvalCode = approvalCode;
	}
	public String getOnlineErrorReturnMsg() {
		return onlineErrorReturnMsg;
	}
	public void setOnlineErrorReturnMsg(String onlineErrorReturnMsg) {
		this.onlineErrorReturnMsg = onlineErrorReturnMsg;
	}
	public String getAdditionalTnxDescription1() {
		return additionalTnxDescription1;
	}
	public void setAdditionalTnxDescription1(String additionalTnxDescription1) {
		this.additionalTnxDescription1 = additionalTnxDescription1;
	}
	public String getAdditionalTnxDescription2() {
		return additionalTnxDescription2;
	}
	public void setAdditionalTnxDescription2(String additionalTnxDescription2) {
		this.additionalTnxDescription2 = additionalTnxDescription2;
	}
	public String getAdditionalTnxDescription3() {
		return additionalTnxDescription3;
	}
	public void setAdditionalTnxDescription3(String additionalTnxDescription3) {
		this.additionalTnxDescription3 = additionalTnxDescription3;
	}
	public String getAdditionalTnxDescription4() {
		return additionalTnxDescription4;
	}
	public void setAdditionalTnxDescription4(String additionalTnxDescription4) {
		this.additionalTnxDescription4 = additionalTnxDescription4;
	}
	public String getUserDataField1() {
		return userDataField1;
	}
	public void setUserDataField1(String userDataField1) {
		this.userDataField1 = userDataField1;
	}
	public String getUserDataField2() {
		return userDataField2;
	}
	public void setUserDataField2(String userDataField2) {
		this.userDataField2 = userDataField2;
	}
	public String getCardNumber() {
		return cardNumber;
	}
	public void setCardNumber(String cardNumber) {
		this.cardNumber = cardNumber;
	}
	public String getTransactionCardCountryCode() {
		return transactionCardCountryCode;
	}
	public void setTransactionCardCountryCode(String transactionCardCountryCode) {
		this.transactionCardCountryCode = transactionCardCountryCode;
	}
	public String getAmountType() {
		return amountType;
	}
	public void setAmountType(String amountType) {
		this.amountType = amountType;
	}
	public String getAdditionalAmount() {
		return additionalAmount;
	}
	public void setAdditionalAmount(String additionalAmount) {
		this.additionalAmount = additionalAmount;
	}
	public String getRecordCurrencyCode() {
		return recordCurrencyCode;
	}
	public void setRecordCurrencyCode(String recordCurrencyCode) {
		this.recordCurrencyCode = recordCurrencyCode;
	}
	public String getRecordAccountType() {
		return recordAccountType;
	}
	public void setRecordAccountType(String recordAccountType) {
		this.recordAccountType = recordAccountType;
	}
}
