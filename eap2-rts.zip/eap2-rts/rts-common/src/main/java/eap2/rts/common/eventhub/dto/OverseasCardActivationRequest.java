package eap2.rts.common.eventhub.dto;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonProperty;

public class OverseasCardActivationRequest implements Serializable {
	private static final long serialVersionUID = -4637495733319828986L;
	
	@JsonProperty("Event")
	private EventOverseasCardActivation event;
	
	public EventOverseasCardActivation getEvent() {
		return event;
	}
	public void setEvent(EventOverseasCardActivation event) {
		this.event = event;
	}
	@Override
	public String toString() {
		return "OverseasCardActivationRequest [event=" + event + "]";
	}
}
