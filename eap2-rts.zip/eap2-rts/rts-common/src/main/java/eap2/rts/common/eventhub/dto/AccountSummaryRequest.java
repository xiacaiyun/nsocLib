package eap2.rts.common.eventhub.dto;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonProperty;

public class AccountSummaryRequest implements Serializable {
	private static final long serialVersionUID = -7730225212011793456L;
	
	@JsonProperty("Event")
	private EventAccountSummary event;
	
	public EventAccountSummary getEvent() {
		return event;
	}
	public void setEvent(EventAccountSummary event) {
		this.event = event;
	}
	@Override
	public String toString() {
		return "AccountSummaryRequest [event=" + event + "]";
	}
}
