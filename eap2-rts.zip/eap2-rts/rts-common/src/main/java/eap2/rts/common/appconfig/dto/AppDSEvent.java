package eap2.rts.common.appconfig.dto;

import java.util.List;

public class AppDSEvent implements java.io.Serializable {
	private static final long serialVersionUID = 1L;

	private Integer id;
	private String name;
	private Integer appDSId;
	private String eventTypeCode;
	private String description;

	// Child records
	private List<AppDSDetail> eventDSDetails;
	private List<EventAction> eventActions;

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public Integer getAppDSId() {
		return appDSId;
	}

	public void setAppDSId(Integer appDSId) {
		this.appDSId = appDSId;
	}

	public String getEventTypeCode() {
		return eventTypeCode;
	}

	public void setEventTypeCode(String eventTypeCode) {
		this.eventTypeCode = eventTypeCode;
	}

	public List<AppDSDetail> getEventDSDetails() {
		return eventDSDetails;
	}

	public void setEventDSDetails(List<AppDSDetail> eventDSDetails) {
		this.eventDSDetails = eventDSDetails;
	}

	public List<EventAction> getEventActions() {
		return eventActions;
	}

	public void setEventActions(List<EventAction> eventActions) {
		this.eventActions = eventActions;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((appDSId == null) ? 0 : appDSId.hashCode());
		result = prime * result + ((description == null) ? 0 : description.hashCode());
		result = prime * result + ((eventActions == null) ? 0 : eventActions.hashCode());
		result = prime * result + ((eventDSDetails == null) ? 0 : eventDSDetails.hashCode());
		result = prime * result + ((eventTypeCode == null) ? 0 : eventTypeCode.hashCode());
		result = prime * result + ((id == null) ? 0 : id.hashCode());
		result = prime * result + ((name == null) ? 0 : name.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		AppDSEvent other = (AppDSEvent) obj;
		if (appDSId == null) {
			if (other.appDSId != null)
				return false;
		} else if (!appDSId.equals(other.appDSId))
			return false;
		if (description == null) {
			if (other.description != null)
				return false;
		} else if (!description.equals(other.description))
			return false;
		if (eventActions == null) {
			if (other.eventActions != null)
				return false;
		} else if (!eventActions.equals(other.eventActions))
			return false;
		if (eventDSDetails == null) {
			if (other.eventDSDetails != null)
				return false;
		} else if (!eventDSDetails.equals(other.eventDSDetails))
			return false;
		if (eventTypeCode == null) {
			if (other.eventTypeCode != null)
				return false;
		} else if (!eventTypeCode.equals(other.eventTypeCode))
			return false;
		if (id == null) {
			if (other.id != null)
				return false;
		} else if (!id.equals(other.id))
			return false;
		if (name == null) {
			if (other.name != null)
				return false;
		} else if (!name.equals(other.name))
			return false;
		return true;
	}

	@Override
	public String toString() {
		return "AppEvent [id=" + id + ", name=" + name + ", appDSId=" + appDSId + ", eventTypeCode=" + eventTypeCode + ", description=" + description
				+ ", eventDSDetails=" + eventDSDetails + ", eventActions=" + eventActions + "]";
	}

}
