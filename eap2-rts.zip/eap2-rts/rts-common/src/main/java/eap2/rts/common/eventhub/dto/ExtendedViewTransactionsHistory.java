package eap2.rts.common.eventhub.dto;

import java.io.Serializable;

public class ExtendedViewTransactionsHistory implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = -4897710129289499613L;

}
