package eap2.rts.common.appconfig.dao.ora;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Properties;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import eap2.rts.common.SysConstants;
import eap2.rts.common.appconfig.dao.AppConfigDAO;
import eap2.rts.common.appconfig.dto.AppDSEvent;
import eap2.rts.common.appconfig.dto.AppParam;
import eap2.rts.common.appconfig.dto.Application;
import eap2.rts.common.appconfig.dto.EventAction;
import eap2.rts.common.appconfig.dto.EventActionDetail;
import eap2.rts.common.appconfig.dto.AppDS;
import eap2.rts.common.appconfig.dto.AppDSDetail;
import eap2.rts.common.appconfig.dto.TenantAppParam;
import eap2.rts.common.exception.AppConfigException;

public class AppConfigOraDAO extends GenericJDBCDAO implements AppConfigDAO {

	protected static Logger logger = LoggerFactory.getLogger(AppConfigOraDAO.class);

	public AppConfigOraDAO(Properties props) {
		super(props);
		logger.info(">>>>> AppConfigOraDAO Initialized.....");
	}

	public Integer getAppIdByAppName(String appName) throws AppConfigException {
		logger.info(">>>>> Loading Application Configurations by name " + appName + " .....");
		Integer appId = null;
		String sqlQuery = (String) props.get(SysConstants.APP_BY_NAME);
		Collection<Object> params = new ArrayList<Object>();
		params.add(appName);
		try {
			logger.info(">>>>> processing query ");
			List<Object> results = (List<Object>) execute(sqlQuery, params, DTOBuilderHelper.intObjectBuilder);
			if (results != null && !results.isEmpty()) {
				appId = (Integer) results.get(0);
			} else {
				throw new AppConfigException("No result retruned.");
			}
		} catch (Exception e) {
			throw new AppConfigException(e);
		}
		return appId;
	}

	public Application getApplicationById(Integer appId) throws AppConfigException {
		logger.info(">>>>> Loading Application Configurations by appId " + appId + " .....");
		Application application = null;
		String sqlQuery = (String) props.get(SysConstants.APP_BY_ID);
		Collection<Object> params = new ArrayList<Object>();
		params.add(appId);
		try {
			List<Object> results = (List<Object>) execute(sqlQuery, params, DTOBuilderHelper.applicationDTOBuilder);
			if (results != null && !results.isEmpty()) {
				application = (Application) results.get(0);
			} else {
				throw new AppConfigException("No result retruned.");
			}
		} catch (Exception e) {
			throw new AppConfigException(e);
		}
		return application;
	}

	@Override
	public Map<String, Map<String, String>> getTenantAppParamsByAppId(Integer appId) throws AppConfigException {
		logger.info(">>>>> Loading TenantAppParam Configurations by appId " + appId + " .....");
		Map<String, Map<String, String>> appParams = null;
		String sqlQuery = (String) props.get(SysConstants.TENANT_APP_PARAMS_BY_ID);

		Collection<Object> params = new ArrayList<Object>();
		params.add(appId);
		try {
			List<TenantAppParam> appParamList = (List<TenantAppParam>) execute(sqlQuery, params, DTOBuilderHelper.tenantAppParamDTOBuilder);
			appParams = buildTenantAppParamMap(appParamList);
		} catch (Exception e) {
			throw new AppConfigException(e);
		}
		return appParams;
	}

	@Override
	public Map<String, Map<String, String>> getAppParamsByAppId(Integer appId) throws AppConfigException {
		logger.info(">>>>> Loading AppParam Configurations by appId " + appId + " .....");
		Map<String, Map<String, String>> appParams = null;
		String sqlQuery = (String) props.get(SysConstants.APP_PARAMS_BY_ID);
		Collection<Object> params = new ArrayList<Object>();
		params.add(appId);
		try {
			List<AppParam> appParamList = (List<AppParam>) execute(sqlQuery, params, DTOBuilderHelper.appParamDTOBuilder);
			appParams = buildAppParamMap(appParamList);
		} catch (Exception e) {
			throw new AppConfigException(e);
		}
		return appParams;
	}

	private Map<String, Map<String, String>> buildTenantAppParamMap(List<TenantAppParam> appParamList) {
		Map<String, Map<String, String>> map = new HashMap<String, Map<String, String>>();
		for (TenantAppParam param : appParamList) {
			String paramTypeCode = param.getParamTypeCode();
			Map<String, String> paramList = map.get(paramTypeCode);
			if (paramList == null) {
				paramList = new HashMap<String, String>();
				map.put(paramTypeCode, paramList);
			}
			paramList.put(param.getParamName(), param.getParamValue());
		}
		return map;
	}

	private Map<String, Map<String, String>> buildAppParamMap(List<AppParam> appParamList) {
		Map<String, Map<String, String>> map = new HashMap<String, Map<String, String>>();
		for (AppParam param : appParamList) {
			String paramTypeCode = param.getParamTypeCode();
			Map<String, String> paramList = map.get(paramTypeCode);
			if (paramList == null) {
				paramList = new HashMap<String, String>();
			}
			paramList.put(param.getParamName(), param.getParamValue());
			map.put(paramTypeCode, paramList);
		}
		return map;
	}

	/**
	 * @param appId
	 * @return
	 * @throws AppConfigException
	 */
	@Override
	public List<AppDSEvent> getAppEventByAppDSId(Integer appId) throws AppConfigException {
		logger.info(">>>>> Loading AppEvent Configurations by appId " + appId + " .....");
		List<AppDSEvent> appEventList = null;
		String sqlQuery = (String) props.get(SysConstants.APP_EVENT_BY_APP_DS_ID);
		Collection<Object> params = new ArrayList<Object>();
		params.add(appId);
		try {
			appEventList = (List<AppDSEvent>) execute(sqlQuery, params, DTOBuilderHelper.appEventDTOBuilder);
		} catch (Exception e) {
			throw new AppConfigException(e);
		}
		return appEventList;
	}

	@Override
	public List<EventAction> getEventActionByEventId(Integer eventId) throws AppConfigException {
		logger.info(">>>>> Loading EventAction Configurations by eventId " + eventId + " .....");
		List<EventAction> eventActions = null;
		String sqlQuery = (String) props.get(SysConstants.APP_EVENT_ACTION_BY_EVENT_ID);
		Collection<Object> params = new ArrayList<Object>();
		params.add(eventId);
		try {
			eventActions = (List<EventAction>) execute(sqlQuery, params, DTOBuilderHelper.eventActionDTOBuilder);
		} catch (Exception e) {
			throw new AppConfigException(e);
		}
		return eventActions;
	}

	@Override
	public List<EventActionDetail> getActionDetailsByActionId(Integer actionId) throws AppConfigException {
		logger.info(">>>>> Loading ActionDetail by actionId " + actionId + " .....");
		List<EventActionDetail> actionDetails = null;
		String sqlQuery = (String) props.get(SysConstants.ACTION_DET_BY_ACTION_ID);
		Collection<Object> params = new ArrayList<Object>();
		params.add(actionId);
		try {
			actionDetails = (List<EventActionDetail>) execute(sqlQuery, params, DTOBuilderHelper.eventActionDetailBuilder);
		} catch (Exception e) {
			throw new AppConfigException(e);
		}
		return actionDetails;
	}

	@Override
	public List<AppDSDetail> getAppDSDetailByAppDSId(Integer dsId) throws AppConfigException {
		logger.info(">>>>> Loading AppDSDetail Configurations by eventId " + dsId + " .....");
		List<AppDSDetail> appDSDetails = null;
		String sqlQuery = (String) props.get(SysConstants.APP_DS_DET_BY_DS_ID);
		Collection<Object> params = new ArrayList<Object>();
		params.add(dsId);
		try {
			appDSDetails = (List<AppDSDetail>) execute(sqlQuery, params, DTOBuilderHelper.appDSDetailDTOBuilder);
		} catch (Exception e) {
			throw new AppConfigException(e);
		}
		return appDSDetails;
	}

	@Override
	public List<AppDS> getAppDSByAppId(Integer appId) throws AppConfigException {
		logger.info(">>>>> Loading AppDS Configurations by appId " + appId + " .....");
		List<AppDS> appDSList = null;
		String sqlQuery = (String) props.get(SysConstants.APP_DS_BY_APP_ID);
		Collection<Object> params = new ArrayList<Object>();
		params.add(appId);
		try {
			appDSList = (List<AppDS>) execute(sqlQuery, params, DTOBuilderHelper.appDSDTOBuilder);
		} catch (Exception e) {
			throw new AppConfigException(e);
		}
		return appDSList;
	}

}