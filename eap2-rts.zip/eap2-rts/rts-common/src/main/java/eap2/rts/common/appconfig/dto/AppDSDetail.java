package eap2.rts.common.appconfig.dto;

import java.io.Serializable;

public class AppDSDetail implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 372039499172015235L;
	private Integer id;
	private Integer appDSId;
	private String paramName;
	private String paramValue;
	private String valueEncrypted;
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public Integer getAppDSId() {
		return appDSId;
	}
	public void setAppDSId(Integer appDSId) {
		this.appDSId = appDSId;
	}
	public String getParamName() {
		return paramName;
	}
	public void setParamName(String paramName) {
		this.paramName = paramName;
	}
	public String getParamValue() {
		return paramValue;
	}
	public void setParamValue(String paramValue) {
		this.paramValue = paramValue;
	}
	public String getValueEncrypted() {
		return valueEncrypted;
	}
	public void setValueEncrypted(String valueEncrypted) {
		this.valueEncrypted = valueEncrypted;
	}
	@Override
	public String toString() {
		return "EventDSDetail [id=" + id + ", appDSId=" + appDSId + ", paramName=" + paramName + ", paramValue=" + paramValue + "]";
	}

	
}
