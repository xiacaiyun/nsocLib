package eap2.rts.common;

public class SysConstants {

	// Oracle JDBC Driver Parameters
	public static final String ORA_DRIVER_PARAM = "connection.driver_class";
	public static final String ORA_URL_PARAM = "connection.url";
	public static final String ORA_USER_PARAM = "connection.username";
	public static final String ORA_PASSWORD_PARAM = "connection.password";
	
	//PWP parameters
	public static final String ORACLE_SERVERNAME="oracle.servername";
	public static final String ORACLE_USERNAME="oracle.username";
	public static final String TIBCO_SERVERNAME="tibco.servername";
	public static final String TIBCO_USERNAME="tibco.username";
	public static final String MONGO_SERVERNAME="mongo.servername";
	public static final String MONGO_USERNAME="mongo.username";
	public static final String PWP_SALT="eap2.pwp.salt";
	public static final String IS_PASSWORD_ENCRYPTED="eap2.is.password.encrypted";
	
	// Parameter Types
	public static final String PARAM_TYPE_APP_CONF = "APP_CONF";
	public static final String PARAM_TYPE_HDFS_CONF = "HDFS_CONF";
	public static final String PARAM_TYPE_HIVE_CONF = "HIVE_CONF";
	public static final String PARAM_TYPE_SPARK_CONF = "SPARK_CONF";
	public static final String PARAM_TYPE_TIBCO_CONF = "TIBCO_CONF";

	// Action Types
	public static final String ACTION_TYPE_PUB = "PUB";
	public static final String ACTION_TYPE_PARSE = "PARSE";
	public static final String ACTION_TYPE_SAVE = "SAVE";

	// Regex
	public static final String STR_EMPTY = "";
	public static final String STR_COMMA = ",";
	public static final String STR_HASH = "#";
	public static final String STR_NULL = "null";
	public static final String STR_SPACE = " ";
	public static final String STR_PIPE = "|";

	public static final String YES_IND = "Y";
	public static final String NO_IND = "N";

	// HDFS config
	public final static String HDFS_MASTER_URL = "hdfs.master.url";
	public final static String HDFS_CORE_SITE_XML_LOCATION = "hdfs.core.site.xml.location";
	public final static String HDFS_SITE_XML_LOCATION = "hdfs.site.xml.location";

	// Tibco JMS configurations
	public static final String TIBCO_JMS_CONTEXT_FACTORY = "tibco.jms.context.factory";
	public static final String TIBCO_JMS_JNDI_CONN_URL = "tibco.jms.jndi.conn.url";
	public static final String TIBCO_JMS_CONTEXT_FACTORY_NAME_EAP2_ER_OUTBOUND = "tibco.jms.context.factory.name.outbound";
	public static final String TIBCO_JMS_OUTBOUND_TOPIC_NAME = "tibco.jms.outbound.topic.name";
	public static final String TIBCO_JMS_TOPIC_USERNAME = "tibco.jms.topic.username";
	public static final String TIBCO_JMS_TOPIC_PASSWORD = "tibco.jms.topic.password";

	// AutoWatch Events
	public static final String EVENT_STARTED = "Started";
	public static final String EVENT_COMPLETED = "Completed";
	public static final String EVENT_FAILED = "Failed";

	// Enrichment Configurations
	public static final String ENRICH_TYPE_NO_OP = "NOOP";
	public static final String CONSTANT_LOG_UDF = "AddConstLong";
	public static final String CONSTANT_INT_UDF = "AddConstInt";
	 
	//DAO QUERIES
	public static final String APP_BY_NAME = "get.app.by.name";
	public static final String APP_BY_ID ="get.app.by.id";
	public static final String TENANT_APP_PARAMS_BY_ID= "get.tenant.app.param.by.id";
	public static final String APP_PARAMS_BY_ID = "get.app.params.by.id";
	public static final String APP_EVENT_BY_APP_DS_ID ="get.app.event.by.app.ds.id";
	public static final String APP_EVENT_ACTION_BY_EVENT_ID = "get.app.event.action.by.event.id";
	public static final String ACTION_DET_BY_ACTION_ID="get.action.details.by.action.id";
	public static final String APP_DS_DET_BY_DS_ID ="get.app.ds.detail.by.ds.id";
	public static final String APP_DS_BY_APP_ID ="get.app.ds.by.app.id";
	
	//ShutdownTime
	public static final String SHUTDOWN_HOUR = "shutdown.hour";
	public static final String SHUTDOWN_MINUTES = "shutdown.minutes";
	
	//Python Conf
	
	public static final String PYTHON_CONF_SECTION_NAME = "config_section_name";
	public static final String PYTHON_CONF_FILE = "python_config_file";
	public static final String PYTHON_SCRIPT = "python_script";
	public static final String PYTHON_PATH = "python_path";
	public static final String FILES_LOCAL_PATH = "files_local_path";
	public static final String FILE_HDFS_PATH = "files_hdfs_path";
	public static final String HDFS_ROOT_URL = "hdfs_root_url";
	public static final String MONGO_DB_PASSWORD = "mongo_db_password";
	public static final String PYTHON_SAVING_SCORING_OUTPUT = "save_python_scoring_output";
	
}