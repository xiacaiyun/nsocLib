package eap2.rts.common.eventhub.dto;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonProperty;

public class CreditCardClosureRequest implements Serializable {
	private static final long serialVersionUID = -6696312823935059556L;
	
	@JsonProperty("Event")
	private EventCreditCardClosure event;
	
	public EventCreditCardClosure getEvent() {
		return event;
	}
	public void setEvent(EventCreditCardClosure event) {
		this.event = event;
	}
	@Override
	public String toString() {
		return "CreditCardClosureRequest [event=" + event + "]";
	}
}
