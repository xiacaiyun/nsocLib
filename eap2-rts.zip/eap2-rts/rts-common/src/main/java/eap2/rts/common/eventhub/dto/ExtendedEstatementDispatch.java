package eap2.rts.common.eventhub.dto;

import java.io.Serializable;

public class ExtendedEstatementDispatch implements Serializable {
	private static final long serialVersionUID = 8155280950107613225L;
	
	
}
