package eap2.rts.common.eventhub.dto;

import java.io.Serializable;

public class ExtendedEPPLOPOfferView implements Serializable {
	
	private static final long serialVersionUID = 1133524819520275537L;
	
}
