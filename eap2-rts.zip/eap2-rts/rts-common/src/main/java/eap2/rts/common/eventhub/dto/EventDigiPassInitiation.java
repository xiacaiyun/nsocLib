package eap2.rts.common.eventhub.dto;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonProperty;

public class EventDigiPassInitiation implements Serializable {
	private static final long serialVersionUID = -7342220645529683571L;
	
	@JsonProperty("Standard")
	private StandardDigiPassInitiation Standard;
	@JsonProperty("CustomerAccess")
    private CustomerAccessDigiPassInitiation CustomerAccess;
	@JsonProperty("Extended")
    private ExtendedDigiPassInitiation Extended;
	@JsonProperty("Metadata")
    private MetadataDigiPassInitiation Metadata;

    public StandardDigiPassInitiation getStandard ()
    {
        return Standard;
    }

    public void setStandard (StandardDigiPassInitiation Standard)
    {
        this.Standard = Standard;
    }

    public CustomerAccessDigiPassInitiation getCustomerAccess ()
    {
        return CustomerAccess;
    }

    public void setCustomerAccess (CustomerAccessDigiPassInitiation CustomerAccess)
    {
        this.CustomerAccess = CustomerAccess;
    }

    public ExtendedDigiPassInitiation getExtended ()
    {
        return Extended;
    }

    public void setExtended (ExtendedDigiPassInitiation Extended)
    {
        this.Extended = Extended;
    }

    public MetadataDigiPassInitiation getMetadata ()
    {
        return Metadata;
    }

    public void setMetadata (MetadataDigiPassInitiation Metadata)
    {
        this.Metadata = Metadata;
    }

    @Override
    public String toString()
    {
        return "ClassPojo [Standard = "+Standard+", CustomerAccess = "+CustomerAccess+", Extended = "+Extended+", Metadata = "+Metadata+"]";
    }
}
