package eap2.rts.common.eventhub.dto;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonProperty;

public class EventForgotUserIdAndPassword implements Serializable {
	private static final long serialVersionUID = -7604211973260530628L;
	
	@JsonProperty("Standard")
	private StandardForgotUserIdAndPassword Standard;
	@JsonProperty("CustomerAccess")
    private CustomerAccessForgotUserIdAndPassword CustomerAccess;
	@JsonProperty("Extended")
    private ExtendedForgotUserIdAndPassword Extended;
	@JsonProperty("Metadata")
    private MetadataForgotUserIdAndPassword Metadata;

    public StandardForgotUserIdAndPassword getStandard ()
    {
        return Standard;
    }

    public void setStandard (StandardForgotUserIdAndPassword Standard)
    {
        this.Standard = Standard;
    }

    public CustomerAccessForgotUserIdAndPassword getCustomerAccess ()
    {
        return CustomerAccess;
    }

    public void setCustomerAccess (CustomerAccessForgotUserIdAndPassword CustomerAccess)
    {
        this.CustomerAccess = CustomerAccess;
    }

    public ExtendedForgotUserIdAndPassword getExtended ()
    {
        return Extended;
    }

    public void setExtended (ExtendedForgotUserIdAndPassword Extended)
    {
        this.Extended = Extended;
    }

    public MetadataForgotUserIdAndPassword getMetadata ()
    {
        return Metadata;
    }

    public void setMetadata (MetadataForgotUserIdAndPassword Metadata)
    {
        this.Metadata = Metadata;
    }

    @Override
    public String toString()
    {
        return "ClassPojo [Standard = "+Standard+", CustomerAccess = "+CustomerAccess+", Extended = "+Extended+", Metadata = "+Metadata+"]";
    }
}
