package eap2.rts.common.eventhub.dto;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonProperty;

public class OnlineDirectDebitExecutionRequest implements Serializable {
	private static final long serialVersionUID = 3880587946546239734L;
	
	@JsonProperty("Event")
	private EventOnlineDirectDebitExecution event;
	
	public EventOnlineDirectDebitExecution getEvent() {
		return event;
	}
	public void setEvent(EventOnlineDirectDebitExecution event) {
		this.event = event;
	}
	@Override
	public String toString() {
		return "OnlineDirectDebitExecutionRequest [event=" + event + "]";
	}
}
