package eap2.rts.common.eventhub.dto;

import java.io.Serializable;

public class ExtendedCustLoginIDStatusChange implements Serializable {
	private static final long serialVersionUID = 689548654305240576L;
	
	
}
