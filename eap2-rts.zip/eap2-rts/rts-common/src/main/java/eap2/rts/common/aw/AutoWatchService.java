package eap2.rts.common.aw;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import eap2.cda.common.aw.EAPEvent;
import eap2.rts.common.SysConstants;
import eap2.rts.common.util.HDFSFileUtility;

/**
 * @author bs34500
 */
public class AutoWatchService {

	/**
	 * @param hdfsConfig
	 * @param awTriggerPath
	 * @return
	 * @throws Exception
	 */
	public static EAPEvent getEAPEventFromHDFSPath(Map<String, String> hdfsConfig, String awTriggerPath) throws Exception {
		String awXML = HDFSFileUtility.getInstance(hdfsConfig).readHDFSFileAsString(awTriggerPath);
		EAPEvent eapEvent = JAXBHelper.getInstance().unMarshal(awXML);
		return eapEvent;
	}

	/**
	 * @param eapEvent
	 * @return
	 * @throws Exception
	 */
	public static String getXmlFromEAPEvent(EAPEvent eapEvent) throws Exception {
		String awResponse = JAXBHelper.getInstance().marshal(eapEvent);
		return awResponse;
	}

	public static String publishStartedStatus(final EAPEvent eapEvent, final Map<String, String> jmsConfig) throws Exception {
		eapEvent.setStatus(SysConstants.EVENT_STARTED);
		String awResponse = getXmlFromEAPEvent(eapEvent);
		AutowatchJMSService.getInstance(jmsConfig).publish(awResponse);
		return awResponse;
	}

	/**
	 * @param eapEvent
	 * @param errorList
	 * @param jmsConfig
	 * @throws Exception
	 */
	public static String publishFailedStatus(EAPEvent eapEvent, String[] errorList, Map<String, String> jmsConfig) throws Exception {
		eapEvent.setStatus(SysConstants.EVENT_FAILED);
		EAPEvent.Process.Output output = new EAPEvent.Process.Output();
		List<EAPEvent.Process.Output.Attr> attrList = new ArrayList<EAPEvent.Process.Output.Attr>();
		for (String error : errorList) {
			EAPEvent.Process.Output.Attr outputAttr = new EAPEvent.Process.Output.Attr();
			outputAttr.setName("ErrorMessage");
			outputAttr.setType("Stats");
			outputAttr.setValue(error);
			attrList.add(outputAttr);
		}
		output.getAttr().addAll(attrList);
		eapEvent.getProcess().setOutput(output);
		String awResponse = getXmlFromEAPEvent(eapEvent);
		AutowatchJMSService.getInstance(jmsConfig).publish(awResponse);
		return awResponse;
	}

	public static String publishFinishedStatus(EAPEvent eapEvent, long resultCount, String[] outputFiles, Map<String, String> jmsConfig)
			throws Exception {
		eapEvent.setStatus(SysConstants.EVENT_COMPLETED);
		List<EAPEvent.Process.Output.Attr> attrList = new ArrayList<EAPEvent.Process.Output.Attr>();

		// Set result count
		EAPEvent.Process.Output.Attr outputAttr3 = new EAPEvent.Process.Output.Attr();
		outputAttr3.setName("RESULT_COUNT");
		outputAttr3.setType("Stats");
		outputAttr3.setValue("" + resultCount);
		attrList.add(outputAttr3);

		// Set output file path
		for (String file : outputFiles) {
			EAPEvent.Process.Output.Attr outputAttr4 = new EAPEvent.Process.Output.Attr();
			outputAttr4.setName("CDA_OUTPUT_FILE");
			outputAttr4.setType("fileID");
			outputAttr4.setValue(file);
			attrList.add(outputAttr4);
		}

		EAPEvent.Process.Output output = new EAPEvent.Process.Output();
		output.getAttr().addAll(attrList);
		eapEvent.getProcess().setOutput(output);

		// Convert into XML string
		String awResponse = getXmlFromEAPEvent(eapEvent);
		AutowatchJMSService.getInstance(jmsConfig).publish(awResponse);
		return awResponse;
	}
}