package eap2.rts.common.eventhub.dto;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonProperty;

public class EventCreditCardClosure implements Serializable {
	private static final long serialVersionUID = -7037669511603503549L;
	
	@JsonProperty("Standard")
	private StandardCreditCardClosure Standard;
	@JsonProperty("CustomerAccess")
    private CustomerAccessCreditCardClosure CustomerAccess;
	@JsonProperty("Extended")
    private ExtendedCreditCardClosure Extended;
	@JsonProperty("Metadata")
    private MetadataCreditCardClosure Metadata;

    public StandardCreditCardClosure getStandard ()
    {
        return Standard;
    }

    public void setStandard (StandardCreditCardClosure Standard)
    {
        this.Standard = Standard;
    }

    public CustomerAccessCreditCardClosure getCustomerAccess ()
    {
        return CustomerAccess;
    }

    public void setCustomerAccess (CustomerAccessCreditCardClosure CustomerAccess)
    {
        this.CustomerAccess = CustomerAccess;
    }

    public ExtendedCreditCardClosure getExtended ()
    {
        return Extended;
    }

    public void setExtended (ExtendedCreditCardClosure Extended)
    {
        this.Extended = Extended;
    }

    public MetadataCreditCardClosure getMetadata ()
    {
        return Metadata;
    }

    public void setMetadata (MetadataCreditCardClosure Metadata)
    {
        this.Metadata = Metadata;
    }

    @Override
    public String toString()
    {
        return "ClassPojo [Standard = "+Standard+", CustomerAccess = "+CustomerAccess+", Extended = "+Extended+", Metadata = "+Metadata+"]";
    }
}
