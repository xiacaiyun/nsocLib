package eap2.rts.common.event.dto;

import com.fasterxml.jackson.annotation.JsonProperty;

public class GetReason {

	@JsonProperty("CountryCode")
	private String CountryCode;

	@JsonProperty("CustomerID")
	private String CustomerID;

	@JsonProperty("CountryCode")
	public String getCountryCode() {
		return CountryCode;
	}

	@JsonProperty("CountryCode")
	public void setCountryCode(String countryCode) {
		this.CountryCode = countryCode;
	}

	@JsonProperty("CustomerID")
	public String getCustomerID() {
		return CustomerID;
	}

	@JsonProperty("CustomerID")
	public void setCustomerID(String customerID) {
		this.CustomerID = customerID;
	}

	@Override
	public String toString() {
		return "GetReason [countryCode=" + CountryCode + ", customerID=" + CustomerID + "]";
	}
}
