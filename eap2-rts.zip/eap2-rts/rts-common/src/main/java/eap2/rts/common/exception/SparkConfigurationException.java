package eap2.rts.common.exception;

public class SparkConfigurationException extends Exception {

	private static final long serialVersionUID = 2519928850742513103L;

	public SparkConfigurationException() {
	}

	public SparkConfigurationException(String message) {
		super(message);
	}

	public SparkConfigurationException(Throwable cause) {
		super(cause);
	}

	public SparkConfigurationException(String message, Throwable cause) {
		super(message, cause);
	}

	public SparkConfigurationException(String message, Throwable cause, boolean enableSuppression, boolean writableStackTrace) {
		super(message, cause, enableSuppression, writableStackTrace);
	}

}
