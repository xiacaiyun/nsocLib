package eap2.rts.common.eventhub.dto;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonProperty;

public class StandardCpoCallStart implements Serializable {
	private static final long serialVersionUID = -1748149910332641502L;
	@JsonProperty("CorrelationID")
    private String CorrelationID;
	@JsonProperty("EventID")
    private String EventID;
	@JsonProperty("EventUUID")
    private String EventUUID;
	@JsonProperty("EventProducer")
    private String EventProducer;
	@JsonProperty("EventTransmitter")
    private String EventTransmitter;
	@JsonProperty("CountryCode")
    private String CountryCode;
	@JsonProperty("BusinessID")
    private String BusinessID;
	@JsonProperty("UUID_UniqueID")
    private String UUID_UniqueID;
	@JsonProperty("ESBUUID")
    private String ESBUUID;
	@JsonProperty("BizFunctionID")
    private String BizFunctionID;
	@JsonProperty("CustomerID")
    private String CustomerID;
	@JsonProperty("CustomerType")
    private String CustomerType;
	@JsonProperty("CardNumber")
	private String CardNumber;
	@JsonProperty("AccountNumber")
    private String AccountNumber;
	@JsonProperty("IsCustomerPrimary")
    private String IsCustomerPrimary;
	@JsonProperty("TransactionStatus")
    private String TransactionStatus;
	@JsonProperty("TransactionType")
    private String TransactionType;
	@JsonProperty("RespStatusCode")
    private String RespStatusCode;
	@JsonProperty("RespStatusMsg")
    private String RespStatusMsg;
	@JsonProperty("ServerDateTime")
    private String ServerDateTime;
	@JsonProperty("TouchPoint")
    private String TouchPoint;
	@JsonProperty("AssistedChannelUserID")
    private String AssistedChannelUserID;

    public String getCardNumber ()
    {
        return CardNumber;
    }

    public void setCardNumber (String CardNumber)
    {
        this.CardNumber = CardNumber;
    }

    public String getCustomerType ()
    {
        return CustomerType;
    }

    public void setCustomerType (String CustomerType)
    {
        this.CustomerType = CustomerType;
    }

    public String getServerDateTime ()
    {
        return ServerDateTime;
    }

    public void setServerDateTime (String ServerDateTime)
    {
        this.ServerDateTime = ServerDateTime;
    }

    public String getAccountNumber ()
    {
        return AccountNumber;
    }

    public void setAccountNumber (String AccountNumber)
    {
        this.AccountNumber = AccountNumber;
    }

    public String getEventUUID ()
    {
        return EventUUID;
    }

    public void setEventUUID (String EventUUID)
    {
        this.EventUUID = EventUUID;
    }

    public String getBusinessID ()
    {
        return BusinessID;
    }

    public void setBusinessID (String BusinessID)
    {
        this.BusinessID = BusinessID;
    }

    public String getESBUUID ()
    {
        return ESBUUID;
    }

    public void setESBUUID (String ESBUUID)
    {
        this.ESBUUID = ESBUUID;
    }

    public String getEventProducer ()
    {
        return EventProducer;
    }

    public void setEventProducer (String EventProducer)
    {
        this.EventProducer = EventProducer;
    }

    public String getBizFunctionID ()
    {
        return BizFunctionID;
    }

    public void setBizFunctionID (String BizFunctionID)
    {
        this.BizFunctionID = BizFunctionID;
    }

    public String getCorrelationID ()
    {
        return CorrelationID;
    }

    public void setCorrelationID (String CorrelationID)
    {
        this.CorrelationID = CorrelationID;
    }

    public String getTransactionType ()
    {
        return TransactionType;
    }

    public void setTransactionType (String TransactionType)
    {
        this.TransactionType = TransactionType;
    }

    public String getEventID ()
    {
        return EventID;
    }

    public void setEventID (String EventID)
    {
        this.EventID = EventID;
    }

    public String getEventTransmitter ()
    {
        return EventTransmitter;
    }

    public void setEventTransmitter (String EventTransmitter)
    {
        this.EventTransmitter = EventTransmitter;
    }

    public String getUUID_UniqueID ()
    {
        return UUID_UniqueID;
    }

    public void setUUID_UniqueID (String UUID_UniqueID)
    {
        this.UUID_UniqueID = UUID_UniqueID;
    }

    public String getRespStatusCode ()
    {
        return RespStatusCode;
    }

    public void setRespStatusCode (String RespStatusCode)
    {
        this.RespStatusCode = RespStatusCode;
    }

    public String getTouchPoint ()
    {
        return TouchPoint;
    }

    public void setTouchPoint (String TouchPoint)
    {
        this.TouchPoint = TouchPoint;
    }

    public String getTransactionStatus ()
    {
        return TransactionStatus;
    }

    public void setTransactionStatus (String TransactionStatus)
    {
        this.TransactionStatus = TransactionStatus;
    }

    public String getIsCustomerPrimary ()
    {
        return IsCustomerPrimary;
    }

    public void setIsCustomerPrimary (String IsCustomerPrimary)
    {
        this.IsCustomerPrimary = IsCustomerPrimary;
    }

    public String getCustomerID ()
    {
        return CustomerID;
    }

    public void setCustomerID (String CustomerID)
    {
        this.CustomerID = CustomerID;
    }

    public String getAssistedChannelUserID ()
    {
        return AssistedChannelUserID;
    }

    public void setAssistedChannelUserID (String AssistedChannelUserID)
    {
        this.AssistedChannelUserID = AssistedChannelUserID;
    }

    public String getCountryCode ()
    {
        return CountryCode;
    }

    public void setCountryCode (String CountryCode)
    {
        this.CountryCode = CountryCode;
    }

    public String getRespStatusMsg ()
    {
        return RespStatusMsg;
    }

    public void setRespStatusMsg (String RespStatusMsg)
    {
        this.RespStatusMsg = RespStatusMsg;
    }

    @Override
    public String toString()
    {
        return "ClassPojo [CardNumber = "+CardNumber+", CustomerType = "+CustomerType+", ServerDateTime = "+ServerDateTime+", AccountNumber = "+AccountNumber+", EventUUID = "+EventUUID+", BusinessID = "+BusinessID+", ESBUUID = "+ESBUUID+", EventProducer = "+EventProducer+", BizFunctionID = "+BizFunctionID+", CorrelationID = "+CorrelationID+", TransactionType = "+TransactionType+", EventID = "+EventID+", EventTransmitter = "+EventTransmitter+", UUID_UniqueID = "+UUID_UniqueID+", RespStatusCode = "+RespStatusCode+", TouchPoint = "+TouchPoint+", TransactionStatus = "+TransactionStatus+", IsCustomerPrimary = "+IsCustomerPrimary+", CustomerID = "+CustomerID+", AssistedChannelUserID = "+AssistedChannelUserID+", CountryCode = "+CountryCode+", RespStatusMsg = "+RespStatusMsg+"]";
    }
}
