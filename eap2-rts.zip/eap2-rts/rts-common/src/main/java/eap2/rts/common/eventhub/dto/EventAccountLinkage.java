package eap2.rts.common.eventhub.dto;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonProperty;

public class EventAccountLinkage implements Serializable {
	private static final long serialVersionUID = 5829470568976073497L;
	
	@JsonProperty("Standard")
	private StandardAccountLinkage Standard;
	@JsonProperty("CustomerAccess")
    private CustomerAccessAccountLinkage CustomerAccess;
	@JsonProperty("Extended")
    private ExtendedAccountLinkage Extended;
	@JsonProperty("Metadata")
    private MetadataAccountLinkage Metadata;

    public StandardAccountLinkage getStandard ()
    {
        return Standard;
    }

    public void setStandard (StandardAccountLinkage Standard)
    {
        this.Standard = Standard;
    }

    public CustomerAccessAccountLinkage getCustomerAccess ()
    {
        return CustomerAccess;
    }

    public void setCustomerAccess (CustomerAccessAccountLinkage CustomerAccess)
    {
        this.CustomerAccess = CustomerAccess;
    }

    public ExtendedAccountLinkage getExtended ()
    {
        return Extended;
    }

    public void setExtended (ExtendedAccountLinkage Extended)
    {
        this.Extended = Extended;
    }

    public MetadataAccountLinkage getMetadata ()
    {
        return Metadata;
    }

    public void setMetadata (MetadataAccountLinkage Metadata)
    {
        this.Metadata = Metadata;
    }

    @Override
    public String toString()
    {
        return "ClassPojo [Standard = "+Standard+", CustomerAccess = "+CustomerAccess+", Extended = "+Extended+", Metadata = "+Metadata+"]";
    }
}
