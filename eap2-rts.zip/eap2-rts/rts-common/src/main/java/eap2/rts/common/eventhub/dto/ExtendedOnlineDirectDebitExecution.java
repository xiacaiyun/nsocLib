package eap2.rts.common.eventhub.dto;

import java.io.Serializable;

public class ExtendedOnlineDirectDebitExecution implements Serializable {
	private static final long serialVersionUID = -7668206108585480732L;
	
}
