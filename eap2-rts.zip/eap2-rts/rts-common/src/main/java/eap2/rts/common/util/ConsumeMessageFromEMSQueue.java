package eap2.rts.common.util;

import java.io.File;
import java.util.Enumeration;
import java.util.Properties;

import javax.jms.Connection;
import javax.jms.ConnectionFactory;
import javax.jms.JMSException;
import javax.jms.Message;
import javax.jms.MessageConsumer;
import javax.jms.Queue;
import javax.jms.QueueBrowser;
import javax.jms.Session;
import javax.jms.TextMessage;
import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.FileSystem;
import org.apache.hadoop.fs.Path;
import org.apache.spark.streaming.receiver.Receiver;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import eap2.rts.common.event.dto.SimpleRequestObject;
import scala.Tuple2;

public class ConsumeMessageFromEMSQueue {
	protected static final Logger logger = LoggerFactory.getLogger(ConsumeMessageFromEMSQueue.class);
	public static void main(String[] args) {

		/*	String p12Path = "ssl://gpd-ed9-5c7e.nam.nsroot.net:7243";
		String providerURL = "hdfs://gftsdev/user/gcgdmasg/security/DIT_EAP_USR.ca1.p12";*/



		Receiver<Tuple2<String,SimpleRequestObject>> _reciever;
		Properties env = new Properties();
		Connection _jmsConnection;
		MessageConsumer _jmsMessageConsumer;
		Session _jmsSession;
		Queue _jmsQueue;

		env.put(Context.INITIAL_CONTEXT_FACTORY, "com.tibco.tibjms.naming.TibjmsInitialContextFactory");
		env.put(Context.PROVIDER_URL, "ssl://gpd-ed9-5c7e.nam.nsroot.net:7243");
		try {
			env.put("com.tibco.tibjms.naming.ssl_identity",copyP12File("file:///C:/Users/ss36531/DIT_EAP_USR.ca1.p12"));
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		/*env.put(Context.SECURITY_PRINCIPAL, "IMASS_9990");
		env.put(Context.SECURITY_CREDENTIALS, "citi1bank");*/
		env.put(Context.SECURITY_PRINCIPAL, "SIT_EAP_USR");
		env.put(Context.SECURITY_CREDENTIALS, "citi1234");
		env.put("com.tibco.tibjms.naming.security_protocol", "ssl");
		env.put("com.tibco.tibjms.naming.ssl_enable_verify_host", "false");
		env.put("com.tibco.tibjms.naming.ssl_vendor", "j2se-default");
		env.put("com.sun.net.ssl.internal.ssl.Provider", "j2se-default");
		env.put("com.tibco.tibjms.naming.ssl_auth_only", "true");
		env.put("java.property.TIBCO_SECURITY_VENDOR", "j2se-default");
		env.put("java.property.TIBCO_SECURITY_TRACE", "true");
		env.put("com.tibco.tibjms.naming.ssl_debug_trace", "true");
		env.put("com.tibco.tibjms.naming.ssl_trace", "true");

		try {
			Context ctx = new InitialContext(env);
			//ConnectionFactory factory = (ConnectionFactory) ctx.lookup(_eventConfig.get(AppConstants.QUEUE_CF));
			//ConnectionFactory factory = (ConnectionFactory) ctx.lookup("citi.gts.na.giw_9990.eap.QueueCF.ssl");
			ConnectionFactory factory = (ConnectionFactory) ctx.lookup("G2C_EAPCOPAUPHBatchQueueConnectionFactory");
			//_jmsConnection = factory.createConnection("IMASS_9990", "citi1bank");
			_jmsConnection = factory.createConnection("SIT_EAP_USR", "citi1234");
			_jmsConnection.start();
			_jmsSession = _jmsConnection.createSession(false, Session.CLIENT_ACKNOWLEDGE);
			//_jmsQueue = _jmsSession.createQueue("cmb.gts.na.giw_169944.CRDP_INBOUND_QUEUE");
			_jmsQueue = _jmsSession.createQueue("citi.gcg.gom.cop_163124.au_card.mre.transaction.request");
			_jmsMessageConsumer = _jmsSession.createConsumer(_jmsQueue);
			// Attached listeners 
			while(true){
				Message msg=_jmsMessageConsumer.receive();
				TextMessage tm = (TextMessage) msg;
				/*String eventID=tm.getStringProperty("EventID");
				String eventProducer=tm.getStringProperty("EventProducer");
				String countryCode=tm.getStringProperty("CountryCode");
				String bussinessID=tm.getStringProperty("BusinessID");
				String bizFunctionID=tm.getStringProperty("BizFunctionID");
				String transactionStatus=tm.getStringProperty("TransactionStatus");
				String touchPoint=tm.getStringProperty("TouchPoint");
				String eventUUID=tm.getStringProperty("EventUUID");*/
				//				logger.info("Message received on SSLqueue with P12 VALIDATION" + tm.getText());
				System.out.println("SYSO::::::::::::::Message received on SSLqueue with P12 VALIDATION" + tm.getText());
				msg.acknowledge();


				
				/*System.out.println("eventID: "+ eventID);
				System.out.println("eventProducer: "+ eventProducer);
				System.out.println("countryCode: "+ countryCode);
				System.out.println("bussinessID: "+ bussinessID);
				System.out.println("bizFunctionID: "+ bizFunctionID);
				System.out.println("transactionStatus: "+ transactionStatus);
				System.out.println("touchPoint: "+ touchPoint);
				System.out.println("eventUUID: "+ eventUUID);*/
			}
			
			/*QueueBrowser queueBrowser = _jmsSession.createBrowser(_jmsQueue);

			Enumeration e = queueBrowser.getEnumeration();

			int numMsgs = 0;

			// count number of messages

			while (e.hasMoreElements()) {

				Message message2 = (Message) e.nextElement();

				numMsgs++;

			}
			
			System.out.println("Total no of messages pending>>>>>>>>>>>>>>>>>>" + numMsgs);*/

		} catch (JMSException e) {
			logger.error("SparkTibcoEMSConsumer->>>>>run->>>>>Debug->>>>>starts->>>>>");
			logger.error("An error has occured", e);
			logger.error("SparkTibcoEMSConsumer->>>>>run->>>>>Debug->>>>>ends->>>>>");
			throw new RuntimeException(e);
		} catch (NamingException e) {
			logger.error("SparkTibcoEMSConsumer->>>>>run->>>>>Debug->>>>>starts->>>>>");
			logger.error("An error has occured", e);
			logger.error("SparkTibcoEMSConsumer->>>>>run->>>>>Debug->>>>>ends->>>>>");
			throw new RuntimeException(e);
		}


	}

	public static String copyP12File(String hdfs_path) throws Exception {
		Configuration conf = new Configuration();
		// conf.set("fs.defaultFS", "${NAMENODE_URI}");
		FileSystem hdfsFileSystem = FileSystem.get(conf);

		String result = null;

		Path hdfs = new Path(hdfs_path);
		Path local = new Path("/tmp");
		File file = new File("/tmp/DIT_EAP_USR.ca1.p12");

		if (hdfsFileSystem.exists(hdfs)) {
			logger.info("Inside copyP12File->>>>> file exists in hdfs");
			if (file.exists()) {
				logger.info("Inside copyP12File->>>>> file exists in tmp as well");
				result = "/tmp/DIT_EAP_USR.ca1.p12";
			} else {
				logger.info("Inside copyP12File->>>>> copying file to tmp");
				hdfsFileSystem.copyToLocalFile(false, hdfs, local, true);
				result = "/tmp/DIT_EAP_USR.ca1.p12";
			}
		} else {
			logger.info("Inside copyP12File->>>>> file does not exists in hdfs");
			result = null;
		}

		return result;

	}
}
