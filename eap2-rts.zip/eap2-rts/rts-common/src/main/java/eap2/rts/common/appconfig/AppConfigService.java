package eap2.rts.common.appconfig;

import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Properties;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import eap2.rts.common.SysConstants;
import eap2.rts.common.appconfig.dao.AppConfigDAO;
import eap2.rts.common.appconfig.dao.ora.AppConfigOraDAO;
import eap2.rts.common.appconfig.dto.AppDS;
import eap2.rts.common.appconfig.dto.AppDSDetail;
import eap2.rts.common.appconfig.dto.AppDSEvent;
import eap2.rts.common.appconfig.dto.Application;
import eap2.rts.common.appconfig.dto.EventAction;
import eap2.rts.common.appconfig.dto.EventActionDetail;
import eap2.rts.common.exception.AppConfigException;
import eap2.rts.pwp.PWPUtilMain;

public class AppConfigService {
	protected static Logger logger = LoggerFactory.getLogger(AppConfigService.class);
	private AppConfigDAO appConfigDAO;
	private PWPUtilMain pwpUtil=new PWPUtilMain();

	public AppConfigService(Properties dbProperties) {
		logger.info(">>>>> Initializing AppConfigService.....");
		appConfigDAO = new AppConfigOraDAO(dbProperties);
	}

	public Application getAppConfigByName(String appName,String salt) throws AppConfigException {
		logger.info("Loading Application Configurations for application " + appName + " .....");
		Integer appId = appConfigDAO.getAppIdByAppName(appName);
		return getAppConfigById(appId,salt);
	}

	public Application getAppConfigById(Integer appId,String salt) throws AppConfigException {
		logger.info("Inside method AppConfigService-->getAppConfigById...");

		// 1. Fetch Application DTO
		Application appConfig = appConfigDAO.getApplicationById(appId);

		// 2. Fetch AppParams map
		Map<String, Map<String, String>> tenantAppParams = appConfigDAO.getTenantAppParamsByAppId(appConfig.getId());
		Map<String, Map<String, String>> appParams = appConfigDAO.getAppParamsByAppId(appConfig.getId());
		if (tenantAppParams != null && !tenantAppParams.isEmpty()) {
			Iterator<String> iter = tenantAppParams.keySet().iterator();
			while (iter.hasNext()) {
				String paramTypeCode = iter.next();
				Map<String, String> tMap = tenantAppParams.get(paramTypeCode);
				Map<String, String> aMap = appParams.get(paramTypeCode);
				if (tMap != null) {
					if (aMap != null) {
						tenantAppParams.get(paramTypeCode).putAll(aMap);
					}
				} else {
					if (aMap != null) {
						tenantAppParams.put(paramTypeCode, aMap);
					}
				}
			}
		}
		appConfig.setAppParams(tenantAppParams);

		// 3. Fetch AppEvents
		List<AppDS> appDSList=appConfigDAO.getAppDSByAppId(appConfig.getId());
		for(AppDS appDS: appDSList){
			
			// 4. Fetch event DataSource details
			List<AppDSDetail> appDSDetails = appConfigDAO.getAppDSDetailByAppDSId(appDS.getId());
			for(AppDSDetail appDSDetail:appDSDetails){
				if(appDSDetail.getValueEncrypted().equals(SysConstants.YES_IND)){
					String paramValue=appDSDetail.getParamValue();
					String decryptedValue="";
					try {
						decryptedValue=pwpUtil.decrypt(salt, paramValue);
					} catch (Exception e) {
						logger.error("Unable to decrypt value",e);
					
					}
					appDSDetail.setParamValue(decryptedValue);
				}
			}
			appDS.setAppDSDetails(appDSDetails);
			
			List<AppDSEvent> appDSEvents = appConfigDAO.getAppEventByAppDSId(appDS.getId());
			for (AppDSEvent appDSEvent : appDSEvents) {
				// 5. Fetch Event Actions
				List<EventAction> eventActions = appConfigDAO.getEventActionByEventId(appDSEvent.getId());
				for (EventAction action : eventActions) {
					List<EventActionDetail> eventActionDetails = appConfigDAO.getActionDetailsByActionId(action.getId());
					for(EventActionDetail eventActionDetail:eventActionDetails){
						if(eventActionDetail.getValueEncrypted().equals(SysConstants.YES_IND)){
							String paramValue=eventActionDetail.getParamValue();
							String decryptedValue="";
							try {
								decryptedValue=pwpUtil.decrypt(salt, paramValue);
							} catch (Exception e) {
								logger.error("Unable to decrypt value",e);
								
							}
							eventActionDetail.setParamValue(decryptedValue);
						}
					}
					action.setEventActionDetails(eventActionDetails);
				}
				appDSEvent.setEventActions(eventActions);
			}
			appDS.setAppDSEvents(appDSEvents);
		}
		
		appConfig.setAppDS(appDSList);
		
		return appConfig;
	}
}
