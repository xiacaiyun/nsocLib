package eap2.rts.common.eventhub.dto;

import java.io.Serializable;

public class ExtendedCardBlockCodeUpdate implements Serializable {
	private static final long serialVersionUID = -8381815198073591649L;
	
	
}
