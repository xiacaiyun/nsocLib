package eap2.rts.common.eventhub.dto;

import java.io.Serializable;

public class ExtendedDemographicChange implements Serializable {
	private static final long serialVersionUID = -3668072499830857458L;
	
	
}
