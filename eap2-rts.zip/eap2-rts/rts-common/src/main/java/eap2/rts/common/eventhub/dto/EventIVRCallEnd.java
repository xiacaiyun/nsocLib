package eap2.rts.common.eventhub.dto;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonProperty;

public class EventIVRCallEnd implements Serializable {
	private static final long serialVersionUID = -5344318245745907310L;
	
	@JsonProperty("Standard")
	private StandardIVRCallEnd Standard;
	@JsonProperty("CustomerAccess")
    private CustomerAccessIVRCallEnd CustomerAccess;
	@JsonProperty("Extended")
    private ExtendedIVRCallEnd Extended;
	@JsonProperty("Metadata")
    private MetadataIVRCallEnd Metadata;

    public StandardIVRCallEnd getStandard ()
    {
        return Standard;
    }

    public void setStandard (StandardIVRCallEnd Standard)
    {
        this.Standard = Standard;
    }

    public CustomerAccessIVRCallEnd getCustomerAccess ()
    {
        return CustomerAccess;
    }

    public void setCustomerAccess (CustomerAccessIVRCallEnd CustomerAccess)
    {
        this.CustomerAccess = CustomerAccess;
    }

    public ExtendedIVRCallEnd getExtended ()
    {
        return Extended;
    }

    public void setExtended (ExtendedIVRCallEnd Extended)
    {
        this.Extended = Extended;
    }

    public MetadataIVRCallEnd getMetadata ()
    {
        return Metadata;
    }

    public void setMetadata (MetadataIVRCallEnd Metadata)
    {
        this.Metadata = Metadata;
    }

    @Override
    public String toString()
    {
        return "ClassPojo [Standard = "+Standard+", CustomerAccess = "+CustomerAccess+", Extended = "+Extended+", Metadata = "+Metadata+"]";
    }
}
