package eap2.rts.common.eventhub.dto;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonProperty;

public class EventRewardRedemptionAccess implements Serializable {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = -3600969222562028545L;
	@JsonProperty("Standard")
	private StandardRewardRedemptionAccess Standard;
	@JsonProperty("CustomerAccess")
    private CustomerAccessRewardRedemptionAccess CustomerAccess;
	@JsonProperty("Extended")
    private ExtendedRewardRedemptionAccess Extended;
	@JsonProperty("Metadata")
    private MetadataRewardRedemptionAccess Metadata;
	public StandardRewardRedemptionAccess getStandard() {
		return Standard;
	}
	public void setStandard(StandardRewardRedemptionAccess standard) {
		Standard = standard;
	}
	public CustomerAccessRewardRedemptionAccess getCustomerAccess() {
		return CustomerAccess;
	}
	public void setCustomerAccess(CustomerAccessRewardRedemptionAccess customerAccess) {
		CustomerAccess = customerAccess;
	}
	public ExtendedRewardRedemptionAccess getExtended() {
		return Extended;
	}
	public void setExtended(ExtendedRewardRedemptionAccess extended) {
		Extended = extended;
	}
	public MetadataRewardRedemptionAccess getMetadata() {
		return Metadata;
	}
	public void setMetadata(MetadataRewardRedemptionAccess metadata) {
		Metadata = metadata;
	}
	@Override
	public String toString() {
		return "EventRewardRedemptionAccess [Standard=" + Standard + ", CustomerAccess=" + CustomerAccess
				+ ", Extended=" + Extended + ", Metadata=" + Metadata + "]";
	}
	
	
}
