package eap2.rts.common.eventhub.dto;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonProperty;

public class EventEstatementView implements Serializable {
	private static final long serialVersionUID = -8080374004007519155L;
	
	@JsonProperty("Standard")
	private StandardEstatementView Standard;
	@JsonProperty("CustomerAccess")
    private CustomerAccessEstatementView CustomerAccess;
	@JsonProperty("Extended")
    private ExtendedEstatementView Extended;
	@JsonProperty("Metadata")
    private MetadataEstatementView Metadata;

    public StandardEstatementView getStandard ()
    {
        return Standard;
    }

    public void setStandard (StandardEstatementView Standard)
    {
        this.Standard = Standard;
    }

    public CustomerAccessEstatementView getCustomerAccess ()
    {
        return CustomerAccess;
    }

    public void setCustomerAccess (CustomerAccessEstatementView CustomerAccess)
    {
        this.CustomerAccess = CustomerAccess;
    }

    public ExtendedEstatementView getExtended ()
    {
        return Extended;
    }

    public void setExtended (ExtendedEstatementView Extended)
    {
        this.Extended = Extended;
    }

    public MetadataEstatementView getMetadata ()
    {
        return Metadata;
    }

    public void setMetadata (MetadataEstatementView Metadata)
    {
        this.Metadata = Metadata;
    }

    @Override
    public String toString()
    {
        return "ClassPojo [Standard = "+Standard+", CustomerAccess = "+CustomerAccess+", Extended = "+Extended+", Metadata = "+Metadata+"]";
    }
}
