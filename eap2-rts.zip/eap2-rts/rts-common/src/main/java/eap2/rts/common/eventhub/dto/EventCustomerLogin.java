package eap2.rts.common.eventhub.dto;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonProperty;

public class EventCustomerLogin implements Serializable {
	private static final long serialVersionUID = 555937496082675770L;
	
	@JsonProperty("Standard")
	private StandardCustomerLogin Standard;
	@JsonProperty("CustomerAccess")
    private CustomerAccessCustomerLogin CustomerAccess;
	@JsonProperty("Extended")
    private ExtendedCustomerLogin Extended;
	@JsonProperty("Metadata")
    private MetadataCustomerLogin Metadata;

    public StandardCustomerLogin getStandard ()
    {
        return Standard;
    }

    public void setStandard (StandardCustomerLogin Standard)
    {
        this.Standard = Standard;
    }

    public CustomerAccessCustomerLogin getCustomerAccess ()
    {
        return CustomerAccess;
    }

    public void setCustomerAccess (CustomerAccessCustomerLogin CustomerAccess)
    {
        this.CustomerAccess = CustomerAccess;
    }

    public ExtendedCustomerLogin getExtended ()
    {
        return Extended;
    }

    public void setExtended (ExtendedCustomerLogin Extended)
    {
        this.Extended = Extended;
    }

    public MetadataCustomerLogin getMetadata ()
    {
        return Metadata;
    }

    public void setMetadata (MetadataCustomerLogin Metadata)
    {
        this.Metadata = Metadata;
    }

    @Override
    public String toString()
    {
        return "ClassPojo [Standard = "+Standard+", CustomerAccess = "+CustomerAccess+", Extended = "+Extended+", Metadata = "+Metadata+"]";
    }
}
