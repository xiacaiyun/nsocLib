package eap2.rts.common.event.dto;

import com.fasterxml.jackson.annotation.JsonProperty;

public class PossibleReasonRequest {

	private static final long serialVersionUID = 5775761644659932852L;

	@JsonProperty("GetReason")
	private GetReason getReason;

	@JsonProperty("GetReason")
	public GetReason getGetReason() {
		return getReason;
	}

	@JsonProperty("GetReason")
	public void setGetReason(GetReason getReason) {
		this.getReason = getReason;
	}

	@Override
	public String toString() {
		return "PossibleReasonRequest [getReason=" + getReason + "]";
	}

}
