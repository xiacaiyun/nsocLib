package eap2.rts.common.eventhub.dto;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonProperty;

public class DemographicChangeRequest implements Serializable {
	private static final long serialVersionUID = 3601307228244184098L;
	
	@JsonProperty("Event")
	private EventDemographicChange event;
	
	public EventDemographicChange getEvent() {
		return event;
	}
	public void setEvent(EventDemographicChange event) {
		this.event = event;
	}
	@Override
	public String toString() {
		return "DemographicChangeRequest [event=" + event + "]";
	}
}
