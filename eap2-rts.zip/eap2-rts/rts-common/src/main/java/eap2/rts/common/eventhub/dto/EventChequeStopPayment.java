package eap2.rts.common.eventhub.dto;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonProperty;

public class EventChequeStopPayment implements Serializable {
	private static final long serialVersionUID = -7262369779513403287L;
	
	@JsonProperty("Standard")
	private StandardChequeStopPayment Standard;
	@JsonProperty("CustomerAccess")
    private CustomerAccessChequeStopPayment CustomerAccess;
	@JsonProperty("Extended")
    private ExtendedChequeStopPayment Extended;
	@JsonProperty("Metadata")
    private MetadataChequeStopPayment Metadata;

    public StandardChequeStopPayment getStandard ()
    {
        return Standard;
    }

    public void setStandard (StandardChequeStopPayment Standard)
    {
        this.Standard = Standard;
    }

    public CustomerAccessChequeStopPayment getCustomerAccess ()
    {
        return CustomerAccess;
    }

    public void setCustomerAccess (CustomerAccessChequeStopPayment CustomerAccess)
    {
        this.CustomerAccess = CustomerAccess;
    }

    public ExtendedChequeStopPayment getExtended ()
    {
        return Extended;
    }

    public void setExtended (ExtendedChequeStopPayment Extended)
    {
        this.Extended = Extended;
    }

    public MetadataChequeStopPayment getMetadata ()
    {
        return Metadata;
    }

    public void setMetadata (MetadataChequeStopPayment Metadata)
    {
        this.Metadata = Metadata;
    }

    @Override
    public String toString()
    {
        return "ClassPojo [Standard = "+Standard+", CustomerAccess = "+CustomerAccess+", Extended = "+Extended+", Metadata = "+Metadata+"]";
    }
}
