package eap2.rts.common.eventhub.dto;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonProperty;

public class EventDemographicChange implements Serializable {
	private static final long serialVersionUID = 7418601770846384177L;
	
	@JsonProperty("Standard")
	private StandardDemographicChange Standard;
	@JsonProperty("CustomerAccess")
    private CustomerAccessDemographicChange CustomerAccess;
	@JsonProperty("Extended")
    private ExtendedDemographicChange Extended;
	@JsonProperty("Metadata")
    private MetadataDemographicChange Metadata;

    public StandardDemographicChange getStandard ()
    {
        return Standard;
    }

    public void setStandard (StandardDemographicChange Standard)
    {
        this.Standard = Standard;
    }

    public CustomerAccessDemographicChange getCustomerAccess ()
    {
        return CustomerAccess;
    }

    public void setCustomerAccess (CustomerAccessDemographicChange CustomerAccess)
    {
        this.CustomerAccess = CustomerAccess;
    }

    public ExtendedDemographicChange getExtended ()
    {
        return Extended;
    }

    public void setExtended (ExtendedDemographicChange Extended)
    {
        this.Extended = Extended;
    }

    public MetadataDemographicChange getMetadata ()
    {
        return Metadata;
    }

    public void setMetadata (MetadataDemographicChange Metadata)
    {
        this.Metadata = Metadata;
    }

    @Override
    public String toString()
    {
        return "ClassPojo [Standard = "+Standard+", CustomerAccess = "+CustomerAccess+", Extended = "+Extended+", Metadata = "+Metadata+"]";
    }
}
