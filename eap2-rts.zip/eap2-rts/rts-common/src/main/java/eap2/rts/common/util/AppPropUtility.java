/**
 * 
 */
package eap2.rts.common.util;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

import org.apache.commons.configuration.CompositeConfiguration;
import org.apache.commons.configuration.Configuration;
import org.apache.commons.configuration.ConfigurationException;
import org.apache.commons.configuration.PropertiesConfiguration;
import org.apache.log4j.Logger;

public class AppPropUtility {

	protected static Logger logger = Logger.getLogger(AppPropUtility.class.getName());

	public static Map<String, String> loadProperties(final String configFileName) throws ConfigurationException{
		logger.info("Inside Utility->>>>>loadProperties->>>>>");
		System.out.println("Config File Name = " + configFileName);
		CompositeConfiguration config = new CompositeConfiguration();
		Configuration appConfig = new PropertiesConfiguration(configFileName);
		config.addConfiguration(appConfig);
		Map<String, String> configMap = new HashMap<String, String>();
		Iterator keys = config.getKeys();
		while (keys.hasNext()) {
			String key = (String) keys.next();
			String value = config.getString(key);
			configMap.put(key, value);
		}
		return configMap;
	}
}