package eap2.rts.common.eventhub.dto;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonProperty;

public class EstatementDispatchRequest implements Serializable {
	private static final long serialVersionUID = 8336193885126752451L;
	
	@JsonProperty("Event")
	private EventEstatementDispatch event;
	
	public EventEstatementDispatch getEvent() {
		return event;
	}
	public void setEvent(EventEstatementDispatch event) {
		this.event = event;
	}
	@Override
	public String toString() {
		return "EstatementDispatchRequest [event=" + event + "]";
	}
}
