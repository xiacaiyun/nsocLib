package eap2.rts.common.eventhub.dto;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonProperty;

public class EventEPPLOPOfferView  implements Serializable {
	
	private static final long serialVersionUID = -7030702635654278542L;
	
	@JsonProperty("Standard")
	private StandardEPPLOPOfferView Standard;
	@JsonProperty("Metadata")
    private MetadataEPPLOPOfferView Metadata;
	@JsonProperty("CustomerAccess")
    private CustomerAccessEPPLOPOfferView CustomerAccess;
	@JsonProperty("Extended")
    private ExtendedEPPLOPOfferView Extended;
	
	public StandardEPPLOPOfferView getStandard() {
		return Standard;
	}
	public void setStandard(StandardEPPLOPOfferView standard) {
		Standard = standard;
	}
	public CustomerAccessEPPLOPOfferView getCustomerAccess() {
		return CustomerAccess;
	}
	public void setCustomerAccess(CustomerAccessEPPLOPOfferView customerAccess) {
		CustomerAccess = customerAccess;
	}
	public ExtendedEPPLOPOfferView getExtended() {
		return Extended;
	}
	public void setExtended(ExtendedEPPLOPOfferView extended) {
		Extended = extended;
	}
	public MetadataEPPLOPOfferView getMetadata() {
		return Metadata;
	}
	public void setMetadata(MetadataEPPLOPOfferView metadata) {
		Metadata = metadata;
	}
	@Override
	public String toString() {
		return "EventEPPLOPOfferView [Standard=" + Standard + ", CustomerAccess=" + CustomerAccess + ", Extended="
				+ Extended + ", Metadata=" + Metadata + "]";
	}
	
	
	
}
