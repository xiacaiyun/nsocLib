package eap2.rts.common.appconfig.dao.ora;

import java.sql.ResultSet;
import java.sql.SQLException;

import eap2.rts.common.appconfig.dao.DTOBuilder;
import eap2.rts.common.appconfig.dto.AppDS;
import eap2.rts.common.appconfig.dto.AppDSDetail;
import eap2.rts.common.appconfig.dto.AppDSEvent;
import eap2.rts.common.appconfig.dto.AppParam;
import eap2.rts.common.appconfig.dto.Application;
import eap2.rts.common.appconfig.dto.EventAction;
import eap2.rts.common.appconfig.dto.EventActionDetail;
import eap2.rts.common.appconfig.dto.TenantAppParam;

public class DTOBuilderHelper {

	static public DTOBuilder intObjectBuilder = new DTOBuilder() {
		public Object transform(Object rs) throws SQLException {
			Integer appId = null;
			ResultSet resultSet = (ResultSet) rs;
			appId = resultSet.getInt(1);
			return appId;
		}
	};

	static public DTOBuilder applicationDTOBuilder = new DTOBuilder() {
		public Object transform(Object rs) throws SQLException {
			Application appConfig = new Application();
			ResultSet resultSet = (ResultSet) rs;
			appConfig.setId(resultSet.getInt("id"));
			appConfig.setName(resultSet.getString("name"));
			appConfig.setTenantId(resultSet.getInt("tenant_id"));
			appConfig.setDescription(resultSet.getString("description"));
			appConfig.setVoidInd(resultSet.getString("void_ind"));
			return appConfig;
		}
	};

	static public DTOBuilder tenantAppParamDTOBuilder = new DTOBuilder() {
		public Object transform(Object rs) throws SQLException {
			TenantAppParam tenantAppParam = new TenantAppParam();
			ResultSet resultSet = (ResultSet) rs;
			tenantAppParam.setId(resultSet.getInt("id"));
			tenantAppParam.setTenantId(resultSet.getInt("tenant_id"));
			tenantAppParam.setParamTypeCode(resultSet.getString("param_type_code"));
			tenantAppParam.setParamName(resultSet.getString("param_name"));
			tenantAppParam.setParamValue(resultSet.getString("param_value"));
			return tenantAppParam;
		}
	};

	static public DTOBuilder appParamDTOBuilder = new DTOBuilder() {
		public Object transform(Object rs) throws SQLException {
			AppParam appParam = new AppParam();
			ResultSet resultSet = (ResultSet) rs;
			appParam.setId(resultSet.getInt("id"));
			appParam.setAppId(resultSet.getInt("app_id"));
			appParam.setParamTypeCode(resultSet.getString("param_type_code"));
			appParam.setParamName(resultSet.getString("param_name"));
			appParam.setParamValue(resultSet.getString("param_value"));
			appParam.setDescription(resultSet.getString("description"));
			return appParam;
		}
	};

	static public DTOBuilder appEventDTOBuilder = new DTOBuilder() {
		public Object transform(Object rs) throws SQLException {
			AppDSEvent appDSEvent = new AppDSEvent();
			ResultSet resultSet = (ResultSet) rs;
			appDSEvent.setId(resultSet.getInt("id"));
			appDSEvent.setName(resultSet.getString("name"));
			appDSEvent.setAppDSId(resultSet.getInt("app_ds_id"));
			appDSEvent.setEventTypeCode(resultSet.getString("event_type_code"));
			appDSEvent.setDescription(resultSet.getString("description"));
			return appDSEvent;
		}
	};
	
	static public DTOBuilder appDSDTOBuilder = new DTOBuilder() {
		public Object transform(Object rs) throws SQLException {
			AppDS appDS = new AppDS();
			ResultSet resultSet = (ResultSet) rs;
			appDS.setId(resultSet.getInt("id"));
			appDS.setName(resultSet.getString("name"));
			appDS.setAppId(resultSet.getInt("app_id"));
			appDS.setDsTypeCode(resultSet.getString("ds_type_code"));
			appDS.setDescription(resultSet.getString("description"));
			appDS.setDefaultEvent(resultSet.getString("default_event"));
			return appDS;
		}
	};

	static public DTOBuilder appDSDetailDTOBuilder = new DTOBuilder() {
		public Object transform(Object rs) throws SQLException {
			AppDSDetail appDSDetail = new AppDSDetail();
			ResultSet resultSet = (ResultSet) rs;
			appDSDetail.setId(resultSet.getInt("id"));
			appDSDetail.setAppDSId(resultSet.getInt("app_ds_id"));
			appDSDetail.setParamName(resultSet.getString("param_name"));
			appDSDetail.setParamValue(resultSet.getString("param_value"));
			appDSDetail.setValueEncrypted(resultSet.getString("value_encrypted"));
			return appDSDetail;
		}
	};

	static public DTOBuilder eventActionDTOBuilder = new DTOBuilder() {
		public Object transform(Object rs) throws SQLException {
			EventAction eventAction = new EventAction();
			ResultSet resultSet = (ResultSet) rs;
			eventAction.setId(resultSet.getInt("id"));
			eventAction.setAppEventId(resultSet.getInt("app_event_id"));
			eventAction.setActionTypeCode(resultSet.getString("action_type_code"));
			eventAction.setExecOrder(resultSet.getInt("exec_order"));
			return eventAction;
		}
	};

	static public DTOBuilder eventActionDetailBuilder = new DTOBuilder() {
		public Object transform(Object rs) throws SQLException {
			EventActionDetail eventActionDetail = new EventActionDetail();
			ResultSet resultSet = (ResultSet) rs;
			eventActionDetail.setId(resultSet.getInt("id"));
			eventActionDetail.setEventActionId(resultSet.getInt("event_action_id"));
			eventActionDetail.setParamName(resultSet.getString("param_name"));
			eventActionDetail.setParamValue(resultSet.getString("param_value"));
			eventActionDetail.setValueEncrypted(resultSet.getString("value_encrypted"));
			return eventActionDetail;
		}
	};	
}