package eap2.rts.common.eventhub.dto;

import java.io.Serializable;

public class ExtendedReportLostStolen implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1911515353967490927L;

}
