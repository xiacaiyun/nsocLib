package eap2.rts.common.eventhub.dto;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonProperty;

public class ExtendedPaymentAndTransfer implements Serializable{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 508989893439566593L;
	@JsonProperty("SourceAccountNo")
    private String SourceAccountNo;
	@JsonProperty("DestinationAccountNo")
    private String DestinationAccountNo;
	@JsonProperty("PaymentAmount")
	private String PaymentAmount;
	@JsonProperty("Currency")
    private String Currency;
	public String getSourceAccountNo() {
		return SourceAccountNo;
	}
	public void setSourceAccountNo(String sourceAccountNo) {
		SourceAccountNo = sourceAccountNo;
	}
	public String getDestinationAccountNo() {
		return DestinationAccountNo;
	}
	public void setDestinationAccountNo(String destinationAccountNo) {
		DestinationAccountNo = destinationAccountNo;
	}
	public String getPaymentAmount() {
		return PaymentAmount;
	}
	public void setPaymentAmount(String paymentAmount) {
		PaymentAmount = paymentAmount;
	}
	public String getCurrency() {
		return Currency;
	}
	public void setCurrency(String currency) {
		Currency = currency;
	}
	@Override
	public String toString() {
		return "ExtendedPaymentAndTransfer [SourceAccountNo=" + SourceAccountNo + ", DestinationAccountNo="
				+ DestinationAccountNo + ", PaymentAmount=" + PaymentAmount + ", Currency=" + Currency + "]";
	}


	
	
}
