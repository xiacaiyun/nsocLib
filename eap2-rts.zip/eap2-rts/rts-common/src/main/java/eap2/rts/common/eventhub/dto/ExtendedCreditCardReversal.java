package eap2.rts.common.eventhub.dto;

import java.io.Serializable;

public class ExtendedCreditCardReversal implements Serializable {
	private static final long serialVersionUID = -8848831913900243632L;
	
	
}
