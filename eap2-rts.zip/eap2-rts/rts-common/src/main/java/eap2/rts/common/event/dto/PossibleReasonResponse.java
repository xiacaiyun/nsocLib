package eap2.rts.common.event.dto;

import java.io.Serializable;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonProperty;

public class PossibleReasonResponse implements Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = 6113899119594398741L;
	private String errorcode;
	private String errordescription;
	
	private String CustomerID;
	
	private String CoutryCode;
	
	private List<PredictReason> PredictedReason;

	public String getErrorcode() {
		return errorcode;
	}

	public void setErrorcode(String errorcode) {
		this.errorcode = errorcode;
	}

	public String getErrordescription() {
		return errordescription;
	}

	public void setErrordescription(String errordescription) {
		this.errordescription = errordescription;
	}

	public String getCustomerid() {
		return CustomerID;
	}
	@JsonProperty("CustomerID")
	public void setCustomerid(String customerid) {
		this.CustomerID = customerid;
	}

	public String getCoutrycode() {
		return CoutryCode;
	}
	@JsonProperty("CoutryCode")
	public void setCoutrycode(String coutrycode) {
		this.CoutryCode = coutrycode;
	}

	public List<PredictReason> getPredictedreason() {
		return PredictedReason;
	}
	@JsonProperty("PredictedReason")
	public void setPredictedreason(List<PredictReason> reasonList) {
		this.PredictedReason = reasonList;
	}

}
