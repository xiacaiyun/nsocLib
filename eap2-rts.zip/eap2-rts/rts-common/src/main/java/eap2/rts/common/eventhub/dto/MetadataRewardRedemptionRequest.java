package eap2.rts.common.eventhub.dto;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonProperty;

public class MetadataRewardRedemptionRequest implements Serializable {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = -4479200393004710026L;
	@JsonProperty("OriginatorFunctionID")
    private String OriginatorFunctionID;
	@JsonProperty("OriginatorSubFunctionID")
    private String OriginatorSubFunctionID;
	@JsonProperty("OriginatorFunctionType")
    private String OriginatorFunctionType;
	@JsonProperty("OriginatorFunctionSubType")
	private String OriginatorFunctionSubType;

    public String getOriginatorFunctionSubType ()
    {
        return OriginatorFunctionSubType;
    }

    public void setOriginatorFunctionSubType (String OriginatorFunctionSubType)
    {
        this.OriginatorFunctionSubType = OriginatorFunctionSubType;
    }

    public String getOriginatorFunctionID ()
    {
        return OriginatorFunctionID;
    }

    public void setOriginatorFunctionID (String OriginatorFunctionID)
    {
        this.OriginatorFunctionID = OriginatorFunctionID;
    }

    public String getOriginatorFunctionType ()
    {
        return OriginatorFunctionType;
    }

    public void setOriginatorFunctionType (String OriginatorFunctionType)
    {
        this.OriginatorFunctionType = OriginatorFunctionType;
    }

    public String getOriginatorSubFunctionID ()
    {
        return OriginatorSubFunctionID;
    }

    public void setOriginatorSubFunctionID (String OriginatorSubFunctionID)
    {
        this.OriginatorSubFunctionID = OriginatorSubFunctionID;
    }

    @Override
    public String toString()
    {
        return "ClassPojo [OriginatorFunctionSubType = "+OriginatorFunctionSubType+", OriginatorFunctionID = "+OriginatorFunctionID+", OriginatorFunctionType = "+OriginatorFunctionType+", OriginatorSubFunctionID = "+OriginatorSubFunctionID+"]";
    }
}
