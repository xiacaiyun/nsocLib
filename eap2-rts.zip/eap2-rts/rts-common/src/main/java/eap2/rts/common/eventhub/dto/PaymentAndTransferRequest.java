package eap2.rts.common.eventhub.dto;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonProperty;

public class PaymentAndTransferRequest implements Serializable {
	
	private static final long serialVersionUID = 2174877603564919300L;
	@JsonProperty("Event")
	private EventPaymentAndTransfer event;
	
	public EventPaymentAndTransfer getEvent() {
		return event;
	}
	public void setEvent(EventPaymentAndTransfer event) {
		this.event = event;
	}
	@Override
	public String toString() {
		return "PaymentAndTransferRequest [event=" + event + "]";
	}
}
