package eap2.rts.common.eventhub.dto;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonProperty;

public class SMSEmailOffersRequest implements Serializable {
	private static final long serialVersionUID = -4637495733319828986L;
	
	@JsonProperty("Event")
	private EventSMSEmailOffers event;
	
	public EventSMSEmailOffers getEvent() {
		return event;
	}
	public void setEvent(EventSMSEmailOffers event) {
		this.event = event;
	}
	@Override
	public String toString() {
		return "SMSEmailOffersRequest [event=" + event + "]";
	}
}
