package eap2.rts.common.appconfig.dto;

import java.io.Serializable;

public class EventDSDetail implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 372039499172015235L;
	private Integer id;
	private Integer appEventId;
	private String paramName;
	private String paramValue;
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public Integer getAppEventId() {
		return appEventId;
	}
	public void setAppEventId(Integer appEventId) {
		this.appEventId = appEventId;
	}
	public String getParamName() {
		return paramName;
	}
	public void setParamName(String paramName) {
		this.paramName = paramName;
	}
	public String getParamValue() {
		return paramValue;
	}
	public void setParamValue(String paramValue) {
		this.paramValue = paramValue;
	}
	@Override
	public String toString() {
		return "EventDSDetail [id=" + id + ", appEventId=" + appEventId + ", paramName=" + paramName + ", paramValue=" + paramValue + "]";
	}

	
}
