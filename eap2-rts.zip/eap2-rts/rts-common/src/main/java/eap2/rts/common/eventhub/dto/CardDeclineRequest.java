package eap2.rts.common.eventhub.dto;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonProperty;

public class CardDeclineRequest implements Serializable {
	private static final long serialVersionUID = 1552486537662360613L;
	
	@JsonProperty("Event")
	private EventCardDecline event;
	
	public EventCardDecline getEvent() {
		return event;
	}
	public void setEvent(EventCardDecline event) {
		this.event = event;
	}
	@Override
	public String toString() {
		return "CardDeclineRequest [event=" + event + "]";
	}
}
