package eap2.rts.common.eventhub.dto;

import java.io.Serializable;

public class ExtendedOverseasCardActivation implements Serializable {
	private static final long serialVersionUID = 3362522626166222039L;
	
	
}
