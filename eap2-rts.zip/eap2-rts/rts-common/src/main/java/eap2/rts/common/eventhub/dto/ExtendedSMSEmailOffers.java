package eap2.rts.common.eventhub.dto;

import java.io.Serializable;

public class ExtendedSMSEmailOffers implements Serializable {
	private static final long serialVersionUID = 3362522618566222039L;
	
	
}
