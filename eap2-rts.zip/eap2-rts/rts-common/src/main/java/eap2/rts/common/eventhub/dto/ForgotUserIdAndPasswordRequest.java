package eap2.rts.common.eventhub.dto;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonProperty;

public class ForgotUserIdAndPasswordRequest implements Serializable {
	private static final long serialVersionUID = 5553100243065995743L;
	
	@JsonProperty("Event")
	private EventForgotUserIdAndPassword event;
	
	public EventForgotUserIdAndPassword getEvent() {
		return event;
	}
	public void setEvent(EventForgotUserIdAndPassword event) {
		this.event = event;
	}
	@Override
	public String toString() {
		return "ForgotUserIdAndPasswordRequest [event=" + event + "]";
	}
}
