package eap2.rts.common.eventhub.dto;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonProperty;

public class EventCBOLMBOLRegistration implements Serializable {
	private static final long serialVersionUID = 1862613073637734010L;
	
	@JsonProperty("Standard")
	private StandardCBOLMBOLRegistration Standard;
	@JsonProperty("CustomerAccess")
    private CustomerAccessCBOLMBOLRegistration CustomerAccess;
	@JsonProperty("Extended")
    private ExtendedCBOLMBOLRegistration Extended;
	@JsonProperty("Metadata")
    private MetadataCBOLMBOLRegistration Metadata;

    public StandardCBOLMBOLRegistration getStandard ()
    {
        return Standard;
    }

    public void setStandard (StandardCBOLMBOLRegistration Standard)
    {
        this.Standard = Standard;
    }

    public CustomerAccessCBOLMBOLRegistration getCustomerAccess ()
    {
        return CustomerAccess;
    }

    public void setCustomerAccess (CustomerAccessCBOLMBOLRegistration CustomerAccess)
    {
        this.CustomerAccess = CustomerAccess;
    }

    public ExtendedCBOLMBOLRegistration getExtended ()
    {
        return Extended;
    }

    public void setExtended (ExtendedCBOLMBOLRegistration Extended)
    {
        this.Extended = Extended;
    }

    public MetadataCBOLMBOLRegistration getMetadata ()
    {
        return Metadata;
    }

    public void setMetadata (MetadataCBOLMBOLRegistration Metadata)
    {
        this.Metadata = Metadata;
    }

    @Override
    public String toString()
    {
        return "ClassPojo [Standard = "+Standard+", CustomerAccess = "+CustomerAccess+", Extended = "+Extended+", Metadata = "+Metadata+"]";
    }
}
