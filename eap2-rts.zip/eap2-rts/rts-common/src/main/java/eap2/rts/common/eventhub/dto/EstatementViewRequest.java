package eap2.rts.common.eventhub.dto;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonProperty;

public class EstatementViewRequest implements Serializable {
	private static final long serialVersionUID = 8070302841471734401L;
	
	@JsonProperty("Event")
	private EventEstatementView event;
	
	public EventEstatementView getEvent() {
		return event;
	}
	public void setEvent(EventEstatementView event) {
		this.event = event;
	}
	@Override
	public String toString() {
		return "EstatementViewRequest [event=" + event + "]";
	}
}
