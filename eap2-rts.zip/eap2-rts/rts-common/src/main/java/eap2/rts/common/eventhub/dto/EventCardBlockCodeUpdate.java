package eap2.rts.common.eventhub.dto;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonProperty;

public class EventCardBlockCodeUpdate implements Serializable {
	private static final long serialVersionUID = 2712793706249495547L;
	
	@JsonProperty("Standard")
	private StandardCardBlockCodeUpdate Standard;
	@JsonProperty("CustomerAccess")
    private CustomerAccessCardBlockCodeUpdate CustomerAccess;
	@JsonProperty("Extended")
    private ExtendedCardBlockCodeUpdate Extended;
	@JsonProperty("Metadata")
    private MetadataCardBlockCodeUpdate Metadata;

    public StandardCardBlockCodeUpdate getStandard ()
    {
        return Standard;
    }

    public void setStandard (StandardCardBlockCodeUpdate Standard)
    {
        this.Standard = Standard;
    }

    public CustomerAccessCardBlockCodeUpdate getCustomerAccess ()
    {
        return CustomerAccess;
    }

    public void setCustomerAccess (CustomerAccessCardBlockCodeUpdate CustomerAccess)
    {
        this.CustomerAccess = CustomerAccess;
    }

    public ExtendedCardBlockCodeUpdate getExtended ()
    {
        return Extended;
    }

    public void setExtended (ExtendedCardBlockCodeUpdate Extended)
    {
        this.Extended = Extended;
    }

    public MetadataCardBlockCodeUpdate getMetadata ()
    {
        return Metadata;
    }

    public void setMetadata (MetadataCardBlockCodeUpdate Metadata)
    {
        this.Metadata = Metadata;
    }

    @Override
    public String toString()
    {
        return "ClassPojo [Standard = "+Standard+", CustomerAccess = "+CustomerAccess+", Extended = "+Extended+", Metadata = "+Metadata+"]";
    }
}
