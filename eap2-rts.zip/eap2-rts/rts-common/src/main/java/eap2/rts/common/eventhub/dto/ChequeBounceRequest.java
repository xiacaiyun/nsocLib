package eap2.rts.common.eventhub.dto;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonProperty;

public class ChequeBounceRequest implements Serializable {
	private static final long serialVersionUID = -3870950827852464258L;
	
	@JsonProperty("Event")
	private EventChequeBounce event;
	
	public EventChequeBounce getEvent() {
		return event;
	}
	public void setEvent(EventChequeBounce event) {
		this.event = event;
	}
	@Override
	public String toString() {
		return "ChequeBounceRequest [event=" + event + "]";
	}
}
