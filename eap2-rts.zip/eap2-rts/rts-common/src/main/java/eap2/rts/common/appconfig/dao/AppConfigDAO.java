package eap2.rts.common.appconfig.dao;

import java.util.List;
import java.util.Map;

import eap2.rts.common.appconfig.dto.AppDS;
import eap2.rts.common.appconfig.dto.AppDSDetail;
import eap2.rts.common.appconfig.dto.AppDSEvent;
import eap2.rts.common.appconfig.dto.Application;
import eap2.rts.common.appconfig.dto.EventAction;
import eap2.rts.common.appconfig.dto.EventActionDetail;
import eap2.rts.common.exception.AppConfigException;

public interface AppConfigDAO {
	public Integer getAppIdByAppName(String pAppName) throws AppConfigException;

	public Application getApplicationById(Integer appId) throws AppConfigException;

	public Map<String, Map<String, String>> getTenantAppParamsByAppId(Integer tenantId) throws AppConfigException;
	
	public Map<String, Map<String, String>> getAppParamsByAppId(Integer appId) throws AppConfigException;

	public List<AppDS> getAppDSByAppId(Integer appId) throws AppConfigException;
	
	public List<AppDSEvent> getAppEventByAppDSId(Integer appId) throws AppConfigException;

	public List<EventAction> getEventActionByEventId(Integer eventId) throws AppConfigException;

	public List<EventActionDetail> getActionDetailsByActionId(Integer actionId) throws AppConfigException;

	public List<AppDSDetail> getAppDSDetailByAppDSId(Integer eventId) throws AppConfigException;
	
}
