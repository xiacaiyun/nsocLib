package eap2.rts.common.eventhub.dto;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonProperty;

public class PreAuthRequest implements Serializable {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 106794775360451260L;
	@JsonProperty("Event")
	private EventPreAuth event;
	
	public EventPreAuth getEvent() {
		return event;
	}
	public void setEvent(EventPreAuth event) {
		this.event = event;
	}
	@Override
	public String toString() {
		return "PreAuthRequest [event=" + event + "]";
	}
}
