package eap2.rts.common.eventhub.dto;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonProperty;

public class IVRCallEndRequest implements Serializable {
	private static final long serialVersionUID = -7822394761406839979L;
	
	@JsonProperty("Event")
	private EventIVRCallEnd event;
	
	public EventIVRCallEnd getEvent() {
		return event;
	}
	public void setEvent(EventIVRCallEnd event) {
		this.event = event;
	}
	@Override
	public String toString() {
		return "IVRCallEndRequest [event=" + event + "]";
	}
}
