package eap2.rts.common.eventhub.dto;

import java.io.Serializable;

public class ExtendedSDNMatchResolved implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -2160907273519130803L;
	
	
}
