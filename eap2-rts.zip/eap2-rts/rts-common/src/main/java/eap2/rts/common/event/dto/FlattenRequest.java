package eap2.rts.common.event.dto;

import java.text.SimpleDateFormat;
import java.util.GregorianCalendar;

import com.google.gson.Gson;
import com.tibco.schemas.copsrainbow.sharedresources.schemas.eventschema.mretransaction.TransactionMRERes;

import eap2.rts.common.eventhub.dto.APINChangeFlat;
import eap2.rts.common.eventhub.dto.APINChangeRequest;
import eap2.rts.common.eventhub.dto.AccountLinkageFlat;
import eap2.rts.common.eventhub.dto.AccountLinkageRequest;
import eap2.rts.common.eventhub.dto.AccountSummaryFlat;
import eap2.rts.common.eventhub.dto.AccountSummaryRequest;
import eap2.rts.common.eventhub.dto.BillPaymentFlat;
import eap2.rts.common.eventhub.dto.BillPaymentRequest;
import eap2.rts.common.eventhub.dto.CBOLMBOLRegistrationFlat;
import eap2.rts.common.eventhub.dto.CBOLMBOLRegistrationRequest;
import eap2.rts.common.eventhub.dto.CardActivationFlat;
import eap2.rts.common.eventhub.dto.CardActivationRequest;
import eap2.rts.common.eventhub.dto.CardBlockCodeUpdateFlat;
import eap2.rts.common.eventhub.dto.CardBlockCodeUpdateRequest;
import eap2.rts.common.eventhub.dto.CardDeclineFlat;
import eap2.rts.common.eventhub.dto.CardDeclineRequest;
import eap2.rts.common.eventhub.dto.ChargeDisputeFlat;
import eap2.rts.common.eventhub.dto.ChargeDisputeRequest;
import eap2.rts.common.eventhub.dto.ChequeBounceFlat;
import eap2.rts.common.eventhub.dto.ChequeBounceRequest;
import eap2.rts.common.eventhub.dto.ChequeStopPaymentFlat;
import eap2.rts.common.eventhub.dto.ChequeStopPaymentRequest;
import eap2.rts.common.eventhub.dto.CpoCallEndFlat;
import eap2.rts.common.eventhub.dto.CpoCallEndRequest;
import eap2.rts.common.eventhub.dto.CpoCallStartFlat;
import eap2.rts.common.eventhub.dto.CpoCallStartRequest;
import eap2.rts.common.eventhub.dto.CreditCardClosureFlat;
import eap2.rts.common.eventhub.dto.CreditCardClosureRequest;
import eap2.rts.common.eventhub.dto.CreditCardReversalFlat;
import eap2.rts.common.eventhub.dto.CreditCardReversalRequest;
import eap2.rts.common.eventhub.dto.CreditLimitIncreaseFlat;
import eap2.rts.common.eventhub.dto.CreditLimitIncreaseRequest;
import eap2.rts.common.eventhub.dto.CustHWTokenFlat;
import eap2.rts.common.eventhub.dto.CustHWTokenRequest;
import eap2.rts.common.eventhub.dto.CustLoginIDStatusChangeFlat;
import eap2.rts.common.eventhub.dto.CustLoginIDStatusChangeRequest;
import eap2.rts.common.eventhub.dto.CustomerLoginFlat;
import eap2.rts.common.eventhub.dto.CustomerLoginRequest;
import eap2.rts.common.eventhub.dto.DemographicChangeFlat;
import eap2.rts.common.eventhub.dto.DemographicChangeRequest;
import eap2.rts.common.eventhub.dto.DigiPassInitiationFlat;
import eap2.rts.common.eventhub.dto.DigiPassInitiationRequest;
import eap2.rts.common.eventhub.dto.EPPLOPOfferViewFlat;
import eap2.rts.common.eventhub.dto.EPPLOPOfferViewRequest;
import eap2.rts.common.eventhub.dto.EstatementDispatchFlat;
import eap2.rts.common.eventhub.dto.EstatementDispatchRequest;
import eap2.rts.common.eventhub.dto.EstatementViewFlat;
import eap2.rts.common.eventhub.dto.EstatementViewRequest;
import eap2.rts.common.eventhub.dto.ForgotUserIdAndPasswordFlat;
import eap2.rts.common.eventhub.dto.ForgotUserIdAndPasswordRequest;
import eap2.rts.common.eventhub.dto.IVRCallEndFlat;
import eap2.rts.common.eventhub.dto.IVRCallEndRequest;
import eap2.rts.common.eventhub.dto.IVRCallStartFlat;
import eap2.rts.common.eventhub.dto.IVRCallStartRequest;
import eap2.rts.common.eventhub.dto.OnlineDirectDebitExecutionFlat;
import eap2.rts.common.eventhub.dto.OnlineDirectDebitExecutionRequest;
import eap2.rts.common.eventhub.dto.OverseasCardActivationFlat;
import eap2.rts.common.eventhub.dto.OverseasCardActivationRequest;
import eap2.rts.common.eventhub.dto.PINValidationFlat;
import eap2.rts.common.eventhub.dto.PINValidationRequest;
import eap2.rts.common.eventhub.dto.PaymentAndTransferFlat;
import eap2.rts.common.eventhub.dto.PaymentAndTransferRequest;
import eap2.rts.common.eventhub.dto.PreAuthFlat;
import eap2.rts.common.eventhub.dto.PreAuthRequest;
import eap2.rts.common.eventhub.dto.ReportLostStolenFlat;
import eap2.rts.common.eventhub.dto.ReportLostStolenRequest;
import eap2.rts.common.eventhub.dto.RewardRedemptionAccessFlat;
import eap2.rts.common.eventhub.dto.RewardRedemptionAccessRequest;
import eap2.rts.common.eventhub.dto.RewardRedemptionRequestFlat;
import eap2.rts.common.eventhub.dto.RewardRedemptionRequestRequest;
import eap2.rts.common.eventhub.dto.SDNMatchFoundFlat;
import eap2.rts.common.eventhub.dto.SDNMatchFoundRequest;
import eap2.rts.common.eventhub.dto.SDNMatchResolvedFlat;
import eap2.rts.common.eventhub.dto.SDNMatchResolvedRequest;
import eap2.rts.common.eventhub.dto.SMSEmailOffersFlat;
import eap2.rts.common.eventhub.dto.SMSEmailOffersRequest;
import eap2.rts.common.eventhub.dto.ServiceRequestFlat;
import eap2.rts.common.eventhub.dto.ServiceRequestRequest;
import eap2.rts.common.eventhub.dto.TPINCreateResetChangeIssuanceFlat;
import eap2.rts.common.eventhub.dto.TPINCreateResetChangeIssuanceRequest;
import eap2.rts.common.eventhub.dto.ViewTransactionsHistoryFlat;
import eap2.rts.common.eventhub.dto.ViewTransactionsHistoryRequest;

public class FlattenRequest {
	
	public TransactionMREFlatRes getTransactionMREFlatRes(TransactionMREFlatRes transactionMREFlatRes, TransactionMRERes transactionMRERes){
		//TransactionMREFlatRes transactionMREFlatRes = new TransactionMREFlatRes();
		
		if(transactionMRERes != null){
			
			transactionMREFlatRes.setCopTransactionID(transactionMRERes.getCOPTransactionID());
			transactionMREFlatRes.setCountryCode(transactionMRERes.getCountryCode());
			transactionMREFlatRes.setCustomerNo(transactionMRERes.getCustomerNo());
			transactionMREFlatRes.setAccountNo(transactionMRERes.getAccountNo());
			transactionMREFlatRes.setCardNo(transactionMRERes.getCardNo());
			transactionMREFlatRes.setGeoRecommendation(transactionMRERes.getGeoMerchantID());
			transactionMREFlatRes.setNonGeoRecommendation(transactionMRERes.getNonGeoMerchantID());
			transactionMREFlatRes.setFinancialTX(transactionMRERes.getFinancialTX());
			transactionMREFlatRes.setSituationValue(transactionMRERes.getSituationValue());
			transactionMREFlatRes.setFamily(transactionMRERes.getFamily());
		}
		
		
		if(transactionMRERes.getTransaction().getTransactionBank() != null){
			
			//Transaction Bank

			transactionMREFlatRes.setProductCode(transactionMRERes.getTransaction().getTransactionBank().getProductCode());
			transactionMREFlatRes.setProductProcessorCode(transactionMRERes.getTransaction().getTransactionBank().getProductProcessorCode());
			transactionMREFlatRes.setAccountNumber(transactionMRERes.getTransaction().getTransactionBank().getAccountNumber());
			transactionMREFlatRes.setAccountCurrencyCode(transactionMRERes.getTransaction().getTransactionBank().getAccountCurrencyCode());
			transactionMREFlatRes.setCustomerProf(transactionMRERes.getTransaction().getTransactionBank().getCustomerProf());
			transactionMREFlatRes.setAccountCurrency(transactionMRERes.getTransaction().getTransactionBank().getAccountCurrency());
			transactionMREFlatRes.setBranchCode(transactionMRERes.getTransaction().getTransactionBank().getBranchCode());
			transactionMREFlatRes.setAcqID(transactionMRERes.getTransaction().getTransactionBank().getAcqID());
			transactionMREFlatRes.setMerchantCity(transactionMRERes.getTransaction().getTransactionBank().getMerchantCity());
			transactionMREFlatRes.setMerchantCtry(transactionMRERes.getTransaction().getTransactionBank().getMerchantCtry());
			transactionMREFlatRes.setTermID(transactionMRERes.getTransaction().getTransactionBank().getTermID());
			transactionMREFlatRes.setMcc(transactionMRERes.getTransaction().getTransactionBank().getMCC());
			transactionMREFlatRes.setPoseMode(transactionMRERes.getTransaction().getTransactionBank().getPoseMode());
			transactionMREFlatRes.setTdMaturityDate(transactionMRERes.getTransaction().getTransactionBank().getTDMaturityDate());
			transactionMREFlatRes.setExpDate(transactionMRERes.getTransaction().getTransactionBank().getExpDate());
			transactionMREFlatRes.setOtherAcctNbr(transactionMRERes.getTransaction().getTransactionBank().getOtherAcctNbr());
			transactionMREFlatRes.setOtherProdCode(transactionMRERes.getTransaction().getTransactionBank().getOtherProdCode());
			transactionMREFlatRes.setOtherBankCode(transactionMRERes.getTransaction().getTransactionBank().getOtherBankCode());
			transactionMREFlatRes.setOtherBranchCode(transactionMRERes.getTransaction().getTransactionBank().getOtherBranchCode());
			transactionMREFlatRes.setOtherAcctName(transactionMRERes.getTransaction().getTransactionBank().getOtherAcctName());
			transactionMREFlatRes.setOtherAcctAdd1(transactionMRERes.getTransaction().getTransactionBank().getOtherAcctAdd1());
			transactionMREFlatRes.setOtherAcctAdd2(transactionMRERes.getTransaction().getTransactionBank().getOtherAcctAdd2());
			transactionMREFlatRes.setOtherAcctCity(transactionMRERes.getTransaction().getTransactionBank().getOtherAcctCity());
			transactionMREFlatRes.setOtherAcctState(transactionMRERes.getTransaction().getTransactionBank().getOtherAcctState());
			transactionMREFlatRes.setOtherAcctCtry(transactionMRERes.getTransaction().getTransactionBank().getOtherAcctCtry());
			transactionMREFlatRes.setOtherAcctZip(transactionMRERes.getTransaction().getTransactionBank().getOtherAcctZip());
			transactionMREFlatRes.setChequeNumber(transactionMRERes.getTransaction().getTransactionBank().getChequeNumber());
			transactionMREFlatRes.setChequeStatus(transactionMRERes.getTransaction().getTransactionBank().getChequeStatus());
			transactionMREFlatRes.setDuplicateChequeFlag(transactionMRERes.getTransaction().getTransactionBank().getDuplicateChequeFlag());
			transactionMREFlatRes.setFloatDays(transactionMRERes.getTransaction().getTransactionBank().getFloatDays());
			transactionMREFlatRes.setAcctBal(transactionMRERes.getTransaction().getTransactionBank().getAcctBal());
			transactionMREFlatRes.setAcctLedgBal(transactionMRERes.getTransaction().getTransactionBank().getAcctLedgBal());
			transactionMREFlatRes.setPersonalAmountThresholds(transactionMRERes.getTransaction().getTransactionBank().getPersonalAmountThresholds());
			transactionMREFlatRes.setUniqRefNbr(transactionMRERes.getTransaction().getTransactionBank().getUniqRefNbr());
			transactionMREFlatRes.setAccountStatus(transactionMRERes.getTransaction().getTransactionBank().getAccountStatus());
			transactionMREFlatRes.setAccountCloseRSN(transactionMRERes.getTransaction().getTransactionBank().getAccountCloseRSN());
			transactionMREFlatRes.setTrmDepMatDate(transactionMRERes.getTransaction().getTransactionBank().getTrmDepMatDate());
			transactionMREFlatRes.setOrg(transactionMRERes.getTransaction().getTransactionBank().getOrg());
			transactionMREFlatRes.setCashWithdrawalDays(transactionMRERes.getTransaction().getTransactionBank().getCashWithdrawalDays());
			transactionMREFlatRes.setCashWithdrawalPeriod(transactionMRERes.getTransaction().getTransactionBank().getCashWithdrawalPeriod());
			transactionMREFlatRes.setCashWithdrawalPercent(transactionMRERes.getTransaction().getTransactionBank().getCashWithdrawalPercent());
			transactionMREFlatRes.setPayeeBankCode(transactionMRERes.getTransaction().getTransactionBank().getPayeeBankCode());
			transactionMREFlatRes.setPayeeBankName(transactionMRERes.getTransaction().getTransactionBank().getPayeeBankName());
			transactionMREFlatRes.setPayeeBranchCode(transactionMRERes.getTransaction().getTransactionBank().getPayeeBranchCode());
			transactionMREFlatRes.setPayeeAccountNumber(transactionMRERes.getTransaction().getTransactionBank().getPayeeAccountNumber());
			transactionMREFlatRes.setPayeeName(transactionMRERes.getTransaction().getTransactionBank().getPayeeName());
			transactionMREFlatRes.setPaymentMode(transactionMRERes.getTransaction().getTransactionBank().getPaymentMode());
			transactionMREFlatRes.setBeginningCheckSerialNumber(transactionMRERes.getTransaction().getTransactionBank().getBeginningCheckSerialNumber());
			transactionMREFlatRes.setEndCheckSerialNumber(transactionMRERes.getTransaction().getTransactionBank().getEndCheckSerialNumber());
			transactionMREFlatRes.setDcemvFlag(transactionMRERes.getTransaction().getTransactionBank().getDCEMVFlag());
			transactionMREFlatRes.setDcFallBackCount(transactionMRERes.getTransaction().getTransactionBank().getDCFallBackCount());
			transactionMREFlatRes.setTsTransactionCode(transactionMRERes.getTransaction().getTransactionBank().getTSTransactionCode());
			transactionMREFlatRes.setLogOnCountry(transactionMRERes.getTransaction().getTransactionBank().getLogOnCountry());
			transactionMREFlatRes.setFundTransferType(transactionMRERes.getTransaction().getTransactionBank().getFundTransferType());
			transactionMREFlatRes.setReversalIndicator(transactionMRERes.getTransaction().getTransactionBank().getReversalIndicator());
			transactionMREFlatRes.setSourceApplication(transactionMRERes.getTransaction().getTransactionBank().getSourceApplication());
			transactionMREFlatRes.setBlockCode(transactionMRERes.getTransaction().getTransactionBank().getBlockCode());
			transactionMREFlatRes.setFirstTxnFlag(transactionMRERes.getTransaction().getTransactionBank().getFirstTxnFlag());
			transactionMREFlatRes.setDcExpiryDate(transactionMRERes.getTransaction().getTransactionBank().getDCExpiryDate());
			transactionMREFlatRes.setFillerField1(transactionMRERes.getTransaction().getTransactionBank().getFillerField1());
			transactionMREFlatRes.setFillerField2(transactionMRERes.getTransaction().getTransactionBank().getFillerField2());
			transactionMREFlatRes.setFillerField3(transactionMRERes.getTransaction().getTransactionBank().getFillerField3());
			transactionMREFlatRes.setFillerField4(transactionMRERes.getTransaction().getTransactionBank().getFillerField4());
			transactionMREFlatRes.setFillerField5(transactionMRERes.getTransaction().getTransactionBank().getFillerField5());
			transactionMREFlatRes.setUniqueId(transactionMRERes.getTransaction().getTransactionBank().getUniqueId());
			transactionMREFlatRes.setAuthText(transactionMRERes.getTransaction().getTransactionBank().getAuthText());
			transactionMREFlatRes.setTxnCntryDate(transactionMRERes.getTransaction().getTransactionBank().getTxnCntryDate());
			transactionMREFlatRes.setTxnSubChannel(transactionMRERes.getTransaction().getTransactionBank().getTxnSubChannel());
			transactionMREFlatRes.setTxnCntryTime(transactionMRERes.getTransaction().getTransactionBank().getTxnCntryTime());
			transactionMREFlatRes.setBizSegment(transactionMRERes.getTransaction().getTransactionBank().getBizSegment());
			transactionMREFlatRes.setSrcAcctStaffInd(transactionMRERes.getTransaction().getTransactionBank().getSrcAcctStaffInd());
			transactionMREFlatRes.setDestAcctStaffInd(transactionMRERes.getTransaction().getTransactionBank().getDestAcctStaffInd());
			transactionMREFlatRes.setDomicileCntryCD(transactionMRERes.getTransaction().getTransactionBank().getDomicileCntryCD());
			transactionMREFlatRes.setAcctZipCD(transactionMRERes.getTransaction().getTransactionBank().getAcctZipCD());
			transactionMREFlatRes.setBranchNbr(transactionMRERes.getTransaction().getTransactionBank().getBranchNbr());
			transactionMREFlatRes.setTxnEffDate(transactionMRERes.getTransaction().getTransactionBank().getTxnEffDate());
			transactionMREFlatRes.setTxnEffTime(transactionMRERes.getTransaction().getTransactionBank().getTxnEffTime());
			transactionMREFlatRes.setAvgAcctBal(transactionMRERes.getTransaction().getTransactionBank().getAcctBal());
			transactionMREFlatRes.setConsolidateAcctBal(transactionMRERes.getTransaction().getTransactionBank().getConsolidateAcctBal());
			transactionMREFlatRes.setPhoneNum(transactionMRERes.getTransaction().getTransactionBank().getPhoneNum());
			transactionMREFlatRes.settPinConf(transactionMRERes.getTransaction().getTransactionBank().getTPinConf());
			transactionMREFlatRes.setCpoId(transactionMRERes.getTransaction().getTransactionBank().getCpoId());
			transactionMREFlatRes.setEnrollPhInd(transactionMRERes.getTransaction().getTransactionBank().getEnrollPhInd());
			transactionMREFlatRes.setVerifyQuesIndF(transactionMRERes.getTransaction().getTransactionBank().getVerifyQuesIndF());
			transactionMREFlatRes.setVerifyQuesInd(transactionMRERes.getTransaction().getTransactionBank().getVerifyQuesInd());
			transactionMREFlatRes.setMerchIpAddress(transactionMRERes.getTransaction().getTransactionBank().getMerchIpAddress());
			transactionMREFlatRes.setUserTyp(transactionMRERes.getTransaction().getTransactionBank().getUserTyp());
			transactionMREFlatRes.setAtmLocation(transactionMRERes.getTransaction().getTransactionBank().getAtmLocation());
			transactionMREFlatRes.setEmvChipInd(transactionMRERes.getTransaction().getTransactionBank().getEmvChipInd());
			transactionMREFlatRes.setCustSsnNric(transactionMRERes.getTransaction().getTransactionBank().getCustSsnNric());
			transactionMREFlatRes.setBarcdInfo(transactionMRERes.getTransaction().getTransactionBank().getBarcdInfo());
			transactionMREFlatRes.setDebitType(transactionMRERes.getTransaction().getTransactionBank().getDebitType());
			transactionMREFlatRes.setLsnCode(transactionMRERes.getTransaction().getTransactionBank().getLsnCode());
			transactionMREFlatRes.setCenterCode(transactionMRERes.getTransaction().getTransactionBank().getCenterCode());
			transactionMREFlatRes.setRetnCode(transactionMRERes.getTransaction().getTransactionBank().getRetnCode());
			transactionMREFlatRes.setRetnMsg(transactionMRERes.getTransaction().getTransactionBank().getRetnMsg());
			transactionMREFlatRes.setTxnMode(transactionMRERes.getTransaction().getTransactionBank().getTxnMode());
			transactionMREFlatRes.setWalletDPAN(transactionMRERes.getTransaction().getTransactionBank().getWalletDPAN());
			transactionMREFlatRes.setWalletServInd(transactionMRERes.getTransaction().getTransactionBank().getWalletServInd());
			transactionMREFlatRes.setWalletTxnInd(transactionMRERes.getTransaction().getTransactionBank().getWalletTxnInd());
			transactionMREFlatRes.setPinFlag(transactionMRERes.getTransaction().getTransactionBank().getPinFlag());
			transactionMREFlatRes.setP2PTxnId(transactionMRERes.getTransaction().getTransactionBank().getP2PTxnId());

		}
		
		if(transactionMRERes.getTransaction().getTransactionCard() != null){
			
			//Transaction Card
			transactionMREFlatRes.setMerchantKey(transactionMRERes.getTransaction().getTransactionCard().getMerchantKey());
			transactionMREFlatRes.setMerchantOrg(transactionMRERes.getTransaction().getTransactionCard().getMerchantOrg());
			transactionMREFlatRes.setMerchantNumber(transactionMRERes.getTransaction().getTransactionCard().getMerchantNumber());
			transactionMREFlatRes.setOperatorID(transactionMRERes.getTransaction().getTransactionCard().getOperatorID());
			transactionMREFlatRes.setApprovalID(transactionMRERes.getTransaction().getTransactionCard().getApprovalID());
			transactionMREFlatRes.setOasatc(transactionMRERes.getTransaction().getTransactionCard().getOASATC());
			transactionMREFlatRes.setApprovalTC(transactionMRERes.getTransaction().getTransactionCard().getApprovalTC());
			transactionMREFlatRes.setVisaDeclineReferralTC(transactionMRERes.getTransaction().getTransactionCard().getVisaDeclineReferralTC());

			transactionMREFlatRes.setAmountType(transactionMRERes.getTransaction().getTransactionCard().getAddlRecTable().getRecords().get(0).getAmountType());
			transactionMREFlatRes.setAdditionalAmount(transactionMRERes.getTransaction().getTransactionCard().getAddlRecTable().getRecords().get(0).getAdditionalAmount());
			transactionMREFlatRes.setRecordCurrencyCode(transactionMRERes.getTransaction().getTransactionCard().getAddlRecTable().getRecords().get(0).getCurrencyCode());
			transactionMREFlatRes.setAccountType(transactionMRERes.getTransaction().getTransactionCard().getAddlRecTable().getRecords().get(0).getAccountType());
			
			transactionMREFlatRes.setMasterApprovalTC(transactionMRERes.getTransaction().getTransactionCard().getMasterApprovalTC());
			transactionMREFlatRes.setMasterDeclineTC(transactionMRERes.getTransaction().getTransactionCard().getMasterDeclineTC());
			transactionMREFlatRes.setJcbApprovalTC(transactionMRERes.getTransaction().getTransactionCard().getJCBApprovalTC());
			transactionMREFlatRes.setFromAccountCode(transactionMRERes.getTransaction().getTransactionCard().getFromAccountCode());
			transactionMREFlatRes.setToAccountCode(transactionMRERes.getTransaction().getTransactionCard().getToAccountCode());
			transactionMREFlatRes.setChBlngAmt(transactionMRERes.getTransaction().getTransactionCard().getChBlngAmt());
			transactionMREFlatRes.setGmtDateTime(transactionMRERes.getTransaction().getTransactionCard().getGMTDateTime());
			transactionMREFlatRes.setChRateConversion(transactionMRERes.getTransaction().getTransactionCard().getChRateConversion());
			transactionMREFlatRes.setCdcAmount(transactionMRERes.getTransaction().getTransactionCard().getCDCAmount());
			transactionMREFlatRes.setExpiryDate(transactionMRERes.getTransaction().getTransactionCard().getExpiryDate());
			transactionMREFlatRes.setExpiryDateMM(transactionMRERes.getTransaction().getTransactionCard().getExpiryDateMM());
			transactionMREFlatRes.setExpiryDateYY(transactionMRERes.getTransaction().getTransactionCard().getExpiryDateYY());
			transactionMREFlatRes.setMerchantType(transactionMRERes.getTransaction().getTransactionCard().getMerchantType());
			transactionMREFlatRes.setTransactionCardCountryCode(transactionMRERes.getTransaction().getTransactionCard().getCountryCode());
			transactionMREFlatRes.setPosEntryMode(transactionMRERes.getTransaction().getTransactionCard().getPosEntryMode());
			transactionMREFlatRes.setPinCAP(transactionMRERes.getTransaction().getTransactionCard().getPinCAP());
			transactionMREFlatRes.setAcquirerID(transactionMRERes.getTransaction().getTransactionCard().getAcquirerID());
			transactionMREFlatRes.setForwardID(transactionMRERes.getTransaction().getTransactionCard().getForwardID());
			transactionMREFlatRes.setAuthorizationCode(transactionMRERes.getTransaction().getTransactionCard().getAuthorizationCode());
			transactionMREFlatRes.setSvcRestCode(transactionMRERes.getTransaction().getTransactionCard().getSvcRestCode());
			transactionMREFlatRes.setCardAcceptRec(transactionMRERes.getTransaction().getTransactionCard().getCardAcceptRec());
			transactionMREFlatRes.setCardAcceptStore(transactionMRERes.getTransaction().getTransactionCard().getCardAcceptStore());
			transactionMREFlatRes.setMerchantID(transactionMRERes.getTransaction().getTransactionCard().getMerchantID());
			transactionMREFlatRes.setAcceptorIDCode(transactionMRERes.getTransaction().getTransactionCard().getAcceptorIDCode());
			transactionMREFlatRes.setChbCurrencyCode(transactionMRERes.getTransaction().getTransactionCard().getCurrencyCode());
			transactionMREFlatRes.setForceFlag(transactionMRERes.getTransaction().getTransactionCard().getForceFlag());
			transactionMREFlatRes.setInputSource(transactionMRERes.getTransaction().getTransactionCard().getInputSource());
			transactionMREFlatRes.setCardType(transactionMRERes.getTransaction().getTransactionCard().getCardType());
			transactionMREFlatRes.setUnderMerchFloor(transactionMRERes.getTransaction().getTransactionCard().getUnderMerchFloor());
			transactionMREFlatRes.setSourceTerminal(transactionMRERes.getTransaction().getTransactionCard().getSourceTerminal());
			transactionMREFlatRes.setTimeSent(transactionMRERes.getTransaction().getTransactionCard().getTimeSent());
			transactionMREFlatRes.setAbsTimeSent(transactionMRERes.getTransaction().getTransactionCard().getABSTimeSent());
			transactionMREFlatRes.setTimeReceived(transactionMRERes.getTransaction().getTransactionCard().getTimeReceived());
			transactionMREFlatRes.setAbsTimeReceived(transactionMRERes.getTransaction().getTransactionCard().getABSTimeReceived());
			transactionMREFlatRes.setDeclineReason(transactionMRERes.getTransaction().getTransactionCard().getDeclineReason());
			transactionMREFlatRes.setSourceTransID(transactionMRERes.getTransaction().getTransactionCard().getSourceTransID());
			transactionMREFlatRes.setMerchantName(transactionMRERes.getTransaction().getTransactionCard().getMerchantName());
			transactionMREFlatRes.setCardSequenceNumber(transactionMRERes.getTransaction().getTransactionCard().getCardSequenceNumber());
			transactionMREFlatRes.setReferralReason(transactionMRERes.getTransaction().getTransactionCard().getReferralReason());
			transactionMREFlatRes.setSuspiciousInd(transactionMRERes.getTransaction().getTransactionCard().getSuspiciousInd());
			transactionMREFlatRes.setCmRiskLevel(transactionMRERes.getTransaction().getTransactionCard().getCMRiskLevel());
			transactionMREFlatRes.setCrLimit(transactionMRERes.getTransaction().getTransactionCard().getCRLimit());
			transactionMREFlatRes.setAvailCredit(transactionMRERes.getTransaction().getTransactionCard().getAvailCredit());
			transactionMREFlatRes.setCommitAmount(transactionMRERes.getTransaction().getTransactionCard().getCommitAmount());
			transactionMREFlatRes.setTotalApprovalCount(transactionMRERes.getTransaction().getTransactionCard().getTotalApprovalCount());
			transactionMREFlatRes.setTotalDeclineCount(transactionMRERes.getTransaction().getTransactionCard().getTotalDeclineCount());
			transactionMREFlatRes.setXdaysApprCount(transactionMRERes.getTransaction().getTransactionCard().getXdaysApprCount());
			transactionMREFlatRes.setTrackDataInd(transactionMRERes.getTransaction().getTransactionCard().getTrackDataInd());
			transactionMREFlatRes.setCrdAcceptRec(transactionMRERes.getTransaction().getTransactionCard().getCRDAcceptRec());
			transactionMREFlatRes.setReferralCode(transactionMRERes.getTransaction().getTransactionCard().getReferralCode());
			transactionMREFlatRes.setRcCheckNumber(transactionMRERes.getTransaction().getTransactionCard().getRCCheckNumber());
			transactionMREFlatRes.setSettleIndicator(transactionMRERes.getTransaction().getTransactionCard().getSettleIndicator());
			transactionMREFlatRes.setTransactionSource(transactionMRERes.getTransaction().getTransactionCard().getTransactionSource());
			transactionMREFlatRes.setTransactionAdvice(transactionMRERes.getTransaction().getTransactionCard().getTransactionAdvice());
			transactionMREFlatRes.setFullChipTransaction(transactionMRERes.getTransaction().getTransactionCard().getFullChipTransaction());
			transactionMREFlatRes.setAcquirerIndicator(transactionMRERes.getTransaction().getTransactionCard().getAcquirerIndicator());
			transactionMREFlatRes.setTermEntCap(transactionMRERes.getTransaction().getTransactionCard().getTermEntCap());
			transactionMREFlatRes.setChipConditionCode(transactionMRERes.getTransaction().getTransactionCard().getCHIPConditionCode());
			transactionMREFlatRes.setCcpsTransIndicator(transactionMRERes.getTransaction().getTransactionCard().getCCPSTransIndicator());
			transactionMREFlatRes.setIccIsaCBAFlag(transactionMRERes.getTransaction().getTransactionCard().getICCCBAFlag());
			transactionMREFlatRes.setIccoptIssCurrency(transactionMRERes.getTransaction().getTransactionCard().getICCOPTIssCurrency());
			transactionMREFlatRes.setIccoptIssExpiry(transactionMRERes.getTransaction().getTransactionCard().getICCOPTIssExpiry());
			transactionMREFlatRes.setCurrencyBehaviorScore(transactionMRERes.getTransaction().getTransactionCard().getCurrencyBehaviorScore());
			transactionMREFlatRes.setAuthScenID(transactionMRERes.getTransaction().getTransactionCard().getAuthScenID());
			transactionMREFlatRes.setAuthStgyID(transactionMRERes.getTransaction().getTransactionCard().getAuthStgyID());
			transactionMREFlatRes.setAuthorDigitGroup(transactionMRERes.getTransaction().getTransactionCard().getAuthorDigitGroup());
			transactionMREFlatRes.setReturnMsgDecline(transactionMRERes.getTransaction().getTransactionCard().getReturnMsgDecline());
			transactionMREFlatRes.setVisaAuthData(transactionMRERes.getTransaction().getTransactionCard().getVisaAuthData());
			transactionMREFlatRes.setVisaPosCondCode(transactionMRERes.getTransaction().getTransactionCard().getVisaPosCondCode());
			transactionMREFlatRes.setVisaStipRespCode(transactionMRERes.getTransaction().getTransactionCard().getVisaStipRespCode());
			transactionMREFlatRes.setVisaIssuRetCode(transactionMRERes.getTransaction().getTransactionCard().getVisaIssuRetCode());
			transactionMREFlatRes.setVisaStipRetCode(transactionMRERes.getTransaction().getTransactionCard().getVisaStipRetCode());
			transactionMREFlatRes.setVisaAvsResult(transactionMRERes.getTransaction().getTransactionCard().getVisaAvsResult());
			transactionMREFlatRes.setStateCode(transactionMRERes.getTransaction().getTransactionCard().getStateCode());
			transactionMREFlatRes.setCountyCode(transactionMRERes.getTransaction().getTransactionCard().getCountyCode());
			transactionMREFlatRes.setZip9(transactionMRERes.getTransaction().getTransactionCard().getZip9());
			transactionMREFlatRes.setZip5(transactionMRERes.getTransaction().getTransactionCard().getZip5());
			transactionMREFlatRes.setTransactionID(transactionMRERes.getTransaction().getTransactionCard().getTransactionID());
			transactionMREFlatRes.setRepeatTransaction(transactionMRERes.getTransaction().getTransactionCard().getRepeatTransaction());
			transactionMREFlatRes.setVisaMerchantGroup(transactionMRERes.getTransaction().getTransactionCard().getVisaMerchantGroup());
			transactionMREFlatRes.setVisaSourceStationID(transactionMRERes.getTransaction().getTransactionCard().getVisaSourceStationID());
			transactionMREFlatRes.setVisaVisaphoneCode(transactionMRERes.getTransaction().getTransactionCard().getVisaVisaphoneCode());
			transactionMREFlatRes.setVisaAutoSvcCode(transactionMRERes.getTransaction().getTransactionCard().getVisaAutoSvcCode());
			transactionMREFlatRes.setVisaCWDenialRSN(transactionMRERes.getTransaction().getTransactionCard().getVisaCWDenialRSN());
			transactionMREFlatRes.setVisaPacmDvrLevel(transactionMRERes.getTransaction().getTransactionCard().getVisaPacmDvrLevel());
			transactionMREFlatRes.setVisaPacmDvrRSN(transactionMRERes.getTransaction().getTransactionCard().getVisaPacmDvrRSN());
			transactionMREFlatRes.setVisaCaResult(transactionMRERes.getTransaction().getTransactionCard().getVisaCaResult());
			transactionMREFlatRes.setVisaDebitOrg(transactionMRERes.getTransaction().getTransactionCard().getVisaDebitOrg());
			transactionMREFlatRes.setVisaDebitType(transactionMRERes.getTransaction().getTransactionCard().getVisaDebitType());
			transactionMREFlatRes.setVisaDebitAccount(transactionMRERes.getTransaction().getTransactionCard().getVisaDebitAccount());
			transactionMREFlatRes.setVisaDebitRiskLevel(transactionMRERes.getTransaction().getTransactionCard().getVisaDebitRiskLevel());
			transactionMREFlatRes.setVisaDebitTipAmount(transactionMRERes.getTransaction().getTransactionCard().getVisaDebitTipAmount());
			transactionMREFlatRes.setVisaTermCountryCode(transactionMRERes.getTransaction().getTransactionCard().getVisaTermCountryCode());
			transactionMREFlatRes.setVisatTermTransactionDate(transactionMRERes.getTransaction().getTransactionCard().getVisatTermTransactionDate());
			transactionMREFlatRes.setMasterTCType(transactionMRERes.getTransaction().getTransactionCard().getMasterTCType());
			transactionMREFlatRes.setMasterSpecialTCFlag(transactionMRERes.getTransaction().getTransactionCard().getMasterSpecialTCFlag());
			transactionMREFlatRes.setMasterStateCode(transactionMRERes.getTransaction().getTransactionCard().getMasterStateCode());
			transactionMREFlatRes.setMasterPosDevice(transactionMRERes.getTransaction().getTransactionCard().getMasterPosDevice());
			transactionMREFlatRes.setMasterAvsOptionCode(transactionMRERes.getTransaction().getTransactionCard().getMasterAvsOptionCode());
			transactionMREFlatRes.setMasterAvsResult(transactionMRERes.getTransaction().getTransactionCard().getMasterAvsResult());
			transactionMREFlatRes.setMasterAuthAgentOld(transactionMRERes.getTransaction().getTransactionCard().getMasterAuthAgentOld());
			transactionMREFlatRes.setMasterPaymentSvcIndicator(transactionMRERes.getTransaction().getTransactionCard().getMasterPaymentSvcIndicator());
			transactionMREFlatRes.setMasterValidationCode(transactionMRERes.getTransaction().getTransactionCard().getMasterValidationCode());
			transactionMREFlatRes.setMasterDownGrade(transactionMRERes.getTransaction().getTransactionCard().getMasterDownGrade());
			transactionMREFlatRes.setMasterReptRteConversion(transactionMRERes.getTransaction().getTransactionCard().getMasterReptRteConversion());
			transactionMREFlatRes.setMasterAuthAgentID(transactionMRERes.getTransaction().getTransactionCard().getMasterAuthAgentID());
			transactionMREFlatRes.setDinersResponseCode(transactionMRERes.getTransaction().getTransactionCard().getDinersResponseCode());
			transactionMREFlatRes.setDinersStandingCode(transactionMRERes.getTransaction().getTransactionCard().getDinersStandingCode());
			transactionMREFlatRes.setDinersMerchantGroup(transactionMRERes.getTransaction().getTransactionCard().getDinersMerchantGroup());
			transactionMREFlatRes.setDinersReqFranchise(transactionMRERes.getTransaction().getTransactionCard().getDinersReqFranchise());
			transactionMREFlatRes.setDinersOwnFranchise(transactionMRERes.getTransaction().getTransactionCard().getDinersOwnFranchise());
			transactionMREFlatRes.setDinersErrorCode(transactionMRERes.getTransaction().getTransactionCard().getDinersErrorCode());
			transactionMREFlatRes.setFullAuthReasonCode(transactionMRERes.getTransaction().getTransactionCard().getFullAuthReasonCode());
			transactionMREFlatRes.setDinersReferralResponse(transactionMRERes.getTransaction().getTransactionCard().getDinersReferralResponse());
			transactionMREFlatRes.setDinersTimer(transactionMRERes.getTransaction().getTransactionCard().getDinersTimer());
			transactionMREFlatRes.setCardProduct(transactionMRERes.getTransaction().getTransactionCard().getCardProduct());
			transactionMREFlatRes.setResponseCode(transactionMRERes.getTransaction().getTransactionCard().getResponseCode());
			transactionMREFlatRes.setRegionCodes(transactionMRERes.getTransaction().getTransactionCard().getRegionCodes());
			transactionMREFlatRes.setOldOverridePurgeDate(transactionMRERes.getTransaction().getTransactionCard().getOldOverridePurgeDate());
			transactionMREFlatRes.setNewOverridePurgeDate(transactionMRERes.getTransaction().getTransactionCard().getNewOverridePurgeDate());
			transactionMREFlatRes.setOldOverrideCode(transactionMRERes.getTransaction().getTransactionCard().getOldOverrideCode());
			transactionMREFlatRes.setNewOverrideCode(transactionMRERes.getTransaction().getTransactionCard().getNewOverrideCode());
			transactionMREFlatRes.setOldInstantUpgrade(transactionMRERes.getTransaction().getTransactionCard().getOldInstantUpgrade());
			transactionMREFlatRes.setNewInstantUpdade(transactionMRERes.getTransaction().getTransactionCard().getNewInstantUpdade());
			transactionMREFlatRes.setInstantUpgradeVerifyID(transactionMRERes.getTransaction().getTransactionCard().getInstantUpgradeVerifyID());
			transactionMREFlatRes.setPinCustomerNumber(transactionMRERes.getTransaction().getTransactionCard().getPinCustomerNumber());
			transactionMREFlatRes.setOldPinOffset(transactionMRERes.getTransaction().getTransactionCard().getOldPinOffset());
			transactionMREFlatRes.setNewPinOffset(transactionMRERes.getTransaction().getTransactionCard().getNewPinOffset());
			transactionMREFlatRes.setNewPinKey(transactionMRERes.getTransaction().getTransactionCard().getNewPinKey());
			transactionMREFlatRes.setOldPinRetryCount(transactionMRERes.getTransaction().getTransactionCard().getOldPinRetryCount());
			transactionMREFlatRes.setNewPinRetryCount(transactionMRERes.getTransaction().getTransactionCard().getNewPinRetryCount());
			transactionMREFlatRes.setOldSetStatus(transactionMRERes.getTransaction().getTransactionCard().getOldSetStatus());
			transactionMREFlatRes.setNewSetStatus(transactionMRERes.getTransaction().getTransactionCard().getNewSetStatus());
			transactionMREFlatRes.setOldSetReason(transactionMRERes.getTransaction().getTransactionCard().getOldSetReason());
			transactionMREFlatRes.setNewSetReason(transactionMRERes.getTransaction().getTransactionCard().getNewSetReason());
			transactionMREFlatRes.setOldSetDateProc(transactionMRERes.getTransaction().getTransactionCard().getOldSetDateProc());
			transactionMREFlatRes.setNewSetDateProc(transactionMRERes.getTransaction().getTransactionCard().getNewSetDateProc());
			transactionMREFlatRes.setOfflineBlock(transactionMRERes.getTransaction().getTransactionCard().getOfflineBlock());
			transactionMREFlatRes.setOldEmvCardUse(transactionMRERes.getTransaction().getTransactionCard().getOldEmvCardUse());
			transactionMREFlatRes.setPreviousEmvCardUseIndicator(transactionMRERes.getTransaction().getTransactionCard().getPreviousEmvCardUseIndicator());
			transactionMREFlatRes.setNewEmvCardUse(transactionMRERes.getTransaction().getTransactionCard().getNewEmvCardUse());
			transactionMREFlatRes.setSettAmount(transactionMRERes.getTransaction().getTransactionCard().getSettAmount());
			transactionMREFlatRes.setSettDate(transactionMRERes.getTransaction().getTransactionCard().getSettDate());
			transactionMREFlatRes.setCardAcceptTerm(transactionMRERes.getTransaction().getTransactionCard().getCardAcceptTerm());
			transactionMREFlatRes.setSettCurrencyCode(transactionMRERes.getTransaction().getTransactionCard().getSettCurrencyCode());
			transactionMREFlatRes.setConsCommitAmount(transactionMRERes.getTransaction().getTransactionCard().getConsCommitAmount());
			transactionMREFlatRes.setDciIntfAmount(transactionMRERes.getTransaction().getTransactionCard().getDciIntfAmount());
			transactionMREFlatRes.setDciIntfCurrencyCode(transactionMRERes.getTransaction().getTransactionCard().getDciIntfCurrencyCode());
			transactionMREFlatRes.setDinersActionCode(transactionMRERes.getTransaction().getTransactionCard().getDinersActionCode());
			transactionMREFlatRes.setDinersCardCurrency(transactionMRERes.getTransaction().getTransactionCard().getDinersCardCurrency());
			transactionMREFlatRes.setEdcIndicator(transactionMRERes.getTransaction().getTransactionCard().getEdcIndicator());
			transactionMREFlatRes.setExceptionResponseCode(transactionMRERes.getTransaction().getTransactionCard().getExceptionResponseCode());
			transactionMREFlatRes.setFromOldCardIndicator(transactionMRERes.getTransaction().getTransactionCard().getFromOldCardIndicator());
			transactionMREFlatRes.setInstUpgChangeType(transactionMRERes.getTransaction().getTransactionCard().getInstUpgChangeType());
			transactionMREFlatRes.setInstUpgLimit(transactionMRERes.getTransaction().getTransactionCard().getInstUpgLimit());
			transactionMREFlatRes.setInstUpgPurgeDate(transactionMRERes.getTransaction().getTransactionCard().getInstUpgPurgeDate());
			transactionMREFlatRes.setIsoRespCode(transactionMRERes.getTransaction().getTransactionCard().getISOResponseCode());
			transactionMREFlatRes.setOverrideCodePurgeDate(transactionMRERes.getTransaction().getTransactionCard().getOverrideCodePurgeDate());
			transactionMREFlatRes.setPhoneCardResponseCode(transactionMRERes.getTransaction().getTransactionCard().getPhoneCardResponseCode());
			transactionMREFlatRes.setPinTermID(transactionMRERes.getTransaction().getTransactionCard().getPinTermID());
			transactionMREFlatRes.settPinResetIndicator(transactionMRERes.getTransaction().getTransactionCard().getTPinResetIndicator());
			transactionMREFlatRes.setMasterSetlementDate(transactionMRERes.getTransaction().getTransactionCard().getMasterSetlementDate());
			transactionMREFlatRes.setCardAuthorRI(transactionMRERes.getTransaction().getTransactionCard().getCardAuthorRI());
			transactionMREFlatRes.setProcessCode(transactionMRERes.getTransaction().getTransactionCard().getProcessCode());
			transactionMREFlatRes.setChBilingAmount(transactionMRERes.getTransaction().getTransactionCard().getChBilingAmount());
			transactionMREFlatRes.setCrcDecSep(transactionMRERes.getTransaction().getTransactionCard().getCRCDecSep());
			transactionMREFlatRes.setExpiryDatePresence(transactionMRERes.getTransaction().getTransactionCard().getExpiryDatePresence());
			transactionMREFlatRes.setPosEmPan(transactionMRERes.getTransaction().getTransactionCard().getPosEmPan());
			transactionMREFlatRes.setCardSeqNbr(transactionMRERes.getTransaction().getTransactionCard().getCardSeqNbr());
			transactionMREFlatRes.setTypeBMerchantID(transactionMRERes.getTransaction().getTransactionCard().getTypeBMerchantID());
			transactionMREFlatRes.setIcCpseudoTerm(transactionMRERes.getTransaction().getTransactionCard().getICCpseudoTerm());
			transactionMREFlatRes.setCmBlockCode(transactionMRERes.getTransaction().getTransactionCard().getCMBlockCode());
			transactionMREFlatRes.setCw2CVC2(transactionMRERes.getTransaction().getTransactionCard().getCW2CVC2());
			transactionMREFlatRes.setCw2Presence(transactionMRERes.getTransaction().getTransactionCard().getCW2Presence());
			transactionMREFlatRes.setExceptionPurgeDate(transactionMRERes.getTransaction().getTransactionCard().getExceptionPurgeDate());
			transactionMREFlatRes.setIccIsaCCAAmount(transactionMRERes.getTransaction().getTransactionCard().getIccIsaCCAAmount());
			transactionMREFlatRes.setIccIsaCCASettlement(transactionMRERes.getTransaction().getTransactionCard().getIccIsaCCASettlement());
			transactionMREFlatRes.setIccoifcbaAmount(transactionMRERes.getTransaction().getTransactionCard().getICCOIFCBAAmount());
			transactionMREFlatRes.setIccOptIssAmount(transactionMRERes.getTransaction().getTransactionCard().getICCOptIssAmount());
			transactionMREFlatRes.setInvCWCVC2Indicator(transactionMRERes.getTransaction().getTransactionCard().getInvCWCVC2Indicator());
			transactionMREFlatRes.setInvCWCVCIndicator(transactionMRERes.getTransaction().getTransactionCard().getInvCWCVCIndicator());
			transactionMREFlatRes.setJetcoAcquirerBin(transactionMRERes.getTransaction().getTransactionCard().getJetcoAcquirerBin());
			transactionMREFlatRes.setMasterSettlementAmount(transactionMRERes.getTransaction().getTransactionCard().getMasterSettlementAmount());
			transactionMREFlatRes.setMasterRRCAmount(transactionMRERes.getTransaction().getTransactionCard().getMasterRRCAmount());
			transactionMREFlatRes.setMasterRRCDecSep(transactionMRERes.getTransaction().getTransactionCard().getMasterRRCDecSep());
			transactionMREFlatRes.setMasterRetrivalNumber(transactionMRERes.getTransaction().getTransactionCard().getMasterRetrivalNumber());
			transactionMREFlatRes.setMasterResponseCode(transactionMRERes.getTransaction().getTransactionCard().getMasterResponseCode());
			transactionMREFlatRes.setMasterECI(transactionMRERes.getTransaction().getTransactionCard().getMasterECI());
			transactionMREFlatRes.setMasterInvoiceCvcIndicator(transactionMRERes.getTransaction().getTransactionCard().getMasterInvoiceCvcIndicator());
			transactionMREFlatRes.setMasterTRK2ErrorIndicator(transactionMRERes.getTransaction().getTransactionCard().getMasterTRK2ErrorIndicator());
			transactionMREFlatRes.setMasterTrk2TfmIndicator(transactionMRERes.getTransaction().getTransactionCard().getMasterTrk2TfmIndicator());
			transactionMREFlatRes.setMasterTransactionIndicator(transactionMRERes.getTransaction().getTransactionCard().getMasterTransactionIndicator());
			transactionMREFlatRes.setMasterUCAF(transactionMRERes.getTransaction().getTransactionCard().getMasterUCAF());
			transactionMREFlatRes.setMasterUCAFData(transactionMRERes.getTransaction().getTransactionCard().getMasterUCAFData());
			transactionMREFlatRes.setMasterCardTermIndicator(transactionMRERes.getTransaction().getTransactionCard().getMasterCardTermIndicator());
			transactionMREFlatRes.setMasterPosData(transactionMRERes.getTransaction().getTransactionCard().getMasterPosData());
			transactionMREFlatRes.setMasterPosDataLen(transactionMRERes.getTransaction().getTransactionCard().getMasterPosDataLen());
			transactionMREFlatRes.setMasterBnkntDataRec(transactionMRERes.getTransaction().getTransactionCard().getMasterBnkntDataRec());
			transactionMREFlatRes.setMasterBnkntRefNumber(transactionMRERes.getTransaction().getTransactionCard().getMasterBnkntRefNumber());
			transactionMREFlatRes.setMasterFnclNetworkCode(transactionMRERes.getTransaction().getTransactionCard().getMasterFnclNetworkCode());
			transactionMREFlatRes.setMasterChipData(transactionMRERes.getTransaction().getTransactionCard().getMasterChipData());
			transactionMREFlatRes.setMasterDownOption(transactionMRERes.getTransaction().getTransactionCard().getMasterDownOption());
			transactionMREFlatRes.setMasterDownReason(transactionMRERes.getTransaction().getTransactionCard().getMasterDownReason());
			transactionMREFlatRes.setMasterOptional0130(transactionMRERes.getTransaction().getTransactionCard().getMasterOptional0130());
			transactionMREFlatRes.setMasterOptional3160(transactionMRERes.getTransaction().getTransactionCard().getMasterOptional3160());
			transactionMREFlatRes.setMasterOptionalData(transactionMRERes.getTransaction().getTransactionCard().getMasterOptionalData());
			transactionMREFlatRes.setMasterOptionalDataLen(transactionMRERes.getTransaction().getTransactionCard().getMasterOptionalDataLen());
			transactionMREFlatRes.setNewAltBlockCodeR(transactionMRERes.getTransaction().getTransactionCard().getNewAltBlockCodeR());
			transactionMREFlatRes.setTerminalID(transactionMRERes.getTransaction().getTransactionCard().getTerminalID());
			transactionMREFlatRes.setTraceNbr(transactionMRERes.getTransaction().getTransactionCard().getTraceNbr());
			transactionMREFlatRes.setTrackData(transactionMRERes.getTransaction().getTransactionCard().getTrackData());
			transactionMREFlatRes.setValidCAWIndicator(transactionMRERes.getTransaction().getTransactionCard().getValidCAWIndicator());
			transactionMREFlatRes.setVisaSystemAuditTrace(transactionMRERes.getTransaction().getTransactionCard().getVisaSystemAuditTrace());
			transactionMREFlatRes.setVisaB044CAW(transactionMRERes.getTransaction().getTransactionCard().getVisaB044CAW());
			transactionMREFlatRes.setVisaCAWReturnCode(transactionMRERes.getTransaction().getTransactionCard().getVisaCAWReturnCode());
			transactionMREFlatRes.setVisaPacmRsn(transactionMRERes.getTransaction().getTransactionCard().getVisaPacmRsn());
			transactionMREFlatRes.setVisaAdditional0130(transactionMRERes.getTransaction().getTransactionCard().getVisaAdditional0130());
			transactionMREFlatRes.setVisaAdditional3160(transactionMRERes.getTransaction().getTransactionCard().getVisaAdditional3160());
			transactionMREFlatRes.setVisaAdditionalData(transactionMRERes.getTransaction().getTransactionCard().getVisaAdditionalData());
			transactionMREFlatRes.setVisaAdditionalDataLength(transactionMRERes.getTransaction().getTransactionCard().getVisaAdditionalDataLength());
			transactionMREFlatRes.setVisaCountryCodeX(transactionMRERes.getTransaction().getTransactionCard().getVisaCountryCodeX());
			transactionMREFlatRes.setVisaPosGeoDataLength(transactionMRERes.getTransaction().getTransactionCard().getVisaPosGeoDataLength());
			transactionMREFlatRes.setVisaPosGeoDataRecord(transactionMRERes.getTransaction().getTransactionCard().getVisaPosGeoDataRecord());
			transactionMREFlatRes.setVisaStateCodeX(transactionMRERes.getTransaction().getTransactionCard().getVisaStateCodeX());
			transactionMREFlatRes.setVisaPosEntryCode(transactionMRERes.getTransaction().getTransactionCard().getVisaPosEntryCode());
			transactionMREFlatRes.setVisaPosEntryLength(transactionMRERes.getTransaction().getTransactionCard().getVisaPosEntryLength());
			transactionMREFlatRes.setVisaAmountLength(transactionMRERes.getTransaction().getTransactionCard().getVisaAmountLength());
			transactionMREFlatRes.setVisaAmountSub01(transactionMRERes.getTransaction().getTransactionCard().getVisaAmountSub01());
			transactionMREFlatRes.setVisaAmountSub02(transactionMRERes.getTransaction().getTransactionCard().getVisaAmountSub02());
			transactionMREFlatRes.setVisaAmountSub03(transactionMRERes.getTransaction().getTransactionCard().getVisaAmountSub03());
			transactionMREFlatRes.setVisaPaymentSvcIndicator(transactionMRERes.getTransaction().getTransactionCard().getVisaPaymentSvcIndicator());
			transactionMREFlatRes.setVisaPaymentSvcLength(transactionMRERes.getTransaction().getTransactionCard().getVisaPaymentSvcLength());
			transactionMREFlatRes.setVisaValidationCode(transactionMRERes.getTransaction().getTransactionCard().getVisaValidationCode());
			transactionMREFlatRes.setVisaAccountTransactionAmount(transactionMRERes.getTransaction().getTransactionCard().getVisaAccountTransactionAmount());
			transactionMREFlatRes.setVisaB126CAW(transactionMRERes.getTransaction().getTransactionCard().getVisaB126CAW());
			transactionMREFlatRes.setVisaXid(transactionMRERes.getTransaction().getTransactionCard().getVisaXid());
			transactionMREFlatRes.setVisaTermCapProf(transactionMRERes.getTransaction().getTransactionCard().getVisaTermCapProf());
			transactionMREFlatRes.setVisaTermVerificationRS(transactionMRERes.getTransaction().getTransactionCard().getVisaTermVerificationRS());
			transactionMREFlatRes.setVisaUnpredictNumber(transactionMRERes.getTransaction().getTransactionCard().getVisaUnpredictNumber());
			transactionMREFlatRes.setVisaTermSerialNumber(transactionMRERes.getTransaction().getTransactionCard().getVisaTermSerialNumber());
			transactionMREFlatRes.setVisaDiscrData(transactionMRERes.getTransaction().getTransactionCard().getVisaDiscrData());
			transactionMREFlatRes.setVisaDiscrLength(transactionMRERes.getTransaction().getTransactionCard().getVisaDiscrLength());
			transactionMREFlatRes.setVisaIssDiscrData(transactionMRERes.getTransaction().getTransactionCard().getVisaIssDiscrData());
			transactionMREFlatRes.setVisaIssDiscrLength(transactionMRERes.getTransaction().getTransactionCard().getVisaIssDiscrLength());
			transactionMREFlatRes.setVisaCryptogram(transactionMRERes.getTransaction().getTransactionCard().getVisaCryptogram());
			transactionMREFlatRes.setVisaAppTransactionCounter(transactionMRERes.getTransaction().getTransactionCard().getVisaAppTransactionCounter());
			transactionMREFlatRes.setVisaAppIntegProf(transactionMRERes.getTransaction().getTransactionCard().getVisaAppIntegProf());
			transactionMREFlatRes.setVisaArpcData(transactionMRERes.getTransaction().getTransactionCard().getVisaArpcData());
			transactionMREFlatRes.setVisaIssAuthData(transactionMRERes.getTransaction().getTransactionCard().getVisaIssAuthData());
			transactionMREFlatRes.setVisaIssAuthLength(transactionMRERes.getTransaction().getTransactionCard().getVisaIssAuthLength());
			transactionMREFlatRes.setVisaIssScriptData(transactionMRERes.getTransaction().getTransactionCard().getVisaIssScriptData());
			transactionMREFlatRes.setVisaIssScriptLength(transactionMRERes.getTransaction().getTransactionCard().getVisaIssScriptLength());
			transactionMREFlatRes.setVisaIssScriptr(transactionMRERes.getTransaction().getTransactionCard().getVisaIssScriptr());
			transactionMREFlatRes.setVisaIssScriptrLength(transactionMRERes.getTransaction().getTransactionCard().getVisaIssScriptrLength());
			transactionMREFlatRes.setVisaCrytoTransactionType(transactionMRERes.getTransaction().getTransactionCard().getVisaCrytoTransactionType());
			transactionMREFlatRes.setVisaCryptoAmount(transactionMRERes.getTransaction().getTransactionCard().getVisaCryptoAmount());
			transactionMREFlatRes.setVisaCryptoCurrencyCode(transactionMRERes.getTransaction().getTransactionCard().getVisaCryptoCurrencyCode());
			transactionMREFlatRes.setVisaCryptoCashback(transactionMRERes.getTransaction().getTransactionCard().getVisaCryptoCashback());
			transactionMREFlatRes.setVisaDebitTipAmountV99(transactionMRERes.getTransaction().getTransactionCard().getVisaDebitTipAmountV99());
			transactionMREFlatRes.setTransactionAmountV99(transactionMRERes.getTransaction().getTransactionCard().getTransactionAmountV99());
			transactionMREFlatRes.setAccountType(transactionMRERes.getTransaction().getTransactionCard().getAccountType());
			transactionMREFlatRes.setCurrencyCode(transactionMRERes.getTransaction().getTransactionCard().getCurrencyCode());
			transactionMREFlatRes.setBatchnumber(transactionMRERes.getTransaction().getTransactionCard().getBatchnumber());
			transactionMREFlatRes.setBlockMaintFlag(transactionMRERes.getTransaction().getTransactionCard().getBlockMaintFlag());
			transactionMREFlatRes.setCardMaintOperatorID(transactionMRERes.getTransaction().getTransactionCard().getCardMaintOperatorID());
			transactionMREFlatRes.setCardMaintType(transactionMRERes.getTransaction().getTransactionCard().getCardMaintType());
			transactionMREFlatRes.setIccOrigB051(transactionMRERes.getTransaction().getTransactionCard().getICCOrigB051());
			transactionMREFlatRes.setNewBlockCode(transactionMRERes.getTransaction().getTransactionCard().getNewBlockCode());
			transactionMREFlatRes.setNewBlockCodeDate(transactionMRERes.getTransaction().getTransactionCard().getNewBlockCodeDate());
			transactionMREFlatRes.setNewBlockCodeR(transactionMRERes.getTransaction().getTransactionCard().getNewBlockCodeR());
			transactionMREFlatRes.setNewBlockCodeTime(transactionMRERes.getTransaction().getTransactionCard().getNewBlockCodeTime());
			transactionMREFlatRes.setOldBlockCode(transactionMRERes.getTransaction().getTransactionCard().getOldBlockCode());
			transactionMREFlatRes.setOldBlockCodeR(transactionMRERes.getTransaction().getTransactionCard().getOldBlockCodeR());
			transactionMREFlatRes.setOnlinePrint(transactionMRERes.getTransaction().getTransactionCard().getOnlinePrint());
			transactionMREFlatRes.setOptionalDataIndicator(transactionMRERes.getTransaction().getTransactionCard().getOptionalDataIndicator());
			transactionMREFlatRes.setOrg(transactionMRERes.getTransaction().getTransactionCard().getOrg());
			transactionMREFlatRes.setPinDataPresent(transactionMRERes.getTransaction().getTransactionCard().getPinDataPresent());
			transactionMREFlatRes.setPinKey(transactionMRERes.getTransaction().getTransactionCard().getPinKey());
			transactionMREFlatRes.setPinOffset(transactionMRERes.getTransaction().getTransactionCard().getPinOffset());
			transactionMREFlatRes.setPrevBlockCode(transactionMRERes.getTransaction().getTransactionCard().getPrevBlockCode());
			transactionMREFlatRes.setPrevBlockCodeR(transactionMRERes.getTransaction().getTransactionCard().getPrevBlockCodeR());
			transactionMREFlatRes.setRecordType(transactionMRERes.getTransaction().getTransactionCard().getRecordType());
			transactionMREFlatRes.setRefNumber(transactionMRERes.getTransaction().getTransactionCard().getRefNumber());
			transactionMREFlatRes.setRefNumberX(transactionMRERes.getTransaction().getTransactionCard().getRefNumberX());
			transactionMREFlatRes.setReplaceDigit(transactionMRERes.getTransaction().getTransactionCard().getReplaceDigit());
			transactionMREFlatRes.setSpeicalHandlingFile(transactionMRERes.getTransaction().getTransactionCard().getSpeicalHandlingFile());
			transactionMREFlatRes.setSuppIndicator(transactionMRERes.getTransaction().getTransactionCard().getSuppIndicator());
			transactionMREFlatRes.setVisaB060910(transactionMRERes.getTransaction().getTransactionCard().getVisaB060910());
			transactionMREFlatRes.setTerminalIDX(transactionMRERes.getTransaction().getTransactionCard().getTerminalIDX());
			transactionMREFlatRes.setTfc0005CWSPID(transactionMRERes.getTransaction().getTransactionCard().getTFC0005CWSPID());
			transactionMREFlatRes.setKeyEOD(transactionMRERes.getTransaction().getTransactionCard().getKeyEOD());
			transactionMREFlatRes.setKeyTieBreak(transactionMRERes.getTransaction().getTransactionCard().getKeyTieBreak());
			transactionMREFlatRes.setKeyFileSeg(transactionMRERes.getTransaction().getTransactionCard().getKeyFileSeg());
			transactionMREFlatRes.setEodIndicator(transactionMRERes.getTransaction().getTransactionCard().getEODIndicator());
			transactionMREFlatRes.setActivityData(transactionMRERes.getTransaction().getTransactionCard().getActivityData());
			transactionMREFlatRes.setMessageArea(transactionMRERes.getTransaction().getTransactionCard().getMessageArea());
			transactionMREFlatRes.setSpecialRecordType(transactionMRERes.getTransaction().getTransactionCard().getSpecialRecordType());
			transactionMREFlatRes.setMaintenanceRecord(transactionMRERes.getTransaction().getTransactionCard().getMaintenanceRecord());
			transactionMREFlatRes.setLocalTxnTime(transactionMRERes.getTransaction().getTransactionCard().getLocalTxnTime());
			transactionMREFlatRes.setLocalTxnDate(transactionMRERes.getTransaction().getTransactionCard().getLocalTxnDate());
			transactionMREFlatRes.setRetrievalNumber(transactionMRERes.getTransaction().getTransactionCard().getRetrievalNumber());
			transactionMREFlatRes.setAmedCrLimit(transactionMRERes.getTransaction().getTransactionCard().getAMEDCrLimit());
			transactionMREFlatRes.setAmbsCrLimit(transactionMRERes.getTransaction().getTransactionCard().getAMBSCrLimit());
			transactionMREFlatRes.setAmrmCrLimit(transactionMRERes.getTransaction().getTransactionCard().getAMRMCrLimit());
			transactionMREFlatRes.setAmedAvailCrLimit(transactionMRERes.getTransaction().getTransactionCard().getAMEDAvailCrLimit());
			transactionMREFlatRes.setAmbsAvailCrLimit(transactionMRERes.getTransaction().getTransactionCard().getAMBSAvailCrLimit());
			transactionMREFlatRes.setAmrmAvailCrLimit(transactionMRERes.getTransaction().getTransactionCard().getAMRMAvailCrLimit());
			transactionMREFlatRes.setAmedCommitAmount(transactionMRERes.getTransaction().getTransactionCard().getAMEDCommitAmount());
			transactionMREFlatRes.setAmbsCommitAmount(transactionMRERes.getTransaction().getTransactionCard().getAMBSCommitAmount());
			transactionMREFlatRes.setAmrmCommitAmount(transactionMRERes.getTransaction().getTransactionCard().getAMRMCommitAmount());
			transactionMREFlatRes.setAmedewsBlockCode(transactionMRERes.getTransaction().getTransactionCard().getAMEDEWSBlockCode());
			transactionMREFlatRes.setAmbsewsBlockCode1(transactionMRERes.getTransaction().getTransactionCard().getAMBSEWSBlockCode1());
			transactionMREFlatRes.setAmbsewsBlockCode2(transactionMRERes.getTransaction().getTransactionCard().getAMBSEWSBlockCode2());
			transactionMREFlatRes.setAmrmewsBlockCode(transactionMRERes.getTransaction().getTransactionCard().getAMRMEWSBlockCode());
			transactionMREFlatRes.setEwsRiskLevel(transactionMRERes.getTransaction().getTransactionCard().getEWSRiskLevel());
			transactionMREFlatRes.setEwsActivationInd(transactionMRERes.getTransaction().getTransactionCard().getEWSActivationInd());
			transactionMREFlatRes.setEwsActivationDate(transactionMRERes.getTransaction().getTransactionCard().getEWSActivationDate());
			transactionMREFlatRes.setEwsbsScore(transactionMRERes.getTransaction().getTransactionCard().getEWSBSScore());
			transactionMREFlatRes.setEwsAmountAuthToday(transactionMRERes.getTransaction().getTransactionCard().getEWSAmountAuthToday());
			transactionMREFlatRes.setDailyRTLNumber(transactionMRERes.getTransaction().getTransactionCard().getDailyRTLNumber());
			transactionMREFlatRes.setDailyRTLAmount(transactionMRERes.getTransaction().getTransactionCard().getDailyRTLAmount());
			transactionMREFlatRes.setDailyCashNumber(transactionMRERes.getTransaction().getTransactionCard().getDailyCashNumber());
			transactionMREFlatRes.setDailyCashAmount(transactionMRERes.getTransaction().getTransactionCard().getDailyCashAmount());
			transactionMREFlatRes.setDailyMCCNumber(transactionMRERes.getTransaction().getTransactionCard().getDailyMCCNumber());
			transactionMREFlatRes.setDailyMCCAmount(transactionMRERes.getTransaction().getTransactionCard().getDailyMCCAmount());
			transactionMREFlatRes.setDailyRTLNumber(transactionMRERes.getTransaction().getTransactionCard().getXDaysRTLNumber());
			transactionMREFlatRes.setDailyRTLAmount(transactionMRERes.getTransaction().getTransactionCard().getXDaysRTLAmount());
			transactionMREFlatRes.setxDaysCashNumber(transactionMRERes.getTransaction().getTransactionCard().getXDaysCashNumber());
			transactionMREFlatRes.setxDaysCashAmount(transactionMRERes.getTransaction().getTransactionCard().getXDaysCashAmount());
			transactionMREFlatRes.setxDaysMCCAmount(transactionMRERes.getTransaction().getTransactionCard().getXDaysMCCAmount());
			transactionMREFlatRes.setDeclRSN(transactionMRERes.getTransaction().getTransactionCard().getDeclRSN());
			transactionMREFlatRes.setMatchedInd(transactionMRERes.getTransaction().getTransactionCard().getMatchedInd());
			transactionMREFlatRes.setAuthorisationClass(transactionMRERes.getTransaction().getTransactionCard().getAuthorisationClass());
			transactionMREFlatRes.setAmbsAccount(transactionMRERes.getTransaction().getTransactionCard().getAMBSAccount());
			transactionMREFlatRes.setAmrmRelOrg(transactionMRERes.getTransaction().getTransactionCard().getAMRMRelOrg());
			transactionMREFlatRes.setAmrmRelNumber(transactionMRERes.getTransaction().getTransactionCard().getAMRMRelNumber());
			transactionMREFlatRes.setBlockRSNAMED(transactionMRERes.getTransaction().getTransactionCard().getBlockRSNAMED());
			transactionMREFlatRes.setBlockRSNAMBS1(transactionMRERes.getTransaction().getTransactionCard().getBlockRSNAMBS1());
			transactionMREFlatRes.setBlockRSNAMBS2(transactionMRERes.getTransaction().getTransactionCard().getBlockRSNAMBS2());
			transactionMREFlatRes.setAmbsDateOpened(transactionMRERes.getTransaction().getTransactionCard().getAMBSDateOpened());
			transactionMREFlatRes.setInvalidPinTries(transactionMRERes.getTransaction().getTransactionCard().getInvalidPinTries());
			transactionMREFlatRes.setClogRecType(transactionMRERes.getTransaction().getTransactionCard().getCLOGRecType());
			transactionMREFlatRes.setFiSpid(transactionMRERes.getTransaction().getTransactionCard().getFISpid());
			transactionMREFlatRes.setFiTestDigits(transactionMRERes.getTransaction().getTransactionCard().getFITestDigits());
			transactionMREFlatRes.setFiAuthDigitGroup(transactionMRERes.getTransaction().getTransactionCard().getFIAuthDigitGroup());
			transactionMREFlatRes.setFiAuthStragegyID(transactionMRERes.getTransaction().getTransactionCard().getFIAuthStragegyID());
			transactionMREFlatRes.setClogAuthReport(transactionMRERes.getTransaction().getTransactionCard().getCLOGAuthReport());
			transactionMREFlatRes.setClogAuthDecision(transactionMRERes.getTransaction().getTransactionCard().getCLOGAuthDecision());
			transactionMREFlatRes.setPmtCycleDue(transactionMRERes.getTransaction().getTransactionCard().getPMTCycleDue());
			transactionMREFlatRes.setClogTransType(transactionMRERes.getTransaction().getTransactionCard().getCLOGTransType());
			transactionMREFlatRes.setAmtCTDCash(transactionMRERes.getTransaction().getTransactionCard().getAmtCTDCash());
			transactionMREFlatRes.setCashCRLIM(transactionMRERes.getTransaction().getTransactionCard().getCashCRLIM());
			transactionMREFlatRes.setClogAmountOutStd(transactionMRERes.getTransaction().getTransactionCard().getCLOGAmountOutStd());
			transactionMREFlatRes.setIccInstId(transactionMRERes.getTransaction().getTransactionCard().getICCInstId());
			transactionMREFlatRes.setIccissNetwID(transactionMRERes.getTransaction().getTransactionCard().getICCISSNetwID());
			transactionMREFlatRes.setIccAcqNetwID(transactionMRERes.getTransaction().getTransactionCard().getICCAcqNetwID());
			transactionMREFlatRes.setCurrencyBehaviorScore(transactionMRERes.getTransaction().getTransactionCard().getFICurrBehaviorScore());
			transactionMREFlatRes.setFiAuthScnID(transactionMRERes.getTransaction().getTransactionCard().getFIAuthScnID());
			transactionMREFlatRes.setFraudCPInd(transactionMRERes.getTransaction().getTransactionCard().getFraudCPInd());
			transactionMREFlatRes.setFraudOrigPosEntry(transactionMRERes.getTransaction().getTransactionCard().getFraudOrigPosEntry());
			transactionMREFlatRes.setRecurringInd(transactionMRERes.getTransaction().getTransactionCard().getRecurringInd());
			transactionMREFlatRes.setInstlInd(transactionMRERes.getTransaction().getTransactionCard().getInstlInd());
			transactionMREFlatRes.setUtilityInd(transactionMRERes.getTransaction().getTransactionCard().getUtilityInd());
			transactionMREFlatRes.setMotoInd(transactionMRERes.getTransaction().getTransactionCard().getMotoInd());
			transactionMREFlatRes.setCallCardInd(transactionMRERes.getTransaction().getTransactionCard().getCallCardInd());
			transactionMREFlatRes.setAtiaOrgNumber(transactionMRERes.getTransaction().getTransactionCard().getATIAOrgNumber());
			transactionMREFlatRes.setLocalCurrencyCode(transactionMRERes.getTransaction().getTransactionCard().getLocalCurrencyCode());
			transactionMREFlatRes.setAtiaAuthAmount(transactionMRERes.getTransaction().getTransactionCard().getATIAAuthAmount());
			transactionMREFlatRes.setOrigTypeMessageId(transactionMRERes.getTransaction().getTransactionCard().getOrigTypeMessageId());
			transactionMREFlatRes.setJetcoAcqBin(transactionMRERes.getTransaction().getTransactionCard().getJetcoAcqBin());
			transactionMREFlatRes.setOdlyCashAmount(transactionMRERes.getTransaction().getTransactionCard().getODLYCashAmount());
			transactionMREFlatRes.setOmlyCashAmount(transactionMRERes.getTransaction().getTransactionCard().getOMLYCashAmount());
			transactionMREFlatRes.setMonth6CashAmount(transactionMRERes.getTransaction().getTransactionCard().getMonth6CashAmount());
			transactionMREFlatRes.setMonth12CashAmount(transactionMRERes.getTransaction().getTransactionCard().getMonth12CashAmount());
			transactionMREFlatRes.setExchangeTxn(transactionMRERes.getTransaction().getTransactionCard().getExchangeTxn());
			transactionMREFlatRes.setOvsPurchaseLimit(transactionMRERes.getTransaction().getTransactionCard().getOVSPurchaseLimit());
			transactionMREFlatRes.setOvsPurchaseAvail(transactionMRERes.getTransaction().getTransactionCard().getOVSPurchaseAvail());
			transactionMREFlatRes.setOvsCashLimit(transactionMRERes.getTransaction().getTransactionCard().getOVSCashLimit());
			transactionMREFlatRes.setOvsInternetLimit(transactionMRERes.getTransaction().getTransactionCard().getOVSInternetLimit());
			transactionMREFlatRes.setOvsInternetAvail(transactionMRERes.getTransaction().getTransactionCard().getOVSInternetAvail());
			transactionMREFlatRes.setAmbsCashAvail(transactionMRERes.getTransaction().getTransactionCard().getAMBSCashAvail());
			transactionMREFlatRes.setAmedCashAvail(transactionMRERes.getTransaction().getTransactionCard().getAMEDCashAvail());
			transactionMREFlatRes.setAmedPostToAcc(transactionMRERes.getTransaction().getTransactionCard().getAMEDPostToAcc());
			transactionMREFlatRes.setIcccbaFlag(transactionMRERes.getTransaction().getTransactionCard().getICCCBAFlag());
			transactionMREFlatRes.setCcaSettlementFee(transactionMRERes.getTransaction().getTransactionCard().getCCASettlementFee());
			transactionMREFlatRes.setMasterDebitOrg(transactionMRERes.getTransaction().getTransactionCard().getMasterDebitOrg());
			transactionMREFlatRes.setMasterDebitType(transactionMRERes.getTransaction().getTransactionCard().getMasterDebitType());
			transactionMREFlatRes.setMasterDebitAcct(transactionMRERes.getTransaction().getTransactionCard().getMasterDebitAcct());
			transactionMREFlatRes.setMasterDebitRiskLevel(transactionMRERes.getTransaction().getTransactionCard().getMasterDebitRiskLevel());
			transactionMREFlatRes.setMasterDebitCardInd(transactionMRERes.getTransaction().getTransactionCard().getMasterDebitCardInd());
			transactionMREFlatRes.setMasterDebitTipAmt(transactionMRERes.getTransaction().getTransactionCard().getMasterDebitTipAmt());
			transactionMREFlatRes.setAfewsOnlineMode(transactionMRERes.getTransaction().getTransactionCard().getAfewsOnlineMode());
			transactionMREFlatRes.setAfewsOnlineRC1(transactionMRERes.getTransaction().getTransactionCard().getAfewsOnlineRC1());
			transactionMREFlatRes.setRefrlQSTN1(transactionMRERes.getTransaction().getTransactionCard().getRefrlQSTN1());
			transactionMREFlatRes.setRefrlQSTN2(transactionMRERes.getTransaction().getTransactionCard().getRefrlQSTN2());
			transactionMREFlatRes.setRefrlQSTN3(transactionMRERes.getTransaction().getTransactionCard().getRefrlQSTN3());
			transactionMREFlatRes.setGlobalCountryCode(transactionMRERes.getTransaction().getTransactionCard().getGlobalCountryCode());
			transactionMREFlatRes.setAfewsFalconDSCN(transactionMRERes.getTransaction().getTransactionCard().getAfewsFalconDSCN());
			transactionMREFlatRes.setMasterInvCVC2(transactionMRERes.getTransaction().getTransactionCard().getMasterInvCVC2());
			transactionMREFlatRes.setMasterPOSCondCode(transactionMRERes.getTransaction().getTransactionCard().getMasterPOSCondCode());
			transactionMREFlatRes.setMasterFNCLCode(transactionMRERes.getTransaction().getTransactionCard().getMasterFNCLCode());
			transactionMREFlatRes.setMasterBNKNTREFNumber(transactionMRERes.getTransaction().getTransactionCard().getMasterBNKNTREFNumber());
			transactionMREFlatRes.setDinersSYSTrace(transactionMRERes.getTransaction().getTransactionCard().getDinersSYSTrace());
			transactionMREFlatRes.setIsoRespCode(transactionMRERes.getTransaction().getTransactionCard().getISORespCode());
			transactionMREFlatRes.setCardRespCode(transactionMRERes.getTransaction().getTransactionCard().getCardRespCode());
			transactionMREFlatRes.setDinersCVVInd(transactionMRERes.getTransaction().getTransactionCard().getDinersCVVInd());
			transactionMREFlatRes.setDinersDupInd(transactionMRERes.getTransaction().getTransactionCard().getDinersDupInd());
			transactionMREFlatRes.setDinersRecurInd(transactionMRERes.getTransaction().getTransactionCard().getDinersRecurInd());
			transactionMREFlatRes.setEppTenor(transactionMRERes.getTransaction().getTransactionCard().getEppTenor());
			transactionMREFlatRes.setEppPromoId(transactionMRERes.getTransaction().getTransactionCard().getEppPromoId());
			transactionMREFlatRes.setAltOrgId(transactionMRERes.getTransaction().getTransactionCard().getAltOrgId());
			transactionMREFlatRes.setAmexTCType(transactionMRERes.getTransaction().getTransactionCard().getAmexTCType());
			transactionMREFlatRes.setAmexResCode(transactionMRERes.getTransaction().getTransactionCard().getAmexResCode());
			transactionMREFlatRes.setAmexISOResCode(transactionMRERes.getTransaction().getTransactionCard().getAmexISOResCode());
			transactionMREFlatRes.setAmexLclTxnDTTime(transactionMRERes.getTransaction().getTransactionCard().getAmexLclTxnDTTime());
			transactionMREFlatRes.setAmexEffDate(transactionMRERes.getTransaction().getTransactionCard().getAmexEffDate());
			transactionMREFlatRes.setAmexPosDataCode(transactionMRERes.getTransaction().getTransactionCard().getAmexPosDataCode());
			transactionMREFlatRes.setAmexFunCode(transactionMRERes.getTransaction().getTransactionCard().getAmexFunCode());
			transactionMREFlatRes.setAmexMsgRsnCode(transactionMRERes.getTransaction().getTransactionCard().getAmexMsgRsnCode());
			transactionMREFlatRes.setAmexCardBusCode(transactionMRERes.getTransaction().getTransactionCard().getAmexCardBusCode());
			transactionMREFlatRes.setAmexOrigAmntData01To12(transactionMRERes.getTransaction().getTransactionCard().getAmexOrigAmntData01To12());
			transactionMREFlatRes.setAmexOrigAmntData13To24(transactionMRERes.getTransaction().getTransactionCard().getAmexOrigAmntData13To24());
			transactionMREFlatRes.setAmexAcqRefNbr(transactionMRERes.getTransaction().getTransactionCard().getAmexAcqRefNbr());
			transactionMREFlatRes.setAmexActionCode(transactionMRERes.getTransaction().getTransactionCard().getAmexActionCode());
			transactionMREFlatRes.setAmexCardAcceptName(transactionMRERes.getTransaction().getTransactionCard().getAmexCardAcceptName());
			transactionMREFlatRes.setAmexAdtlResLen(transactionMRERes.getTransaction().getTransactionCard().getAmexAdtlResLen());
			transactionMREFlatRes.setAmexAdtlResDat(transactionMRERes.getTransaction().getTransactionCard().getAmexAdtlResDat());
			transactionMREFlatRes.setAmexAvsResult(transactionMRERes.getTransaction().getTransactionCard().getAmexAvsResult());
			transactionMREFlatRes.setAmexSecCtlResult(transactionMRERes.getTransaction().getTransactionCard().getAmexSecCtlResult());
			transactionMREFlatRes.setAmexAdtlDataLen(transactionMRERes.getTransaction().getTransactionCard().getAmexAdtlDataLen());
			transactionMREFlatRes.setAmexAdtlData(transactionMRERes.getTransaction().getTransactionCard().getAmexAdtlData());
			transactionMREFlatRes.setAmexStipendSent(transactionMRERes.getTransaction().getTransactionCard().getAmexStipendSent());
			transactionMREFlatRes.setAmexStipendParm(transactionMRERes.getTransaction().getTransactionCard().getAmexStipendParm());
			transactionMREFlatRes.setAmexStipendSeType(transactionMRERes.getTransaction().getTransactionCard().getAmexStipendSeType());
			transactionMREFlatRes.setAmexStipendMerType(transactionMRERes.getTransaction().getTransactionCard().getAmexStipendMerType());
			transactionMREFlatRes.setAmexStipendHstIndi(transactionMRERes.getTransaction().getTransactionCard().getAmexStipendHstIndi());
			transactionMREFlatRes.setAmexStiprSent(transactionMRERes.getTransaction().getTransactionCard().getAmexStiprSent());
			transactionMREFlatRes.setAmexStiprParm(transactionMRERes.getTransaction().getTransactionCard().getAmexStiprParm());
			transactionMREFlatRes.setAmexOrigDataLen(transactionMRERes.getTransaction().getTransactionCard().getAmexOrigDataLen());
			transactionMREFlatRes.setAmexODMsgType(transactionMRERes.getTransaction().getTransactionCard().getAmexODMsgType());
			transactionMREFlatRes.setAmexODSysTrace(transactionMRERes.getTransaction().getTransactionCard().getAmexODSysTrace());
			transactionMREFlatRes.setAmexODLclDateTime(transactionMRERes.getTransaction().getTransactionCard().getAmexODLclDateTime());
			transactionMREFlatRes.setAmexODAcqId(transactionMRERes.getTransaction().getTransactionCard().getAmexODAcqId());
			transactionMREFlatRes.setAmexVli(transactionMRERes.getTransaction().getTransactionCard().getAmexVli());
			transactionMREFlatRes.setAmexPriId(transactionMRERes.getTransaction().getTransactionCard().getAmexPriId());
			transactionMREFlatRes.setAmexSecId(transactionMRERes.getTransaction().getTransactionCard().getAmexSecId());
			transactionMREFlatRes.setAmexEci(transactionMRERes.getTransaction().getTransactionCard().getAmexEci());
			transactionMREFlatRes.setAmexAevvRstl(transactionMRERes.getTransaction().getTransactionCard().getAmexAevvRstl());
			transactionMREFlatRes.setAmexAevvId(transactionMRERes.getTransaction().getTransactionCard().getAmexAevvId());
			transactionMREFlatRes.setAmexSub1(transactionMRERes.getTransaction().getTransactionCard().getAmexSub1());
			transactionMREFlatRes.setAmexSub2(transactionMRERes.getTransaction().getTransactionCard().getAmexSub2());
			transactionMREFlatRes.setXid(transactionMRERes.getTransaction().getTransactionCard().getXID());
			transactionMREFlatRes.setXidValue(transactionMRERes.getTransaction().getTransactionCard().getXIDValue());
			transactionMREFlatRes.setAmexFraudIndLen(transactionMRERes.getTransaction().getTransactionCard().getAmexFraudIndLen());
			transactionMREFlatRes.setAmexFraudInd(transactionMRERes.getTransaction().getTransactionCard().getAmexFraudInd());
			transactionMREFlatRes.setAmexPrivUseLen(transactionMRERes.getTransaction().getTransactionCard().getAmexPrivUseLen());
			transactionMREFlatRes.setAmexPrivUseData(transactionMRERes.getTransaction().getTransactionCard().getAmexPrivUseData());
			transactionMREFlatRes.setAmexEadSvcId(transactionMRERes.getTransaction().getTransactionCard().getAmexEadSvcId());
			transactionMREFlatRes.setAmexEadReq(transactionMRERes.getTransaction().getTransactionCard().getAmexEadReq());
			transactionMREFlatRes.setAmexEadPostlCd(transactionMRERes.getTransaction().getTransactionCard().getAmexEadPostlCd());
			transactionMREFlatRes.setAmexEadAddrNbrs(transactionMRERes.getTransaction().getTransactionCard().getAmexEadAddrNbrs());
			transactionMREFlatRes.setAmexOptionalDataLen(transactionMRERes.getTransaction().getTransactionCard().getAmexOptionalDataLen());
			transactionMREFlatRes.setAmexOptionalData(transactionMRERes.getTransaction().getTransactionCard().getAmexOptionalData());
			transactionMREFlatRes.setAmexOptional01To30(transactionMRERes.getTransaction().getTransactionCard().getAmexOptional01To30());
			transactionMREFlatRes.setAmexOptional31To60(transactionMRERes.getTransaction().getTransactionCard().getAmexOptional31To60());
			transactionMREFlatRes.setAmexAdtlData2(transactionMRERes.getTransaction().getTransactionCard().getAmexAdtlData2());
			transactionMREFlatRes.setAuthAdtlDataLen(transactionMRERes.getTransaction().getTransactionCard().getAuthAdtlDataLen());
			transactionMREFlatRes.setAmexIccVerHdrName(transactionMRERes.getTransaction().getTransactionCard().getAmexIccVerHdrName());
			transactionMREFlatRes.setAmexIccVerHdrNbr(transactionMRERes.getTransaction().getTransactionCard().getAmexIccVerHdrNbr());
			transactionMREFlatRes.setAmexApplCrytData(transactionMRERes.getTransaction().getTransactionCard().getAmexApplCrytData());
			transactionMREFlatRes.setAmexIssApplLng(transactionMRERes.getTransaction().getTransactionCard().getAmexIssApplLng());
			transactionMREFlatRes.setAmexIssApplData(transactionMRERes.getTransaction().getTransactionCard().getAmexIssApplData());
			transactionMREFlatRes.setAmexUnpredNbr(transactionMRERes.getTransaction().getTransactionCard().getAmexUnpredNbr());
			transactionMREFlatRes.setAmexAppTranCntr(transactionMRERes.getTransaction().getTransactionCard().getAmexAppTranCntr());
			transactionMREFlatRes.setAmexTvrData(transactionMRERes.getTransaction().getTransactionCard().getAmexTvrData());
			transactionMREFlatRes.setAmexTranDate(transactionMRERes.getTransaction().getTransactionCard().getAmexTranDate());
			transactionMREFlatRes.setAmexTranType(transactionMRERes.getTransaction().getTransactionCard().getAmexTranType());
			transactionMREFlatRes.setAmexAmtAuth(transactionMRERes.getTransaction().getTransactionCard().getAmexAmtAuth());
			transactionMREFlatRes.setAmexTranCurrCode(transactionMRERes.getTransaction().getTransactionCard().getAmexTranCurrCode());
			transactionMREFlatRes.setAmexTermCntryCd(transactionMRERes.getTransaction().getTransactionCard().getAmexTermCntryCd());
			transactionMREFlatRes.setAmexAppIntrData(transactionMRERes.getTransaction().getTransactionCard().getAmexAppIntrData());
			transactionMREFlatRes.setAmexAmtOth(transactionMRERes.getTransaction().getTransactionCard().getAmexAmtOth());
			transactionMREFlatRes.setAmexPanSeqNbr(transactionMRERes.getTransaction().getTransactionCard().getAmexPanSeqNbr());
			transactionMREFlatRes.setAmexCrytInfoDat(transactionMRERes.getTransaction().getTransactionCard().getAmexCrytInfoDat());
			transactionMREFlatRes.setAmexRspAuthTag(transactionMRERes.getTransaction().getTransactionCard().getAmexRspAuthTag());
			transactionMREFlatRes.setAmexRspAuthlen(transactionMRERes.getTransaction().getTransactionCard().getAmexRspAuthlen());
			transactionMREFlatRes.setAmexRspAuthData(transactionMRERes.getTransaction().getTransactionCard().getAmexRspAuthData());
			transactionMREFlatRes.setAmexRspScriptTag(transactionMRERes.getTransaction().getTransactionCard().getAmexRspScriptTag());
			transactionMREFlatRes.setAmexRspScriptLen(transactionMRERes.getTransaction().getTransactionCard().getAmexRspScriptLen());
			transactionMREFlatRes.setAmexRspScriptData(transactionMRERes.getTransaction().getTransactionCard().getAmexRspScriptData());
			transactionMREFlatRes.setPinVerifyIndicator(transactionMRERes.getTransaction().getTransactionCard().getPINVerifyIndicator());
			transactionMREFlatRes.setAfewsTransactionType(transactionMRERes.getTransaction().getTransactionCard().getAfewsTransactionType());
			transactionMREFlatRes.setNfcAssociatedFlag(transactionMRERes.getTransaction().getTransactionCard().getNFCAssociatedFlag());
			transactionMREFlatRes.setTransactionChannelType(transactionMRERes.getTransaction().getTransactionCard().getTransactionChannelType());
			transactionMREFlatRes.setTransactionOriginID(transactionMRERes.getTransaction().getTransactionCard().getTransactionOriginID());
			transactionMREFlatRes.setCupCheck(transactionMRERes.getTransaction().getTransactionCard().getCUPCheck());
			transactionMREFlatRes.setCupTaxID(transactionMRERes.getTransaction().getTransactionCard().getCUPTaxID());
			transactionMREFlatRes.setSafetyNetIndicator(transactionMRERes.getTransaction().getTransactionCard().getSafetyNetIndicator());
			transactionMREFlatRes.setCardTransactionType(transactionMRERes.getTransaction().getTransactionCard().getCardTransactionType());
			transactionMREFlatRes.setDefBalInq(transactionMRERes.getTransaction().getTransactionCard().getDefBalInq());
			transactionMREFlatRes.setFirstUsageFlag(transactionMRERes.getTransaction().getTransactionCard().getFirstUsageFlag());
			transactionMREFlatRes.setMasterAuthResponseCode(transactionMRERes.getTransaction().getTransactionCard().getMasterAuthResponseCode());
			transactionMREFlatRes.setPinBypass(transactionMRERes.getTransaction().getTransactionCard().getPinBypass());
			transactionMREFlatRes.setDomesticTransaction(transactionMRERes.getTransaction().getTransactionCard().getDomesticTransaction());
			transactionMREFlatRes.setPaymentType(transactionMRERes.getTransaction().getTransactionCard().getPaymentType());
			transactionMREFlatRes.setReasonMessage(transactionMRERes.getTransaction().getTransactionCard().getReasonMessage());
			transactionMREFlatRes.setRecipientnameerence(transactionMRERes.getTransaction().getTransactionCard().getRecipientReference());
			transactionMREFlatRes.setTransactionnameerence(transactionMRERes.getTransaction().getTransactionCard().getTransactionReference());
			transactionMREFlatRes.setApplePayInd(transactionMRERes.getTransaction().getTransactionCard().getApplePayInd());

		}
		
		
		if(transactionMRERes.getTransaction().getTransactionDetail() != null){
			
			//Transaction Details
			
			transactionMREFlatRes.setTransactionID(transactionMRERes.getTransaction().getTransactionDetail().getTransactionID());
			transactionMREFlatRes.setTransactionStatus(transactionMRERes.getTransaction().getTransactionDetail().getTransactionStatus());
			transactionMREFlatRes.setTransactionAmount(transactionMRERes.getTransaction().getTransactionDetail().getTransactionAmount());
			transactionMREFlatRes.setTransactionCurrencyCode(transactionMRERes.getTransaction().getTransactionDetail().getTransactionCurrencyCode());
			transactionMREFlatRes.setTransactionDate(formatDate(transactionMRERes.getTransaction().getTransactionDetail().getTransactionDate().toGregorianCalendar()));
			transactionMREFlatRes.setTransactionTime(formatTime(transactionMRERes.getTransaction().getTransactionDetail().getTransactionTime().toGregorianCalendar()));
			transactionMREFlatRes.setTransactionChannel(transactionMRERes.getTransaction().getTransactionDetail().getTransactionChannel());
			transactionMREFlatRes.setTransactionType(transactionMRERes.getTransaction().getTransactionDetail().getTransactionType());
			transactionMREFlatRes.setCreditOrDebitIndicator(transactionMRERes.getTransaction().getTransactionDetail().getCreditOrDebitIndicator());
			transactionMREFlatRes.setTransactionCode(transactionMRERes.getTransaction().getTransactionDetail().getTransactionCode());
			transactionMREFlatRes.setGrbCustomerNumber(transactionMRERes.getTransaction().getTransactionDetail().getGRBCustomerNumber());
			transactionMREFlatRes.setGrbRelationshipNumber(transactionMRERes.getTransaction().getTransactionDetail().getGRBRelationshipNumber());
			transactionMREFlatRes.setTransactionCountry(transactionMRERes.getTransaction().getTransactionDetail().getTransactionCountry());
			transactionMREFlatRes.setTransactionState(transactionMRERes.getTransaction().getTransactionDetail().getTransactionState());
			transactionMREFlatRes.setTransactionCity(transactionMRERes.getTransaction().getTransactionDetail().getTransactionCity());
			transactionMREFlatRes.setResponseCode(transactionMRERes.getTransaction().getTransactionDetail().getResponseCode());
			transactionMREFlatRes.setDeclineReasonCode(transactionMRERes.getTransaction().getTransactionDetail().getDeclineReasonCode());
			transactionMREFlatRes.setIpAddressInternetTxn(transactionMRERes.getTransaction().getTransactionDetail().getIPAddressInternetTxn());
			transactionMREFlatRes.setMacAddress(transactionMRERes.getTransaction().getTransactionDetail().getMACAddress());
			transactionMREFlatRes.setBlockReasonCode(transactionMRERes.getTransaction().getTransactionDetail().getBlockReasonCode());
			transactionMREFlatRes.setBafesTransactionCode(transactionMRERes.getTransaction().getTransactionDetail().getBAFESTransactionCode());
			transactionMREFlatRes.setAuthorizationDescription(transactionMRERes.getTransaction().getTransactionDetail().getAuthorizationDescription());
			transactionMREFlatRes.setApprovalCode(transactionMRERes.getTransaction().getTransactionDetail().getApprovalCode());
			transactionMREFlatRes.setOnlineErrorReturnMsg(transactionMRERes.getTransaction().getTransactionDetail().getOnlineErrorReturnMsg());
			transactionMREFlatRes.setAdditionalTnxDescription1(transactionMRERes.getTransaction().getTransactionDetail().getAdditionalTnxDescription1());
			transactionMREFlatRes.setAdditionalTnxDescription2(transactionMRERes.getTransaction().getTransactionDetail().getAdditionalTnxDescription2());
			transactionMREFlatRes.setAdditionalTnxDescription3(transactionMRERes.getTransaction().getTransactionDetail().getAdditionalTnxDescription3());
			transactionMREFlatRes.setAdditionalTnxDescription4(transactionMRERes.getTransaction().getTransactionDetail().getAdditionalTnxDescription4());
			transactionMREFlatRes.setUserDataField1(transactionMRERes.getTransaction().getTransactionDetail().getUserDataField1());
			transactionMREFlatRes.setUserDataField2(transactionMRERes.getTransaction().getTransactionDetail().getUserDataField2());
			transactionMREFlatRes.setCardNumber(transactionMRERes.getTransaction().getTransactionDetail().getCardNumber());
			transactionMREFlatRes.setMerchantName(transactionMRERes.getTransaction().getTransactionDetail().getMerchantName());
			transactionMREFlatRes.setMerchantID(transactionMRERes.getTransaction().getTransactionDetail().getMerchantID());
			transactionMREFlatRes.setaFewsBillPayChannel(transactionMRERes.getTransaction().getTransactionDetail().getAfewsBillPayChannel());
			transactionMREFlatRes.setBearer_Mob_Num(transactionMRERes.getTransaction().getTransactionDetail().getBearerMobNum());

		}
		
				
		return transactionMREFlatRes;
		
	}

	public String convertObjectToJson(TransactionMREFlatRes transactionMREFlatRes) {
		Gson gObj = new Gson();
		String jsonString = gObj.toJson(transactionMREFlatRes);
		System.out.println("Flattened JSON String: " + jsonString);
		return jsonString;
	}


	public String formatDate(GregorianCalendar calendar){
	    SimpleDateFormat df = new SimpleDateFormat("dd-MMM-yyyy");
	    df.setCalendar(calendar);
	    String dateFormatted = df.format(calendar.getTime());
	    return dateFormatted;
	}
	
	public String formatTime(GregorianCalendar calendar){
	    SimpleDateFormat df = new SimpleDateFormat("HH:mm:ss");
	    df.setCalendar(calendar);
	    String timeFormatted = df.format(calendar.getTime());
	    return timeFormatted;
	}

	public CardActivationFlat getCardActivationFlat(CardActivationRequest cardActivationRequest) {
		CardActivationFlat cardActivationFlat=new CardActivationFlat();
		if(cardActivationRequest.getEvent().getStandard()!=null){
			cardActivationFlat.setCorrelationID(cardActivationRequest.getEvent().getStandard().getCorrelationID());
			cardActivationFlat.setEventID(cardActivationRequest.getEvent().getStandard().getEventID());
			cardActivationFlat.setEventUUID(cardActivationRequest.getEvent().getStandard().getEventUUID());
			cardActivationFlat.setEventProducer(cardActivationRequest.getEvent().getStandard().getEventProducer());
			cardActivationFlat.setEventTransmitter(cardActivationRequest.getEvent().getStandard().getEventTransmitter());
			cardActivationFlat.setCountryCode(cardActivationRequest.getEvent().getStandard().getCountryCode());
			cardActivationFlat.setBusinessID(cardActivationRequest.getEvent().getStandard().getBusinessID());
			cardActivationFlat.setUUID_UniqueID(cardActivationRequest.getEvent().getStandard().getUUID_UniqueID());
			cardActivationFlat.setESBUUID(cardActivationRequest.getEvent().getStandard().getESBUUID());
			cardActivationFlat.setBizFunctionID(cardActivationRequest.getEvent().getStandard().getBizFunctionID());
			cardActivationFlat.setCustomerID(cardActivationRequest.getEvent().getStandard().getCustomerID());
			cardActivationFlat.setCustomerType(cardActivationRequest.getEvent().getStandard().getCustomerType());
			cardActivationFlat.setCardNumber(cardActivationRequest.getEvent().getStandard().getCardNumber());
		    cardActivationFlat.setAccountNumber(cardActivationRequest.getEvent().getStandard().getAccountNumber());
			cardActivationFlat.setIsCustomerPrimary(cardActivationRequest.getEvent().getStandard().getIsCustomerPrimary());
			cardActivationFlat.setTransactionStatus(cardActivationRequest.getEvent().getStandard().getTransactionStatus());
			cardActivationFlat.setTransactionType(cardActivationRequest.getEvent().getStandard().getTransactionType());
			cardActivationFlat.setRespStatusCode(cardActivationRequest.getEvent().getStandard().getRespStatusCode());
			cardActivationFlat.setRespStatusMsg(cardActivationRequest.getEvent().getStandard().getRespStatusMsg());
		    cardActivationFlat.setServerDateTime(cardActivationRequest.getEvent().getStandard().getServerDateTime());
		    cardActivationFlat.setTouchPoint(cardActivationRequest.getEvent().getStandard().getTouchPoint());
		    cardActivationFlat.setAssistedChannelUserID(cardActivationRequest.getEvent().getStandard().getAssistedChannelUserID());
		}
		
	    if(cardActivationRequest.getEvent().getMetadata()!=null){
	    	cardActivationFlat.setOriginatorFunctionID(cardActivationRequest.getEvent().getMetadata().getOriginatorFunctionID());
		    cardActivationFlat.setOriginatorFunctionType(cardActivationRequest.getEvent().getMetadata().getOriginatorFunctionType());
		    cardActivationFlat.setOriginatorSubFunctionID(cardActivationRequest.getEvent().getMetadata().getOriginatorSubFunctionID());
			cardActivationFlat.setOriginatorFunctionSubType(cardActivationRequest.getEvent().getMetadata().getOriginatorFunctionSubType());
	    }
	    
		if(cardActivationRequest.getEvent().getCustomerAccess()!=null){
			cardActivationFlat.setChannelSessionId(cardActivationRequest.getEvent().getCustomerAccess().getChannelSessionId());
			cardActivationFlat.setDeviceType(cardActivationRequest.getEvent().getCustomerAccess().getDeviceType());
			cardActivationFlat.setDeviceID(cardActivationRequest.getEvent().getCustomerAccess().getDeviceID());
			cardActivationFlat.setDeviceOS(cardActivationRequest.getEvent().getCustomerAccess().getDeviceOS());
			cardActivationFlat.setGeoLocLatitude(cardActivationRequest.getEvent().getCustomerAccess().getGeoLocLatitude());
		    cardActivationFlat.setGeoLocLongitude(cardActivationRequest.getEvent().getCustomerAccess().getGeoLocLongitude());
		    cardActivationFlat.setBrowserName(cardActivationRequest.getEvent().getCustomerAccess().getBrowserName());
		    cardActivationFlat.setClientIPAddress(cardActivationRequest.getEvent().getCustomerAccess().getClientIPAddress());
		}
	    
	    if(cardActivationRequest.getEvent().getExtended()!=null){
	    	cardActivationFlat.setProductType(cardActivationRequest.getEvent().getExtended().getProductType());
	    	cardActivationFlat.setMerchantName(cardActivationRequest.getEvent().getExtended().getMerchantName());
	    	cardActivationFlat.setTransactionAmount(cardActivationRequest.getEvent().getExtended().getTransactionAmount());
	    	cardActivationFlat.setTransactionCurrency(cardActivationRequest.getEvent().getExtended().getTransactionCurrency());
	    }
		
		return cardActivationFlat;
	}
	
	public AccountLinkageFlat getAccountLinkageFlat(AccountLinkageRequest accountLinkageRequest) {
		AccountLinkageFlat accountLinkageFlat=new AccountLinkageFlat();
		if(accountLinkageRequest.getEvent().getStandard()!=null){
			accountLinkageFlat.setCorrelationID(accountLinkageRequest.getEvent().getStandard().getCorrelationID());
			accountLinkageFlat.setEventID(accountLinkageRequest.getEvent().getStandard().getEventID());
			accountLinkageFlat.setEventUUID(accountLinkageRequest.getEvent().getStandard().getEventUUID());
			accountLinkageFlat.setEventProducer(accountLinkageRequest.getEvent().getStandard().getEventProducer());
			accountLinkageFlat.setEventTransmitter(accountLinkageRequest.getEvent().getStandard().getEventTransmitter());
			accountLinkageFlat.setCountryCode(accountLinkageRequest.getEvent().getStandard().getCountryCode());
			accountLinkageFlat.setBusinessID(accountLinkageRequest.getEvent().getStandard().getBusinessID());
			accountLinkageFlat.setUUID_UniqueID(accountLinkageRequest.getEvent().getStandard().getUUID_UniqueID());
			accountLinkageFlat.setESBUUID(accountLinkageRequest.getEvent().getStandard().getESBUUID());
			accountLinkageFlat.setBizFunctionID(accountLinkageRequest.getEvent().getStandard().getBizFunctionID());
			accountLinkageFlat.setCustomerID(accountLinkageRequest.getEvent().getStandard().getCustomerID());
			accountLinkageFlat.setCustomerType(accountLinkageRequest.getEvent().getStandard().getCustomerType());
			accountLinkageFlat.setCardNumber(accountLinkageRequest.getEvent().getStandard().getCardNumber());
		    accountLinkageFlat.setAccountNumber(accountLinkageRequest.getEvent().getStandard().getAccountNumber());
			accountLinkageFlat.setIsCustomerPrimary(accountLinkageRequest.getEvent().getStandard().getIsCustomerPrimary());
			accountLinkageFlat.setTransactionStatus(accountLinkageRequest.getEvent().getStandard().getTransactionStatus());
			accountLinkageFlat.setTransactionType(accountLinkageRequest.getEvent().getStandard().getTransactionType());
			accountLinkageFlat.setRespStatusCode(accountLinkageRequest.getEvent().getStandard().getRespStatusCode());
			accountLinkageFlat.setRespStatusMsg(accountLinkageRequest.getEvent().getStandard().getRespStatusMsg());
		    accountLinkageFlat.setServerDateTime(accountLinkageRequest.getEvent().getStandard().getServerDateTime());
		    accountLinkageFlat.setTouchPoint(accountLinkageRequest.getEvent().getStandard().getTouchPoint());
		    accountLinkageFlat.setAssistedChannelUserID(accountLinkageRequest.getEvent().getStandard().getAssistedChannelUserID());
		}
		
	    if(accountLinkageRequest.getEvent().getMetadata()!=null){
	    	accountLinkageFlat.setOriginatorFunctionID(accountLinkageRequest.getEvent().getMetadata().getOriginatorFunctionID());
		    accountLinkageFlat.setOriginatorFunctionType(accountLinkageRequest.getEvent().getMetadata().getOriginatorFunctionType());
		    accountLinkageFlat.setOriginatorSubFunctionID(accountLinkageRequest.getEvent().getMetadata().getOriginatorSubFunctionID());
			accountLinkageFlat.setOriginatorFunctionSubType(accountLinkageRequest.getEvent().getMetadata().getOriginatorFunctionSubType());
	    }
	    
		if(accountLinkageRequest.getEvent().getCustomerAccess()!=null){
			accountLinkageFlat.setChannelSessionId(accountLinkageRequest.getEvent().getCustomerAccess().getChannelSessionId());
			accountLinkageFlat.setDeviceType(accountLinkageRequest.getEvent().getCustomerAccess().getDeviceType());
			accountLinkageFlat.setDeviceID(accountLinkageRequest.getEvent().getCustomerAccess().getDeviceID());
			accountLinkageFlat.setDeviceOS(accountLinkageRequest.getEvent().getCustomerAccess().getDeviceOS());
			accountLinkageFlat.setGeoLocLatitude(accountLinkageRequest.getEvent().getCustomerAccess().getGeoLocLatitude());
		    accountLinkageFlat.setGeoLocLongitude(accountLinkageRequest.getEvent().getCustomerAccess().getGeoLocLongitude());
		    accountLinkageFlat.setBrowserName(accountLinkageRequest.getEvent().getCustomerAccess().getBrowserName());
		    accountLinkageFlat.setClientIPAddress(accountLinkageRequest.getEvent().getCustomerAccess().getClientIPAddress());
		}
		
		return accountLinkageFlat;
	}
	
	public AccountSummaryFlat getAccountSummaryFlat(AccountSummaryRequest accountSummaryRequest) {
		AccountSummaryFlat accountSummaryFlat=new AccountSummaryFlat();
		if(accountSummaryRequest.getEvent().getStandard()!=null){
			accountSummaryFlat.setCorrelationID(accountSummaryRequest.getEvent().getStandard().getCorrelationID());
			accountSummaryFlat.setEventID(accountSummaryRequest.getEvent().getStandard().getEventID());
			accountSummaryFlat.setEventUUID(accountSummaryRequest.getEvent().getStandard().getEventUUID());
			accountSummaryFlat.setEventProducer(accountSummaryRequest.getEvent().getStandard().getEventProducer());
			accountSummaryFlat.setEventTransmitter(accountSummaryRequest.getEvent().getStandard().getEventTransmitter());
			accountSummaryFlat.setCountryCode(accountSummaryRequest.getEvent().getStandard().getCountryCode());
			accountSummaryFlat.setBusinessID(accountSummaryRequest.getEvent().getStandard().getBusinessID());
			accountSummaryFlat.setUUID_UniqueID(accountSummaryRequest.getEvent().getStandard().getUUID_UniqueID());
			accountSummaryFlat.setESBUUID(accountSummaryRequest.getEvent().getStandard().getESBUUID());
			accountSummaryFlat.setBizFunctionID(accountSummaryRequest.getEvent().getStandard().getBizFunctionID());
			accountSummaryFlat.setCustomerID(accountSummaryRequest.getEvent().getStandard().getCustomerID());
			accountSummaryFlat.setCustomerType(accountSummaryRequest.getEvent().getStandard().getCustomerType());
			accountSummaryFlat.setCardNumber(accountSummaryRequest.getEvent().getStandard().getCardNumber());
		    accountSummaryFlat.setAccountNumber(accountSummaryRequest.getEvent().getStandard().getAccountNumber());
			accountSummaryFlat.setIsCustomerPrimary(accountSummaryRequest.getEvent().getStandard().getIsCustomerPrimary());
			accountSummaryFlat.setTransactionStatus(accountSummaryRequest.getEvent().getStandard().getTransactionStatus());
			accountSummaryFlat.setTransactionType(accountSummaryRequest.getEvent().getStandard().getTransactionType());
			accountSummaryFlat.setRespStatusCode(accountSummaryRequest.getEvent().getStandard().getRespStatusCode());
			accountSummaryFlat.setRespStatusMsg(accountSummaryRequest.getEvent().getStandard().getRespStatusMsg());
		    accountSummaryFlat.setServerDateTime(accountSummaryRequest.getEvent().getStandard().getServerDateTime());
		    accountSummaryFlat.setTouchPoint(accountSummaryRequest.getEvent().getStandard().getTouchPoint());
		    accountSummaryFlat.setAssistedChannelUserID(accountSummaryRequest.getEvent().getStandard().getAssistedChannelUserID());
		}
		
	    if(accountSummaryRequest.getEvent().getMetadata()!=null){
	    	accountSummaryFlat.setOriginatorFunctionID(accountSummaryRequest.getEvent().getMetadata().getOriginatorFunctionID());
		    accountSummaryFlat.setOriginatorFunctionType(accountSummaryRequest.getEvent().getMetadata().getOriginatorFunctionType());
		    accountSummaryFlat.setOriginatorSubFunctionID(accountSummaryRequest.getEvent().getMetadata().getOriginatorSubFunctionID());
			accountSummaryFlat.setOriginatorFunctionSubType(accountSummaryRequest.getEvent().getMetadata().getOriginatorFunctionSubType());
	    }
	    
		if(accountSummaryRequest.getEvent().getCustomerAccess()!=null){
			accountSummaryFlat.setChannelSessionId(accountSummaryRequest.getEvent().getCustomerAccess().getChannelSessionId());
			accountSummaryFlat.setDeviceType(accountSummaryRequest.getEvent().getCustomerAccess().getDeviceType());
			accountSummaryFlat.setDeviceID(accountSummaryRequest.getEvent().getCustomerAccess().getDeviceID());
			accountSummaryFlat.setDeviceOS(accountSummaryRequest.getEvent().getCustomerAccess().getDeviceOS());
			accountSummaryFlat.setGeoLocLatitude(accountSummaryRequest.getEvent().getCustomerAccess().getGeoLocLatitude());
		    accountSummaryFlat.setGeoLocLongitude(accountSummaryRequest.getEvent().getCustomerAccess().getGeoLocLongitude());
		    accountSummaryFlat.setBrowserName(accountSummaryRequest.getEvent().getCustomerAccess().getBrowserName());
		    accountSummaryFlat.setClientIPAddress(accountSummaryRequest.getEvent().getCustomerAccess().getClientIPAddress());
		}
	    
		return accountSummaryFlat;
	}
	
	public APINChangeFlat getAPINChangeFlat(APINChangeRequest apinChangeRequest) {
		APINChangeFlat apinChangeFlat=new APINChangeFlat();
		if(apinChangeRequest.getEvent().getStandard()!=null){
			apinChangeFlat.setCorrelationID(apinChangeRequest.getEvent().getStandard().getCorrelationID());
			apinChangeFlat.setEventID(apinChangeRequest.getEvent().getStandard().getEventID());
			apinChangeFlat.setEventUUID(apinChangeRequest.getEvent().getStandard().getEventUUID());
			apinChangeFlat.setEventProducer(apinChangeRequest.getEvent().getStandard().getEventProducer());
			apinChangeFlat.setEventTransmitter(apinChangeRequest.getEvent().getStandard().getEventTransmitter());
			apinChangeFlat.setCountryCode(apinChangeRequest.getEvent().getStandard().getCountryCode());
			apinChangeFlat.setBusinessID(apinChangeRequest.getEvent().getStandard().getBusinessID());
			apinChangeFlat.setUUID_UniqueID(apinChangeRequest.getEvent().getStandard().getUUID_UniqueID());
			apinChangeFlat.setESBUUID(apinChangeRequest.getEvent().getStandard().getESBUUID());
			apinChangeFlat.setBizFunctionID(apinChangeRequest.getEvent().getStandard().getBizFunctionID());
			apinChangeFlat.setCustomerID(apinChangeRequest.getEvent().getStandard().getCustomerID());
			apinChangeFlat.setCustomerType(apinChangeRequest.getEvent().getStandard().getCustomerType());
			apinChangeFlat.setCardNumber(apinChangeRequest.getEvent().getStandard().getCardNumber());
		    apinChangeFlat.setAccountNumber(apinChangeRequest.getEvent().getStandard().getAccountNumber());
			apinChangeFlat.setIsCustomerPrimary(apinChangeRequest.getEvent().getStandard().getIsCustomerPrimary());
			apinChangeFlat.setTransactionStatus(apinChangeRequest.getEvent().getStandard().getTransactionStatus());
			apinChangeFlat.setTransactionType(apinChangeRequest.getEvent().getStandard().getTransactionType());
			apinChangeFlat.setRespStatusCode(apinChangeRequest.getEvent().getStandard().getRespStatusCode());
			apinChangeFlat.setRespStatusMsg(apinChangeRequest.getEvent().getStandard().getRespStatusMsg());
		    apinChangeFlat.setServerDateTime(apinChangeRequest.getEvent().getStandard().getServerDateTime());
		    apinChangeFlat.setTouchPoint(apinChangeRequest.getEvent().getStandard().getTouchPoint());
		    apinChangeFlat.setAssistedChannelUserID(apinChangeRequest.getEvent().getStandard().getAssistedChannelUserID());
		}
		
	    if(apinChangeRequest.getEvent().getMetadata()!=null){
	    	apinChangeFlat.setOriginatorFunctionID(apinChangeRequest.getEvent().getMetadata().getOriginatorFunctionID());
		    apinChangeFlat.setOriginatorFunctionType(apinChangeRequest.getEvent().getMetadata().getOriginatorFunctionType());
		    apinChangeFlat.setOriginatorSubFunctionID(apinChangeRequest.getEvent().getMetadata().getOriginatorSubFunctionID());
			apinChangeFlat.setOriginatorFunctionSubType(apinChangeRequest.getEvent().getMetadata().getOriginatorFunctionSubType());
	    }
	    
		if(apinChangeRequest.getEvent().getCustomerAccess()!=null){
			apinChangeFlat.setChannelSessionId(apinChangeRequest.getEvent().getCustomerAccess().getChannelSessionId());
			apinChangeFlat.setDeviceType(apinChangeRequest.getEvent().getCustomerAccess().getDeviceType());
			apinChangeFlat.setDeviceID(apinChangeRequest.getEvent().getCustomerAccess().getDeviceID());
			apinChangeFlat.setDeviceOS(apinChangeRequest.getEvent().getCustomerAccess().getDeviceOS());
			apinChangeFlat.setGeoLocLatitude(apinChangeRequest.getEvent().getCustomerAccess().getGeoLocLatitude());
		    apinChangeFlat.setGeoLocLongitude(apinChangeRequest.getEvent().getCustomerAccess().getGeoLocLongitude());
		    apinChangeFlat.setBrowserName(apinChangeRequest.getEvent().getCustomerAccess().getBrowserName());
		    apinChangeFlat.setClientIPAddress(apinChangeRequest.getEvent().getCustomerAccess().getClientIPAddress());
		}
	    
		
		return apinChangeFlat;
	}
	
	public BillPaymentFlat getBillPaymentFlat(BillPaymentRequest billPaymentRequest) {
		BillPaymentFlat billPaymentFlat=new BillPaymentFlat();
		if(billPaymentRequest.getEvent().getStandard()!=null){
			billPaymentFlat.setCorrelationID(billPaymentRequest.getEvent().getStandard().getCorrelationID());
			billPaymentFlat.setEventID(billPaymentRequest.getEvent().getStandard().getEventID());
			billPaymentFlat.setEventUUID(billPaymentRequest.getEvent().getStandard().getEventUUID());
			billPaymentFlat.setEventProducer(billPaymentRequest.getEvent().getStandard().getEventProducer());
			billPaymentFlat.setEventTransmitter(billPaymentRequest.getEvent().getStandard().getEventTransmitter());
			billPaymentFlat.setCountryCode(billPaymentRequest.getEvent().getStandard().getCountryCode());
			billPaymentFlat.setBusinessID(billPaymentRequest.getEvent().getStandard().getBusinessID());
			billPaymentFlat.setUUID_UniqueID(billPaymentRequest.getEvent().getStandard().getUUID_UniqueID());
			billPaymentFlat.setESBUUID(billPaymentRequest.getEvent().getStandard().getESBUUID());
			billPaymentFlat.setBizFunctionID(billPaymentRequest.getEvent().getStandard().getBizFunctionID());
			billPaymentFlat.setCustomerID(billPaymentRequest.getEvent().getStandard().getCustomerID());
			billPaymentFlat.setCustomerType(billPaymentRequest.getEvent().getStandard().getCustomerType());
			billPaymentFlat.setCardNumber(billPaymentRequest.getEvent().getStandard().getCardNumber());
		    billPaymentFlat.setAccountNumber(billPaymentRequest.getEvent().getStandard().getAccountNumber());
			billPaymentFlat.setIsCustomerPrimary(billPaymentRequest.getEvent().getStandard().getIsCustomerPrimary());
			billPaymentFlat.setTransactionStatus(billPaymentRequest.getEvent().getStandard().getTransactionStatus());
			billPaymentFlat.setTransactionType(billPaymentRequest.getEvent().getStandard().getTransactionType());
			billPaymentFlat.setRespStatusCode(billPaymentRequest.getEvent().getStandard().getRespStatusCode());
			billPaymentFlat.setRespStatusMsg(billPaymentRequest.getEvent().getStandard().getRespStatusMsg());
		    billPaymentFlat.setServerDateTime(billPaymentRequest.getEvent().getStandard().getServerDateTime());
		    billPaymentFlat.setTouchPoint(billPaymentRequest.getEvent().getStandard().getTouchPoint());
		    billPaymentFlat.setAssistedChannelUserID(billPaymentRequest.getEvent().getStandard().getAssistedChannelUserID());
		}
		
	    if(billPaymentRequest.getEvent().getMetadata()!=null){
	    	billPaymentFlat.setOriginatorFunctionID(billPaymentRequest.getEvent().getMetadata().getOriginatorFunctionID());
		    billPaymentFlat.setOriginatorFunctionType(billPaymentRequest.getEvent().getMetadata().getOriginatorFunctionType());
		    billPaymentFlat.setOriginatorSubFunctionID(billPaymentRequest.getEvent().getMetadata().getOriginatorSubFunctionID());
			billPaymentFlat.setOriginatorFunctionSubType(billPaymentRequest.getEvent().getMetadata().getOriginatorFunctionSubType());
	    }
	    
		if(billPaymentRequest.getEvent().getCustomerAccess()!=null){
			billPaymentFlat.setChannelSessionId(billPaymentRequest.getEvent().getCustomerAccess().getChannelSessionId());
			billPaymentFlat.setDeviceType(billPaymentRequest.getEvent().getCustomerAccess().getDeviceType());
			billPaymentFlat.setDeviceID(billPaymentRequest.getEvent().getCustomerAccess().getDeviceID());
			billPaymentFlat.setDeviceOS(billPaymentRequest.getEvent().getCustomerAccess().getDeviceOS());
			billPaymentFlat.setGeoLocLatitude(billPaymentRequest.getEvent().getCustomerAccess().getGeoLocLatitude());
		    billPaymentFlat.setGeoLocLongitude(billPaymentRequest.getEvent().getCustomerAccess().getGeoLocLongitude());
		    billPaymentFlat.setBrowserName(billPaymentRequest.getEvent().getCustomerAccess().getBrowserName());
		    billPaymentFlat.setClientIPAddress(billPaymentRequest.getEvent().getCustomerAccess().getClientIPAddress());
		}
	    
	    if(billPaymentRequest.getEvent().getExtended()!=null){
	    	billPaymentFlat.setMerchantName(billPaymentRequest.getEvent().getExtended().getMerchantName());
	    	billPaymentFlat.setMerchantNo(billPaymentRequest.getEvent().getExtended().getMerchantNo());
	    	billPaymentFlat.setReferenceNo(billPaymentRequest.getEvent().getExtended().getReferenceNo());
	    	billPaymentFlat.setSourceAccountNo(billPaymentRequest.getEvent().getExtended().getSourceAccountNo());
	    	billPaymentFlat.setPaymentAmount(billPaymentRequest.getEvent().getExtended().getPaymentAmount());
	    	billPaymentFlat.setCurrency(billPaymentRequest.getEvent().getExtended().getCurrency());
	    }
		
		return billPaymentFlat;
	}
	
	public CardBlockCodeUpdateFlat getCardBlockCodeUpdateFlat(CardBlockCodeUpdateRequest cardBlockCodeUpdateRequest) {
		CardBlockCodeUpdateFlat cardBlockCodeUpdateFlat=new CardBlockCodeUpdateFlat();
		if(cardBlockCodeUpdateRequest.getEvent().getStandard()!=null){
			cardBlockCodeUpdateFlat.setCorrelationID(cardBlockCodeUpdateRequest.getEvent().getStandard().getCorrelationID());
			cardBlockCodeUpdateFlat.setEventID(cardBlockCodeUpdateRequest.getEvent().getStandard().getEventID());
			cardBlockCodeUpdateFlat.setEventUUID(cardBlockCodeUpdateRequest.getEvent().getStandard().getEventUUID());
			cardBlockCodeUpdateFlat.setEventProducer(cardBlockCodeUpdateRequest.getEvent().getStandard().getEventProducer());
			cardBlockCodeUpdateFlat.setEventTransmitter(cardBlockCodeUpdateRequest.getEvent().getStandard().getEventTransmitter());
			cardBlockCodeUpdateFlat.setCountryCode(cardBlockCodeUpdateRequest.getEvent().getStandard().getCountryCode());
			cardBlockCodeUpdateFlat.setBusinessID(cardBlockCodeUpdateRequest.getEvent().getStandard().getBusinessID());
			cardBlockCodeUpdateFlat.setUUID_UniqueID(cardBlockCodeUpdateRequest.getEvent().getStandard().getUUID_UniqueID());
			cardBlockCodeUpdateFlat.setESBUUID(cardBlockCodeUpdateRequest.getEvent().getStandard().getESBUUID());
			cardBlockCodeUpdateFlat.setBizFunctionID(cardBlockCodeUpdateRequest.getEvent().getStandard().getBizFunctionID());
			cardBlockCodeUpdateFlat.setCustomerID(cardBlockCodeUpdateRequest.getEvent().getStandard().getCustomerID());
			cardBlockCodeUpdateFlat.setCustomerType(cardBlockCodeUpdateRequest.getEvent().getStandard().getCustomerType());
			cardBlockCodeUpdateFlat.setCardNumber(cardBlockCodeUpdateRequest.getEvent().getStandard().getCardNumber());
		    cardBlockCodeUpdateFlat.setAccountNumber(cardBlockCodeUpdateRequest.getEvent().getStandard().getAccountNumber());
			cardBlockCodeUpdateFlat.setIsCustomerPrimary(cardBlockCodeUpdateRequest.getEvent().getStandard().getIsCustomerPrimary());
			cardBlockCodeUpdateFlat.setTransactionStatus(cardBlockCodeUpdateRequest.getEvent().getStandard().getTransactionStatus());
			cardBlockCodeUpdateFlat.setTransactionType(cardBlockCodeUpdateRequest.getEvent().getStandard().getTransactionType());
			cardBlockCodeUpdateFlat.setRespStatusCode(cardBlockCodeUpdateRequest.getEvent().getStandard().getRespStatusCode());
			cardBlockCodeUpdateFlat.setRespStatusMsg(cardBlockCodeUpdateRequest.getEvent().getStandard().getRespStatusMsg());
		    cardBlockCodeUpdateFlat.setServerDateTime(cardBlockCodeUpdateRequest.getEvent().getStandard().getServerDateTime());
		    cardBlockCodeUpdateFlat.setTouchPoint(cardBlockCodeUpdateRequest.getEvent().getStandard().getTouchPoint());
		    cardBlockCodeUpdateFlat.setAssistedChannelUserID(cardBlockCodeUpdateRequest.getEvent().getStandard().getAssistedChannelUserID());
		}
		
	    if(cardBlockCodeUpdateRequest.getEvent().getMetadata()!=null){
	    	cardBlockCodeUpdateFlat.setOriginatorFunctionID(cardBlockCodeUpdateRequest.getEvent().getMetadata().getOriginatorFunctionID());
		    cardBlockCodeUpdateFlat.setOriginatorFunctionType(cardBlockCodeUpdateRequest.getEvent().getMetadata().getOriginatorFunctionType());
		    cardBlockCodeUpdateFlat.setOriginatorSubFunctionID(cardBlockCodeUpdateRequest.getEvent().getMetadata().getOriginatorSubFunctionID());
			cardBlockCodeUpdateFlat.setOriginatorFunctionSubType(cardBlockCodeUpdateRequest.getEvent().getMetadata().getOriginatorFunctionSubType());
	    }
	    
		if(cardBlockCodeUpdateRequest.getEvent().getCustomerAccess()!=null){
			cardBlockCodeUpdateFlat.setChannelSessionId(cardBlockCodeUpdateRequest.getEvent().getCustomerAccess().getChannelSessionId());
			cardBlockCodeUpdateFlat.setDeviceType(cardBlockCodeUpdateRequest.getEvent().getCustomerAccess().getDeviceType());
			cardBlockCodeUpdateFlat.setDeviceID(cardBlockCodeUpdateRequest.getEvent().getCustomerAccess().getDeviceID());
			cardBlockCodeUpdateFlat.setDeviceOS(cardBlockCodeUpdateRequest.getEvent().getCustomerAccess().getDeviceOS());
			cardBlockCodeUpdateFlat.setGeoLocLatitude(cardBlockCodeUpdateRequest.getEvent().getCustomerAccess().getGeoLocLatitude());
		    cardBlockCodeUpdateFlat.setGeoLocLongitude(cardBlockCodeUpdateRequest.getEvent().getCustomerAccess().getGeoLocLongitude());
		    cardBlockCodeUpdateFlat.setBrowserName(cardBlockCodeUpdateRequest.getEvent().getCustomerAccess().getBrowserName());
		    cardBlockCodeUpdateFlat.setClientIPAddress(cardBlockCodeUpdateRequest.getEvent().getCustomerAccess().getClientIPAddress());
		}
	    
		
		return cardBlockCodeUpdateFlat;
	}
	
	public CardDeclineFlat getCardDeclineFlat(CardDeclineRequest cardDeclineRequest) {
		CardDeclineFlat cardDeclineFlat=new CardDeclineFlat();
		if(cardDeclineRequest.getEvent().getStandard()!=null){
			cardDeclineFlat.setCorrelationID(cardDeclineRequest.getEvent().getStandard().getCorrelationID());
			cardDeclineFlat.setEventID(cardDeclineRequest.getEvent().getStandard().getEventID());
			cardDeclineFlat.setEventUUID(cardDeclineRequest.getEvent().getStandard().getEventUUID());
			cardDeclineFlat.setEventProducer(cardDeclineRequest.getEvent().getStandard().getEventProducer());
			cardDeclineFlat.setEventTransmitter(cardDeclineRequest.getEvent().getStandard().getEventTransmitter());
			cardDeclineFlat.setCountryCode(cardDeclineRequest.getEvent().getStandard().getCountryCode());
			cardDeclineFlat.setBusinessID(cardDeclineRequest.getEvent().getStandard().getBusinessID());
			cardDeclineFlat.setUUID_UniqueID(cardDeclineRequest.getEvent().getStandard().getUUID_UniqueID());
			cardDeclineFlat.setESBUUID(cardDeclineRequest.getEvent().getStandard().getESBUUID());
			cardDeclineFlat.setBizFunctionID(cardDeclineRequest.getEvent().getStandard().getBizFunctionID());
			cardDeclineFlat.setCustomerID(cardDeclineRequest.getEvent().getStandard().getCustomerID());
			cardDeclineFlat.setCustomerType(cardDeclineRequest.getEvent().getStandard().getCustomerType());
			cardDeclineFlat.setCardNumber(cardDeclineRequest.getEvent().getStandard().getCardNumber());
		    cardDeclineFlat.setAccountNumber(cardDeclineRequest.getEvent().getStandard().getAccountNumber());
			cardDeclineFlat.setIsCustomerPrimary(cardDeclineRequest.getEvent().getStandard().getIsCustomerPrimary());
			cardDeclineFlat.setTransactionStatus(cardDeclineRequest.getEvent().getStandard().getTransactionStatus());
			cardDeclineFlat.setTransactionType(cardDeclineRequest.getEvent().getStandard().getTransactionType());
			cardDeclineFlat.setRespStatusCode(cardDeclineRequest.getEvent().getStandard().getRespStatusCode());
			cardDeclineFlat.setRespStatusMsg(cardDeclineRequest.getEvent().getStandard().getRespStatusMsg());
		    cardDeclineFlat.setServerDateTime(cardDeclineRequest.getEvent().getStandard().getServerDateTime());
		    cardDeclineFlat.setTouchPoint(cardDeclineRequest.getEvent().getStandard().getTouchPoint());
		    cardDeclineFlat.setAssistedChannelUserID(cardDeclineRequest.getEvent().getStandard().getAssistedChannelUserID());
		}
		
	    if(cardDeclineRequest.getEvent().getMetadata()!=null){
	    	cardDeclineFlat.setOriginatorFunctionID(cardDeclineRequest.getEvent().getMetadata().getOriginatorFunctionID());
		    cardDeclineFlat.setOriginatorFunctionType(cardDeclineRequest.getEvent().getMetadata().getOriginatorFunctionType());
		    cardDeclineFlat.setOriginatorSubFunctionID(cardDeclineRequest.getEvent().getMetadata().getOriginatorSubFunctionID());
			cardDeclineFlat.setOriginatorFunctionSubType(cardDeclineRequest.getEvent().getMetadata().getOriginatorFunctionSubType());
	    }
	    
		if(cardDeclineRequest.getEvent().getCustomerAccess()!=null){
			cardDeclineFlat.setChannelSessionId(cardDeclineRequest.getEvent().getCustomerAccess().getChannelSessionId());
			cardDeclineFlat.setDeviceType(cardDeclineRequest.getEvent().getCustomerAccess().getDeviceType());
			cardDeclineFlat.setDeviceID(cardDeclineRequest.getEvent().getCustomerAccess().getDeviceID());
			cardDeclineFlat.setDeviceOS(cardDeclineRequest.getEvent().getCustomerAccess().getDeviceOS());
			cardDeclineFlat.setGeoLocLatitude(cardDeclineRequest.getEvent().getCustomerAccess().getGeoLocLatitude());
		    cardDeclineFlat.setGeoLocLongitude(cardDeclineRequest.getEvent().getCustomerAccess().getGeoLocLongitude());
		    cardDeclineFlat.setBrowserName(cardDeclineRequest.getEvent().getCustomerAccess().getBrowserName());
		    cardDeclineFlat.setClientIPAddress(cardDeclineRequest.getEvent().getCustomerAccess().getClientIPAddress());
		}
	    
	    if(cardDeclineRequest.getEvent().getExtended()!=null){
	    	cardDeclineFlat.setProductType(cardDeclineRequest.getEvent().getExtended().getProductType());
	    }
		
		return cardDeclineFlat;
	}
	
	public CBOLMBOLRegistrationFlat getCBOLMBOLRegistrationFlat(CBOLMBOLRegistrationRequest cbolmbolRegistrationRequest) {
		CBOLMBOLRegistrationFlat cbolmbolRegistrationFlat=new CBOLMBOLRegistrationFlat();
		if(cbolmbolRegistrationRequest.getEvent().getStandard()!=null){
			cbolmbolRegistrationFlat.setCorrelationID(cbolmbolRegistrationRequest.getEvent().getStandard().getCorrelationID());
			cbolmbolRegistrationFlat.setEventID(cbolmbolRegistrationRequest.getEvent().getStandard().getEventID());
			cbolmbolRegistrationFlat.setEventUUID(cbolmbolRegistrationRequest.getEvent().getStandard().getEventUUID());
			cbolmbolRegistrationFlat.setEventProducer(cbolmbolRegistrationRequest.getEvent().getStandard().getEventProducer());
			cbolmbolRegistrationFlat.setEventTransmitter(cbolmbolRegistrationRequest.getEvent().getStandard().getEventTransmitter());
			cbolmbolRegistrationFlat.setCountryCode(cbolmbolRegistrationRequest.getEvent().getStandard().getCountryCode());
			cbolmbolRegistrationFlat.setBusinessID(cbolmbolRegistrationRequest.getEvent().getStandard().getBusinessID());
			cbolmbolRegistrationFlat.setUUID_UniqueID(cbolmbolRegistrationRequest.getEvent().getStandard().getUUID_UniqueID());
			cbolmbolRegistrationFlat.setESBUUID(cbolmbolRegistrationRequest.getEvent().getStandard().getESBUUID());
			cbolmbolRegistrationFlat.setBizFunctionID(cbolmbolRegistrationRequest.getEvent().getStandard().getBizFunctionID());
			cbolmbolRegistrationFlat.setCustomerID(cbolmbolRegistrationRequest.getEvent().getStandard().getCustomerID());
			cbolmbolRegistrationFlat.setCustomerType(cbolmbolRegistrationRequest.getEvent().getStandard().getCustomerType());
			cbolmbolRegistrationFlat.setCardNumber(cbolmbolRegistrationRequest.getEvent().getStandard().getCardNumber());
		    cbolmbolRegistrationFlat.setAccountNumber(cbolmbolRegistrationRequest.getEvent().getStandard().getAccountNumber());
			cbolmbolRegistrationFlat.setIsCustomerPrimary(cbolmbolRegistrationRequest.getEvent().getStandard().getIsCustomerPrimary());
			cbolmbolRegistrationFlat.setTransactionStatus(cbolmbolRegistrationRequest.getEvent().getStandard().getTransactionStatus());
			cbolmbolRegistrationFlat.setTransactionType(cbolmbolRegistrationRequest.getEvent().getStandard().getTransactionType());
			cbolmbolRegistrationFlat.setRespStatusCode(cbolmbolRegistrationRequest.getEvent().getStandard().getRespStatusCode());
			cbolmbolRegistrationFlat.setRespStatusMsg(cbolmbolRegistrationRequest.getEvent().getStandard().getRespStatusMsg());
		    cbolmbolRegistrationFlat.setServerDateTime(cbolmbolRegistrationRequest.getEvent().getStandard().getServerDateTime());
		    cbolmbolRegistrationFlat.setTouchPoint(cbolmbolRegistrationRequest.getEvent().getStandard().getTouchPoint());
		    cbolmbolRegistrationFlat.setAssistedChannelUserID(cbolmbolRegistrationRequest.getEvent().getStandard().getAssistedChannelUserID());
		}
		
	    if(cbolmbolRegistrationRequest.getEvent().getMetadata()!=null){
	    	cbolmbolRegistrationFlat.setOriginatorFunctionID(cbolmbolRegistrationRequest.getEvent().getMetadata().getOriginatorFunctionID());
		    cbolmbolRegistrationFlat.setOriginatorFunctionType(cbolmbolRegistrationRequest.getEvent().getMetadata().getOriginatorFunctionType());
		    cbolmbolRegistrationFlat.setOriginatorSubFunctionID(cbolmbolRegistrationRequest.getEvent().getMetadata().getOriginatorSubFunctionID());
			cbolmbolRegistrationFlat.setOriginatorFunctionSubType(cbolmbolRegistrationRequest.getEvent().getMetadata().getOriginatorFunctionSubType());
	    }
	    
		if(cbolmbolRegistrationRequest.getEvent().getCustomerAccess()!=null){
			cbolmbolRegistrationFlat.setChannelSessionId(cbolmbolRegistrationRequest.getEvent().getCustomerAccess().getChannelSessionId());
			cbolmbolRegistrationFlat.setDeviceType(cbolmbolRegistrationRequest.getEvent().getCustomerAccess().getDeviceType());
			cbolmbolRegistrationFlat.setDeviceID(cbolmbolRegistrationRequest.getEvent().getCustomerAccess().getDeviceID());
			cbolmbolRegistrationFlat.setDeviceOS(cbolmbolRegistrationRequest.getEvent().getCustomerAccess().getDeviceOS());
			cbolmbolRegistrationFlat.setGeoLocLatitude(cbolmbolRegistrationRequest.getEvent().getCustomerAccess().getGeoLocLatitude());
		    cbolmbolRegistrationFlat.setGeoLocLongitude(cbolmbolRegistrationRequest.getEvent().getCustomerAccess().getGeoLocLongitude());
		    cbolmbolRegistrationFlat.setBrowserName(cbolmbolRegistrationRequest.getEvent().getCustomerAccess().getBrowserName());
		    cbolmbolRegistrationFlat.setClientIPAddress(cbolmbolRegistrationRequest.getEvent().getCustomerAccess().getClientIPAddress());
		}
	    
//	    if(cbolmbolRegistrationRequest.getEvent().getExtended()!=null){
//	    	cbolmbolRegistrationFlat.setProductType(cbolmbolRegistrationRequest.getEvent().getExtended().getProductType());
//	    }
		
		return cbolmbolRegistrationFlat;
	}
	
	public ChargeDisputeFlat getChargeDisputeFlat(ChargeDisputeRequest chargeDisputeRequest) {
		ChargeDisputeFlat chargeDisputeFlat=new ChargeDisputeFlat();
		if(chargeDisputeRequest.getEvent().getStandard()!=null){
			chargeDisputeFlat.setCorrelationID(chargeDisputeRequest.getEvent().getStandard().getCorrelationID());
			chargeDisputeFlat.setEventID(chargeDisputeRequest.getEvent().getStandard().getEventID());
			chargeDisputeFlat.setEventUUID(chargeDisputeRequest.getEvent().getStandard().getEventUUID());
			chargeDisputeFlat.setEventProducer(chargeDisputeRequest.getEvent().getStandard().getEventProducer());
			chargeDisputeFlat.setEventTransmitter(chargeDisputeRequest.getEvent().getStandard().getEventTransmitter());
			chargeDisputeFlat.setCountryCode(chargeDisputeRequest.getEvent().getStandard().getCountryCode());
			chargeDisputeFlat.setBusinessID(chargeDisputeRequest.getEvent().getStandard().getBusinessID());
			chargeDisputeFlat.setUUID_UniqueID(chargeDisputeRequest.getEvent().getStandard().getUUID_UniqueID());
			chargeDisputeFlat.setESBUUID(chargeDisputeRequest.getEvent().getStandard().getESBUUID());
			chargeDisputeFlat.setBizFunctionID(chargeDisputeRequest.getEvent().getStandard().getBizFunctionID());
			chargeDisputeFlat.setCustomerID(chargeDisputeRequest.getEvent().getStandard().getCustomerID());
			chargeDisputeFlat.setCustomerType(chargeDisputeRequest.getEvent().getStandard().getCustomerType());
			chargeDisputeFlat.setCardNumber(chargeDisputeRequest.getEvent().getStandard().getCardNumber());
		    chargeDisputeFlat.setAccountNumber(chargeDisputeRequest.getEvent().getStandard().getAccountNumber());
			chargeDisputeFlat.setIsCustomerPrimary(chargeDisputeRequest.getEvent().getStandard().getIsCustomerPrimary());
			chargeDisputeFlat.setTransactionStatus(chargeDisputeRequest.getEvent().getStandard().getTransactionStatus());
			chargeDisputeFlat.setTransactionType(chargeDisputeRequest.getEvent().getStandard().getTransactionType());
			chargeDisputeFlat.setRespStatusCode(chargeDisputeRequest.getEvent().getStandard().getRespStatusCode());
			chargeDisputeFlat.setRespStatusMsg(chargeDisputeRequest.getEvent().getStandard().getRespStatusMsg());
		    chargeDisputeFlat.setServerDateTime(chargeDisputeRequest.getEvent().getStandard().getServerDateTime());
		    chargeDisputeFlat.setTouchPoint(chargeDisputeRequest.getEvent().getStandard().getTouchPoint());
		    chargeDisputeFlat.setAssistedChannelUserID(chargeDisputeRequest.getEvent().getStandard().getAssistedChannelUserID());
		}
		
	    if(chargeDisputeRequest.getEvent().getMetadata()!=null){
	    	chargeDisputeFlat.setOriginatorFunctionID(chargeDisputeRequest.getEvent().getMetadata().getOriginatorFunctionID());
		    chargeDisputeFlat.setOriginatorFunctionType(chargeDisputeRequest.getEvent().getMetadata().getOriginatorFunctionType());
		    chargeDisputeFlat.setOriginatorSubFunctionID(chargeDisputeRequest.getEvent().getMetadata().getOriginatorSubFunctionID());
			chargeDisputeFlat.setOriginatorFunctionSubType(chargeDisputeRequest.getEvent().getMetadata().getOriginatorFunctionSubType());
	    }
	    
		if(chargeDisputeRequest.getEvent().getCustomerAccess()!=null){
			chargeDisputeFlat.setChannelSessionId(chargeDisputeRequest.getEvent().getCustomerAccess().getChannelSessionId());
			chargeDisputeFlat.setDeviceType(chargeDisputeRequest.getEvent().getCustomerAccess().getDeviceType());
			chargeDisputeFlat.setDeviceID(chargeDisputeRequest.getEvent().getCustomerAccess().getDeviceID());
			chargeDisputeFlat.setDeviceOS(chargeDisputeRequest.getEvent().getCustomerAccess().getDeviceOS());
			chargeDisputeFlat.setGeoLocLatitude(chargeDisputeRequest.getEvent().getCustomerAccess().getGeoLocLatitude());
		    chargeDisputeFlat.setGeoLocLongitude(chargeDisputeRequest.getEvent().getCustomerAccess().getGeoLocLongitude());
		    chargeDisputeFlat.setBrowserName(chargeDisputeRequest.getEvent().getCustomerAccess().getBrowserName());
		    chargeDisputeFlat.setClientIPAddress(chargeDisputeRequest.getEvent().getCustomerAccess().getClientIPAddress());
		}
	    
//	    if(chargeDisputeRequest.getEvent().getExtended()!=null){
//	    	chargeDisputeFlat.setProductType(chargeDisputeRequest.getEvent().getExtended().getProductType());
//	    }
		
		return chargeDisputeFlat;
	}
	
	public ChequeBounceFlat getChequeBounceFlat(ChequeBounceRequest chequeBounceRequest) {
		ChequeBounceFlat chequeBounceFlat=new ChequeBounceFlat();
		if(chequeBounceRequest.getEvent().getStandard()!=null){
			chequeBounceFlat.setCorrelationID(chequeBounceRequest.getEvent().getStandard().getCorrelationID());
			chequeBounceFlat.setEventID(chequeBounceRequest.getEvent().getStandard().getEventID());
			chequeBounceFlat.setEventUUID(chequeBounceRequest.getEvent().getStandard().getEventUUID());
			chequeBounceFlat.setEventProducer(chequeBounceRequest.getEvent().getStandard().getEventProducer());
			chequeBounceFlat.setEventTransmitter(chequeBounceRequest.getEvent().getStandard().getEventTransmitter());
			chequeBounceFlat.setCountryCode(chequeBounceRequest.getEvent().getStandard().getCountryCode());
			chequeBounceFlat.setBusinessID(chequeBounceRequest.getEvent().getStandard().getBusinessID());
			chequeBounceFlat.setUUID_UniqueID(chequeBounceRequest.getEvent().getStandard().getUUID_UniqueID());
			chequeBounceFlat.setESBUUID(chequeBounceRequest.getEvent().getStandard().getESBUUID());
			chequeBounceFlat.setBizFunctionID(chequeBounceRequest.getEvent().getStandard().getBizFunctionID());
			chequeBounceFlat.setCustomerID(chequeBounceRequest.getEvent().getStandard().getCustomerID());
			chequeBounceFlat.setCustomerType(chequeBounceRequest.getEvent().getStandard().getCustomerType());
			chequeBounceFlat.setCardNumber(chequeBounceRequest.getEvent().getStandard().getCardNumber());
		    chequeBounceFlat.setAccountNumber(chequeBounceRequest.getEvent().getStandard().getAccountNumber());
			chequeBounceFlat.setIsCustomerPrimary(chequeBounceRequest.getEvent().getStandard().getIsCustomerPrimary());
			chequeBounceFlat.setTransactionStatus(chequeBounceRequest.getEvent().getStandard().getTransactionStatus());
			chequeBounceFlat.setTransactionType(chequeBounceRequest.getEvent().getStandard().getTransactionType());
			chequeBounceFlat.setRespStatusCode(chequeBounceRequest.getEvent().getStandard().getRespStatusCode());
			chequeBounceFlat.setRespStatusMsg(chequeBounceRequest.getEvent().getStandard().getRespStatusMsg());
		    chequeBounceFlat.setServerDateTime(chequeBounceRequest.getEvent().getStandard().getServerDateTime());
		    chequeBounceFlat.setTouchPoint(chequeBounceRequest.getEvent().getStandard().getTouchPoint());
		    chequeBounceFlat.setAssistedChannelUserID(chequeBounceRequest.getEvent().getStandard().getAssistedChannelUserID());
		}
		
	    if(chequeBounceRequest.getEvent().getMetadata()!=null){
	    	chequeBounceFlat.setOriginatorFunctionID(chequeBounceRequest.getEvent().getMetadata().getOriginatorFunctionID());
		    chequeBounceFlat.setOriginatorFunctionType(chequeBounceRequest.getEvent().getMetadata().getOriginatorFunctionType());
		    chequeBounceFlat.setOriginatorSubFunctionID(chequeBounceRequest.getEvent().getMetadata().getOriginatorSubFunctionID());
			chequeBounceFlat.setOriginatorFunctionSubType(chequeBounceRequest.getEvent().getMetadata().getOriginatorFunctionSubType());
	    }
	    
		if(chequeBounceRequest.getEvent().getCustomerAccess()!=null){
			chequeBounceFlat.setChannelSessionId(chequeBounceRequest.getEvent().getCustomerAccess().getChannelSessionId());
			chequeBounceFlat.setDeviceType(chequeBounceRequest.getEvent().getCustomerAccess().getDeviceType());
			chequeBounceFlat.setDeviceID(chequeBounceRequest.getEvent().getCustomerAccess().getDeviceID());
			chequeBounceFlat.setDeviceOS(chequeBounceRequest.getEvent().getCustomerAccess().getDeviceOS());
			chequeBounceFlat.setGeoLocLatitude(chequeBounceRequest.getEvent().getCustomerAccess().getGeoLocLatitude());
		    chequeBounceFlat.setGeoLocLongitude(chequeBounceRequest.getEvent().getCustomerAccess().getGeoLocLongitude());
		    chequeBounceFlat.setBrowserName(chequeBounceRequest.getEvent().getCustomerAccess().getBrowserName());
		    chequeBounceFlat.setClientIPAddress(chequeBounceRequest.getEvent().getCustomerAccess().getClientIPAddress());
		}
	    
//	    if(chequeBounceRequest.getEvent().getExtended()!=null){
//	    	chequeBounceFlat.setProductType(chequeBounceRequest.getEvent().getExtended().getProductType());
//	    }
		
		return chequeBounceFlat;
	}
	
	public ChequeStopPaymentFlat getChequeStopPaymentFlat(ChequeStopPaymentRequest chequeStopPaymentRequest) {
		ChequeStopPaymentFlat chequeStopPaymentFlat=new ChequeStopPaymentFlat();
		if(chequeStopPaymentRequest.getEvent().getStandard()!=null){
			chequeStopPaymentFlat.setCorrelationID(chequeStopPaymentRequest.getEvent().getStandard().getCorrelationID());
			chequeStopPaymentFlat.setEventID(chequeStopPaymentRequest.getEvent().getStandard().getEventID());
			chequeStopPaymentFlat.setEventUUID(chequeStopPaymentRequest.getEvent().getStandard().getEventUUID());
			chequeStopPaymentFlat.setEventProducer(chequeStopPaymentRequest.getEvent().getStandard().getEventProducer());
			chequeStopPaymentFlat.setEventTransmitter(chequeStopPaymentRequest.getEvent().getStandard().getEventTransmitter());
			chequeStopPaymentFlat.setCountryCode(chequeStopPaymentRequest.getEvent().getStandard().getCountryCode());
			chequeStopPaymentFlat.setBusinessID(chequeStopPaymentRequest.getEvent().getStandard().getBusinessID());
			chequeStopPaymentFlat.setUUID_UniqueID(chequeStopPaymentRequest.getEvent().getStandard().getUUID_UniqueID());
			chequeStopPaymentFlat.setESBUUID(chequeStopPaymentRequest.getEvent().getStandard().getESBUUID());
			chequeStopPaymentFlat.setBizFunctionID(chequeStopPaymentRequest.getEvent().getStandard().getBizFunctionID());
			chequeStopPaymentFlat.setCustomerID(chequeStopPaymentRequest.getEvent().getStandard().getCustomerID());
			chequeStopPaymentFlat.setCustomerType(chequeStopPaymentRequest.getEvent().getStandard().getCustomerType());
			chequeStopPaymentFlat.setCardNumber(chequeStopPaymentRequest.getEvent().getStandard().getCardNumber());
		    chequeStopPaymentFlat.setAccountNumber(chequeStopPaymentRequest.getEvent().getStandard().getAccountNumber());
			chequeStopPaymentFlat.setIsCustomerPrimary(chequeStopPaymentRequest.getEvent().getStandard().getIsCustomerPrimary());
			chequeStopPaymentFlat.setTransactionStatus(chequeStopPaymentRequest.getEvent().getStandard().getTransactionStatus());
			chequeStopPaymentFlat.setTransactionType(chequeStopPaymentRequest.getEvent().getStandard().getTransactionType());
			chequeStopPaymentFlat.setRespStatusCode(chequeStopPaymentRequest.getEvent().getStandard().getRespStatusCode());
			chequeStopPaymentFlat.setRespStatusMsg(chequeStopPaymentRequest.getEvent().getStandard().getRespStatusMsg());
		    chequeStopPaymentFlat.setServerDateTime(chequeStopPaymentRequest.getEvent().getStandard().getServerDateTime());
		    chequeStopPaymentFlat.setTouchPoint(chequeStopPaymentRequest.getEvent().getStandard().getTouchPoint());
		    chequeStopPaymentFlat.setAssistedChannelUserID(chequeStopPaymentRequest.getEvent().getStandard().getAssistedChannelUserID());
		}
		
	    if(chequeStopPaymentRequest.getEvent().getMetadata()!=null){
	    	chequeStopPaymentFlat.setOriginatorFunctionID(chequeStopPaymentRequest.getEvent().getMetadata().getOriginatorFunctionID());
		    chequeStopPaymentFlat.setOriginatorFunctionType(chequeStopPaymentRequest.getEvent().getMetadata().getOriginatorFunctionType());
		    chequeStopPaymentFlat.setOriginatorSubFunctionID(chequeStopPaymentRequest.getEvent().getMetadata().getOriginatorSubFunctionID());
			chequeStopPaymentFlat.setOriginatorFunctionSubType(chequeStopPaymentRequest.getEvent().getMetadata().getOriginatorFunctionSubType());
	    }
	    
		if(chequeStopPaymentRequest.getEvent().getCustomerAccess()!=null){
			chequeStopPaymentFlat.setChannelSessionId(chequeStopPaymentRequest.getEvent().getCustomerAccess().getChannelSessionId());
			chequeStopPaymentFlat.setDeviceType(chequeStopPaymentRequest.getEvent().getCustomerAccess().getDeviceType());
			chequeStopPaymentFlat.setDeviceID(chequeStopPaymentRequest.getEvent().getCustomerAccess().getDeviceID());
			chequeStopPaymentFlat.setDeviceOS(chequeStopPaymentRequest.getEvent().getCustomerAccess().getDeviceOS());
			chequeStopPaymentFlat.setGeoLocLatitude(chequeStopPaymentRequest.getEvent().getCustomerAccess().getGeoLocLatitude());
		    chequeStopPaymentFlat.setGeoLocLongitude(chequeStopPaymentRequest.getEvent().getCustomerAccess().getGeoLocLongitude());
		    chequeStopPaymentFlat.setBrowserName(chequeStopPaymentRequest.getEvent().getCustomerAccess().getBrowserName());
		    chequeStopPaymentFlat.setClientIPAddress(chequeStopPaymentRequest.getEvent().getCustomerAccess().getClientIPAddress());
		}
	    
//	    if(chequeStopPaymentRequest.getEvent().getExtended()!=null){
//	    	chequeStopPaymentFlat.setProductType(chequeStopPaymentRequest.getEvent().getExtended().getProductType());
//	    }
		
		return chequeStopPaymentFlat;
	}
	
	public CpoCallEndFlat getCpoCallEndFlat(CpoCallEndRequest cpoCallEndRequest) {
		CpoCallEndFlat cpoCallEndFlat=new CpoCallEndFlat();
		if(cpoCallEndRequest.getEvent().getStandard()!=null){
			cpoCallEndFlat.setCorrelationID(cpoCallEndRequest.getEvent().getStandard().getCorrelationID());
			cpoCallEndFlat.setEventID(cpoCallEndRequest.getEvent().getStandard().getEventID());
			cpoCallEndFlat.setEventUUID(cpoCallEndRequest.getEvent().getStandard().getEventUUID());
			cpoCallEndFlat.setEventProducer(cpoCallEndRequest.getEvent().getStandard().getEventProducer());
			cpoCallEndFlat.setEventTransmitter(cpoCallEndRequest.getEvent().getStandard().getEventTransmitter());
			cpoCallEndFlat.setCountryCode(cpoCallEndRequest.getEvent().getStandard().getCountryCode());
			cpoCallEndFlat.setBusinessID(cpoCallEndRequest.getEvent().getStandard().getBusinessID());
			cpoCallEndFlat.setUUID_UniqueID(cpoCallEndRequest.getEvent().getStandard().getUUID_UniqueID());
			cpoCallEndFlat.setESBUUID(cpoCallEndRequest.getEvent().getStandard().getESBUUID());
			cpoCallEndFlat.setBizFunctionID(cpoCallEndRequest.getEvent().getStandard().getBizFunctionID());
			cpoCallEndFlat.setCustomerID(cpoCallEndRequest.getEvent().getStandard().getCustomerID());
			cpoCallEndFlat.setCustomerType(cpoCallEndRequest.getEvent().getStandard().getCustomerType());
			cpoCallEndFlat.setCardNumber(cpoCallEndRequest.getEvent().getStandard().getCardNumber());
		    cpoCallEndFlat.setAccountNumber(cpoCallEndRequest.getEvent().getStandard().getAccountNumber());
			cpoCallEndFlat.setIsCustomerPrimary(cpoCallEndRequest.getEvent().getStandard().getIsCustomerPrimary());
			cpoCallEndFlat.setTransactionStatus(cpoCallEndRequest.getEvent().getStandard().getTransactionStatus());
			cpoCallEndFlat.setTransactionType(cpoCallEndRequest.getEvent().getStandard().getTransactionType());
			cpoCallEndFlat.setRespStatusCode(cpoCallEndRequest.getEvent().getStandard().getRespStatusCode());
			cpoCallEndFlat.setRespStatusMsg(cpoCallEndRequest.getEvent().getStandard().getRespStatusMsg());
		    cpoCallEndFlat.setServerDateTime(cpoCallEndRequest.getEvent().getStandard().getServerDateTime());
		    cpoCallEndFlat.setTouchPoint(cpoCallEndRequest.getEvent().getStandard().getTouchPoint());
		    cpoCallEndFlat.setAssistedChannelUserID(cpoCallEndRequest.getEvent().getStandard().getAssistedChannelUserID());
		}
		
	    if(cpoCallEndRequest.getEvent().getMetadata()!=null){
	    	cpoCallEndFlat.setOriginatorFunctionID(cpoCallEndRequest.getEvent().getMetadata().getOriginatorFunctionID());
		    cpoCallEndFlat.setOriginatorFunctionType(cpoCallEndRequest.getEvent().getMetadata().getOriginatorFunctionType());
		    cpoCallEndFlat.setOriginatorSubFunctionID(cpoCallEndRequest.getEvent().getMetadata().getOriginatorSubFunctionID());
			cpoCallEndFlat.setOriginatorFunctionSubType(cpoCallEndRequest.getEvent().getMetadata().getOriginatorFunctionSubType());
	    }
	    
		if(cpoCallEndRequest.getEvent().getCustomerAccess()!=null){
			cpoCallEndFlat.setChannelSessionId(cpoCallEndRequest.getEvent().getCustomerAccess().getChannelSessionId());
			cpoCallEndFlat.setDeviceType(cpoCallEndRequest.getEvent().getCustomerAccess().getDeviceType());
			cpoCallEndFlat.setDeviceID(cpoCallEndRequest.getEvent().getCustomerAccess().getDeviceID());
			cpoCallEndFlat.setDeviceOS(cpoCallEndRequest.getEvent().getCustomerAccess().getDeviceOS());
			cpoCallEndFlat.setGeoLocLatitude(cpoCallEndRequest.getEvent().getCustomerAccess().getGeoLocLatitude());
		    cpoCallEndFlat.setGeoLocLongitude(cpoCallEndRequest.getEvent().getCustomerAccess().getGeoLocLongitude());
		    cpoCallEndFlat.setBrowserName(cpoCallEndRequest.getEvent().getCustomerAccess().getBrowserName());
		    cpoCallEndFlat.setClientIPAddress(cpoCallEndRequest.getEvent().getCustomerAccess().getClientIPAddress());
		}
	    
	    if(cpoCallEndRequest.getEvent().getExtended()!=null){
	    	cpoCallEndFlat.setCPOAgentID(cpoCallEndRequest.getEvent().getExtended().getCPOAgentID());
	    }
		
		return cpoCallEndFlat;
	}
	
	public CpoCallStartFlat getCpoCallStartFlat(CpoCallStartRequest cpoCallStartRequest) {
		CpoCallStartFlat cpoCallStartFlat=new CpoCallStartFlat();
		if(cpoCallStartRequest.getEvent().getStandard()!=null){
			cpoCallStartFlat.setCorrelationID(cpoCallStartRequest.getEvent().getStandard().getCorrelationID());
			cpoCallStartFlat.setEventID(cpoCallStartRequest.getEvent().getStandard().getEventID());
			cpoCallStartFlat.setEventUUID(cpoCallStartRequest.getEvent().getStandard().getEventUUID());
			cpoCallStartFlat.setEventProducer(cpoCallStartRequest.getEvent().getStandard().getEventProducer());
			cpoCallStartFlat.setEventTransmitter(cpoCallStartRequest.getEvent().getStandard().getEventTransmitter());
			cpoCallStartFlat.setCountryCode(cpoCallStartRequest.getEvent().getStandard().getCountryCode());
			cpoCallStartFlat.setBusinessID(cpoCallStartRequest.getEvent().getStandard().getBusinessID());
			cpoCallStartFlat.setUUID_UniqueID(cpoCallStartRequest.getEvent().getStandard().getUUID_UniqueID());
			cpoCallStartFlat.setESBUUID(cpoCallStartRequest.getEvent().getStandard().getESBUUID());
			cpoCallStartFlat.setBizFunctionID(cpoCallStartRequest.getEvent().getStandard().getBizFunctionID());
			cpoCallStartFlat.setCustomerID(cpoCallStartRequest.getEvent().getStandard().getCustomerID());
			cpoCallStartFlat.setCustomerType(cpoCallStartRequest.getEvent().getStandard().getCustomerType());
			cpoCallStartFlat.setCardNumber(cpoCallStartRequest.getEvent().getStandard().getCardNumber());
		    cpoCallStartFlat.setAccountNumber(cpoCallStartRequest.getEvent().getStandard().getAccountNumber());
			cpoCallStartFlat.setIsCustomerPrimary(cpoCallStartRequest.getEvent().getStandard().getIsCustomerPrimary());
			cpoCallStartFlat.setTransactionStatus(cpoCallStartRequest.getEvent().getStandard().getTransactionStatus());
			cpoCallStartFlat.setTransactionType(cpoCallStartRequest.getEvent().getStandard().getTransactionType());
			cpoCallStartFlat.setRespStatusCode(cpoCallStartRequest.getEvent().getStandard().getRespStatusCode());
			cpoCallStartFlat.setRespStatusMsg(cpoCallStartRequest.getEvent().getStandard().getRespStatusMsg());
		    cpoCallStartFlat.setServerDateTime(cpoCallStartRequest.getEvent().getStandard().getServerDateTime());
		    cpoCallStartFlat.setTouchPoint(cpoCallStartRequest.getEvent().getStandard().getTouchPoint());
		    cpoCallStartFlat.setAssistedChannelUserID(cpoCallStartRequest.getEvent().getStandard().getAssistedChannelUserID());
		}
		
	    if(cpoCallStartRequest.getEvent().getMetadata()!=null){
	    	cpoCallStartFlat.setOriginatorFunctionID(cpoCallStartRequest.getEvent().getMetadata().getOriginatorFunctionID());
		    cpoCallStartFlat.setOriginatorFunctionType(cpoCallStartRequest.getEvent().getMetadata().getOriginatorFunctionType());
		    cpoCallStartFlat.setOriginatorSubFunctionID(cpoCallStartRequest.getEvent().getMetadata().getOriginatorSubFunctionID());
			cpoCallStartFlat.setOriginatorFunctionSubType(cpoCallStartRequest.getEvent().getMetadata().getOriginatorFunctionSubType());
	    }
	    
		if(cpoCallStartRequest.getEvent().getCustomerAccess()!=null){
			cpoCallStartFlat.setChannelSessionId(cpoCallStartRequest.getEvent().getCustomerAccess().getChannelSessionId());
			cpoCallStartFlat.setDeviceType(cpoCallStartRequest.getEvent().getCustomerAccess().getDeviceType());
			cpoCallStartFlat.setDeviceID(cpoCallStartRequest.getEvent().getCustomerAccess().getDeviceID());
			cpoCallStartFlat.setDeviceOS(cpoCallStartRequest.getEvent().getCustomerAccess().getDeviceOS());
			cpoCallStartFlat.setGeoLocLatitude(cpoCallStartRequest.getEvent().getCustomerAccess().getGeoLocLatitude());
		    cpoCallStartFlat.setGeoLocLongitude(cpoCallStartRequest.getEvent().getCustomerAccess().getGeoLocLongitude());
		    cpoCallStartFlat.setBrowserName(cpoCallStartRequest.getEvent().getCustomerAccess().getBrowserName());
		    cpoCallStartFlat.setClientIPAddress(cpoCallStartRequest.getEvent().getCustomerAccess().getClientIPAddress());
		}
	    
	    if(cpoCallStartRequest.getEvent().getExtended()!=null){
	    	cpoCallStartFlat.setCPOAgentID(cpoCallStartRequest.getEvent().getExtended().getCPOAgentID());
	    }
		
		return cpoCallStartFlat;
	}
	
	public CreditCardClosureFlat getCreditCardClosureFlat(CreditCardClosureRequest creditCardClosureRequest) {
		CreditCardClosureFlat creditCardClosureFlat=new CreditCardClosureFlat();
		if(creditCardClosureRequest.getEvent().getStandard()!=null){
			creditCardClosureFlat.setCorrelationID(creditCardClosureRequest.getEvent().getStandard().getCorrelationID());
			creditCardClosureFlat.setEventID(creditCardClosureRequest.getEvent().getStandard().getEventID());
			creditCardClosureFlat.setEventUUID(creditCardClosureRequest.getEvent().getStandard().getEventUUID());
			creditCardClosureFlat.setEventProducer(creditCardClosureRequest.getEvent().getStandard().getEventProducer());
			creditCardClosureFlat.setEventTransmitter(creditCardClosureRequest.getEvent().getStandard().getEventTransmitter());
			creditCardClosureFlat.setCountryCode(creditCardClosureRequest.getEvent().getStandard().getCountryCode());
			creditCardClosureFlat.setBusinessID(creditCardClosureRequest.getEvent().getStandard().getBusinessID());
			creditCardClosureFlat.setUUID_UniqueID(creditCardClosureRequest.getEvent().getStandard().getUUID_UniqueID());
			creditCardClosureFlat.setESBUUID(creditCardClosureRequest.getEvent().getStandard().getESBUUID());
			creditCardClosureFlat.setBizFunctionID(creditCardClosureRequest.getEvent().getStandard().getBizFunctionID());
			creditCardClosureFlat.setCustomerID(creditCardClosureRequest.getEvent().getStandard().getCustomerID());
			creditCardClosureFlat.setCustomerType(creditCardClosureRequest.getEvent().getStandard().getCustomerType());
			creditCardClosureFlat.setCardNumber(creditCardClosureRequest.getEvent().getStandard().getCardNumber());
		    creditCardClosureFlat.setAccountNumber(creditCardClosureRequest.getEvent().getStandard().getAccountNumber());
			creditCardClosureFlat.setIsCustomerPrimary(creditCardClosureRequest.getEvent().getStandard().getIsCustomerPrimary());
			creditCardClosureFlat.setTransactionStatus(creditCardClosureRequest.getEvent().getStandard().getTransactionStatus());
			creditCardClosureFlat.setTransactionType(creditCardClosureRequest.getEvent().getStandard().getTransactionType());
			creditCardClosureFlat.setRespStatusCode(creditCardClosureRequest.getEvent().getStandard().getRespStatusCode());
			creditCardClosureFlat.setRespStatusMsg(creditCardClosureRequest.getEvent().getStandard().getRespStatusMsg());
		    creditCardClosureFlat.setServerDateTime(creditCardClosureRequest.getEvent().getStandard().getServerDateTime());
		    creditCardClosureFlat.setTouchPoint(creditCardClosureRequest.getEvent().getStandard().getTouchPoint());
		    creditCardClosureFlat.setAssistedChannelUserID(creditCardClosureRequest.getEvent().getStandard().getAssistedChannelUserID());
		}
		
	    if(creditCardClosureRequest.getEvent().getMetadata()!=null){
	    	creditCardClosureFlat.setOriginatorFunctionID(creditCardClosureRequest.getEvent().getMetadata().getOriginatorFunctionID());
		    creditCardClosureFlat.setOriginatorFunctionType(creditCardClosureRequest.getEvent().getMetadata().getOriginatorFunctionType());
		    creditCardClosureFlat.setOriginatorSubFunctionID(creditCardClosureRequest.getEvent().getMetadata().getOriginatorSubFunctionID());
			creditCardClosureFlat.setOriginatorFunctionSubType(creditCardClosureRequest.getEvent().getMetadata().getOriginatorFunctionSubType());
	    }
	    
		if(creditCardClosureRequest.getEvent().getCustomerAccess()!=null){
			creditCardClosureFlat.setChannelSessionId(creditCardClosureRequest.getEvent().getCustomerAccess().getChannelSessionId());
			creditCardClosureFlat.setDeviceType(creditCardClosureRequest.getEvent().getCustomerAccess().getDeviceType());
			creditCardClosureFlat.setDeviceID(creditCardClosureRequest.getEvent().getCustomerAccess().getDeviceID());
			creditCardClosureFlat.setDeviceOS(creditCardClosureRequest.getEvent().getCustomerAccess().getDeviceOS());
			creditCardClosureFlat.setGeoLocLatitude(creditCardClosureRequest.getEvent().getCustomerAccess().getGeoLocLatitude());
		    creditCardClosureFlat.setGeoLocLongitude(creditCardClosureRequest.getEvent().getCustomerAccess().getGeoLocLongitude());
		    creditCardClosureFlat.setBrowserName(creditCardClosureRequest.getEvent().getCustomerAccess().getBrowserName());
		    creditCardClosureFlat.setClientIPAddress(creditCardClosureRequest.getEvent().getCustomerAccess().getClientIPAddress());
		}
	    
		return creditCardClosureFlat;
	}
	
	public CreditCardReversalFlat getCreditCardReversalFlat(CreditCardReversalRequest creditCardReversalRequest) {
		CreditCardReversalFlat creditCardReversalFlat=new CreditCardReversalFlat();
		if(creditCardReversalRequest.getEvent().getStandard()!=null){
			creditCardReversalFlat.setCorrelationID(creditCardReversalRequest.getEvent().getStandard().getCorrelationID());
			creditCardReversalFlat.setEventID(creditCardReversalRequest.getEvent().getStandard().getEventID());
			creditCardReversalFlat.setEventUUID(creditCardReversalRequest.getEvent().getStandard().getEventUUID());
			creditCardReversalFlat.setEventProducer(creditCardReversalRequest.getEvent().getStandard().getEventProducer());
			creditCardReversalFlat.setEventTransmitter(creditCardReversalRequest.getEvent().getStandard().getEventTransmitter());
			creditCardReversalFlat.setCountryCode(creditCardReversalRequest.getEvent().getStandard().getCountryCode());
			creditCardReversalFlat.setBusinessID(creditCardReversalRequest.getEvent().getStandard().getBusinessID());
			creditCardReversalFlat.setUUID_UniqueID(creditCardReversalRequest.getEvent().getStandard().getUUID_UniqueID());
			creditCardReversalFlat.setESBUUID(creditCardReversalRequest.getEvent().getStandard().getESBUUID());
			creditCardReversalFlat.setBizFunctionID(creditCardReversalRequest.getEvent().getStandard().getBizFunctionID());
			creditCardReversalFlat.setCustomerID(creditCardReversalRequest.getEvent().getStandard().getCustomerID());
			creditCardReversalFlat.setCustomerType(creditCardReversalRequest.getEvent().getStandard().getCustomerType());
			creditCardReversalFlat.setCardNumber(creditCardReversalRequest.getEvent().getStandard().getCardNumber());
		    creditCardReversalFlat.setAccountNumber(creditCardReversalRequest.getEvent().getStandard().getAccountNumber());
			creditCardReversalFlat.setIsCustomerPrimary(creditCardReversalRequest.getEvent().getStandard().getIsCustomerPrimary());
			creditCardReversalFlat.setTransactionStatus(creditCardReversalRequest.getEvent().getStandard().getTransactionStatus());
			creditCardReversalFlat.setTransactionType(creditCardReversalRequest.getEvent().getStandard().getTransactionType());
			creditCardReversalFlat.setRespStatusCode(creditCardReversalRequest.getEvent().getStandard().getRespStatusCode());
			creditCardReversalFlat.setRespStatusMsg(creditCardReversalRequest.getEvent().getStandard().getRespStatusMsg());
		    creditCardReversalFlat.setServerDateTime(creditCardReversalRequest.getEvent().getStandard().getServerDateTime());
		    creditCardReversalFlat.setTouchPoint(creditCardReversalRequest.getEvent().getStandard().getTouchPoint());
		    creditCardReversalFlat.setAssistedChannelUserID(creditCardReversalRequest.getEvent().getStandard().getAssistedChannelUserID());
		}
		
	    if(creditCardReversalRequest.getEvent().getMetadata()!=null){
	    	creditCardReversalFlat.setOriginatorFunctionID(creditCardReversalRequest.getEvent().getMetadata().getOriginatorFunctionID());
		    creditCardReversalFlat.setOriginatorFunctionType(creditCardReversalRequest.getEvent().getMetadata().getOriginatorFunctionType());
		    creditCardReversalFlat.setOriginatorSubFunctionID(creditCardReversalRequest.getEvent().getMetadata().getOriginatorSubFunctionID());
			creditCardReversalFlat.setOriginatorFunctionSubType(creditCardReversalRequest.getEvent().getMetadata().getOriginatorFunctionSubType());
	    }
	    
		if(creditCardReversalRequest.getEvent().getCustomerAccess()!=null){
			creditCardReversalFlat.setChannelSessionId(creditCardReversalRequest.getEvent().getCustomerAccess().getChannelSessionId());
			creditCardReversalFlat.setDeviceType(creditCardReversalRequest.getEvent().getCustomerAccess().getDeviceType());
			creditCardReversalFlat.setDeviceID(creditCardReversalRequest.getEvent().getCustomerAccess().getDeviceID());
			creditCardReversalFlat.setDeviceOS(creditCardReversalRequest.getEvent().getCustomerAccess().getDeviceOS());
			creditCardReversalFlat.setGeoLocLatitude(creditCardReversalRequest.getEvent().getCustomerAccess().getGeoLocLatitude());
		    creditCardReversalFlat.setGeoLocLongitude(creditCardReversalRequest.getEvent().getCustomerAccess().getGeoLocLongitude());
		    creditCardReversalFlat.setBrowserName(creditCardReversalRequest.getEvent().getCustomerAccess().getBrowserName());
		    creditCardReversalFlat.setClientIPAddress(creditCardReversalRequest.getEvent().getCustomerAccess().getClientIPAddress());
		}
	    
		return creditCardReversalFlat;
	}
	
	public CreditLimitIncreaseFlat getCreditLimitIncreaseFlat(CreditLimitIncreaseRequest creditLimitIncreaseRequest) {
		CreditLimitIncreaseFlat creditLimitIncreaseFlat=new CreditLimitIncreaseFlat();
		if(creditLimitIncreaseRequest.getEvent().getStandard()!=null){
			creditLimitIncreaseFlat.setCorrelationID(creditLimitIncreaseRequest.getEvent().getStandard().getCorrelationID());
			creditLimitIncreaseFlat.setEventID(creditLimitIncreaseRequest.getEvent().getStandard().getEventID());
			creditLimitIncreaseFlat.setEventUUID(creditLimitIncreaseRequest.getEvent().getStandard().getEventUUID());
			creditLimitIncreaseFlat.setEventProducer(creditLimitIncreaseRequest.getEvent().getStandard().getEventProducer());
			creditLimitIncreaseFlat.setEventTransmitter(creditLimitIncreaseRequest.getEvent().getStandard().getEventTransmitter());
			creditLimitIncreaseFlat.setCountryCode(creditLimitIncreaseRequest.getEvent().getStandard().getCountryCode());
			creditLimitIncreaseFlat.setBusinessID(creditLimitIncreaseRequest.getEvent().getStandard().getBusinessID());
			creditLimitIncreaseFlat.setUUID_UniqueID(creditLimitIncreaseRequest.getEvent().getStandard().getUUID_UniqueID());
			creditLimitIncreaseFlat.setESBUUID(creditLimitIncreaseRequest.getEvent().getStandard().getESBUUID());
			creditLimitIncreaseFlat.setBizFunctionID(creditLimitIncreaseRequest.getEvent().getStandard().getBizFunctionID());
			creditLimitIncreaseFlat.setCustomerID(creditLimitIncreaseRequest.getEvent().getStandard().getCustomerID());
			creditLimitIncreaseFlat.setCustomerType(creditLimitIncreaseRequest.getEvent().getStandard().getCustomerType());
			creditLimitIncreaseFlat.setCardNumber(creditLimitIncreaseRequest.getEvent().getStandard().getCardNumber());
		    creditLimitIncreaseFlat.setAccountNumber(creditLimitIncreaseRequest.getEvent().getStandard().getAccountNumber());
			creditLimitIncreaseFlat.setIsCustomerPrimary(creditLimitIncreaseRequest.getEvent().getStandard().getIsCustomerPrimary());
			creditLimitIncreaseFlat.setTransactionStatus(creditLimitIncreaseRequest.getEvent().getStandard().getTransactionStatus());
			creditLimitIncreaseFlat.setTransactionType(creditLimitIncreaseRequest.getEvent().getStandard().getTransactionType());
			creditLimitIncreaseFlat.setRespStatusCode(creditLimitIncreaseRequest.getEvent().getStandard().getRespStatusCode());
			creditLimitIncreaseFlat.setRespStatusMsg(creditLimitIncreaseRequest.getEvent().getStandard().getRespStatusMsg());
		    creditLimitIncreaseFlat.setServerDateTime(creditLimitIncreaseRequest.getEvent().getStandard().getServerDateTime());
		    creditLimitIncreaseFlat.setTouchPoint(creditLimitIncreaseRequest.getEvent().getStandard().getTouchPoint());
		    creditLimitIncreaseFlat.setAssistedChannelUserID(creditLimitIncreaseRequest.getEvent().getStandard().getAssistedChannelUserID());
		}
		
	    if(creditLimitIncreaseRequest.getEvent().getMetadata()!=null){
	    	creditLimitIncreaseFlat.setOriginatorFunctionID(creditLimitIncreaseRequest.getEvent().getMetadata().getOriginatorFunctionID());
		    creditLimitIncreaseFlat.setOriginatorFunctionType(creditLimitIncreaseRequest.getEvent().getMetadata().getOriginatorFunctionType());
		    creditLimitIncreaseFlat.setOriginatorSubFunctionID(creditLimitIncreaseRequest.getEvent().getMetadata().getOriginatorSubFunctionID());
			creditLimitIncreaseFlat.setOriginatorFunctionSubType(creditLimitIncreaseRequest.getEvent().getMetadata().getOriginatorFunctionSubType());
	    }
	    
		if(creditLimitIncreaseRequest.getEvent().getCustomerAccess()!=null){
			creditLimitIncreaseFlat.setChannelSessionId(creditLimitIncreaseRequest.getEvent().getCustomerAccess().getChannelSessionId());
			creditLimitIncreaseFlat.setDeviceType(creditLimitIncreaseRequest.getEvent().getCustomerAccess().getDeviceType());
			creditLimitIncreaseFlat.setDeviceID(creditLimitIncreaseRequest.getEvent().getCustomerAccess().getDeviceID());
			creditLimitIncreaseFlat.setDeviceOS(creditLimitIncreaseRequest.getEvent().getCustomerAccess().getDeviceOS());
			creditLimitIncreaseFlat.setGeoLocLatitude(creditLimitIncreaseRequest.getEvent().getCustomerAccess().getGeoLocLatitude());
		    creditLimitIncreaseFlat.setGeoLocLongitude(creditLimitIncreaseRequest.getEvent().getCustomerAccess().getGeoLocLongitude());
		    creditLimitIncreaseFlat.setBrowserName(creditLimitIncreaseRequest.getEvent().getCustomerAccess().getBrowserName());
		    creditLimitIncreaseFlat.setClientIPAddress(creditLimitIncreaseRequest.getEvent().getCustomerAccess().getClientIPAddress());
		}
	    
		return creditLimitIncreaseFlat;
	}
	
	public CustHWTokenFlat getCustHWTokenFlat(CustHWTokenRequest custHWTokenRequest) {
		CustHWTokenFlat custHWTokenFlat=new CustHWTokenFlat();
		if(custHWTokenRequest.getEvent().getStandard()!=null){
			custHWTokenFlat.setCorrelationID(custHWTokenRequest.getEvent().getStandard().getCorrelationID());
			custHWTokenFlat.setEventID(custHWTokenRequest.getEvent().getStandard().getEventID());
			custHWTokenFlat.setEventUUID(custHWTokenRequest.getEvent().getStandard().getEventUUID());
			custHWTokenFlat.setEventProducer(custHWTokenRequest.getEvent().getStandard().getEventProducer());
			custHWTokenFlat.setEventTransmitter(custHWTokenRequest.getEvent().getStandard().getEventTransmitter());
			custHWTokenFlat.setCountryCode(custHWTokenRequest.getEvent().getStandard().getCountryCode());
			custHWTokenFlat.setBusinessID(custHWTokenRequest.getEvent().getStandard().getBusinessID());
			custHWTokenFlat.setUUID_UniqueID(custHWTokenRequest.getEvent().getStandard().getUUID_UniqueID());
			custHWTokenFlat.setESBUUID(custHWTokenRequest.getEvent().getStandard().getESBUUID());
			custHWTokenFlat.setBizFunctionID(custHWTokenRequest.getEvent().getStandard().getBizFunctionID());
			custHWTokenFlat.setCustomerID(custHWTokenRequest.getEvent().getStandard().getCustomerID());
			custHWTokenFlat.setCustomerType(custHWTokenRequest.getEvent().getStandard().getCustomerType());
			custHWTokenFlat.setCardNumber(custHWTokenRequest.getEvent().getStandard().getCardNumber());
		    custHWTokenFlat.setAccountNumber(custHWTokenRequest.getEvent().getStandard().getAccountNumber());
			custHWTokenFlat.setIsCustomerPrimary(custHWTokenRequest.getEvent().getStandard().getIsCustomerPrimary());
			custHWTokenFlat.setTransactionStatus(custHWTokenRequest.getEvent().getStandard().getTransactionStatus());
			custHWTokenFlat.setTransactionType(custHWTokenRequest.getEvent().getStandard().getTransactionType());
			custHWTokenFlat.setRespStatusCode(custHWTokenRequest.getEvent().getStandard().getRespStatusCode());
			custHWTokenFlat.setRespStatusMsg(custHWTokenRequest.getEvent().getStandard().getRespStatusMsg());
		    custHWTokenFlat.setServerDateTime(custHWTokenRequest.getEvent().getStandard().getServerDateTime());
		    custHWTokenFlat.setTouchPoint(custHWTokenRequest.getEvent().getStandard().getTouchPoint());
		    custHWTokenFlat.setAssistedChannelUserID(custHWTokenRequest.getEvent().getStandard().getAssistedChannelUserID());
		}
		
	    if(custHWTokenRequest.getEvent().getMetadata()!=null){
	    	custHWTokenFlat.setOriginatorFunctionID(custHWTokenRequest.getEvent().getMetadata().getOriginatorFunctionID());
		    custHWTokenFlat.setOriginatorFunctionType(custHWTokenRequest.getEvent().getMetadata().getOriginatorFunctionType());
		    custHWTokenFlat.setOriginatorSubFunctionID(custHWTokenRequest.getEvent().getMetadata().getOriginatorSubFunctionID());
			custHWTokenFlat.setOriginatorFunctionSubType(custHWTokenRequest.getEvent().getMetadata().getOriginatorFunctionSubType());
	    }
	    
		if(custHWTokenRequest.getEvent().getCustomerAccess()!=null){
			custHWTokenFlat.setChannelSessionId(custHWTokenRequest.getEvent().getCustomerAccess().getChannelSessionId());
			custHWTokenFlat.setDeviceType(custHWTokenRequest.getEvent().getCustomerAccess().getDeviceType());
			custHWTokenFlat.setDeviceID(custHWTokenRequest.getEvent().getCustomerAccess().getDeviceID());
			custHWTokenFlat.setDeviceOS(custHWTokenRequest.getEvent().getCustomerAccess().getDeviceOS());
			custHWTokenFlat.setGeoLocLatitude(custHWTokenRequest.getEvent().getCustomerAccess().getGeoLocLatitude());
		    custHWTokenFlat.setGeoLocLongitude(custHWTokenRequest.getEvent().getCustomerAccess().getGeoLocLongitude());
		    custHWTokenFlat.setBrowserName(custHWTokenRequest.getEvent().getCustomerAccess().getBrowserName());
		    custHWTokenFlat.setClientIPAddress(custHWTokenRequest.getEvent().getCustomerAccess().getClientIPAddress());
		}
	    
		return custHWTokenFlat;
	}
	
	public CustLoginIDStatusChangeFlat getCustLoginIDStatusChangeFlat(CustLoginIDStatusChangeRequest custLoginIDStatusChangeRequest) {
		CustLoginIDStatusChangeFlat custLoginIDStatusChangeFlat=new CustLoginIDStatusChangeFlat();
		if(custLoginIDStatusChangeRequest.getEvent().getStandard()!=null){
			custLoginIDStatusChangeFlat.setCorrelationID(custLoginIDStatusChangeRequest.getEvent().getStandard().getCorrelationID());
			custLoginIDStatusChangeFlat.setEventID(custLoginIDStatusChangeRequest.getEvent().getStandard().getEventID());
			custLoginIDStatusChangeFlat.setEventUUID(custLoginIDStatusChangeRequest.getEvent().getStandard().getEventUUID());
			custLoginIDStatusChangeFlat.setEventProducer(custLoginIDStatusChangeRequest.getEvent().getStandard().getEventProducer());
			custLoginIDStatusChangeFlat.setEventTransmitter(custLoginIDStatusChangeRequest.getEvent().getStandard().getEventTransmitter());
			custLoginIDStatusChangeFlat.setCountryCode(custLoginIDStatusChangeRequest.getEvent().getStandard().getCountryCode());
			custLoginIDStatusChangeFlat.setBusinessID(custLoginIDStatusChangeRequest.getEvent().getStandard().getBusinessID());
			custLoginIDStatusChangeFlat.setUUID_UniqueID(custLoginIDStatusChangeRequest.getEvent().getStandard().getUUID_UniqueID());
			custLoginIDStatusChangeFlat.setESBUUID(custLoginIDStatusChangeRequest.getEvent().getStandard().getESBUUID());
			custLoginIDStatusChangeFlat.setBizFunctionID(custLoginIDStatusChangeRequest.getEvent().getStandard().getBizFunctionID());
			custLoginIDStatusChangeFlat.setCustomerID(custLoginIDStatusChangeRequest.getEvent().getStandard().getCustomerID());
			custLoginIDStatusChangeFlat.setCustomerType(custLoginIDStatusChangeRequest.getEvent().getStandard().getCustomerType());
			custLoginIDStatusChangeFlat.setCardNumber(custLoginIDStatusChangeRequest.getEvent().getStandard().getCardNumber());
		    custLoginIDStatusChangeFlat.setAccountNumber(custLoginIDStatusChangeRequest.getEvent().getStandard().getAccountNumber());
			custLoginIDStatusChangeFlat.setIsCustomerPrimary(custLoginIDStatusChangeRequest.getEvent().getStandard().getIsCustomerPrimary());
			custLoginIDStatusChangeFlat.setTransactionStatus(custLoginIDStatusChangeRequest.getEvent().getStandard().getTransactionStatus());
			custLoginIDStatusChangeFlat.setTransactionType(custLoginIDStatusChangeRequest.getEvent().getStandard().getTransactionType());
			custLoginIDStatusChangeFlat.setRespStatusCode(custLoginIDStatusChangeRequest.getEvent().getStandard().getRespStatusCode());
			custLoginIDStatusChangeFlat.setRespStatusMsg(custLoginIDStatusChangeRequest.getEvent().getStandard().getRespStatusMsg());
		    custLoginIDStatusChangeFlat.setServerDateTime(custLoginIDStatusChangeRequest.getEvent().getStandard().getServerDateTime());
		    custLoginIDStatusChangeFlat.setTouchPoint(custLoginIDStatusChangeRequest.getEvent().getStandard().getTouchPoint());
		    custLoginIDStatusChangeFlat.setAssistedChannelUserID(custLoginIDStatusChangeRequest.getEvent().getStandard().getAssistedChannelUserID());
		}
		
	    if(custLoginIDStatusChangeRequest.getEvent().getMetadata()!=null){
	    	custLoginIDStatusChangeFlat.setOriginatorFunctionID(custLoginIDStatusChangeRequest.getEvent().getMetadata().getOriginatorFunctionID());
		    custLoginIDStatusChangeFlat.setOriginatorFunctionType(custLoginIDStatusChangeRequest.getEvent().getMetadata().getOriginatorFunctionType());
		    custLoginIDStatusChangeFlat.setOriginatorSubFunctionID(custLoginIDStatusChangeRequest.getEvent().getMetadata().getOriginatorSubFunctionID());
			custLoginIDStatusChangeFlat.setOriginatorFunctionSubType(custLoginIDStatusChangeRequest.getEvent().getMetadata().getOriginatorFunctionSubType());
	    }
	    
		if(custLoginIDStatusChangeRequest.getEvent().getCustomerAccess()!=null){
			custLoginIDStatusChangeFlat.setChannelSessionId(custLoginIDStatusChangeRequest.getEvent().getCustomerAccess().getChannelSessionId());
			custLoginIDStatusChangeFlat.setDeviceType(custLoginIDStatusChangeRequest.getEvent().getCustomerAccess().getDeviceType());
			custLoginIDStatusChangeFlat.setDeviceID(custLoginIDStatusChangeRequest.getEvent().getCustomerAccess().getDeviceID());
			custLoginIDStatusChangeFlat.setDeviceOS(custLoginIDStatusChangeRequest.getEvent().getCustomerAccess().getDeviceOS());
			custLoginIDStatusChangeFlat.setGeoLocLatitude(custLoginIDStatusChangeRequest.getEvent().getCustomerAccess().getGeoLocLatitude());
		    custLoginIDStatusChangeFlat.setGeoLocLongitude(custLoginIDStatusChangeRequest.getEvent().getCustomerAccess().getGeoLocLongitude());
		    custLoginIDStatusChangeFlat.setBrowserName(custLoginIDStatusChangeRequest.getEvent().getCustomerAccess().getBrowserName());
		    custLoginIDStatusChangeFlat.setClientIPAddress(custLoginIDStatusChangeRequest.getEvent().getCustomerAccess().getClientIPAddress());
		}
	    
		return custLoginIDStatusChangeFlat;
	}
	
	public CustomerLoginFlat getCustomerLoginFlat(CustomerLoginRequest customerLoginRequest) {
		CustomerLoginFlat customerLoginFlat=new CustomerLoginFlat();
		if(customerLoginRequest.getEvent().getStandard()!=null){
			customerLoginFlat.setCorrelationID(customerLoginRequest.getEvent().getStandard().getCorrelationID());
			customerLoginFlat.setEventID(customerLoginRequest.getEvent().getStandard().getEventID());
			customerLoginFlat.setEventUUID(customerLoginRequest.getEvent().getStandard().getEventUUID());
			customerLoginFlat.setEventProducer(customerLoginRequest.getEvent().getStandard().getEventProducer());
			customerLoginFlat.setEventTransmitter(customerLoginRequest.getEvent().getStandard().getEventTransmitter());
			customerLoginFlat.setCountryCode(customerLoginRequest.getEvent().getStandard().getCountryCode());
			customerLoginFlat.setBusinessID(customerLoginRequest.getEvent().getStandard().getBusinessID());
			customerLoginFlat.setUUID_UniqueID(customerLoginRequest.getEvent().getStandard().getUUID_UniqueID());
			customerLoginFlat.setESBUUID(customerLoginRequest.getEvent().getStandard().getESBUUID());
			customerLoginFlat.setBizFunctionID(customerLoginRequest.getEvent().getStandard().getBizFunctionID());
			customerLoginFlat.setCustomerID(customerLoginRequest.getEvent().getStandard().getCustomerID());
			customerLoginFlat.setCustomerType(customerLoginRequest.getEvent().getStandard().getCustomerType());
			customerLoginFlat.setCardNumber(customerLoginRequest.getEvent().getStandard().getCardNumber());
		    customerLoginFlat.setAccountNumber(customerLoginRequest.getEvent().getStandard().getAccountNumber());
			customerLoginFlat.setIsCustomerPrimary(customerLoginRequest.getEvent().getStandard().getIsCustomerPrimary());
			customerLoginFlat.setTransactionStatus(customerLoginRequest.getEvent().getStandard().getTransactionStatus());
			customerLoginFlat.setTransactionType(customerLoginRequest.getEvent().getStandard().getTransactionType());
			customerLoginFlat.setRespStatusCode(customerLoginRequest.getEvent().getStandard().getRespStatusCode());
			customerLoginFlat.setRespStatusMsg(customerLoginRequest.getEvent().getStandard().getRespStatusMsg());
		    customerLoginFlat.setServerDateTime(customerLoginRequest.getEvent().getStandard().getServerDateTime());
		    customerLoginFlat.setTouchPoint(customerLoginRequest.getEvent().getStandard().getTouchPoint());
		    customerLoginFlat.setAssistedChannelUserID(customerLoginRequest.getEvent().getStandard().getAssistedChannelUserID());
		}
		
	    if(customerLoginRequest.getEvent().getMetadata()!=null){
	    	customerLoginFlat.setOriginatorFunctionID(customerLoginRequest.getEvent().getMetadata().getOriginatorFunctionID());
		    customerLoginFlat.setOriginatorFunctionType(customerLoginRequest.getEvent().getMetadata().getOriginatorFunctionType());
		    customerLoginFlat.setOriginatorSubFunctionID(customerLoginRequest.getEvent().getMetadata().getOriginatorSubFunctionID());
			customerLoginFlat.setOriginatorFunctionSubType(customerLoginRequest.getEvent().getMetadata().getOriginatorFunctionSubType());
	    }
	    
		if(customerLoginRequest.getEvent().getCustomerAccess()!=null){
			customerLoginFlat.setChannelSessionId(customerLoginRequest.getEvent().getCustomerAccess().getChannelSessionId());
			customerLoginFlat.setDeviceType(customerLoginRequest.getEvent().getCustomerAccess().getDeviceType());
			customerLoginFlat.setDeviceID(customerLoginRequest.getEvent().getCustomerAccess().getDeviceID());
			customerLoginFlat.setDeviceOS(customerLoginRequest.getEvent().getCustomerAccess().getDeviceOS());
			customerLoginFlat.setGeoLocLatitude(customerLoginRequest.getEvent().getCustomerAccess().getGeoLocLatitude());
		    customerLoginFlat.setGeoLocLongitude(customerLoginRequest.getEvent().getCustomerAccess().getGeoLocLongitude());
		    customerLoginFlat.setBrowserName(customerLoginRequest.getEvent().getCustomerAccess().getBrowserName());
		    customerLoginFlat.setClientIPAddress(customerLoginRequest.getEvent().getCustomerAccess().getClientIPAddress());
		}
	    
		return customerLoginFlat;
	}
	
	public DemographicChangeFlat getDemographicChangeFlat(DemographicChangeRequest demographicChangeRequest) {
		DemographicChangeFlat demographicChangeFlat=new DemographicChangeFlat();
		if(demographicChangeRequest.getEvent().getStandard()!=null){
			demographicChangeFlat.setCorrelationID(demographicChangeRequest.getEvent().getStandard().getCorrelationID());
			demographicChangeFlat.setEventID(demographicChangeRequest.getEvent().getStandard().getEventID());
			demographicChangeFlat.setEventUUID(demographicChangeRequest.getEvent().getStandard().getEventUUID());
			demographicChangeFlat.setEventProducer(demographicChangeRequest.getEvent().getStandard().getEventProducer());
			demographicChangeFlat.setEventTransmitter(demographicChangeRequest.getEvent().getStandard().getEventTransmitter());
			demographicChangeFlat.setCountryCode(demographicChangeRequest.getEvent().getStandard().getCountryCode());
			demographicChangeFlat.setBusinessID(demographicChangeRequest.getEvent().getStandard().getBusinessID());
			demographicChangeFlat.setUUID_UniqueID(demographicChangeRequest.getEvent().getStandard().getUUID_UniqueID());
			demographicChangeFlat.setESBUUID(demographicChangeRequest.getEvent().getStandard().getESBUUID());
			demographicChangeFlat.setBizFunctionID(demographicChangeRequest.getEvent().getStandard().getBizFunctionID());
			demographicChangeFlat.setCustomerID(demographicChangeRequest.getEvent().getStandard().getCustomerID());
			demographicChangeFlat.setCustomerType(demographicChangeRequest.getEvent().getStandard().getCustomerType());
			demographicChangeFlat.setCardNumber(demographicChangeRequest.getEvent().getStandard().getCardNumber());
		    demographicChangeFlat.setAccountNumber(demographicChangeRequest.getEvent().getStandard().getAccountNumber());
			demographicChangeFlat.setIsCustomerPrimary(demographicChangeRequest.getEvent().getStandard().getIsCustomerPrimary());
			demographicChangeFlat.setTransactionStatus(demographicChangeRequest.getEvent().getStandard().getTransactionStatus());
			demographicChangeFlat.setTransactionType(demographicChangeRequest.getEvent().getStandard().getTransactionType());
			demographicChangeFlat.setRespStatusCode(demographicChangeRequest.getEvent().getStandard().getRespStatusCode());
			demographicChangeFlat.setRespStatusMsg(demographicChangeRequest.getEvent().getStandard().getRespStatusMsg());
		    demographicChangeFlat.setServerDateTime(demographicChangeRequest.getEvent().getStandard().getServerDateTime());
		    demographicChangeFlat.setTouchPoint(demographicChangeRequest.getEvent().getStandard().getTouchPoint());
		    demographicChangeFlat.setAssistedChannelUserID(demographicChangeRequest.getEvent().getStandard().getAssistedChannelUserID());
		}
		
	    if(demographicChangeRequest.getEvent().getMetadata()!=null){
	    	demographicChangeFlat.setOriginatorFunctionID(demographicChangeRequest.getEvent().getMetadata().getOriginatorFunctionID());
		    demographicChangeFlat.setOriginatorFunctionType(demographicChangeRequest.getEvent().getMetadata().getOriginatorFunctionType());
		    demographicChangeFlat.setOriginatorSubFunctionID(demographicChangeRequest.getEvent().getMetadata().getOriginatorSubFunctionID());
			demographicChangeFlat.setOriginatorFunctionSubType(demographicChangeRequest.getEvent().getMetadata().getOriginatorFunctionSubType());
	    }
	    
		if(demographicChangeRequest.getEvent().getCustomerAccess()!=null){
			demographicChangeFlat.setChannelSessionId(demographicChangeRequest.getEvent().getCustomerAccess().getChannelSessionId());
			demographicChangeFlat.setDeviceType(demographicChangeRequest.getEvent().getCustomerAccess().getDeviceType());
			demographicChangeFlat.setDeviceID(demographicChangeRequest.getEvent().getCustomerAccess().getDeviceID());
			demographicChangeFlat.setDeviceOS(demographicChangeRequest.getEvent().getCustomerAccess().getDeviceOS());
			demographicChangeFlat.setGeoLocLatitude(demographicChangeRequest.getEvent().getCustomerAccess().getGeoLocLatitude());
		    demographicChangeFlat.setGeoLocLongitude(demographicChangeRequest.getEvent().getCustomerAccess().getGeoLocLongitude());
		    demographicChangeFlat.setBrowserName(demographicChangeRequest.getEvent().getCustomerAccess().getBrowserName());
		    demographicChangeFlat.setClientIPAddress(demographicChangeRequest.getEvent().getCustomerAccess().getClientIPAddress());
		}
	    
		return demographicChangeFlat;
	}
	
	public DigiPassInitiationFlat getDigiPassInitiationFlat(DigiPassInitiationRequest digiPassInitiationRequest) {
		DigiPassInitiationFlat digiPassInitiationFlat=new DigiPassInitiationFlat();
		if(digiPassInitiationRequest.getEvent().getStandard()!=null){
			digiPassInitiationFlat.setCorrelationID(digiPassInitiationRequest.getEvent().getStandard().getCorrelationID());
			digiPassInitiationFlat.setEventID(digiPassInitiationRequest.getEvent().getStandard().getEventID());
			digiPassInitiationFlat.setEventUUID(digiPassInitiationRequest.getEvent().getStandard().getEventUUID());
			digiPassInitiationFlat.setEventProducer(digiPassInitiationRequest.getEvent().getStandard().getEventProducer());
			digiPassInitiationFlat.setEventTransmitter(digiPassInitiationRequest.getEvent().getStandard().getEventTransmitter());
			digiPassInitiationFlat.setCountryCode(digiPassInitiationRequest.getEvent().getStandard().getCountryCode());
			digiPassInitiationFlat.setBusinessID(digiPassInitiationRequest.getEvent().getStandard().getBusinessID());
			digiPassInitiationFlat.setUUID_UniqueID(digiPassInitiationRequest.getEvent().getStandard().getUUID_UniqueID());
			digiPassInitiationFlat.setESBUUID(digiPassInitiationRequest.getEvent().getStandard().getESBUUID());
			digiPassInitiationFlat.setBizFunctionID(digiPassInitiationRequest.getEvent().getStandard().getBizFunctionID());
			digiPassInitiationFlat.setCustomerID(digiPassInitiationRequest.getEvent().getStandard().getCustomerID());
			digiPassInitiationFlat.setCustomerType(digiPassInitiationRequest.getEvent().getStandard().getCustomerType());
			digiPassInitiationFlat.setCardNumber(digiPassInitiationRequest.getEvent().getStandard().getCardNumber());
		    digiPassInitiationFlat.setAccountNumber(digiPassInitiationRequest.getEvent().getStandard().getAccountNumber());
			digiPassInitiationFlat.setIsCustomerPrimary(digiPassInitiationRequest.getEvent().getStandard().getIsCustomerPrimary());
			digiPassInitiationFlat.setTransactionStatus(digiPassInitiationRequest.getEvent().getStandard().getTransactionStatus());
			digiPassInitiationFlat.setTransactionType(digiPassInitiationRequest.getEvent().getStandard().getTransactionType());
			digiPassInitiationFlat.setRespStatusCode(digiPassInitiationRequest.getEvent().getStandard().getRespStatusCode());
			digiPassInitiationFlat.setRespStatusMsg(digiPassInitiationRequest.getEvent().getStandard().getRespStatusMsg());
		    digiPassInitiationFlat.setServerDateTime(digiPassInitiationRequest.getEvent().getStandard().getServerDateTime());
		    digiPassInitiationFlat.setTouchPoint(digiPassInitiationRequest.getEvent().getStandard().getTouchPoint());
		    digiPassInitiationFlat.setAssistedChannelUserID(digiPassInitiationRequest.getEvent().getStandard().getAssistedChannelUserID());
		}
		
	    if(digiPassInitiationRequest.getEvent().getMetadata()!=null){
	    	digiPassInitiationFlat.setOriginatorFunctionID(digiPassInitiationRequest.getEvent().getMetadata().getOriginatorFunctionID());
		    digiPassInitiationFlat.setOriginatorFunctionType(digiPassInitiationRequest.getEvent().getMetadata().getOriginatorFunctionType());
		    digiPassInitiationFlat.setOriginatorSubFunctionID(digiPassInitiationRequest.getEvent().getMetadata().getOriginatorSubFunctionID());
			digiPassInitiationFlat.setOriginatorFunctionSubType(digiPassInitiationRequest.getEvent().getMetadata().getOriginatorFunctionSubType());
	    }
	    
		if(digiPassInitiationRequest.getEvent().getCustomerAccess()!=null){
			digiPassInitiationFlat.setChannelSessionId(digiPassInitiationRequest.getEvent().getCustomerAccess().getChannelSessionId());
			digiPassInitiationFlat.setDeviceType(digiPassInitiationRequest.getEvent().getCustomerAccess().getDeviceType());
			digiPassInitiationFlat.setDeviceID(digiPassInitiationRequest.getEvent().getCustomerAccess().getDeviceID());
			digiPassInitiationFlat.setDeviceOS(digiPassInitiationRequest.getEvent().getCustomerAccess().getDeviceOS());
			digiPassInitiationFlat.setGeoLocLatitude(digiPassInitiationRequest.getEvent().getCustomerAccess().getGeoLocLatitude());
		    digiPassInitiationFlat.setGeoLocLongitude(digiPassInitiationRequest.getEvent().getCustomerAccess().getGeoLocLongitude());
		    digiPassInitiationFlat.setBrowserName(digiPassInitiationRequest.getEvent().getCustomerAccess().getBrowserName());
		    digiPassInitiationFlat.setClientIPAddress(digiPassInitiationRequest.getEvent().getCustomerAccess().getClientIPAddress());
		}
	    
		return digiPassInitiationFlat;
	}
	
	public EPPLOPOfferViewFlat getEPPLOPOfferViewFlat(EPPLOPOfferViewRequest epplopOfferViewRequest) {
		EPPLOPOfferViewFlat epplopOfferViewFlat=new EPPLOPOfferViewFlat();
		if(epplopOfferViewRequest.getEvent().getStandard()!=null){
			epplopOfferViewFlat.setCorrelationID(epplopOfferViewRequest.getEvent().getStandard().getCorrelationID());
			epplopOfferViewFlat.setEventID(epplopOfferViewRequest.getEvent().getStandard().getEventID());
			epplopOfferViewFlat.setEventUUID(epplopOfferViewRequest.getEvent().getStandard().getEventUUID());
			epplopOfferViewFlat.setEventProducer(epplopOfferViewRequest.getEvent().getStandard().getEventProducer());
			epplopOfferViewFlat.setEventTransmitter(epplopOfferViewRequest.getEvent().getStandard().getEventTransmitter());
			epplopOfferViewFlat.setCountryCode(epplopOfferViewRequest.getEvent().getStandard().getCountryCode());
			epplopOfferViewFlat.setBusinessID(epplopOfferViewRequest.getEvent().getStandard().getBusinessID());
			epplopOfferViewFlat.setUUID_UniqueID(epplopOfferViewRequest.getEvent().getStandard().getUUID_UniqueID());
			epplopOfferViewFlat.setESBUUID(epplopOfferViewRequest.getEvent().getStandard().getESBUUID());
			epplopOfferViewFlat.setBizFunctionID(epplopOfferViewRequest.getEvent().getStandard().getBizFunctionID());
			epplopOfferViewFlat.setCustomerID(epplopOfferViewRequest.getEvent().getStandard().getCustomerID());
			epplopOfferViewFlat.setCustomerType(epplopOfferViewRequest.getEvent().getStandard().getCustomerType());
			epplopOfferViewFlat.setCardNumber(epplopOfferViewRequest.getEvent().getStandard().getCardNumber());
		    epplopOfferViewFlat.setAccountNumber(epplopOfferViewRequest.getEvent().getStandard().getAccountNumber());
			epplopOfferViewFlat.setIsCustomerPrimary(epplopOfferViewRequest.getEvent().getStandard().getIsCustomerPrimary());
			epplopOfferViewFlat.setTransactionStatus(epplopOfferViewRequest.getEvent().getStandard().getTransactionStatus());
			epplopOfferViewFlat.setTransactionType(epplopOfferViewRequest.getEvent().getStandard().getTransactionType());
			epplopOfferViewFlat.setRespStatusCode(epplopOfferViewRequest.getEvent().getStandard().getRespStatusCode());
			epplopOfferViewFlat.setRespStatusMsg(epplopOfferViewRequest.getEvent().getStandard().getRespStatusMsg());
		    epplopOfferViewFlat.setServerDateTime(epplopOfferViewRequest.getEvent().getStandard().getServerDateTime());
		    epplopOfferViewFlat.setTouchPoint(epplopOfferViewRequest.getEvent().getStandard().getTouchPoint());
		    epplopOfferViewFlat.setAssistedChannelUserID(epplopOfferViewRequest.getEvent().getStandard().getAssistedChannelUserID());
		}
		
	    if(epplopOfferViewRequest.getEvent().getMetadata()!=null){
	    	epplopOfferViewFlat.setOriginatorFunctionID(epplopOfferViewRequest.getEvent().getMetadata().getOriginatorFunctionID());
		    epplopOfferViewFlat.setOriginatorFunctionType(epplopOfferViewRequest.getEvent().getMetadata().getOriginatorFunctionType());
		    epplopOfferViewFlat.setOriginatorSubFunctionID(epplopOfferViewRequest.getEvent().getMetadata().getOriginatorSubFunctionID());
			epplopOfferViewFlat.setOriginatorFunctionSubType(epplopOfferViewRequest.getEvent().getMetadata().getOriginatorFunctionSubType());
	    }
	    
		if(epplopOfferViewRequest.getEvent().getCustomerAccess()!=null){
			epplopOfferViewFlat.setChannelSessionId(epplopOfferViewRequest.getEvent().getCustomerAccess().getChannelSessionId());
			epplopOfferViewFlat.setDeviceType(epplopOfferViewRequest.getEvent().getCustomerAccess().getDeviceType());
			epplopOfferViewFlat.setDeviceID(epplopOfferViewRequest.getEvent().getCustomerAccess().getDeviceID());
			epplopOfferViewFlat.setDeviceOS(epplopOfferViewRequest.getEvent().getCustomerAccess().getDeviceOS());
			epplopOfferViewFlat.setGeoLocLatitude(epplopOfferViewRequest.getEvent().getCustomerAccess().getGeoLocLatitude());
		    epplopOfferViewFlat.setGeoLocLongitude(epplopOfferViewRequest.getEvent().getCustomerAccess().getGeoLocLongitude());
		    epplopOfferViewFlat.setBrowserName(epplopOfferViewRequest.getEvent().getCustomerAccess().getBrowserName());
		    epplopOfferViewFlat.setClientIPAddress(epplopOfferViewRequest.getEvent().getCustomerAccess().getClientIPAddress());
		}
	    
		return epplopOfferViewFlat;
	}
	
	public EstatementDispatchFlat getEstatementDispatchFlat(EstatementDispatchRequest estatementDispatchRequest) {
		EstatementDispatchFlat estatementDispatchFlat=new EstatementDispatchFlat();
		if(estatementDispatchRequest.getEvent().getStandard()!=null){
			estatementDispatchFlat.setCorrelationID(estatementDispatchRequest.getEvent().getStandard().getCorrelationID());
			estatementDispatchFlat.setEventID(estatementDispatchRequest.getEvent().getStandard().getEventID());
			estatementDispatchFlat.setEventUUID(estatementDispatchRequest.getEvent().getStandard().getEventUUID());
			estatementDispatchFlat.setEventProducer(estatementDispatchRequest.getEvent().getStandard().getEventProducer());
			estatementDispatchFlat.setEventTransmitter(estatementDispatchRequest.getEvent().getStandard().getEventTransmitter());
			estatementDispatchFlat.setCountryCode(estatementDispatchRequest.getEvent().getStandard().getCountryCode());
			estatementDispatchFlat.setBusinessID(estatementDispatchRequest.getEvent().getStandard().getBusinessID());
			estatementDispatchFlat.setUUID_UniqueID(estatementDispatchRequest.getEvent().getStandard().getUUID_UniqueID());
			estatementDispatchFlat.setESBUUID(estatementDispatchRequest.getEvent().getStandard().getESBUUID());
			estatementDispatchFlat.setBizFunctionID(estatementDispatchRequest.getEvent().getStandard().getBizFunctionID());
			estatementDispatchFlat.setCustomerID(estatementDispatchRequest.getEvent().getStandard().getCustomerID());
			estatementDispatchFlat.setCustomerType(estatementDispatchRequest.getEvent().getStandard().getCustomerType());
			estatementDispatchFlat.setCardNumber(estatementDispatchRequest.getEvent().getStandard().getCardNumber());
		    estatementDispatchFlat.setAccountNumber(estatementDispatchRequest.getEvent().getStandard().getAccountNumber());
			estatementDispatchFlat.setIsCustomerPrimary(estatementDispatchRequest.getEvent().getStandard().getIsCustomerPrimary());
			estatementDispatchFlat.setTransactionStatus(estatementDispatchRequest.getEvent().getStandard().getTransactionStatus());
			estatementDispatchFlat.setTransactionType(estatementDispatchRequest.getEvent().getStandard().getTransactionType());
			estatementDispatchFlat.setRespStatusCode(estatementDispatchRequest.getEvent().getStandard().getRespStatusCode());
			estatementDispatchFlat.setRespStatusMsg(estatementDispatchRequest.getEvent().getStandard().getRespStatusMsg());
		    estatementDispatchFlat.setServerDateTime(estatementDispatchRequest.getEvent().getStandard().getServerDateTime());
		    estatementDispatchFlat.setTouchPoint(estatementDispatchRequest.getEvent().getStandard().getTouchPoint());
		    estatementDispatchFlat.setAssistedChannelUserID(estatementDispatchRequest.getEvent().getStandard().getAssistedChannelUserID());
		}
		
	    if(estatementDispatchRequest.getEvent().getMetadata()!=null){
	    	estatementDispatchFlat.setOriginatorFunctionID(estatementDispatchRequest.getEvent().getMetadata().getOriginatorFunctionID());
		    estatementDispatchFlat.setOriginatorFunctionType(estatementDispatchRequest.getEvent().getMetadata().getOriginatorFunctionType());
		    estatementDispatchFlat.setOriginatorSubFunctionID(estatementDispatchRequest.getEvent().getMetadata().getOriginatorSubFunctionID());
			estatementDispatchFlat.setOriginatorFunctionSubType(estatementDispatchRequest.getEvent().getMetadata().getOriginatorFunctionSubType());
	    }
	    
		if(estatementDispatchRequest.getEvent().getCustomerAccess()!=null){
			estatementDispatchFlat.setChannelSessionId(estatementDispatchRequest.getEvent().getCustomerAccess().getChannelSessionId());
			estatementDispatchFlat.setDeviceType(estatementDispatchRequest.getEvent().getCustomerAccess().getDeviceType());
			estatementDispatchFlat.setDeviceID(estatementDispatchRequest.getEvent().getCustomerAccess().getDeviceID());
			estatementDispatchFlat.setDeviceOS(estatementDispatchRequest.getEvent().getCustomerAccess().getDeviceOS());
			estatementDispatchFlat.setGeoLocLatitude(estatementDispatchRequest.getEvent().getCustomerAccess().getGeoLocLatitude());
		    estatementDispatchFlat.setGeoLocLongitude(estatementDispatchRequest.getEvent().getCustomerAccess().getGeoLocLongitude());
		    estatementDispatchFlat.setBrowserName(estatementDispatchRequest.getEvent().getCustomerAccess().getBrowserName());
		    estatementDispatchFlat.setClientIPAddress(estatementDispatchRequest.getEvent().getCustomerAccess().getClientIPAddress());
		}
		
		return estatementDispatchFlat;
	}
	
	public EstatementViewFlat getEstatementViewFlat(EstatementViewRequest estatementViewRequest) {
		EstatementViewFlat estatementViewFlat=new EstatementViewFlat();
		if(estatementViewRequest.getEvent().getStandard()!=null){
			estatementViewFlat.setCorrelationID(estatementViewRequest.getEvent().getStandard().getCorrelationID());
			estatementViewFlat.setEventID(estatementViewRequest.getEvent().getStandard().getEventID());
			estatementViewFlat.setEventUUID(estatementViewRequest.getEvent().getStandard().getEventUUID());
			estatementViewFlat.setEventProducer(estatementViewRequest.getEvent().getStandard().getEventProducer());
			estatementViewFlat.setEventTransmitter(estatementViewRequest.getEvent().getStandard().getEventTransmitter());
			estatementViewFlat.setCountryCode(estatementViewRequest.getEvent().getStandard().getCountryCode());
			estatementViewFlat.setBusinessID(estatementViewRequest.getEvent().getStandard().getBusinessID());
			estatementViewFlat.setUUID_UniqueID(estatementViewRequest.getEvent().getStandard().getUUID_UniqueID());
			estatementViewFlat.setESBUUID(estatementViewRequest.getEvent().getStandard().getESBUUID());
			estatementViewFlat.setBizFunctionID(estatementViewRequest.getEvent().getStandard().getBizFunctionID());
			estatementViewFlat.setCustomerID(estatementViewRequest.getEvent().getStandard().getCustomerID());
			estatementViewFlat.setCustomerType(estatementViewRequest.getEvent().getStandard().getCustomerType());
			estatementViewFlat.setCardNumber(estatementViewRequest.getEvent().getStandard().getCardNumber());
		    estatementViewFlat.setAccountNumber(estatementViewRequest.getEvent().getStandard().getAccountNumber());
			estatementViewFlat.setIsCustomerPrimary(estatementViewRequest.getEvent().getStandard().getIsCustomerPrimary());
			estatementViewFlat.setTransactionStatus(estatementViewRequest.getEvent().getStandard().getTransactionStatus());
			estatementViewFlat.setTransactionType(estatementViewRequest.getEvent().getStandard().getTransactionType());
			estatementViewFlat.setRespStatusCode(estatementViewRequest.getEvent().getStandard().getRespStatusCode());
			estatementViewFlat.setRespStatusMsg(estatementViewRequest.getEvent().getStandard().getRespStatusMsg());
		    estatementViewFlat.setServerDateTime(estatementViewRequest.getEvent().getStandard().getServerDateTime());
		    estatementViewFlat.setTouchPoint(estatementViewRequest.getEvent().getStandard().getTouchPoint());
		    estatementViewFlat.setAssistedChannelUserID(estatementViewRequest.getEvent().getStandard().getAssistedChannelUserID());
		}
		
	    if(estatementViewRequest.getEvent().getMetadata()!=null){
	    	estatementViewFlat.setOriginatorFunctionID(estatementViewRequest.getEvent().getMetadata().getOriginatorFunctionID());
		    estatementViewFlat.setOriginatorFunctionType(estatementViewRequest.getEvent().getMetadata().getOriginatorFunctionType());
		    estatementViewFlat.setOriginatorSubFunctionID(estatementViewRequest.getEvent().getMetadata().getOriginatorSubFunctionID());
			estatementViewFlat.setOriginatorFunctionSubType(estatementViewRequest.getEvent().getMetadata().getOriginatorFunctionSubType());
	    }
	    
		if(estatementViewRequest.getEvent().getCustomerAccess()!=null){
			estatementViewFlat.setChannelSessionId(estatementViewRequest.getEvent().getCustomerAccess().getChannelSessionId());
			estatementViewFlat.setDeviceType(estatementViewRequest.getEvent().getCustomerAccess().getDeviceType());
			estatementViewFlat.setDeviceID(estatementViewRequest.getEvent().getCustomerAccess().getDeviceID());
			estatementViewFlat.setDeviceOS(estatementViewRequest.getEvent().getCustomerAccess().getDeviceOS());
			estatementViewFlat.setGeoLocLatitude(estatementViewRequest.getEvent().getCustomerAccess().getGeoLocLatitude());
		    estatementViewFlat.setGeoLocLongitude(estatementViewRequest.getEvent().getCustomerAccess().getGeoLocLongitude());
		    estatementViewFlat.setBrowserName(estatementViewRequest.getEvent().getCustomerAccess().getBrowserName());
		    estatementViewFlat.setClientIPAddress(estatementViewRequest.getEvent().getCustomerAccess().getClientIPAddress());
		}
	    
	    if(estatementViewRequest.getEvent().getExtended()!=null){
	    	estatementViewFlat.setStatementAccountNo(estatementViewRequest.getEvent().getExtended().getStatementAccountNo());
	    	estatementViewFlat.setStatementMonth(estatementViewRequest.getEvent().getExtended().getStatementMonth());
	    }
		
		return estatementViewFlat;
	}
	
	public ForgotUserIdAndPasswordFlat getForgotUserIdAndPasswordFlat(ForgotUserIdAndPasswordRequest forgotUserIdAndPasswordRequest) {
		ForgotUserIdAndPasswordFlat forgotUserIdAndPasswordFlat=new ForgotUserIdAndPasswordFlat();
		if(forgotUserIdAndPasswordRequest.getEvent().getStandard()!=null){
			forgotUserIdAndPasswordFlat.setCorrelationID(forgotUserIdAndPasswordRequest.getEvent().getStandard().getCorrelationID());
			forgotUserIdAndPasswordFlat.setEventID(forgotUserIdAndPasswordRequest.getEvent().getStandard().getEventID());
			forgotUserIdAndPasswordFlat.setEventUUID(forgotUserIdAndPasswordRequest.getEvent().getStandard().getEventUUID());
			forgotUserIdAndPasswordFlat.setEventProducer(forgotUserIdAndPasswordRequest.getEvent().getStandard().getEventProducer());
			forgotUserIdAndPasswordFlat.setEventTransmitter(forgotUserIdAndPasswordRequest.getEvent().getStandard().getEventTransmitter());
			forgotUserIdAndPasswordFlat.setCountryCode(forgotUserIdAndPasswordRequest.getEvent().getStandard().getCountryCode());
			forgotUserIdAndPasswordFlat.setBusinessID(forgotUserIdAndPasswordRequest.getEvent().getStandard().getBusinessID());
			forgotUserIdAndPasswordFlat.setUUID_UniqueID(forgotUserIdAndPasswordRequest.getEvent().getStandard().getUUID_UniqueID());
			forgotUserIdAndPasswordFlat.setESBUUID(forgotUserIdAndPasswordRequest.getEvent().getStandard().getESBUUID());
			forgotUserIdAndPasswordFlat.setBizFunctionID(forgotUserIdAndPasswordRequest.getEvent().getStandard().getBizFunctionID());
			forgotUserIdAndPasswordFlat.setCustomerID(forgotUserIdAndPasswordRequest.getEvent().getStandard().getCustomerID());
			forgotUserIdAndPasswordFlat.setCustomerType(forgotUserIdAndPasswordRequest.getEvent().getStandard().getCustomerType());
			forgotUserIdAndPasswordFlat.setCardNumber(forgotUserIdAndPasswordRequest.getEvent().getStandard().getCardNumber());
		    forgotUserIdAndPasswordFlat.setAccountNumber(forgotUserIdAndPasswordRequest.getEvent().getStandard().getAccountNumber());
			forgotUserIdAndPasswordFlat.setIsCustomerPrimary(forgotUserIdAndPasswordRequest.getEvent().getStandard().getIsCustomerPrimary());
			forgotUserIdAndPasswordFlat.setTransactionStatus(forgotUserIdAndPasswordRequest.getEvent().getStandard().getTransactionStatus());
			forgotUserIdAndPasswordFlat.setTransactionType(forgotUserIdAndPasswordRequest.getEvent().getStandard().getTransactionType());
			forgotUserIdAndPasswordFlat.setRespStatusCode(forgotUserIdAndPasswordRequest.getEvent().getStandard().getRespStatusCode());
			forgotUserIdAndPasswordFlat.setRespStatusMsg(forgotUserIdAndPasswordRequest.getEvent().getStandard().getRespStatusMsg());
		    forgotUserIdAndPasswordFlat.setServerDateTime(forgotUserIdAndPasswordRequest.getEvent().getStandard().getServerDateTime());
		    forgotUserIdAndPasswordFlat.setTouchPoint(forgotUserIdAndPasswordRequest.getEvent().getStandard().getTouchPoint());
		    forgotUserIdAndPasswordFlat.setAssistedChannelUserID(forgotUserIdAndPasswordRequest.getEvent().getStandard().getAssistedChannelUserID());
		}
		
	    if(forgotUserIdAndPasswordRequest.getEvent().getMetadata()!=null){
	    	forgotUserIdAndPasswordFlat.setOriginatorFunctionID(forgotUserIdAndPasswordRequest.getEvent().getMetadata().getOriginatorFunctionID());
		    forgotUserIdAndPasswordFlat.setOriginatorFunctionType(forgotUserIdAndPasswordRequest.getEvent().getMetadata().getOriginatorFunctionType());
		    forgotUserIdAndPasswordFlat.setOriginatorSubFunctionID(forgotUserIdAndPasswordRequest.getEvent().getMetadata().getOriginatorSubFunctionID());
			forgotUserIdAndPasswordFlat.setOriginatorFunctionSubType(forgotUserIdAndPasswordRequest.getEvent().getMetadata().getOriginatorFunctionSubType());
	    }
	    
		if(forgotUserIdAndPasswordRequest.getEvent().getCustomerAccess()!=null){
			forgotUserIdAndPasswordFlat.setChannelSessionId(forgotUserIdAndPasswordRequest.getEvent().getCustomerAccess().getChannelSessionId());
			forgotUserIdAndPasswordFlat.setDeviceType(forgotUserIdAndPasswordRequest.getEvent().getCustomerAccess().getDeviceType());
			forgotUserIdAndPasswordFlat.setDeviceID(forgotUserIdAndPasswordRequest.getEvent().getCustomerAccess().getDeviceID());
			forgotUserIdAndPasswordFlat.setDeviceOS(forgotUserIdAndPasswordRequest.getEvent().getCustomerAccess().getDeviceOS());
			forgotUserIdAndPasswordFlat.setGeoLocLatitude(forgotUserIdAndPasswordRequest.getEvent().getCustomerAccess().getGeoLocLatitude());
		    forgotUserIdAndPasswordFlat.setGeoLocLongitude(forgotUserIdAndPasswordRequest.getEvent().getCustomerAccess().getGeoLocLongitude());
		    forgotUserIdAndPasswordFlat.setBrowserName(forgotUserIdAndPasswordRequest.getEvent().getCustomerAccess().getBrowserName());
		    forgotUserIdAndPasswordFlat.setClientIPAddress(forgotUserIdAndPasswordRequest.getEvent().getCustomerAccess().getClientIPAddress());
		}
	    
		return forgotUserIdAndPasswordFlat;
	}
	
	public IVRCallEndFlat getIVRCallEndFlat(IVRCallEndRequest ivrCallEndRequest) {
		IVRCallEndFlat ivrCallEndFlat=new IVRCallEndFlat();
		if(ivrCallEndRequest.getEvent().getStandard()!=null){
			ivrCallEndFlat.setCorrelationID(ivrCallEndRequest.getEvent().getStandard().getCorrelationID());
			ivrCallEndFlat.setEventID(ivrCallEndRequest.getEvent().getStandard().getEventID());
			ivrCallEndFlat.setEventUUID(ivrCallEndRequest.getEvent().getStandard().getEventUUID());
			ivrCallEndFlat.setEventProducer(ivrCallEndRequest.getEvent().getStandard().getEventProducer());
			ivrCallEndFlat.setEventTransmitter(ivrCallEndRequest.getEvent().getStandard().getEventTransmitter());
			ivrCallEndFlat.setCountryCode(ivrCallEndRequest.getEvent().getStandard().getCountryCode());
			ivrCallEndFlat.setBusinessID(ivrCallEndRequest.getEvent().getStandard().getBusinessID());
			ivrCallEndFlat.setUUID_UniqueID(ivrCallEndRequest.getEvent().getStandard().getUUID_UniqueID());
			ivrCallEndFlat.setESBUUID(ivrCallEndRequest.getEvent().getStandard().getESBUUID());
			ivrCallEndFlat.setBizFunctionID(ivrCallEndRequest.getEvent().getStandard().getBizFunctionID());
			ivrCallEndFlat.setCustomerID(ivrCallEndRequest.getEvent().getStandard().getCustomerID());
			ivrCallEndFlat.setCustomerType(ivrCallEndRequest.getEvent().getStandard().getCustomerType());
			ivrCallEndFlat.setCardNumber(ivrCallEndRequest.getEvent().getStandard().getCardNumber());
		    ivrCallEndFlat.setAccountNumber(ivrCallEndRequest.getEvent().getStandard().getAccountNumber());
			ivrCallEndFlat.setIsCustomerPrimary(ivrCallEndRequest.getEvent().getStandard().getIsCustomerPrimary());
			ivrCallEndFlat.setTransactionStatus(ivrCallEndRequest.getEvent().getStandard().getTransactionStatus());
			ivrCallEndFlat.setTransactionType(ivrCallEndRequest.getEvent().getStandard().getTransactionType());
			ivrCallEndFlat.setRespStatusCode(ivrCallEndRequest.getEvent().getStandard().getRespStatusCode());
			ivrCallEndFlat.setRespStatusMsg(ivrCallEndRequest.getEvent().getStandard().getRespStatusMsg());
		    ivrCallEndFlat.setServerDateTime(ivrCallEndRequest.getEvent().getStandard().getServerDateTime());
		    ivrCallEndFlat.setTouchPoint(ivrCallEndRequest.getEvent().getStandard().getTouchPoint());
		    ivrCallEndFlat.setAssistedChannelUserID(ivrCallEndRequest.getEvent().getStandard().getAssistedChannelUserID());
		}
		
	    if(ivrCallEndRequest.getEvent().getMetadata()!=null){
	    	ivrCallEndFlat.setOriginatorFunctionID(ivrCallEndRequest.getEvent().getMetadata().getOriginatorFunctionID());
		    ivrCallEndFlat.setOriginatorFunctionType(ivrCallEndRequest.getEvent().getMetadata().getOriginatorFunctionType());
		    ivrCallEndFlat.setOriginatorSubFunctionID(ivrCallEndRequest.getEvent().getMetadata().getOriginatorSubFunctionID());
			ivrCallEndFlat.setOriginatorFunctionSubType(ivrCallEndRequest.getEvent().getMetadata().getOriginatorFunctionSubType());
	    }
	    
		if(ivrCallEndRequest.getEvent().getCustomerAccess()!=null){
			ivrCallEndFlat.setChannelSessionId(ivrCallEndRequest.getEvent().getCustomerAccess().getChannelSessionId());
			ivrCallEndFlat.setDeviceType(ivrCallEndRequest.getEvent().getCustomerAccess().getDeviceType());
			ivrCallEndFlat.setDeviceID(ivrCallEndRequest.getEvent().getCustomerAccess().getDeviceID());
			ivrCallEndFlat.setDeviceOS(ivrCallEndRequest.getEvent().getCustomerAccess().getDeviceOS());
			ivrCallEndFlat.setGeoLocLatitude(ivrCallEndRequest.getEvent().getCustomerAccess().getGeoLocLatitude());
		    ivrCallEndFlat.setGeoLocLongitude(ivrCallEndRequest.getEvent().getCustomerAccess().getGeoLocLongitude());
		    ivrCallEndFlat.setBrowserName(ivrCallEndRequest.getEvent().getCustomerAccess().getBrowserName());
		    ivrCallEndFlat.setClientIPAddress(ivrCallEndRequest.getEvent().getCustomerAccess().getClientIPAddress());
		}
	    
	    if(ivrCallEndRequest.getEvent().getExtended()!=null){
	    	ivrCallEndFlat.setCallDisposition(ivrCallEndRequest.getEvent().getExtended().getCallDisposition());
	    }
		
		return ivrCallEndFlat;
	}
	
	public IVRCallStartFlat getIVRCallStartFlat(IVRCallStartRequest ivrCallStartRequest) {
		IVRCallStartFlat ivrCallStartFlat=new IVRCallStartFlat();
		if(ivrCallStartRequest.getEvent().getStandard()!=null){
			ivrCallStartFlat.setCorrelationID(ivrCallStartRequest.getEvent().getStandard().getCorrelationID());
			ivrCallStartFlat.setEventID(ivrCallStartRequest.getEvent().getStandard().getEventID());
			ivrCallStartFlat.setEventUUID(ivrCallStartRequest.getEvent().getStandard().getEventUUID());
			ivrCallStartFlat.setEventProducer(ivrCallStartRequest.getEvent().getStandard().getEventProducer());
			ivrCallStartFlat.setEventTransmitter(ivrCallStartRequest.getEvent().getStandard().getEventTransmitter());
			ivrCallStartFlat.setCountryCode(ivrCallStartRequest.getEvent().getStandard().getCountryCode());
			ivrCallStartFlat.setBusinessID(ivrCallStartRequest.getEvent().getStandard().getBusinessID());
			ivrCallStartFlat.setUUID_UniqueID(ivrCallStartRequest.getEvent().getStandard().getUUID_UniqueID());
			ivrCallStartFlat.setESBUUID(ivrCallStartRequest.getEvent().getStandard().getESBUUID());
			ivrCallStartFlat.setBizFunctionID(ivrCallStartRequest.getEvent().getStandard().getBizFunctionID());
			ivrCallStartFlat.setCustomerID(ivrCallStartRequest.getEvent().getStandard().getCustomerID());
			ivrCallStartFlat.setCustomerType(ivrCallStartRequest.getEvent().getStandard().getCustomerType());
			ivrCallStartFlat.setCardNumber(ivrCallStartRequest.getEvent().getStandard().getCardNumber());
		    ivrCallStartFlat.setAccountNumber(ivrCallStartRequest.getEvent().getStandard().getAccountNumber());
			ivrCallStartFlat.setIsCustomerPrimary(ivrCallStartRequest.getEvent().getStandard().getIsCustomerPrimary());
			ivrCallStartFlat.setTransactionStatus(ivrCallStartRequest.getEvent().getStandard().getTransactionStatus());
			ivrCallStartFlat.setTransactionType(ivrCallStartRequest.getEvent().getStandard().getTransactionType());
			ivrCallStartFlat.setRespStatusCode(ivrCallStartRequest.getEvent().getStandard().getRespStatusCode());
			ivrCallStartFlat.setRespStatusMsg(ivrCallStartRequest.getEvent().getStandard().getRespStatusMsg());
		    ivrCallStartFlat.setServerDateTime(ivrCallStartRequest.getEvent().getStandard().getServerDateTime());
		    ivrCallStartFlat.setTouchPoint(ivrCallStartRequest.getEvent().getStandard().getTouchPoint());
		    ivrCallStartFlat.setAssistedChannelUserID(ivrCallStartRequest.getEvent().getStandard().getAssistedChannelUserID());
		}
		
	    if(ivrCallStartRequest.getEvent().getMetadata()!=null){
	    	ivrCallStartFlat.setOriginatorFunctionID(ivrCallStartRequest.getEvent().getMetadata().getOriginatorFunctionID());
		    ivrCallStartFlat.setOriginatorFunctionType(ivrCallStartRequest.getEvent().getMetadata().getOriginatorFunctionType());
		    ivrCallStartFlat.setOriginatorSubFunctionID(ivrCallStartRequest.getEvent().getMetadata().getOriginatorSubFunctionID());
			ivrCallStartFlat.setOriginatorFunctionSubType(ivrCallStartRequest.getEvent().getMetadata().getOriginatorFunctionSubType());
	    }
	    
		if(ivrCallStartRequest.getEvent().getCustomerAccess()!=null){
			ivrCallStartFlat.setChannelSessionId(ivrCallStartRequest.getEvent().getCustomerAccess().getChannelSessionId());
			ivrCallStartFlat.setDeviceType(ivrCallStartRequest.getEvent().getCustomerAccess().getDeviceType());
			ivrCallStartFlat.setDeviceID(ivrCallStartRequest.getEvent().getCustomerAccess().getDeviceID());
			ivrCallStartFlat.setDeviceOS(ivrCallStartRequest.getEvent().getCustomerAccess().getDeviceOS());
			ivrCallStartFlat.setGeoLocLatitude(ivrCallStartRequest.getEvent().getCustomerAccess().getGeoLocLatitude());
		    ivrCallStartFlat.setGeoLocLongitude(ivrCallStartRequest.getEvent().getCustomerAccess().getGeoLocLongitude());
		    ivrCallStartFlat.setBrowserName(ivrCallStartRequest.getEvent().getCustomerAccess().getBrowserName());
		    ivrCallStartFlat.setClientIPAddress(ivrCallStartRequest.getEvent().getCustomerAccess().getClientIPAddress());
		}
		
		return ivrCallStartFlat;
	}
	
	public OnlineDirectDebitExecutionFlat getOnlineDirectDebitExecutionFlat(OnlineDirectDebitExecutionRequest onlineDirectDebitExecutionRequest) {
		OnlineDirectDebitExecutionFlat onlineDirectDebitExecutionFlat=new OnlineDirectDebitExecutionFlat();
		if(onlineDirectDebitExecutionRequest.getEvent().getStandard()!=null){
			onlineDirectDebitExecutionFlat.setCorrelationID(onlineDirectDebitExecutionRequest.getEvent().getStandard().getCorrelationID());
			onlineDirectDebitExecutionFlat.setEventID(onlineDirectDebitExecutionRequest.getEvent().getStandard().getEventID());
			onlineDirectDebitExecutionFlat.setEventUUID(onlineDirectDebitExecutionRequest.getEvent().getStandard().getEventUUID());
			onlineDirectDebitExecutionFlat.setEventProducer(onlineDirectDebitExecutionRequest.getEvent().getStandard().getEventProducer());
			onlineDirectDebitExecutionFlat.setEventTransmitter(onlineDirectDebitExecutionRequest.getEvent().getStandard().getEventTransmitter());
			onlineDirectDebitExecutionFlat.setCountryCode(onlineDirectDebitExecutionRequest.getEvent().getStandard().getCountryCode());
			onlineDirectDebitExecutionFlat.setBusinessID(onlineDirectDebitExecutionRequest.getEvent().getStandard().getBusinessID());
			onlineDirectDebitExecutionFlat.setUUID_UniqueID(onlineDirectDebitExecutionRequest.getEvent().getStandard().getUUID_UniqueID());
			onlineDirectDebitExecutionFlat.setESBUUID(onlineDirectDebitExecutionRequest.getEvent().getStandard().getESBUUID());
			onlineDirectDebitExecutionFlat.setBizFunctionID(onlineDirectDebitExecutionRequest.getEvent().getStandard().getBizFunctionID());
			onlineDirectDebitExecutionFlat.setCustomerID(onlineDirectDebitExecutionRequest.getEvent().getStandard().getCustomerID());
			onlineDirectDebitExecutionFlat.setCustomerType(onlineDirectDebitExecutionRequest.getEvent().getStandard().getCustomerType());
			onlineDirectDebitExecutionFlat.setCardNumber(onlineDirectDebitExecutionRequest.getEvent().getStandard().getCardNumber());
		    onlineDirectDebitExecutionFlat.setAccountNumber(onlineDirectDebitExecutionRequest.getEvent().getStandard().getAccountNumber());
			onlineDirectDebitExecutionFlat.setIsCustomerPrimary(onlineDirectDebitExecutionRequest.getEvent().getStandard().getIsCustomerPrimary());
			onlineDirectDebitExecutionFlat.setTransactionStatus(onlineDirectDebitExecutionRequest.getEvent().getStandard().getTransactionStatus());
			onlineDirectDebitExecutionFlat.setTransactionType(onlineDirectDebitExecutionRequest.getEvent().getStandard().getTransactionType());
			onlineDirectDebitExecutionFlat.setRespStatusCode(onlineDirectDebitExecutionRequest.getEvent().getStandard().getRespStatusCode());
			onlineDirectDebitExecutionFlat.setRespStatusMsg(onlineDirectDebitExecutionRequest.getEvent().getStandard().getRespStatusMsg());
		    onlineDirectDebitExecutionFlat.setServerDateTime(onlineDirectDebitExecutionRequest.getEvent().getStandard().getServerDateTime());
		    onlineDirectDebitExecutionFlat.setTouchPoint(onlineDirectDebitExecutionRequest.getEvent().getStandard().getTouchPoint());
		    onlineDirectDebitExecutionFlat.setAssistedChannelUserID(onlineDirectDebitExecutionRequest.getEvent().getStandard().getAssistedChannelUserID());
		}
		
	    if(onlineDirectDebitExecutionRequest.getEvent().getMetadata()!=null){
	    	onlineDirectDebitExecutionFlat.setOriginatorFunctionID(onlineDirectDebitExecutionRequest.getEvent().getMetadata().getOriginatorFunctionID());
		    onlineDirectDebitExecutionFlat.setOriginatorFunctionType(onlineDirectDebitExecutionRequest.getEvent().getMetadata().getOriginatorFunctionType());
		    onlineDirectDebitExecutionFlat.setOriginatorSubFunctionID(onlineDirectDebitExecutionRequest.getEvent().getMetadata().getOriginatorSubFunctionID());
			onlineDirectDebitExecutionFlat.setOriginatorFunctionSubType(onlineDirectDebitExecutionRequest.getEvent().getMetadata().getOriginatorFunctionSubType());
	    }
	    
		if(onlineDirectDebitExecutionRequest.getEvent().getCustomerAccess()!=null){
			onlineDirectDebitExecutionFlat.setChannelSessionId(onlineDirectDebitExecutionRequest.getEvent().getCustomerAccess().getChannelSessionId());
			onlineDirectDebitExecutionFlat.setDeviceType(onlineDirectDebitExecutionRequest.getEvent().getCustomerAccess().getDeviceType());
			onlineDirectDebitExecutionFlat.setDeviceID(onlineDirectDebitExecutionRequest.getEvent().getCustomerAccess().getDeviceID());
			onlineDirectDebitExecutionFlat.setDeviceOS(onlineDirectDebitExecutionRequest.getEvent().getCustomerAccess().getDeviceOS());
			onlineDirectDebitExecutionFlat.setGeoLocLatitude(onlineDirectDebitExecutionRequest.getEvent().getCustomerAccess().getGeoLocLatitude());
		    onlineDirectDebitExecutionFlat.setGeoLocLongitude(onlineDirectDebitExecutionRequest.getEvent().getCustomerAccess().getGeoLocLongitude());
		    onlineDirectDebitExecutionFlat.setBrowserName(onlineDirectDebitExecutionRequest.getEvent().getCustomerAccess().getBrowserName());
		    onlineDirectDebitExecutionFlat.setClientIPAddress(onlineDirectDebitExecutionRequest.getEvent().getCustomerAccess().getClientIPAddress());
		}
	    
		return onlineDirectDebitExecutionFlat;
	}
	
	public OverseasCardActivationFlat getOverseasCardActivationFlat(OverseasCardActivationRequest overseasCardActivationRequest) {
		OverseasCardActivationFlat overseasCardActivationFlat=new OverseasCardActivationFlat();
		if(overseasCardActivationRequest.getEvent().getStandard()!=null){
			overseasCardActivationFlat.setCorrelationID(overseasCardActivationRequest.getEvent().getStandard().getCorrelationID());
			overseasCardActivationFlat.setEventID(overseasCardActivationRequest.getEvent().getStandard().getEventID());
			overseasCardActivationFlat.setEventUUID(overseasCardActivationRequest.getEvent().getStandard().getEventUUID());
			overseasCardActivationFlat.setEventProducer(overseasCardActivationRequest.getEvent().getStandard().getEventProducer());
			overseasCardActivationFlat.setEventTransmitter(overseasCardActivationRequest.getEvent().getStandard().getEventTransmitter());
			overseasCardActivationFlat.setCountryCode(overseasCardActivationRequest.getEvent().getStandard().getCountryCode());
			overseasCardActivationFlat.setBusinessID(overseasCardActivationRequest.getEvent().getStandard().getBusinessID());
			overseasCardActivationFlat.setUUID_UniqueID(overseasCardActivationRequest.getEvent().getStandard().getUUID_UniqueID());
			overseasCardActivationFlat.setESBUUID(overseasCardActivationRequest.getEvent().getStandard().getESBUUID());
			overseasCardActivationFlat.setBizFunctionID(overseasCardActivationRequest.getEvent().getStandard().getBizFunctionID());
			overseasCardActivationFlat.setCustomerID(overseasCardActivationRequest.getEvent().getStandard().getCustomerID());
			overseasCardActivationFlat.setCustomerType(overseasCardActivationRequest.getEvent().getStandard().getCustomerType());
			overseasCardActivationFlat.setCardNumber(overseasCardActivationRequest.getEvent().getStandard().getCardNumber());
		    overseasCardActivationFlat.setAccountNumber(overseasCardActivationRequest.getEvent().getStandard().getAccountNumber());
			overseasCardActivationFlat.setIsCustomerPrimary(overseasCardActivationRequest.getEvent().getStandard().getIsCustomerPrimary());
			overseasCardActivationFlat.setTransactionStatus(overseasCardActivationRequest.getEvent().getStandard().getTransactionStatus());
			overseasCardActivationFlat.setTransactionType(overseasCardActivationRequest.getEvent().getStandard().getTransactionType());
			overseasCardActivationFlat.setRespStatusCode(overseasCardActivationRequest.getEvent().getStandard().getRespStatusCode());
			overseasCardActivationFlat.setRespStatusMsg(overseasCardActivationRequest.getEvent().getStandard().getRespStatusMsg());
		    overseasCardActivationFlat.setServerDateTime(overseasCardActivationRequest.getEvent().getStandard().getServerDateTime());
		    overseasCardActivationFlat.setTouchPoint(overseasCardActivationRequest.getEvent().getStandard().getTouchPoint());
		    overseasCardActivationFlat.setAssistedChannelUserID(overseasCardActivationRequest.getEvent().getStandard().getAssistedChannelUserID());
		}
		
	    if(overseasCardActivationRequest.getEvent().getMetadata()!=null){
	    	overseasCardActivationFlat.setOriginatorFunctionID(overseasCardActivationRequest.getEvent().getMetadata().getOriginatorFunctionID());
		    overseasCardActivationFlat.setOriginatorFunctionType(overseasCardActivationRequest.getEvent().getMetadata().getOriginatorFunctionType());
		    overseasCardActivationFlat.setOriginatorSubFunctionID(overseasCardActivationRequest.getEvent().getMetadata().getOriginatorSubFunctionID());
			overseasCardActivationFlat.setOriginatorFunctionSubType(overseasCardActivationRequest.getEvent().getMetadata().getOriginatorFunctionSubType());
	    }
	    
		if(overseasCardActivationRequest.getEvent().getCustomerAccess()!=null){
			overseasCardActivationFlat.setChannelSessionId(overseasCardActivationRequest.getEvent().getCustomerAccess().getChannelSessionId());
			overseasCardActivationFlat.setDeviceType(overseasCardActivationRequest.getEvent().getCustomerAccess().getDeviceType());
			overseasCardActivationFlat.setDeviceID(overseasCardActivationRequest.getEvent().getCustomerAccess().getDeviceID());
			overseasCardActivationFlat.setDeviceOS(overseasCardActivationRequest.getEvent().getCustomerAccess().getDeviceOS());
			overseasCardActivationFlat.setGeoLocLatitude(overseasCardActivationRequest.getEvent().getCustomerAccess().getGeoLocLatitude());
		    overseasCardActivationFlat.setGeoLocLongitude(overseasCardActivationRequest.getEvent().getCustomerAccess().getGeoLocLongitude());
		    overseasCardActivationFlat.setBrowserName(overseasCardActivationRequest.getEvent().getCustomerAccess().getBrowserName());
		    overseasCardActivationFlat.setClientIPAddress(overseasCardActivationRequest.getEvent().getCustomerAccess().getClientIPAddress());
		}
	    
		return overseasCardActivationFlat;
	}
	

	public PaymentAndTransferFlat getPaymentAndTransferFlat(PaymentAndTransferRequest paymentAndTransferRequest) {

		PaymentAndTransferFlat paymentAndTransferFlat = new PaymentAndTransferFlat();

		if(paymentAndTransferRequest.getEvent().getStandard()!=null){
			paymentAndTransferFlat.setCorrelationID(paymentAndTransferRequest.getEvent().getStandard().getCorrelationID());
			paymentAndTransferFlat.setEventID(paymentAndTransferRequest.getEvent().getStandard().getEventID());
			paymentAndTransferFlat.setEventUUID(paymentAndTransferRequest.getEvent().getStandard().getEventUUID());
			paymentAndTransferFlat.setEventProducer(paymentAndTransferRequest.getEvent().getStandard().getEventProducer());
			paymentAndTransferFlat.setEventTransmitter(paymentAndTransferRequest.getEvent().getStandard().getEventTransmitter());
			paymentAndTransferFlat.setCountryCode(paymentAndTransferRequest.getEvent().getStandard().getCountryCode());
			paymentAndTransferFlat.setBusinessID(paymentAndTransferRequest.getEvent().getStandard().getBusinessID());
			paymentAndTransferFlat.setUUID_UniqueID(paymentAndTransferRequest.getEvent().getStandard().getUUID_UniqueID());
			paymentAndTransferFlat.setESBUUID(paymentAndTransferRequest.getEvent().getStandard().getESBUUID());
			paymentAndTransferFlat.setBizFunctionID(paymentAndTransferRequest.getEvent().getStandard().getBizFunctionID());
			paymentAndTransferFlat.setCustomerID(paymentAndTransferRequest.getEvent().getStandard().getCustomerID());
			paymentAndTransferFlat.setCustomerType(paymentAndTransferRequest.getEvent().getStandard().getCustomerType());
			paymentAndTransferFlat.setCardNumber(paymentAndTransferRequest.getEvent().getStandard().getCardNumber());
			paymentAndTransferFlat.setAccountNumber(paymentAndTransferRequest.getEvent().getStandard().getAccountNumber());
			paymentAndTransferFlat.setIsCustomerPrimary(paymentAndTransferRequest.getEvent().getStandard().getIsCustomerPrimary());
			paymentAndTransferFlat.setTransactionStatus(paymentAndTransferRequest.getEvent().getStandard().getTransactionStatus());
			paymentAndTransferFlat.setTransactionType(paymentAndTransferRequest.getEvent().getStandard().getTransactionType());
			paymentAndTransferFlat.setRespStatusCode(paymentAndTransferRequest.getEvent().getStandard().getRespStatusCode());
			paymentAndTransferFlat.setRespStatusMsg(paymentAndTransferRequest.getEvent().getStandard().getRespStatusMsg());
			paymentAndTransferFlat.setServerDateTime(paymentAndTransferRequest.getEvent().getStandard().getServerDateTime());
			paymentAndTransferFlat.setTouchPoint(paymentAndTransferRequest.getEvent().getStandard().getTouchPoint());
			paymentAndTransferFlat.setAssistedChannelUserID(paymentAndTransferRequest.getEvent().getStandard().getAssistedChannelUserID());
		}

		if(paymentAndTransferRequest.getEvent().getMetadata()!=null){
			paymentAndTransferFlat.setOriginatorFunctionID(paymentAndTransferRequest.getEvent().getMetadata().getOriginatorFunctionID());
			paymentAndTransferFlat.setOriginatorFunctionType(paymentAndTransferRequest.getEvent().getMetadata().getOriginatorFunctionType());
			paymentAndTransferFlat.setOriginatorSubFunctionID(paymentAndTransferRequest.getEvent().getMetadata().getOriginatorSubFunctionID());
			paymentAndTransferFlat.setOriginatorFunctionSubType(paymentAndTransferRequest.getEvent().getMetadata().getOriginatorFunctionSubType());
		}

		if(paymentAndTransferRequest.getEvent().getCustomerAccess()!=null){
			paymentAndTransferFlat.setChannelSessionId(paymentAndTransferRequest.getEvent().getCustomerAccess().getChannelSessionId());
			paymentAndTransferFlat.setDeviceType(paymentAndTransferRequest.getEvent().getCustomerAccess().getDeviceType());
			paymentAndTransferFlat.setDeviceID(paymentAndTransferRequest.getEvent().getCustomerAccess().getDeviceID());
			paymentAndTransferFlat.setDeviceOS(paymentAndTransferRequest.getEvent().getCustomerAccess().getDeviceOS());
			paymentAndTransferFlat.setGeoLocLatitude(paymentAndTransferRequest.getEvent().getCustomerAccess().getGeoLocLatitude());
			paymentAndTransferFlat.setGeoLocLongitude(paymentAndTransferRequest.getEvent().getCustomerAccess().getGeoLocLongitude());
			paymentAndTransferFlat.setBrowserName(paymentAndTransferRequest.getEvent().getCustomerAccess().getBrowserName());
			paymentAndTransferFlat.setClientIPAddress(paymentAndTransferRequest.getEvent().getCustomerAccess().getClientIPAddress());
		}

		if(paymentAndTransferRequest.getEvent().getExtended()!=null){

			paymentAndTransferFlat.setSourceAccountNo(paymentAndTransferRequest.getEvent().getExtended().getSourceAccountNo());
			paymentAndTransferFlat.setDestinationAccountNo(paymentAndTransferRequest.getEvent().getExtended().getDestinationAccountNo());
			paymentAndTransferFlat.setPaymentAmount(paymentAndTransferRequest.getEvent().getExtended().getPaymentAmount());
			paymentAndTransferFlat.setCurrency(paymentAndTransferRequest.getEvent().getExtended().getCurrency());
		}

		return paymentAndTransferFlat;
	}

	public PINValidationFlat getPinValidationFlat(PINValidationRequest pinValidationRequest) {

		PINValidationFlat pinValidationFlat = new PINValidationFlat();

		if(pinValidationRequest.getEvent().getStandard()!=null){
			pinValidationFlat.setCorrelationID(pinValidationRequest.getEvent().getStandard().getCorrelationID());
			pinValidationFlat.setEventID(pinValidationRequest.getEvent().getStandard().getEventID());
			pinValidationFlat.setEventUUID(pinValidationRequest.getEvent().getStandard().getEventUUID());
			pinValidationFlat.setEventProducer(pinValidationRequest.getEvent().getStandard().getEventProducer());
			pinValidationFlat.setEventTransmitter(pinValidationRequest.getEvent().getStandard().getEventTransmitter());
			pinValidationFlat.setCountryCode(pinValidationRequest.getEvent().getStandard().getCountryCode());
			pinValidationFlat.setBusinessID(pinValidationRequest.getEvent().getStandard().getBusinessID());
			pinValidationFlat.setUUID_UniqueID(pinValidationRequest.getEvent().getStandard().getUUID_UniqueID());
			pinValidationFlat.setESBUUID(pinValidationRequest.getEvent().getStandard().getESBUUID());
			pinValidationFlat.setBizFunctionID(pinValidationRequest.getEvent().getStandard().getBizFunctionID());
			pinValidationFlat.setCustomerID(pinValidationRequest.getEvent().getStandard().getCustomerID());
			pinValidationFlat.setCustomerType(pinValidationRequest.getEvent().getStandard().getCustomerType());
			pinValidationFlat.setCardNumber(pinValidationRequest.getEvent().getStandard().getCardNumber());
			pinValidationFlat.setAccountNumber(pinValidationRequest.getEvent().getStandard().getAccountNumber());
			pinValidationFlat.setIsCustomerPrimary(pinValidationRequest.getEvent().getStandard().getIsCustomerPrimary());
			pinValidationFlat.setTransactionStatus(pinValidationRequest.getEvent().getStandard().getTransactionStatus());
			pinValidationFlat.setTransactionType(pinValidationRequest.getEvent().getStandard().getTransactionType());
			pinValidationFlat.setRespStatusCode(pinValidationRequest.getEvent().getStandard().getRespStatusCode());
			pinValidationFlat.setRespStatusMsg(pinValidationRequest.getEvent().getStandard().getRespStatusMsg());
			pinValidationFlat.setServerDateTime(pinValidationRequest.getEvent().getStandard().getServerDateTime());
			pinValidationFlat.setTouchPoint(pinValidationRequest.getEvent().getStandard().getTouchPoint());
			pinValidationFlat.setAssistedChannelUserID(pinValidationRequest.getEvent().getStandard().getAssistedChannelUserID());
		}

		if(pinValidationRequest.getEvent().getMetadata()!=null){
			pinValidationFlat.setOriginatorFunctionID(pinValidationRequest.getEvent().getMetadata().getOriginatorFunctionID());
			pinValidationFlat.setOriginatorFunctionType(pinValidationRequest.getEvent().getMetadata().getOriginatorFunctionType());
			pinValidationFlat.setOriginatorSubFunctionID(pinValidationRequest.getEvent().getMetadata().getOriginatorSubFunctionID());
			pinValidationFlat.setOriginatorFunctionSubType(pinValidationRequest.getEvent().getMetadata().getOriginatorFunctionSubType());
		}

		if(pinValidationRequest.getEvent().getCustomerAccess()!=null){
			pinValidationFlat.setChannelSessionId(pinValidationRequest.getEvent().getCustomerAccess().getChannelSessionId());
			pinValidationFlat.setDeviceType(pinValidationRequest.getEvent().getCustomerAccess().getDeviceType());
			pinValidationFlat.setDeviceID(pinValidationRequest.getEvent().getCustomerAccess().getDeviceID());
			pinValidationFlat.setDeviceOS(pinValidationRequest.getEvent().getCustomerAccess().getDeviceOS());
			pinValidationFlat.setGeoLocLatitude(pinValidationRequest.getEvent().getCustomerAccess().getGeoLocLatitude());
			pinValidationFlat.setGeoLocLongitude(pinValidationRequest.getEvent().getCustomerAccess().getGeoLocLongitude());
			pinValidationFlat.setBrowserName(pinValidationRequest.getEvent().getCustomerAccess().getBrowserName());
			pinValidationFlat.setClientIPAddress(pinValidationRequest.getEvent().getCustomerAccess().getClientIPAddress());
		}


		return pinValidationFlat;
	}

	public PreAuthFlat getPreAuthFlat(PreAuthRequest preAuthRequest) {

		PreAuthFlat preAuthFlat = new PreAuthFlat();

		if(preAuthRequest.getEvent().getStandard()!=null){
			preAuthFlat.setCorrelationID(preAuthRequest.getEvent().getStandard().getCorrelationID());
			preAuthFlat.setEventID(preAuthRequest.getEvent().getStandard().getEventID());
			preAuthFlat.setEventUUID(preAuthRequest.getEvent().getStandard().getEventUUID());
			preAuthFlat.setEventProducer(preAuthRequest.getEvent().getStandard().getEventProducer());
			preAuthFlat.setEventTransmitter(preAuthRequest.getEvent().getStandard().getEventTransmitter());
			preAuthFlat.setCountryCode(preAuthRequest.getEvent().getStandard().getCountryCode());
			preAuthFlat.setBusinessID(preAuthRequest.getEvent().getStandard().getBusinessID());
			preAuthFlat.setUUID_UniqueID(preAuthRequest.getEvent().getStandard().getUUID_UniqueID());
			preAuthFlat.setESBUUID(preAuthRequest.getEvent().getStandard().getESBUUID());
			preAuthFlat.setBizFunctionID(preAuthRequest.getEvent().getStandard().getBizFunctionID());
			preAuthFlat.setCustomerID(preAuthRequest.getEvent().getStandard().getCustomerID());
			preAuthFlat.setCustomerType(preAuthRequest.getEvent().getStandard().getCustomerType());
			preAuthFlat.setCardNumber(preAuthRequest.getEvent().getStandard().getCardNumber());
			preAuthFlat.setAccountNumber(preAuthRequest.getEvent().getStandard().getAccountNumber());
			preAuthFlat.setIsCustomerPrimary(preAuthRequest.getEvent().getStandard().getIsCustomerPrimary());
			preAuthFlat.setTransactionStatus(preAuthRequest.getEvent().getStandard().getTransactionStatus());
			preAuthFlat.setTransactionType(preAuthRequest.getEvent().getStandard().getTransactionType());
			preAuthFlat.setRespStatusCode(preAuthRequest.getEvent().getStandard().getRespStatusCode());
			preAuthFlat.setRespStatusMsg(preAuthRequest.getEvent().getStandard().getRespStatusMsg());
			preAuthFlat.setServerDateTime(preAuthRequest.getEvent().getStandard().getServerDateTime());
			preAuthFlat.setTouchPoint(preAuthRequest.getEvent().getStandard().getTouchPoint());
			preAuthFlat.setAssistedChannelUserID(preAuthRequest.getEvent().getStandard().getAssistedChannelUserID());
		}

		if(preAuthRequest.getEvent().getMetadata()!=null){
			preAuthFlat.setOriginatorFunctionID(preAuthRequest.getEvent().getMetadata().getOriginatorFunctionID());
			preAuthFlat.setOriginatorFunctionType(preAuthRequest.getEvent().getMetadata().getOriginatorFunctionType());
			preAuthFlat.setOriginatorSubFunctionID(preAuthRequest.getEvent().getMetadata().getOriginatorSubFunctionID());
			preAuthFlat.setOriginatorFunctionSubType(preAuthRequest.getEvent().getMetadata().getOriginatorFunctionSubType());
		}

		if(preAuthRequest.getEvent().getCustomerAccess()!=null){
			preAuthFlat.setChannelSessionId(preAuthRequest.getEvent().getCustomerAccess().getChannelSessionId());
			preAuthFlat.setDeviceType(preAuthRequest.getEvent().getCustomerAccess().getDeviceType());
			preAuthFlat.setDeviceID(preAuthRequest.getEvent().getCustomerAccess().getDeviceID());
			preAuthFlat.setDeviceOS(preAuthRequest.getEvent().getCustomerAccess().getDeviceOS());
			preAuthFlat.setGeoLocLatitude(preAuthRequest.getEvent().getCustomerAccess().getGeoLocLatitude());
			preAuthFlat.setGeoLocLongitude(preAuthRequest.getEvent().getCustomerAccess().getGeoLocLongitude());
			preAuthFlat.setBrowserName(preAuthRequest.getEvent().getCustomerAccess().getBrowserName());
			preAuthFlat.setClientIPAddress(preAuthRequest.getEvent().getCustomerAccess().getClientIPAddress());
		}


		return preAuthFlat;
	}

	public ReportLostStolenFlat getReportLostStolenFlat(ReportLostStolenRequest reportLostStolenRequest) {

		ReportLostStolenFlat reportLostStolenFlat = new ReportLostStolenFlat();

		if(reportLostStolenRequest.getEvent().getStandard()!=null){
			reportLostStolenFlat.setCorrelationID(reportLostStolenRequest.getEvent().getStandard().getCorrelationID());
			reportLostStolenFlat.setEventID(reportLostStolenRequest.getEvent().getStandard().getEventID());
			reportLostStolenFlat.setEventUUID(reportLostStolenRequest.getEvent().getStandard().getEventUUID());
			reportLostStolenFlat.setEventProducer(reportLostStolenRequest.getEvent().getStandard().getEventProducer());
			reportLostStolenFlat.setEventTransmitter(reportLostStolenRequest.getEvent().getStandard().getEventTransmitter());
			reportLostStolenFlat.setCountryCode(reportLostStolenRequest.getEvent().getStandard().getCountryCode());
			reportLostStolenFlat.setBusinessID(reportLostStolenRequest.getEvent().getStandard().getBusinessID());
			reportLostStolenFlat.setUUID_UniqueID(reportLostStolenRequest.getEvent().getStandard().getUUID_UniqueID());
			reportLostStolenFlat.setESBUUID(reportLostStolenRequest.getEvent().getStandard().getESBUUID());
			reportLostStolenFlat.setBizFunctionID(reportLostStolenRequest.getEvent().getStandard().getBizFunctionID());
			reportLostStolenFlat.setCustomerID(reportLostStolenRequest.getEvent().getStandard().getCustomerID());
			reportLostStolenFlat.setCustomerType(reportLostStolenRequest.getEvent().getStandard().getCustomerType());
			reportLostStolenFlat.setCardNumber(reportLostStolenRequest.getEvent().getStandard().getCardNumber());
			reportLostStolenFlat.setAccountNumber(reportLostStolenRequest.getEvent().getStandard().getAccountNumber());
			reportLostStolenFlat.setIsCustomerPrimary(reportLostStolenRequest.getEvent().getStandard().getIsCustomerPrimary());
			reportLostStolenFlat.setTransactionStatus(reportLostStolenRequest.getEvent().getStandard().getTransactionStatus());
			reportLostStolenFlat.setTransactionType(reportLostStolenRequest.getEvent().getStandard().getTransactionType());
			reportLostStolenFlat.setRespStatusCode(reportLostStolenRequest.getEvent().getStandard().getRespStatusCode());
			reportLostStolenFlat.setRespStatusMsg(reportLostStolenRequest.getEvent().getStandard().getRespStatusMsg());
			reportLostStolenFlat.setServerDateTime(reportLostStolenRequest.getEvent().getStandard().getServerDateTime());
			reportLostStolenFlat.setTouchPoint(reportLostStolenRequest.getEvent().getStandard().getTouchPoint());
			reportLostStolenFlat.setAssistedChannelUserID(reportLostStolenRequest.getEvent().getStandard().getAssistedChannelUserID());
		}

		if(reportLostStolenRequest.getEvent().getMetadata()!=null){
			reportLostStolenFlat.setOriginatorFunctionID(reportLostStolenRequest.getEvent().getMetadata().getOriginatorFunctionID());
			reportLostStolenFlat.setOriginatorFunctionType(reportLostStolenRequest.getEvent().getMetadata().getOriginatorFunctionType());
			reportLostStolenFlat.setOriginatorSubFunctionID(reportLostStolenRequest.getEvent().getMetadata().getOriginatorSubFunctionID());
			reportLostStolenFlat.setOriginatorFunctionSubType(reportLostStolenRequest.getEvent().getMetadata().getOriginatorFunctionSubType());
		}

		if(reportLostStolenRequest.getEvent().getCustomerAccess()!=null){
			reportLostStolenFlat.setChannelSessionId(reportLostStolenRequest.getEvent().getCustomerAccess().getChannelSessionId());
			reportLostStolenFlat.setDeviceType(reportLostStolenRequest.getEvent().getCustomerAccess().getDeviceType());
			reportLostStolenFlat.setDeviceID(reportLostStolenRequest.getEvent().getCustomerAccess().getDeviceID());
			reportLostStolenFlat.setDeviceOS(reportLostStolenRequest.getEvent().getCustomerAccess().getDeviceOS());
			reportLostStolenFlat.setGeoLocLatitude(reportLostStolenRequest.getEvent().getCustomerAccess().getGeoLocLatitude());
			reportLostStolenFlat.setGeoLocLongitude(reportLostStolenRequest.getEvent().getCustomerAccess().getGeoLocLongitude());
			reportLostStolenFlat.setBrowserName(reportLostStolenRequest.getEvent().getCustomerAccess().getBrowserName());
			reportLostStolenFlat.setClientIPAddress(reportLostStolenRequest.getEvent().getCustomerAccess().getClientIPAddress());
		}

		return reportLostStolenFlat;
	}

	public RewardRedemptionAccessFlat getRewardRedemptionAccessFlat(
			RewardRedemptionAccessRequest rewardRedemptionAccessRequest) {

		RewardRedemptionAccessFlat redemptionAccessFlat = new RewardRedemptionAccessFlat();

		if(rewardRedemptionAccessRequest.getEvent().getStandard()!=null){
			redemptionAccessFlat.setCorrelationID(rewardRedemptionAccessRequest.getEvent().getStandard().getCorrelationID());
			redemptionAccessFlat.setEventID(rewardRedemptionAccessRequest.getEvent().getStandard().getEventID());
			redemptionAccessFlat.setEventUUID(rewardRedemptionAccessRequest.getEvent().getStandard().getEventUUID());
			redemptionAccessFlat.setEventProducer(rewardRedemptionAccessRequest.getEvent().getStandard().getEventProducer());
			redemptionAccessFlat.setEventTransmitter(rewardRedemptionAccessRequest.getEvent().getStandard().getEventTransmitter());
			redemptionAccessFlat.setCountryCode(rewardRedemptionAccessRequest.getEvent().getStandard().getCountryCode());
			redemptionAccessFlat.setBusinessID(rewardRedemptionAccessRequest.getEvent().getStandard().getBusinessID());
			redemptionAccessFlat.setUUID_UniqueID(rewardRedemptionAccessRequest.getEvent().getStandard().getUUID_UniqueID());
			redemptionAccessFlat.setESBUUID(rewardRedemptionAccessRequest.getEvent().getStandard().getESBUUID());
			redemptionAccessFlat.setBizFunctionID(rewardRedemptionAccessRequest.getEvent().getStandard().getBizFunctionID());
			redemptionAccessFlat.setCustomerID(rewardRedemptionAccessRequest.getEvent().getStandard().getCustomerID());
			redemptionAccessFlat.setCustomerType(rewardRedemptionAccessRequest.getEvent().getStandard().getCustomerType());
			redemptionAccessFlat.setCardNumber(rewardRedemptionAccessRequest.getEvent().getStandard().getCardNumber());
			redemptionAccessFlat.setAccountNumber(rewardRedemptionAccessRequest.getEvent().getStandard().getAccountNumber());
			redemptionAccessFlat.setIsCustomerPrimary(rewardRedemptionAccessRequest.getEvent().getStandard().getIsCustomerPrimary());
			redemptionAccessFlat.setTransactionStatus(rewardRedemptionAccessRequest.getEvent().getStandard().getTransactionStatus());
			redemptionAccessFlat.setTransactionType(rewardRedemptionAccessRequest.getEvent().getStandard().getTransactionType());
			redemptionAccessFlat.setRespStatusCode(rewardRedemptionAccessRequest.getEvent().getStandard().getRespStatusCode());
			redemptionAccessFlat.setRespStatusMsg(rewardRedemptionAccessRequest.getEvent().getStandard().getRespStatusMsg());
			redemptionAccessFlat.setServerDateTime(rewardRedemptionAccessRequest.getEvent().getStandard().getServerDateTime());
			redemptionAccessFlat.setTouchPoint(rewardRedemptionAccessRequest.getEvent().getStandard().getTouchPoint());
			redemptionAccessFlat.setAssistedChannelUserID(rewardRedemptionAccessRequest.getEvent().getStandard().getAssistedChannelUserID());
		}

		if(rewardRedemptionAccessRequest.getEvent().getMetadata()!=null){
			redemptionAccessFlat.setOriginatorFunctionID(rewardRedemptionAccessRequest.getEvent().getMetadata().getOriginatorFunctionID());
			redemptionAccessFlat.setOriginatorFunctionType(rewardRedemptionAccessRequest.getEvent().getMetadata().getOriginatorFunctionType());
			redemptionAccessFlat.setOriginatorSubFunctionID(rewardRedemptionAccessRequest.getEvent().getMetadata().getOriginatorSubFunctionID());
			redemptionAccessFlat.setOriginatorFunctionSubType(rewardRedemptionAccessRequest.getEvent().getMetadata().getOriginatorFunctionSubType());
		}

		if(rewardRedemptionAccessRequest.getEvent().getCustomerAccess()!=null){
			redemptionAccessFlat.setChannelSessionId(rewardRedemptionAccessRequest.getEvent().getCustomerAccess().getChannelSessionId());
			redemptionAccessFlat.setDeviceType(rewardRedemptionAccessRequest.getEvent().getCustomerAccess().getDeviceType());
			redemptionAccessFlat.setDeviceID(rewardRedemptionAccessRequest.getEvent().getCustomerAccess().getDeviceID());
			redemptionAccessFlat.setDeviceOS(rewardRedemptionAccessRequest.getEvent().getCustomerAccess().getDeviceOS());
			redemptionAccessFlat.setGeoLocLatitude(rewardRedemptionAccessRequest.getEvent().getCustomerAccess().getGeoLocLatitude());
			redemptionAccessFlat.setGeoLocLongitude(rewardRedemptionAccessRequest.getEvent().getCustomerAccess().getGeoLocLongitude());
			redemptionAccessFlat.setBrowserName(rewardRedemptionAccessRequest.getEvent().getCustomerAccess().getBrowserName());
			redemptionAccessFlat.setClientIPAddress(rewardRedemptionAccessRequest.getEvent().getCustomerAccess().getClientIPAddress());
		}

		return redemptionAccessFlat;
	}

	public RewardRedemptionRequestFlat getRewardRedemptionRequestFlat(
			RewardRedemptionRequestRequest rewardRedemptionRequestRequest) {

		RewardRedemptionRequestFlat rewardRedemptionRequestFlat = new RewardRedemptionRequestFlat();

		if(rewardRedemptionRequestRequest.getEvent().getStandard()!=null){
			rewardRedemptionRequestFlat.setCorrelationID(rewardRedemptionRequestRequest.getEvent().getStandard().getCorrelationID());
			rewardRedemptionRequestFlat.setEventID(rewardRedemptionRequestRequest.getEvent().getStandard().getEventID());
			rewardRedemptionRequestFlat.setEventUUID(rewardRedemptionRequestRequest.getEvent().getStandard().getEventUUID());
			rewardRedemptionRequestFlat.setEventProducer(rewardRedemptionRequestRequest.getEvent().getStandard().getEventProducer());
			rewardRedemptionRequestFlat.setEventTransmitter(rewardRedemptionRequestRequest.getEvent().getStandard().getEventTransmitter());
			rewardRedemptionRequestFlat.setCountryCode(rewardRedemptionRequestRequest.getEvent().getStandard().getCountryCode());
			rewardRedemptionRequestFlat.setBusinessID(rewardRedemptionRequestRequest.getEvent().getStandard().getBusinessID());
			rewardRedemptionRequestFlat.setUUID_UniqueID(rewardRedemptionRequestRequest.getEvent().getStandard().getUUID_UniqueID());
			rewardRedemptionRequestFlat.setESBUUID(rewardRedemptionRequestRequest.getEvent().getStandard().getESBUUID());
			rewardRedemptionRequestFlat.setBizFunctionID(rewardRedemptionRequestRequest.getEvent().getStandard().getBizFunctionID());
			rewardRedemptionRequestFlat.setCustomerID(rewardRedemptionRequestRequest.getEvent().getStandard().getCustomerID());
			rewardRedemptionRequestFlat.setCustomerType(rewardRedemptionRequestRequest.getEvent().getStandard().getCustomerType());
			rewardRedemptionRequestFlat.setCardNumber(rewardRedemptionRequestRequest.getEvent().getStandard().getCardNumber());
			rewardRedemptionRequestFlat.setAccountNumber(rewardRedemptionRequestRequest.getEvent().getStandard().getAccountNumber());
			rewardRedemptionRequestFlat.setIsCustomerPrimary(rewardRedemptionRequestRequest.getEvent().getStandard().getIsCustomerPrimary());
			rewardRedemptionRequestFlat.setTransactionStatus(rewardRedemptionRequestRequest.getEvent().getStandard().getTransactionStatus());
			rewardRedemptionRequestFlat.setTransactionType(rewardRedemptionRequestRequest.getEvent().getStandard().getTransactionType());
			rewardRedemptionRequestFlat.setRespStatusCode(rewardRedemptionRequestRequest.getEvent().getStandard().getRespStatusCode());
			rewardRedemptionRequestFlat.setRespStatusMsg(rewardRedemptionRequestRequest.getEvent().getStandard().getRespStatusMsg());
			rewardRedemptionRequestFlat.setServerDateTime(rewardRedemptionRequestRequest.getEvent().getStandard().getServerDateTime());
			rewardRedemptionRequestFlat.setTouchPoint(rewardRedemptionRequestRequest.getEvent().getStandard().getTouchPoint());
			rewardRedemptionRequestFlat.setAssistedChannelUserID(rewardRedemptionRequestRequest.getEvent().getStandard().getAssistedChannelUserID());
		}

		if(rewardRedemptionRequestRequest.getEvent().getMetadata()!=null){
			rewardRedemptionRequestFlat.setOriginatorFunctionID(rewardRedemptionRequestRequest.getEvent().getMetadata().getOriginatorFunctionID());
			rewardRedemptionRequestFlat.setOriginatorFunctionType(rewardRedemptionRequestRequest.getEvent().getMetadata().getOriginatorFunctionType());
			rewardRedemptionRequestFlat.setOriginatorSubFunctionID(rewardRedemptionRequestRequest.getEvent().getMetadata().getOriginatorSubFunctionID());
			rewardRedemptionRequestFlat.setOriginatorFunctionSubType(rewardRedemptionRequestRequest.getEvent().getMetadata().getOriginatorFunctionSubType());
		}

		if(rewardRedemptionRequestRequest.getEvent().getCustomerAccess()!=null){
			rewardRedemptionRequestFlat.setChannelSessionId(rewardRedemptionRequestRequest.getEvent().getCustomerAccess().getChannelSessionId());
			rewardRedemptionRequestFlat.setDeviceType(rewardRedemptionRequestRequest.getEvent().getCustomerAccess().getDeviceType());
			rewardRedemptionRequestFlat.setDeviceID(rewardRedemptionRequestRequest.getEvent().getCustomerAccess().getDeviceID());
			rewardRedemptionRequestFlat.setDeviceOS(rewardRedemptionRequestRequest.getEvent().getCustomerAccess().getDeviceOS());
			rewardRedemptionRequestFlat.setGeoLocLatitude(rewardRedemptionRequestRequest.getEvent().getCustomerAccess().getGeoLocLatitude());
			rewardRedemptionRequestFlat.setGeoLocLongitude(rewardRedemptionRequestRequest.getEvent().getCustomerAccess().getGeoLocLongitude());
			rewardRedemptionRequestFlat.setBrowserName(rewardRedemptionRequestRequest.getEvent().getCustomerAccess().getBrowserName());
			rewardRedemptionRequestFlat.setClientIPAddress(rewardRedemptionRequestRequest.getEvent().getCustomerAccess().getClientIPAddress());
		}

		return rewardRedemptionRequestFlat;
	}

	public SDNMatchFoundFlat getSDNMatchFoundFlat(SDNMatchFoundRequest sdnMatchFoundRequest) {

		SDNMatchFoundFlat sdnMatchFoundFlat = new SDNMatchFoundFlat();

		if(sdnMatchFoundRequest.getEvent().getStandard()!=null){
			sdnMatchFoundFlat.setCorrelationID(sdnMatchFoundRequest.getEvent().getStandard().getCorrelationID());
			sdnMatchFoundFlat.setEventID(sdnMatchFoundRequest.getEvent().getStandard().getEventID());
			sdnMatchFoundFlat.setEventUUID(sdnMatchFoundRequest.getEvent().getStandard().getEventUUID());
			sdnMatchFoundFlat.setEventProducer(sdnMatchFoundRequest.getEvent().getStandard().getEventProducer());
			sdnMatchFoundFlat.setEventTransmitter(sdnMatchFoundRequest.getEvent().getStandard().getEventTransmitter());
			sdnMatchFoundFlat.setCountryCode(sdnMatchFoundRequest.getEvent().getStandard().getCountryCode());
			sdnMatchFoundFlat.setBusinessID(sdnMatchFoundRequest.getEvent().getStandard().getBusinessID());
			sdnMatchFoundFlat.setUUID_UniqueID(sdnMatchFoundRequest.getEvent().getStandard().getUUID_UniqueID());
			sdnMatchFoundFlat.setESBUUID(sdnMatchFoundRequest.getEvent().getStandard().getESBUUID());
			sdnMatchFoundFlat.setBizFunctionID(sdnMatchFoundRequest.getEvent().getStandard().getBizFunctionID());
			sdnMatchFoundFlat.setCustomerID(sdnMatchFoundRequest.getEvent().getStandard().getCustomerID());
			sdnMatchFoundFlat.setCustomerType(sdnMatchFoundRequest.getEvent().getStandard().getCustomerType());
			sdnMatchFoundFlat.setCardNumber(sdnMatchFoundRequest.getEvent().getStandard().getCardNumber());
			sdnMatchFoundFlat.setAccountNumber(sdnMatchFoundRequest.getEvent().getStandard().getAccountNumber());
			sdnMatchFoundFlat.setIsCustomerPrimary(sdnMatchFoundRequest.getEvent().getStandard().getIsCustomerPrimary());
			sdnMatchFoundFlat.setTransactionStatus(sdnMatchFoundRequest.getEvent().getStandard().getTransactionStatus());
			sdnMatchFoundFlat.setTransactionType(sdnMatchFoundRequest.getEvent().getStandard().getTransactionType());
			sdnMatchFoundFlat.setRespStatusCode(sdnMatchFoundRequest.getEvent().getStandard().getRespStatusCode());
			sdnMatchFoundFlat.setRespStatusMsg(sdnMatchFoundRequest.getEvent().getStandard().getRespStatusMsg());
			sdnMatchFoundFlat.setServerDateTime(sdnMatchFoundRequest.getEvent().getStandard().getServerDateTime());
			sdnMatchFoundFlat.setTouchPoint(sdnMatchFoundRequest.getEvent().getStandard().getTouchPoint());
			sdnMatchFoundFlat.setAssistedChannelUserID(sdnMatchFoundRequest.getEvent().getStandard().getAssistedChannelUserID());
		}

		if(sdnMatchFoundRequest.getEvent().getMetadata()!=null){
			sdnMatchFoundFlat.setOriginatorFunctionID(sdnMatchFoundRequest.getEvent().getMetadata().getOriginatorFunctionID());
			sdnMatchFoundFlat.setOriginatorFunctionType(sdnMatchFoundRequest.getEvent().getMetadata().getOriginatorFunctionType());
			sdnMatchFoundFlat.setOriginatorSubFunctionID(sdnMatchFoundRequest.getEvent().getMetadata().getOriginatorSubFunctionID());
			sdnMatchFoundFlat.setOriginatorFunctionSubType(sdnMatchFoundRequest.getEvent().getMetadata().getOriginatorFunctionSubType());
		}

		if(sdnMatchFoundRequest.getEvent().getCustomerAccess()!=null){
			sdnMatchFoundFlat.setChannelSessionId(sdnMatchFoundRequest.getEvent().getCustomerAccess().getChannelSessionId());
			sdnMatchFoundFlat.setDeviceType(sdnMatchFoundRequest.getEvent().getCustomerAccess().getDeviceType());
			sdnMatchFoundFlat.setDeviceID(sdnMatchFoundRequest.getEvent().getCustomerAccess().getDeviceID());
			sdnMatchFoundFlat.setDeviceOS(sdnMatchFoundRequest.getEvent().getCustomerAccess().getDeviceOS());
			sdnMatchFoundFlat.setGeoLocLatitude(sdnMatchFoundRequest.getEvent().getCustomerAccess().getGeoLocLatitude());
			sdnMatchFoundFlat.setGeoLocLongitude(sdnMatchFoundRequest.getEvent().getCustomerAccess().getGeoLocLongitude());
			sdnMatchFoundFlat.setBrowserName(sdnMatchFoundRequest.getEvent().getCustomerAccess().getBrowserName());
			sdnMatchFoundFlat.setClientIPAddress(sdnMatchFoundRequest.getEvent().getCustomerAccess().getClientIPAddress());
		}

		if(sdnMatchFoundRequest.getEvent().getExtended()!=null){

			sdnMatchFoundFlat.setPayeeName(sdnMatchFoundRequest.getEvent().getExtended().getPayeeName());
			sdnMatchFoundFlat.setDestinationAccountNo(sdnMatchFoundRequest.getEvent().getExtended().getDestinationAccountNo());
			sdnMatchFoundFlat.setRemarks(sdnMatchFoundRequest.getEvent().getExtended().getRemarks());
		}

		return sdnMatchFoundFlat;
	}

	public SDNMatchResolvedFlat getSDNMatchResolvedFlat(SDNMatchResolvedRequest sdnMatchResolvedRequest) {

		SDNMatchResolvedFlat sdnMatchResolvedFlat = new SDNMatchResolvedFlat();

		if(sdnMatchResolvedRequest.getEvent().getStandard()!=null){
			sdnMatchResolvedFlat.setCorrelationID(sdnMatchResolvedRequest.getEvent().getStandard().getCorrelationID());
			sdnMatchResolvedFlat.setEventID(sdnMatchResolvedRequest.getEvent().getStandard().getEventID());
			sdnMatchResolvedFlat.setEventUUID(sdnMatchResolvedRequest.getEvent().getStandard().getEventUUID());
			sdnMatchResolvedFlat.setEventProducer(sdnMatchResolvedRequest.getEvent().getStandard().getEventProducer());
			sdnMatchResolvedFlat.setEventTransmitter(sdnMatchResolvedRequest.getEvent().getStandard().getEventTransmitter());
			sdnMatchResolvedFlat.setCountryCode(sdnMatchResolvedRequest.getEvent().getStandard().getCountryCode());
			sdnMatchResolvedFlat.setBusinessID(sdnMatchResolvedRequest.getEvent().getStandard().getBusinessID());
			sdnMatchResolvedFlat.setUUID_UniqueID(sdnMatchResolvedRequest.getEvent().getStandard().getUUID_UniqueID());
			sdnMatchResolvedFlat.setESBUUID(sdnMatchResolvedRequest.getEvent().getStandard().getESBUUID());
			sdnMatchResolvedFlat.setBizFunctionID(sdnMatchResolvedRequest.getEvent().getStandard().getBizFunctionID());
			sdnMatchResolvedFlat.setCustomerID(sdnMatchResolvedRequest.getEvent().getStandard().getCustomerID());
			sdnMatchResolvedFlat.setCustomerType(sdnMatchResolvedRequest.getEvent().getStandard().getCustomerType());
			sdnMatchResolvedFlat.setCardNumber(sdnMatchResolvedRequest.getEvent().getStandard().getCardNumber());
			sdnMatchResolvedFlat.setAccountNumber(sdnMatchResolvedRequest.getEvent().getStandard().getAccountNumber());
			sdnMatchResolvedFlat.setIsCustomerPrimary(sdnMatchResolvedRequest.getEvent().getStandard().getIsCustomerPrimary());
			sdnMatchResolvedFlat.setTransactionStatus(sdnMatchResolvedRequest.getEvent().getStandard().getTransactionStatus());
			sdnMatchResolvedFlat.setTransactionType(sdnMatchResolvedRequest.getEvent().getStandard().getTransactionType());
			sdnMatchResolvedFlat.setRespStatusCode(sdnMatchResolvedRequest.getEvent().getStandard().getRespStatusCode());
			sdnMatchResolvedFlat.setRespStatusMsg(sdnMatchResolvedRequest.getEvent().getStandard().getRespStatusMsg());
			sdnMatchResolvedFlat.setServerDateTime(sdnMatchResolvedRequest.getEvent().getStandard().getServerDateTime());
			sdnMatchResolvedFlat.setTouchPoint(sdnMatchResolvedRequest.getEvent().getStandard().getTouchPoint());
			sdnMatchResolvedFlat.setAssistedChannelUserID(sdnMatchResolvedRequest.getEvent().getStandard().getAssistedChannelUserID());
		}

		if(sdnMatchResolvedRequest.getEvent().getMetadata()!=null){
			sdnMatchResolvedFlat.setOriginatorFunctionID(sdnMatchResolvedRequest.getEvent().getMetadata().getOriginatorFunctionID());
			sdnMatchResolvedFlat.setOriginatorFunctionType(sdnMatchResolvedRequest.getEvent().getMetadata().getOriginatorFunctionType());
			sdnMatchResolvedFlat.setOriginatorSubFunctionID(sdnMatchResolvedRequest.getEvent().getMetadata().getOriginatorSubFunctionID());
			sdnMatchResolvedFlat.setOriginatorFunctionSubType(sdnMatchResolvedRequest.getEvent().getMetadata().getOriginatorFunctionSubType());
		}

		if(sdnMatchResolvedRequest.getEvent().getCustomerAccess()!=null){
			sdnMatchResolvedFlat.setChannelSessionId(sdnMatchResolvedRequest.getEvent().getCustomerAccess().getChannelSessionId());
			sdnMatchResolvedFlat.setDeviceType(sdnMatchResolvedRequest.getEvent().getCustomerAccess().getDeviceType());
			sdnMatchResolvedFlat.setDeviceID(sdnMatchResolvedRequest.getEvent().getCustomerAccess().getDeviceID());
			sdnMatchResolvedFlat.setDeviceOS(sdnMatchResolvedRequest.getEvent().getCustomerAccess().getDeviceOS());
			sdnMatchResolvedFlat.setGeoLocLatitude(sdnMatchResolvedRequest.getEvent().getCustomerAccess().getGeoLocLatitude());
			sdnMatchResolvedFlat.setGeoLocLongitude(sdnMatchResolvedRequest.getEvent().getCustomerAccess().getGeoLocLongitude());
			sdnMatchResolvedFlat.setBrowserName(sdnMatchResolvedRequest.getEvent().getCustomerAccess().getBrowserName());
			sdnMatchResolvedFlat.setClientIPAddress(sdnMatchResolvedRequest.getEvent().getCustomerAccess().getClientIPAddress());
		}

		return sdnMatchResolvedFlat;
	}

	public ServiceRequestFlat getServiceRequestFlat(ServiceRequestRequest serviceRequestRequest) {

		ServiceRequestFlat serviceRequestFlat = new ServiceRequestFlat();

		if(serviceRequestRequest.getEvent().getStandard()!=null){
			serviceRequestFlat.setCorrelationID(serviceRequestRequest.getEvent().getStandard().getCorrelationID());
			serviceRequestFlat.setEventID(serviceRequestRequest.getEvent().getStandard().getEventID());
			serviceRequestFlat.setEventUUID(serviceRequestRequest.getEvent().getStandard().getEventUUID());
			serviceRequestFlat.setEventProducer(serviceRequestRequest.getEvent().getStandard().getEventProducer());
			serviceRequestFlat.setEventTransmitter(serviceRequestRequest.getEvent().getStandard().getEventTransmitter());
			serviceRequestFlat.setCountryCode(serviceRequestRequest.getEvent().getStandard().getCountryCode());
			serviceRequestFlat.setBusinessID(serviceRequestRequest.getEvent().getStandard().getBusinessID());
			serviceRequestFlat.setUUID_UniqueID(serviceRequestRequest.getEvent().getStandard().getUUID_UniqueID());
			serviceRequestFlat.setESBUUID(serviceRequestRequest.getEvent().getStandard().getESBUUID());
			serviceRequestFlat.setBizFunctionID(serviceRequestRequest.getEvent().getStandard().getBizFunctionID());
			serviceRequestFlat.setCustomerID(serviceRequestRequest.getEvent().getStandard().getCustomerID());
			serviceRequestFlat.setCustomerType(serviceRequestRequest.getEvent().getStandard().getCustomerType());
			serviceRequestFlat.setCardNumber(serviceRequestRequest.getEvent().getStandard().getCardNumber());
			serviceRequestFlat.setAccountNumber(serviceRequestRequest.getEvent().getStandard().getAccountNumber());
			serviceRequestFlat.setIsCustomerPrimary(serviceRequestRequest.getEvent().getStandard().getIsCustomerPrimary());
			serviceRequestFlat.setTransactionStatus(serviceRequestRequest.getEvent().getStandard().getTransactionStatus());
			serviceRequestFlat.setTransactionType(serviceRequestRequest.getEvent().getStandard().getTransactionType());
			serviceRequestFlat.setRespStatusCode(serviceRequestRequest.getEvent().getStandard().getRespStatusCode());
			serviceRequestFlat.setRespStatusMsg(serviceRequestRequest.getEvent().getStandard().getRespStatusMsg());
			serviceRequestFlat.setServerDateTime(serviceRequestRequest.getEvent().getStandard().getServerDateTime());
			serviceRequestFlat.setTouchPoint(serviceRequestRequest.getEvent().getStandard().getTouchPoint());
			serviceRequestFlat.setAssistedChannelUserID(serviceRequestRequest.getEvent().getStandard().getAssistedChannelUserID());
		}

		if(serviceRequestRequest.getEvent().getMetadata()!=null){
			serviceRequestFlat.setOriginatorFunctionID(serviceRequestRequest.getEvent().getMetadata().getOriginatorFunctionID());
			serviceRequestFlat.setOriginatorFunctionType(serviceRequestRequest.getEvent().getMetadata().getOriginatorFunctionType());
			serviceRequestFlat.setOriginatorSubFunctionID(serviceRequestRequest.getEvent().getMetadata().getOriginatorSubFunctionID());
			serviceRequestFlat.setOriginatorFunctionSubType(serviceRequestRequest.getEvent().getMetadata().getOriginatorFunctionSubType());
		}

		if(serviceRequestRequest.getEvent().getCustomerAccess()!=null){
			serviceRequestFlat.setChannelSessionId(serviceRequestRequest.getEvent().getCustomerAccess().getChannelSessionId());
			serviceRequestFlat.setDeviceType(serviceRequestRequest.getEvent().getCustomerAccess().getDeviceType());
			serviceRequestFlat.setDeviceID(serviceRequestRequest.getEvent().getCustomerAccess().getDeviceID());
			serviceRequestFlat.setDeviceOS(serviceRequestRequest.getEvent().getCustomerAccess().getDeviceOS());
			serviceRequestFlat.setGeoLocLatitude(serviceRequestRequest.getEvent().getCustomerAccess().getGeoLocLatitude());
			serviceRequestFlat.setGeoLocLongitude(serviceRequestRequest.getEvent().getCustomerAccess().getGeoLocLongitude());
			serviceRequestFlat.setBrowserName(serviceRequestRequest.getEvent().getCustomerAccess().getBrowserName());
			serviceRequestFlat.setClientIPAddress(serviceRequestRequest.getEvent().getCustomerAccess().getClientIPAddress());
		}

		if(serviceRequestRequest.getEvent().getExtended()!=null){

			serviceRequestFlat.setSubject(serviceRequestRequest.getEvent().getExtended().getSubject());
			serviceRequestFlat.setSubject(serviceRequestRequest.getEvent().getExtended().getESMSUDPprocesscode());
			serviceRequestFlat.setSubject(serviceRequestRequest.getEvent().getExtended().getMISGroupDescription());
			serviceRequestFlat.setSubject(serviceRequestRequest.getEvent().getExtended().getMISTypeDescription());
			
		}
		
		return serviceRequestFlat;
	}

	public SMSEmailOffersFlat getSMSEmailOffersFlat(SMSEmailOffersRequest smsEmailOffersRequest) {

		SMSEmailOffersFlat smsEmailOffersFlat = new SMSEmailOffersFlat();

		if(smsEmailOffersRequest.getEvent().getStandard()!=null){
			smsEmailOffersFlat.setCorrelationID(smsEmailOffersRequest.getEvent().getStandard().getCorrelationID());
			smsEmailOffersFlat.setEventID(smsEmailOffersRequest.getEvent().getStandard().getEventID());
			smsEmailOffersFlat.setEventUUID(smsEmailOffersRequest.getEvent().getStandard().getEventUUID());
			smsEmailOffersFlat.setEventProducer(smsEmailOffersRequest.getEvent().getStandard().getEventProducer());
			smsEmailOffersFlat.setEventTransmitter(smsEmailOffersRequest.getEvent().getStandard().getEventTransmitter());
			smsEmailOffersFlat.setCountryCode(smsEmailOffersRequest.getEvent().getStandard().getCountryCode());
			smsEmailOffersFlat.setBusinessID(smsEmailOffersRequest.getEvent().getStandard().getBusinessID());
			smsEmailOffersFlat.setUUID_UniqueID(smsEmailOffersRequest.getEvent().getStandard().getUUID_UniqueID());
			smsEmailOffersFlat.setESBUUID(smsEmailOffersRequest.getEvent().getStandard().getESBUUID());
			smsEmailOffersFlat.setBizFunctionID(smsEmailOffersRequest.getEvent().getStandard().getBizFunctionID());
			smsEmailOffersFlat.setCustomerID(smsEmailOffersRequest.getEvent().getStandard().getCustomerID());
			smsEmailOffersFlat.setCustomerType(smsEmailOffersRequest.getEvent().getStandard().getCustomerType());
			smsEmailOffersFlat.setCardNumber(smsEmailOffersRequest.getEvent().getStandard().getCardNumber());
			smsEmailOffersFlat.setAccountNumber(smsEmailOffersRequest.getEvent().getStandard().getAccountNumber());
			smsEmailOffersFlat.setIsCustomerPrimary(smsEmailOffersRequest.getEvent().getStandard().getIsCustomerPrimary());
			smsEmailOffersFlat.setTransactionStatus(smsEmailOffersRequest.getEvent().getStandard().getTransactionStatus());
			smsEmailOffersFlat.setTransactionType(smsEmailOffersRequest.getEvent().getStandard().getTransactionType());
			smsEmailOffersFlat.setRespStatusCode(smsEmailOffersRequest.getEvent().getStandard().getRespStatusCode());
			smsEmailOffersFlat.setRespStatusMsg(smsEmailOffersRequest.getEvent().getStandard().getRespStatusMsg());
			smsEmailOffersFlat.setServerDateTime(smsEmailOffersRequest.getEvent().getStandard().getServerDateTime());
			smsEmailOffersFlat.setTouchPoint(smsEmailOffersRequest.getEvent().getStandard().getTouchPoint());
			smsEmailOffersFlat.setAssistedChannelUserID(smsEmailOffersRequest.getEvent().getStandard().getAssistedChannelUserID());
		}

		if(smsEmailOffersRequest.getEvent().getMetadata()!=null){
			smsEmailOffersFlat.setOriginatorFunctionID(smsEmailOffersRequest.getEvent().getMetadata().getOriginatorFunctionID());
			smsEmailOffersFlat.setOriginatorFunctionType(smsEmailOffersRequest.getEvent().getMetadata().getOriginatorFunctionType());
			smsEmailOffersFlat.setOriginatorSubFunctionID(smsEmailOffersRequest.getEvent().getMetadata().getOriginatorSubFunctionID());
			smsEmailOffersFlat.setOriginatorFunctionSubType(smsEmailOffersRequest.getEvent().getMetadata().getOriginatorFunctionSubType());
		}

		if(smsEmailOffersRequest.getEvent().getCustomerAccess()!=null){
			smsEmailOffersFlat.setChannelSessionId(smsEmailOffersRequest.getEvent().getCustomerAccess().getChannelSessionId());
			smsEmailOffersFlat.setDeviceType(smsEmailOffersRequest.getEvent().getCustomerAccess().getDeviceType());
			smsEmailOffersFlat.setDeviceID(smsEmailOffersRequest.getEvent().getCustomerAccess().getDeviceID());
			smsEmailOffersFlat.setDeviceOS(smsEmailOffersRequest.getEvent().getCustomerAccess().getDeviceOS());
			smsEmailOffersFlat.setGeoLocLatitude(smsEmailOffersRequest.getEvent().getCustomerAccess().getGeoLocLatitude());
			smsEmailOffersFlat.setGeoLocLongitude(smsEmailOffersRequest.getEvent().getCustomerAccess().getGeoLocLongitude());
			smsEmailOffersFlat.setBrowserName(smsEmailOffersRequest.getEvent().getCustomerAccess().getBrowserName());
			smsEmailOffersFlat.setClientIPAddress(smsEmailOffersRequest.getEvent().getCustomerAccess().getClientIPAddress());
		}

		return smsEmailOffersFlat;
	}

	public TPINCreateResetChangeIssuanceFlat getTPINCreateResetChangeIssuanceFlat(
			TPINCreateResetChangeIssuanceRequest tpinCreateResetChangeIssuanceRequest) {

		TPINCreateResetChangeIssuanceFlat tpinCreateResetChangeIssuanceFlat = new TPINCreateResetChangeIssuanceFlat();

		if(tpinCreateResetChangeIssuanceRequest.getEvent().getStandard()!=null){
			tpinCreateResetChangeIssuanceFlat.setCorrelationID(tpinCreateResetChangeIssuanceRequest.getEvent().getStandard().getCorrelationID());
			tpinCreateResetChangeIssuanceFlat.setEventID(tpinCreateResetChangeIssuanceRequest.getEvent().getStandard().getEventID());
			tpinCreateResetChangeIssuanceFlat.setEventUUID(tpinCreateResetChangeIssuanceRequest.getEvent().getStandard().getEventUUID());
			tpinCreateResetChangeIssuanceFlat.setEventProducer(tpinCreateResetChangeIssuanceRequest.getEvent().getStandard().getEventProducer());
			tpinCreateResetChangeIssuanceFlat.setEventTransmitter(tpinCreateResetChangeIssuanceRequest.getEvent().getStandard().getEventTransmitter());
			tpinCreateResetChangeIssuanceFlat.setCountryCode(tpinCreateResetChangeIssuanceRequest.getEvent().getStandard().getCountryCode());
			tpinCreateResetChangeIssuanceFlat.setBusinessID(tpinCreateResetChangeIssuanceRequest.getEvent().getStandard().getBusinessID());
			tpinCreateResetChangeIssuanceFlat.setUUID_UniqueID(tpinCreateResetChangeIssuanceRequest.getEvent().getStandard().getUUID_UniqueID());
			tpinCreateResetChangeIssuanceFlat.setESBUUID(tpinCreateResetChangeIssuanceRequest.getEvent().getStandard().getESBUUID());
			tpinCreateResetChangeIssuanceFlat.setBizFunctionID(tpinCreateResetChangeIssuanceRequest.getEvent().getStandard().getBizFunctionID());
			tpinCreateResetChangeIssuanceFlat.setCustomerID(tpinCreateResetChangeIssuanceRequest.getEvent().getStandard().getCustomerID());
			tpinCreateResetChangeIssuanceFlat.setCustomerType(tpinCreateResetChangeIssuanceRequest.getEvent().getStandard().getCustomerType());
			tpinCreateResetChangeIssuanceFlat.setCardNumber(tpinCreateResetChangeIssuanceRequest.getEvent().getStandard().getCardNumber());
			tpinCreateResetChangeIssuanceFlat.setAccountNumber(tpinCreateResetChangeIssuanceRequest.getEvent().getStandard().getAccountNumber());
			tpinCreateResetChangeIssuanceFlat.setIsCustomerPrimary(tpinCreateResetChangeIssuanceRequest.getEvent().getStandard().getIsCustomerPrimary());
			tpinCreateResetChangeIssuanceFlat.setTransactionStatus(tpinCreateResetChangeIssuanceRequest.getEvent().getStandard().getTransactionStatus());
			tpinCreateResetChangeIssuanceFlat.setTransactionType(tpinCreateResetChangeIssuanceRequest.getEvent().getStandard().getTransactionType());
			tpinCreateResetChangeIssuanceFlat.setRespStatusCode(tpinCreateResetChangeIssuanceRequest.getEvent().getStandard().getRespStatusCode());
			tpinCreateResetChangeIssuanceFlat.setRespStatusMsg(tpinCreateResetChangeIssuanceRequest.getEvent().getStandard().getRespStatusMsg());
			tpinCreateResetChangeIssuanceFlat.setServerDateTime(tpinCreateResetChangeIssuanceRequest.getEvent().getStandard().getServerDateTime());
			tpinCreateResetChangeIssuanceFlat.setTouchPoint(tpinCreateResetChangeIssuanceRequest.getEvent().getStandard().getTouchPoint());
			tpinCreateResetChangeIssuanceFlat.setAssistedChannelUserID(tpinCreateResetChangeIssuanceRequest.getEvent().getStandard().getAssistedChannelUserID());
		}

		if(tpinCreateResetChangeIssuanceRequest.getEvent().getMetadata()!=null){
			tpinCreateResetChangeIssuanceFlat.setOriginatorFunctionID(tpinCreateResetChangeIssuanceRequest.getEvent().getMetadata().getOriginatorFunctionID());
			tpinCreateResetChangeIssuanceFlat.setOriginatorFunctionType(tpinCreateResetChangeIssuanceRequest.getEvent().getMetadata().getOriginatorFunctionType());
			tpinCreateResetChangeIssuanceFlat.setOriginatorSubFunctionID(tpinCreateResetChangeIssuanceRequest.getEvent().getMetadata().getOriginatorSubFunctionID());
			tpinCreateResetChangeIssuanceFlat.setOriginatorFunctionSubType(tpinCreateResetChangeIssuanceRequest.getEvent().getMetadata().getOriginatorFunctionSubType());
		}

		if(tpinCreateResetChangeIssuanceRequest.getEvent().getCustomerAccess()!=null){
			tpinCreateResetChangeIssuanceFlat.setChannelSessionId(tpinCreateResetChangeIssuanceRequest.getEvent().getCustomerAccess().getChannelSessionId());
			tpinCreateResetChangeIssuanceFlat.setDeviceType(tpinCreateResetChangeIssuanceRequest.getEvent().getCustomerAccess().getDeviceType());
			tpinCreateResetChangeIssuanceFlat.setDeviceID(tpinCreateResetChangeIssuanceRequest.getEvent().getCustomerAccess().getDeviceID());
			tpinCreateResetChangeIssuanceFlat.setDeviceOS(tpinCreateResetChangeIssuanceRequest.getEvent().getCustomerAccess().getDeviceOS());
			tpinCreateResetChangeIssuanceFlat.setGeoLocLatitude(tpinCreateResetChangeIssuanceRequest.getEvent().getCustomerAccess().getGeoLocLatitude());
			tpinCreateResetChangeIssuanceFlat.setGeoLocLongitude(tpinCreateResetChangeIssuanceRequest.getEvent().getCustomerAccess().getGeoLocLongitude());
			tpinCreateResetChangeIssuanceFlat.setBrowserName(tpinCreateResetChangeIssuanceRequest.getEvent().getCustomerAccess().getBrowserName());
			tpinCreateResetChangeIssuanceFlat.setClientIPAddress(tpinCreateResetChangeIssuanceRequest.getEvent().getCustomerAccess().getClientIPAddress());
		}

		return tpinCreateResetChangeIssuanceFlat;
	}

	public ViewTransactionsHistoryFlat getViewTransactionsHistoryFlat(
			ViewTransactionsHistoryRequest viewTransactionsHistoryRequest) {

		ViewTransactionsHistoryFlat viewTransactionsHistoryFlat = new ViewTransactionsHistoryFlat();

		if(viewTransactionsHistoryRequest.getEvent().getStandard()!=null){
			viewTransactionsHistoryFlat.setCorrelationID(viewTransactionsHistoryRequest.getEvent().getStandard().getCorrelationID());
			viewTransactionsHistoryFlat.setEventID(viewTransactionsHistoryRequest.getEvent().getStandard().getEventID());
			viewTransactionsHistoryFlat.setEventUUID(viewTransactionsHistoryRequest.getEvent().getStandard().getEventUUID());
			viewTransactionsHistoryFlat.setEventProducer(viewTransactionsHistoryRequest.getEvent().getStandard().getEventProducer());
			viewTransactionsHistoryFlat.setEventTransmitter(viewTransactionsHistoryRequest.getEvent().getStandard().getEventTransmitter());
			viewTransactionsHistoryFlat.setCountryCode(viewTransactionsHistoryRequest.getEvent().getStandard().getCountryCode());
			viewTransactionsHistoryFlat.setBusinessID(viewTransactionsHistoryRequest.getEvent().getStandard().getBusinessID());
			viewTransactionsHistoryFlat.setUUID_UniqueID(viewTransactionsHistoryRequest.getEvent().getStandard().getUUID_UniqueID());
			viewTransactionsHistoryFlat.setESBUUID(viewTransactionsHistoryRequest.getEvent().getStandard().getESBUUID());
			viewTransactionsHistoryFlat.setBizFunctionID(viewTransactionsHistoryRequest.getEvent().getStandard().getBizFunctionID());
			viewTransactionsHistoryFlat.setCustomerID(viewTransactionsHistoryRequest.getEvent().getStandard().getCustomerID());
			viewTransactionsHistoryFlat.setCustomerType(viewTransactionsHistoryRequest.getEvent().getStandard().getCustomerType());
			viewTransactionsHistoryFlat.setCardNumber(viewTransactionsHistoryRequest.getEvent().getStandard().getCardNumber());
			viewTransactionsHistoryFlat.setAccountNumber(viewTransactionsHistoryRequest.getEvent().getStandard().getAccountNumber());
			viewTransactionsHistoryFlat.setIsCustomerPrimary(viewTransactionsHistoryRequest.getEvent().getStandard().getIsCustomerPrimary());
			viewTransactionsHistoryFlat.setTransactionStatus(viewTransactionsHistoryRequest.getEvent().getStandard().getTransactionStatus());
			viewTransactionsHistoryFlat.setTransactionType(viewTransactionsHistoryRequest.getEvent().getStandard().getTransactionType());
			viewTransactionsHistoryFlat.setRespStatusCode(viewTransactionsHistoryRequest.getEvent().getStandard().getRespStatusCode());
			viewTransactionsHistoryFlat.setRespStatusMsg(viewTransactionsHistoryRequest.getEvent().getStandard().getRespStatusMsg());
			viewTransactionsHistoryFlat.setServerDateTime(viewTransactionsHistoryRequest.getEvent().getStandard().getServerDateTime());
			viewTransactionsHistoryFlat.setTouchPoint(viewTransactionsHistoryRequest.getEvent().getStandard().getTouchPoint());
			viewTransactionsHistoryFlat.setAssistedChannelUserID(viewTransactionsHistoryRequest.getEvent().getStandard().getAssistedChannelUserID());
		}

		if(viewTransactionsHistoryRequest.getEvent().getMetadata()!=null){
			viewTransactionsHistoryFlat.setOriginatorFunctionID(viewTransactionsHistoryRequest.getEvent().getMetadata().getOriginatorFunctionID());
			viewTransactionsHistoryFlat.setOriginatorFunctionType(viewTransactionsHistoryRequest.getEvent().getMetadata().getOriginatorFunctionType());
			viewTransactionsHistoryFlat.setOriginatorSubFunctionID(viewTransactionsHistoryRequest.getEvent().getMetadata().getOriginatorSubFunctionID());
			viewTransactionsHistoryFlat.setOriginatorFunctionSubType(viewTransactionsHistoryRequest.getEvent().getMetadata().getOriginatorFunctionSubType());
		}

		if(viewTransactionsHistoryRequest.getEvent().getCustomerAccess()!=null){
			viewTransactionsHistoryFlat.setChannelSessionId(viewTransactionsHistoryRequest.getEvent().getCustomerAccess().getChannelSessionId());
			viewTransactionsHistoryFlat.setDeviceType(viewTransactionsHistoryRequest.getEvent().getCustomerAccess().getDeviceType());
			viewTransactionsHistoryFlat.setDeviceID(viewTransactionsHistoryRequest.getEvent().getCustomerAccess().getDeviceID());
			viewTransactionsHistoryFlat.setDeviceOS(viewTransactionsHistoryRequest.getEvent().getCustomerAccess().getDeviceOS());
			viewTransactionsHistoryFlat.setGeoLocLatitude(viewTransactionsHistoryRequest.getEvent().getCustomerAccess().getGeoLocLatitude());
			viewTransactionsHistoryFlat.setGeoLocLongitude(viewTransactionsHistoryRequest.getEvent().getCustomerAccess().getGeoLocLongitude());
			viewTransactionsHistoryFlat.setBrowserName(viewTransactionsHistoryRequest.getEvent().getCustomerAccess().getBrowserName());
			viewTransactionsHistoryFlat.setClientIPAddress(viewTransactionsHistoryRequest.getEvent().getCustomerAccess().getClientIPAddress());
		}

		return viewTransactionsHistoryFlat;
	}


}
