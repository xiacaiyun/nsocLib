package eap2.rts.common.eventhub.dto;

public class ExtendedPINValidation {

}
