package eap2.rts.common.eventhub.dto;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonProperty;

public class EventBillPayment implements Serializable {
	
	private static final long serialVersionUID = -8249039344563568489L;
	@JsonProperty("Standard")
	private StandardBillPayment Standard;
	@JsonProperty("CustomerAccess")
    private CustomerAccessBillPayment CustomerAccess;
	@JsonProperty("Extended")
    private ExtendedBillPayment Extended;
	@JsonProperty("Metadata")
    private MetadataBillPayment Metadata;

    public StandardBillPayment getStandard ()
    {
        return Standard;
    }

    public void setStandard (StandardBillPayment Standard)
    {
        this.Standard = Standard;
    }

    public CustomerAccessBillPayment getCustomerAccess ()
    {
        return CustomerAccess;
    }

    public void setCustomerAccess (CustomerAccessBillPayment CustomerAccess)
    {
        this.CustomerAccess = CustomerAccess;
    }

    public ExtendedBillPayment getExtended ()
    {
        return Extended;
    }

    public void setExtended (ExtendedBillPayment Extended)
    {
        this.Extended = Extended;
    }

    public MetadataBillPayment getMetadata ()
    {
        return Metadata;
    }

    public void setMetadata (MetadataBillPayment Metadata)
    {
        this.Metadata = Metadata;
    }

    @Override
    public String toString()
    {
        return "ClassPojo [Standard = "+Standard+", CustomerAccess = "+CustomerAccess+", Extended = "+Extended+", Metadata = "+Metadata+"]";
    }
}
