package eap2.rts.common.eventhub.dto;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonProperty;

public class ExtendedSDNMatchFound implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -1517320887831830713L;
	@JsonProperty("DestinationAccountNo")
    private String DestinationAccountNo;
	@JsonProperty("PayeeName")
    private String PayeeName;
	@JsonProperty("Remarks")
	private String Remarks;
	
	
	
	public String getDestinationAccountNo() {
		return DestinationAccountNo;
	}



	public void setDestinationAccountNo(String destinationAccountNo) {
		DestinationAccountNo = destinationAccountNo;
	}



	public String getPayeeName() {
		return PayeeName;
	}



	public void setPayeeName(String payeeName) {
		PayeeName = payeeName;
	}



	public String getRemarks() {
		return Remarks;
	}



	public void setRemarks(String remarks) {
		Remarks = remarks;
	}



	@Override
	public String toString() {
		return "ExtendedSDNMatchFound [DestinationAccountNo=" + DestinationAccountNo + ", PayeeName=" + PayeeName
				+ ", Remarks=" + Remarks + "]";
	}
	
	
	
}
