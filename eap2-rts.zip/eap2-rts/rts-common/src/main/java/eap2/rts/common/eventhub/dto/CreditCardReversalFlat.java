package eap2.rts.common.eventhub.dto;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonProperty;

public class CreditCardReversalFlat implements Serializable{
	private static final long serialVersionUID = -4318983062065908062L;
	
	@JsonProperty("CardNumber")
	private String CardNumber;
	@JsonProperty("CustomerType")
    private String CustomerType;
	@JsonProperty("ServerDateTime")
    private String ServerDateTime;
	@JsonProperty("AccountNumber")
    private String AccountNumber;
	@JsonProperty("EventUUID")
    private String EventUUID;
	@JsonProperty("BusinessID")
    private String BusinessID;
	@JsonProperty("ESBUUID")
    private String ESBUUID;
	@JsonProperty("EventProducer")
    private String EventProducer;
	@JsonProperty("BizFunctionID")
    private String BizFunctionID;
	@JsonProperty("CorrelationID")
    private String CorrelationID;
	@JsonProperty("TransactionType")
    private String TransactionType;
	@JsonProperty("EventID")
    private String EventID;
	@JsonProperty("EventTransmitter")
    private String EventTransmitter;
	@JsonProperty("UUID_UniqueID")
    private String UUID_UniqueID;
	@JsonProperty("RespStatusCode")
    private String RespStatusCode;
	@JsonProperty("TouchPoint")
    private String TouchPoint;
	@JsonProperty("TransactionStatus")
    private String TransactionStatus;
	@JsonProperty("IsCustomerPrimary")
    private String IsCustomerPrimary;
	@JsonProperty("CustomerID")
    private String CustomerID;
	@JsonProperty("AssistedChannelUserID")
    private String AssistedChannelUserID;
	@JsonProperty("CountryCode")
    private String CountryCode;
	@JsonProperty("RespStatusMsg")
    private String RespStatusMsg;
	
//	Metadata
	@JsonProperty("OriginatorFunctionSubType")
	private String OriginatorFunctionSubType;
	@JsonProperty("OriginatorFunctionID")
    private String OriginatorFunctionID;
	@JsonProperty("OriginatorFunctionType")
    private String OriginatorFunctionType;
	@JsonProperty("OriginatorSubFunctionID")
    private String OriginatorSubFunctionID;

	
//	CustomerAcess
	@JsonProperty("DeviceID")
	private String DeviceID;
	@JsonProperty("ChannelSessionId")
    private String ChannelSessionId;
	@JsonProperty("GeoLocLongitude")
    private String GeoLocLongitude;
	@JsonProperty("ClientIPAddress")
    private String ClientIPAddress;
	@JsonProperty("DeviceOS")
    private String DeviceOS;
	@JsonProperty("GeoLocLatitude")
    private String GeoLocLatitude;
	@JsonProperty("BrowserName")
    private String BrowserName;
	@JsonProperty("DeviceType")
    private String DeviceType;
	
//	Extended

	public String getCardNumber() {
		return CardNumber;
	}

	public void setCardNumber(String cardNumber) {
		CardNumber = cardNumber;
	}

	public String getCustomerType() {
		return CustomerType;
	}

	public void setCustomerType(String customerType) {
		CustomerType = customerType;
	}

	public String getServerDateTime() {
		return ServerDateTime;
	}

	public void setServerDateTime(String serverDateTime) {
		ServerDateTime = serverDateTime;
	}

	public String getAccountNumber() {
		return AccountNumber;
	}

	public void setAccountNumber(String accountNumber) {
		AccountNumber = accountNumber;
	}

	public String getEventUUID() {
		return EventUUID;
	}

	public void setEventUUID(String eventUUID) {
		EventUUID = eventUUID;
	}

	public String getBusinessID() {
		return BusinessID;
	}

	public void setBusinessID(String businessID) {
		BusinessID = businessID;
	}

	public String getESBUUID() {
		return ESBUUID;
	}

	public void setESBUUID(String eSBUUID) {
		ESBUUID = eSBUUID;
	}

	public String getEventProducer() {
		return EventProducer;
	}

	public void setEventProducer(String eventProducer) {
		EventProducer = eventProducer;
	}

	public String getBizFunctionID() {
		return BizFunctionID;
	}

	public void setBizFunctionID(String bizFunctionID) {
		BizFunctionID = bizFunctionID;
	}

	public String getCorrelationID() {
		return CorrelationID;
	}

	public void setCorrelationID(String correlationID) {
		CorrelationID = correlationID;
	}

	public String getTransactionType() {
		return TransactionType;
	}

	public void setTransactionType(String transactionType) {
		TransactionType = transactionType;
	}

	public String getEventID() {
		return EventID;
	}

	public void setEventID(String eventID) {
		EventID = eventID;
	}

	public String getEventTransmitter() {
		return EventTransmitter;
	}

	public void setEventTransmitter(String eventTransmitter) {
		EventTransmitter = eventTransmitter;
	}

	public String getUUID_UniqueID() {
		return UUID_UniqueID;
	}

	public void setUUID_UniqueID(String uUID_UniqueID) {
		UUID_UniqueID = uUID_UniqueID;
	}

	public String getRespStatusCode() {
		return RespStatusCode;
	}

	public void setRespStatusCode(String respStatusCode) {
		RespStatusCode = respStatusCode;
	}

	public String getTouchPoint() {
		return TouchPoint;
	}

	public void setTouchPoint(String touchPoint) {
		TouchPoint = touchPoint;
	}

	public String getTransactionStatus() {
		return TransactionStatus;
	}

	public void setTransactionStatus(String transactionStatus) {
		TransactionStatus = transactionStatus;
	}

	public String getIsCustomerPrimary() {
		return IsCustomerPrimary;
	}

	public void setIsCustomerPrimary(String isCustomerPrimary) {
		IsCustomerPrimary = isCustomerPrimary;
	}

	public String getCustomerID() {
		return CustomerID;
	}

	public void setCustomerID(String customerID) {
		CustomerID = customerID;
	}

	public String getAssistedChannelUserID() {
		return AssistedChannelUserID;
	}

	public void setAssistedChannelUserID(String assistedChannelUserID) {
		AssistedChannelUserID = assistedChannelUserID;
	}

	public String getCountryCode() {
		return CountryCode;
	}

	public void setCountryCode(String countryCode) {
		CountryCode = countryCode;
	}

	public String getRespStatusMsg() {
		return RespStatusMsg;
	}

	public void setRespStatusMsg(String respStatusMsg) {
		RespStatusMsg = respStatusMsg;
	}

	public String getOriginatorFunctionSubType() {
		return OriginatorFunctionSubType;
	}

	public void setOriginatorFunctionSubType(String originatorFunctionSubType) {
		OriginatorFunctionSubType = originatorFunctionSubType;
	}

	public String getOriginatorFunctionID() {
		return OriginatorFunctionID;
	}

	public void setOriginatorFunctionID(String originatorFunctionID) {
		OriginatorFunctionID = originatorFunctionID;
	}

	public String getOriginatorFunctionType() {
		return OriginatorFunctionType;
	}

	public void setOriginatorFunctionType(String originatorFunctionType) {
		OriginatorFunctionType = originatorFunctionType;
	}

	public String getOriginatorSubFunctionID() {
		return OriginatorSubFunctionID;
	}

	public void setOriginatorSubFunctionID(String originatorSubFunctionID) {
		OriginatorSubFunctionID = originatorSubFunctionID;
	}

	public String getDeviceID() {
		return DeviceID;
	}

	public void setDeviceID(String deviceID) {
		DeviceID = deviceID;
	}

	public String getChannelSessionId() {
		return ChannelSessionId;
	}

	public void setChannelSessionId(String channelSessionId) {
		ChannelSessionId = channelSessionId;
	}

	public String getGeoLocLongitude() {
		return GeoLocLongitude;
	}

	public void setGeoLocLongitude(String geoLocLongitude) {
		GeoLocLongitude = geoLocLongitude;
	}

	public String getClientIPAddress() {
		return ClientIPAddress;
	}

	public void setClientIPAddress(String clientIPAddress) {
		ClientIPAddress = clientIPAddress;
	}

	public String getDeviceOS() {
		return DeviceOS;
	}

	public void setDeviceOS(String deviceOS) {
		DeviceOS = deviceOS;
	}

	public String getGeoLocLatitude() {
		return GeoLocLatitude;
	}

	public void setGeoLocLatitude(String geoLocLatitude) {
		GeoLocLatitude = geoLocLatitude;
	}

	public String getBrowserName() {
		return BrowserName;
	}

	public void setBrowserName(String browserName) {
		BrowserName = browserName;
	}

	public String getDeviceType() {
		return DeviceType;
	}

	public void setDeviceType(String deviceType) {
		DeviceType = deviceType;
	}

}
