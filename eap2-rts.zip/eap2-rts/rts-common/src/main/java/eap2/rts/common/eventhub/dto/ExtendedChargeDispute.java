package eap2.rts.common.eventhub.dto;

import java.io.Serializable;

public class ExtendedChargeDispute implements Serializable {
	private static final long serialVersionUID = -4101830153535185275L;
	
	
}
