package eap2.rts.common.eventhub.dto;

import java.io.Serializable;

public class ExtendedChequeBounce implements Serializable {
	private static final long serialVersionUID = -810069546432580341L;
	
	
}
