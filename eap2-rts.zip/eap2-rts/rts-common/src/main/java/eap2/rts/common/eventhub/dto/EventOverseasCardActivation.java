package eap2.rts.common.eventhub.dto;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonProperty;

public class EventOverseasCardActivation implements Serializable {
	private static final long serialVersionUID = -8188320421703912065L;
	
	@JsonProperty("Standard")
	private StandardOverseasCardActivation Standard;
	@JsonProperty("CustomerAccess")
    private CustomerAccessOverseasCardActivation CustomerAccess;
	@JsonProperty("Extended")
    private ExtendedOverseasCardActivation Extended;
	@JsonProperty("Metadata")
    private MetadataOverseasCardActivation Metadata;

    public StandardOverseasCardActivation getStandard ()
    {
        return Standard;
    }

    public void setStandard (StandardOverseasCardActivation Standard)
    {
        this.Standard = Standard;
    }

    public CustomerAccessOverseasCardActivation getCustomerAccess ()
    {
        return CustomerAccess;
    }

    public void setCustomerAccess (CustomerAccessOverseasCardActivation CustomerAccess)
    {
        this.CustomerAccess = CustomerAccess;
    }

    public ExtendedOverseasCardActivation getExtended ()
    {
        return Extended;
    }

    public void setExtended (ExtendedOverseasCardActivation Extended)
    {
        this.Extended = Extended;
    }

    public MetadataOverseasCardActivation getMetadata ()
    {
        return Metadata;
    }

    public void setMetadata (MetadataOverseasCardActivation Metadata)
    {
        this.Metadata = Metadata;
    }

    @Override
    public String toString()
    {
        return "ClassPojo [Standard = "+Standard+", CustomerAccess = "+CustomerAccess+", Extended = "+Extended+", Metadata = "+Metadata+"]";
    }
}
