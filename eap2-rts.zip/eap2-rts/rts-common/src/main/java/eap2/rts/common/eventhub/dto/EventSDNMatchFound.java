package eap2.rts.common.eventhub.dto;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonProperty;

public class EventSDNMatchFound implements Serializable {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 9069776700650092833L;
	@JsonProperty("Standard")
	private StandardSDNMatchFound Standard;
	@JsonProperty("CustomerAccess")
    private CustomerAccessSDNMatchFound CustomerAccess;
	@JsonProperty("Extended")
    private ExtendedSDNMatchFound Extended;
	@JsonProperty("Metadata")
    private MetadataSDNMatchFound Metadata;
	public StandardSDNMatchFound getStandard() {
		return Standard;
	}
	public void setStandard(StandardSDNMatchFound standard) {
		Standard = standard;
	}
	public CustomerAccessSDNMatchFound getCustomerAccess() {
		return CustomerAccess;
	}
	public void setCustomerAccess(CustomerAccessSDNMatchFound customerAccess) {
		CustomerAccess = customerAccess;
	}
	public ExtendedSDNMatchFound getExtended() {
		return Extended;
	}
	public void setExtended(ExtendedSDNMatchFound extended) {
		Extended = extended;
	}
	public MetadataSDNMatchFound getMetadata() {
		return Metadata;
	}
	public void setMetadata(MetadataSDNMatchFound metadata) {
		Metadata = metadata;
	}
	
	
	
}
