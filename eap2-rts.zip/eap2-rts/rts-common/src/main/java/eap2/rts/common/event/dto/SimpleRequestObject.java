package eap2.rts.common.event.dto;

import java.io.Serializable;

public class SimpleRequestObject implements Serializable {

	private static final long serialVersionUID = -6572558058092228648L;
	private long timeStamp;
	private String messageid;
	private String requestQueueName;
	private String msgBody;
	private String requestDatetime;

	public long getTimeStamp() {
		return timeStamp;
	}

	public void setTimeStamp(long timeStamp) {
		this.timeStamp = timeStamp;
	}

	public String getMsgBody() {
		return msgBody;
	}

	public void setMsgBody(String msgBody) {
		this.msgBody = msgBody;
	}

	public String getMessageid() {
		return messageid;
	}

	public void setMessageid(String messageid) {
		this.messageid = messageid;
	}

	public String getRequestQueueName() {
		return requestQueueName;
	}

	public void setRequestQueueName(String requestQueueName) {
		this.requestQueueName = requestQueueName;
	}

	public String getRequestDatetime() {
		return requestDatetime;
	}

	public void setRequestDatetime(String requestDatetime) {
		this.requestDatetime = requestDatetime;
	}

	@Override
	public String toString() {
		return "SimpleRequestObject [timeStamp=" + timeStamp + ", messageid=" + messageid + ", requestQueueName="
				+ requestQueueName + ", msgBody=" + msgBody + ", requestDatetime=" + requestDatetime + "]";
	}

	

}
