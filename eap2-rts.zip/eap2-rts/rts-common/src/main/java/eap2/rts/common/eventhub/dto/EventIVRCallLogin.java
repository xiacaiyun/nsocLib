package eap2.rts.common.eventhub.dto;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonProperty;

public class EventIVRCallLogin implements Serializable {
	private static final long serialVersionUID = 5318901469142517374L;
	
	@JsonProperty("Standard")
	private StandardIVRCallLogin Standard;
	@JsonProperty("CustomerAccess")
    private CustomerAccessIVRCallLogin CustomerAccess;
	@JsonProperty("Extended")
    private ExtendedIVRCallLogin Extended;
	@JsonProperty("Metadata")
    private MetadataIVRCallLogin Metadata;

    public StandardIVRCallLogin getStandard ()
    {
        return Standard;
    }

    public void setStandard (StandardIVRCallLogin Standard)
    {
        this.Standard = Standard;
    }

    public CustomerAccessIVRCallLogin getCustomerAccess ()
    {
        return CustomerAccess;
    }

    public void setCustomerAccess (CustomerAccessIVRCallLogin CustomerAccess)
    {
        this.CustomerAccess = CustomerAccess;
    }

    public ExtendedIVRCallLogin getExtended ()
    {
        return Extended;
    }

    public void setExtended (ExtendedIVRCallLogin Extended)
    {
        this.Extended = Extended;
    }

    public MetadataIVRCallLogin getMetadata ()
    {
        return Metadata;
    }

    public void setMetadata (MetadataIVRCallLogin Metadata)
    {
        this.Metadata = Metadata;
    }

    @Override
    public String toString()
    {
        return "ClassPojo [Standard = "+Standard+", CustomerAccess = "+CustomerAccess+", Extended = "+Extended+", Metadata = "+Metadata+"]";
    }
}
