package eap2.rts.common.appconfig.dao.ora;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Properties;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import eap2.rts.common.SysConstants;
import eap2.rts.common.appconfig.dao.DTOBuilder;
import eap2.rts.common.exception.SystemException;

public abstract class GenericJDBCDAO {
	protected Logger logger = LoggerFactory.getLogger(this.getClass());

	protected Properties props;
	private Connection connection = null;

	public GenericJDBCDAO(Properties props) {
		this.props = props;
		if (logger.isTraceEnabled()) {
			logger.info("Inside GenericJDBCDAO-->GenericJDBCDAO...");
		}
	}

	protected PreparedStatement getQuery(String sqlQuery, Collection<?> params, Connection conn) throws SQLException {
		if (logger.isTraceEnabled())
			logger.info("Inside GenericJDBCDAO-->getQuery...");
		PreparedStatement ps = conn.prepareStatement(sqlQuery);
		initParamValues(ps, params);
		return ps;
	}

	private void initParamValues(PreparedStatement stmt, Collection<?> params) throws SQLException {
		if (logger.isTraceEnabled())
			logger.info("Inside GenericJDBCDAO-->initParamValues...");
		Object[] values = params.toArray();
		for (int i = 0; i < values.length; i++) {
			if (values[i] == null) {
				stmt.setNull(i + 1, Types.NULL);
			} else {
				stmt.setObject(i + 1, values[i]);
			}
		}
	}

	protected Object execute(String sqlQuery, Collection<?> params, DTOBuilder transformer) throws SQLException, SystemException {
		Connection connection = null;
		PreparedStatement queryPS = null;
		ResultSet queryRS = null;
		boolean bResultSet = false;
		try {
			connection = getConnection();
			queryPS = getQuery(sqlQuery, params, connection);
			bResultSet = queryPS.execute();
			Object result;
			long count;
			if (bResultSet) {
				queryRS = queryPS.getResultSet();
				result = new ResultSetUtils().collect(queryRS, transformer);
				count = ((Collection<?>) result).size();
			} else {
				count = queryPS.getUpdateCount();
				result = new Long(count);
			}
			return result;
		} finally {
			close(queryRS);
			close(queryPS);
			close(connection);
		}
	}

	private class ResultSetUtils {
		public Collection<Object> collect(ResultSet queryRS, DTOBuilder transformer) throws SQLException {
			ArrayList<Object> rows = new ArrayList<Object>();
			Object row = null;
			if (queryRS != null && transformer != null) {
				while (queryRS.next()) {
					row = transformer.transform(queryRS);
					rows.add(row);
					if (logger.isTraceEnabled())
						logger.info("Inside GenericJDBCDAO.ResultSetUtils-->collect... Row: " + row);
				}
			}
			return rows;
		}
	}

	private Connection getConnection() throws SQLException, SystemException {
		if (logger.isTraceEnabled()) {
			logger.info("Inside GenericJDBCDAO-->getConnection...");
		}

		if (connection != null && !connection.isClosed()) {
			return connection;
		}

		try {
			String driverClass = props.getProperty(SysConstants.ORA_DRIVER_PARAM);
			String dbURL = props.getProperty(SysConstants.ORA_URL_PARAM);
			String dbUser = props.getProperty(SysConstants.ORA_USER_PARAM);
			String dbPassword = props.getProperty(SysConstants.ORA_PASSWORD_PARAM);
			Class.forName(driverClass);
			connection = DriverManager.getConnection(dbURL, dbUser, dbPassword);
		} catch (Exception e) {
			throw new SystemException(e);
		}
		return connection;
	}

	private void close(ResultSet closable) throws SQLException {
		if (closable != null) {
			closable.close();
		}
	}

	private void close(PreparedStatement closable) throws SQLException {
		if (closable != null) {
			closable.close();
		}
	}

	private void close(Connection closable) throws SQLException {
		if (closable != null) {
			closable.close();
		}
	}

	protected void finalize() {
		if (connection != null) {
			try {
				close(connection);
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
	}

}