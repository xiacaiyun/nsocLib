package eap2.rts.common.eventhub.dto;

import java.io.Serializable;

public class ExtendedRewardRedemptionRequest implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1729996110884373337L;
	
	
}
