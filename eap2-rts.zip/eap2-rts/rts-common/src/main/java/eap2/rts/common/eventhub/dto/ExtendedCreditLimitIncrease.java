package eap2.rts.common.eventhub.dto;

import java.io.Serializable;

public class ExtendedCreditLimitIncrease implements Serializable {
	private static final long serialVersionUID = -7738653753443674897L;
	
	
}
