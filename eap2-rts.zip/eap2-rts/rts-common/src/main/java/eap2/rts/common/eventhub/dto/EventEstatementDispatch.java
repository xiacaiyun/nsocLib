package eap2.rts.common.eventhub.dto;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonProperty;

public class EventEstatementDispatch implements Serializable {
	private static final long serialVersionUID = 3701614914548780701L;
	
	@JsonProperty("Standard")
	private StandardEstatementDispatch Standard;
	@JsonProperty("CustomerAccess")
    private CustomerAccessEstatementDispatch CustomerAccess;
	@JsonProperty("Extended")
    private ExtendedEstatementDispatch Extended;
	@JsonProperty("Metadata")
    private MetadataEstatementDispatch Metadata;

    public StandardEstatementDispatch getStandard ()
    {
        return Standard;
    }

    public void setStandard (StandardEstatementDispatch Standard)
    {
        this.Standard = Standard;
    }

    public CustomerAccessEstatementDispatch getCustomerAccess ()
    {
        return CustomerAccess;
    }

    public void setCustomerAccess (CustomerAccessEstatementDispatch CustomerAccess)
    {
        this.CustomerAccess = CustomerAccess;
    }

    public ExtendedEstatementDispatch getExtended ()
    {
        return Extended;
    }

    public void setExtended (ExtendedEstatementDispatch Extended)
    {
        this.Extended = Extended;
    }

    public MetadataEstatementDispatch getMetadata ()
    {
        return Metadata;
    }

    public void setMetadata (MetadataEstatementDispatch Metadata)
    {
        this.Metadata = Metadata;
    }

    @Override
    public String toString()
    {
        return "ClassPojo [Standard = "+Standard+", CustomerAccess = "+CustomerAccess+", Extended = "+Extended+", Metadata = "+Metadata+"]";
    }
}
