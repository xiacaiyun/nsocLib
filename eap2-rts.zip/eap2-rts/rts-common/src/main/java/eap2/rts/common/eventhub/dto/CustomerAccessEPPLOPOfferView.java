package eap2.rts.common.eventhub.dto;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonProperty;

public class CustomerAccessEPPLOPOfferView implements Serializable{
	
	private static final long serialVersionUID = 7682422869993570858L;
	
	@JsonProperty("ChannelSessionId")
    private String ChannelSessionId;
	@JsonProperty("DeviceType")
    private String DeviceType;
	@JsonProperty("DeviceID")
	private String DeviceID;
	@JsonProperty("DeviceOS")
    private String DeviceOS;
	@JsonProperty("GeoLocLatitude")
    private String GeoLocLatitude;
	@JsonProperty("GeoLocLongitude")
    private String GeoLocLongitude;
	@JsonProperty("BrowserName")
    private String BrowserName;
	@JsonProperty("ClientIPAddress")
    private String ClientIPAddress;
	
	
	public String getChannelSessionId() {
		return ChannelSessionId;
	}
	public void setChannelSessionId(String channelSessionId) {
		ChannelSessionId = channelSessionId;
	}
	public String getDeviceType() {
		return DeviceType;
	}
	public void setDeviceType(String deviceType) {
		DeviceType = deviceType;
	}
	public String getDeviceID() {
		return DeviceID;
	}
	public void setDeviceID(String deviceID) {
		DeviceID = deviceID;
	}
	public String getDeviceOS() {
		return DeviceOS;
	}
	public void setDeviceOS(String deviceOS) {
		DeviceOS = deviceOS;
	}
	public String getGeoLocLatitude() {
		return GeoLocLatitude;
	}
	public void setGeoLocLatitude(String geoLocLatitude) {
		GeoLocLatitude = geoLocLatitude;
	}
	public String getGeoLocLongitude() {
		return GeoLocLongitude;
	}
	public void setGeoLocLongitude(String geoLocLongitude) {
		GeoLocLongitude = geoLocLongitude;
	}
	public String getBrowserName() {
		return BrowserName;
	}
	public void setBrowserName(String browserName) {
		BrowserName = browserName;
	}
	public String getClientIPAddress() {
		return ClientIPAddress;
	}
	public void setClientIPAddress(String clientIPAddress) {
		ClientIPAddress = clientIPAddress;
	}
	@Override
	public String toString() {
		return "CustomerAccessEPPLOPOfferView [ChannelSessionId=" + ChannelSessionId + ", DeviceType=" + DeviceType
				+ ", DeviceID=" + DeviceID + ", DeviceOS=" + DeviceOS + ", GeoLocLatitude=" + GeoLocLatitude
				+ ", GeoLocLongitude=" + GeoLocLongitude + ", BrowserName=" + BrowserName + ", ClientIPAddress="
				+ ClientIPAddress + "]";
	}
	
	
	
	
	
}
