package eap2.rts.common.appconfig.dao;

import java.sql.SQLException;

public interface DTOBuilder {

	public Object transform(Object rs) throws SQLException;

}
