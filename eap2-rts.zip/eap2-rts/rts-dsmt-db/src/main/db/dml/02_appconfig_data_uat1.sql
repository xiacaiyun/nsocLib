INSERT INTO RTS3_UAT1_APPLICATION (id, name, tenant_id, description, void_ind)
VALUES(10001, 'CPO', 10001, 'Citi Phone Officer Dashboard', 'N');

INSERT INTO RTS3_UAT1_APP_PARAM (id, param_type_code, app_id, param_name, param_value, description)
VALUES(10001, 'SPARK_CONF', 10001, 'spark.app.name', 'CPO Spark', null);
INSERT INTO RTS3_UAT1_APP_PARAM (id, param_type_code, app_id, param_name, param_value, description)
VALUES(10003, 'APP_CONF', 10001, 'app.spark.duration', '300', 'milli-seconds');
INSERT INTO RTS3_UAT1_APP_PARAM (id, param_type_code, app_id, param_name, param_value, description)
VALUES(10004, 'APP_CONF', 10001, 'app.spark.msg.broker.type', 'TIBCO', null);

INSERT INTO RTS3_UAT1_APP_DS(id, name, app_id, ds_type_code, description,default_event)
VALUES(10001, 'EPP_POSS_RES_DS', 10001,'TIBCO', 'EPP POSS RES DS','EPP_POSS_RES');

INSERT INTO RTS3_UAT1_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(10001,10001,'INITIAL_CONTEXT_FACTORY','com.tibco.tibjms.naming.TibjmsInitialContextFactory','N');
INSERT INTO RTS3_UAT1_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(10002,10001,'PROVIDER_URL', 'ssl://gpd-f1e-9b87.nam.nsroot.net:41143','N');
INSERT INTO RTS3_UAT1_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(10003,10001,'com.tibco.tibjms.naming.ssl_identity', 'hdfs://gftsdev/user/gcgdmasg/security/DIT_EAP_USR.ca1.p12','N');
INSERT INTO RTS3_UAT1_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(10004,10001,'com.tibco.tibjms.naming.ssl_password', 'CZfUOw6Rr9RNtmVYgmAKdA==','Y');
INSERT INTO RTS3_UAT1_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(10005,10001,'SECURITY_PRINCIPAL', 'SIT_EAP_USR','N');
INSERT INTO RTS3_UAT1_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(10006,10001,'SECURITY_CREDENTIALS', 'CZfUOw6Rr9RNtmVYgmAKdA==','Y');
INSERT INTO RTS3_UAT1_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(10007,10001,'com.tibco.tibjms.naming.security_protocol', 'ssl','N');
INSERT INTO RTS3_UAT1_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(10008,10001,'com.tibco.tibjms.naming.ssl_enable_verify_host', 'false','N');
INSERT INTO RTS3_UAT1_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(10009,10001,'com.tibco.tibjms.naming.ssl_vendor', 'j2se-default','N');
INSERT INTO RTS3_UAT1_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(10010,10001,'com.sun.net.ssl.internal.ssl.Provider', 'j2se-default','N');
INSERT INTO RTS3_UAT1_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(10011,10001,'com.tibco.tibjms.naming.ssl_auth_only', 'true','N');
INSERT INTO RTS3_UAT1_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(10012,10001,'java.property.TIBCO_SECURITY_VENDOR','j2se-default','N');
INSERT INTO RTS3_UAT1_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(10013,10001,'java.property.TIBCO_SECURITY_TRACE', 'false','N');
INSERT INTO RTS3_UAT1_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(10014,10001,'com.tibco.tibjms.naming.ssl_debug_trace', 'true','N');
INSERT INTO RTS3_UAT1_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(10015,10001,'com.tibco.tibjms.naming.ssl_trace','true','N');
INSERT INTO RTS3_UAT1_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(10016,10001,'tibco.jms.queue.queueCF','G2C_ESB_EAPQueueConnectionFactory','N');
INSERT INTO RTS3_UAT1_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(10017,10001,'tibco.jms.inbound.queue.name','citi.gcg.gom.esb_159515.my.eap.possiblereason.Rq','N');
INSERT INTO RTS3_UAT1_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(10018,10001,'tibco.jms.queue.username','SIT_EAP_USR','N');
INSERT INTO RTS3_UAT1_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(10019,10001,'tibco.jms.queue.password','CZfUOw6Rr9RNtmVYgmAKdA==','Y');
INSERT INTO RTS3_UAT1_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(10020,10001,'tibco.p12.enable','true','N');

INSERT INTO RTS3_UAT1_APP_DS_EVENT(id, name, app_ds_id, event_type_code, description)
VALUES(10001, 'EPP_POSS_RES', 10001,'EPP_POSS_RES', 'TIBCO JMS Events');

INSERT INTO RTS3_UAT1_EVENT_ACTION(id,app_event_id,action_type_code,exec_order)
VALUES(10001,10001,'PARSE_EVENT',1);

INSERT INTO RTS3_UAT1_EVENT_ACTION(id,app_event_id,action_type_code,exec_order)
VALUES(10002,10001,'RET_MONGO',2);

INSERT INTO RTS3_UAT1_EVENT_ACTION_DETAIL(id,event_action_id,param_name,param_value,value_encrypted)
VALUES(10001,10002,'mongodb.uri','mongodb://admin_mongodb:$PASSWORD@maas-mw-d5-u0037.nam.nsroot.net:37017,maas-gt-d5-u0025.nam.nsroot.net:37017,maas-sw-d5-u0007.nam.nsroot.net:37017/GCG_ASIA_PH?ssl=true&authSource=admin','N');
INSERT INTO RTS3_UAT1_EVENT_ACTION_DETAIL(id,event_action_id,param_name,param_value,value_encrypted)
VALUES(10002,10002,'mongodb.db.name','GCG_ASIA_PH','N');
INSERT INTO RTS3_UAT1_EVENT_ACTION_DETAIL(id,event_action_id,param_name,param_value,value_encrypted)
VALUES(10003,10002,'mongodb.collection.name','MONGO_IVR_PR_MODEL_PSB_RSN_CONTEXT','N');
INSERT INTO RTS3_UAT1_EVENT_ACTION_DETAIL(id,event_action_id,param_name,param_value,value_encrypted)
VALUES(10027,10002,'mongodb.db.password','cZNjPmJtqQ0wDFs2DNZsZw==','Y');

INSERT INTO RTS3_UAT1_EVENT_ACTION(id,app_event_id,action_type_code,exec_order)
VALUES(10003,10001,'PUB_TIBCO',3);

INSERT INTO RTS3_UAT1_EVENT_ACTION_DETAIL(id,event_action_id,param_name,param_value,value_encrypted)
VALUES(10004,10003,'INITIAL_CONTEXT_FACTORY','com.tibco.tibjms.naming.TibjmsInitialContextFactory','N');
INSERT INTO RTS3_UAT1_EVENT_ACTION_DETAIL(id,event_action_id,param_name,param_value,value_encrypted)
VALUES(10005,10003,'PROVIDER_URL', 'ssl://gpd-f1e-9b87.nam.nsroot.net:41143','N');
INSERT INTO RTS3_UAT1_EVENT_ACTION_DETAIL(id,event_action_id,param_name,param_value,value_encrypted)
VALUES(10006,10003,'com.tibco.tibjms.naming.ssl_identity', 'hdfs://gftsdev/user/gcgdmasg/security/DIT_EAP_USR.ca1.p12','N');
INSERT INTO RTS3_UAT1_EVENT_ACTION_DETAIL(id,event_action_id,param_name,param_value,value_encrypted)
VALUES(10007,10003,'com.tibco.tibjms.naming.ssl_password', 'CZfUOw6Rr9RNtmVYgmAKdA==','Y');
INSERT INTO RTS3_UAT1_EVENT_ACTION_DETAIL(id,event_action_id,param_name,param_value,value_encrypted)
VALUES(10008,10003,'SECURITY_PRINCIPAL', 'SIT_EAP_USR','N');
INSERT INTO RTS3_UAT1_EVENT_ACTION_DETAIL(id,event_action_id,param_name,param_value,value_encrypted)
VALUES(10009,10003,'SECURITY_CREDENTIALS', 'CZfUOw6Rr9RNtmVYgmAKdA==','Y');
INSERT INTO RTS3_UAT1_EVENT_ACTION_DETAIL(id,event_action_id,param_name,param_value,value_encrypted)
VALUES(10010,10003,'com.tibco.tibjms.naming.security_protocol', 'ssl','N');
INSERT INTO RTS3_UAT1_EVENT_ACTION_DETAIL(id,event_action_id,param_name,param_value,value_encrypted)
VALUES(10011,10003,'com.tibco.tibjms.naming.ssl_enable_verify_host', 'false','N');
INSERT INTO RTS3_UAT1_EVENT_ACTION_DETAIL(id,event_action_id,param_name,param_value,value_encrypted)
VALUES(10012,10003,'com.tibco.tibjms.naming.ssl_vendor', 'j2se-default','N');
INSERT INTO RTS3_UAT1_EVENT_ACTION_DETAIL(id,event_action_id,param_name,param_value,value_encrypted)
VALUES(10013,10003,'com.sun.net.ssl.internal.ssl.Provider', 'j2se-default','N');
INSERT INTO RTS3_UAT1_EVENT_ACTION_DETAIL(id,event_action_id,param_name,param_value,value_encrypted)
VALUES(10014,10003,'com.tibco.tibjms.naming.ssl_auth_only', 'true','N');
INSERT INTO RTS3_UAT1_EVENT_ACTION_DETAIL(id,event_action_id,param_name,param_value,value_encrypted)
VALUES(10015,10003,'java.property.TIBCO_SECURITY_VENDOR','j2se-default','N');
INSERT INTO RTS3_UAT1_EVENT_ACTION_DETAIL(id,event_action_id,param_name,param_value,value_encrypted)
VALUES(10016,10003,'java.property.TIBCO_SECURITY_TRACE', 'false','N');
INSERT INTO RTS3_UAT1_EVENT_ACTION_DETAIL(id,event_action_id,param_name,param_value,value_encrypted)
VALUES(10017,10003,'com.tibco.tibjms.naming.ssl_debug_trace', 'true','N');
INSERT INTO RTS3_UAT1_EVENT_ACTION_DETAIL(id,event_action_id,param_name,param_value,value_encrypted)
VALUES(10018,10003,'com.tibco.tibjms.naming.ssl_trace','true','N');
INSERT INTO RTS3_UAT1_EVENT_ACTION_DETAIL(id,event_action_id,param_name,param_value,value_encrypted)
VALUES(10019,10003,'tibco.jms.queue.queueCF','G2C_ESB_EAPQueueConnectionFactory','N');
INSERT INTO RTS3_UAT1_EVENT_ACTION_DETAIL(id,event_action_id,param_name,param_value,value_encrypted)
VALUES(10020,10003,'tibco.jms.inbound.queue.name','citi.gcg.gom.esb_159515.my.eap.possiblereason.Rs','N');
INSERT INTO RTS3_UAT1_EVENT_ACTION_DETAIL(id,event_action_id,param_name,param_value,value_encrypted)
VALUES(10021,10003,'tibco.jms.queue.username','SIT_EAP_USR','N');
INSERT INTO RTS3_UAT1_EVENT_ACTION_DETAIL(id,event_action_id,param_name,param_value,value_encrypted)
VALUES(10022,10003,'tibco.jms.queue.password','CZfUOw6Rr9RNtmVYgmAKdA==','Y');
INSERT INTO RTS3_UAT1_EVENT_ACTION_DETAIL(id,event_action_id,param_name,param_value,value_encrypted)
VALUES(10028,10003,'tibco.p12.enable','true','N');

INSERT INTO RTS3_UAT1_EVENT_ACTION(id,app_event_id,action_type_code,exec_order)
VALUES(10004,10001,'SAVE_MONGO',4);

INSERT INTO RTS3_UAT1_EVENT_ACTION_DETAIL(id,event_action_id,param_name,param_value,value_encrypted)
VALUES(10023,10004,'mongodb.uri','mongodb://admin_mongodb:$PASSWORD@maas-sw-d5-u0007.nam.nsroot.net:37017,maas-gt-d5-u0025.nam.nsroot.net:37017,maas-sw-d5-u0007.nam.nsroot.net:37017/GCG_ASIA_PH?ssl=true&authSource=admin','N');
INSERT INTO RTS3_UAT1_EVENT_ACTION_DETAIL(id,event_action_id,param_name,param_value,value_encrypted)
VALUES(10024,10004,'mongodb.db.name','GCG_ASIA_PH','N');
INSERT INTO RTS3_UAT1_EVENT_ACTION_DETAIL(id,event_action_id,param_name,param_value,value_encrypted)
VALUES(10025,10004,'mongodb.collection.name','IVR_REQ_RES_LOG','N');
INSERT INTO RTS3_UAT1_EVENT_ACTION_DETAIL(id,event_action_id,param_name,param_value,value_encrypted)
VALUES(10026,10004,'mongodb.db.password','cZNjPmJtqQ0wDFs2DNZsZw==','Y');