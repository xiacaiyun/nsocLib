INSERT INTO RTS3_MST_TENANT(ID, NAME) VALUES(10001, 'GCG Asia MRE');

INSERT INTO RTS3_TENANT_PARAM (ID, TENANT_ID, PARAM_TYPE_CODE, PARAM_NAME, PARAM_VALUE)
VALUES(10001, 10001, 'SPARK_CONF', 'spark.serializer', 'org.apache.spark.serializer.KryoSerializer');
INSERT INTO RTS3_TENANT_PARAM (ID, TENANT_ID, PARAM_TYPE_CODE, PARAM_NAME, PARAM_VALUE)
VALUES(10002, 10001, 'SPARK_CONF', 'spark.kryoserializer.buffer.max', '1024');
INSERT INTO RTS3_TENANT_PARAM (ID, TENANT_ID, PARAM_TYPE_CODE, PARAM_NAME, PARAM_VALUE)
VALUES(10003, 10001, 'SPARK_CONF', 'spark.sql.caseSensitive', 'false');

INSERT INTO RTS3_TENANT_PARAM (ID, TENANT_ID, PARAM_TYPE_CODE, PARAM_NAME, PARAM_VALUE)
VALUES(10020, 10001, 'HDFS_CONF','hdfs.master.url','hdfs://gftsuat');
INSERT INTO RTS3_TENANT_PARAM (ID, TENANT_ID, PARAM_TYPE_CODE, PARAM_NAME, PARAM_VALUE)
VALUES(10021, 10001, 'HDFS_CONF','hdfs.core.site.xml.location','/etc/hadoop/conf.cloudera.hdfs/core-site.xml');
INSERT INTO RTS3_TENANT_PARAM (ID, TENANT_ID, PARAM_TYPE_CODE, PARAM_NAME, PARAM_VALUE)
VALUES(10022, 10001, 'HDFS_CONF','hdfs.site.xml.location','/etc/hadoop/conf.cloudera.hdfs/hdfs-site.xml');

INSERT INTO RTS3_TENANT_PARAM (ID, TENANT_ID, PARAM_TYPE_CODE, PARAM_NAME, PARAM_VALUE)
VALUES(10030, 10001, 'APP_CONF','app.partition.num','6');
INSERT INTO RTS3_TENANT_PARAM (ID, TENANT_ID, PARAM_TYPE_CODE, PARAM_NAME, PARAM_VALUE)
VALUES(10031, 10001, 'APP_CONF','app.temp.folder','file:/c:/data/tmp');
INSERT INTO RTS3_TENANT_PARAM (ID, TENANT_ID, PARAM_TYPE_CODE, PARAM_NAME, PARAM_VALUE)
VALUES(10032, 10001, 'APP_CONF','app.output.folder','file:/c:/data/cda/xml');

---------------------------------SG-------------------------------------------------------------
INSERT INTO RTS3_APPLICATION (id, name, tenant_id, description, void_ind)
VALUES(20001, 'CB-MRE-SG', 10001, 'Cross Border MRE', 'N');

INSERT INTO RTS3_APP_PARAM (id, param_type_code, app_id, param_name, param_value, description)
VALUES(20001, 'SPARK_CONF', 20001, 'spark.app.name', 'CB-MRE-SG Spark', null);
INSERT INTO RTS3_APP_PARAM (id, param_type_code, app_id, param_name, param_value, description)
VALUES(20002, 'APP_CONF', 20001, 'app.spark.duration', '300', 'milli-seconds');
INSERT INTO RTS3_APP_PARAM (id, param_type_code, app_id, param_name, param_value, description)
VALUES(20003, 'APP_CONF', 20001, 'app.spark.msg.broker.type', 'TIBCO', null);

INSERT INTO RTS3_APP_DS(id, name, app_id, ds_type_code, description,default_event)
VALUES(20001, 'CB_MRE_SG', 20001,'TIBCO', 'CB_MRE_SG DS' , 'CB_MRE_REQUEST_SG');

INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value)
VALUES(20001,20001,'INITIAL_CONTEXT_FACTORY','com.tibco.tibjms.naming.TibjmsInitialContextFactory');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value)
VALUES(20002,20001,'PROVIDER_URL', 'ssl://copuat2jndi.nam.nsroot.net:7245');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value)
VALUES(20003,20001,'com.tibco.tibjms.naming.ssl_identity', 'hdfs://gftsuat/user/gcgsgasg/security/UAT_EAP_USR.ca1.p12');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value)
VALUES(20004,20001,'com.tibco.tibjms.naming.ssl_password', '');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value)
VALUES(20005,20001,'SECURITY_PRINCIPAL', 'UAT_EAP_USR');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value)
VALUES(20006,20001,'SECURITY_CREDENTIALS', '');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value)
VALUES(20007,20001,'com.tibco.tibjms.naming.security_protocol', 'ssl');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value)
VALUES(20008,20001,'com.tibco.tibjms.naming.ssl_enable_verify_host', 'false');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value)
VALUES(20009,20001,'com.tibco.tibjms.naming.ssl_vendor', 'j2se-default');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value)
VALUES(20010,20001,'com.sun.net.ssl.internal.ssl.Provider', 'j2se-default');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value)
VALUES(20011,20001,'com.tibco.tibjms.naming.ssl_auth_only', 'true');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value)
VALUES(20012,20001,'java.property.TIBCO_SECURITY_VENDOR','j2se-default');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value)
VALUES(20013,20001,'java.property.TIBCO_SECURITY_TRACE', 'false');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value)
VALUES(20014,20001,'com.tibco.tibjms.naming.ssl_debug_trace', 'true');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value)
VALUES(20015,20001,'com.tibco.tibjms.naming.ssl_trace','true');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value)
VALUES(20016,20001,'tibco.jms.queue.queueCF','G2C_EAPCOPSGBatchQueueConnectionFactory');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value)
VALUES(20017,20001,'tibco.jms.inbound.queue.name','citi.gcg.gomsg.cop_163124.sg_card.mre.transaction.request');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value)
VALUES(20018,20001,'tibco.jms.queue.username','UAT_EAP_USR');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value)
VALUES(20019,20001,'tibco.jms.queue.password','');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value)
VALUES(20020,20001,'tibco.p12.enable','true');

INSERT INTO RTS3_APP_DS_EVENT(id, name, app_ds_id, event_type_code, description)
VALUES(20001, 'CB_MRE_REQUEST_SG', 20001,'CB_MRE_REQUEST_SG', 'TIBCO JMS Events');

INSERT INTO RTS3_EVENT_ACTION(id,app_event_id,action_type_code,exec_order)
VALUES(20001,20001,'PARSE_EVENT',1);

INSERT INTO RTS3_EVENT_ACTION(id,app_event_id,action_type_code,exec_order)
VALUES(20002,20001,'SAVE_MONGO',2);

INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name,param_value)
VALUES(20001,20002,'mongodb.uri','mongodb://eap_mongodb_uat:$PASSWORD@maas-gt-p72-m0002.nam.nsroot.net:37017,maas-sw-p72-m0001.nam.nsroot.net:37017,maas-mw-p72-m0001.nam.nsroot.net:37017/GCG_ASIA_SG?ssl=true&authSource=admin');
INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name,param_value)
VALUES(20002,20002,'mongodb.db.name','GCG_ASIA_SG');
INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name,param_value)
VALUES(20003,20002,'mongodb.collection.name','COP_CROSS_ORDER_MRE_REQ');

INSERT INTO RTS3_EVENT_ACTION(id,app_event_id,action_type_code,exec_order)
VALUES(20003,20001,'LOOKUP',3);

INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name,param_value)
VALUES(20027,20003,'mongodb.uri','mongodb://eap_mongodb_uat:$PASSWORD@maas-gt-p72-m0002.nam.nsroot.net:37017,maas-sw-p72-m0001.nam.nsroot.net:37017,maas-mw-p72-m0001.nam.nsroot.net:37017/GCG_ASIA_SG?ssl=true&authSource=admin');
INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name,param_value)
VALUES(20028,20003,'mongodb.db.name','GCG_ASIA_SG');
INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name,param_value)
VALUES(20029,20003,'mongodb.collection.name','COP_CROSS_ORDER_MRE_REQ,merchant_normalized,ASSOCIATION_RULES,merchant_master');

INSERT INTO RTS3_EVENT_ACTION(id,app_event_id,action_type_code,exec_order)
VALUES(20004,20001,'PUB_TIBCO',4);

INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name,param_value)
VALUES(20004,20004,'INITIAL_CONTEXT_FACTORY','com.tibco.tibjms.naming.TibjmsInitialContextFactory');
INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name,param_value)
VALUES(20005,20004,'PROVIDER_URL', 'ssl://copuat2jndi.nam.nsroot.net:7245');
INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name,param_value)
VALUES(20006,20004,'com.tibco.tibjms.naming.ssl_identity', 'hdfs://gftsuat/user/gcgsgasg/security/UAT_EAP_USR.ca1.p12');
INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name,param_value)
VALUES(20007,20004,'com.tibco.tibjms.naming.ssl_password', '');
INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name,param_value)
VALUES(20008,20004,'SECURITY_PRINCIPAL', 'UAT_EAP_USR');
INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name,param_value)
VALUES(20009,20004,'SECURITY_CREDENTIALS', '');
INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name,param_value)
VALUES(20010,20004,'com.tibco.tibjms.naming.security_protocol', 'ssl');
INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name,param_value)
VALUES(20011,20004,'com.tibco.tibjms.naming.ssl_enable_verify_host', 'false');
INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name,param_value)
VALUES(20012,20004,'com.tibco.tibjms.naming.ssl_vendor', 'j2se-default');
INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name,param_value)
VALUES(20013,20004,'com.sun.net.ssl.internal.ssl.Provider', 'j2se-default');
INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name,param_value)
VALUES(20014,20004,'com.tibco.tibjms.naming.ssl_auth_only', 'true');
INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name,param_value)
VALUES(20015,20004,'java.property.TIBCO_SECURITY_VENDOR','j2se-default');
INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name,param_value)
VALUES(20016,20004,'java.property.TIBCO_SECURITY_TRACE', 'false');
INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name,param_value)
VALUES(20017,20004,'com.tibco.tibjms.naming.ssl_debug_trace', 'true');
INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name,param_value)
VALUES(20018,20004,'com.tibco.tibjms.naming.ssl_trace','true');
INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name,param_value)
VALUES(20019,20004,'tibco.jms.queue.queueCF','G2C_EAPCOPSGBatchQueueConnectionFactory');
INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name,param_value)
VALUES(20020,20004,'tibco.jms.inbound.queue.name','citi.gcg.gom.cop_163124.sg_card.mre.transaction.response');
INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name,param_value)
VALUES(20021,20004,'tibco.jms.queue.username','UAT_EAP_USR');
INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name,param_value)
VALUES(20022,20004,'tibco.jms.queue.password','');
INSERT INTO RTS3_EVENT_ACTION_DETAIL(id, event_action_id, param_name, param_value)
VALUES(20023,20004,'tibco.p12.enable','true');


INSERT INTO RTS3_EVENT_ACTION(id,app_event_id,action_type_code,exec_order)
VALUES(20005,20001,'SAVE_FLAT_MONGO',5);
INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name,param_value)
VALUES(20024,20005,'mongodb.uri','mongodb://eap_mongodb_uat:$PASSWORD@maas-gt-p72-m0002.nam.nsroot.net:37017,maas-sw-p72-m0001.nam.nsroot.net:37017,maas-mw-p72-m0001.nam.nsroot.net:37017/GCG_ASIA_SG?ssl=true&authSource=admin');
INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name,param_value)
VALUES(20025,20005,'mongodb.db.name','GCG_ASIA_SG');
INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name,param_value)
VALUES(20026,20005,'mongodb.collection.name','COP_CROSS_ORDER_MRE_RES');

-------------------------------------------------------TH-------------------------------------------------------------------------------------
INSERT INTO RTS3_APPLICATION (id, name, tenant_id, description, void_ind)
VALUES(21001, 'CB-MRE-TH', 10001, 'Cross Border MRE', 'N');

INSERT INTO RTS3_APP_PARAM (id, param_type_code, app_id, param_name, param_value, description)
VALUES(21001, 'SPARK_CONF', 21001, 'spark.app.name', 'CB-MRE-TH Spark', null);
INSERT INTO RTS3_APP_PARAM (id, param_type_code, app_id, param_name, param_value, description)
VALUES(21002, 'APP_CONF', 21001, 'app.spark.duration', '300', 'milli-seconds');
INSERT INTO RTS3_APP_PARAM (id, param_type_code, app_id, param_name, param_value, description)
VALUES(21003, 'APP_CONF', 21001, 'app.spark.msg.broker.type', 'TIBCO', null);

INSERT INTO RTS3_APP_DS(id, name, app_id, ds_type_code, description,default_event)
VALUES(21001, 'CB_MRE_TH', 21001,'TIBCO', 'CB_MRE_TH DS' , 'CB_MRE_REQUEST_TH');

INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value)
VALUES(21001,21001,'INITIAL_CONTEXT_FACTORY','com.tibco.tibjms.naming.TibjmsInitialContextFactory');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value)
VALUES(21002,21001,'PROVIDER_URL', 'ssl://copuat2jndi.nam.nsroot.net:7245');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value)
VALUES(21003,21001,'com.tibco.tibjms.naming.ssl_identity', 'hdfs://gftsuat/user/gcgthasg/security/UAT_EAP_USR.ca1.p12');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value)
VALUES(21004,21001,'com.tibco.tibjms.naming.ssl_password', '');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value)
VALUES(21005,21001,'SECURITY_PRINCIPAL', 'UAT_EAP_USR');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value)
VALUES(21006,21001,'SECURITY_CREDENTIALS', '');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value)
VALUES(21007,21001,'com.tibco.tibjms.naming.security_protocol', 'ssl');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value)
VALUES(21008,21001,'com.tibco.tibjms.naming.ssl_enable_verify_host', 'false');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value)
VALUES(21009,21001,'com.tibco.tibjms.naming.ssl_vendor', 'j2se-default');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value)
VALUES(21010,21001,'com.sun.net.ssl.internal.ssl.Provider', 'j2se-default');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value)
VALUES(21011,21001,'com.tibco.tibjms.naming.ssl_auth_only', 'true');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value)
VALUES(21012,21001,'java.property.TIBCO_SECURITY_VENDOR','j2se-default');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value)
VALUES(21013,21001,'java.property.TIBCO_SECURITY_TRACE', 'false');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value)
VALUES(21014,21001,'com.tibco.tibjms.naming.ssl_debug_trace', 'true');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value)
VALUES(21015,21001,'com.tibco.tibjms.naming.ssl_trace','true');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value)
VALUES(21016,21001,'tibco.jms.queue.queueCF','G2C_EAPCOPTHBatchQueueConnectionFactory');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value)
VALUES(21017,21001,'tibco.jms.inbound.queue.name','citi.gcg.gom.cop_163124.th_card.mre.transaction.request');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value)
VALUES(21018,21001,'tibco.jms.queue.username','UAT_EAP_USR');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value)
VALUES(21019,21001,'tibco.jms.queue.password','');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value)
VALUES(21020,21001,'tibco.p12.enable','true');

INSERT INTO RTS3_APP_DS_EVENT(id, name, app_ds_id, event_type_code, description)
VALUES(21001, 'CB_MRE_REQUEST_TH', 21001,'CB_MRE_REQUEST_TH', 'TIBCO JMS Events');

INSERT INTO RTS3_EVENT_ACTION(id,app_event_id,action_type_code,exec_order)
VALUES(21001,21001,'PARSE_EVENT',1);

INSERT INTO RTS3_EVENT_ACTION(id,app_event_id,action_type_code,exec_order)
VALUES(21002,21001,'SAVE_MONGO',2);

INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name,param_value)
VALUES(21001,21002,'mongodb.uri','mongodb://eap_mongodb_uat:$PASSWORD@maas-gt-p72-m0002.nam.nsroot.net:37017,maas-sw-p72-m0001.nam.nsroot.net:37017,maas-mw-p72-m0001.nam.nsroot.net:37017/GCG_ASIA_TH?ssl=true&authSource=admin');
INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name,param_value)
VALUES(21002,21002,'mongodb.db.name','GCG_ASIA_TH');
INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name,param_value)
VALUES(21003,21002,'mongodb.collection.name','COP_CROSS_ORDER_MRE_REQ');

INSERT INTO RTS3_EVENT_ACTION(id,app_event_id,action_type_code,exec_order)
VALUES(21003,21001,'LOOKUP',3);

INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name,param_value)
VALUES(21027,21003,'mongodb.uri','mongodb://eap_mongodb_uat:$PASSWORD@maas-gt-p72-m0002.nam.nsroot.net:37017,maas-sw-p72-m0001.nam.nsroot.net:37017,maas-mw-p72-m0001.nam.nsroot.net:37017/GCG_ASIA_TH?ssl=true&authSource=admin');
INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name,param_value)
VALUES(21028,21003,'mongodb.db.name','GCG_ASIA_TH');
INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name,param_value)
VALUES(21029,21003,'mongodb.collection.name','COP_CROSS_ORDER_MRE_REQ,merchant_normalized,ASSOCIATION_RULES,merchant_master');

INSERT INTO RTS3_EVENT_ACTION(id,app_event_id,action_type_code,exec_order)
VALUES(21004,21001,'PUB_TIBCO',4);

INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name,param_value)
VALUES(21004,21004,'INITIAL_CONTEXT_FACTORY','com.tibco.tibjms.naming.TibjmsInitialContextFactory');
INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name,param_value)
VALUES(21005,21004,'PROVIDER_URL', 'ssl://copuat2jndi.nam.nsroot.net:7245');
INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name,param_value)
VALUES(21006,21004,'com.tibco.tibjms.naming.ssl_identity', 'hdfs://gftsuat/user/gcgthasg/security/UAT_EAP_USR.ca1.p12');
INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name,param_value)
VALUES(21007,21004,'com.tibco.tibjms.naming.ssl_password', '');
INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name,param_value)
VALUES(21008,21004,'SECURITY_PRINCIPAL', 'UAT_EAP_USR');
INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name,param_value)
VALUES(21009,21004,'SECURITY_CREDENTIALS', '');
INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name,param_value)
VALUES(21010,21004,'com.tibco.tibjms.naming.security_protocol', 'ssl');
INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name,param_value)
VALUES(21011,21004,'com.tibco.tibjms.naming.ssl_enable_verify_host', 'false');
INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name,param_value)
VALUES(21012,21004,'com.tibco.tibjms.naming.ssl_vendor', 'j2se-default');
INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name,param_value)
VALUES(21013,21004,'com.sun.net.ssl.internal.ssl.Provider', 'j2se-default');
INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name,param_value)
VALUES(21014,21004,'com.tibco.tibjms.naming.ssl_auth_only', 'true');
INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name,param_value)
VALUES(21015,21004,'java.property.TIBCO_SECURITY_VENDOR','j2se-default');
INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name,param_value)
VALUES(21016,21004,'java.property.TIBCO_SECURITY_TRACE', 'false');
INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name,param_value)
VALUES(21017,21004,'com.tibco.tibjms.naming.ssl_debug_trace', 'true');
INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name,param_value)
VALUES(21018,21004,'com.tibco.tibjms.naming.ssl_trace','true');
INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name,param_value)
VALUES(21019,21004,'tibco.jms.queue.queueCF','G2C_EAPCOPTHBatchQueueConnectionFactory');
INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name,param_value)
VALUES(21020,21004,'tibco.jms.inbound.queue.name','citi.gcg.gom.cop_163124.th_card.mre.transaction.response');
INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name,param_value)
VALUES(21021,21004,'tibco.jms.queue.username','UAT_EAP_USR');
INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name,param_value)
VALUES(21022,21004,'tibco.jms.queue.password','');
INSERT INTO RTS3_EVENT_ACTION_DETAIL(id, event_action_id, param_name, param_value)
VALUES(21023,21004,'tibco.p12.enable','true');


INSERT INTO RTS3_EVENT_ACTION(id,app_event_id,action_type_code,exec_order)
VALUES(21005,21001,'SAVE_FLAT_MONGO',5);
INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name,param_value)
VALUES(21024,21005,'mongodb.uri','mongodb://eap_mongodb_uat:$PASSWORD@maas-gt-p72-m0002.nam.nsroot.net:37017,maas-sw-p72-m0001.nam.nsroot.net:37017,maas-mw-p72-m0001.nam.nsroot.net:37017/GCG_ASIA_TH?ssl=true&authSource=admin');
INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name,param_value)
VALUES(21025,21005,'mongodb.db.name','GCG_ASIA_TH');
INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name,param_value)
VALUES(21026,21005,'mongodb.collection.name','COP_CROSS_ORDER_MRE_RES');

-------------------------------------------------------ID-------------------------------------------------------------------------------------
INSERT INTO RTS3_APPLICATION (id, name, tenant_id, description, void_ind)
VALUES(22001, 'CB-MRE-ID', 10001, 'Cross Border MRE', 'N');

INSERT INTO RTS3_APP_PARAM (id, param_type_code, app_id, param_name, param_value, description)
VALUES(22001, 'SPARK_CONF', 22001, 'spark.app.name', 'CB-MRE-ID Spark', null);
INSERT INTO RTS3_APP_PARAM (id, param_type_code, app_id, param_name, param_value, description)
VALUES(22002, 'APP_CONF', 22001, 'app.spark.duration', '300', 'milli-seconds');
INSERT INTO RTS3_APP_PARAM (id, param_type_code, app_id, param_name, param_value, description)
VALUES(22003, 'APP_CONF', 22001, 'app.spark.msg.broker.type', 'TIBCO', null);

INSERT INTO RTS3_APP_DS(id, name, app_id, ds_type_code, description,default_event)
VALUES(22001, 'CB_MRE_ID', 22001,'TIBCO', 'CB_MRE_ID DS' , 'CB_MRE_REQUEST_ID');

INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value)
VALUES(22001,22001,'INITIAL_CONTEXT_FACTORY','com.tibco.tibjms.naming.TibjmsInitialContextFactory');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value)
VALUES(22002,22001,'PROVIDER_URL', 'ssl://copuat2jndi.nam.nsroot.net:7245');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value)
VALUES(22003,22001,'com.tibco.tibjms.naming.ssl_identity', 'hdfs://gftsuat/user/gcgidasg/security/UAT_EAP_USR.ca1.p12');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value)
VALUES(22004,22001,'com.tibco.tibjms.naming.ssl_password', '');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value)
VALUES(22005,22001,'SECURITY_PRINCIPAL', 'UAT_EAP_USR');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value)
VALUES(22006,22001,'SECURITY_CREDENTIALS', '');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value)
VALUES(22007,22001,'com.tibco.tibjms.naming.security_protocol', 'ssl');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value)
VALUES(22008,22001,'com.tibco.tibjms.naming.ssl_enable_verify_host', 'false');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value)
VALUES(22009,22001,'com.tibco.tibjms.naming.ssl_vendor', 'j2se-default');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value)
VALUES(22010,22001,'com.sun.net.ssl.internal.ssl.Provider', 'j2se-default');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value)
VALUES(22011,22001,'com.tibco.tibjms.naming.ssl_auth_only', 'true');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value)
VALUES(22012,22001,'java.property.TIBCO_SECURITY_VENDOR','j2se-default');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value)
VALUES(22013,22001,'java.property.TIBCO_SECURITY_TRACE', 'false');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value)
VALUES(22014,22001,'com.tibco.tibjms.naming.ssl_debug_trace', 'true');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value)
VALUES(22015,22001,'com.tibco.tibjms.naming.ssl_trace','true');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value)
VALUES(22016,22001,'tibco.jms.queue.queueCF','G2C_EPPCOPIDBatchQueueConnectionFactory');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value)
VALUES(22017,22001,'tibco.jms.inbound.queue.name','citi.gcg.gom.cop_163124.id_card.mre.transaction.request');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value)
VALUES(22018,22001,'tibco.jms.queue.username','UAT_EAP_USR');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value)
VALUES(22019,22001,'tibco.jms.queue.password','');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value)
VALUES(22020,22001,'tibco.p12.enable','true');

INSERT INTO RTS3_APP_DS_EVENT(id, name, app_ds_id, event_type_code, description)
VALUES(22001, 'CB_MRE_REQUEST_ID', 22001,'CB_MRE_REQUEST_ID', 'TIBCO JMS Events');

INSERT INTO RTS3_EVENT_ACTION(id,app_event_id,action_type_code,exec_order)
VALUES(22001,22001,'PARSE_EVENT',1);

INSERT INTO RTS3_EVENT_ACTION(id,app_event_id,action_type_code,exec_order)
VALUES(22002,22001,'SAVE_MONGO',2);

INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name,param_value)
VALUES(22001,22002,'mongodb.uri','mongodb://eap_mongodb_uat:$PASSWORD@maas-gt-p72-m0002.nam.nsroot.net:37017,maas-sw-p72-m0001.nam.nsroot.net:37017,maas-mw-p72-m0001.nam.nsroot.net:37017/GCG_ASIA_ID?ssl=true&authSource=admin');
INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name,param_value)
VALUES(22002,22002,'mongodb.db.name','GCG_ASIA_ID');
INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name,param_value)
VALUES(22003,22002,'mongodb.collection.name','COP_CROSS_ORDER_MRE_REQ');

INSERT INTO RTS3_EVENT_ACTION(id,app_event_id,action_type_code,exec_order)
VALUES(22003,22001,'LOOKUP',3);

INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name,param_value)
VALUES(22027,22003,'mongodb.uri','mongodb://eap_mongodb_uat:$PASSWORD@maas-gt-p72-m0002.nam.nsroot.net:37017,maas-sw-p72-m0001.nam.nsroot.net:37017,maas-mw-p72-m0001.nam.nsroot.net:37017/GCG_ASIA_ID?ssl=true&authSource=admin');
INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name,param_value)
VALUES(22028,22003,'mongodb.db.name','GCG_ASIA_ID');
INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name,param_value)
VALUES(22029,22003,'mongodb.collection.name','COP_CROSS_ORDER_MRE_REQ,merchant_normalized,ASSOCIATION_RULES,merchant_master');

INSERT INTO RTS3_EVENT_ACTION(id,app_event_id,action_type_code,exec_order)
VALUES(22004,22001,'PUB_TIBCO',4);

INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name,param_value)
VALUES(22004,22004,'INITIAL_CONTEXT_FACTORY','com.tibco.tibjms.naming.TibjmsInitialContextFactory');
INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name,param_value)
VALUES(22005,22004,'PROVIDER_URL', 'ssl://copuat2jndi.nam.nsroot.net:7245');
INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name,param_value)
VALUES(22006,22004,'com.tibco.tibjms.naming.ssl_identity', 'hdfs://gftsuat/user/gcgidasg/security/UAT_EAP_USR.ca1.p12');
INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name,param_value)
VALUES(22007,22004,'com.tibco.tibjms.naming.ssl_password', '');
INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name,param_value)
VALUES(22008,22004,'SECURITY_PRINCIPAL', 'UAT_EAP_USR');
INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name,param_value)
VALUES(22009,22004,'SECURITY_CREDENTIALS', '');
INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name,param_value)
VALUES(22010,22004,'com.tibco.tibjms.naming.security_protocol', 'ssl');
INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name,param_value)
VALUES(22011,22004,'com.tibco.tibjms.naming.ssl_enable_verify_host', 'false');
INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name,param_value)
VALUES(22012,22004,'com.tibco.tibjms.naming.ssl_vendor', 'j2se-default');
INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name,param_value)
VALUES(22013,22004,'com.sun.net.ssl.internal.ssl.Provider', 'j2se-default');
INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name,param_value)
VALUES(22014,22004,'com.tibco.tibjms.naming.ssl_auth_only', 'true');
INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name,param_value)
VALUES(22015,22004,'java.property.TIBCO_SECURITY_VENDOR','j2se-default');
INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name,param_value)
VALUES(22016,22004,'java.property.TIBCO_SECURITY_TRACE', 'false');
INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name,param_value)
VALUES(22017,22004,'com.tibco.tibjms.naming.ssl_debug_trace', 'true');
INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name,param_value)
VALUES(22018,22004,'com.tibco.tibjms.naming.ssl_trace','true');
INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name,param_value)
VALUES(22019,22004,'tibco.jms.queue.queueCF','G2C_EPPCOPIDBatchQueueConnectionFactory');
INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name,param_value)
VALUES(22020,22004,'tibco.jms.inbound.queue.name','citi.gcg.gom.cop_163124.id_card.mre.transaction.response');
INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name,param_value)
VALUES(22021,22004,'tibco.jms.queue.username','UAT_EAP_USR');
INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name,param_value)
VALUES(22022,22004,'tibco.jms.queue.password','');
INSERT INTO RTS3_EVENT_ACTION_DETAIL(id, event_action_id, param_name, param_value)
VALUES(22023,22004,'tibco.p12.enable','true');


INSERT INTO RTS3_EVENT_ACTION(id,app_event_id,action_type_code,exec_order)
VALUES(22005,22001,'SAVE_FLAT_MONGO',5);
INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name,param_value)
VALUES(22024,22005,'mongodb.uri','mongodb://eap_mongodb_uat:$PASSWORD@maas-gt-p72-m0002.nam.nsroot.net:37017,maas-sw-p72-m0001.nam.nsroot.net:37017,maas-mw-p72-m0001.nam.nsroot.net:37017/GCG_ASIA_ID?ssl=true&authSource=admin');
INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name,param_value)
VALUES(22025,22005,'mongodb.db.name','GCG_ASIA_ID');
INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name,param_value)
VALUES(22026,22005,'mongodb.collection.name','COP_CROSS_ORDER_MRE_RES');
