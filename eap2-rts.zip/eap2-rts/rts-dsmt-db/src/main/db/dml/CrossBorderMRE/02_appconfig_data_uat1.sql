INSERT INTO RTS3_UAT1_MST_TENANT(ID, NAME) VALUES(10001, 'GCG Asia MRE');

INSERT INTO RTS3_UAT1_TENANT_PARAM (ID, TENANT_ID, PARAM_TYPE_CODE, PARAM_NAME, PARAM_VALUE)
VALUES(10001, 10001, 'SPARK_CONF', 'spark.serializer', 'org.apache.spark.serializer.KryoSerializer');
INSERT INTO RTS3_UAT1_TENANT_PARAM (ID, TENANT_ID, PARAM_TYPE_CODE, PARAM_NAME, PARAM_VALUE)
VALUES(10002, 10001, 'SPARK_CONF', 'spark.kryoserializer.buffer.max', '1024');
INSERT INTO RTS3_UAT1_TENANT_PARAM (ID, TENANT_ID, PARAM_TYPE_CODE, PARAM_NAME, PARAM_VALUE)
VALUES(10003, 10001, 'SPARK_CONF', 'spark.sql.caseSensitive', 'false');

INSERT INTO RTS3_UAT1_TENANT_PARAM (ID, TENANT_ID, PARAM_TYPE_CODE, PARAM_NAME, PARAM_VALUE)
VALUES(10020, 10001, 'HDFS_CONF','hdfs.master.url','hdfs://gftsdev');
INSERT INTO RTS3_UAT1_TENANT_PARAM (ID, TENANT_ID, PARAM_TYPE_CODE, PARAM_NAME, PARAM_VALUE)
VALUES(10021, 10001, 'HDFS_CONF','hdfs.core.site.xml.location','/etc/hadoop/conf.cloudera.hdfs/core-site.xml');
INSERT INTO RTS3_UAT1_TENANT_PARAM (ID, TENANT_ID, PARAM_TYPE_CODE, PARAM_NAME, PARAM_VALUE)
VALUES(10022, 10001, 'HDFS_CONF','hdfs.site.xml.location','/etc/hadoop/conf.cloudera.hdfs/hdfs-site.xml');

INSERT INTO RTS3_UAT1_TENANT_PARAM (ID, TENANT_ID, PARAM_TYPE_CODE, PARAM_NAME, PARAM_VALUE)
VALUES(10030, 10001, 'APP_CONF','app.partition.num','6');
INSERT INTO RTS3_UAT1_TENANT_PARAM (ID, TENANT_ID, PARAM_TYPE_CODE, PARAM_NAME, PARAM_VALUE)
VALUES(10031, 10001, 'APP_CONF','app.temp.folder','file:/c:/data/tmp');
INSERT INTO RTS3_UAT1_TENANT_PARAM (ID, TENANT_ID, PARAM_TYPE_CODE, PARAM_NAME, PARAM_VALUE)
VALUES(10032, 10001, 'APP_CONF','app.output.folder','file:/c:/data/cda/xml');

INSERT INTO RTS3_UAT1_APPLICATION (id, name, tenant_id, description, void_ind)
VALUES(20001, 'CB-MRE', 10001, 'Cross Border MRE', 'N');

INSERT INTO RTS3_UAT1_APP_PARAM (id, param_type_code, app_id, param_name, param_value, description)
VALUES(20001, 'SPARK_CONF', 20001, 'spark.app.name', 'CB-MRE Spark', null);
INSERT INTO RTS3_UAT1_APP_PARAM (id, param_type_code, app_id, param_name, param_value, description)
VALUES(20002, 'APP_CONF', 20001, 'app.spark.duration', '300', 'milli-seconds');
INSERT INTO RTS3_UAT1_APP_PARAM (id, param_type_code, app_id, param_name, param_value, description)
VALUES(20003, 'APP_CONF', 20001, 'app.spark.msg.broker.type', 'TIBCO', null);

INSERT INTO RTS3_UAT1_APP_DS(id, name, app_id, ds_type_code, description,default_event)
VALUES(20001, 'CB_MRE_SG', 20001,'TIBCO', 'CB_MRE_SG DS' , 'CB_MRE_REQUEST_SG');

INSERT INTO RTS3_UAT1_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(20001,20001,'INITIAL_CONTEXT_FACTORY','com.tibco.tibjms.naming.TibjmsInitialContextFactory','N');
INSERT INTO RTS3_UAT1_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(20002,20001,'PROVIDER_URL', 'ssl://gpd-ed9-5c7e.nam.nsroot.net:7243','N');
INSERT INTO RTS3_UAT1_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(20003,20001,'com.tibco.tibjms.naming.ssl_identity', 'file:///C:/Users/ss36531/DIT_EAP_USR.ca1.p12','N');
INSERT INTO RTS3_UAT1_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(20004,20001,'com.tibco.tibjms.naming.ssl_password', 'CZfUOw6Rr9RNtmVYgmAKdA==','Y');
INSERT INTO RTS3_UAT1_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(20005,20001,'SECURITY_PRINCIPAL', 'SIT_EAP_USR','N');
INSERT INTO RTS3_UAT1_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(20006,20001,'SECURITY_CREDENTIALS', 'CZfUOw6Rr9RNtmVYgmAKdA==','Y');
INSERT INTO RTS3_UAT1_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(20007,20001,'com.tibco.tibjms.naming.security_protocol', 'ssl','N');
INSERT INTO RTS3_UAT1_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(20008,20001,'com.tibco.tibjms.naming.ssl_enable_verify_host', 'false','N');
INSERT INTO RTS3_UAT1_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(20009,20001,'com.tibco.tibjms.naming.ssl_vendor', 'j2se-default','N');
INSERT INTO RTS3_UAT1_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(20010,20001,'com.sun.net.ssl.internal.ssl.Provider', 'j2se-default','N');
INSERT INTO RTS3_UAT1_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(20011,20001,'com.tibco.tibjms.naming.ssl_auth_only', 'true','N');
INSERT INTO RTS3_UAT1_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(20012,20001,'java.property.TIBCO_SECURITY_VENDOR','j2se-default','N');
INSERT INTO RTS3_UAT1_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(20013,20001,'java.property.TIBCO_SECURITY_TRACE', 'false','N');
INSERT INTO RTS3_UAT1_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(20014,20001,'com.tibco.tibjms.naming.ssl_debug_trace', 'true','N');
INSERT INTO RTS3_UAT1_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(20015,20001,'com.tibco.tibjms.naming.ssl_trace','true','N');
INSERT INTO RTS3_UAT1_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(20016,20001,'tibco.jms.queue.queueCF','G2C_EAPCOPSGIDVNBatchQueueConnectionFactory','N');
INSERT INTO RTS3_UAT1_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(20017,20001,'tibco.jms.inbound.queue.name','citi.gcg.gom.cop_163124.sg_card.mre.transaction.request','N');
INSERT INTO RTS3_UAT1_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(20018,20001,'tibco.jms.queue.username','SIT_EAP_USR','N');
INSERT INTO RTS3_UAT1_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(20019,20001,'tibco.jms.queue.password','CZfUOw6Rr9RNtmVYgmAKdA==','Y');
INSERT INTO RTS3_UAT1_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(20020,20001,'tibco.p12.enable','false','N');

INSERT INTO RTS3_UAT1_APP_DS_EVENT(id, name, app_ds_id, event_type_code, description)
VALUES(20001, 'CB_MRE_REQUEST_SG', 20001,'CB_MRE_REQUEST_SG', 'TIBCO JMS Events');

INSERT INTO RTS3_UAT1_EVENT_ACTION(id,app_event_id,action_type_code,exec_order)
VALUES(20001,20001,'PARSE_EVENT',1);

INSERT INTO RTS3_UAT1_EVENT_ACTION(id,app_event_id,action_type_code,exec_order)
VALUES(20002,20001,'SAVE_MONGO',2);

INSERT INTO RTS3_UAT1_EVENT_ACTION_DETAIL(id,event_action_id,param_name, param_value,value_encrypted)
VALUES(20001,20002,'mongodb.uri','mongodb://admin_mongodb:P5MwnVbm@maas-mw-d5-u0037.nam.nsroot.net:37017,maas-gt-d5-u0025.nam.nsroot.net:37017,maas-sw-d5-u0007.nam.nsroot.net:37017/GCG_ASIA_SG?ssl=true&authSource=admin','N');
INSERT INTO RTS3_UAT1_EVENT_ACTION_DETAIL(id,event_action_id,param_name, param_value,value_encrypted)
VALUES(20002,20002,'mongodb.db.name','GCG_ASIA_SG','N');
INSERT INTO RTS3_UAT1_EVENT_ACTION_DETAIL(id,event_action_id,param_name, param_value,value_encrypted)
VALUES(20003,20002,'mongodb.collection.name','GCG_ASIA_SG.COP_CROSS_ORDER_MRE_REQ','N');
INSERT INTO RTS3_UAT1_EVENT_ACTION_DETAIL(id,event_action_id,param_name,param_value,value_encrypted)
VALUES(20030,20002,'mongodb.db.password','cZNjPmJtqQ0wDFs2DNZsZw==','Y');

INSERT INTO RTS3_UAT1_EVENT_ACTION(id,app_event_id,action_type_code,exec_order)
VALUES(20003,20001,'LOOKUP',3);

INSERT INTO RTS3_UAT1_EVENT_ACTION_DETAIL(id,event_action_id,param_name, param_value,value_encrypted)
VALUES(20027,20003,'mongodb.uri','mongodb://admin_mongodb:P5MwnVbm@maas-mw-d5-u0037.nam.nsroot.net:37017,maas-gt-d5-u0025.nam.nsroot.net:37017,maas-sw-d5-u0007.nam.nsroot.net:37017/GCG_ASIA_SG?ssl=true&authSource=admin','N');
INSERT INTO RTS3_UAT1_EVENT_ACTION_DETAIL(id,event_action_id,param_name, param_value,value_encrypted)
VALUES(20028,20003,'mongodb.db.name','GCG_ASIA_SG','N');
INSERT INTO RTS3_UAT1_EVENT_ACTION_DETAIL(id,event_action_id,param_name, param_value,value_encrypted)
VALUES(20029,20003,'mongodb.collection.name','GCG_ASIA_SG.COP_CROSS_ORDER_MRE_REQ,merchant_normalized,ASSOCIATION_RULES,merchant_master,EAP_CNTRY_CD','N');
INSERT INTO RTS3_UAT1_EVENT_ACTION_DETAIL(id,event_action_id,param_name,param_value,value_encrypted)
VALUES(20031,20003,'mongodb.db.password','cZNjPmJtqQ0wDFs2DNZsZw==','Y');

INSERT INTO RTS3_UAT1_EVENT_ACTION(id,app_event_id,action_type_code,exec_order)
VALUES(20004,20001,'PUB_TIBCO',4);

INSERT INTO RTS3_UAT1_EVENT_ACTION_DETAIL(id,event_action_id,param_name, param_value,value_encrypted)
VALUES(20004,20004,'INITIAL_CONTEXT_FACTORY','com.tibco.tibjms.naming.TibjmsInitialContextFactory','N');
INSERT INTO RTS3_UAT1_EVENT_ACTION_DETAIL(id,event_action_id,param_name, param_value,value_encrypted)
VALUES(20005,20004,'PROVIDER_URL', 'ssl://gpd-ed9-5c7e.nam.nsroot.net:7243','N');
INSERT INTO RTS3_UAT1_EVENT_ACTION_DETAIL(id,event_action_id,param_name, param_value,value_encrypted)
VALUES(20006,20004,'com.tibco.tibjms.naming.ssl_identity', 'hdfs://gftsdev/user/gcgdmasg/security/DIT_EAP_USR.ca1.p12','N');
INSERT INTO RTS3_UAT1_EVENT_ACTION_DETAIL(id,event_action_id,param_name, param_value,value_encrypted)
VALUES(20007,20004,'com.tibco.tibjms.naming.ssl_password', 'CZfUOw6Rr9RNtmVYgmAKdA==','Y');
INSERT INTO RTS3_UAT1_EVENT_ACTION_DETAIL(id,event_action_id,param_name, param_value,value_encrypted)
VALUES(20008,20004,'SECURITY_PRINCIPAL', 'SIT_EAP_USR','N');
INSERT INTO RTS3_UAT1_EVENT_ACTION_DETAIL(id,event_action_id,param_name, param_value,value_encrypted)
VALUES(20009,20004,'SECURITY_CREDENTIALS', 'CZfUOw6Rr9RNtmVYgmAKdA==','Y');
INSERT INTO RTS3_UAT1_EVENT_ACTION_DETAIL(id,event_action_id,param_name, param_value,value_encrypted)
VALUES(20010,20004,'com.tibco.tibjms.naming.security_protocol', 'ssl','N');
INSERT INTO RTS3_UAT1_EVENT_ACTION_DETAIL(id,event_action_id,param_name, param_value,value_encrypted)
VALUES(20011,20004,'com.tibco.tibjms.naming.ssl_enable_verify_host', 'false','N');
INSERT INTO RTS3_UAT1_EVENT_ACTION_DETAIL(id,event_action_id,param_name, param_value,value_encrypted)
VALUES(20012,20004,'com.tibco.tibjms.naming.ssl_vendor', 'j2se-default','N');
INSERT INTO RTS3_UAT1_EVENT_ACTION_DETAIL(id,event_action_id,param_name, param_value,value_encrypted)
VALUES(20013,20004,'com.sun.net.ssl.internal.ssl.Provider', 'j2se-default','N');
INSERT INTO RTS3_UAT1_EVENT_ACTION_DETAIL(id,event_action_id,param_name, param_value,value_encrypted)
VALUES(20014,20004,'com.tibco.tibjms.naming.ssl_auth_only', 'true','N');
INSERT INTO RTS3_UAT1_EVENT_ACTION_DETAIL(id,event_action_id,param_name, param_value,value_encrypted)
VALUES(20015,20004,'java.property.TIBCO_SECURITY_VENDOR','j2se-default','N');
INSERT INTO RTS3_UAT1_EVENT_ACTION_DETAIL(id,event_action_id,param_name, param_value,value_encrypted)
VALUES(20016,20004,'java.property.TIBCO_SECURITY_TRACE', 'false','N');
INSERT INTO RTS3_UAT1_EVENT_ACTION_DETAIL(id,event_action_id,param_name, param_value,value_encrypted)
VALUES(20017,20004,'com.tibco.tibjms.naming.ssl_debug_trace', 'true','N');
INSERT INTO RTS3_UAT1_EVENT_ACTION_DETAIL(id,event_action_id,param_name, param_value,value_encrypted)
VALUES(20018,20004,'com.tibco.tibjms.naming.ssl_trace','true','N');
INSERT INTO RTS3_UAT1_EVENT_ACTION_DETAIL(id,event_action_id,param_name, param_value,value_encrypted)
VALUES(20019,20004,'tibco.jms.queue.queueCF','G2C_EAPCOPSGIDVNBatchQueueConnectionFactory','N');
INSERT INTO RTS3_UAT1_EVENT_ACTION_DETAIL(id,event_action_id,param_name, param_value,value_encrypted)
VALUES(20020,20004,'tibco.jms.inbound.queue.name','citi.gcg.gomsg.cop_163124.sg_card.mre.transaction.response','N');
INSERT INTO RTS3_UAT1_EVENT_ACTION_DETAIL(id,event_action_id,param_name, param_value,value_encrypted)
VALUES(20021,20004,'tibco.jms.queue.username','SIT_EAP_USR','N');
INSERT INTO RTS3_UAT1_EVENT_ACTION_DETAIL(id,event_action_id,param_name, param_value,value_encrypted)
VALUES(20022,20004,'tibco.jms.queue.password','CZfUOw6Rr9RNtmVYgmAKdA==','Y');
INSERT INTO RTS3_UAT1_EVENT_ACTION_DETAIL(id, event_action_id, param_name, param_value,value_encrypted)
VALUES(20023,20004,'tibco.p12.enable','true','N');


INSERT INTO RTS3_UAT1_EVENT_ACTION(id,app_event_id,action_type_code,exec_order)
VALUES(20005,20001,'SAVE_FLAT_MONGO',5);

INSERT INTO RTS3_UAT1_EVENT_ACTION_DETAIL(id,event_action_id,param_name, param_value,value_encrypted)
VALUES(20024,20005,'mongodb.uri','mongodb://admin_mongodb:P5MwnVbm@maas-mw-d5-u0037.nam.nsroot.net:37017,maas-gt-d5-u0025.nam.nsroot.net:37017,maas-sw-d5-u0007.nam.nsroot.net:37017/GCG_ASIA_SG?ssl=true&authSource=admin','N');
INSERT INTO RTS3_UAT1_EVENT_ACTION_DETAIL(id,event_action_id,param_name, param_value,value_encrypted)
VALUES(20025,20005,'mongodb.db.name','GCG_ASIA_SG','N');
INSERT INTO RTS3_UAT1_EVENT_ACTION_DETAIL(id,event_action_id,param_name, param_value,value_encrypted)
VALUES(20026,20005,'mongodb.collection.name','GCG_ASIA_SG.COP_CROSS_ORDER_MRE_RES,GCG_ASIA_SG.COP_CROSS_ORDER_MRE_REQ','N');
INSERT INTO RTS3_UAT1_EVENT_ACTION_DETAIL(id,event_action_id,param_name,param_value,value_encrypted)
VALUES(20032,20005,'mongodb.db.password','cZNjPmJtqQ0wDFs2DNZsZw==','Y');