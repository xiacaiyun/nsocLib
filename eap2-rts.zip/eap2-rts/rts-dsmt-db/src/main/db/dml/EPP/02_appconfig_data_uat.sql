INSERT INTO RTS3_APPLICATION (id, name, tenant_id, description, void_ind)
VALUES(40001, 'EPP-MY', 10001, 'Extended Payment Plan', 'N');

INSERT INTO RTS3_APP_PARAM (id, param_type_code, app_id, param_name, param_value, description)
VALUES(40001, 'SPARK_CONF', 40001, 'spark.app.name', 'EPP Spark', null);
INSERT INTO RTS3_APP_PARAM (id, param_type_code, app_id, param_name, param_value, description)
VALUES(40002, 'APP_CONF', 40001, 'app.spark.duration', '300', 'milli-seconds');
INSERT INTO RTS3_APP_PARAM (id, param_type_code, app_id, param_name, param_value, description)
VALUES(40003, 'APP_CONF', 40001, 'app.spark.msg.broker.type', 'TIBCO', null);

INSERT INTO RTS3_APP_DS(id, name, app_id, ds_type_code, description,default_event)
VALUES(40001, 'EPP_MY', 40001,'TIBCO', 'EPP_MY DS' , 'EPP_REQUEST_MY');

INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value)
VALUES(40001,40001,'INITIAL_CONTEXT_FACTORY','com.tibco.tibjms.naming.TibjmsInitialContextFactory');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value)
VALUES(40002,40001,'PROVIDER_URL', 'ssl://copuat2jndi.nam.nsroot.net:7245');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value)
VALUES(40003,40001,'com.tibco.tibjms.naming.ssl_identity', 'hdfs://gftsuat/user/gcgmyasg/security/UAT_EAP_USR.ca1.p12');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value)
VALUES(40004,40001,'com.tibco.tibjms.naming.ssl_password', '');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value)
VALUES(40005,40001,'SECURITY_PRINCIPAL', 'UAT_EPP_USR');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value)
VALUES(40006,40001,'SECURITY_CREDENTIALS', '');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value)
VALUES(40007,40001,'com.tibco.tibjms.naming.security_protocol', 'ssl');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value)
VALUES(40008,40001,'com.tibco.tibjms.naming.ssl_enable_verify_host', 'false');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value)
VALUES(40009,40001,'com.tibco.tibjms.naming.ssl_vendor', 'j2se-default');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value)
VALUES(40010,40001,'com.sun.net.ssl.internal.ssl.Provider', 'j2se-default');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value)
VALUES(40011,40001,'com.tibco.tibjms.naming.ssl_auth_only', 'true');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value)
VALUES(40012,40001,'java.property.TIBCO_SECURITY_VENDOR','j2se-default');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value)
VALUES(40013,40001,'java.property.TIBCO_SECURITY_TRACE', 'false');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value)
VALUES(40014,40001,'com.tibco.tibjms.naming.ssl_debug_trace', 'true');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value)
VALUES(40015,40001,'com.tibco.tibjms.naming.ssl_trace','true');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value)
VALUES(40016,40001,'tibco.jms.queue.queueCF','G2C_EPPCOPMYBatchQueueConnectionFactory');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value)
VALUES(40017,40001,'tibco.jms.inbound.queue.name','citi.gcg.gommy.cop_163124.my_card.epp.txnmodel.request');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value)
VALUES(40018,40001,'tibco.jms.queue.username','UAT_EPP_USR');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value)
VALUES(40019,40001,'tibco.jms.queue.password','');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value)
VALUES(40020,40001,'tibco.p12.enable','true');


INSERT INTO RTS3_APP_DS_EVENT(id, name, app_ds_id, event_type_code, description)
VALUES(40001, 'EPP_REQUEST_MY', 40001,'EPP_REQUEST_MY', 'TIBCO JMS Events');

INSERT INTO RTS3_EVENT_ACTION(id,app_event_id,action_type_code,exec_order)
VALUES(40001,40001,'PARSE_EVENT',1);

INSERT INTO RTS3_EVENT_ACTION(id,app_event_id,action_type_code,exec_order)
VALUES(40002,40001,'SAVE_MONGO',2);

INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name,param_value)
VALUES(40001,40002,'mongodb.uri','mongodb://eap_mongodb_uat:$PASSWORD@maas-gt-p72-m0002.nam.nsroot.net:37017,maas-sw-p72-m0001.nam.nsroot.net:37017,maas-mw-p72-m0001.nam.nsroot.net:37017/GCG_ASIA_MY?ssl=true&authSource=admin');
INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name,param_value)
VALUES(40002,40002,'mongodb.db.name','GCG_ASIA_MY');
INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name,param_value)
VALUES(40003,40002,'mongodb.collection.name','TXN_EPP_COP_Request');

INSERT INTO RTS3_EVENT_ACTION(id,app_event_id,action_type_code,exec_order)
VALUES(40003,40001,'CALL_PYTHON_CODE',3);

INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name,param_value)
VALUES(40027,40003,'mongodb.uri','mongodb://eap_mongodb_uat:$PASSWORD@maas-gt-p72-m0002.nam.nsroot.net:37017,maas-sw-p72-m0001.nam.nsroot.net:37017,maas-mw-p72-m0001.nam.nsroot.net:37017/GCG_ASIA_MY?ssl=true&authSource=admin');
INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name,param_value)
VALUES(40028,40003,'mongodb.db.name','GCG_ASIA_MY');
INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name,param_value)
VALUES(40029,40003,'mongodb.collection.name','EAP_EPP_TXN_SCORE');

INSERT INTO RTS3_EVENT_ACTION(id,app_event_id,action_type_code,exec_order)
VALUES(40004,40001,'PUB_TIBCO',4);

INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name,param_value)
VALUES(40004,40004,'INITIAL_CONTEXT_FACTORY','com.tibco.tibjms.naming.TibjmsInitialContextFactory');
INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name,param_value)
VALUES(40005,40004,'PROVIDER_URL', 'ssl://copuat2jndi.nam.nsroot.net:7245');
INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name,param_value)
VALUES(40006,40004,'com.tibco.tibjms.naming.ssl_identity', 'hdfs://gftsuat/user/gcgmyasg/security/UAT_EAP_USR.ca1.p12');
INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name,param_value)
VALUES(40007,40004,'com.tibco.tibjms.naming.ssl_password', '');
INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name,param_value)
VALUES(40008,40004,'SECURITY_PRINCIPAL', 'UAT_EPP_USR');
INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name,param_value)
VALUES(40009,40004,'SECURITY_CREDENTIALS', '');
INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name,param_value)
VALUES(40010,40004,'com.tibco.tibjms.naming.security_protocol', 'ssl');
INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name,param_value)
VALUES(40011,40004,'com.tibco.tibjms.naming.ssl_enable_verify_host', 'false');
INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name,param_value)
VALUES(40012,40004,'com.tibco.tibjms.naming.ssl_vendor', 'j2se-default');
INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name,param_value)
VALUES(40013,40004,'com.sun.net.ssl.internal.ssl.Provider', 'j2se-default');
INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name,param_value)
VALUES(40014,40004,'com.tibco.tibjms.naming.ssl_auth_only', 'true');
INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name,param_value)
VALUES(40015,40004,'java.property.TIBCO_SECURITY_VENDOR','j2se-default');
INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name,param_value)
VALUES(40016,40004,'java.property.TIBCO_SECURITY_TRACE', 'false');
INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name,param_value)
VALUES(40017,40004,'com.tibco.tibjms.naming.ssl_debug_trace', 'true');
INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name,param_value)
VALUES(40018,40004,'com.tibco.tibjms.naming.ssl_trace','true');
INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name,param_value)
VALUES(40019,40004,'tibco.jms.queue.queueCF','G2C_EPPCOPMYBatchQueueConnectionFactory');
INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name,param_value)
VALUES(40020,40004,'tibco.jms.inbound.queue.name','citi.gcg.gommy.cop_163124.my_card.epp.txnmodel.response');
INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name,param_value)
VALUES(40021,40004,'tibco.jms.queue.username','UAT_EPP_USR');
INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name,param_value)
VALUES(40022,40004,'tibco.jms.queue.password','');
INSERT INTO RTS3_EVENT_ACTION_DETAIL(id, event_action_id, param_name, param_value)
VALUES(40023,40004,'tibco.p12.enable','true');


INSERT INTO RTS3_EVENT_ACTION(id,app_event_id,action_type_code,exec_order)
VALUES(40005,40001,'SAVE_FLAT_MONGO',5);

INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name,param_value)
VALUES(40024,40005,'mongodb.uri','mongodb://eap_mongodb_uat:$PASSWORD@maas-gt-p72-m0002.nam.nsroot.net:37017,maas-sw-p72-m0001.nam.nsroot.net:37017,maas-mw-p72-m0001.nam.nsroot.net:37017/GCG_ASIA_MY?ssl=true&authSource=admin');
INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name,param_value)
VALUES(40025,40005,'mongodb.db.name','GCG_ASIA_MY');
INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name,param_value)
VALUES(40026,40005,'mongodb.collection.name','TXN_EPP_COP_Response');



----------------------------------------------------------------------TH-----------------------------------------------------------------------
INSERT INTO RTS3_APPLICATION (id, name, tenant_id, description, void_ind)
VALUES(41001, 'EPP-TH', 10001, 'Extended Payment Plan', 'N');

INSERT INTO RTS3_APP_PARAM (id, param_type_code, app_id, param_name, param_value, description)
VALUES(41001, 'SPARK_CONF', 41001, 'spark.app.name', 'EPP Spark', null);
INSERT INTO RTS3_APP_PARAM (id, param_type_code, app_id, param_name, param_value, description)
VALUES(41002, 'APP_CONF', 41001, 'app.spark.duration', '300', 'milli-seconds');
INSERT INTO RTS3_APP_PARAM (id, param_type_code, app_id, param_name, param_value, description)
VALUES(41003, 'APP_CONF', 41001, 'app.spark.msg.broker.type', 'TIBCO', null);

INSERT INTO RTS3_APP_DS(id, name, app_id, ds_type_code, description,default_event)
VALUES(41001, 'EPP_TH', 41001,'TIBCO', 'EPP_TH DS' , 'EPP_REQUEST_TH');

INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value)
VALUES(41001,41001,'INITIAL_CONTEXT_FACTORY','com.tibco.tibjms.naming.TibjmsInitialContextFactory');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value)
VALUES(41002,41001,'PROVIDER_URL', 'ssl://copuat2jndi.nam.nsroot.net:7245');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value)
VALUES(41003,41001,'com.tibco.tibjms.naming.ssl_identity', 'hdfs://gftsuat/user/gcgthasg/security/UAT_EAP_USR.ca1.p12');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value)
VALUES(41004,41001,'com.tibco.tibjms.naming.ssl_password', '');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value)
VALUES(41005,41001,'SECURITY_PRINCIPAL', 'UAT_EPP_USR');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value)
VALUES(41006,41001,'SECURITY_CREDENTIALS', '');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value)
VALUES(41007,41001,'com.tibco.tibjms.naming.security_protocol', 'ssl');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value)
VALUES(41008,41001,'com.tibco.tibjms.naming.ssl_enable_verify_host', 'false');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value)
VALUES(41009,41001,'com.tibco.tibjms.naming.ssl_vendor', 'j2se-default');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value)
VALUES(41010,41001,'com.sun.net.ssl.internal.ssl.Provider', 'j2se-default');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value)
VALUES(41011,41001,'com.tibco.tibjms.naming.ssl_auth_only', 'true');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value)
VALUES(41012,41001,'java.property.TIBCO_SECURITY_VENDOR','j2se-default');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value)
VALUES(41013,41001,'java.property.TIBCO_SECURITY_TRACE', 'false');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value)
VALUES(41014,41001,'com.tibco.tibjms.naming.ssl_debug_trace', 'true');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value)
VALUES(41015,41001,'com.tibco.tibjms.naming.ssl_trace','true');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value)
VALUES(41016,41001,'tibco.jms.queue.queueCF','G2C_EPPCOPTHBatchQueueConnectionFactory');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value)
VALUES(41017,41001,'tibco.jms.inbound.queue.name','citi.gcg.gomth.cop_163124.th_card.epp.txnmodel.request');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value)
VALUES(41018,41001,'tibco.jms.queue.username','UAT_EPP_USR');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value)
VALUES(41019,41001,'tibco.jms.queue.password','');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value)
VALUES(41020,41001,'tibco.p12.enable','true');


INSERT INTO RTS3_APP_DS_EVENT(id, name, app_ds_id, event_type_code, description)
VALUES(41001, 'EPP_REQUEST_TH', 41001,'EPP_REQUEST_TH', 'TIBCO JMS Events');

INSERT INTO RTS3_EVENT_ACTION(id,app_event_id,action_type_code,exec_order)
VALUES(41001,41001,'PARSE_EVENT',1);

INSERT INTO RTS3_EVENT_ACTION(id,app_event_id,action_type_code,exec_order)
VALUES(41002,41001,'SAVE_MONGO',2);

INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name,param_value)
VALUES(41001,41002,'mongodb.uri','mongodb://eap_mongodb_uat:$PASSWORD@maas-gt-p72-m0002.nam.nsroot.net:37017,maas-sw-p72-m0001.nam.nsroot.net:37017,maas-mw-p72-m0001.nam.nsroot.net:37017/GCG_ASIA_TH?ssl=true&authSource=admin');
INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name,param_value)
VALUES(41002,41002,'mongodb.db.name','GCG_ASIA_TH');
INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name,param_value)
VALUES(41003,41002,'mongodb.collection.name','TXN_EPP_COP_Request');

INSERT INTO RTS3_EVENT_ACTION(id,app_event_id,action_type_code,exec_order)
VALUES(41003,41001,'CALL_PYTHON_CODE',3);

INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name,param_value)
VALUES(41027,41003,'mongodb.uri','mongodb://eap_mongodb_uat:$PASSWORD@maas-gt-p72-m0002.nam.nsroot.net:37017,maas-sw-p72-m0001.nam.nsroot.net:37017,maas-mw-p72-m0001.nam.nsroot.net:37017/GCG_ASIA_TH?ssl=true&authSource=admin');
INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name,param_value)
VALUES(41028,41003,'mongodb.db.name','GCG_ASIA_TH');
INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name,param_value)
VALUES(41029,41003,'mongodb.collection.name','EAP_EPP_TXN_SCORE');

INSERT INTO RTS3_EVENT_ACTION(id,app_event_id,action_type_code,exec_order)
VALUES(41004,41001,'PUB_TIBCO',4);

INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name,param_value)
VALUES(41004,41004,'INITIAL_CONTEXT_FACTORY','com.tibco.tibjms.naming.TibjmsInitialContextFactory');
INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name,param_value)
VALUES(41005,41004,'PROVIDER_URL', 'ssl://copuat2jndi.nam.nsroot.net:7245');
INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name,param_value)
VALUES(41006,41004,'com.tibco.tibjms.naming.ssl_identity', 'hdfs://gftsuat/user/gcgthasg/security/UAT_EAP_USR.ca1.p12');
INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name,param_value)
VALUES(41007,41004,'com.tibco.tibjms.naming.ssl_password', '');
INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name,param_value)
VALUES(41008,41004,'SECURITY_PRINCIPAL', 'UAT_EPP_USR');
INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name,param_value)
VALUES(41009,41004,'SECURITY_CREDENTIALS', '');
INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name,param_value)
VALUES(41010,41004,'com.tibco.tibjms.naming.security_protocol', 'ssl');
INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name,param_value)
VALUES(41011,41004,'com.tibco.tibjms.naming.ssl_enable_verify_host', 'false');
INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name,param_value)
VALUES(41012,41004,'com.tibco.tibjms.naming.ssl_vendor', 'j2se-default');
INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name,param_value)
VALUES(41013,41004,'com.sun.net.ssl.internal.ssl.Provider', 'j2se-default');
INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name,param_value)
VALUES(41014,41004,'com.tibco.tibjms.naming.ssl_auth_only', 'true');
INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name,param_value)
VALUES(41015,41004,'java.property.TIBCO_SECURITY_VENDOR','j2se-default');
INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name,param_value)
VALUES(41016,41004,'java.property.TIBCO_SECURITY_TRACE', 'false');
INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name,param_value)
VALUES(41017,41004,'com.tibco.tibjms.naming.ssl_debug_trace', 'true');
INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name,param_value)
VALUES(41018,41004,'com.tibco.tibjms.naming.ssl_trace','true');
INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name,param_value)
VALUES(41019,41004,'tibco.jms.queue.queueCF','G2C_EPPCOPTHBatchQueueConnectionFactory');
INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name,param_value)
VALUES(41020,41004,'tibco.jms.inbound.queue.name','citi.gcg.gomth.cop_163124.th_card.epp.txnmodel.response');
INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name,param_value)
VALUES(41021,41004,'tibco.jms.queue.username','UAT_EPP_USR');
INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name,param_value)
VALUES(41022,41004,'tibco.jms.queue.password','');
INSERT INTO RTS3_EVENT_ACTION_DETAIL(id, event_action_id, param_name, param_value)
VALUES(41023,41004,'tibco.p12.enable','true');


INSERT INTO RTS3_EVENT_ACTION(id,app_event_id,action_type_code,exec_order)
VALUES(41005,41001,'SAVE_FLAT_MONGO',5);

INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name,param_value)
VALUES(41024,41005,'mongodb.uri','mongodb://eap_mongodb_uat:$PASSWORD@maas-gt-p72-m0002.nam.nsroot.net:37017,maas-sw-p72-m0001.nam.nsroot.net:37017,maas-mw-p72-m0001.nam.nsroot.net:37017/GCG_ASIA_TH?ssl=true&authSource=admin');
INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name,param_value)
VALUES(41025,41005,'mongodb.db.name','GCG_ASIA_TH');
INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name,param_value)
VALUES(41026,41005,'mongodb.collection.name','TXN_EPP_COP_Response');


---------------------------------------------------------------------PH------------------------------------------------------------------------------
INSERT INTO RTS3_APPLICATION (id, name, tenant_id, description, void_ind)
VALUES(42001, 'EPP-PH', 10001, 'Extended Payment Plan', 'N');

INSERT INTO RTS3_APP_PARAM (id, param_type_code, app_id, param_name, param_value, description)
VALUES(42001, 'SPARK_CONF', 42001, 'spark.app.name', 'EPP Spark', null);
INSERT INTO RTS3_APP_PARAM (id, param_type_code, app_id, param_name, param_value, description)
VALUES(42002, 'APP_CONF', 42001, 'app.spark.duration', '300', 'milli-seconds');
INSERT INTO RTS3_APP_PARAM (id, param_type_code, app_id, param_name, param_value, description)
VALUES(42003, 'APP_CONF', 42001, 'app.spark.msg.broker.type', 'TIBCO', null);

INSERT INTO RTS3_APP_DS(id, name, app_id, ds_type_code, description,default_event)
VALUES(42001, 'EPP_PH', 42001,'TIBCO', 'EPP_PH DS' , 'EPP_REQUEST_PH');

INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value)
VALUES(42001,42001,'INITIAL_CONTEXT_FACTORY','com.tibco.tibjms.naming.TibjmsInitialContextFactory');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value)
VALUES(42002,42001,'PROVIDER_URL', 'ssl://copuat2jndi.nam.nsroot.net:7245');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value)
VALUES(42003,42001,'com.tibco.tibjms.naming.ssl_identity', 'hdfs://gftsuat/user/gcgphasg/security/UAT_EAP_USR.ca1.p12');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value)
VALUES(42004,42001,'com.tibco.tibjms.naming.ssl_password', '');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value)
VALUES(42005,42001,'SECURITY_PRINCIPAL', 'UAT_EPP_USR');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value)
VALUES(42006,42001,'SECURITY_CREDENTIALS', '');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value)
VALUES(42007,42001,'com.tibco.tibjms.naming.security_protocol', 'ssl');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value)
VALUES(42008,42001,'com.tibco.tibjms.naming.ssl_enable_verify_host', 'false');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value)
VALUES(42009,42001,'com.tibco.tibjms.naming.ssl_vendor', 'j2se-default');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value)
VALUES(42010,42001,'com.sun.net.ssl.internal.ssl.Provider', 'j2se-default');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value)
VALUES(42011,42001,'com.tibco.tibjms.naming.ssl_auth_only', 'true');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value)
VALUES(42012,42001,'java.property.TIBCO_SECURITY_VENDOR','j2se-default');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value)
VALUES(42013,42001,'java.property.TIBCO_SECURITY_TRACE', 'false');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value)
VALUES(42014,42001,'com.tibco.tibjms.naming.ssl_debug_trace', 'true');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value)
VALUES(42015,42001,'com.tibco.tibjms.naming.ssl_trace','true');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value)
VALUES(42016,42001,'tibco.jms.queue.queueCF','G2C_EPPCOPPHBatchQueueConnectionFactory');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value)
VALUES(42017,42001,'tibco.jms.inbound.queue.name','citi.gcg.gomph.cop_163124.ph_card.epp.txnmodel.request');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value)
VALUES(42018,42001,'tibco.jms.queue.username','UAT_EPP_USR');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value)
VALUES(42019,42001,'tibco.jms.queue.password','');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value)
VALUES(42020,42001,'tibco.p12.enable','true');


INSERT INTO RTS3_APP_DS_EVENT(id, name, app_ds_id, event_type_code, description)
VALUES(42001, 'EPP_REQUEST_PH', 42001,'EPP_REQUEST_PH', 'TIBCO JMS Events');

INSERT INTO RTS3_EVENT_ACTION(id,app_event_id,action_type_code,exec_order)
VALUES(42001,42001,'PARSE_EVENT',1);

INSERT INTO RTS3_EVENT_ACTION(id,app_event_id,action_type_code,exec_order)
VALUES(42002,42001,'SAVE_MONGO',2);

INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name,param_value)
VALUES(42001,42002,'mongodb.uri','mongodb://eap_mongodb_uat:$PASSWORD@maas-gt-p72-m0002.nam.nsroot.net:37017,maas-sw-p72-m0001.nam.nsroot.net:37017,maas-mw-p72-m0001.nam.nsroot.net:37017/GCG_ASIA_PH?ssl=true&authSource=admin');
INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name,param_value)
VALUES(42002,42002,'mongodb.db.name','GCG_ASIA_PH');
INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name,param_value)
VALUES(42003,42002,'mongodb.collection.name','TXN_EPP_COP_Request');

INSERT INTO RTS3_EVENT_ACTION(id,app_event_id,action_type_code,exec_order)
VALUES(42003,42001,'CALL_PYTHON_CODE',3);

INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name,param_value)
VALUES(42027,42003,'mongodb.uri','mongodb://eap_mongodb_uat:$PASSWORD@maas-gt-p72-m0002.nam.nsroot.net:37017,maas-sw-p72-m0001.nam.nsroot.net:37017,maas-mw-p72-m0001.nam.nsroot.net:37017/GCG_ASIA_PH?ssl=true&authSource=admin');
INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name,param_value)
VALUES(42028,42003,'mongodb.db.name','GCG_ASIA_PH');
INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name,param_value)
VALUES(42029,42003,'mongodb.collection.name','EAP_EPP_TXN_SCORE');

INSERT INTO RTS3_EVENT_ACTION(id,app_event_id,action_type_code,exec_order)
VALUES(42004,42001,'PUB_TIBCO',4);

INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name,param_value)
VALUES(42004,42004,'INITIAL_CONTEXT_FACTORY','com.tibco.tibjms.naming.TibjmsInitialContextFactory');
INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name,param_value)
VALUES(42005,42004,'PROVIDER_URL', 'ssl://copuat2jndi.nam.nsroot.net:7245');
INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name,param_value)
VALUES(42006,42004,'com.tibco.tibjms.naming.ssl_identity', 'hdfs://gftsuat/user/gcgphasg/security/UAT_EAP_USR.ca1.p12');
INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name,param_value)
VALUES(42007,42004,'com.tibco.tibjms.naming.ssl_password', '');
INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name,param_value)
VALUES(42008,42004,'SECURITY_PRINCIPAL', 'UAT_EPP_USR');
INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name,param_value)
VALUES(42009,42004,'SECURITY_CREDENTIALS', '');
INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name,param_value)
VALUES(42010,42004,'com.tibco.tibjms.naming.security_protocol', 'ssl');
INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name,param_value)
VALUES(42011,42004,'com.tibco.tibjms.naming.ssl_enable_verify_host', 'false');
INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name,param_value)
VALUES(42012,42004,'com.tibco.tibjms.naming.ssl_vendor', 'j2se-default');
INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name,param_value)
VALUES(42013,42004,'com.sun.net.ssl.internal.ssl.Provider', 'j2se-default');
INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name,param_value)
VALUES(42014,42004,'com.tibco.tibjms.naming.ssl_auth_only', 'true');
INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name,param_value)
VALUES(42015,42004,'java.property.TIBCO_SECURITY_VENDOR','j2se-default');
INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name,param_value)
VALUES(42016,42004,'java.property.TIBCO_SECURITY_TRACE', 'false');
INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name,param_value)
VALUES(42017,42004,'com.tibco.tibjms.naming.ssl_debug_trace', 'true');
INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name,param_value)
VALUES(42018,42004,'com.tibco.tibjms.naming.ssl_trace','true');
INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name,param_value)
VALUES(42019,42004,'tibco.jms.queue.queueCF','G2C_EPPCOPPHBatchQueueConnectionFactory');
INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name,param_value)
VALUES(42020,42004,'tibco.jms.inbound.queue.name','citi.gcg.gomth.cop_163124.th_card.epp.txnmodel.response');
INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name,param_value)
VALUES(42021,42004,'tibco.jms.queue.username','UAT_EPP_USR');
INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name,param_value)
VALUES(42022,42004,'tibco.jms.queue.password','');
INSERT INTO RTS3_EVENT_ACTION_DETAIL(id, event_action_id, param_name, param_value)
VALUES(42023,42004,'tibco.p12.enable','true');


INSERT INTO RTS3_EVENT_ACTION(id,app_event_id,action_type_code,exec_order)
VALUES(42005,42001,'SAVE_FLAT_MONGO',5);

INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name,param_value)
VALUES(42024,42005,'mongodb.uri','mongodb://eap_mongodb_uat:$PASSWORD@maas-gt-p72-m0002.nam.nsroot.net:37017,maas-sw-p72-m0001.nam.nsroot.net:37017,maas-mw-p72-m0001.nam.nsroot.net:37017/GCG_ASIA_PH?ssl=true&authSource=admin');
INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name,param_value)
VALUES(42025,42005,'mongodb.db.name','GCG_ASIA_PH');
INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name,param_value)
VALUES(42026,42005,'mongodb.collection.name','TXN_EPP_COP_Response');

-------------------------------------------------------------------------------------ID----------------------------------------------------------------------------------------
INSERT INTO RTS3_APPLICATION (id, name, tenant_id, description, void_ind)
VALUES(43001, 'EPP-ID', 10001, 'Extended Payment Plan', 'N');

INSERT INTO RTS3_APP_PARAM (id, param_type_code, app_id, param_name, param_value, description)
VALUES(43001, 'SPARK_CONF', 43001, 'spark.app.name', 'EPP Spark', null);
INSERT INTO RTS3_APP_PARAM (id, param_type_code, app_id, param_name, param_value, description)
VALUES(43002, 'APP_CONF', 43001, 'app.spark.duration', '300', 'milli-seconds');
INSERT INTO RTS3_APP_PARAM (id, param_type_code, app_id, param_name, param_value, description)
VALUES(43003, 'APP_CONF', 43001, 'app.spark.msg.broker.type', 'TIBCO', null);

INSERT INTO RTS3_APP_DS(id, name, app_id, ds_type_code, description,default_event)
VALUES(43001, 'EPP_ID', 43001,'TIBCO', 'EPP_ID DS' , 'EPP_REQUEST_ID');

INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value)
VALUES(43001,43001,'INITIAL_CONTEXT_FACTORY','com.tibco.tibjms.naming.TibjmsInitialContextFactory');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value)
VALUES(43002,43001,'PROVIDER_URL', 'ssl://copuat2jndi.nam.nsroot.net:7245');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value)
VALUES(43003,43001,'com.tibco.tibjms.naming.ssl_identity', 'hdfs://gftsuat/user/gcgidasg/security/UAT_EAP_USR.ca1.p12');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value)
VALUES(43004,43001,'com.tibco.tibjms.naming.ssl_password', '');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value)
VALUES(43005,43001,'SECURITY_PRINCIPAL', 'UAT_EPP_USR');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value)
VALUES(43006,43001,'SECURITY_CREDENTIALS', '');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value)
VALUES(43007,43001,'com.tibco.tibjms.naming.security_protocol', 'ssl');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value)
VALUES(43008,43001,'com.tibco.tibjms.naming.ssl_enable_verify_host', 'false');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value)
VALUES(43009,43001,'com.tibco.tibjms.naming.ssl_vendor', 'j2se-default');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value)
VALUES(43010,43001,'com.sun.net.ssl.internal.ssl.Provider', 'j2se-default');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value)
VALUES(43011,43001,'com.tibco.tibjms.naming.ssl_auth_only', 'true');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value)
VALUES(43012,43001,'java.property.TIBCO_SECURITY_VENDOR','j2se-default');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value)
VALUES(43013,43001,'java.property.TIBCO_SECURITY_TRACE', 'false');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value)
VALUES(43014,43001,'com.tibco.tibjms.naming.ssl_debug_trace', 'true');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value)
VALUES(43015,43001,'com.tibco.tibjms.naming.ssl_trace','true');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value)
VALUES(43016,43001,'tibco.jms.queue.queueCF','G2C_EPPCOPIDBatchQueueConnectionFactory');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value)
VALUES(43017,43001,'tibco.jms.inbound.queue.name','citi.gcg.gomid.cop_163124.id_card.epp.txnmodel.request');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value)
VALUES(43018,43001,'tibco.jms.queue.username','UAT_EPP_USR');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value)
VALUES(43019,43001,'tibco.jms.queue.password','');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value)
VALUES(43020,43001,'tibco.p12.enable','true');


INSERT INTO RTS3_APP_DS_EVENT(id, name, app_ds_id, event_type_code, description)
VALUES(43001, 'EPP_REQUEST_ID', 43001,'EPP_REQUEST_ID', 'TIBCO JMS Events');

INSERT INTO RTS3_EVENT_ACTION(id,app_event_id,action_type_code,exec_order)
VALUES(43001,43001,'PARSE_EVENT',1);

INSERT INTO RTS3_EVENT_ACTION(id,app_event_id,action_type_code,exec_order)
VALUES(43002,43001,'SAVE_MONGO',2);

INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name,param_value)
VALUES(43001,43002,'mongodb.uri','mongodb://eap_mongodb_uat:$PASSWORD@maas-gt-p72-m0002.nam.nsroot.net:37017,maas-sw-p72-m0001.nam.nsroot.net:37017,maas-mw-p72-m0001.nam.nsroot.net:37017/GCG_ASIA_ID?ssl=true&authSource=admin');
INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name,param_value)
VALUES(43002,43002,'mongodb.db.name','GCG_ASIA_ID');
INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name,param_value)
VALUES(43003,43002,'mongodb.collection.name','TXN_EPP_COP_Request');

INSERT INTO RTS3_EVENT_ACTION(id,app_event_id,action_type_code,exec_order)
VALUES(43003,43001,'CALL_PYTHON_CODE',3);

INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name,param_value)
VALUES(43027,43003,'mongodb.uri','mongodb://eap_mongodb_uat:$PASSWORD@maas-gt-p72-m0002.nam.nsroot.net:37017,maas-sw-p72-m0001.nam.nsroot.net:37017,maas-mw-p72-m0001.nam.nsroot.net:37017/GCG_ASIA_ID?ssl=true&authSource=admin');
INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name,param_value)
VALUES(43028,43003,'mongodb.db.name','GCG_ASIA_ID');
INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name,param_value)
VALUES(43029,43003,'mongodb.collection.name','EAP_EPP_TXN_SCORE');

INSERT INTO RTS3_EVENT_ACTION(id,app_event_id,action_type_code,exec_order)
VALUES(43004,43001,'PUB_TIBCO',4);

INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name,param_value)
VALUES(43004,43004,'INITIAL_CONTEXT_FACTORY','com.tibco.tibjms.naming.TibjmsInitialContextFactory');
INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name,param_value)
VALUES(43005,43004,'PROVIDER_URL', 'ssl://copuat2jndi.nam.nsroot.net:7245');
INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name,param_value)
VALUES(43006,43004,'com.tibco.tibjms.naming.ssl_identity', 'hdfs://gftsuat/user/gcgidasg/security/UAT_EAP_USR.ca1.p12');
INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name,param_value)
VALUES(43007,43004,'com.tibco.tibjms.naming.ssl_password', '');
INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name,param_value)
VALUES(43008,43004,'SECURITY_PRINCIPAL', 'UAT_EPP_USR');
INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name,param_value)
VALUES(43009,43004,'SECURITY_CREDENTIALS', '');
INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name,param_value)
VALUES(43010,43004,'com.tibco.tibjms.naming.security_protocol', 'ssl');
INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name,param_value)
VALUES(43011,43004,'com.tibco.tibjms.naming.ssl_enable_verify_host', 'false');
INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name,param_value)
VALUES(43012,43004,'com.tibco.tibjms.naming.ssl_vendor', 'j2se-default');
INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name,param_value)
VALUES(43013,43004,'com.sun.net.ssl.internal.ssl.Provider', 'j2se-default');
INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name,param_value)
VALUES(43014,43004,'com.tibco.tibjms.naming.ssl_auth_only', 'true');
INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name,param_value)
VALUES(43015,43004,'java.property.TIBCO_SECURITY_VENDOR','j2se-default');
INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name,param_value)
VALUES(43016,43004,'java.property.TIBCO_SECURITY_TRACE', 'false');
INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name,param_value)
VALUES(43017,43004,'com.tibco.tibjms.naming.ssl_debug_trace', 'true');
INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name,param_value)
VALUES(43018,43004,'com.tibco.tibjms.naming.ssl_trace','true');
INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name,param_value)
VALUES(43019,43004,'tibco.jms.queue.queueCF','G2C_EPPCOPIDBatchQueueConnectionFactory');
INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name,param_value)
VALUES(43020,43004,'tibco.jms.inbound.queue.name','citi.gcg.gomth.cop_163124.th_card.epp.txnmodel.response');
INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name,param_value)
VALUES(43021,43004,'tibco.jms.queue.username','UAT_EPP_USR');
INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name,param_value)
VALUES(43022,43004,'tibco.jms.queue.password','');
INSERT INTO RTS3_EVENT_ACTION_DETAIL(id, event_action_id, param_name, param_value)
VALUES(43023,43004,'tibco.p12.enable','true');


INSERT INTO RTS3_EVENT_ACTION(id,app_event_id,action_type_code,exec_order)
VALUES(43005,43001,'SAVE_FLAT_MONGO',5);

INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name,param_value)
VALUES(43024,43005,'mongodb.uri','mongodb://eap_mongodb_uat:$PASSWORD@maas-gt-p72-m0002.nam.nsroot.net:37017,maas-sw-p72-m0001.nam.nsroot.net:37017,maas-mw-p72-m0001.nam.nsroot.net:37017/GCG_ASIA_ID?ssl=true&authSource=admin');
INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name,param_value)
VALUES(43025,43005,'mongodb.db.name','GCG_ASIA_ID');
INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name,param_value)
VALUES(43026,43005,'mongodb.collection.name','TXN_EPP_COP_Response');