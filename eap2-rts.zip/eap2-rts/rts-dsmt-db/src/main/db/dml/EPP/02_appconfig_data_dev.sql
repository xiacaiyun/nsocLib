INSERT INTO RTS3_APPLICATION (id, name, tenant_id, description, void_ind)
VALUES(40001, 'EPP-MY', 10001, 'Extended Payment Plan', 'N');

INSERT INTO RTS3_APP_PARAM (id, param_type_code, app_id, param_name, param_value, description)
VALUES(40001, 'SPARK_CONF', 40001, 'spark.app.name', 'EPP Spark', null);
INSERT INTO RTS3_APP_PARAM (id, param_type_code, app_id, param_name, param_value, description)
VALUES(40002, 'APP_CONF', 40001, 'app.spark.duration', '300', 'milli-seconds');
INSERT INTO RTS3_APP_PARAM (id, param_type_code, app_id, param_name, param_value, description)
VALUES(40003, 'APP_CONF', 40001, 'app.spark.msg.broker.type', 'TIBCO', null);

INSERT INTO RTS3_APP_DS(id, name, app_id, ds_type_code, description,default_event)
VALUES(40001, 'EPP_MY', 40001,'TIBCO', 'EPP_MY DS' , 'EPP_REQUEST_MY');

INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(40001,40001,'INITIAL_CONTEXT_FACTORY','com.tibco.tibjms.naming.TibjmsInitialContextFactory','N');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(40002,40001,'PROVIDER_URL', 'ssl://gpd-ed9-5c7e.nam.nsroot.net:7243','N');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(40003,40001,'com.tibco.tibjms.naming.ssl_identity', 'hdfs://gftsdev/user/gcgdmasg/security/DIT_EAP_USR.ca1.p12','N');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(40004,40001,'com.tibco.tibjms.naming.ssl_password', 'CZfUOw6Rr9RNtmVYgmAKdA==','Y');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(40005,40001,'SECURITY_PRINCIPAL', 'SIT_EPP_USR','N');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(40006,40001,'SECURITY_CREDENTIALS', 'CZfUOw6Rr9RNtmVYgmAKdA==','Y');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(40007,40001,'com.tibco.tibjms.naming.security_protocol', 'ssl','N');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(40008,40001,'com.tibco.tibjms.naming.ssl_enable_verify_host', 'false','N');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(40009,40001,'com.tibco.tibjms.naming.ssl_vendor', 'j2se-default','N');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(40010,40001,'com.sun.net.ssl.internal.ssl.Provider', 'j2se-default','N');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(40011,40001,'com.tibco.tibjms.naming.ssl_auth_only', 'true','N');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(40012,40001,'java.property.TIBCO_SECURITY_VENDOR','j2se-default','N');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(40013,40001,'java.property.TIBCO_SECURITY_TRACE', 'false','N');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(40014,40001,'com.tibco.tibjms.naming.ssl_debug_trace', 'true','N');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(40015,40001,'com.tibco.tibjms.naming.ssl_trace','true','N');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(40016,40001,'tibco.jms.queue.queueCF','G2C_EPPCOPTHMYBatchQueueConnectionFactory','N');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(40017,40001,'tibco.jms.inbound.queue.name','citi.gcg.gommy.cop_163124.my_card.epp.txnmodel.request','N');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(40018,40001,'tibco.jms.queue.username','SIT_EPP_USR','N');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(40019,40001,'tibco.jms.queue.password','CZfUOw6Rr9RNtmVYgmAKdA==','Y');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(40020,40001,'tibco.p12.enable','true','N');

INSERT INTO RTS3_APP_DS_EVENT(id, name, app_ds_id, event_type_code, description)
VALUES(40001, 'EPP_REQUEST_MY', 40001,'EPP_REQUEST_MY', 'TIBCO JMS Events');

INSERT INTO RTS3_EVENT_ACTION(id,app_event_id,action_type_code,exec_order)
VALUES(40001,40001,'PARSE_EVENT',1);

INSERT INTO RTS3_EVENT_ACTION(id,app_event_id,action_type_code,exec_order)
VALUES(40002,40001,'SAVE_MONGO',2);

INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name, param_value,value_encrypted)
VALUES(40001,40002,'mongodb.uri','mongodb://admin_mongodb:P5MwnVbm@maas-mw-d5-u0037.nam.nsroot.net:37017,maas-gt-d5-u0025.nam.nsroot.net:37017,maas-sw-d5-u0007.nam.nsroot.net:37017/GCG_ASIA_MY?ssl=true&authSource=admin','N');
INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name, param_value,value_encrypted)
VALUES(40002,40002,'mongodb.db.name','GCG_ASIA_MY','N');
INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name, param_value,value_encrypted)
VALUES(40003,40002,'mongodb.collection.name','GCG_ASIA_MY.TXN_EPP_COP_Request','N');
INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name,param_value,value_encrypted)
VALUES(40030,40002,'mongodb.db.password','cZNjPmJtqQ0wDFs2DNZsZw==','Y');

INSERT INTO RTS3_EVENT_ACTION(id,app_event_id,action_type_code,exec_order)
VALUES(40003,40001,'CALL_PYTHON_CODE',3);

INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name, param_value,value_encrypted)
VALUES(40027,40003,'mongodb.uri','mongodb://admin_mongodb:P5MwnVbm@maas-mw-d5-u0037.nam.nsroot.net:37017,maas-gt-d5-u0025.nam.nsroot.net:37017,maas-sw-d5-u0007.nam.nsroot.net:37017/GCG_ASIA_MY?ssl=true&authSource=admin','N');
INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name, param_value,value_encrypted)
VALUES(40028,40003,'mongodb.db.name','GCG_ASIA_MY','N');
INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name, param_value,value_encrypted)
VALUES(40029,40003,'mongodb.collection.name','EAP_EPP_TXN_SCORE','N');
INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name,param_value,value_encrypted)
VALUES(40031,40003,'mongodb.db.password','cZNjPmJtqQ0wDFs2DNZsZw==','Y');

INSERT INTO RTS3_EVENT_ACTION(id,app_event_id,action_type_code,exec_order)
VALUES(40004,40001,'PUB_TIBCO',4);

INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name, param_value,value_encrypted)
VALUES(40004,40004,'INITIAL_CONTEXT_FACTORY','com.tibco.tibjms.naming.TibjmsInitialContextFactory','N');
INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name, param_value,value_encrypted)
VALUES(40005,40004,'PROVIDER_URL', 'ssl://gpd-ed9-5c7e.nam.nsroot.net:7243','N');
INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name, param_value,value_encrypted)
VALUES(40006,40004,'com.tibco.tibjms.naming.ssl_identity', 'hdfs://gftsdev/user/gcgdmasg/security/DIT_EAP_USR.ca1.p12','N');
INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name, param_value,value_encrypted)
VALUES(40007,40004,'com.tibco.tibjms.naming.ssl_password', 'CZfUOw6Rr9RNtmVYgmAKdA==','Y');
INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name, param_value,value_encrypted)
VALUES(40008,40004,'SECURITY_PRINCIPAL', 'SIT_EPP_USR','N');
INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name, param_value,value_encrypted)
VALUES(40009,40004,'SECURITY_CREDENTIALS', 'CZfUOw6Rr9RNtmVYgmAKdA==','Y');
INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name, param_value,value_encrypted)
VALUES(40010,40004,'com.tibco.tibjms.naming.security_protocol', 'ssl','N');
INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name, param_value,value_encrypted)
VALUES(40011,40004,'com.tibco.tibjms.naming.ssl_enable_verify_host', 'false','N');
INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name, param_value,value_encrypted)
VALUES(40012,40004,'com.tibco.tibjms.naming.ssl_vendor', 'j2se-default','N');
INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name, param_value,value_encrypted)
VALUES(40013,40004,'com.sun.net.ssl.internal.ssl.Provider', 'j2se-default','N');
INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name, param_value,value_encrypted)
VALUES(40014,40004,'com.tibco.tibjms.naming.ssl_auth_only', 'true','N');
INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name, param_value,value_encrypted)
VALUES(40015,40004,'java.property.TIBCO_SECURITY_VENDOR','j2se-default','N');
INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name, param_value,value_encrypted)
VALUES(40016,40004,'java.property.TIBCO_SECURITY_TRACE', 'false','N');
INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name, param_value,value_encrypted)
VALUES(40017,40004,'com.tibco.tibjms.naming.ssl_debug_trace', 'true','N');
INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name, param_value,value_encrypted)
VALUES(40018,40004,'com.tibco.tibjms.naming.ssl_trace','true','N');
INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name, param_value,value_encrypted)
VALUES(40019,40004,'tibco.jms.queue.queueCF','G2C_EPPCOPTHMYBatchQueueConnectionFactory','N');
INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name, param_value,value_encrypted)
VALUES(40020,40004,'tibco.jms.inbound.queue.name','citi.gcg.gommy.cop_163124.my_card.epp.txnmodel.response','N');
INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name, param_value,value_encrypted)
VALUES(40021,40004,'tibco.jms.queue.username','SIT_EPP_USR','N');
INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name, param_value,value_encrypted)
VALUES(40022,40004,'tibco.jms.queue.password','CZfUOw6Rr9RNtmVYgmAKdA==','Y');
INSERT INTO RTS3_EVENT_ACTION_DETAIL(id, event_action_id, param_name, param_value,value_encrypted)
VALUES(40023,40004,'tibco.p12.enable','true','N');

INSERT INTO RTS3_EVENT_ACTION(id,app_event_id,action_type_code,exec_order)
VALUES(40005,40001,'SAVE_FLAT_MONGO',5);

INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name, param_value,value_encrypted)
VALUES(40024,40005,'mongodb.uri','mongodb://admin_mongodb:P5MwnVbm@maas-mw-d5-u0037.nam.nsroot.net:37017,maas-gt-d5-u0025.nam.nsroot.net:37017,maas-sw-d5-u0007.nam.nsroot.net:37017/GCG_ASIA_MY?ssl=true&authSource=admin','N');
INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name, param_value,value_encrypted)
VALUES(40025,40005,'mongodb.db.name','GCG_ASIA_MY','N');
INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name, param_value,value_encrypted)
VALUES(40026,40005,'mongodb.collection.name','GCG_ASIA_MY.TXN_EPP_COP_Response','N');
INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name,param_value,value_encrypted)
VALUES(40032,40005,'mongodb.db.password','cZNjPmJtqQ0wDFs2DNZsZw==','Y');
---------------------------------------------------------------HK---------------------------------------------------------------
INSERT INTO RTS3_APPLICATION (id, name, tenant_id, description, void_ind)
VALUES(41001, 'EPP_EAP_HK', 10001, 'EAP Model Offer', 'N');

INSERT INTO RTS3_APP_PARAM (id, param_type_code, app_id, param_name, param_value, description)
VALUES(41001, 'SPARK_CONF', 41001, 'spark.app.name', 'EPP Spark', null);
INSERT INTO RTS3_APP_PARAM (id, param_type_code, app_id, param_name, param_value, description)
VALUES(41002, 'APP_CONF', 41001, 'app.spark.duration', '300', 'milli-seconds');
INSERT INTO RTS3_APP_PARAM (id, param_type_code, app_id, param_name, param_value, description)
VALUES(41003, 'APP_CONF', 41001, 'app.spark.msg.broker.type', 'TIBCO', null);

INSERT INTO RTS3_APP_DS(id, name, app_id, ds_type_code, description,default_event)
VALUES(41001, 'EPP_MO_HK', 41001,'TIBCO', 'EPP_MO_HK DS' , 'EAPModelOffer');

INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(41001,41001,'INITIAL_CONTEXT_FACTORY','com.tibco.tibjms.naming.TibjmsInitialContextFactory','N');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(41002,41001,'PROVIDER_URL', 'ssl://gpd-ed9-5c7e.nam.nsroot.net:7243','N');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(41003,41001,'com.tibco.tibjms.naming.ssl_identity', 'hdfs://gftsdev/user/gcgdmasg/security/DIT_EAP_USR.ca1.p12','N');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(41004,41001,'com.tibco.tibjms.naming.ssl_password', '','N');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(41005,41001,'SECURITY_PRINCIPAL', 'SIT_EAP_USR','N');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(41006,41001,'SECURITY_CREDENTIALS', 'citi1234','N');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(41007,41001,'com.tibco.tibjms.naming.security_protocol', 'ssl','N');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(41008,41001,'com.tibco.tibjms.naming.ssl_enable_verify_host', 'false','N');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(41009,41001,'com.tibco.tibjms.naming.ssl_vendor', 'j2se-default','N');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(41010,41001,'com.sun.net.ssl.internal.ssl.Provider', 'j2se-default','N');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(41011,41001,'com.tibco.tibjms.naming.ssl_auth_only', 'true','N');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(41012,41001,'java.property.TIBCO_SECURITY_VENDOR','j2se-default','N');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(41013,41001,'java.property.TIBCO_SECURITY_TRACE', 'false','N');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(41014,41001,'com.tibco.tibjms.naming.ssl_debug_trace', 'true','N');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(41015,41001,'com.tibco.tibjms.naming.ssl_trace','true','N');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(41016,41001,'tibco.jms.queue.queueCF','G2C_EAPCOPHKBatchQueueConnectionFactory','N');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(41017,41001,'tibco.jms.inbound.queue.name','citi.gcg.gomhk.cop_163124.hk_card.epp.modeloffer.error','N');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(41018,41001,'tibco.jms.queue.username','SIT_EAP_USR','N');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(41019,41001,'tibco.jms.queue.password','citi1234','N');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(41020,41001,'tibco.p12.enable','true','N');

INSERT INTO RTS3_APP_DS_EVENT(id, name, app_ds_id, event_type_code, description)
VALUES(41001, 'EAPModelOffer', 41001,'EAPModelOffer', 'TIBCO JMS Events');

INSERT INTO RTS3_EVENT_ACTION(id,app_event_id,action_type_code,exec_order)
VALUES(41001,41001,'PARSE_EVENT',1);

INSERT INTO RTS3_EVENT_ACTION(id,app_event_id,action_type_code,exec_order)
VALUES(41002,41001,'SAVE_MONGO',2);

INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name, param_value,value_encrypted)
VALUES(41001,41002,'mongodb.uri','mongodb://admin_mongodb:P5MwnVbm@maas-mw-d5-u0037.nam.nsroot.net:37017,maas-gt-d5-u0025.nam.nsroot.net:37017,maas-sw-d5-u0007.nam.nsroot.net:37017/GCG_ASIA_HK?ssl=true&authSource=admin','N');
INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name, param_value,value_encrypted)
VALUES(41002,41002,'mongodb.db.name','GCG_ASIA_HK','N');
INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name, param_value,value_encrypted)
VALUES(41003,41002,'mongodb.collection.name','EAP_EPP_COP_MODEL_OFR','N');
INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name,param_value,value_encrypted)
VALUES(41004,41002,'mongodb.db.password','cZNjPmJtqQ0wDFs2DNZsZw==','Y');

INSERT INTO RTS3_APP_DS(id, name, app_id, ds_type_code, description,default_event)
VALUES(41002, 'EPP_POT_HK', 41001,'TIBCO', 'EPP_POT_HK DS' , 'EAPProdOfferTemplate');

INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(41021,41002,'INITIAL_CONTEXT_FACTORY','com.tibco.tibjms.naming.TibjmsInitialContextFactory','N');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(41022,41002,'PROVIDER_URL', 'ssl://gpd-ed9-5c7e.nam.nsroot.net:7243','N');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(41023,41002,'com.tibco.tibjms.naming.ssl_identity', 'hdfs://gftsdev/user/gcgdmasg/security/DIT_EAP_USR.ca1.p12','N');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(41024,41002,'com.tibco.tibjms.naming.ssl_password', '','N');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(41025,41002,'SECURITY_PRINCIPAL', 'SIT_EAP_USR','N');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(41026,41002,'SECURITY_CREDENTIALS', 'citi1234','N');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(41027,41002,'com.tibco.tibjms.naming.security_protocol', 'ssl','N');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(41028,41002,'com.tibco.tibjms.naming.ssl_enable_verify_host', 'false','N');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(41029,41002,'com.tibco.tibjms.naming.ssl_vendor', 'j2se-default','N');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(41030,41002,'com.sun.net.ssl.internal.ssl.Provider', 'j2se-default','N');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(41031,41002,'com.tibco.tibjms.naming.ssl_auth_only', 'true','N');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(41032,41002,'java.property.TIBCO_SECURITY_VENDOR','j2se-default','N');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(41033,41002,'java.property.TIBCO_SECURITY_TRACE', 'false','N');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(41034,41002,'com.tibco.tibjms.naming.ssl_debug_trace', 'true','N');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(41035,41002,'com.tibco.tibjms.naming.ssl_trace','true','N');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(41036,41002,'tibco.jms.queue.queueCF','G2C_EAPCOPHKBatchQueueConnectionFactory','N');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(41037,41002,'tibco.jms.inbound.queue.name','citi.gcg.gomhk.cop_163124.hk_card.epp.prodoffertemplate.update','N');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(41038,41002,'tibco.jms.queue.username','SIT_EAP_USR','N');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(41039,41002,'tibco.jms.queue.password','citi1234','N');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(41040,41002,'tibco.p12.enable','true','N');

INSERT INTO RTS3_APP_DS_EVENT(id, name, app_ds_id, event_type_code, description)
VALUES(41002, 'EAPProdOfferTemplate', 41002,'EAPProdOfferTemplate', 'TIBCO JMS Events');

INSERT INTO RTS3_EVENT_ACTION(id,app_event_id,action_type_code,exec_order)
VALUES(41003,41002,'PARSE_EVENT',1);

INSERT INTO RTS3_EVENT_ACTION(id,app_event_id,action_type_code,exec_order)
VALUES(41004,41002,'SAVE_MONGO',2);

INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name, param_value,value_encrypted)
VALUES(41005,41004,'mongodb.uri','mongodb://admin_mongodb:P5MwnVbm@maas-mw-d5-u0037.nam.nsroot.net:37017,maas-gt-d5-u0025.nam.nsroot.net:37017,maas-sw-d5-u0007.nam.nsroot.net:37017/GCG_ASIA_HK?ssl=true&authSource=admin','N');
INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name, param_value,value_encrypted)
VALUES(41006,41004,'mongodb.db.name','GCG_ASIA_HK','N');
INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name, param_value,value_encrypted)
VALUES(41007,41004,'mongodb.collection.name','EAP_EPP_COP_PROD_OFR_TEMPLATE','N');
INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name,param_value,value_encrypted)
VALUES(41008,41004,'mongodb.db.password','cZNjPmJtqQ0wDFs2DNZsZw==','Y');

INSERT INTO RTS3_APP_DS(id, name, app_id, ds_type_code, description,default_event)
VALUES(41003, 'EPP_TT_HK', 41001,'TIBCO', 'EPP_TT_HK DS' , 'EAPTreatmentTemplate');

INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(41041,41003,'INITIAL_CONTEXT_FACTORY','com.tibco.tibjms.naming.TibjmsInitialContextFactory','N');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(41042,41003,'PROVIDER_URL', 'ssl://gpd-ed9-5c7e.nam.nsroot.net:7243','N');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(41043,41003,'com.tibco.tibjms.naming.ssl_identity', 'hdfs://gftsdev/user/gcgdmasg/security/DIT_EAP_USR.ca1.p12','N');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(41044,41003,'com.tibco.tibjms.naming.ssl_password', '','N');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(41045,41003,'SECURITY_PRINCIPAL', 'SIT_EAP_USR','N');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(41046,41003,'SECURITY_CREDENTIALS', 'citi1234','N');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(41047,41003,'com.tibco.tibjms.naming.security_protocol', 'ssl','N');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(41048,41003,'com.tibco.tibjms.naming.ssl_enable_verify_host', 'false','N');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(41049,41003,'com.tibco.tibjms.naming.ssl_vendor', 'j2se-default','N');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(41050,41003,'com.sun.net.ssl.internal.ssl.Provider', 'j2se-default','N');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(41051,41003,'com.tibco.tibjms.naming.ssl_auth_only', 'true','N');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(41052,41003,'java.property.TIBCO_SECURITY_VENDOR','j2se-default','N');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(41053,41003,'java.property.TIBCO_SECURITY_TRACE', 'false','N');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(41054,41003,'com.tibco.tibjms.naming.ssl_debug_trace', 'true','N');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(41055,41003,'com.tibco.tibjms.naming.ssl_trace','true','N');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(41056,41003,'tibco.jms.queue.queueCF','G2C_EAPCOPHKBatchQueueConnectionFactory','N');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(41057,41003,'tibco.jms.inbound.queue.name','citi.gcg.gomhk.cop_163124.hk_card.epp.treatmenttemplate.update','N');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(41058,41003,'tibco.jms.queue.username','SIT_EAP_USR','N');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(41059,41003,'tibco.jms.queue.password','citi1234','N');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(41060,41003,'tibco.p12.enable','true','N');

INSERT INTO RTS3_APP_DS_EVENT(id, name, app_ds_id, event_type_code, description)
VALUES(41003, 'EAPTreatmentTemplate', 41003,'EAPTreatmentTemplate', 'TIBCO JMS Events');

INSERT INTO RTS3_EVENT_ACTION(id,app_event_id,action_type_code,exec_order)
VALUES(41005,41003,'PARSE_EVENT',1);

INSERT INTO RTS3_EVENT_ACTION(id,app_event_id,action_type_code,exec_order)
VALUES(41006,41003,'SAVE_MONGO',2);

INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name, param_value,value_encrypted)
VALUES(41009,41006,'mongodb.uri','mongodb://admin_mongodb:P5MwnVbm@maas-mw-d5-u0037.nam.nsroot.net:37017,maas-gt-d5-u0025.nam.nsroot.net:37017,maas-sw-d5-u0007.nam.nsroot.net:37017/GCG_ASIA_HK?ssl=true&authSource=admin','N');
INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name, param_value,value_encrypted)
VALUES(41010,41006,'mongodb.db.name','GCG_ASIA_HK','N');
INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name, param_value,value_encrypted)
VALUES(41011,41006,'mongodb.collection.name','EAP_EPP_COP_TRT_TEMPLATE','N');
INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name,param_value,value_encrypted)
VALUES(41012,41006,'mongodb.db.password','cZNjPmJtqQ0wDFs2DNZsZw==','Y');


INSERT INTO RTS3_APP_DS(id, name, app_id, ds_type_code, description,default_event)
VALUES(41004, 'EPP_UOF_HK', 41001,'TIBCO', 'EPP_UOF_HK DS' , 'UpdateOfferFullfillmentEapRequest');

INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(41061,41004,'INITIAL_CONTEXT_FACTORY','com.tibco.tibjms.naming.TibjmsInitialContextFactory','N');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(41062,41004,'PROVIDER_URL', 'ssl://gpd-ed9-5c7e.nam.nsroot.net:7243','N');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(41063,41004,'com.tibco.tibjms.naming.ssl_identity', 'hdfs://gftsdev/user/gcgdmasg/security/DIT_EAP_USR.ca1.p12','N');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(41064,41004,'com.tibco.tibjms.naming.ssl_password', '','N');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(41065,41004,'SECURITY_PRINCIPAL', 'SIT_EAP_USR','N');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(41066,41004,'SECURITY_CREDENTIALS', 'citi1234','N');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(41067,41004,'com.tibco.tibjms.naming.security_protocol', 'ssl','N');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(41068,41004,'com.tibco.tibjms.naming.ssl_enable_verify_host', 'false','N');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(41069,41004,'com.tibco.tibjms.naming.ssl_vendor', 'j2se-default','N');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(41070,41004,'com.sun.net.ssl.internal.ssl.Provider', 'j2se-default','N');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(41071,41004,'com.tibco.tibjms.naming.ssl_auth_only', 'true','N');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(41072,41004,'java.property.TIBCO_SECURITY_VENDOR','j2se-default','N');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(41073,41004,'java.property.TIBCO_SECURITY_TRACE', 'false','N');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(41074,41004,'com.tibco.tibjms.naming.ssl_debug_trace', 'true','N');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(41075,41004,'com.tibco.tibjms.naming.ssl_trace','true','N');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(41076,41004,'tibco.jms.queue.queueCF','G2C_EAPCOPHKBatchQueueConnectionFactory','N');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(41077,41004,'tibco.jms.inbound.queue.name','citi.gcg.gomhk.cop_163124.hk_card.offerfulfillment.modelrequest','N');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(41078,41004,'tibco.jms.queue.username','SIT_EAP_USR','N');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(41079,41004,'tibco.jms.queue.password','citi1234','N');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(41080,41004,'tibco.p12.enable','true','N');

INSERT INTO RTS3_APP_DS_EVENT(id, name, app_ds_id, event_type_code, description)
VALUES(41004, 'UpdateOfferFullfillmentEapRequest', 41004,'UpdateOfferFullfillmentEapRequest', 'TIBCO JMS Events');

INSERT INTO RTS3_EVENT_ACTION(id,app_event_id,action_type_code,exec_order)
VALUES(41007,41004,'PARSE_EVENT',1);

INSERT INTO RTS3_EVENT_ACTION(id,app_event_id,action_type_code,exec_order)
VALUES(41008,41004,'SAVE_MONGO',2);

INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name, param_value,value_encrypted)
VALUES(41013,41008,'mongodb.uri','mongodb://admin_mongodb:P5MwnVbm@maas-mw-d5-u0037.nam.nsroot.net:37017,maas-gt-d5-u0025.nam.nsroot.net:37017,maas-sw-d5-u0007.nam.nsroot.net:37017/GCG_ASIA_HK?ssl=true&authSource=admin','N');
INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name, param_value,value_encrypted)
VALUES(41014,41008,'mongodb.db.name','GCG_ASIA_HK','N');
INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name, param_value,value_encrypted)
VALUES(41015,41008,'mongodb.collection.name','EAP_EPP_COP_OFR_FULFILLMENT','N');
INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name,param_value,value_encrypted)
VALUES(41016,41008,'mongodb.db.password','cZNjPmJtqQ0wDFs2DNZsZw==','Y');



-----------------------------------------------------------------------------------AU----------------------------------------------------------------------------

INSERT INTO RTS3_APPLICATION (id, name, tenant_id, description, void_ind)
VALUES(42001, 'EPP_EAP_AU', 10001, 'EAP Model Offer', 'N');

INSERT INTO RTS3_APP_PARAM (id, param_type_code, app_id, param_name, param_value, description)
VALUES(42001, 'SPARK_CONF', 42001, 'spark.app.name', 'EPP Spark', null);
INSERT INTO RTS3_APP_PARAM (id, param_type_code, app_id, param_name, param_value, description)
VALUES(42002, 'APP_CONF', 42001, 'app.spark.duration', '300', 'milli-seconds');
INSERT INTO RTS3_APP_PARAM (id, param_type_code, app_id, param_name, param_value, description)
VALUES(42003, 'APP_CONF', 42001, 'app.spark.msg.broker.type', 'TIBCO', null);

INSERT INTO RTS3_APP_DS(id, name, app_id, ds_type_code, description,default_event)
VALUES(42001, 'EPP_MO_AU', 42001,'TIBCO', 'EPP_MO_AU DS' , 'EAPModelOffer');

INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(42001,42001,'INITIAL_CONTEXT_FACTORY','com.tibco.tibjms.naming.TibjmsInitialContextFactory','N');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(42002,42001,'PROVIDER_URL', 'ssl://gpd-ed9-5c7e.nam.nsroot.net:7243','N');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(42003,42001,'com.tibco.tibjms.naming.ssl_identity', 'hdfs://gftsdev/user/gcgdmasg/security/DIT_EAP_USR.ca1.p12','N');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(42004,42001,'com.tibco.tibjms.naming.ssl_password', '','N');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(42005,42001,'SECURITY_PRINCIPAL', 'SIT_EAP_USR','N');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(42006,42001,'SECURITY_CREDENTIALS', 'citi1234','N');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(42007,42001,'com.tibco.tibjms.naming.security_protocol', 'ssl','N');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(42008,42001,'com.tibco.tibjms.naming.ssl_enable_verify_host', 'false','N');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(42009,42001,'com.tibco.tibjms.naming.ssl_vendor', 'j2se-default','N');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(42010,42001,'com.sun.net.ssl.internal.ssl.Provider', 'j2se-default','N');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(42011,42001,'com.tibco.tibjms.naming.ssl_auth_only', 'true','N');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(42012,42001,'java.property.TIBCO_SECURITY_VENDOR','j2se-default','N');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(42013,42001,'java.property.TIBCO_SECURITY_TRACE', 'false','N');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(42014,42001,'com.tibco.tibjms.naming.ssl_debug_trace', 'true','N');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(42015,42001,'com.tibco.tibjms.naming.ssl_trace','true','N');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(42016,42001,'tibco.jms.queue.queueCF','G2C_EAPCOPAUPHBatchQueueConnectionFactory','N');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(42017,42001,'tibco.jms.inbound.queue.name','citi.gcg.gom.cop_163124.au_card.epp.modeloffer.error','N');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(42018,42001,'tibco.jms.queue.username','SIT_EAP_USR','N');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(42019,42001,'tibco.jms.queue.password','citi1234','N');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(42020,42001,'tibco.p12.enable','true','N');

INSERT INTO RTS3_APP_DS_EVENT(id, name, app_ds_id, event_type_code, description)
VALUES(42001, 'EAPModelOffer', 42001,'EAPModelOffer', 'TIBCO JMS Events');

INSERT INTO RTS3_EVENT_ACTION(id,app_event_id,action_type_code,exec_order)
VALUES(42001,42001,'PARSE_EVENT',1);

INSERT INTO RTS3_EVENT_ACTION(id,app_event_id,action_type_code,exec_order)
VALUES(42002,42001,'SAVE_MONGO',2);

INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name, param_value,value_encrypted)
VALUES(42001,42002,'mongodb.uri','mongodb://admin_mongodb:P5MwnVbm@maas-mw-d5-u0037.nam.nsroot.net:37017,maas-gt-d5-u0025.nam.nsroot.net:37017,maas-sw-d5-u0007.nam.nsroot.net:37017/GCG_ASIA_AU?ssl=true&authSource=admin','N');
INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name, param_value,value_encrypted)
VALUES(42002,42002,'mongodb.db.name','GCG_ASIA_AU','N');
INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name, param_value,value_encrypted)
VALUES(42003,42002,'mongodb.collection.name','EAP_EPP_COP_MODEL_OFR','N');
INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name,param_value,value_encrypted)
VALUES(42004,42002,'mongodb.db.password','cZNjPmJtqQ0wDFs2DNZsZw==','Y');

INSERT INTO RTS3_APP_DS(id, name, app_id, ds_type_code, description,default_event)
VALUES(42002, 'EPP_POT_AU', 42001,'TIBCO', 'EPP_POT_AU DS' , 'EAPProdOfferTemplate');

INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(42021,42002,'INITIAL_CONTEXT_FACTORY','com.tibco.tibjms.naming.TibjmsInitialContextFactory','N');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(42022,42002,'PROVIDER_URL', 'ssl://gpd-ed9-5c7e.nam.nsroot.net:7243','N');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(42023,42002,'com.tibco.tibjms.naming.ssl_identity', 'hdfs://gftsdev/user/gcgdmasg/security/DIT_EAP_USR.ca1.p12','N');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(42024,42002,'com.tibco.tibjms.naming.ssl_password', '','N');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(42025,42002,'SECURITY_PRINCIPAL', 'SIT_EAP_USR','N');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(42026,42002,'SECURITY_CREDENTIALS', 'citi1234','N');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(42027,42002,'com.tibco.tibjms.naming.security_protocol', 'ssl','N');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(42028,42002,'com.tibco.tibjms.naming.ssl_enable_verify_host', 'false','N');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(42029,42002,'com.tibco.tibjms.naming.ssl_vendor', 'j2se-default','N');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(42030,42002,'com.sun.net.ssl.internal.ssl.Provider', 'j2se-default','N');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(42031,42002,'com.tibco.tibjms.naming.ssl_auth_only', 'true','N');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(42032,42002,'java.property.TIBCO_SECURITY_VENDOR','j2se-default','N');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(42033,42002,'java.property.TIBCO_SECURITY_TRACE', 'false','N');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(42034,42002,'com.tibco.tibjms.naming.ssl_debug_trace', 'true','N');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(42035,42002,'com.tibco.tibjms.naming.ssl_trace','true','N');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(42036,42002,'tibco.jms.queue.queueCF','G2C_EAPCOPAUPHBatchQueueConnectionFactory','N');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(42037,42002,'tibco.jms.inbound.queue.name','citi.gcg.gom.cop_163124.au_card.epp.prodoffertemplate.update','N');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(42038,42002,'tibco.jms.queue.username','SIT_EAP_USR','N');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(42039,42002,'tibco.jms.queue.password','citi1234','N');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(42040,42002,'tibco.p12.enable','true','N');

INSERT INTO RTS3_APP_DS_EVENT(id, name, app_ds_id, event_type_code, description)
VALUES(42002, 'EAPProdOfferTemplate', 42002,'EAPProdOfferTemplate', 'TIBCO JMS Events');

INSERT INTO RTS3_EVENT_ACTION(id,app_event_id,action_type_code,exec_order)
VALUES(42003,42002,'PARSE_EVENT',1);

INSERT INTO RTS3_EVENT_ACTION(id,app_event_id,action_type_code,exec_order)
VALUES(42004,42002,'SAVE_MONGO',2);

INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name, param_value,value_encrypted)
VALUES(42005,42004,'mongodb.uri','mongodb://admin_mongodb:P5MwnVbm@maas-mw-d5-u0037.nam.nsroot.net:37017,maas-gt-d5-u0025.nam.nsroot.net:37017,maas-sw-d5-u0007.nam.nsroot.net:37017/GCG_ASIA_AU?ssl=true&authSource=admin','N');
INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name, param_value,value_encrypted)
VALUES(42006,42004,'mongodb.db.name','GCG_ASIA_AU','N');
INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name, param_value,value_encrypted)
VALUES(42007,42004,'mongodb.collection.name','EAP_EPP_COP_PROD_OFR_TEMPLATE','N');
INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name,param_value,value_encrypted)
VALUES(42008,42004,'mongodb.db.password','cZNjPmJtqQ0wDFs2DNZsZw==','Y');

INSERT INTO RTS3_APP_DS(id, name, app_id, ds_type_code, description,default_event)
VALUES(42003, 'EPP_TT_AU', 42001,'TIBCO', 'EPP_TT_AU DS' , 'EAPTreatmentTemplate');

INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(42041,42003,'INITIAL_CONTEXT_FACTORY','com.tibco.tibjms.naming.TibjmsInitialContextFactory','N');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(42042,42003,'PROVIDER_URL', 'ssl://gpd-ed9-5c7e.nam.nsroot.net:7243','N');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(42043,42003,'com.tibco.tibjms.naming.ssl_identity', 'hdfs://gftsdev/user/gcgdmasg/security/DIT_EAP_USR.ca1.p12','N');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(42044,42003,'com.tibco.tibjms.naming.ssl_password', '','N');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(42045,42003,'SECURITY_PRINCIPAL', 'SIT_EAP_USR','N');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(42046,42003,'SECURITY_CREDENTIALS', 'citi1234','N');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(42047,42003,'com.tibco.tibjms.naming.security_protocol', 'ssl','N');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(42048,42003,'com.tibco.tibjms.naming.ssl_enable_verify_host', 'false','N');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(42049,42003,'com.tibco.tibjms.naming.ssl_vendor', 'j2se-default','N');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(42050,42003,'com.sun.net.ssl.internal.ssl.Provider', 'j2se-default','N');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(42051,42003,'com.tibco.tibjms.naming.ssl_auth_only', 'true','N');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(42052,42003,'java.property.TIBCO_SECURITY_VENDOR','j2se-default','N');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(42053,42003,'java.property.TIBCO_SECURITY_TRACE', 'false','N');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(42054,42003,'com.tibco.tibjms.naming.ssl_debug_trace', 'true','N');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(42055,42003,'com.tibco.tibjms.naming.ssl_trace','true','N');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(42056,42003,'tibco.jms.queue.queueCF','G2C_EAPCOPAUPHBatchQueueConnectionFactory','N');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(42057,42003,'tibco.jms.inbound.queue.name','citi.gcg.gom.cop_163124.au_card.epp.treatmenttemplate.update','N');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(42058,42003,'tibco.jms.queue.username','SIT_EAP_USR','N');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(42059,42003,'tibco.jms.queue.password','citi1234','N');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(42060,42003,'tibco.p12.enable','true','N');

INSERT INTO RTS3_APP_DS_EVENT(id, name, app_ds_id, event_type_code, description)
VALUES(42003, 'EAPTreatmentTemplate', 42003,'EAPTreatmentTemplate', 'TIBCO JMS Events');

INSERT INTO RTS3_EVENT_ACTION(id,app_event_id,action_type_code,exec_order)
VALUES(42005,42003,'PARSE_EVENT',1);

INSERT INTO RTS3_EVENT_ACTION(id,app_event_id,action_type_code,exec_order)
VALUES(42006,42003,'SAVE_MONGO',2);

INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name, param_value,value_encrypted)
VALUES(42009,42006,'mongodb.uri','mongodb://admin_mongodb:P5MwnVbm@maas-mw-d5-u0037.nam.nsroot.net:37017,maas-gt-d5-u0025.nam.nsroot.net:37017,maas-sw-d5-u0007.nam.nsroot.net:37017/GCG_ASIA_AU?ssl=true&authSource=admin','N');
INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name, param_value,value_encrypted)
VALUES(42010,42006,'mongodb.db.name','GCG_ASIA_AU','N');
INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name, param_value,value_encrypted)
VALUES(42011,42006,'mongodb.collection.name','EAP_EPP_COP_TRT_TEMPLATE','N');
INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name,param_value,value_encrypted)
VALUES(42012,42006,'mongodb.db.password','cZNjPmJtqQ0wDFs2DNZsZw==','Y');

INSERT INTO RTS3_APP_DS(id, name, app_id, ds_type_code, description,default_event)
VALUES(42004, 'EPP_UOF_AU', 42001,'TIBCO', 'EPP_UOF_AU DS' , 'UpdateOfferFullfillmentEapRequest');

INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(42061,42004,'INITIAL_CONTEXT_FACTORY','com.tibco.tibjms.naming.TibjmsInitialContextFactory','N');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(42062,42004,'PROVIDER_URL', 'ssl://gpd-ed9-5c7e.nam.nsroot.net:7243','N');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(42063,42004,'com.tibco.tibjms.naming.ssl_identity', 'hdfs://gftsdev/user/gcgdmasg/security/DIT_EAP_USR.ca1.p12','N');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(42064,42004,'com.tibco.tibjms.naming.ssl_password', '','N');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(42065,42004,'SECURITY_PRINCIPAL', 'SIT_EAP_USR','N');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(42066,42004,'SECURITY_CREDENTIALS', 'citi1234','N');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(42067,42004,'com.tibco.tibjms.naming.security_protocol', 'ssl','N');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(42068,42004,'com.tibco.tibjms.naming.ssl_enable_verify_host', 'false','N');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(42069,42004,'com.tibco.tibjms.naming.ssl_vendor', 'j2se-default','N');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(42070,42004,'com.sun.net.ssl.internal.ssl.Provider', 'j2se-default','N');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(42071,42004,'com.tibco.tibjms.naming.ssl_auth_only', 'true','N');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(42072,42004,'java.property.TIBCO_SECURITY_VENDOR','j2se-default','N');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(42073,42004,'java.property.TIBCO_SECURITY_TRACE', 'false','N');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(42074,42004,'com.tibco.tibjms.naming.ssl_debug_trace', 'true','N');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(42075,42004,'com.tibco.tibjms.naming.ssl_trace','true','N');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(42076,42004,'tibco.jms.queue.queueCF','G2C_EAPCOPAUPHBatchQueueConnectionFactory','N');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(42077,42004,'tibco.jms.inbound.queue.name','citi.gcg.gom.cop_163124.au_card.offerfulfillment.modelrequest','N');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(42078,42004,'tibco.jms.queue.username','SIT_EAP_USR','N');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(42079,42004,'tibco.jms.queue.password','citi1234','N');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(42080,42004,'tibco.p12.enable','true','N');

INSERT INTO RTS3_APP_DS_EVENT(id, name, app_ds_id, event_type_code, description)
VALUES(42004, 'UpdateOfferFullfillmentEapRequest', 42004,'UpdateOfferFullfillmentEapRequest', 'TIBCO JMS Events');

INSERT INTO RTS3_EVENT_ACTION(id,app_event_id,action_type_code,exec_order)
VALUES(42007,42004,'PARSE_EVENT',1);

INSERT INTO RTS3_EVENT_ACTION(id,app_event_id,action_type_code,exec_order)
VALUES(42008,42004,'SAVE_MONGO',2);

INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name, param_value,value_encrypted)
VALUES(42013,42008,'mongodb.uri','mongodb://admin_mongodb:P5MwnVbm@maas-mw-d5-u0037.nam.nsroot.net:37017,maas-gt-d5-u0025.nam.nsroot.net:37017,maas-sw-d5-u0007.nam.nsroot.net:37017/GCG_ASIA_AU?ssl=true&authSource=admin','N');
INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name, param_value,value_encrypted)
VALUES(42014,42008,'mongodb.db.name','GCG_ASIA_AU','N');
INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name, param_value,value_encrypted)
VALUES(42015,42008,'mongodb.collection.name','EAP_EPP_COP_OFR_FULFILLMENT','N');
INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name,param_value,value_encrypted)
VALUES(42016,42008,'mongodb.db.password','cZNjPmJtqQ0wDFs2DNZsZw==','Y');


--------------------------------------------------------------------------PH-------------------------------------------------------------------------------------

INSERT INTO RTS3_APPLICATION (id, name, tenant_id, description, void_ind)
VALUES(43001, 'EPP_EAP_PH', 10001, 'EAP Model Offer', 'N');

INSERT INTO RTS3_APP_PARAM (id, param_type_code, app_id, param_name, param_value, description)
VALUES(43001, 'SPARK_CONF', 43001, 'spark.app.name', 'EPP Spark', null);
INSERT INTO RTS3_APP_PARAM (id, param_type_code, app_id, param_name, param_value, description)
VALUES(43002, 'APP_CONF', 43001, 'app.spark.duration', '300', 'milli-seconds');
INSERT INTO RTS3_APP_PARAM (id, param_type_code, app_id, param_name, param_value, description)
VALUES(43003, 'APP_CONF', 43001, 'app.spark.msg.broker.type', 'TIBCO', null);

INSERT INTO RTS3_APP_DS(id, name, app_id, ds_type_code, description,default_event)
VALUES(43001, 'EPP_MO_PH', 43001,'TIBCO', 'EPP_MO_PH DS' , 'EAPModelOffer');

INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(43001,43001,'INITIAL_CONTEXT_FACTORY','com.tibco.tibjms.naming.TibjmsInitialContextFactory','N');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(43002,43001,'PROVIDER_URL', 'ssl://gpd-ed9-5c7e.nam.nsroot.net:7243','N');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(43003,43001,'com.tibco.tibjms.naming.ssl_identity', 'hdfs://gftsdev/user/gcgdmasg/security/DIT_EAP_USR.ca1.p12','N');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(43004,43001,'com.tibco.tibjms.naming.ssl_password', '','N');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(43005,43001,'SECURITY_PRINCIPAL', 'SIT_EAP_USR','N');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(43006,43001,'SECURITY_CREDENTIALS', 'citi1234','N');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(43007,43001,'com.tibco.tibjms.naming.security_protocol', 'ssl','N');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(43008,43001,'com.tibco.tibjms.naming.ssl_enable_verify_host', 'false','N');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(43009,43001,'com.tibco.tibjms.naming.ssl_vendor', 'j2se-default','N');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(43010,43001,'com.sun.net.ssl.internal.ssl.Provider', 'j2se-default','N');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(43011,43001,'com.tibco.tibjms.naming.ssl_auth_only', 'true','N');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(43012,43001,'java.property.TIBCO_SECURITY_VENDOR','j2se-default','N');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(43013,43001,'java.property.TIBCO_SECURITY_TRACE', 'false','N');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(43014,43001,'com.tibco.tibjms.naming.ssl_debug_trace', 'true','N');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(43015,43001,'com.tibco.tibjms.naming.ssl_trace','true','N');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(43016,43001,'tibco.jms.queue.queueCF','G2C_EAPCOPAUPHBatchQueueConnectionFactory','N');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(43017,43001,'tibco.jms.inbound.queue.name','citi.gcg.gomph.cop_163124.ph_card.epp.modeloffer.error','N');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(43018,43001,'tibco.jms.queue.username','SIT_EAP_USR','N');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(43019,43001,'tibco.jms.queue.password','citi1234','N');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(43020,43001,'tibco.p12.enable','true','N');

INSERT INTO RTS3_APP_DS_EVENT(id, name, app_ds_id, event_type_code, description)
VALUES(43001, 'EAPModelOffer', 43001,'EAPModelOffer', 'TIBCO JMS Events');

INSERT INTO RTS3_EVENT_ACTION(id,app_event_id,action_type_code,exec_order)
VALUES(43001,43001,'PARSE_EVENT',1);

INSERT INTO RTS3_EVENT_ACTION(id,app_event_id,action_type_code,exec_order)
VALUES(43002,43001,'SAVE_MONGO',2);

INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name, param_value,value_encrypted)
VALUES(43001,43002,'mongodb.uri','mongodb://admin_mongodb:P5MwnVbm@maas-mw-d5-u0037.nam.nsroot.net:37017,maas-gt-d5-u0025.nam.nsroot.net:37017,maas-sw-d5-u0007.nam.nsroot.net:37017/GCG_ASIA_PH?ssl=true&authSource=admin','N');
INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name, param_value,value_encrypted)
VALUES(43002,43002,'mongodb.db.name','GCG_ASIA_PH','N');
INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name, param_value,value_encrypted)
VALUES(43003,43002,'mongodb.collection.name','EAP_EPP_COP_MODEL_OFR','N');
INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name,param_value,value_encrypted)
VALUES(43004,43002,'mongodb.db.password','cZNjPmJtqQ0wDFs2DNZsZw==','Y');

INSERT INTO RTS3_APP_DS(id, name, app_id, ds_type_code, description,default_event)
VALUES(43002, 'EPP_POT_PH', 43001,'TIBCO', 'EPP_POT_PH DS' , 'EAPProdOfferTemplate');

INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(43021,43002,'INITIAL_CONTEXT_FACTORY','com.tibco.tibjms.naming.TibjmsInitialContextFactory','N');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(43022,43002,'PROVIDER_URL', 'ssl://gpd-ed9-5c7e.nam.nsroot.net:7243','N');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(43023,43002,'com.tibco.tibjms.naming.ssl_identity', 'hdfs://gftsdev/user/gcgdmasg/security/DIT_EAP_USR.ca1.p12','N');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(43024,43002,'com.tibco.tibjms.naming.ssl_password', '','N');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(43025,43002,'SECURITY_PRINCIPAL', 'SIT_EAP_USR','N');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(43026,43002,'SECURITY_CREDENTIALS', 'citi1234','N');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(43027,43002,'com.tibco.tibjms.naming.security_protocol', 'ssl','N');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(43028,43002,'com.tibco.tibjms.naming.ssl_enable_verify_host', 'false','N');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(43029,43002,'com.tibco.tibjms.naming.ssl_vendor', 'j2se-default','N');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(43030,43002,'com.sun.net.ssl.internal.ssl.Provider', 'j2se-default','N');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(43031,43002,'com.tibco.tibjms.naming.ssl_auth_only', 'true','N');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(43032,43002,'java.property.TIBCO_SECURITY_VENDOR','j2se-default','N');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(43033,43002,'java.property.TIBCO_SECURITY_TRACE', 'false','N');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(43034,43002,'com.tibco.tibjms.naming.ssl_debug_trace', 'true','N');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(43035,43002,'com.tibco.tibjms.naming.ssl_trace','true','N');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(43036,43002,'tibco.jms.queue.queueCF','G2C_EAPCOPAUPHBatchQueueConnectionFactory','N');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(43037,43002,'tibco.jms.inbound.queue.name','citi.gcg.gomph.cop_163124.ph_card.epp.prodoffertemplate.update','N');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(43038,43002,'tibco.jms.queue.username','SIT_EAP_USR','N');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(43039,43002,'tibco.jms.queue.password','citi1234','N');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(43040,43002,'tibco.p12.enable','true','N');

INSERT INTO RTS3_APP_DS_EVENT(id, name, app_ds_id, event_type_code, description)
VALUES(43002, 'EAPProdOfferTemplate', 43002,'EAPProdOfferTemplate', 'TIBCO JMS Events');

INSERT INTO RTS3_EVENT_ACTION(id,app_event_id,action_type_code,exec_order)
VALUES(43003,43002,'PARSE_EVENT',1);

INSERT INTO RTS3_EVENT_ACTION(id,app_event_id,action_type_code,exec_order)
VALUES(43004,43002,'SAVE_MONGO',2);

INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name, param_value,value_encrypted)
VALUES(43005,43004,'mongodb.uri','mongodb://admin_mongodb:P5MwnVbm@maas-mw-d5-u0037.nam.nsroot.net:37017,maas-gt-d5-u0025.nam.nsroot.net:37017,maas-sw-d5-u0007.nam.nsroot.net:37017/GCG_ASIA_PH?ssl=true&authSource=admin','N');
INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name, param_value,value_encrypted)
VALUES(43006,43004,'mongodb.db.name','GCG_ASIA_PH','N');
INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name, param_value,value_encrypted)
VALUES(43007,43004,'mongodb.collection.name','EAP_EPP_COP_PROD_OFR_TEMPLATE','N');
INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name,param_value,value_encrypted)
VALUES(43008,43004,'mongodb.db.password','cZNjPmJtqQ0wDFs2DNZsZw==','Y');

INSERT INTO RTS3_APP_DS(id, name, app_id, ds_type_code, description,default_event)
VALUES(43003, 'EPP_TT_PH', 43001,'TIBCO', 'EPP_TT_PH DS' , 'EAPTreatmentTemplate');

INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(43041,43003,'INITIAL_CONTEXT_FACTORY','com.tibco.tibjms.naming.TibjmsInitialContextFactory','N');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(43042,43003,'PROVIDER_URL', 'ssl://gpd-ed9-5c7e.nam.nsroot.net:7243','N');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(43043,43003,'com.tibco.tibjms.naming.ssl_identity', 'hdfs://gftsdev/user/gcgdmasg/security/DIT_EAP_USR.ca1.p12','N');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(43044,43003,'com.tibco.tibjms.naming.ssl_password', '','N');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(43045,43003,'SECURITY_PRINCIPAL', 'SIT_EAP_USR','N');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(43046,43003,'SECURITY_CREDENTIALS', 'citi1234','N');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(43047,43003,'com.tibco.tibjms.naming.security_protocol', 'ssl','N');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(43048,43003,'com.tibco.tibjms.naming.ssl_enable_verify_host', 'false','N');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(43049,43003,'com.tibco.tibjms.naming.ssl_vendor', 'j2se-default','N');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(43050,43003,'com.sun.net.ssl.internal.ssl.Provider', 'j2se-default','N');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(43051,43003,'com.tibco.tibjms.naming.ssl_auth_only', 'true','N');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(43052,43003,'java.property.TIBCO_SECURITY_VENDOR','j2se-default','N');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(43053,43003,'java.property.TIBCO_SECURITY_TRACE', 'false','N');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(43054,43003,'com.tibco.tibjms.naming.ssl_debug_trace', 'true','N');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(43055,43003,'com.tibco.tibjms.naming.ssl_trace','true','N');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(43056,43003,'tibco.jms.queue.queueCF','G2C_EAPCOPAUPHBatchQueueConnectionFactory','N');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(43057,43003,'tibco.jms.inbound.queue.name','citi.gcg.gomph.cop_163124.ph_card.epp.treatmenttemplate.update','N');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(43058,43003,'tibco.jms.queue.username','SIT_EAP_USR','N');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(43059,43003,'tibco.jms.queue.password','citi1234','N');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(43060,43003,'tibco.p12.enable','true','N');

INSERT INTO RTS3_APP_DS_EVENT(id, name, app_ds_id, event_type_code, description)
VALUES(43003, 'EAPTreatmentTemplate', 43003,'EAPTreatmentTemplate', 'TIBCO JMS Events');

INSERT INTO RTS3_EVENT_ACTION(id,app_event_id,action_type_code,exec_order)
VALUES(43005,43003,'PARSE_EVENT',1);

INSERT INTO RTS3_EVENT_ACTION(id,app_event_id,action_type_code,exec_order)
VALUES(43006,43003,'SAVE_MONGO',2);

INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name, param_value,value_encrypted)
VALUES(43009,43006,'mongodb.uri','mongodb://admin_mongodb:P5MwnVbm@maas-mw-d5-u0037.nam.nsroot.net:37017,maas-gt-d5-u0025.nam.nsroot.net:37017,maas-sw-d5-u0007.nam.nsroot.net:37017/GCG_ASIA_PH?ssl=true&authSource=admin','N');
INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name, param_value,value_encrypted)
VALUES(43010,43006,'mongodb.db.name','GCG_ASIA_PH','N');
INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name, param_value,value_encrypted)
VALUES(43011,43006,'mongodb.collection.name','EAP_EPP_COP_TRT_TEMPLATE','N');
INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name,param_value,value_encrypted)
VALUES(43012,43006,'mongodb.db.password','cZNjPmJtqQ0wDFs2DNZsZw==','Y');

INSERT INTO RTS3_APP_DS(id, name, app_id, ds_type_code, description,default_event)
VALUES(43004, 'EPP_UOF_PH', 43001,'TIBCO', 'EPP_UOF_PH DS' , 'UpdateOfferFullfillmentEapRequest');

INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(43061,43004,'INITIAL_CONTEXT_FACTORY','com.tibco.tibjms.naming.TibjmsInitialContextFactory','N');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(43062,43004,'PROVIDER_URL', 'ssl://gpd-ed9-5c7e.nam.nsroot.net:7243','N');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(43063,43004,'com.tibco.tibjms.naming.ssl_identity', 'hdfs://gftsdev/user/gcgdmasg/security/DIT_EAP_USR.ca1.p12','N');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(43064,43004,'com.tibco.tibjms.naming.ssl_password', '','N');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(43065,43004,'SECURITY_PRINCIPAL', 'SIT_EAP_USR','N');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(43066,43004,'SECURITY_CREDENTIALS', 'citi1234','N');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(43067,43004,'com.tibco.tibjms.naming.security_protocol', 'ssl','N');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(43068,43004,'com.tibco.tibjms.naming.ssl_enable_verify_host', 'false','N');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(43069,43004,'com.tibco.tibjms.naming.ssl_vendor', 'j2se-default','N');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(43070,43004,'com.sun.net.ssl.internal.ssl.Provider', 'j2se-default','N');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(43071,43004,'com.tibco.tibjms.naming.ssl_auth_only', 'true','N');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(43072,43004,'java.property.TIBCO_SECURITY_VENDOR','j2se-default','N');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(43073,43004,'java.property.TIBCO_SECURITY_TRACE', 'false','N');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(43074,43004,'com.tibco.tibjms.naming.ssl_debug_trace', 'true','N');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(43075,43004,'com.tibco.tibjms.naming.ssl_trace','true','N');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(43076,43004,'tibco.jms.queue.queueCF','G2C_EAPCOPAUPHBatchQueueConnectionFactory','N');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(43077,43004,'tibco.jms.inbound.queue.name','citi.gcg.gomph.cop_163124.ph_card.offerfulfillment.modelrequest','N');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(43078,43004,'tibco.jms.queue.username','SIT_EAP_USR','N');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(43079,43004,'tibco.jms.queue.password','citi1234','N');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(43080,43004,'tibco.p12.enable','true','N');

INSERT INTO RTS3_APP_DS_EVENT(id, name, app_ds_id, event_type_code, description)
VALUES(43004, 'UpdateOfferFullfillmentEapRequest', 43004,'UpdateOfferFullfillmentEapRequest', 'TIBCO JMS Events');

INSERT INTO RTS3_EVENT_ACTION(id,app_event_id,action_type_code,exec_order)
VALUES(43007,43004,'PARSE_EVENT',1);

INSERT INTO RTS3_EVENT_ACTION(id,app_event_id,action_type_code,exec_order)
VALUES(43008,43004,'SAVE_MONGO',2);

INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name, param_value,value_encrypted)
VALUES(43013,43008,'mongodb.uri','mongodb://admin_mongodb:P5MwnVbm@maas-mw-d5-u0037.nam.nsroot.net:37017,maas-gt-d5-u0025.nam.nsroot.net:37017,maas-sw-d5-u0007.nam.nsroot.net:37017/GCG_ASIA_PH?ssl=true&authSource=admin','N');
INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name, param_value,value_encrypted)
VALUES(43014,43008,'mongodb.db.name','GCG_ASIA_PH','N');
INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name, param_value,value_encrypted)
VALUES(43015,43008,'mongodb.collection.name','EAP_EPP_COP_MODEL_OFR','N');
INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name,param_value,value_encrypted)
VALUES(43016,43008,'mongodb.db.password','cZNjPmJtqQ0wDFs2DNZsZw==','Y');

-------------------------------------------------------------------------SG-------------------------------------------------------------

INSERT INTO RTS3_APPLICATION (id, name, tenant_id, description, void_ind)
VALUES(44001, 'EPP_EAP_SG', 10001, 'EAP Model Offer', 'N');

INSERT INTO RTS3_APP_PARAM (id, param_type_code, app_id, param_name, param_value, description)
VALUES(44001, 'SPARK_CONF', 44001, 'spark.app.name', 'EPP Spark', null);
INSERT INTO RTS3_APP_PARAM (id, param_type_code, app_id, param_name, param_value, description)
VALUES(44002, 'APP_CONF', 44001, 'app.spark.duration', '300', 'milli-seconds');
INSERT INTO RTS3_APP_PARAM (id, param_type_code, app_id, param_name, param_value, description)
VALUES(44003, 'APP_CONF', 44001, 'app.spark.msg.broker.type', 'TIBCO', null);

INSERT INTO RTS3_APP_DS(id, name, app_id, ds_type_code, description,default_event)
VALUES(44001, 'EPP_MO_SG', 44001,'TIBCO', 'EPP_MO_SG DS' , 'EAPModelOffer');

INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(44001,44001,'INITIAL_CONTEXT_FACTORY','com.tibco.tibjms.naming.TibjmsInitialContextFactory','N');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(44002,44001,'PROVIDER_URL', 'ssl://gpd-ed9-5c7e.nam.nsroot.net:7243','N');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(44003,44001,'com.tibco.tibjms.naming.ssl_identity', 'hdfs://gftsdev/user/gcgdmasg/security/DIT_EAP_USR.ca1.p12','N');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(44004,44001,'com.tibco.tibjms.naming.ssl_password', '','N');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(44005,44001,'SECURITY_PRINCIPAL', 'SIT_EAP_USR','N');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(44006,44001,'SECURITY_CREDENTIALS', 'citi1234','N');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(44007,44001,'com.tibco.tibjms.naming.security_protocol', 'ssl','N');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(44008,44001,'com.tibco.tibjms.naming.ssl_enable_verify_host', 'false','N');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(44009,44001,'com.tibco.tibjms.naming.ssl_vendor', 'j2se-default','N');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(44010,44001,'com.sun.net.ssl.internal.ssl.Provider', 'j2se-default','N');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(44011,44001,'com.tibco.tibjms.naming.ssl_auth_only', 'true','N');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(44012,44001,'java.property.TIBCO_SECURITY_VENDOR','j2se-default','N');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(44013,44001,'java.property.TIBCO_SECURITY_TRACE', 'false','N');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(44014,44001,'com.tibco.tibjms.naming.ssl_debug_trace', 'true','N');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(44015,44001,'com.tibco.tibjms.naming.ssl_trace','true','N');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(44016,44001,'tibco.jms.queue.queueCF','G2C_EAPCOPSGIDVNBatchQueueConnectionFactory','N');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(44017,44001,'tibco.jms.inbound.queue.name','citi.gcg.gomsg.cop_163124.sg_card.epp.modeloffer.error','N');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(44018,44001,'tibco.jms.queue.username','SIT_EAP_USR','N');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(44019,44001,'tibco.jms.queue.password','citi1234','N');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(44020,44001,'tibco.p12.enable','true','N');

INSERT INTO RTS3_APP_DS_EVENT(id, name, app_ds_id, event_type_code, description)
VALUES(44001, 'EAPModelOffer', 44001,'EAPModelOffer', 'TIBCO JMS Events');

INSERT INTO RTS3_EVENT_ACTION(id,app_event_id,action_type_code,exec_order)
VALUES(44001,44001,'PARSE_EVENT',1);

INSERT INTO RTS3_EVENT_ACTION(id,app_event_id,action_type_code,exec_order)
VALUES(44002,44001,'SAVE_MONGO',2);

INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name, param_value,value_encrypted)
VALUES(44001,44002,'mongodb.uri','mongodb://admin_mongodb:P5MwnVbm@maas-mw-d5-u0037.nam.nsroot.net:37017,maas-gt-d5-u0025.nam.nsroot.net:37017,maas-sw-d5-u0007.nam.nsroot.net:37017/GCG_ASIA_SG?ssl=true&authSource=admin','N');
INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name, param_value,value_encrypted)
VALUES(44002,44002,'mongodb.db.name','GCG_ASIA_SG','N');
INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name, param_value,value_encrypted)
VALUES(44003,44002,'mongodb.collection.name','EAP_EPP_COP_MODEL_OFR','N');
INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name,param_value,value_encrypted)
VALUES(44004,44002,'mongodb.db.password','cZNjPmJtqQ0wDFs2DNZsZw==','Y');

INSERT INTO RTS3_APP_DS(id, name, app_id, ds_type_code, description,default_event)
VALUES(44002, 'EPP_POT_SG', 44001,'TIBCO', 'EPP_POT_SG DS' , 'EAPProdOfferTemplate');

INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(44021,44002,'INITIAL_CONTEXT_FACTORY','com.tibco.tibjms.naming.TibjmsInitialContextFactory','N');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(44022,44002,'PROVIDER_URL', 'ssl://gpd-ed9-5c7e.nam.nsroot.net:7243','N');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(44023,44002,'com.tibco.tibjms.naming.ssl_identity', 'hdfs://gftsdev/user/gcgdmasg/security/DIT_EAP_USR.ca1.p12','N');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(44024,44002,'com.tibco.tibjms.naming.ssl_password', '','N');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(44025,44002,'SECURITY_PRINCIPAL', 'SIT_EAP_USR','N');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(44026,44002,'SECURITY_CREDENTIALS', 'citi1234','N');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(44027,44002,'com.tibco.tibjms.naming.security_protocol', 'ssl','N');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(44028,44002,'com.tibco.tibjms.naming.ssl_enable_verify_host', 'false','N');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(44029,44002,'com.tibco.tibjms.naming.ssl_vendor', 'j2se-default','N');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(44030,44002,'com.sun.net.ssl.internal.ssl.Provider', 'j2se-default','N');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(44031,44002,'com.tibco.tibjms.naming.ssl_auth_only', 'true','N');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(44032,44002,'java.property.TIBCO_SECURITY_VENDOR','j2se-default','N');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(44033,44002,'java.property.TIBCO_SECURITY_TRACE', 'false','N');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(44034,44002,'com.tibco.tibjms.naming.ssl_debug_trace', 'true','N');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(44035,44002,'com.tibco.tibjms.naming.ssl_trace','true','N');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(44036,44002,'tibco.jms.queue.queueCF','G2C_EAPCOPSGIDVNBatchQueueConnectionFactory','N');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(44037,44002,'tibco.jms.inbound.queue.name','citi.gcg.gomsg.cop_163124.sg_card.epp.prodoffertemplate.update','N');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(44038,44002,'tibco.jms.queue.username','SIT_EAP_USR','N');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(44039,44002,'tibco.jms.queue.password','citi1234','N');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(44040,44002,'tibco.p12.enable','true','N');

INSERT INTO RTS3_APP_DS_EVENT(id, name, app_ds_id, event_type_code, description)
VALUES(44002, 'EAPProdOfferTemplate', 44002,'EAPProdOfferTemplate', 'TIBCO JMS Events');

INSERT INTO RTS3_EVENT_ACTION(id,app_event_id,action_type_code,exec_order)
VALUES(44003,44002,'PARSE_EVENT',1);

INSERT INTO RTS3_EVENT_ACTION(id,app_event_id,action_type_code,exec_order)
VALUES(44004,44002,'SAVE_MONGO',2);

INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name, param_value,value_encrypted)
VALUES(44005,44004,'mongodb.uri','mongodb://admin_mongodb:P5MwnVbm@maas-mw-d5-u0037.nam.nsroot.net:37017,maas-gt-d5-u0025.nam.nsroot.net:37017,maas-sw-d5-u0007.nam.nsroot.net:37017/GCG_ASIA_SG?ssl=true&authSource=admin','N');
INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name, param_value,value_encrypted)
VALUES(44006,44004,'mongodb.db.name','GCG_ASIA_SG','N');
INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name, param_value,value_encrypted)
VALUES(44007,44004,'mongodb.collection.name','EAP_EPP_COP_PROD_OFR_TEMPLATE','N');
INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name,param_value,value_encrypted)
VALUES(44008,44004,'mongodb.db.password','cZNjPmJtqQ0wDFs2DNZsZw==','Y');

INSERT INTO RTS3_APP_DS(id, name, app_id, ds_type_code, description,default_event)
VALUES(44003, 'EPP_TT_SG', 44001,'TIBCO', 'EPP_TT_SG DS' , 'EAPTreatmentTemplate');

INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(44041,44003,'INITIAL_CONTEXT_FACTORY','com.tibco.tibjms.naming.TibjmsInitialContextFactory','N');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(44042,44003,'PROVIDER_URL', 'ssl://gpd-ed9-5c7e.nam.nsroot.net:7243','N');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(44043,44003,'com.tibco.tibjms.naming.ssl_identity', 'hdfs://gftsdev/user/gcgdmasg/security/DIT_EAP_USR.ca1.p12','N');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(44044,44003,'com.tibco.tibjms.naming.ssl_password', '','N');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(44045,44003,'SECURITY_PRINCIPAL', 'SIT_EAP_USR','N');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(44046,44003,'SECURITY_CREDENTIALS', 'citi1234','N');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(44047,44003,'com.tibco.tibjms.naming.security_protocol', 'ssl','N');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(44048,44003,'com.tibco.tibjms.naming.ssl_enable_verify_host', 'false','N');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(44049,44003,'com.tibco.tibjms.naming.ssl_vendor', 'j2se-default','N');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(44050,44003,'com.sun.net.ssl.internal.ssl.Provider', 'j2se-default','N');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(44051,44003,'com.tibco.tibjms.naming.ssl_auth_only', 'true','N');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(44052,44003,'java.property.TIBCO_SECURITY_VENDOR','j2se-default','N');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(44053,44003,'java.property.TIBCO_SECURITY_TRACE', 'false','N');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(44054,44003,'com.tibco.tibjms.naming.ssl_debug_trace', 'true','N');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(44055,44003,'com.tibco.tibjms.naming.ssl_trace','true','N');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(44056,44003,'tibco.jms.queue.queueCF','G2C_EAPCOPSGIDVNBatchQueueConnectionFactory','N');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(44057,44003,'tibco.jms.inbound.queue.name','citi.gcg.gomsg.cop_163124.sg_card.epp.treatmenttemplate.update','N');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(44058,44003,'tibco.jms.queue.username','SIT_EAP_USR','N');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(44059,44003,'tibco.jms.queue.password','citi1234','N');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(44060,44003,'tibco.p12.enable','true','N');

INSERT INTO RTS3_APP_DS_EVENT(id, name, app_ds_id, event_type_code, description)
VALUES(44003, 'EAPTreatmentTemplate', 44003,'EAPTreatmentTemplate', 'TIBCO JMS Events');

INSERT INTO RTS3_EVENT_ACTION(id,app_event_id,action_type_code,exec_order)
VALUES(44005,44003,'PARSE_EVENT',1);

INSERT INTO RTS3_EVENT_ACTION(id,app_event_id,action_type_code,exec_order)
VALUES(44006,44003,'SAVE_MONGO',2);

INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name, param_value,value_encrypted)
VALUES(44009,44006,'mongodb.uri','mongodb://admin_mongodb:P5MwnVbm@maas-mw-d5-u0037.nam.nsroot.net:37017,maas-gt-d5-u0025.nam.nsroot.net:37017,maas-sw-d5-u0007.nam.nsroot.net:37017/GCG_ASIA_SG?ssl=true&authSource=admin','N');
INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name, param_value,value_encrypted)
VALUES(44010,44006,'mongodb.db.name','GCG_ASIA_SG','N');
INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name, param_value,value_encrypted)
VALUES(44011,44006,'mongodb.collection.name','EAP_EPP_COP_TRT_TEMPLATE','N');
INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name,param_value,value_encrypted)
VALUES(44012,44006,'mongodb.db.password','cZNjPmJtqQ0wDFs2DNZsZw==','Y');


INSERT INTO RTS3_APP_DS(id, name, app_id, ds_type_code, description,default_event)
VALUES(44004, 'EPP_UOF_SG', 44001,'TIBCO', 'EPP_UOF_SG DS' , 'UpdateOfferFullfillmentEapRequest');

INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(44061,44004,'INITIAL_CONTEXT_FACTORY','com.tibco.tibjms.naming.TibjmsInitialContextFactory','N');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(44062,44004,'PROVIDER_URL', 'ssl://gpd-ed9-5c7e.nam.nsroot.net:7243','N');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(44063,44004,'com.tibco.tibjms.naming.ssl_identity', 'hdfs://gftsdev/user/gcgdmasg/security/DIT_EAP_USR.ca1.p12','N');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(44064,44004,'com.tibco.tibjms.naming.ssl_password', '','N');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(44065,44004,'SECURITY_PRINCIPAL', 'SIT_EAP_USR','N');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(44066,44004,'SECURITY_CREDENTIALS', 'citi1234','N');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(44067,44004,'com.tibco.tibjms.naming.security_protocol', 'ssl','N');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(44068,44004,'com.tibco.tibjms.naming.ssl_enable_verify_host', 'false','N');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(44069,44004,'com.tibco.tibjms.naming.ssl_vendor', 'j2se-default','N');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(44070,44004,'com.sun.net.ssl.internal.ssl.Provider', 'j2se-default','N');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(44071,44004,'com.tibco.tibjms.naming.ssl_auth_only', 'true','N');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(44072,44004,'java.property.TIBCO_SECURITY_VENDOR','j2se-default','N');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(44073,44004,'java.property.TIBCO_SECURITY_TRACE', 'false','N');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(44074,44004,'com.tibco.tibjms.naming.ssl_debug_trace', 'true','N');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(44075,44004,'com.tibco.tibjms.naming.ssl_trace','true','N');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(44076,44004,'tibco.jms.queue.queueCF','G2C_EAPCOPSGIDVNBatchQueueConnectionFactory','N');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(44077,44004,'tibco.jms.inbound.queue.name','citi.gcg.gomsg.cop_163124.sg_card.offerfulfillment.modelrequest','N');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(44078,44004,'tibco.jms.queue.username','SIT_EAP_USR','N');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(44079,44004,'tibco.jms.queue.password','citi1234','N');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(44080,44004,'tibco.p12.enable','true','N');

INSERT INTO RTS3_APP_DS_EVENT(id, name, app_ds_id, event_type_code, description)
VALUES(44004, 'UpdateOfferFullfillmentEapRequest', 44004,'UpdateOfferFullfillmentEapRequest', 'TIBCO JMS Events');

INSERT INTO RTS3_EVENT_ACTION(id,app_event_id,action_type_code,exec_order)
VALUES(44007,44004,'PARSE_EVENT',1);

INSERT INTO RTS3_EVENT_ACTION(id,app_event_id,action_type_code,exec_order)
VALUES(44008,44004,'SAVE_MONGO',2);

INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name, param_value,value_encrypted)
VALUES(44013,44008,'mongodb.uri','mongodb://admin_mongodb:P5MwnVbm@maas-mw-d5-u0037.nam.nsroot.net:37017,maas-gt-d5-u0025.nam.nsroot.net:37017,maas-sw-d5-u0007.nam.nsroot.net:37017/GCG_ASIA_SG?ssl=true&authSource=admin','N');
INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name, param_value,value_encrypted)
VALUES(44014,44008,'mongodb.db.name','GCG_ASIA_SG','N');
INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name, param_value,value_encrypted)
VALUES(44015,44008,'mongodb.collection.name','EAP_EPP_COP_OFR_FULFILLMENT','N');
INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name,param_value,value_encrypted)
VALUES(44016,44008,'mongodb.db.password','cZNjPmJtqQ0wDFs2DNZsZw==','Y');


-------------------------------------------------------------------------TH---------------------------------------------------------


INSERT INTO RTS3_APPLICATION (id, name, tenant_id, description, void_ind)
VALUES(45001, 'EPP_EAP_TH', 10001, 'EAP Model Offer', 'N');

INSERT INTO RTS3_APP_PARAM (id, param_type_code, app_id, param_name, param_value, description)
VALUES(45001, 'SPARK_CONF', 45001, 'spark.app.name', 'EPP Spark', null);
INSERT INTO RTS3_APP_PARAM (id, param_type_code, app_id, param_name, param_value, description)
VALUES(45002, 'APP_CONF', 45001, 'app.spark.duration', '300', 'milli-seconds');
INSERT INTO RTS3_APP_PARAM (id, param_type_code, app_id, param_name, param_value, description)
VALUES(45003, 'APP_CONF', 45001, 'app.spark.msg.broker.type', 'TIBCO', null);

INSERT INTO RTS3_APP_DS(id, name, app_id, ds_type_code, description,default_event)
VALUES(45001, 'EPP_MO_TH', 45001,'TIBCO', 'EPP_MO_TH DS' , 'EAPModelOffer');

INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(45001,45001,'INITIAL_CONTEXT_FACTORY','com.tibco.tibjms.naming.TibjmsInitialContextFactory','N');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(45002,45001,'PROVIDER_URL', 'ssl://gpd-ed9-5c7e.nam.nsroot.net:7243','N');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(45003,45001,'com.tibco.tibjms.naming.ssl_identity', 'hdfs://gftsdev/user/gcgdmasg/security/DIT_EAP_USR.ca1.p12','N');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(45004,45001,'com.tibco.tibjms.naming.ssl_password', '','N');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(45005,45001,'SECURITY_PRINCIPAL', 'SIT_EAP_USR','N');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(45006,45001,'SECURITY_CREDENTIALS', 'citi1234','N');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(45007,45001,'com.tibco.tibjms.naming.security_protocol', 'ssl','N');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(45008,45001,'com.tibco.tibjms.naming.ssl_enable_verify_host', 'false','N');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(45009,45001,'com.tibco.tibjms.naming.ssl_vendor', 'j2se-default','N');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(45010,45001,'com.sun.net.ssl.internal.ssl.Provider', 'j2se-default','N');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(45011,45001,'com.tibco.tibjms.naming.ssl_auth_only', 'true','N');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(45012,45001,'java.property.TIBCO_SECURITY_VENDOR','j2se-default','N');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(45013,45001,'java.property.TIBCO_SECURITY_TRACE', 'false','N');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(45014,45001,'com.tibco.tibjms.naming.ssl_debug_trace', 'true','N');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(45015,45001,'com.tibco.tibjms.naming.ssl_trace','true','N');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(45016,45001,'tibco.jms.queue.queueCF','G2C_EAPCOPTHMYBatchQueueConnectionFactory','N');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(45017,45001,'tibco.jms.inbound.queue.name','citi.gcg.gomth.cop_163124.th_card.epp.modeloffer.error','N');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(45018,45001,'tibco.jms.queue.username','SIT_EAP_USR','N');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(45019,45001,'tibco.jms.queue.password','citi1234','N');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(45020,45001,'tibco.p12.enable','true','N');

INSERT INTO RTS3_APP_DS_EVENT(id, name, app_ds_id, event_type_code, description)
VALUES(45001, 'EAPModelOffer', 45001,'EAPModelOffer', 'TIBCO JMS Events');

INSERT INTO RTS3_EVENT_ACTION(id,app_event_id,action_type_code,exec_order)
VALUES(45001,45001,'PARSE_EVENT',1);

INSERT INTO RTS3_EVENT_ACTION(id,app_event_id,action_type_code,exec_order)
VALUES(45002,45001,'SAVE_MONGO',2);

INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name, param_value,value_encrypted)
VALUES(45001,45002,'mongodb.uri','mongodb://admin_mongodb:P5MwnVbm@maas-mw-d5-u0037.nam.nsroot.net:37017,maas-gt-d5-u0025.nam.nsroot.net:37017,maas-sw-d5-u0007.nam.nsroot.net:37017/GCG_ASIA_TH?ssl=true&authSource=admin','N');
INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name, param_value,value_encrypted)
VALUES(45002,45002,'mongodb.db.name','GCG_ASIA_TH','N');
INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name, param_value,value_encrypted)
VALUES(45003,45002,'mongodb.collection.name','EAP_EPP_COP_MODEL_OFR','N');
INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name,param_value,value_encrypted)
VALUES(45004,45002,'mongodb.db.password','cZNjPmJtqQ0wDFs2DNZsZw==','Y');

INSERT INTO RTS3_APP_DS(id, name, app_id, ds_type_code, description,default_event)
VALUES(45002, 'EPP_POT_TH', 45001,'TIBCO', 'EPP_POT_TH DS' , 'EAPProdOfferTemplate');

INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(45021,45002,'INITIAL_CONTEXT_FACTORY','com.tibco.tibjms.naming.TibjmsInitialContextFactory','N');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(45022,45002,'PROVIDER_URL', 'ssl://gpd-ed9-5c7e.nam.nsroot.net:7243','N');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(45023,45002,'com.tibco.tibjms.naming.ssl_identity', 'hdfs://gftsdev/user/gcgdmasg/security/DIT_EAP_USR.ca1.p12','N');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(45024,45002,'com.tibco.tibjms.naming.ssl_password', '','N');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(45025,45002,'SECURITY_PRINCIPAL', 'SIT_EAP_USR','N');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(45026,45002,'SECURITY_CREDENTIALS', 'citi1234','N');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(45027,45002,'com.tibco.tibjms.naming.security_protocol', 'ssl','N');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(45028,45002,'com.tibco.tibjms.naming.ssl_enable_verify_host', 'false','N');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(45029,45002,'com.tibco.tibjms.naming.ssl_vendor', 'j2se-default','N');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(45030,45002,'com.sun.net.ssl.internal.ssl.Provider', 'j2se-default','N');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(45031,45002,'com.tibco.tibjms.naming.ssl_auth_only', 'true','N');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(45032,45002,'java.property.TIBCO_SECURITY_VENDOR','j2se-default','N');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(45033,45002,'java.property.TIBCO_SECURITY_TRACE', 'false','N');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(45034,45002,'com.tibco.tibjms.naming.ssl_debug_trace', 'true','N');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(45035,45002,'com.tibco.tibjms.naming.ssl_trace','true','N');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(45036,45002,'tibco.jms.queue.queueCF','G2C_EAPCOPTHMYBatchQueueConnectionFactory','N');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(45037,45002,'tibco.jms.inbound.queue.name','citi.gcg.gomth.cop_163124.th_card.epp.prodoffertemplate.update','N');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(45038,45002,'tibco.jms.queue.username','SIT_EAP_USR','N');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(45039,45002,'tibco.jms.queue.password','citi1234','N');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(45040,45002,'tibco.p12.enable','true','N');

INSERT INTO RTS3_APP_DS_EVENT(id, name, app_ds_id, event_type_code, description)
VALUES(45002, 'EAPProdOfferTemplate', 45002,'EAPProdOfferTemplate', 'TIBCO JMS Events');

INSERT INTO RTS3_EVENT_ACTION(id,app_event_id,action_type_code,exec_order)
VALUES(45003,45002,'PARSE_EVENT',1);

INSERT INTO RTS3_EVENT_ACTION(id,app_event_id,action_type_code,exec_order)
VALUES(45004,45002,'SAVE_MONGO',2);

INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name, param_value,value_encrypted)
VALUES(45005,45004,'mongodb.uri','mongodb://admin_mongodb:P5MwnVbm@maas-mw-d5-u0037.nam.nsroot.net:37017,maas-gt-d5-u0025.nam.nsroot.net:37017,maas-sw-d5-u0007.nam.nsroot.net:37017/GCG_ASIA_TH?ssl=true&authSource=admin','N');
INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name, param_value,value_encrypted)
VALUES(45006,45004,'mongodb.db.name','GCG_ASIA_TH','N');
INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name, param_value,value_encrypted)
VALUES(45007,45004,'mongodb.collection.name','EAP_EPP_COP_PROD_OFR_TEMPLATE','N');
INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name,param_value,value_encrypted)
VALUES(45008,45004,'mongodb.db.password','cZNjPmJtqQ0wDFs2DNZsZw==','Y');

INSERT INTO RTS3_APP_DS(id, name, app_id, ds_type_code, description,default_event)
VALUES(45003, 'EPP_TT_TH', 45001,'TIBCO', 'EPP_TT_TH DS' , 'EAPTreatmentTemplate');

INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(45041,45003,'INITIAL_CONTEXT_FACTORY','com.tibco.tibjms.naming.TibjmsInitialContextFactory','N');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(45042,45003,'PROVIDER_URL', 'ssl://gpd-ed9-5c7e.nam.nsroot.net:7243','N');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(45043,45003,'com.tibco.tibjms.naming.ssl_identity', 'hdfs://gftsdev/user/gcgdmasg/security/DIT_EAP_USR.ca1.p12','N');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(45044,45003,'com.tibco.tibjms.naming.ssl_password', '','N');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(45045,45003,'SECURITY_PRINCIPAL', 'SIT_EAP_USR','N');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(45046,45003,'SECURITY_CREDENTIALS', 'citi1234','N');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(45047,45003,'com.tibco.tibjms.naming.security_protocol', 'ssl','N');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(45048,45003,'com.tibco.tibjms.naming.ssl_enable_verify_host', 'false','N');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(45049,45003,'com.tibco.tibjms.naming.ssl_vendor', 'j2se-default','N');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(45050,45003,'com.sun.net.ssl.internal.ssl.Provider', 'j2se-default','N');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(45051,45003,'com.tibco.tibjms.naming.ssl_auth_only', 'true','N');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(45052,45003,'java.property.TIBCO_SECURITY_VENDOR','j2se-default','N');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(45053,45003,'java.property.TIBCO_SECURITY_TRACE', 'false','N');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(45054,45003,'com.tibco.tibjms.naming.ssl_debug_trace', 'true','N');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(45055,45003,'com.tibco.tibjms.naming.ssl_trace','true','N');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(45056,45003,'tibco.jms.queue.queueCF','G2C_EAPCOPTHMYBatchQueueConnectionFactory','N');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(45057,45003,'tibco.jms.inbound.queue.name','citi.gcg.gomth.cop_163124.th_card.epp.treatmenttemplate.update','N');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(45058,45003,'tibco.jms.queue.username','SIT_EAP_USR','N');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(45059,45003,'tibco.jms.queue.password','citi1234','N');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(45060,45003,'tibco.p12.enable','true','N');

INSERT INTO RTS3_APP_DS_EVENT(id, name, app_ds_id, event_type_code, description)
VALUES(45003, 'EAPTreatmentTemplate', 45003,'EAPTreatmentTemplate', 'TIBCO JMS Events');

INSERT INTO RTS3_EVENT_ACTION(id,app_event_id,action_type_code,exec_order)
VALUES(45005,45003,'PARSE_EVENT',1);

INSERT INTO RTS3_EVENT_ACTION(id,app_event_id,action_type_code,exec_order)
VALUES(45006,45003,'SAVE_MONGO',2);

INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name, param_value,value_encrypted)
VALUES(45009,45006,'mongodb.uri','mongodb://admin_mongodb:P5MwnVbm@maas-mw-d5-u0037.nam.nsroot.net:37017,maas-gt-d5-u0025.nam.nsroot.net:37017,maas-sw-d5-u0007.nam.nsroot.net:37017/GCG_ASIA_TH?ssl=true&authSource=admin','N');
INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name, param_value,value_encrypted)
VALUES(45010,45006,'mongodb.db.name','GCG_ASIA_TH','N');
INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name, param_value,value_encrypted)
VALUES(45011,45006,'mongodb.collection.name','EAP_EPP_COP_TRT_TEMPLATE','N');
INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name,param_value,value_encrypted)
VALUES(45012,45006,'mongodb.db.password','cZNjPmJtqQ0wDFs2DNZsZw==','Y');

INSERT INTO RTS3_APP_DS(id, name, app_id, ds_type_code, description,default_event)
VALUES(45004, 'EPP_UOF_TH', 45001,'TIBCO', 'EPP_UOF_TH DS' , 'UpdateOfferFullfillmentEapRequest');

INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(45061,45004,'INITIAL_CONTEXT_FACTORY','com.tibco.tibjms.naming.TibjmsInitialContextFactory','N');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(45062,45004,'PROVIDER_URL', 'ssl://gpd-ed9-5c7e.nam.nsroot.net:7243','N');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(45063,45004,'com.tibco.tibjms.naming.ssl_identity', 'hdfs://gftsdev/user/gcgdmasg/security/DIT_EAP_USR.ca1.p12','N');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(45064,45004,'com.tibco.tibjms.naming.ssl_password', '','N');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(45065,45004,'SECURITY_PRINCIPAL', 'SIT_EAP_USR','N');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(45066,45004,'SECURITY_CREDENTIALS', 'citi1234','N');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(45067,45004,'com.tibco.tibjms.naming.security_protocol', 'ssl','N');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(45068,45004,'com.tibco.tibjms.naming.ssl_enable_verify_host', 'false','N');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(45069,45004,'com.tibco.tibjms.naming.ssl_vendor', 'j2se-default','N');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(45070,45004,'com.sun.net.ssl.internal.ssl.Provider', 'j2se-default','N');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(45071,45004,'com.tibco.tibjms.naming.ssl_auth_only', 'true','N');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(45072,45004,'java.property.TIBCO_SECURITY_VENDOR','j2se-default','N');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(45073,45004,'java.property.TIBCO_SECURITY_TRACE', 'false','N');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(45074,45004,'com.tibco.tibjms.naming.ssl_debug_trace', 'true','N');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(45075,45004,'com.tibco.tibjms.naming.ssl_trace','true','N');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(45076,45004,'tibco.jms.queue.queueCF','G2C_EAPCOPTHMYBatchQueueConnectionFactory','N');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(45077,45004,'tibco.jms.inbound.queue.name','citi.gcg.gomth.cop_163124.th_card.offerfulfillment.modelrequest','N');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(45078,45004,'tibco.jms.queue.username','SIT_EAP_USR','N');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(45079,45004,'tibco.jms.queue.password','citi1234','N');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(45080,45004,'tibco.p12.enable','true','N');

INSERT INTO RTS3_APP_DS_EVENT(id, name, app_ds_id, event_type_code, description)
VALUES(45004, 'UpdateOfferFullfillmentEapRequest', 45004,'UpdateOfferFullfillmentEapRequest', 'TIBCO JMS Events');

INSERT INTO RTS3_EVENT_ACTION(id,app_event_id,action_type_code,exec_order)
VALUES(45007,45004,'PARSE_EVENT',1);

INSERT INTO RTS3_EVENT_ACTION(id,app_event_id,action_type_code,exec_order)
VALUES(45008,45004,'SAVE_MONGO',2);

INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name, param_value,value_encrypted)
VALUES(45013,45008,'mongodb.uri','mongodb://admin_mongodb:P5MwnVbm@maas-mw-d5-u0037.nam.nsroot.net:37017,maas-gt-d5-u0025.nam.nsroot.net:37017,maas-sw-d5-u0007.nam.nsroot.net:37017/GCG_ASIA_TH?ssl=true&authSource=admin','N');
INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name, param_value,value_encrypted)
VALUES(45014,45008,'mongodb.db.name','GCG_ASIA_TH','N');
INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name, param_value,value_encrypted)
VALUES(45015,45008,'mongodb.collection.name','EAP_EPP_COP_OFR_FULFILLMENT','N');
INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name,param_value,value_encrypted)
VALUES(45016,45008,'mongodb.db.password','cZNjPmJtqQ0wDFs2DNZsZw==','Y');

--------------------------------------------------------------------------VN---------------------------------------------------------


INSERT INTO RTS3_APPLICATION (id, name, tenant_id, description, void_ind)
VALUES(46001, 'EPP_EAP_VN', 10001, 'EAP Model Offer', 'N');

INSERT INTO RTS3_APP_PARAM (id, param_type_code, app_id, param_name, param_value, description)
VALUES(46001, 'SPARK_CONF', 46001, 'spark.app.name', 'EPP Spark', null);
INSERT INTO RTS3_APP_PARAM (id, param_type_code, app_id, param_name, param_value, description)
VALUES(46002, 'APP_CONF', 46001, 'app.spark.duration', '300', 'milli-seconds');
INSERT INTO RTS3_APP_PARAM (id, param_type_code, app_id, param_name, param_value, description)
VALUES(46003, 'APP_CONF', 46001, 'app.spark.msg.broker.type', 'TIBCO', null);

INSERT INTO RTS3_APP_DS(id, name, app_id, ds_type_code, description,default_event)
VALUES(46001, 'EPP_MO_VN', 46001,'TIBCO', 'EPP_MO_VN DS' , 'EAPModelOffer');

INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(46001,46001,'INITIAL_CONTEXT_FACTORY','com.tibco.tibjms.naming.TibjmsInitialContextFactory','N');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(46002,46001,'PROVIDER_URL', 'ssl://gpd-ed9-5c7e.nam.nsroot.net:7243','N');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(46003,46001,'com.tibco.tibjms.naming.ssl_identity', 'hdfs://gftsdev/user/gcgdmasg/security/DIT_EAP_USR.ca1.p12','N');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(46004,46001,'com.tibco.tibjms.naming.ssl_password', '','N');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(46005,46001,'SECURITY_PRINCIPAL', 'SIT_EAP_USR','N');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(46006,46001,'SECURITY_CREDENTIALS', 'citi1234','N');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(46007,46001,'com.tibco.tibjms.naming.security_protocol', 'ssl','N');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(46008,46001,'com.tibco.tibjms.naming.ssl_enable_verify_host', 'false','N');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(46009,46001,'com.tibco.tibjms.naming.ssl_vendor', 'j2se-default','N');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(46010,46001,'com.sun.net.ssl.internal.ssl.Provider', 'j2se-default','N');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(46011,46001,'com.tibco.tibjms.naming.ssl_auth_only', 'true','N');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(46012,46001,'java.property.TIBCO_SECURITY_VENDOR','j2se-default','N');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(46013,46001,'java.property.TIBCO_SECURITY_TRACE', 'false','N');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(46014,46001,'com.tibco.tibjms.naming.ssl_debug_trace', 'true','N');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(46015,46001,'com.tibco.tibjms.naming.ssl_trace','true','N');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(46016,46001,'tibco.jms.queue.queueCF','G2C_EAPCOPSGIDVNBatchQueueConnectionFactory','N');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(46017,46001,'tibco.jms.inbound.queue.name','citi.gcg.gomvn.cop_163124.vn_card.epp.modeloffer.error','N');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(46018,46001,'tibco.jms.queue.username','SIT_EAP_USR','N');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(46019,46001,'tibco.jms.queue.password','citi1234','N');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(46020,46001,'tibco.p12.enable','true','N');

INSERT INTO RTS3_APP_DS_EVENT(id, name, app_ds_id, event_type_code, description)
VALUES(46001, 'EAPModelOffer', 46001,'EAPModelOffer', 'TIBCO JMS Events');

INSERT INTO RTS3_EVENT_ACTION(id,app_event_id,action_type_code,exec_order)
VALUES(46001,46001,'PARSE_EVENT',1);

INSERT INTO RTS3_EVENT_ACTION(id,app_event_id,action_type_code,exec_order)
VALUES(46002,46001,'SAVE_MONGO',2);

INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name, param_value,value_encrypted)
VALUES(46001,46002,'mongodb.uri','mongodb://admin_mongodb:P5MwnVbm@maas-mw-d5-u0037.nam.nsroot.net:37017,maas-gt-d5-u0025.nam.nsroot.net:37017,maas-sw-d5-u0007.nam.nsroot.net:37017/GCG_ASIA_VN?ssl=true&authSource=admin','N');
INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name, param_value,value_encrypted)
VALUES(46002,46002,'mongodb.db.name','GCG_ASIA_VN','N');
INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name, param_value,value_encrypted)
VALUES(46003,46002,'mongodb.collection.name','EAP_EPP_COP_MODEL_OFR','N');
INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name,param_value,value_encrypted)
VALUES(46004,46002,'mongodb.db.password','cZNjPmJtqQ0wDFs2DNZsZw==','Y');

INSERT INTO RTS3_APP_DS(id, name, app_id, ds_type_code, description,default_event)
VALUES(46002, 'EPP_POT_VN', 46001,'TIBCO', 'EPP_POT_VN DS' , 'EAPProdOfferTemplate');

INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(46021,46002,'INITIAL_CONTEXT_FACTORY','com.tibco.tibjms.naming.TibjmsInitialContextFactory','N');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(46022,46002,'PROVIDER_URL', 'ssl://gpd-ed9-5c7e.nam.nsroot.net:7243','N');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(46023,46002,'com.tibco.tibjms.naming.ssl_identity', 'hdfs://gftsdev/user/gcgdmasg/security/DIT_EAP_USR.ca1.p12','N');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(46024,46002,'com.tibco.tibjms.naming.ssl_password', '','N');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(46025,46002,'SECURITY_PRINCIPAL', 'SIT_EAP_USR','N');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(46026,46002,'SECURITY_CREDENTIALS', 'citi1234','N');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(46027,46002,'com.tibco.tibjms.naming.security_protocol', 'ssl','N');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(46028,46002,'com.tibco.tibjms.naming.ssl_enable_verify_host', 'false','N');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(46029,46002,'com.tibco.tibjms.naming.ssl_vendor', 'j2se-default','N');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(46030,46002,'com.sun.net.ssl.internal.ssl.Provider', 'j2se-default','N');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(46031,46002,'com.tibco.tibjms.naming.ssl_auth_only', 'true','N');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(46032,46002,'java.property.TIBCO_SECURITY_VENDOR','j2se-default','N');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(46033,46002,'java.property.TIBCO_SECURITY_TRACE', 'false','N');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(46034,46002,'com.tibco.tibjms.naming.ssl_debug_trace', 'true','N');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(46035,46002,'com.tibco.tibjms.naming.ssl_trace','true','N');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(46036,46002,'tibco.jms.queue.queueCF','G2C_EAPCOPSGIDVNBatchQueueConnectionFactory','N');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(46037,46002,'tibco.jms.inbound.queue.name','citi.gcg.gomvn.cop_163124.vn_card.epp.prodoffertemplate.update','N');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(46038,46002,'tibco.jms.queue.username','SIT_EAP_USR','N');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(46039,46002,'tibco.jms.queue.password','citi1234','N');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(46040,46002,'tibco.p12.enable','true','N');

INSERT INTO RTS3_APP_DS_EVENT(id, name, app_ds_id, event_type_code, description)
VALUES(46002, 'EAPProdOfferTemplate', 46002,'EAPProdOfferTemplate', 'TIBCO JMS Events');

INSERT INTO RTS3_EVENT_ACTION(id,app_event_id,action_type_code,exec_order)
VALUES(46003,46002,'PARSE_EVENT',1);

INSERT INTO RTS3_EVENT_ACTION(id,app_event_id,action_type_code,exec_order)
VALUES(46004,46002,'SAVE_MONGO',2);

INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name, param_value,value_encrypted)
VALUES(46005,46004,'mongodb.uri','mongodb://admin_mongodb:P5MwnVbm@maas-mw-d5-u0037.nam.nsroot.net:37017,maas-gt-d5-u0025.nam.nsroot.net:37017,maas-sw-d5-u0007.nam.nsroot.net:37017/GCG_ASIA_VN?ssl=true&authSource=admin','N');
INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name, param_value,value_encrypted)
VALUES(46006,46004,'mongodb.db.name','GCG_ASIA_VN','N');
INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name, param_value,value_encrypted)
VALUES(46007,46004,'mongodb.collection.name','EAP_EPP_COP_PROD_OFR_TEMPLATE','N');
INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name,param_value,value_encrypted)
VALUES(46008,46004,'mongodb.db.password','cZNjPmJtqQ0wDFs2DNZsZw==','Y');

INSERT INTO RTS3_APP_DS(id, name, app_id, ds_type_code, description,default_event)
VALUES(46003, 'EPP_TT_VN', 46001,'TIBCO', 'EPP_TT_VN DS' , 'EAPTreatmentTemplate');

INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(46041,46003,'INITIAL_CONTEXT_FACTORY','com.tibco.tibjms.naming.TibjmsInitialContextFactory','N');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(46042,46003,'PROVIDER_URL', 'ssl://gpd-ed9-5c7e.nam.nsroot.net:7243','N');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(46043,46003,'com.tibco.tibjms.naming.ssl_identity', 'hdfs://gftsdev/user/gcgdmasg/security/DIT_EAP_USR.ca1.p12','N');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(46044,46003,'com.tibco.tibjms.naming.ssl_password', '','N');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(46045,46003,'SECURITY_PRINCIPAL', 'SIT_EAP_USR','N');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(46046,46003,'SECURITY_CREDENTIALS', 'citi1234','N');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(46047,46003,'com.tibco.tibjms.naming.security_protocol', 'ssl','N');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(46048,46003,'com.tibco.tibjms.naming.ssl_enable_verify_host', 'false','N');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(46049,46003,'com.tibco.tibjms.naming.ssl_vendor', 'j2se-default','N');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(46050,46003,'com.sun.net.ssl.internal.ssl.Provider', 'j2se-default','N');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(46051,46003,'com.tibco.tibjms.naming.ssl_auth_only', 'true','N');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(46052,46003,'java.property.TIBCO_SECURITY_VENDOR','j2se-default','N');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(46053,46003,'java.property.TIBCO_SECURITY_TRACE', 'false','N');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(46054,46003,'com.tibco.tibjms.naming.ssl_debug_trace', 'true','N');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(46055,46003,'com.tibco.tibjms.naming.ssl_trace','true','N');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(46056,46003,'tibco.jms.queue.queueCF','G2C_EAPCOPSGIDVNBatchQueueConnectionFactory','N');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(46057,46003,'tibco.jms.inbound.queue.name','citi.gcg.gomvn.cop_163124.vn_card.epp.treatmenttemplate.update','N');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(46058,46003,'tibco.jms.queue.username','SIT_EAP_USR','N');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(46059,46003,'tibco.jms.queue.password','citi1234','N');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(46060,46003,'tibco.p12.enable','true','N');

INSERT INTO RTS3_APP_DS_EVENT(id, name, app_ds_id, event_type_code, description)
VALUES(46003, 'EAPTreatmentTemplate', 46003,'EAPTreatmentTemplate', 'TIBCO JMS Events');

INSERT INTO RTS3_EVENT_ACTION(id,app_event_id,action_type_code,exec_order)
VALUES(46005,46003,'PARSE_EVENT',1);

INSERT INTO RTS3_EVENT_ACTION(id,app_event_id,action_type_code,exec_order)
VALUES(46006,46003,'SAVE_MONGO',2);

INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name, param_value,value_encrypted)
VALUES(46009,46006,'mongodb.uri','mongodb://admin_mongodb:P5MwnVbm@maas-mw-d5-u0037.nam.nsroot.net:37017,maas-gt-d5-u0025.nam.nsroot.net:37017,maas-sw-d5-u0007.nam.nsroot.net:37017/GCG_ASIA_VN?ssl=true&authSource=admin','N');
INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name, param_value,value_encrypted)
VALUES(46010,46006,'mongodb.db.name','GCG_ASIA_VN','N');
INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name, param_value,value_encrypted)
VALUES(46011,46006,'mongodb.collection.name','EAP_EPP_COP_TRT_TEMPLATE','N');
INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name,param_value,value_encrypted)
VALUES(46012,46006,'mongodb.db.password','cZNjPmJtqQ0wDFs2DNZsZw==','Y');

INSERT INTO RTS3_APP_DS(id, name, app_id, ds_type_code, description,default_event)
VALUES(46004, 'EPP_UOF_VN', 46001,'TIBCO', 'EPP_UOF_VN DS' , 'UpdateOfferFullfillmentEapRequest');

INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(46061,46004,'INITIAL_CONTEXT_FACTORY','com.tibco.tibjms.naming.TibjmsInitialContextFactory','N');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(46062,46004,'PROVIDER_URL', 'ssl://gpd-ed9-5c7e.nam.nsroot.net:7243','N');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(46063,46004,'com.tibco.tibjms.naming.ssl_identity', 'hdfs://gftsdev/user/gcgdmasg/security/DIT_EAP_USR.ca1.p12','N');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(46064,46004,'com.tibco.tibjms.naming.ssl_password', '','N');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(46065,46004,'SECURITY_PRINCIPAL', 'SIT_EAP_USR','N');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(46066,46004,'SECURITY_CREDENTIALS', 'citi1234','N');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(46067,46004,'com.tibco.tibjms.naming.security_protocol', 'ssl','N');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(46068,46004,'com.tibco.tibjms.naming.ssl_enable_verify_host', 'false','N');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(46069,46004,'com.tibco.tibjms.naming.ssl_vendor', 'j2se-default','N');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(46070,46004,'com.sun.net.ssl.internal.ssl.Provider', 'j2se-default','N');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(46071,46004,'com.tibco.tibjms.naming.ssl_auth_only', 'true','N');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(46072,46004,'java.property.TIBCO_SECURITY_VENDOR','j2se-default','N');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(46073,46004,'java.property.TIBCO_SECURITY_TRACE', 'false','N');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(46074,46004,'com.tibco.tibjms.naming.ssl_debug_trace', 'true','N');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(46075,46004,'com.tibco.tibjms.naming.ssl_trace','true','N');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(46076,46004,'tibco.jms.queue.queueCF','G2C_EAPCOPSGIDVNBatchQueueConnectionFactory','N');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(46077,46004,'tibco.jms.inbound.queue.name','citi.gcg.gomvn.cop_163124.vn_card.offerfulfillment.modelrequest','N');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(46078,46004,'tibco.jms.queue.username','SIT_EAP_USR','N');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(46079,46004,'tibco.jms.queue.password','citi1234','N');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(46080,46004,'tibco.p12.enable','true','N');

INSERT INTO RTS3_APP_DS_EVENT(id, name, app_ds_id, event_type_code, description)
VALUES(46004, 'UpdateOfferFullfillmentEapRequest', 46004,'UpdateOfferFullfillmentEapRequest', 'TIBCO JMS Events');

INSERT INTO RTS3_EVENT_ACTION(id,app_event_id,action_type_code,exec_order)
VALUES(46007,46004,'PARSE_EVENT',1);

INSERT INTO RTS3_EVENT_ACTION(id,app_event_id,action_type_code,exec_order)
VALUES(46008,46004,'SAVE_MONGO',2);

INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name, param_value,value_encrypted)
VALUES(46013,46008,'mongodb.uri','mongodb://admin_mongodb:P5MwnVbm@maas-mw-d5-u0037.nam.nsroot.net:37017,maas-gt-d5-u0025.nam.nsroot.net:37017,maas-sw-d5-u0007.nam.nsroot.net:37017/GCG_ASIA_VN?ssl=true&authSource=admin','N');
INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name, param_value,value_encrypted)
VALUES(46014,46008,'mongodb.db.name','GCG_ASIA_VN','N');
INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name, param_value,value_encrypted)
VALUES(46015,46008,'mongodb.collection.name','EAP_EPP_COP_OFR_FULFILLMENT','N');
INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name,param_value,value_encrypted)
VALUES(46016,46008,'mongodb.db.password','cZNjPmJtqQ0wDFs2DNZsZw==','Y');


-----------------------------------------------------------------------------ID-------------------------------------------------------------

INSERT INTO RTS3_APPLICATION (id, name, tenant_id, description, void_ind)
VALUES(47001, 'EPP_EAP_ID', 10001, 'EAP Model Offer', 'N');

INSERT INTO RTS3_APP_PARAM (id, param_type_code, app_id, param_name, param_value, description)
VALUES(47001, 'SPARK_CONF', 47001, 'spark.app.name', 'EPP Spark', null);
INSERT INTO RTS3_APP_PARAM (id, param_type_code, app_id, param_name, param_value, description)
VALUES(47002, 'APP_CONF', 47001, 'app.spark.duration', '300', 'milli-seconds');
INSERT INTO RTS3_APP_PARAM (id, param_type_code, app_id, param_name, param_value, description)
VALUES(47003, 'APP_CONF', 47001, 'app.spark.msg.broker.type', 'TIBCO', null);

INSERT INTO RTS3_APP_DS(id, name, app_id, ds_type_code, description,default_event)
VALUES(47001, 'EPP_MO_ID', 47001,'TIBCO', 'EPP_MO_ID DS' , 'EAPModelOffer');

INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(47001,47001,'INITIAL_CONTEXT_FACTORY','com.tibco.tibjms.naming.TibjmsInitialContextFactory','N');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(47002,47001,'PROVIDER_URL', 'ssl://gpd-ed9-5c7e.nam.nsroot.net:7243','N');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(47003,47001,'com.tibco.tibjms.naming.ssl_identity', 'hdfs://gftsdev/user/gcgdmasg/security/DIT_EAP_USR.ca1.p12','N');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(47004,47001,'com.tibco.tibjms.naming.ssl_password', '','N');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(47005,47001,'SECURITY_PRINCIPAL', 'SIT_EAP_USR','N');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(47006,47001,'SECURITY_CREDENTIALS', 'citi1234','N');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(47007,47001,'com.tibco.tibjms.naming.security_protocol', 'ssl','N');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(47008,47001,'com.tibco.tibjms.naming.ssl_enable_verify_host', 'false','N');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(47009,47001,'com.tibco.tibjms.naming.ssl_vendor', 'j2se-default','N');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(47010,47001,'com.sun.net.ssl.internal.ssl.Provider', 'j2se-default','N');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(47011,47001,'com.tibco.tibjms.naming.ssl_auth_only', 'true','N');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(47012,47001,'java.property.TIBCO_SECURITY_VENDOR','j2se-default','N');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(47013,47001,'java.property.TIBCO_SECURITY_TRACE', 'false','N');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(47014,47001,'com.tibco.tibjms.naming.ssl_debug_trace', 'true','N');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(47015,47001,'com.tibco.tibjms.naming.ssl_trace','true','N');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(47016,47001,'tibco.jms.queue.queueCF','G2C_EAPCOPSGIDVNBatchQueueConnectionFactory','N');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(47017,47001,'tibco.jms.inbound.queue.name','citi.gcg.gomid.cop_163124.id_card.epp.modeloffer.error','N');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(47018,47001,'tibco.jms.queue.username','SIT_EAP_USR','N');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(47019,47001,'tibco.jms.queue.password','citi1234','N');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(47020,47001,'tibco.p12.enable','true','N');

INSERT INTO RTS3_APP_DS_EVENT(id, name, app_ds_id, event_type_code, description)
VALUES(47001, 'EAPModelOffer', 47001,'EAPModelOffer', 'TIBCO JMS Events');

INSERT INTO RTS3_EVENT_ACTION(id,app_event_id,action_type_code,exec_order)
VALUES(47001,47001,'PARSE_EVENT',1);

INSERT INTO RTS3_EVENT_ACTION(id,app_event_id,action_type_code,exec_order)
VALUES(47002,47001,'SAVE_MONGO',2);

INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name, param_value,value_encrypted)
VALUES(47001,47002,'mongodb.uri','mongodb://admin_mongodb:P5MwnVbm@maas-mw-d5-u0037.nam.nsroot.net:37017,maas-gt-d5-u0025.nam.nsroot.net:37017,maas-sw-d5-u0007.nam.nsroot.net:37017/GCG_ASIA_ID?ssl=true&authSource=admin','N');
INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name, param_value,value_encrypted)
VALUES(47002,47002,'mongodb.db.name','GCG_ASIA_ID','N');
INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name, param_value,value_encrypted)
VALUES(47003,47002,'mongodb.collection.name','EAP_EPP_COP_MODEL_OFR','N');
INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name,param_value,value_encrypted)
VALUES(47004,47002,'mongodb.db.password','cZNjPmJtqQ0wDFs2DNZsZw==','Y');

INSERT INTO RTS3_APP_DS(id, name, app_id, ds_type_code, description,default_event)
VALUES(47002, 'EPP_POT_ID', 47001,'TIBCO', 'EPP_POT_ID DS' , 'EAPProdOfferTemplate');

INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(47021,47002,'INITIAL_CONTEXT_FACTORY','com.tibco.tibjms.naming.TibjmsInitialContextFactory','N');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(47022,47002,'PROVIDER_URL', 'ssl://gpd-ed9-5c7e.nam.nsroot.net:7243','N');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(47023,47002,'com.tibco.tibjms.naming.ssl_identity', 'hdfs://gftsdev/user/gcgdmasg/security/DIT_EAP_USR.ca1.p12','N');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(47024,47002,'com.tibco.tibjms.naming.ssl_password', '','N');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(47025,47002,'SECURITY_PRINCIPAL', 'SIT_EAP_USR','N');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(47026,47002,'SECURITY_CREDENTIALS', 'citi1234','N');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(47027,47002,'com.tibco.tibjms.naming.security_protocol', 'ssl','N');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(47028,47002,'com.tibco.tibjms.naming.ssl_enable_verify_host', 'false','N');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(47029,47002,'com.tibco.tibjms.naming.ssl_vendor', 'j2se-default','N');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(47030,47002,'com.sun.net.ssl.internal.ssl.Provider', 'j2se-default','N');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(47031,47002,'com.tibco.tibjms.naming.ssl_auth_only', 'true','N');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(47032,47002,'java.property.TIBCO_SECURITY_VENDOR','j2se-default','N');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(47033,47002,'java.property.TIBCO_SECURITY_TRACE', 'false','N');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(47034,47002,'com.tibco.tibjms.naming.ssl_debug_trace', 'true','N');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(47035,47002,'com.tibco.tibjms.naming.ssl_trace','true','N');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(47036,47002,'tibco.jms.queue.queueCF','G2C_EAPCOPSGIDVNBatchQueueConnectionFactory','N');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(47037,47002,'tibco.jms.inbound.queue.name','citi.gcg.gomid.cop_163124.id_card.epp.prodoffertemplate.update','N');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(47038,47002,'tibco.jms.queue.username','SIT_EAP_USR','N');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(47039,47002,'tibco.jms.queue.password','citi1234','N');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(47040,47002,'tibco.p12.enable','true','N');

INSERT INTO RTS3_APP_DS_EVENT(id, name, app_ds_id, event_type_code, description)
VALUES(47002, 'EAPProdOfferTemplate', 47002,'EAPProdOfferTemplate', 'TIBCO JMS Events');

INSERT INTO RTS3_EVENT_ACTION(id,app_event_id,action_type_code,exec_order)
VALUES(47003,47002,'PARSE_EVENT',1);

INSERT INTO RTS3_EVENT_ACTION(id,app_event_id,action_type_code,exec_order)
VALUES(47004,47002,'SAVE_MONGO',2);

INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name, param_value,value_encrypted)
VALUES(47005,47004,'mongodb.uri','mongodb://admin_mongodb:P5MwnVbm@maas-mw-d5-u0037.nam.nsroot.net:37017,maas-gt-d5-u0025.nam.nsroot.net:37017,maas-sw-d5-u0007.nam.nsroot.net:37017/GCG_ASIA_ID?ssl=true&authSource=admin','N');
INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name, param_value,value_encrypted)
VALUES(47006,47004,'mongodb.db.name','GCG_ASIA_ID','N');
INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name, param_value,value_encrypted)
VALUES(47007,47004,'mongodb.collection.name','EAP_EPP_COP_PROD_OFR_TEMPLATE','N');
INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name,param_value,value_encrypted)
VALUES(47008,47004,'mongodb.db.password','cZNjPmJtqQ0wDFs2DNZsZw==','Y');

INSERT INTO RTS3_APP_DS(id, name, app_id, ds_type_code, description,default_event)
VALUES(47003, 'EPP_TT_ID', 47001,'TIBCO', 'EPP_TT_ID DS' , 'EAPTreatmentTemplate');

INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(47041,47003,'INITIAL_CONTEXT_FACTORY','com.tibco.tibjms.naming.TibjmsInitialContextFactory','N');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(47042,47003,'PROVIDER_URL', 'ssl://gpd-ed9-5c7e.nam.nsroot.net:7243','N');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(47043,47003,'com.tibco.tibjms.naming.ssl_identity', 'hdfs://gftsdev/user/gcgdmasg/security/DIT_EAP_USR.ca1.p12','N');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(47044,47003,'com.tibco.tibjms.naming.ssl_password', '','N');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(47045,47003,'SECURITY_PRINCIPAL', 'SIT_EAP_USR','N');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(47046,47003,'SECURITY_CREDENTIALS', 'citi1234','N');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(47047,47003,'com.tibco.tibjms.naming.security_protocol', 'ssl','N');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(47048,47003,'com.tibco.tibjms.naming.ssl_enable_verify_host', 'false','N');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(47049,47003,'com.tibco.tibjms.naming.ssl_vendor', 'j2se-default','N');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(47050,47003,'com.sun.net.ssl.internal.ssl.Provider', 'j2se-default','N');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(47051,47003,'com.tibco.tibjms.naming.ssl_auth_only', 'true','N');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(47052,47003,'java.property.TIBCO_SECURITY_VENDOR','j2se-default','N');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(47053,47003,'java.property.TIBCO_SECURITY_TRACE', 'false','N');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(47054,47003,'com.tibco.tibjms.naming.ssl_debug_trace', 'true','N');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(47055,47003,'com.tibco.tibjms.naming.ssl_trace','true','N');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(47056,47003,'tibco.jms.queue.queueCF','G2C_EAPCOPSGIDVNBatchQueueConnectionFactory','N');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(47057,47003,'tibco.jms.inbound.queue.name','citi.gcg.gomid.cop_163124.id_card.epp.treatmenttemplate.update','N');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(47058,47003,'tibco.jms.queue.username','SIT_EAP_USR','N');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(47059,47003,'tibco.jms.queue.password','citi1234','N');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(47060,47003,'tibco.p12.enable','true','N');

INSERT INTO RTS3_APP_DS_EVENT(id, name, app_ds_id, event_type_code, description)
VALUES(47003, 'EAPTreatmentTemplate', 47003,'EAPTreatmentTemplate', 'TIBCO JMS Events');

INSERT INTO RTS3_EVENT_ACTION(id,app_event_id,action_type_code,exec_order)
VALUES(47005,47003,'PARSE_EVENT',1);

INSERT INTO RTS3_EVENT_ACTION(id,app_event_id,action_type_code,exec_order)
VALUES(47006,47003,'SAVE_MONGO',2);

INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name, param_value,value_encrypted)
VALUES(47009,47006,'mongodb.uri','mongodb://admin_mongodb:P5MwnVbm@maas-mw-d5-u0037.nam.nsroot.net:37017,maas-gt-d5-u0025.nam.nsroot.net:37017,maas-sw-d5-u0007.nam.nsroot.net:37017/GCG_ASIA_ID?ssl=true&authSource=admin','N');
INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name, param_value,value_encrypted)
VALUES(47010,47006,'mongodb.db.name','GCG_ASIA_ID','N');
INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name, param_value,value_encrypted)
VALUES(47011,47006,'mongodb.collection.name','EAP_EPP_COP_TRT_TEMPLATE','N');
INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name,param_value,value_encrypted)
VALUES(47012,47006,'mongodb.db.password','cZNjPmJtqQ0wDFs2DNZsZw==','Y');

INSERT INTO RTS3_APP_DS(id, name, app_id, ds_type_code, description,default_event)
VALUES(47004, 'EPP_UOF_ID', 47001,'TIBCO', 'EPP_UOF_ID DS' , 'UpdateOfferFullfillmentEapRequest');

INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(47061,47004,'INITIAL_CONTEXT_FACTORY','com.tibco.tibjms.naming.TibjmsInitialContextFactory','N');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(47062,47004,'PROVIDER_URL', 'ssl://gpd-ed9-5c7e.nam.nsroot.net:7243','N');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(47063,47004,'com.tibco.tibjms.naming.ssl_identity', 'hdfs://gftsdev/user/gcgdmasg/security/DIT_EAP_USR.ca1.p12','N');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(47064,47004,'com.tibco.tibjms.naming.ssl_password', '','N');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(47065,47004,'SECURITY_PRINCIPAL', 'SIT_EAP_USR','N');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(47066,47004,'SECURITY_CREDENTIALS', 'citi1234','N');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(47067,47004,'com.tibco.tibjms.naming.security_protocol', 'ssl','N');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(47068,47004,'com.tibco.tibjms.naming.ssl_enable_verify_host', 'false','N');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(47069,47004,'com.tibco.tibjms.naming.ssl_vendor', 'j2se-default','N');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(47070,47004,'com.sun.net.ssl.internal.ssl.Provider', 'j2se-default','N');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(47071,47004,'com.tibco.tibjms.naming.ssl_auth_only', 'true','N');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(47072,47004,'java.property.TIBCO_SECURITY_VENDOR','j2se-default','N');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(47073,47004,'java.property.TIBCO_SECURITY_TRACE', 'false','N');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(47074,47004,'com.tibco.tibjms.naming.ssl_debug_trace', 'true','N');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(47075,47004,'com.tibco.tibjms.naming.ssl_trace','true','N');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(47076,47004,'tibco.jms.queue.queueCF','G2C_EAPCOPSGIDVNBatchQueueConnectionFactory','N');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(47077,47004,'tibco.jms.inbound.queue.name','citi.gcg.gomid.cop_163124.id_card.offerfulfillment.modelrequest','N');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(47078,47004,'tibco.jms.queue.username','SIT_EAP_USR','N');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(47079,47004,'tibco.jms.queue.password','citi1234','N');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(47080,47004,'tibco.p12.enable','true','N');

INSERT INTO RTS3_APP_DS_EVENT(id, name, app_ds_id, event_type_code, description)
VALUES(47004, 'UpdateOfferFullfillmentEapRequest', 47004,'UpdateOfferFullfillmentEapRequest', 'TIBCO JMS Events');

INSERT INTO RTS3_EVENT_ACTION(id,app_event_id,action_type_code,exec_order)
VALUES(47007,47004,'PARSE_EVENT',1);

INSERT INTO RTS3_EVENT_ACTION(id,app_event_id,action_type_code,exec_order)
VALUES(47008,47004,'SAVE_MONGO',2);

INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name, param_value,value_encrypted)
VALUES(47013,47008,'mongodb.uri','mongodb://admin_mongodb:P5MwnVbm@maas-mw-d5-u0037.nam.nsroot.net:37017,maas-gt-d5-u0025.nam.nsroot.net:37017,maas-sw-d5-u0007.nam.nsroot.net:37017/GCG_ASIA_ID?ssl=true&authSource=admin','N');
INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name, param_value,value_encrypted)
VALUES(47014,47008,'mongodb.db.name','GCG_ASIA_ID','N');
INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name, param_value,value_encrypted)
VALUES(47015,47008,'mongodb.collection.name','EAP_EPP_COP_OFR_FULFILLMENT','N');
INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name,param_value,value_encrypted)
VALUES(47016,47008,'mongodb.db.password','cZNjPmJtqQ0wDFs2DNZsZw==','Y');

--------------------------------------------------------------MY-------------------------------------------------------------------


INSERT INTO RTS3_APPLICATION (id, name, tenant_id, description, void_ind)
VALUES(48001, 'EPP_EAP_MY', 10001, 'EAP Model Offer', 'N');

INSERT INTO RTS3_APP_PARAM (id, param_type_code, app_id, param_name, param_value, description)
VALUES(48001, 'SPARK_CONF', 48001, 'spark.app.name', 'EPP Spark', null);
INSERT INTO RTS3_APP_PARAM (id, param_type_code, app_id, param_name, param_value, description)
VALUES(48002, 'APP_CONF', 48001, 'app.spark.duration', '300', 'milli-seconds');
INSERT INTO RTS3_APP_PARAM (id, param_type_code, app_id, param_name, param_value, description)
VALUES(48003, 'APP_CONF', 48001, 'app.spark.msg.broker.type', 'TIBCO', null);

INSERT INTO RTS3_APP_DS(id, name, app_id, ds_type_code, description,default_event)
VALUES(48001, 'EPP_MO_MY', 48001,'TIBCO', 'EPP_MO_MY DS' , 'EAPModelOffer');

INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(48001,48001,'INITIAL_CONTEXT_FACTORY','com.tibco.tibjms.naming.TibjmsInitialContextFactory','N');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(48002,48001,'PROVIDER_URL', 'ssl://gpd-ed9-5c7e.nam.nsroot.net:7243','N');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(48003,48001,'com.tibco.tibjms.naming.ssl_identity', 'hdfs://gftsdev/user/gcgdmasg/security/DIT_EAP_USR.ca1.p12','N');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(48004,48001,'com.tibco.tibjms.naming.ssl_password', '','N');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(48005,48001,'SECURITY_PRINCIPAL', 'SIT_EAP_USR','N');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(48006,48001,'SECURITY_CREDENTIALS', 'citi1234','N');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(48007,48001,'com.tibco.tibjms.naming.security_protocol', 'ssl','N');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(48008,48001,'com.tibco.tibjms.naming.ssl_enable_verify_host', 'false','N');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(48009,48001,'com.tibco.tibjms.naming.ssl_vendor', 'j2se-default','N');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(48010,48001,'com.sun.net.ssl.internal.ssl.Provider', 'j2se-default','N');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(48011,48001,'com.tibco.tibjms.naming.ssl_auth_only', 'true','N');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(48012,48001,'java.property.TIBCO_SECURITY_VENDOR','j2se-default','N');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(48013,48001,'java.property.TIBCO_SECURITY_TRACE', 'false','N');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(48014,48001,'com.tibco.tibjms.naming.ssl_debug_trace', 'true','N');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(48015,48001,'com.tibco.tibjms.naming.ssl_trace','true','N');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(48016,48001,'tibco.jms.queue.queueCF','G2C_EAPCOPTHMYBatchQueueConnectionFactory','N');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(48017,48001,'tibco.jms.inbound.queue.name','citi.gcg.gommy.cop_163124.my_card.epp.modeloffer.error','N');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(48018,48001,'tibco.jms.queue.username','SIT_EAP_USR','N');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(48019,48001,'tibco.jms.queue.password','citi1234','N');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(48020,48001,'tibco.p12.enable','true','N');

INSERT INTO RTS3_APP_DS_EVENT(id, name, app_ds_id, event_type_code, description)
VALUES(48001, 'EAPModelOffer', 48001,'EAPModelOffer', 'TIBCO JMS Events');

INSERT INTO RTS3_EVENT_ACTION(id,app_event_id,action_type_code,exec_order)
VALUES(48001,48001,'PARSE_EVENT',1);

INSERT INTO RTS3_EVENT_ACTION(id,app_event_id,action_type_code,exec_order)
VALUES(48002,48001,'SAVE_MONGO',2);

INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name, param_value,value_encrypted)
VALUES(48001,48002,'mongodb.uri','mongodb://admin_mongodb:P5MwnVbm@maas-mw-d5-u0037.nam.nsroot.net:37017,maas-gt-d5-u0025.nam.nsroot.net:37017,maas-sw-d5-u0007.nam.nsroot.net:37017/GCG_ASIA_MY?ssl=true&authSource=admin','N');
INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name, param_value,value_encrypted)
VALUES(48002,48002,'mongodb.db.name','GCG_ASIA_MY','N');
INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name, param_value,value_encrypted)
VALUES(48003,48002,'mongodb.collection.name','EAP_EPP_COP_MODEL_OFR','N');
INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name,param_value,value_encrypted)
VALUES(48004,48002,'mongodb.db.password','cZNjPmJtqQ0wDFs2DNZsZw==','Y');

INSERT INTO RTS3_APP_DS(id, name, app_id, ds_type_code, description,default_event)
VALUES(48002, 'EPP_POT_MY', 48001,'TIBCO', 'EPP_POT_MY DS' , 'EAPProdOfferTemplate');

INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(48021,48002,'INITIAL_CONTEXT_FACTORY','com.tibco.tibjms.naming.TibjmsInitialContextFactory','N');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(48022,48002,'PROVIDER_URL', 'ssl://gpd-ed9-5c7e.nam.nsroot.net:7243','N');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(48023,48002,'com.tibco.tibjms.naming.ssl_identity', 'hdfs://gftsdev/user/gcgdmasg/security/DIT_EAP_USR.ca1.p12','N');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(48024,48002,'com.tibco.tibjms.naming.ssl_password', '','N');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(48025,48002,'SECURITY_PRINCIPAL', 'SIT_EAP_USR','N');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(48026,48002,'SECURITY_CREDENTIALS', 'citi1234','N');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(48027,48002,'com.tibco.tibjms.naming.security_protocol', 'ssl','N');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(48028,48002,'com.tibco.tibjms.naming.ssl_enable_verify_host', 'false','N');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(48029,48002,'com.tibco.tibjms.naming.ssl_vendor', 'j2se-default','N');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(48030,48002,'com.sun.net.ssl.internal.ssl.Provider', 'j2se-default','N');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(48031,48002,'com.tibco.tibjms.naming.ssl_auth_only', 'true','N');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(48032,48002,'java.property.TIBCO_SECURITY_VENDOR','j2se-default','N');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(48033,48002,'java.property.TIBCO_SECURITY_TRACE', 'false','N');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(48034,48002,'com.tibco.tibjms.naming.ssl_debug_trace', 'true','N');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(48035,48002,'com.tibco.tibjms.naming.ssl_trace','true','N');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(48036,48002,'tibco.jms.queue.queueCF','G2C_EAPCOPTHMYBatchQueueConnectionFactory','N');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(48037,48002,'tibco.jms.inbound.queue.name','citi.gcg.gommy.cop_163124.my_card.epp.prodoffertemplate.update','N');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(48038,48002,'tibco.jms.queue.username','SIT_EAP_USR','N');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(48039,48002,'tibco.jms.queue.password','citi1234','N');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(48040,48002,'tibco.p12.enable','true','N');

INSERT INTO RTS3_APP_DS_EVENT(id, name, app_ds_id, event_type_code, description)
VALUES(48002, 'EAPProdOfferTemplate', 48002,'EAPProdOfferTemplate', 'TIBCO JMS Events');

INSERT INTO RTS3_EVENT_ACTION(id,app_event_id,action_type_code,exec_order)
VALUES(48003,48002,'PARSE_EVENT',1);

INSERT INTO RTS3_EVENT_ACTION(id,app_event_id,action_type_code,exec_order)
VALUES(48004,48002,'SAVE_MONGO',2);

INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name, param_value,value_encrypted)
VALUES(48005,48004,'mongodb.uri','mongodb://admin_mongodb:P5MwnVbm@maas-mw-d5-u0037.nam.nsroot.net:37017,maas-gt-d5-u0025.nam.nsroot.net:37017,maas-sw-d5-u0007.nam.nsroot.net:37017/GCG_ASIA_MY?ssl=true&authSource=admin','N');
INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name, param_value,value_encrypted)
VALUES(48006,48004,'mongodb.db.name','GCG_ASIA_MY','N');
INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name, param_value,value_encrypted)
VALUES(48007,48004,'mongodb.collection.name','EAP_EPP_COP_PROD_OFR_TEMPLATE','N');
INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name,param_value,value_encrypted)
VALUES(48008,48004,'mongodb.db.password','cZNjPmJtqQ0wDFs2DNZsZw==','Y');

INSERT INTO RTS3_APP_DS(id, name, app_id, ds_type_code, description,default_event)
VALUES(48003, 'EPP_TT_MY', 48001,'TIBCO', 'EPP_TT_MY DS' , 'EAPTreatmentTemplate');

INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(48041,48003,'INITIAL_CONTEXT_FACTORY','com.tibco.tibjms.naming.TibjmsInitialContextFactory','N');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(48042,48003,'PROVIDER_URL', 'ssl://gpd-ed9-5c7e.nam.nsroot.net:7243','N');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(48043,48003,'com.tibco.tibjms.naming.ssl_identity', 'hdfs://gftsdev/user/gcgdmasg/security/DIT_EAP_USR.ca1.p12','N');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(48044,48003,'com.tibco.tibjms.naming.ssl_password', '','N');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(48045,48003,'SECURITY_PRINCIPAL', 'SIT_EAP_USR','N');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(48046,48003,'SECURITY_CREDENTIALS', 'citi1234','N');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(48047,48003,'com.tibco.tibjms.naming.security_protocol', 'ssl','N');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(48048,48003,'com.tibco.tibjms.naming.ssl_enable_verify_host', 'false','N');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(48049,48003,'com.tibco.tibjms.naming.ssl_vendor', 'j2se-default','N');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(48050,48003,'com.sun.net.ssl.internal.ssl.Provider', 'j2se-default','N');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(48051,48003,'com.tibco.tibjms.naming.ssl_auth_only', 'true','N');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(48052,48003,'java.property.TIBCO_SECURITY_VENDOR','j2se-default','N');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(48053,48003,'java.property.TIBCO_SECURITY_TRACE', 'false','N');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(48054,48003,'com.tibco.tibjms.naming.ssl_debug_trace', 'true','N');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(48055,48003,'com.tibco.tibjms.naming.ssl_trace','true','N');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(48056,48003,'tibco.jms.queue.queueCF','G2C_EAPCOPTHMYBatchQueueConnectionFactory','N');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(48057,48003,'tibco.jms.inbound.queue.name','citi.gcg.gommy.cop_163124.my_card.epp.treatmenttemplate.update','N');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(48058,48003,'tibco.jms.queue.username','SIT_EAP_USR','N');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(48059,48003,'tibco.jms.queue.password','citi1234','N');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(48060,48003,'tibco.p12.enable','true','N');

INSERT INTO RTS3_APP_DS_EVENT(id, name, app_ds_id, event_type_code, description)
VALUES(48003, 'EAPTreatmentTemplate', 48003,'EAPTreatmentTemplate', 'TIBCO JMS Events');

INSERT INTO RTS3_EVENT_ACTION(id,app_event_id,action_type_code,exec_order)
VALUES(48005,48003,'PARSE_EVENT',1);

INSERT INTO RTS3_EVENT_ACTION(id,app_event_id,action_type_code,exec_order)
VALUES(48006,48003,'SAVE_MONGO',2);

INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name, param_value,value_encrypted)
VALUES(48009,48006,'mongodb.uri','mongodb://admin_mongodb:P5MwnVbm@maas-mw-d5-u0037.nam.nsroot.net:37017,maas-gt-d5-u0025.nam.nsroot.net:37017,maas-sw-d5-u0007.nam.nsroot.net:37017/GCG_ASIA_MY?ssl=true&authSource=admin','N');
INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name, param_value,value_encrypted)
VALUES(48010,48006,'mongodb.db.name','GCG_ASIA_MY','N');
INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name, param_value,value_encrypted)
VALUES(48011,48006,'mongodb.collection.name','EAP_EPP_COP_TRT_TEMPLATE','N');
INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name,param_value,value_encrypted)
VALUES(48012,48006,'mongodb.db.password','cZNjPmJtqQ0wDFs2DNZsZw==','Y');

INSERT INTO RTS3_APP_DS(id, name, app_id, ds_type_code, description,default_event)
VALUES(48004, 'EPP_UOF_MY', 48001,'TIBCO', 'EPP_UOF_MY DS' , 'UpdateOfferFullfillmentEapRequest');

INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(48061,48004,'INITIAL_CONTEXT_FACTORY','com.tibco.tibjms.naming.TibjmsInitialContextFactory','N');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(48062,48004,'PROVIDER_URL', 'ssl://gpd-ed9-5c7e.nam.nsroot.net:7243','N');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(48063,48004,'com.tibco.tibjms.naming.ssl_identity', 'hdfs://gftsdev/user/gcgdmasg/security/DIT_EAP_USR.ca1.p12','N');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(48064,48004,'com.tibco.tibjms.naming.ssl_password', '','N');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(48065,48004,'SECURITY_PRINCIPAL', 'SIT_EAP_USR','N');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(48066,48004,'SECURITY_CREDENTIALS', 'citi1234','N');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(48067,48004,'com.tibco.tibjms.naming.security_protocol', 'ssl','N');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(48068,48004,'com.tibco.tibjms.naming.ssl_enable_verify_host', 'false','N');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(48069,48004,'com.tibco.tibjms.naming.ssl_vendor', 'j2se-default','N');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(48070,48004,'com.sun.net.ssl.internal.ssl.Provider', 'j2se-default','N');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(48071,48004,'com.tibco.tibjms.naming.ssl_auth_only', 'true','N');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(48072,48004,'java.property.TIBCO_SECURITY_VENDOR','j2se-default','N');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(48073,48004,'java.property.TIBCO_SECURITY_TRACE', 'false','N');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(48074,48004,'com.tibco.tibjms.naming.ssl_debug_trace', 'true','N');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(48075,48004,'com.tibco.tibjms.naming.ssl_trace','true','N');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(48076,48004,'tibco.jms.queue.queueCF','G2C_EAPCOPTHMYBatchQueueConnectionFactory','N');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(48077,48004,'tibco.jms.inbound.queue.name','citi.gcg.gommy.cop_163124.my_card.offerfulfillment.modelrequest','N');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(48078,48004,'tibco.jms.queue.username','SIT_EAP_USR','N');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(48079,48004,'tibco.jms.queue.password','citi1234','N');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value,value_encrypted)
VALUES(48080,48004,'tibco.p12.enable','true','N');

INSERT INTO RTS3_APP_DS_EVENT(id, name, app_ds_id, event_type_code, description)
VALUES(48004, 'UpdateOfferFullfillmentEapRequest', 48004,'UpdateOfferFullfillmentEapRequest', 'TIBCO JMS Events');

INSERT INTO RTS3_EVENT_ACTION(id,app_event_id,action_type_code,exec_order)
VALUES(48007,48004,'PARSE_EVENT',1);

INSERT INTO RTS3_EVENT_ACTION(id,app_event_id,action_type_code,exec_order)
VALUES(48008,48004,'SAVE_MONGO',2);

INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name, param_value,value_encrypted)
VALUES(48013,48008,'mongodb.uri','mongodb://admin_mongodb:P5MwnVbm@maas-mw-d5-u0037.nam.nsroot.net:37017,maas-gt-d5-u0025.nam.nsroot.net:37017,maas-sw-d5-u0007.nam.nsroot.net:37017/GCG_ASIA_MY?ssl=true&authSource=admin','N');
INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name, param_value,value_encrypted)
VALUES(48014,48008,'mongodb.db.name','GCG_ASIA_MY','N');
INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name, param_value,value_encrypted)
VALUES(48015,48008,'mongodb.collection.name','EAP_EPP_COP_OFR_FULFILLMENT','N');
INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name,param_value,value_encrypted)
VALUES(48016,48008,'mongodb.db.password','cZNjPmJtqQ0wDFs2DNZsZw==','Y');

