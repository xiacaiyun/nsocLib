INSERT INTO RTS3_APPLICATION (id, name, tenant_id, description, void_ind)
VALUES(30001, 'CJEH', 10001, 'Customer Journey Event Hub', 'N');

INSERT INTO RTS3_APP_PARAM (id, param_type_code, app_id, param_name, param_value, description)
VALUES(30001, 'SPARK_CONF', 30001, 'spark.app.name', 'CJEH Spark', null);
INSERT INTO RTS3_APP_PARAM (id, param_type_code, app_id, param_name, param_value, description)
VALUES(30003, 'APP_CONF', 30001, 'app.spark.duration', '3000', 'milli-seconds');
INSERT INTO RTS3_APP_PARAM (id, param_type_code, app_id, param_name, param_value, description)
VALUES(30004, 'APP_CONF', 30001, 'app.spark.msg.broker.type', 'TIBCO', null);

INSERT INTO RTS3_APP_DS(id, name, app_id, ds_type_code, description,default_event)
VALUES(30001, 'EVENT_HUB_DS1', 30001,'TIBCO', 'EVENT HUB DS2',null);

INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value)
VALUES(30001,30001,'INITIAL_CONTEXT_FACTORY','com.tibco.tibjms.naming.TibjmsInitialContextFactory');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value)
VALUES(30002,30001,'PROVIDER_URL', 'ssl://mwgtc-tibla16s.nam.nsroot.net:7243');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value)
VALUES(30003,30001,'com.tibco.tibjms.naming.ssl_identity', '/user/gcgauasg/security/UAT_EAP_USR.ca1.p12');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value)
VALUES(30004,30001,'com.tibco.tibjms.naming.ssl_password', '');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value)
VALUES(30005,30001,'SECURITY_PRINCIPAL', 'UAT_EAP_USR');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value)
VALUES(30006,30001,'SECURITY_CREDENTIALS', '');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value)
VALUES(30007,30001,'com.tibco.tibjms.naming.security_protocol', 'ssl');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value)
VALUES(30008,30001,'com.tibco.tibjms.naming.ssl_enable_verify_host', 'false');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value)
VALUES(30009,30001,'com.tibco.tibjms.naming.ssl_vendor', 'j2se-default');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value)
VALUES(30010,30001,'com.sun.net.ssl.internal.ssl.Provider', 'j2se-default');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value)
VALUES(30011,30001,'com.tibco.tibjms.naming.ssl_auth_only', 'true');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value)
VALUES(30012,30001,'java.property.TIBCO_SECURITY_VENDOR','j2se-default');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value)
VALUES(30013,30001,'java.property.TIBCO_SECURITY_TRACE', 'false');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value)
VALUES(30014,30001,'com.tibco.tibjms.naming.ssl_debug_trace', 'true');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value)
VALUES(30015,30001,'com.tibco.tibjms.naming.ssl_trace','true');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value)
VALUES(30016,30001,'tibco.jms.queue.queueCF','G2C_EC_EAP1QueueConnectionFactory');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value)
VALUES(30017,30001,'tibco.jms.inbound.queue.name','citi.gcg.apac.eventcloud.consumer.eap');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value)
VALUES(30018,30001,'tibco.jms.queue.username','UAT_EAP_USR');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value)
VALUES(30019,30001,'tibco.jms.queue.password','');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value)
VALUES(30020,30001,'tibco.p12.enable','true');

INSERT INTO RTS3_APP_DS_EVENT(id, name, app_ds_id, event_type_code, description)
VALUES(30001, 'CardActivation', 30001,'CardActivation', 'TIBCO JMS Events');

INSERT INTO RTS3_EVENT_ACTION(id,app_event_id,action_type_code,exec_order)
VALUES(30001,30001,'SAVE_MONGO',1);

INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name,param_value)
VALUES(30001,30001,'mongodb.uri','mongodb://eap_mongodb_uat:$PASSWORD@maas-gt-p72-m0002.nam.nsroot.net:37017,maas-sw-p72-m0001.nam.nsroot.net:37017,maas-mw-p72-m0001.nam.nsroot.net:37017/GCG_ASIA_MY?ssl=true&authSource=admin');
INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name,param_value)
VALUES(30002,30001,'mongodb.db.name','GCG_ASIA_MY');
INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name,param_value)
VALUES(30003,30001,'mongodb.collection.name','EAP_IVR_CARD_ACTIVATION');

INSERT INTO RTS3_APP_DS_EVENT(id, name, app_ds_id, event_type_code, description)
VALUES(30002, 'AccountLinkage', 30001,'AccountLinkage', 'TIBCO JMS Events');

INSERT INTO RTS3_EVENT_ACTION(id,app_event_id,action_type_code,exec_order)
VALUES(30002,30002,'SAVE_MONGO',1);

INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name,param_value)
VALUES(30004,30002,'mongodb.uri','mongodb://eap_mongodb_uat:$PASSWORD@maas-gt-p72-m0002.nam.nsroot.net:37017,maas-sw-p72-m0001.nam.nsroot.net:37017,maas-mw-p72-m0001.nam.nsroot.net:37017/GCG_ASIA_MY?ssl=true&authSource=admin');
INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name,param_value)
VALUES(30005,30002,'mongodb.db.name','GCG_ASIA_MY');
INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name,param_value)
VALUES(30006,30002,'mongodb.collection.name','EAP_IVR_ACCOUNT_LINKAGE');

INSERT INTO RTS3_APP_DS_EVENT(id, name, app_ds_id, event_type_code, description)
VALUES(30003, 'AccountSummary', 30001,'AccountSummary', 'TIBCO JMS Events');

INSERT INTO RTS3_EVENT_ACTION(id,app_event_id,action_type_code,exec_order)
VALUES(30003,30003,'SAVE_MONGO',1);

INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name,param_value)
VALUES(30007,30003,'mongodb.uri','mongodb://eap_mongodb_uat:$PASSWORD@maas-gt-p72-m0002.nam.nsroot.net:37017,maas-sw-p72-m0001.nam.nsroot.net:37017,maas-mw-p72-m0001.nam.nsroot.net:37017/GCG_ASIA_MY?ssl=true&authSource=admin');
INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name,param_value)
VALUES(30008,30003,'mongodb.db.name','GCG_ASIA_MY');
INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name,param_value)
VALUES(30009,30003,'mongodb.collection.name','EAP_IVR_ACCOUNT_SUMMARY');

INSERT INTO RTS3_APP_DS_EVENT(id, name, app_ds_id, event_type_code, description)
VALUES(30004, 'APINChange', 30001,'APINChange', 'TIBCO JMS Events');

INSERT INTO RTS3_EVENT_ACTION(id,app_event_id,action_type_code,exec_order)
VALUES(30004,30004,'SAVE_MONGO',1);

INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name,param_value)
VALUES(30010,30004,'mongodb.uri','mongodb://eap_mongodb_uat:$PASSWORD@maas-gt-p72-m0002.nam.nsroot.net:37017,maas-sw-p72-m0001.nam.nsroot.net:37017,maas-mw-p72-m0001.nam.nsroot.net:37017/GCG_ASIA_MY?ssl=true&authSource=admin');
INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name,param_value)
VALUES(30011,30004,'mongodb.db.name','GCG_ASIA_MY');
INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name,param_value)
VALUES(30012,30004,'mongodb.collection.name','EAP_IVR_APIN_CHANGE');

INSERT INTO RTS3_APP_DS_EVENT(id, name, app_ds_id, event_type_code, description)
VALUES(30005, 'BillPayment', 30001,'BillPayment', 'TIBCO JMS Events');

INSERT INTO RTS3_EVENT_ACTION(id,app_event_id,action_type_code,exec_order)
VALUES(30005,30005,'SAVE_MONGO',1);

INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name,param_value)
VALUES(30013,30005,'mongodb.uri','mongodb://eap_mongodb_uat:$PASSWORD@maas-gt-p72-m0002.nam.nsroot.net:37017,maas-sw-p72-m0001.nam.nsroot.net:37017,maas-mw-p72-m0001.nam.nsroot.net:37017/GCG_ASIA_MY?ssl=true&authSource=admin');
INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name,param_value)
VALUES(30014,30005,'mongodb.db.name','GCG_ASIA_MY');
INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name,param_value)
VALUES(30015,30005,'mongodb.collection.name','EAP_IVR_BILL_PAYMENT');

INSERT INTO RTS3_APP_DS_EVENT(id, name, app_ds_id, event_type_code, description)
VALUES(30006, 'CardBlockCodeUpdate', 30001,'CardBlockCodeUpdate', 'TIBCO JMS Events');

INSERT INTO RTS3_EVENT_ACTION(id,app_event_id,action_type_code,exec_order)
VALUES(30006,30006,'SAVE_MONGO',1);

INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name,param_value)
VALUES(30016,30006,'mongodb.uri','mongodb://eap_mongodb_uat:$PASSWORD@maas-gt-p72-m0002.nam.nsroot.net:37017,maas-sw-p72-m0001.nam.nsroot.net:37017,maas-mw-p72-m0001.nam.nsroot.net:37017/GCG_ASIA_MY?ssl=true&authSource=admin');
INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name,param_value)
VALUES(30017,30006,'mongodb.db.name','GCG_ASIA_MY');
INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name,param_value)
VALUES(30018,30006,'mongodb.collection.name','EAP_IVR_CARD_BLOCK_CODE_UPDATE');

INSERT INTO RTS3_APP_DS_EVENT(id, name, app_ds_id, event_type_code, description)
VALUES(30007, 'CardDecline', 30001,'CardDecline', 'TIBCO JMS Events');

INSERT INTO RTS3_EVENT_ACTION(id,app_event_id,action_type_code,exec_order)
VALUES(30007,30007,'SAVE_MONGO',1);

INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name,param_value)
VALUES(30019,30007,'mongodb.uri','mongodb://eap_mongodb_uat:$PASSWORD@maas-gt-p72-m0002.nam.nsroot.net:37017,maas-sw-p72-m0001.nam.nsroot.net:37017,maas-mw-p72-m0001.nam.nsroot.net:37017/GCG_ASIA_MY?ssl=true&authSource=admin');
INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name,param_value)
VALUES(30020,30007,'mongodb.db.name','GCG_ASIA_MY');
INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name,param_value)
VALUES(30021,30007,'mongodb.collection.name','EAP_IVR_CARD_DECLINE');

INSERT INTO RTS3_APP_DS_EVENT(id, name, app_ds_id, event_type_code, description)
VALUES(30008, 'CBOLMBOLRegistration', 30001,'CBOLMBOLRegistration', 'TIBCO JMS Events');

INSERT INTO RTS3_EVENT_ACTION(id,app_event_id,action_type_code,exec_order)
VALUES(30008,30008,'SAVE_MONGO',1);

INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name,param_value)
VALUES(30022,30008,'mongodb.uri','mongodb://eap_mongodb_uat:$PASSWORD@maas-gt-p72-m0002.nam.nsroot.net:37017,maas-sw-p72-m0001.nam.nsroot.net:37017,maas-mw-p72-m0001.nam.nsroot.net:37017/GCG_ASIA_MY?ssl=true&authSource=admin');
INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name,param_value)
VALUES(30023,30008,'mongodb.db.name','GCG_ASIA_MY');
INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name,param_value)
VALUES(30024,30008,'mongodb.collection.name','EAP_IVR_CBOL_MBOL_REGISTRATION');

INSERT INTO RTS3_APP_DS_EVENT(id, name, app_ds_id, event_type_code, description)
VALUES(30009, 'ChargeDispute', 30001,'ChargeDispute', 'TIBCO JMS Events');

INSERT INTO RTS3_EVENT_ACTION(id,app_event_id,action_type_code,exec_order)
VALUES(30009,30009,'SAVE_MONGO',1);

INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name,param_value)
VALUES(30025,30009,'mongodb.uri','mongodb://eap_mongodb_uat:$PASSWORD@maas-gt-p72-m0002.nam.nsroot.net:37017,maas-sw-p72-m0001.nam.nsroot.net:37017,maas-mw-p72-m0001.nam.nsroot.net:37017/GCG_ASIA_MY?ssl=true&authSource=admin');
INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name,param_value)
VALUES(30026,30009,'mongodb.db.name','GCG_ASIA_MY');
INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name,param_value)
VALUES(30027,30009,'mongodb.collection.name','EAP_IVR_CHARGE_DISPUTE');

INSERT INTO RTS3_APP_DS_EVENT(id, name, app_ds_id, event_type_code, description)
VALUES(30010, 'ChequeBounce', 30001,'ChequeBounce', 'TIBCO JMS Events');

INSERT INTO RTS3_EVENT_ACTION(id,app_event_id,action_type_code,exec_order)
VALUES(30010,30010,'SAVE_MONGO',1);

INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name,param_value)
VALUES(30028,30010,'mongodb.uri','mongodb://eap_mongodb_uat:$PASSWORD@maas-gt-p72-m0002.nam.nsroot.net:37017,maas-sw-p72-m0001.nam.nsroot.net:37017,maas-mw-p72-m0001.nam.nsroot.net:37017/GCG_ASIA_MY?ssl=true&authSource=admin');
INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name,param_value)
VALUES(30029,30010,'mongodb.db.name','GCG_ASIA_MY');
INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name,param_value)
VALUES(30030,30010,'mongodb.collection.name','EAP_IVR_CHEQUE_BOUNCE');

INSERT INTO RTS3_APP_DS_EVENT(id, name, app_ds_id, event_type_code, description)
VALUES(30011, 'ChequeStopPayment', 30001,'ChequeStopPayment', 'TIBCO JMS Events');

INSERT INTO RTS3_EVENT_ACTION(id,app_event_id,action_type_code,exec_order)
VALUES(30011,30011,'SAVE_MONGO',1);

INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name,param_value)
VALUES(30031,30011,'mongodb.uri','mongodb://eap_mongodb_uat:$PASSWORD@maas-gt-p72-m0002.nam.nsroot.net:37017,maas-sw-p72-m0001.nam.nsroot.net:37017,maas-mw-p72-m0001.nam.nsroot.net:37017/GCG_ASIA_MY?ssl=true&authSource=admin');
INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name,param_value)
VALUES(30032,30011,'mongodb.db.name','GCG_ASIA_MY');
INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name,param_value)
VALUES(30033,30011,'mongodb.collection.name','EAP_IVR_CHEQUE_STOPPAYMENT');

INSERT INTO RTS3_APP_DS_EVENT(id, name, app_ds_id, event_type_code, description)
VALUES(30012, 'CpoCallEnd', 30001,'CpoCallEnd', 'TIBCO JMS Events');

INSERT INTO RTS3_EVENT_ACTION(id,app_event_id,action_type_code,exec_order)
VALUES(30012,30012,'SAVE_MONGO',1);

INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name,param_value)
VALUES(30034,30012,'mongodb.uri','mongodb://eap_mongodb_uat:$PASSWORD@maas-gt-p72-m0002.nam.nsroot.net:37017,maas-sw-p72-m0001.nam.nsroot.net:37017,maas-mw-p72-m0001.nam.nsroot.net:37017/GCG_ASIA_MY?ssl=true&authSource=admin');
INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name,param_value)
VALUES(30035,30012,'mongodb.db.name','GCG_ASIA_MY');
INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name,param_value)
VALUES(30036,30012,'mongodb.collection.name','EAP_IVR_CPO_CALL_END');

INSERT INTO RTS3_APP_DS_EVENT(id, name, app_ds_id, event_type_code, description)
VALUES(30013, 'CpoCallStart', 30001,'CpoCallStart', 'TIBCO JMS Events');

INSERT INTO RTS3_EVENT_ACTION(id,app_event_id,action_type_code,exec_order)
VALUES(30013,30013,'SAVE_MONGO',1);

INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name,param_value)
VALUES(30037,30013,'mongodb.uri','mongodb://eap_mongodb_uat:$PASSWORD@maas-gt-p72-m0002.nam.nsroot.net:37017,maas-sw-p72-m0001.nam.nsroot.net:37017,maas-mw-p72-m0001.nam.nsroot.net:37017/GCG_ASIA_MY?ssl=true&authSource=admin');
INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name,param_value)
VALUES(30038,30013,'mongodb.db.name','GCG_ASIA_MY');
INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name,param_value)
VALUES(30039,30013,'mongodb.collection.name','EAP_IVR_CPO_CALL_START');

INSERT INTO RTS3_APP_DS_EVENT(id, name, app_ds_id, event_type_code, description)
VALUES(30014, 'CreditCardClosure', 30001,'CreditCardClosure', 'TIBCO JMS Events');

INSERT INTO RTS3_EVENT_ACTION(id,app_event_id,action_type_code,exec_order)
VALUES(30014,30014,'SAVE_MONGO',1);

INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name,param_value)
VALUES(30040,30014,'mongodb.uri','mongodb://eap_mongodb_uat:$PASSWORD@maas-gt-p72-m0002.nam.nsroot.net:37017,maas-sw-p72-m0001.nam.nsroot.net:37017,maas-mw-p72-m0001.nam.nsroot.net:37017/GCG_ASIA_MY?ssl=true&authSource=admin');
INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name,param_value)
VALUES(30041,30014,'mongodb.db.name','GCG_ASIA_MY');
INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name,param_value)
VALUES(30042,30014,'mongodb.collection.name','EAP_IVR_CREDIT_CARD_CLOSURE');

INSERT INTO RTS3_APP_DS_EVENT(id, name, app_ds_id, event_type_code, description)
VALUES(30015, 'CreditCardReversal', 30001,'CreditCardReversal', 'TIBCO JMS Events');

INSERT INTO RTS3_EVENT_ACTION(id,app_event_id,action_type_code,exec_order)
VALUES(30015,30015,'SAVE_MONGO',1);

INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name,param_value)
VALUES(30043,30015,'mongodb.uri','mongodb://eap_mongodb_uat:$PASSWORD@maas-gt-p72-m0002.nam.nsroot.net:37017,maas-sw-p72-m0001.nam.nsroot.net:37017,maas-mw-p72-m0001.nam.nsroot.net:37017/GCG_ASIA_MY?ssl=true&authSource=admin');
INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name,param_value)
VALUES(30044,30015,'mongodb.db.name','GCG_ASIA_MY');
INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name,param_value)
VALUES(30045,30015,'mongodb.collection.name','EAP_IVR_CREDIT_CARD_REVERSAL');

INSERT INTO RTS3_APP_DS_EVENT(id, name, app_ds_id, event_type_code, description)
VALUES(30016, 'CreditLimitIncrease', 30001,'CreditLimitIncrease', 'TIBCO JMS Events');

INSERT INTO RTS3_EVENT_ACTION(id,app_event_id,action_type_code,exec_order)
VALUES(30016,30016,'SAVE_MONGO',1);

INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name,param_value)
VALUES(30046,30016,'mongodb.uri','mongodb://eap_mongodb_uat:$PASSWORD@maas-gt-p72-m0002.nam.nsroot.net:37017,maas-sw-p72-m0001.nam.nsroot.net:37017,maas-mw-p72-m0001.nam.nsroot.net:37017/GCG_ASIA_MY?ssl=true&authSource=admin');
INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name,param_value)
VALUES(30047,30016,'mongodb.db.name','GCG_ASIA_MY');
INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name,param_value)
VALUES(30048,30016,'mongodb.collection.name','EAP_IVR_CREDIT_LIMIT_INCREASE');

INSERT INTO RTS3_APP_DS_EVENT(id, name, app_ds_id, event_type_code, description)
VALUES(30017, 'CustHWTokenRequest', 30001,'CustHWTokenRequest', 'TIBCO JMS Events');

INSERT INTO RTS3_EVENT_ACTION(id,app_event_id,action_type_code,exec_order)
VALUES(30017,30017,'SAVE_MONGO',1);

INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name,param_value)
VALUES(30049,30017,'mongodb.uri','mongodb://eap_mongodb_uat:$PASSWORD@maas-gt-p72-m0002.nam.nsroot.net:37017,maas-sw-p72-m0001.nam.nsroot.net:37017,maas-mw-p72-m0001.nam.nsroot.net:37017/GCG_ASIA_MY?ssl=true&authSource=admin');
INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name,param_value)
VALUES(30050,30017,'mongodb.db.name','GCG_ASIA_MY');
INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name,param_value)
VALUES(30051,30017,'mongodb.collection.name','EAP_IVR_CUST_HWTOKEN_REQUEST');

INSERT INTO RTS3_APP_DS_EVENT(id, name, app_ds_id, event_type_code, description)
VALUES(30018, 'CustLoginIDStatusChange', 30001,'CustLoginIDStatusChange', 'TIBCO JMS Events');

INSERT INTO RTS3_EVENT_ACTION(id,app_event_id,action_type_code,exec_order)
VALUES(30018,30018,'SAVE_MONGO',1);

INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name,param_value)
VALUES(30052,30018,'mongodb.uri','mongodb://eap_mongodb_uat:$PASSWORD@maas-gt-p72-m0002.nam.nsroot.net:37017,maas-sw-p72-m0001.nam.nsroot.net:37017,maas-mw-p72-m0001.nam.nsroot.net:37017/GCG_ASIA_MY?ssl=true&authSource=admin');
INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name,param_value)
VALUES(30053,30018,'mongodb.db.name','GCG_ASIA_MY');
INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name,param_value)
VALUES(30054,30018,'mongodb.collection.name','EAP_IVR_CUST_LOGINID_STATUS_CHANGE');

INSERT INTO RTS3_APP_DS_EVENT(id, name, app_ds_id, event_type_code, description)
VALUES(30019, 'CustomerLogin', 30001,'CustomerLogin', 'TIBCO JMS Events');

INSERT INTO RTS3_EVENT_ACTION(id,app_event_id,action_type_code,exec_order)
VALUES(30019,30019,'SAVE_MONGO',1);

INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name,param_value)
VALUES(30055,30019,'mongodb.uri','mongodb://eap_mongodb_uat:$PASSWORD@maas-gt-p72-m0002.nam.nsroot.net:37017,maas-sw-p72-m0001.nam.nsroot.net:37017,maas-mw-p72-m0001.nam.nsroot.net:37017/GCG_ASIA_MY?ssl=true&authSource=admin');
INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name,param_value)
VALUES(30056,30019,'mongodb.db.name','GCG_ASIA_MY');
INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name,param_value)
VALUES(30057,30019,'mongodb.collection.name','EAP_IVR_CUSTOMER_LOGIN');

INSERT INTO RTS3_APP_DS_EVENT(id, name, app_ds_id, event_type_code, description)
VALUES(30020, 'DemographicChange', 30001,'DemographicChange', 'TIBCO JMS Events');

INSERT INTO RTS3_EVENT_ACTION(id,app_event_id,action_type_code,exec_order)
VALUES(30020,30020,'SAVE_MONGO',1);

INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name,param_value)
VALUES(30058,30020,'mongodb.uri','mongodb://eap_mongodb_uat:$PASSWORD@maas-gt-p72-m0002.nam.nsroot.net:37017,maas-sw-p72-m0001.nam.nsroot.net:37017,maas-mw-p72-m0001.nam.nsroot.net:37017/GCG_ASIA_MY?ssl=true&authSource=admin');
INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name,param_value)
VALUES(30059,30020,'mongodb.db.name','GCG_ASIA_MY');
INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name,param_value)
VALUES(30060,30020,'mongodb.collection.name','EAP_IVR_DEMOGRAPHIC_CHANGE');

INSERT INTO RTS3_APP_DS_EVENT(id, name, app_ds_id, event_type_code, description)
VALUES(30021, 'DigiPassInitiation', 30001,'DigiPassInitiation', 'TIBCO JMS Events');

INSERT INTO RTS3_EVENT_ACTION(id,app_event_id,action_type_code,exec_order)
VALUES(30021,30021,'SAVE_MONGO',1);

INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name,param_value)
VALUES(30061,30021,'mongodb.uri','mongodb://eap_mongodb_uat:$PASSWORD@maas-gt-p72-m0002.nam.nsroot.net:37017,maas-sw-p72-m0001.nam.nsroot.net:37017,maas-mw-p72-m0001.nam.nsroot.net:37017/GCG_ASIA_MY?ssl=true&authSource=admin');
INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name,param_value)
VALUES(30062,30021,'mongodb.db.name','GCG_ASIA_MY');
INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name,param_value)
VALUES(30063,30021,'mongodb.collection.name','EAP_IVR_DIGI_PASS_INITIATION');

INSERT INTO RTS3_APP_DS_EVENT(id, name, app_ds_id, event_type_code, description)
VALUES(30022, 'EPPLOPOfferView', 30001,'EPPLOPOfferView', 'TIBCO JMS Events');

INSERT INTO RTS3_EVENT_ACTION(id,app_event_id,action_type_code,exec_order)
VALUES(30022,30022,'SAVE_MONGO',1);

INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name,param_value)
VALUES(30064,30022,'mongodb.uri','mongodb://eap_mongodb_uat:$PASSWORD@maas-gt-p72-m0002.nam.nsroot.net:37017,maas-sw-p72-m0001.nam.nsroot.net:37017,maas-mw-p72-m0001.nam.nsroot.net:37017/GCG_ASIA_MY?ssl=true&authSource=admin');
INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name,param_value)
VALUES(30065,30022,'mongodb.db.name','GCG_ASIA_MY');
INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name,param_value)
VALUES(30066,30022,'mongodb.collection.name','EAP_IVR_EPP_LOP_OFFER_VIEW');

INSERT INTO RTS3_APP_DS_EVENT(id, name, app_ds_id, event_type_code, description)
VALUES(30023, 'EstatementDispatch', 30001,'EstatementDispatch', 'TIBCO JMS Events');

INSERT INTO RTS3_EVENT_ACTION(id,app_event_id,action_type_code,exec_order)
VALUES(30023,30023,'SAVE_MONGO',1);

INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name,param_value)
VALUES(30067,30023,'mongodb.uri','mongodb://eap_mongodb_uat:$PASSWORD@maas-gt-p72-m0002.nam.nsroot.net:37017,maas-sw-p72-m0001.nam.nsroot.net:37017,maas-mw-p72-m0001.nam.nsroot.net:37017/GCG_ASIA_MY?ssl=true&authSource=admin');
INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name,param_value)
VALUES(30068,30023,'mongodb.db.name','GCG_ASIA_MY');
INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name,param_value)
VALUES(30069,30023,'mongodb.collection.name','EAP_IVR_ESTATEMENT_DISPATCH');

INSERT INTO RTS3_APP_DS_EVENT(id, name, app_ds_id, event_type_code, description)
VALUES(30024, 'eStatementView', 30001,'eStatementView', 'TIBCO JMS Events');

INSERT INTO RTS3_EVENT_ACTION(id,app_event_id,action_type_code,exec_order)
VALUES(30024,30024,'SAVE_MONGO',1);

INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name,param_value)
VALUES(30070,30024,'mongodb.uri','mongodb://eap_mongodb_uat:$PASSWORD@maas-gt-p72-m0002.nam.nsroot.net:37017,maas-sw-p72-m0001.nam.nsroot.net:37017,maas-mw-p72-m0001.nam.nsroot.net:37017/GCG_ASIA_MY?ssl=true&authSource=admin');
INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name,param_value)
VALUES(30071,30024,'mongodb.db.name','GCG_ASIA_MY');
INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name,param_value)
VALUES(30072,30024,'mongodb.collection.name','EAP_IVR_ESTATEMENT_VIEW');

INSERT INTO RTS3_APP_DS_EVENT(id, name, app_ds_id, event_type_code, description)
VALUES(30025, 'ForgotUserIdAndPassword', 30001,'ForgotUserIdAndPassword', 'TIBCO JMS Events');

INSERT INTO RTS3_EVENT_ACTION(id,app_event_id,action_type_code,exec_order)
VALUES(30025,30025,'SAVE_MONGO',1);

INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name,param_value)
VALUES(30073,30025,'mongodb.uri','mongodb://eap_mongodb_uat:$PASSWORD@maas-gt-p72-m0002.nam.nsroot.net:37017,maas-sw-p72-m0001.nam.nsroot.net:37017,maas-mw-p72-m0001.nam.nsroot.net:37017/GCG_ASIA_MY?ssl=true&authSource=admin');
INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name,param_value)
VALUES(30074,30025,'mongodb.db.name','GCG_ASIA_MY');
INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name,param_value)
VALUES(30075,30025,'mongodb.collection.name','EAP_IVR_FORGOT_USERID_AND_PASSWORD');

INSERT INTO RTS3_APP_DS_EVENT(id, name, app_ds_id, event_type_code, description)
VALUES(30026, 'IVRCallEnd', 30001,'IVRCallEnd', 'TIBCO JMS Events');

INSERT INTO RTS3_EVENT_ACTION(id,app_event_id,action_type_code,exec_order)
VALUES(30026,30026,'SAVE_MONGO',1);

INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name,param_value)
VALUES(30076,30026,'mongodb.uri','mongodb://eap_mongodb_uat:$PASSWORD@maas-gt-p72-m0002.nam.nsroot.net:37017,maas-sw-p72-m0001.nam.nsroot.net:37017,maas-mw-p72-m0001.nam.nsroot.net:37017/GCG_ASIA_MY?ssl=true&authSource=admin');
INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name,param_value)
VALUES(30077,30026,'mongodb.db.name','GCG_ASIA_MY');
INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name,param_value)
VALUES(30078,30026,'mongodb.collection.name','EAP_IVR_IVR_CALL_END');

INSERT INTO RTS3_APP_DS_EVENT(id, name, app_ds_id, event_type_code, description)
VALUES(30027, 'IVRCallStart', 30001,'IVRCallStart', 'TIBCO JMS Events');

INSERT INTO RTS3_EVENT_ACTION(id,app_event_id,action_type_code,exec_order)
VALUES(30027,30027,'SAVE_MONGO',1);

INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name,param_value)
VALUES(30079,30027,'mongodb.uri','mongodb://eap_mongodb_uat:$PASSWORD@maas-gt-p72-m0002.nam.nsroot.net:37017,maas-sw-p72-m0001.nam.nsroot.net:37017,maas-mw-p72-m0001.nam.nsroot.net:37017/GCG_ASIA_MY?ssl=true&authSource=admin');
INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name,param_value)
VALUES(30080,30027,'mongodb.db.name','GCG_ASIA_MY');
INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name,param_value)
VALUES(30081,30027,'mongodb.collection.name','EAP_IVR_IVR_CALL_START');

INSERT INTO RTS3_APP_DS_EVENT(id, name, app_ds_id, event_type_code, description)
VALUES(30028, 'OnlineDirectDebitExecution', 30001,'OnlineDirectDebitExecution', 'TIBCO JMS Events');

INSERT INTO RTS3_EVENT_ACTION(id,app_event_id,action_type_code,exec_order)
VALUES(30028,30028,'SAVE_MONGO',1);

INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name,param_value)
VALUES(30082,30028,'mongodb.uri','mongodb://eap_mongodb_uat:$PASSWORD@maas-gt-p72-m0002.nam.nsroot.net:37017,maas-sw-p72-m0001.nam.nsroot.net:37017,maas-mw-p72-m0001.nam.nsroot.net:37017/GCG_ASIA_MY?ssl=true&authSource=admin');
INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name,param_value)
VALUES(30083,30028,'mongodb.db.name','GCG_ASIA_MY');
INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name,param_value)
VALUES(30084,30028,'mongodb.collection.name','EAP_IVR_ONLINE_DIRECT_DEBIT_EXECUTION');

INSERT INTO RTS3_APP_DS_EVENT(id, name, app_ds_id, event_type_code, description)
VALUES(30029, 'OverseasCardActivation', 30001,'OverseasCardActivation', 'TIBCO JMS Events');

INSERT INTO RTS3_EVENT_ACTION(id,app_event_id,action_type_code,exec_order)
VALUES(30029,30029,'SAVE_MONGO',1);

INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name,param_value)
VALUES(30085,30029,'mongodb.uri','mongodb://eap_mongodb_uat:$PASSWORD@maas-gt-p72-m0002.nam.nsroot.net:37017,maas-sw-p72-m0001.nam.nsroot.net:37017,maas-mw-p72-m0001.nam.nsroot.net:37017/GCG_ASIA_MY?ssl=true&authSource=admin');
INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name,param_value)
VALUES(30086,30029,'mongodb.db.name','GCG_ASIA_MY');
INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name,param_value)
VALUES(30087,30029,'mongodb.collection.name','EAP_IVR_OVERSEAS_CARD_ACTIVATION');

INSERT INTO RTS3_APP_DS_EVENT(id, name, app_ds_id, event_type_code, description)
VALUES(30030, 'PaymentAndTransfer', 30001,'PaymentAndTransfer', 'TIBCO JMS Events');

INSERT INTO RTS3_EVENT_ACTION(id,app_event_id,action_type_code,exec_order)
VALUES(30030,30030,'SAVE_MONGO',1);

INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name,param_value)
VALUES(30088,30030,'mongodb.uri','mongodb://eap_mongodb_uat:$PASSWORD@maas-gt-p72-m0002.nam.nsroot.net:37017,maas-sw-p72-m0001.nam.nsroot.net:37017,maas-mw-p72-m0001.nam.nsroot.net:37017/GCG_ASIA_MY?ssl=true&authSource=admin');
INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name,param_value)
VALUES(30089,30030,'mongodb.db.name','GCG_ASIA_MY');
INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name,param_value)
VALUES(30090,30030,'mongodb.collection.name','EAP_IVR_PAYMENT_AND_TRANSFER');

INSERT INTO RTS3_APP_DS_EVENT(id, name, app_ds_id, event_type_code, description)
VALUES(30031, 'PINValidation', 30001,'PINValidation', 'TIBCO JMS Events');

INSERT INTO RTS3_EVENT_ACTION(id,app_event_id,action_type_code,exec_order)
VALUES(30031,30031,'SAVE_MONGO',1);

INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name,param_value)
VALUES(30091,30031,'mongodb.uri','mongodb://eap_mongodb_uat:$PASSWORD@maas-gt-p72-m0002.nam.nsroot.net:37017,maas-sw-p72-m0001.nam.nsroot.net:37017,maas-mw-p72-m0001.nam.nsroot.net:37017/GCG_ASIA_MY?ssl=true&authSource=admin');
INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name,param_value)
VALUES(30092,30031,'mongodb.db.name','GCG_ASIA_MY');
INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name,param_value)
VALUES(30093,30031,'mongodb.collection.name','EAP_IVR_PIN_VALIDATION');

INSERT INTO RTS3_APP_DS_EVENT(id, name, app_ds_id, event_type_code, description)
VALUES(30032, 'PreAuth', 30001,'PreAuth', 'TIBCO JMS Events');

INSERT INTO RTS3_EVENT_ACTION(id,app_event_id,action_type_code,exec_order)
VALUES(30032,30032,'SAVE_MONGO',1);

INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name,param_value)
VALUES(30094,30032,'mongodb.uri','mongodb://eap_mongodb_uat:$PASSWORD@maas-gt-p72-m0002.nam.nsroot.net:37017,maas-sw-p72-m0001.nam.nsroot.net:37017,maas-mw-p72-m0001.nam.nsroot.net:37017/GCG_ASIA_MY?ssl=true&authSource=admin');
INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name,param_value)
VALUES(30095,30032,'mongodb.db.name','GCG_ASIA_MY');
INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name,param_value)
VALUES(30096,30032,'mongodb.collection.name','EAP_IVR_PRE_AUTH');

INSERT INTO RTS3_APP_DS_EVENT(id, name, app_ds_id, event_type_code, description)
VALUES(30033, 'ReportLostStolen', 30001,'ReportLostStolen', 'TIBCO JMS Events');

INSERT INTO RTS3_EVENT_ACTION(id,app_event_id,action_type_code,exec_order)
VALUES(30033,30033,'SAVE_MONGO',1);

INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name,param_value)
VALUES(30097,30033,'mongodb.uri','mongodb://eap_mongodb_uat:$PASSWORD@maas-gt-p72-m0002.nam.nsroot.net:37017,maas-sw-p72-m0001.nam.nsroot.net:37017,maas-mw-p72-m0001.nam.nsroot.net:37017/GCG_ASIA_MY?ssl=true&authSource=admin');
INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name,param_value)
VALUES(30098,30033,'mongodb.db.name','GCG_ASIA_MY');
INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name,param_value)
VALUES(30099,30033,'mongodb.collection.name','EAP_IVR_REPORT_LOST_STOLEN');

INSERT INTO RTS3_APP_DS_EVENT(id, name, app_ds_id, event_type_code, description)
VALUES(30034, 'RewardRedemptionAccess', 30001,'RewardRedemptionAccess', 'TIBCO JMS Events');

INSERT INTO RTS3_EVENT_ACTION(id,app_event_id,action_type_code,exec_order)
VALUES(30034,30034,'SAVE_MONGO',1);

INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name,param_value)
VALUES(30100,30034,'mongodb.uri','mongodb://eap_mongodb_uat:$PASSWORD@maas-gt-p72-m0002.nam.nsroot.net:37017,maas-sw-p72-m0001.nam.nsroot.net:37017,maas-mw-p72-m0001.nam.nsroot.net:37017/GCG_ASIA_MY?ssl=true&authSource=admin');
INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name,param_value)
VALUES(30101,30034,'mongodb.db.name','GCG_ASIA_MY');
INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name,param_value)
VALUES(30102,30034,'mongodb.collection.name','EAP_IVR_REWARD_REDEMPTION_ACCESS');

INSERT INTO RTS3_APP_DS_EVENT(id, name, app_ds_id, event_type_code, description)
VALUES(30035, 'RewardRedemptionRequest', 30001,'RewardRedemptionRequest', 'TIBCO JMS Events');

INSERT INTO RTS3_EVENT_ACTION(id,app_event_id,action_type_code,exec_order)
VALUES(30035,30035,'SAVE_MONGO',1);

INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name,param_value)
VALUES(30103,30035,'mongodb.uri','mongodb://eap_mongodb_uat:$PASSWORD@maas-gt-p72-m0002.nam.nsroot.net:37017,maas-sw-p72-m0001.nam.nsroot.net:37017,maas-mw-p72-m0001.nam.nsroot.net:37017/GCG_ASIA_MY?ssl=true&authSource=admin');
INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name,param_value)
VALUES(30104,30035,'mongodb.db.name','GCG_ASIA_MY');
INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name,param_value)
VALUES(30105,30035,'mongodb.collection.name','EAP_IVR_REWARD_REDEMPTION_REQUEST');

INSERT INTO RTS3_APP_DS_EVENT(id, name, app_ds_id, event_type_code, description)
VALUES(30036, 'SDNMatchFound', 30001,'SDNMatchFound', 'TIBCO JMS Events');

INSERT INTO RTS3_EVENT_ACTION(id,app_event_id,action_type_code,exec_order)
VALUES(30036,30036,'SAVE_MONGO',1);

INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name,param_value)
VALUES(30106,30036,'mongodb.uri','mongodb://eap_mongodb_uat:$PASSWORD@maas-gt-p72-m0002.nam.nsroot.net:37017,maas-sw-p72-m0001.nam.nsroot.net:37017,maas-mw-p72-m0001.nam.nsroot.net:37017/GCG_ASIA_MY?ssl=true&authSource=admin');
INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name,param_value)
VALUES(30107,30036,'mongodb.db.name','GCG_ASIA_MY');
INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name,param_value)
VALUES(30108,30036,'mongodb.collection.name','EAP_IVR_SDN_MATCH_FOUND');

INSERT INTO RTS3_APP_DS_EVENT(id, name, app_ds_id, event_type_code, description)
VALUES(30037, 'SDNMatchResolved', 30001,'SDNMatchResolved', 'TIBCO JMS Events');

INSERT INTO RTS3_EVENT_ACTION(id,app_event_id,action_type_code,exec_order)
VALUES(30037,30037,'SAVE_MONGO',1);

INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name,param_value)
VALUES(30109,30037,'mongodb.uri','mongodb://eap_mongodb_uat:$PASSWORD@maas-gt-p72-m0002.nam.nsroot.net:37017,maas-sw-p72-m0001.nam.nsroot.net:37017,maas-mw-p72-m0001.nam.nsroot.net:37017/GCG_ASIA_MY?ssl=true&authSource=admin');
INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name,param_value)
VALUES(30110,30037,'mongodb.db.name','GCG_ASIA_MY');
INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name,param_value)
VALUES(30111,30037,'mongodb.collection.name','EAP_IVR_SDN_MATCH_RESOLVED');

INSERT INTO RTS3_APP_DS_EVENT(id, name, app_ds_id, event_type_code, description)
VALUES(30038, 'ServiceRequest', 30001,'ServiceRequest', 'TIBCO JMS Events');

INSERT INTO RTS3_EVENT_ACTION(id,app_event_id,action_type_code,exec_order)
VALUES(30038,30038,'SAVE_MONGO',1);

INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name,param_value)
VALUES(30112,30038,'mongodb.uri','mongodb://eap_mongodb_uat:$PASSWORD@maas-gt-p72-m0002.nam.nsroot.net:37017,maas-sw-p72-m0001.nam.nsroot.net:37017,maas-mw-p72-m0001.nam.nsroot.net:37017/GCG_ASIA_MY?ssl=true&authSource=admin');
INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name,param_value)
VALUES(30113,30038,'mongodb.db.name','GCG_ASIA_MY');
INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name,param_value)
VALUES(30114,30038,'mongodb.collection.name','EAP_IVR_SERVICE_REQUEST');

INSERT INTO RTS3_APP_DS_EVENT(id, name, app_ds_id, event_type_code, description)
VALUES(30039, 'SMSEmailOffers', 30001,'SMSEmailOffers', 'TIBCO JMS Events');

INSERT INTO RTS3_EVENT_ACTION(id,app_event_id,action_type_code,exec_order)
VALUES(30039,30039,'SAVE_MONGO',1);

INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name,param_value)
VALUES(30115,30039,'mongodb.uri','mongodb://eap_mongodb_uat:$PASSWORD@maas-gt-p72-m0002.nam.nsroot.net:37017,maas-sw-p72-m0001.nam.nsroot.net:37017,maas-mw-p72-m0001.nam.nsroot.net:37017/GCG_ASIA_MY?ssl=true&authSource=admin');
INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name,param_value)
VALUES(30116,30039,'mongodb.db.name','GCG_ASIA_MY');
INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name,param_value)
VALUES(30117,30039,'mongodb.collection.name','EAP_IVR_SMS_EMAIL_OFFERS');

INSERT INTO RTS3_APP_DS_EVENT(id, name, app_ds_id, event_type_code, description)
VALUES(30040, 'TPINCreateResetChangeIssuance', 30001,'TPINCreateResetChangeIssuance', 'TIBCO JMS Events');

INSERT INTO RTS3_EVENT_ACTION(id,app_event_id,action_type_code,exec_order)
VALUES(30040,30040,'SAVE_MONGO',1);

INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name,param_value)
VALUES(30118,30040,'mongodb.uri','mongodb://eap_mongodb_uat:$PASSWORD@maas-gt-p72-m0002.nam.nsroot.net:37017,maas-sw-p72-m0001.nam.nsroot.net:37017,maas-mw-p72-m0001.nam.nsroot.net:37017/GCG_ASIA_MY?ssl=true&authSource=admin');
INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name,param_value)
VALUES(30119,30040,'mongodb.db.name','GCG_ASIA_MY');
INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name,param_value)
VALUES(30120,30040,'mongodb.collection.name','EAP_IVR_TPIN_CREATE_RESET_CHANGE_ISSUANCE');

INSERT INTO RTS3_APP_DS_EVENT(id, name, app_ds_id, event_type_code, description)
VALUES(30041, 'ViewTransactionsHistory', 30001,'ViewTransactionsHistory', 'TIBCO JMS Events');

INSERT INTO RTS3_EVENT_ACTION(id,app_event_id,action_type_code,exec_order)
VALUES(30041,30041,'SAVE_MONGO',1);

INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name,param_value)
VALUES(30121,30041,'mongodb.uri','mongodb://eap_mongodb_uat:$PASSWORD@maas-gt-p72-m0002.nam.nsroot.net:37017,maas-sw-p72-m0001.nam.nsroot.net:37017,maas-mw-p72-m0001.nam.nsroot.net:37017/GCG_ASIA_MY?ssl=true&authSource=admin');
INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name,param_value)
VALUES(30122,30041,'mongodb.db.name','GCG_ASIA_MY');
INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name,param_value)
VALUES(30123,30041,'mongodb.collection.name','EAP_IVR_VIEW_TRANSACTIONS_HISTORY');


INSERT INTO RTS3_APP_DS_EVENT(id, name, app_ds_id, event_type_code, description)
VALUES(30042, 'CollectionsAlert', 30001,'CollectionsAlert', 'TIBCO JMS Events');

INSERT INTO RTS3_EVENT_ACTION(id,app_event_id,action_type_code,exec_order)
VALUES(30042,30042,'SAVE_MONGO',1);

INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name,param_value)
VALUES(30124,30042,'mongodb.uri','mongodb://eap_mongodb_uat:$PASSWORD@maas-gt-p72-m0002.nam.nsroot.net:37017,maas-sw-p72-m0001.nam.nsroot.net:37017,maas-mw-p72-m0001.nam.nsroot.net:37017/GCG_ASIA_MY?ssl=true&authSource=admin');
INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name,param_value)
VALUES(30125,30042,'mongodb.db.name','GCG_ASIA_MY');
INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name,param_value)
VALUES(30126,30042,'mongodb.collection.name','EAP_IVR_DWH_EVENT_SCHEMA');

INSERT INTO RTS3_APP_DS_EVENT(id, name, app_ds_id, event_type_code, description)
VALUES(30043, 'AnnualFeeCharged', 30001,'AnnualFeeCharged', 'TIBCO JMS Events');

INSERT INTO RTS3_EVENT_ACTION(id,app_event_id,action_type_code,exec_order)
VALUES(30043,30043,'SAVE_MONGO',1);

INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name,param_value)
VALUES(30127,30043,'mongodb.uri','mongodb://eap_mongodb_uat:$PASSWORD@maas-gt-p72-m0002.nam.nsroot.net:37017,maas-sw-p72-m0001.nam.nsroot.net:37017,maas-mw-p72-m0001.nam.nsroot.net:37017/GCG_ASIA_MY?ssl=true&authSource=admin');
INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name,param_value)
VALUES(30128,30043,'mongodb.db.name','GCG_ASIA_MY');
INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name,param_value)
VALUES(30129,30043,'mongodb.collection.name','EAP_IVR_DWH_EVENT_SCHEMA');

INSERT INTO RTS3_APP_DS_EVENT(id, name, app_ds_id, event_type_code, description)
VALUES(30044, 'DirectDebit', 30001,'DirectDebit', 'TIBCO JMS Events');

INSERT INTO RTS3_EVENT_ACTION(id,app_event_id,action_type_code,exec_order)
VALUES(30044,30044,'SAVE_MONGO',1);

INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name,param_value)
VALUES(30130,30044,'mongodb.uri','mongodb://eap_mongodb_uat:$PASSWORD@maas-gt-p72-m0002.nam.nsroot.net:37017,maas-sw-p72-m0001.nam.nsroot.net:37017,maas-mw-p72-m0001.nam.nsroot.net:37017/GCG_ASIA_MY?ssl=true&authSource=admin');
INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name,param_value)
VALUES(30131,30044,'mongodb.db.name','GCG_ASIA_MY');
INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name,param_value)
VALUES(30132,30044,'mongodb.collection.name','EAP_IVR_DWH_EVENT_SCHEMA');

INSERT INTO RTS3_APP_DS_EVENT(id, name, app_ds_id, event_type_code, description)
VALUES(30045, 'StandingInstructionExecution', 30001,'StandingInstructionExecution', 'TIBCO JMS Events');

INSERT INTO RTS3_EVENT_ACTION(id,app_event_id,action_type_code,exec_order)
VALUES(30045,30045,'SAVE_MONGO',1);

INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name,param_value)
VALUES(30133,30045,'mongodb.uri','mongodb://eap_mongodb_uat:$PASSWORD@maas-gt-p72-m0002.nam.nsroot.net:37017,maas-sw-p72-m0001.nam.nsroot.net:37017,maas-mw-p72-m0001.nam.nsroot.net:37017/GCG_ASIA_MY?ssl=true&authSource=admin');
INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name,param_value)
VALUES(30134,30045,'mongodb.db.name','GCG_ASIA_MY');
INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name,param_value)
VALUES(30135,30045,'mongodb.collection.name','EAP_IVR_DWH_EVENT_SCHEMA');

INSERT INTO RTS3_APP_DS_EVENT(id, name, app_ds_id, event_type_code, description)
VALUES(30046, 'Cardissuance', 30001,'Cardissuance', 'TIBCO JMS Events');

INSERT INTO RTS3_EVENT_ACTION(id,app_event_id,action_type_code,exec_order)
VALUES(30046,30046,'SAVE_MONGO',1);

INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name,param_value)
VALUES(30136,30046,'mongodb.uri','mongodb://eap_mongodb_uat:$PASSWORD@maas-gt-p72-m0002.nam.nsroot.net:37017,maas-sw-p72-m0001.nam.nsroot.net:37017,maas-mw-p72-m0001.nam.nsroot.net:37017/GCG_ASIA_MY?ssl=true&authSource=admin');
INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name,param_value)
VALUES(30137,30046,'mongodb.db.name','GCG_ASIA_MY');
INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name,param_value)
VALUES(30138,30046,'mongodb.collection.name','EAP_IVR_DWH_EVENT_SCHEMA');

INSERT INTO RTS3_APP_DS_EVENT(id, name, app_ds_id, event_type_code, description)
VALUES(30047, 'StatementGeneration', 30001,'StatementGeneration', 'TIBCO JMS Events');

INSERT INTO RTS3_EVENT_ACTION(id,app_event_id,action_type_code,exec_order)
VALUES(30047,30047,'SAVE_MONGO',1);

INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name,param_value)
VALUES(30139,30047,'mongodb.uri','mongodb://eap_mongodb_uat:$PASSWORD@maas-gt-p72-m0002.nam.nsroot.net:37017,maas-sw-p72-m0001.nam.nsroot.net:37017,maas-mw-p72-m0001.nam.nsroot.net:37017/GCG_ASIA_MY?ssl=true&authSource=admin');
INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name,param_value)
VALUES(30140,30047,'mongodb.db.name','GCG_ASIA_MY');
INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name,param_value)
VALUES(30141,30047,'mongodb.collection.name','EAP_IVR_DWH_EVENT_SCHEMA');

INSERT INTO RTS3_APP_DS_EVENT(id, name, app_ds_id, event_type_code, description)
VALUES(30048, 'LateFinanceCharge', 30001,'LateFinanceCharge', 'TIBCO JMS Events');

INSERT INTO RTS3_EVENT_ACTION(id,app_event_id,action_type_code,exec_order)
VALUES(30048,30048,'SAVE_MONGO',1);

INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name,param_value)
VALUES(30142,30048,'mongodb.uri','mongodb://eap_mongodb_uat:$PASSWORD@maas-gt-p72-m0002.nam.nsroot.net:37017,maas-sw-p72-m0001.nam.nsroot.net:37017,maas-mw-p72-m0001.nam.nsroot.net:37017/GCG_ASIA_MY?ssl=true&authSource=admin');
INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name,param_value)
VALUES(30143,30048,'mongodb.db.name','GCG_ASIA_MY');
INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name,param_value)
VALUES(30144,30048,'mongodb.collection.name','EAP_IVR_DWH_EVENT_SCHEMA');

INSERT INTO RTS3_APP_DS_EVENT(id, name, app_ds_id, event_type_code, description)
VALUES(30049, 'MinimunBalanceBankcharge', 30001,'MinimunBalanceBankcharge', 'TIBCO JMS Events');

INSERT INTO RTS3_EVENT_ACTION(id,app_event_id,action_type_code,exec_order)
VALUES(30049,30049,'SAVE_MONGO',1);

INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name,param_value)
VALUES(30145,30049,'mongodb.uri','mongodb://eap_mongodb_uat:$PASSWORD@maas-gt-p72-m0002.nam.nsroot.net:37017,maas-sw-p72-m0001.nam.nsroot.net:37017,maas-mw-p72-m0001.nam.nsroot.net:37017/GCG_ASIA_MY?ssl=true&authSource=admin');
INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name,param_value)
VALUES(30146,30049,'mongodb.db.name','GCG_ASIA_MY');
INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name,param_value)
VALUES(30147,30049,'mongodb.collection.name','EAP_IVR_DWH_EVENT_SCHEMA');

INSERT INTO RTS3_APP_DS_EVENT(id, name, app_ds_id, event_type_code, description)
VALUES(30050, 'PreEmbossCardIssued', 30001,'PreEmbossCardIssued', 'TIBCO JMS Events');

INSERT INTO RTS3_EVENT_ACTION(id,app_event_id,action_type_code,exec_order)
VALUES(30050,30050,'SAVE_MONGO',1);

INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name,param_value)
VALUES(30148,30050,'mongodb.uri','mongodb://eap_mongodb_uat:$PASSWORD@maas-gt-p72-m0002.nam.nsroot.net:37017,maas-sw-p72-m0001.nam.nsroot.net:37017,maas-mw-p72-m0001.nam.nsroot.net:37017/GCG_ASIA_MY?ssl=true&authSource=admin');
INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name,param_value)
VALUES(30149,30050,'mongodb.db.name','GCG_ASIA_MY');
INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name,param_value)
VALUES(30150,30050,'mongodb.collection.name','EAP_IVR_DWH_EVENT_SCHEMA');

INSERT INTO RTS3_APP_DS_EVENT(id, name, app_ds_id, event_type_code, description)
VALUES(30051, 'BankAccountStatusChange', 30001,'BankAccountStatusChange', 'TIBCO JMS Events');

INSERT INTO RTS3_EVENT_ACTION(id,app_event_id,action_type_code,exec_order)
VALUES(30051,30051,'SAVE_MONGO',1);

INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name,param_value)
VALUES(30151,30051,'mongodb.uri','mongodb://eap_mongodb_uat:$PASSWORD@maas-gt-p72-m0002.nam.nsroot.net:37017,maas-sw-p72-m0001.nam.nsroot.net:37017,maas-mw-p72-m0001.nam.nsroot.net:37017/GCG_ASIA_MY?ssl=true&authSource=admin');
INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name,param_value)
VALUES(30152,30051,'mongodb.db.name','GCG_ASIA_MY');
INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name,param_value)
VALUES(30153,30051,'mongodb.collection.name','EAP_IVR_DWH_EVENT_SCHEMA');

INSERT INTO RTS3_APP_DS_EVENT(id, name, app_ds_id, event_type_code, description)
VALUES(30052, 'CustomerWhereAbout', 30001,'CustomerWhereAbout', 'TIBCO JMS Events');

INSERT INTO RTS3_EVENT_ACTION(id,app_event_id,action_type_code,exec_order)
VALUES(30052,30052,'SAVE_MONGO',1);

INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name,param_value)
VALUES(30154,30052,'mongodb.uri','mongodb://eap_mongodb_uat:$PASSWORD@maas-gt-p72-m0002.nam.nsroot.net:37017,maas-sw-p72-m0001.nam.nsroot.net:37017,maas-mw-p72-m0001.nam.nsroot.net:37017/GCG_ASIA_MY?ssl=true&authSource=admin');
INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name,param_value)
VALUES(30155,30052,'mongodb.db.name','GCG_ASIA_MY');
INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name,param_value)
VALUES(30156,30052,'mongodb.collection.name','EAP_IVR_DWH_EVENT_SCHEMA');

INSERT INTO RTS3_APP_DS_EVENT(id, name, app_ds_id, event_type_code, description)
VALUES(30053, 'TDRollOver', 30001,'TDRollOver', 'TIBCO JMS Events');

INSERT INTO RTS3_EVENT_ACTION(id,app_event_id,action_type_code,exec_order)
VALUES(30053,30053,'SAVE_MONGO',1);

INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name,param_value)
VALUES(30157,30053,'mongodb.uri','mongodb://eap_mongodb_uat:$PASSWORD@maas-gt-p72-m0002.nam.nsroot.net:37017,maas-sw-p72-m0001.nam.nsroot.net:37017,maas-mw-p72-m0001.nam.nsroot.net:37017/GCG_ASIA_MY?ssl=true&authSource=admin');
INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name,param_value)
VALUES(30158,30053,'mongodb.db.name','GCG_ASIA_MY');
INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name,param_value)
VALUES(30159,30053,'mongodb.collection.name','EAP_IVR_DWH_EVENT_SCHEMA');

INSERT INTO RTS3_APP_DS_EVENT(id, name, app_ds_id, event_type_code, description)
VALUES(30054, 'CallFeedback', 30001,'CallFeedback', 'TIBCO JMS Events');

INSERT INTO RTS3_EVENT_ACTION(id,app_event_id,action_type_code,exec_order)
VALUES(30054,30054,'SAVE_MONGO',1);

INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name,param_value)
VALUES(30160,30054,'mongodb.uri','mongodb://eap_mongodb_uat:$PASSWORD@maas-gt-p72-m0002.nam.nsroot.net:37017,maas-sw-p72-m0001.nam.nsroot.net:37017,maas-mw-p72-m0001.nam.nsroot.net:37017/GCG_ASIA_MY?ssl=true&authSource=admin');
INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name,param_value)
VALUES(30161,30054,'mongodb.db.name','GCG_ASIA_MY');
INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name,param_value)
VALUES(30162,30054,'mongodb.collection.name','MONGO_IVR_AGNT_FEED_RSN_TXN_D');






INSERT INTO RTS3_APP_DS(id, name, app_id, ds_type_code, description,default_event)
VALUES(30002, 'EVENT_HUB_DS2', 30001,'TIBCO', 'EVENT HUB DS2',null);

INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value)
VALUES(30021,30002,'INITIAL_CONTEXT_FACTORY','com.tibco.tibjms.naming.TibjmsInitialContextFactory');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value)
VALUES(30022,30002,'PROVIDER_URL', 'ssl://mwgtc-tibla16s.nam.nsroot.net:7243');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value)
VALUES(30023,30002,'com.tibco.tibjms.naming.ssl_identity', '/user/gcgauasg/security/UAT_EAP_USR.ca1.p12');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value)
VALUES(30024,30002,'com.tibco.tibjms.naming.ssl_password', '');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value)
VALUES(30025,30002,'SECURITY_PRINCIPAL', 'UAT_EAP_USR');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value)
VALUES(30026,30002,'SECURITY_CREDENTIALS', '');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value)
VALUES(30027,30002,'com.tibco.tibjms.naming.security_protocol', 'ssl');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value)
VALUES(30028,30002,'com.tibco.tibjms.naming.ssl_enable_verify_host', 'false');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value)
VALUES(30029,30002,'com.tibco.tibjms.naming.ssl_vendor', 'j2se-default');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value)
VALUES(30030,30002,'com.sun.net.ssl.internal.ssl.Provider', 'j2se-default');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value)
VALUES(30031,30002,'com.tibco.tibjms.naming.ssl_auth_only', 'true');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value)
VALUES(30032,30002,'java.property.TIBCO_SECURITY_VENDOR','j2se-default');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value)
VALUES(30033,30002,'java.property.TIBCO_SECURITY_TRACE', 'false');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value)
VALUES(30034,30002,'com.tibco.tibjms.naming.ssl_debug_trace', 'true');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value)
VALUES(30035,30002,'com.tibco.tibjms.naming.ssl_trace','true');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value)
VALUES(30036,30002,'tibco.jms.queue.queueCF','G2C_EC_EAP2QueueConnectionFactory');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value)
VALUES(30037,30002,'tibco.jms.inbound.queue.name','citi.gcg.apac.eventcloud.consumer.eap');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value)
VALUES(30038,30002,'tibco.jms.queue.username','UAT_EAP_USR');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value)
VALUES(30039,30002,'tibco.jms.queue.password','');
INSERT INTO RTS3_APP_DS_DETAIL(id, app_ds_id, param_name, param_value)
VALUES(30040,30002,'tibco.p12.enable','true');

INSERT INTO RTS3_APP_DS_EVENT(id, name, app_ds_id, event_type_code, description)
VALUES(30055, 'CardActivation', 30002,'CardActivation', 'TIBCO JMS Events');

INSERT INTO RTS3_EVENT_ACTION(id,app_event_id,action_type_code,exec_order)
VALUES(30055,30055,'SAVE_MONGO',1);

INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name,param_value)
VALUES(30163,30055,'mongodb.uri','mongodb://eap_mongodb_uat:$PASSWORD@maas-gt-p72-m0002.nam.nsroot.net:37017,maas-sw-p72-m0001.nam.nsroot.net:37017,maas-mw-p72-m0001.nam.nsroot.net:37017/GCG_ASIA_MY?ssl=true&authSource=admin');
INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name,param_value)
VALUES(30164,30055,'mongodb.db.name','GCG_ASIA_MY');
INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name,param_value)
VALUES(30165,30055,'mongodb.collection.name','EAP_IVR_CARD_ACTIVATION');

INSERT INTO RTS3_APP_DS_EVENT(id, name, app_ds_id, event_type_code, description)
VALUES(30056, 'AccountLinkage', 30002,'AccountLinkage', 'TIBCO JMS Events');

INSERT INTO RTS3_EVENT_ACTION(id,app_event_id,action_type_code,exec_order)
VALUES(30056,30056,'SAVE_MONGO',1);

INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name,param_value)
VALUES(30166,30056,'mongodb.uri','mongodb://eap_mongodb_uat:$PASSWORD@maas-gt-p72-m0002.nam.nsroot.net:37017,maas-sw-p72-m0001.nam.nsroot.net:37017,maas-mw-p72-m0001.nam.nsroot.net:37017/GCG_ASIA_MY?ssl=true&authSource=admin');
INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name,param_value)
VALUES(30167,30056,'mongodb.db.name','GCG_ASIA_MY');
INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name,param_value)
VALUES(30168,30056,'mongodb.collection.name','EAP_IVR_ACCOUNT_LINKAGE');

INSERT INTO RTS3_APP_DS_EVENT(id, name, app_ds_id, event_type_code, description)
VALUES(30057, 'AccountSummary', 30002,'AccountSummary', 'TIBCO JMS Events');

INSERT INTO RTS3_EVENT_ACTION(id,app_event_id,action_type_code,exec_order)
VALUES(30057,30057,'SAVE_MONGO',1);

INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name,param_value)
VALUES(30169,30057,'mongodb.uri','mongodb://eap_mongodb_uat:$PASSWORD@maas-gt-p72-m0002.nam.nsroot.net:37017,maas-sw-p72-m0001.nam.nsroot.net:37017,maas-mw-p72-m0001.nam.nsroot.net:37017/GCG_ASIA_MY?ssl=true&authSource=admin');
INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name,param_value)
VALUES(30170,30057,'mongodb.db.name','GCG_ASIA_MY');
INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name,param_value)
VALUES(30171,30057,'mongodb.collection.name','EAP_IVR_ACCOUNT_SUMMARY');

INSERT INTO RTS3_APP_DS_EVENT(id, name, app_ds_id, event_type_code, description)
VALUES(30058, 'APINChange', 30002,'APINChange', 'TIBCO JMS Events');

INSERT INTO RTS3_EVENT_ACTION(id,app_event_id,action_type_code,exec_order)
VALUES(30058,30058,'SAVE_MONGO',1);

INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name,param_value)
VALUES(30172,30058,'mongodb.uri','mongodb://eap_mongodb_uat:$PASSWORD@maas-gt-p72-m0002.nam.nsroot.net:37017,maas-sw-p72-m0001.nam.nsroot.net:37017,maas-mw-p72-m0001.nam.nsroot.net:37017/GCG_ASIA_MY?ssl=true&authSource=admin');
INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name,param_value)
VALUES(30173,30058,'mongodb.db.name','GCG_ASIA_MY');
INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name,param_value)
VALUES(30174,30058,'mongodb.collection.name','EAP_IVR_APIN_CHANGE');

INSERT INTO RTS3_APP_DS_EVENT(id, name, app_ds_id, event_type_code, description)
VALUES(30059, 'BillPayment', 30002,'BillPayment', 'TIBCO JMS Events');

INSERT INTO RTS3_EVENT_ACTION(id,app_event_id,action_type_code,exec_order)
VALUES(30059,30059,'SAVE_MONGO',1);

INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name,param_value)
VALUES(30175,30059,'mongodb.uri','mongodb://eap_mongodb_uat:$PASSWORD@maas-gt-p72-m0002.nam.nsroot.net:37017,maas-sw-p72-m0001.nam.nsroot.net:37017,maas-mw-p72-m0001.nam.nsroot.net:37017/GCG_ASIA_MY?ssl=true&authSource=admin');
INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name,param_value)
VALUES(30176,30059,'mongodb.db.name','GCG_ASIA_MY');
INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name,param_value)
VALUES(30177,30059,'mongodb.collection.name','EAP_IVR_BILL_PAYMENT');

INSERT INTO RTS3_APP_DS_EVENT(id, name, app_ds_id, event_type_code, description)
VALUES(30060, 'CardBlockCodeUpdate', 30002,'CardBlockCodeUpdate', 'TIBCO JMS Events');

INSERT INTO RTS3_EVENT_ACTION(id,app_event_id,action_type_code,exec_order)
VALUES(30060,30060,'SAVE_MONGO',1);

INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name,param_value)
VALUES(30178,30060,'mongodb.uri','mongodb://eap_mongodb_uat:$PASSWORD@maas-gt-p72-m0002.nam.nsroot.net:37017,maas-sw-p72-m0001.nam.nsroot.net:37017,maas-mw-p72-m0001.nam.nsroot.net:37017/GCG_ASIA_MY?ssl=true&authSource=admin');
INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name,param_value)
VALUES(30179,30060,'mongodb.db.name','GCG_ASIA_MY');
INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name,param_value)
VALUES(30180,30060,'mongodb.collection.name','EAP_IVR_CARD_BLOCK_CODE_UPDATE');

INSERT INTO RTS3_APP_DS_EVENT(id, name, app_ds_id, event_type_code, description)
VALUES(30061, 'CardDecline', 30002,'CardDecline', 'TIBCO JMS Events');

INSERT INTO RTS3_EVENT_ACTION(id,app_event_id,action_type_code,exec_order)
VALUES(30061,30061,'SAVE_MONGO',1);

INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name,param_value)
VALUES(30181,30061,'mongodb.uri','mongodb://eap_mongodb_uat:$PASSWORD@maas-gt-p72-m0002.nam.nsroot.net:37017,maas-sw-p72-m0001.nam.nsroot.net:37017,maas-mw-p72-m0001.nam.nsroot.net:37017/GCG_ASIA_MY?ssl=true&authSource=admin');
INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name,param_value)
VALUES(30182,30061,'mongodb.db.name','GCG_ASIA_MY');
INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name,param_value)
VALUES(30183,30061,'mongodb.collection.name','EAP_IVR_CARD_DECLINE');

INSERT INTO RTS3_APP_DS_EVENT(id, name, app_ds_id, event_type_code, description)
VALUES(30062, 'CBOLMBOLRegistration', 30002,'CBOLMBOLRegistration', 'TIBCO JMS Events');

INSERT INTO RTS3_EVENT_ACTION(id,app_event_id,action_type_code,exec_order)
VALUES(30062,30062,'SAVE_MONGO',1);

INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name,param_value)
VALUES(30184,30062,'mongodb.uri','mongodb://eap_mongodb_uat:$PASSWORD@maas-gt-p72-m0002.nam.nsroot.net:37017,maas-sw-p72-m0001.nam.nsroot.net:37017,maas-mw-p72-m0001.nam.nsroot.net:37017/GCG_ASIA_MY?ssl=true&authSource=admin');
INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name,param_value)
VALUES(30185,30062,'mongodb.db.name','GCG_ASIA_MY');
INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name,param_value)
VALUES(30186,30062,'mongodb.collection.name','EAP_IVR_CBOL_MBOL_REGISTRATION');

INSERT INTO RTS3_APP_DS_EVENT(id, name, app_ds_id, event_type_code, description)
VALUES(30063, 'ChargeDispute', 30002,'ChargeDispute', 'TIBCO JMS Events');

INSERT INTO RTS3_EVENT_ACTION(id,app_event_id,action_type_code,exec_order)
VALUES(30063,30063,'SAVE_MONGO',1);

INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name,param_value)
VALUES(30187,30063,'mongodb.uri','mongodb://eap_mongodb_uat:$PASSWORD@maas-gt-p72-m0002.nam.nsroot.net:37017,maas-sw-p72-m0001.nam.nsroot.net:37017,maas-mw-p72-m0001.nam.nsroot.net:37017/GCG_ASIA_MY?ssl=true&authSource=admin');
INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name,param_value)
VALUES(30188,30063,'mongodb.db.name','GCG_ASIA_MY');
INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name,param_value)
VALUES(30189,30063,'mongodb.collection.name','EAP_IVR_CHARGE_DISPUTE');

INSERT INTO RTS3_APP_DS_EVENT(id, name, app_ds_id, event_type_code, description)
VALUES(30064, 'ChequeBounce', 30002,'ChequeBounce', 'TIBCO JMS Events');

INSERT INTO RTS3_EVENT_ACTION(id,app_event_id,action_type_code,exec_order)
VALUES(30064,30064,'SAVE_MONGO',1);

INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name,param_value)
VALUES(30190,30064,'mongodb.uri','mongodb://eap_mongodb_uat:$PASSWORD@maas-gt-p72-m0002.nam.nsroot.net:37017,maas-sw-p72-m0001.nam.nsroot.net:37017,maas-mw-p72-m0001.nam.nsroot.net:37017/GCG_ASIA_MY?ssl=true&authSource=admin');
INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name,param_value)
VALUES(30191,30064,'mongodb.db.name','GCG_ASIA_MY');
INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name,param_value)
VALUES(30192,30064,'mongodb.collection.name','EAP_IVR_CHEQUE_BOUNCE');

INSERT INTO RTS3_APP_DS_EVENT(id, name, app_ds_id, event_type_code, description)
VALUES(30065, 'ChequeStopPayment', 30002,'ChequeStopPayment', 'TIBCO JMS Events');

INSERT INTO RTS3_EVENT_ACTION(id,app_event_id,action_type_code,exec_order)
VALUES(30065,30065,'SAVE_MONGO',1);

INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name,param_value)
VALUES(30193,30065,'mongodb.uri','mongodb://eap_mongodb_uat:$PASSWORD@maas-gt-p72-m0002.nam.nsroot.net:37017,maas-sw-p72-m0001.nam.nsroot.net:37017,maas-mw-p72-m0001.nam.nsroot.net:37017/GCG_ASIA_MY?ssl=true&authSource=admin');
INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name,param_value)
VALUES(30194,30065,'mongodb.db.name','GCG_ASIA_MY');
INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name,param_value)
VALUES(30195,30065,'mongodb.collection.name','EAP_IVR_CHEQUE_STOPPAYMENT');

INSERT INTO RTS3_APP_DS_EVENT(id, name, app_ds_id, event_type_code, description)
VALUES(30066, 'CpoCallEnd', 30002,'CpoCallEnd', 'TIBCO JMS Events');

INSERT INTO RTS3_EVENT_ACTION(id,app_event_id,action_type_code,exec_order)
VALUES(30066,30066,'SAVE_MONGO',1);

INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name,param_value)
VALUES(30196,30066,'mongodb.uri','mongodb://eap_mongodb_uat:$PASSWORD@maas-gt-p72-m0002.nam.nsroot.net:37017,maas-sw-p72-m0001.nam.nsroot.net:37017,maas-mw-p72-m0001.nam.nsroot.net:37017/GCG_ASIA_MY?ssl=true&authSource=admin');
INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name,param_value)
VALUES(30197,30066,'mongodb.db.name','GCG_ASIA_MY');
INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name,param_value)
VALUES(30198,30066,'mongodb.collection.name','EAP_IVR_CPO_CALL_END');

INSERT INTO RTS3_APP_DS_EVENT(id, name, app_ds_id, event_type_code, description)
VALUES(30067, 'CpoCallStart', 30002,'CpoCallStart', 'TIBCO JMS Events');

INSERT INTO RTS3_EVENT_ACTION(id,app_event_id,action_type_code,exec_order)
VALUES(30067,30067,'SAVE_MONGO',1);

INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name,param_value)
VALUES(30199,30067,'mongodb.uri','mongodb://eap_mongodb_uat:$PASSWORD@maas-gt-p72-m0002.nam.nsroot.net:37017,maas-sw-p72-m0001.nam.nsroot.net:37017,maas-mw-p72-m0001.nam.nsroot.net:37017/GCG_ASIA_MY?ssl=true&authSource=admin');
INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name,param_value)
VALUES(30200,30067,'mongodb.db.name','GCG_ASIA_MY');
INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name,param_value)
VALUES(30201,30067,'mongodb.collection.name','EAP_IVR_CPO_CALL_START');

INSERT INTO RTS3_APP_DS_EVENT(id, name, app_ds_id, event_type_code, description)
VALUES(30068, 'CreditCardClosure', 30002,'CreditCardClosure', 'TIBCO JMS Events');

INSERT INTO RTS3_EVENT_ACTION(id,app_event_id,action_type_code,exec_order)
VALUES(30068,30068,'SAVE_MONGO',1);

INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name,param_value)
VALUES(30202,30068,'mongodb.uri','mongodb://eap_mongodb_uat:$PASSWORD@maas-gt-p72-m0002.nam.nsroot.net:37017,maas-sw-p72-m0001.nam.nsroot.net:37017,maas-mw-p72-m0001.nam.nsroot.net:37017/GCG_ASIA_MY?ssl=true&authSource=admin');
INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name,param_value)
VALUES(30203,30068,'mongodb.db.name','GCG_ASIA_MY');
INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name,param_value)
VALUES(30204,30068,'mongodb.collection.name','EAP_IVR_CREDIT_CARD_CLOSURE');

INSERT INTO RTS3_APP_DS_EVENT(id, name, app_ds_id, event_type_code, description)
VALUES(30069, 'CreditCardReversal', 30002,'CreditCardReversal', 'TIBCO JMS Events');

INSERT INTO RTS3_EVENT_ACTION(id,app_event_id,action_type_code,exec_order)
VALUES(30069,30069,'SAVE_MONGO',1);

INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name,param_value)
VALUES(30205,30069,'mongodb.uri','mongodb://eap_mongodb_uat:$PASSWORD@maas-gt-p72-m0002.nam.nsroot.net:37017,maas-sw-p72-m0001.nam.nsroot.net:37017,maas-mw-p72-m0001.nam.nsroot.net:37017/GCG_ASIA_MY?ssl=true&authSource=admin');
INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name,param_value)
VALUES(30206,30069,'mongodb.db.name','GCG_ASIA_MY');
INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name,param_value)
VALUES(30207,30069,'mongodb.collection.name','EAP_IVR_CREDIT_CARD_REVERSAL');

INSERT INTO RTS3_APP_DS_EVENT(id, name, app_ds_id, event_type_code, description)
VALUES(30070, 'CreditLimitIncrease', 30002,'CreditLimitIncrease', 'TIBCO JMS Events');

INSERT INTO RTS3_EVENT_ACTION(id,app_event_id,action_type_code,exec_order)
VALUES(30070,30070,'SAVE_MONGO',1);

INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name,param_value)
VALUES(30208,30070,'mongodb.uri','mongodb://eap_mongodb_uat:$PASSWORD@maas-gt-p72-m0002.nam.nsroot.net:37017,maas-sw-p72-m0001.nam.nsroot.net:37017,maas-mw-p72-m0001.nam.nsroot.net:37017/GCG_ASIA_MY?ssl=true&authSource=admin');
INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name,param_value)
VALUES(30209,30070,'mongodb.db.name','GCG_ASIA_MY');
INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name,param_value)
VALUES(30210,30070,'mongodb.collection.name','EAP_IVR_CREDIT_LIMIT_INCREASE');

INSERT INTO RTS3_APP_DS_EVENT(id, name, app_ds_id, event_type_code, description)
VALUES(30071, 'CustHWTokenRequest', 30002,'CustHWTokenRequest', 'TIBCO JMS Events');

INSERT INTO RTS3_EVENT_ACTION(id,app_event_id,action_type_code,exec_order)
VALUES(30071,30071,'SAVE_MONGO',1);

INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name,param_value)
VALUES(30211,30071,'mongodb.uri','mongodb://eap_mongodb_uat:$PASSWORD@maas-gt-p72-m0002.nam.nsroot.net:37017,maas-sw-p72-m0001.nam.nsroot.net:37017,maas-mw-p72-m0001.nam.nsroot.net:37017/GCG_ASIA_MY?ssl=true&authSource=admin');
INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name,param_value)
VALUES(30212,30071,'mongodb.db.name','GCG_ASIA_MY');
INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name,param_value)
VALUES(30213,30071,'mongodb.collection.name','EAP_IVR_CUST_HWTOKEN_REQUEST');

INSERT INTO RTS3_APP_DS_EVENT(id, name, app_ds_id, event_type_code, description)
VALUES(30072, 'CustLoginIDStatusChange', 30002,'CustLoginIDStatusChange', 'TIBCO JMS Events');

INSERT INTO RTS3_EVENT_ACTION(id,app_event_id,action_type_code,exec_order)
VALUES(30072,30072,'SAVE_MONGO',1);

INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name,param_value)
VALUES(30214,30072,'mongodb.uri','mongodb://eap_mongodb_uat:$PASSWORD@maas-gt-p72-m0002.nam.nsroot.net:37017,maas-sw-p72-m0001.nam.nsroot.net:37017,maas-mw-p72-m0001.nam.nsroot.net:37017/GCG_ASIA_MY?ssl=true&authSource=admin');
INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name,param_value)
VALUES(30215,30072,'mongodb.db.name','GCG_ASIA_MY');
INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name,param_value)
VALUES(30216,30072,'mongodb.collection.name','EAP_IVR_CUST_LOGINID_STATUS_CHANGE');

INSERT INTO RTS3_APP_DS_EVENT(id, name, app_ds_id, event_type_code, description)
VALUES(30073, 'CustomerLogin', 30002,'CustomerLogin', 'TIBCO JMS Events');

INSERT INTO RTS3_EVENT_ACTION(id,app_event_id,action_type_code,exec_order)
VALUES(30073,30073,'SAVE_MONGO',1);

INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name,param_value)
VALUES(30217,30073,'mongodb.uri','mongodb://eap_mongodb_uat:$PASSWORD@maas-gt-p72-m0002.nam.nsroot.net:37017,maas-sw-p72-m0001.nam.nsroot.net:37017,maas-mw-p72-m0001.nam.nsroot.net:37017/GCG_ASIA_MY?ssl=true&authSource=admin');
INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name,param_value)
VALUES(30218,30073,'mongodb.db.name','GCG_ASIA_MY');
INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name,param_value)
VALUES(30219,30073,'mongodb.collection.name','EAP_IVR_CUSTOMER_LOGIN');

INSERT INTO RTS3_APP_DS_EVENT(id, name, app_ds_id, event_type_code, description)
VALUES(30074, 'DemographicChange', 30002,'DemographicChange', 'TIBCO JMS Events');

INSERT INTO RTS3_EVENT_ACTION(id,app_event_id,action_type_code,exec_order)
VALUES(30074,30074,'SAVE_MONGO',1);

INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name,param_value)
VALUES(30220,30074,'mongodb.uri','mongodb://eap_mongodb_uat:$PASSWORD@maas-gt-p72-m0002.nam.nsroot.net:37017,maas-sw-p72-m0001.nam.nsroot.net:37017,maas-mw-p72-m0001.nam.nsroot.net:37017/GCG_ASIA_MY?ssl=true&authSource=admin');
INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name,param_value)
VALUES(30221,30074,'mongodb.db.name','GCG_ASIA_MY');
INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name,param_value)
VALUES(30222,30074,'mongodb.collection.name','EAP_IVR_DEMOGRAPHIC_CHANGE');

INSERT INTO RTS3_APP_DS_EVENT(id, name, app_ds_id, event_type_code, description)
VALUES(30075, 'DigiPassInitiation', 30002,'DigiPassInitiation', 'TIBCO JMS Events');

INSERT INTO RTS3_EVENT_ACTION(id,app_event_id,action_type_code,exec_order)
VALUES(30075,30075,'SAVE_MONGO',1);

INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name,param_value)
VALUES(30223,30075,'mongodb.uri','mongodb://eap_mongodb_uat:$PASSWORD@maas-gt-p72-m0002.nam.nsroot.net:37017,maas-sw-p72-m0001.nam.nsroot.net:37017,maas-mw-p72-m0001.nam.nsroot.net:37017/GCG_ASIA_MY?ssl=true&authSource=admin');
INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name,param_value)
VALUES(30224,30075,'mongodb.db.name','GCG_ASIA_MY');
INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name,param_value)
VALUES(30225,30075,'mongodb.collection.name','EAP_IVR_DIGI_PASS_INITIATION');

INSERT INTO RTS3_APP_DS_EVENT(id, name, app_ds_id, event_type_code, description)
VALUES(30076, 'EPPLOPOfferView', 30002,'EPPLOPOfferView', 'TIBCO JMS Events');

INSERT INTO RTS3_EVENT_ACTION(id,app_event_id,action_type_code,exec_order)
VALUES(30076,30076,'SAVE_MONGO',1);

INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name,param_value)
VALUES(30226,30076,'mongodb.uri','mongodb://eap_mongodb_uat:$PASSWORD@maas-gt-p72-m0002.nam.nsroot.net:37017,maas-sw-p72-m0001.nam.nsroot.net:37017,maas-mw-p72-m0001.nam.nsroot.net:37017/GCG_ASIA_MY?ssl=true&authSource=admin');
INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name,param_value)
VALUES(30227,30076,'mongodb.db.name','GCG_ASIA_MY');
INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name,param_value)
VALUES(30228,30076,'mongodb.collection.name','EAP_IVR_EPP_LOP_OFFER_VIEW');

INSERT INTO RTS3_APP_DS_EVENT(id, name, app_ds_id, event_type_code, description)
VALUES(30077, 'EstatementDispatch', 30002,'EstatementDispatch', 'TIBCO JMS Events');

INSERT INTO RTS3_EVENT_ACTION(id,app_event_id,action_type_code,exec_order)
VALUES(30077,30077,'SAVE_MONGO',1);

INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name,param_value)
VALUES(30229,30077,'mongodb.uri','mongodb://eap_mongodb_uat:$PASSWORD@maas-gt-p72-m0002.nam.nsroot.net:37017,maas-sw-p72-m0001.nam.nsroot.net:37017,maas-mw-p72-m0001.nam.nsroot.net:37017/GCG_ASIA_MY?ssl=true&authSource=admin');
INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name,param_value)
VALUES(30230,30077,'mongodb.db.name','GCG_ASIA_MY');
INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name,param_value)
VALUES(30231,30077,'mongodb.collection.name','EAP_IVR_ESTATEMENT_DISPATCH');

INSERT INTO RTS3_APP_DS_EVENT(id, name, app_ds_id, event_type_code, description)
VALUES(30078, 'eStatementView', 30002,'eStatementView', 'TIBCO JMS Events');

INSERT INTO RTS3_EVENT_ACTION(id,app_event_id,action_type_code,exec_order)
VALUES(30078,30078,'SAVE_MONGO',1);

INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name,param_value)
VALUES(30232,30078,'mongodb.uri','mongodb://eap_mongodb_uat:$PASSWORD@maas-gt-p72-m0002.nam.nsroot.net:37017,maas-sw-p72-m0001.nam.nsroot.net:37017,maas-mw-p72-m0001.nam.nsroot.net:37017/GCG_ASIA_MY?ssl=true&authSource=admin');
INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name,param_value)
VALUES(30233,30078,'mongodb.db.name','GCG_ASIA_MY');
INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name,param_value)
VALUES(30234,30078,'mongodb.collection.name','EAP_IVR_ESTATEMENT_VIEW');

INSERT INTO RTS3_APP_DS_EVENT(id, name, app_ds_id, event_type_code, description)
VALUES(30079, 'ForgotUserIdAndPassword', 30002,'ForgotUserIdAndPassword', 'TIBCO JMS Events');

INSERT INTO RTS3_EVENT_ACTION(id,app_event_id,action_type_code,exec_order)
VALUES(30079,30079,'SAVE_MONGO',1);

INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name,param_value)
VALUES(30235,30079,'mongodb.uri','mongodb://eap_mongodb_uat:$PASSWORD@maas-gt-p72-m0002.nam.nsroot.net:37017,maas-sw-p72-m0001.nam.nsroot.net:37017,maas-mw-p72-m0001.nam.nsroot.net:37017/GCG_ASIA_MY?ssl=true&authSource=admin');
INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name,param_value)
VALUES(30236,30079,'mongodb.db.name','GCG_ASIA_MY');
INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name,param_value)
VALUES(30237,30079,'mongodb.collection.name','EAP_IVR_FORGOT_USERID_AND_PASSWORD');

INSERT INTO RTS3_APP_DS_EVENT(id, name, app_ds_id, event_type_code, description)
VALUES(30080, 'IVRCallEnd', 30002,'IVRCallEnd', 'TIBCO JMS Events');

INSERT INTO RTS3_EVENT_ACTION(id,app_event_id,action_type_code,exec_order)
VALUES(30080,30080,'SAVE_MONGO',1);

INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name,param_value)
VALUES(30238,30080,'mongodb.uri','mongodb://eap_mongodb_uat:$PASSWORD@maas-gt-p72-m0002.nam.nsroot.net:37017,maas-sw-p72-m0001.nam.nsroot.net:37017,maas-mw-p72-m0001.nam.nsroot.net:37017/GCG_ASIA_MY?ssl=true&authSource=admin');
INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name,param_value)
VALUES(30239,30080,'mongodb.db.name','GCG_ASIA_MY');
INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name,param_value)
VALUES(30240,30080,'mongodb.collection.name','EAP_IVR_IVR_CALL_END');

INSERT INTO RTS3_APP_DS_EVENT(id, name, app_ds_id, event_type_code, description)
VALUES(30081, 'IVRCallStart', 30002,'IVRCallStart', 'TIBCO JMS Events');

INSERT INTO RTS3_EVENT_ACTION(id,app_event_id,action_type_code,exec_order)
VALUES(30081,30081,'SAVE_MONGO',1);

INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name,param_value)
VALUES(30241,30081,'mongodb.uri','mongodb://eap_mongodb_uat:$PASSWORD@maas-gt-p72-m0002.nam.nsroot.net:37017,maas-sw-p72-m0001.nam.nsroot.net:37017,maas-mw-p72-m0001.nam.nsroot.net:37017/GCG_ASIA_MY?ssl=true&authSource=admin');
INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name,param_value)
VALUES(30242,30081,'mongodb.db.name','GCG_ASIA_MY');
INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name,param_value)
VALUES(30243,30081,'mongodb.collection.name','EAP_IVR_IVR_CALL_START');

INSERT INTO RTS3_APP_DS_EVENT(id, name, app_ds_id, event_type_code, description)
VALUES(30082, 'OnlineDirectDebitExecution', 30002,'OnlineDirectDebitExecution', 'TIBCO JMS Events');

INSERT INTO RTS3_EVENT_ACTION(id,app_event_id,action_type_code,exec_order)
VALUES(30082,30082,'SAVE_MONGO',1);

INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name,param_value)
VALUES(30244,30082,'mongodb.uri','mongodb://eap_mongodb_uat:$PASSWORD@maas-gt-p72-m0002.nam.nsroot.net:37017,maas-sw-p72-m0001.nam.nsroot.net:37017,maas-mw-p72-m0001.nam.nsroot.net:37017/GCG_ASIA_MY?ssl=true&authSource=admin');
INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name,param_value)
VALUES(30245,30082,'mongodb.db.name','GCG_ASIA_MY');
INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name,param_value)
VALUES(30246,30082,'mongodb.collection.name','EAP_IVR_ONLINE_DIRECT_DEBIT_EXECUTION');

INSERT INTO RTS3_APP_DS_EVENT(id, name, app_ds_id, event_type_code, description)
VALUES(30083, 'OverseasCardActivation', 30002,'OverseasCardActivation', 'TIBCO JMS Events');

INSERT INTO RTS3_EVENT_ACTION(id,app_event_id,action_type_code,exec_order)
VALUES(30083,30083,'SAVE_MONGO',1);

INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name,param_value)
VALUES(30247,30083,'mongodb.uri','mongodb://eap_mongodb_uat:$PASSWORD@maas-gt-p72-m0002.nam.nsroot.net:37017,maas-sw-p72-m0001.nam.nsroot.net:37017,maas-mw-p72-m0001.nam.nsroot.net:37017/GCG_ASIA_MY?ssl=true&authSource=admin');
INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name,param_value)
VALUES(30248,30083,'mongodb.db.name','GCG_ASIA_MY');
INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name,param_value)
VALUES(30249,30083,'mongodb.collection.name','EAP_IVR_OVERSEAS_CARD_ACTIVATION');

INSERT INTO RTS3_APP_DS_EVENT(id, name, app_ds_id, event_type_code, description)
VALUES(30084, 'PaymentAndTransfer', 30002,'PaymentAndTransfer', 'TIBCO JMS Events');

INSERT INTO RTS3_EVENT_ACTION(id,app_event_id,action_type_code,exec_order)
VALUES(30084,30084,'SAVE_MONGO',1);

INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name,param_value)
VALUES(30250,30084,'mongodb.uri','mongodb://eap_mongodb_uat:$PASSWORD@maas-gt-p72-m0002.nam.nsroot.net:37017,maas-sw-p72-m0001.nam.nsroot.net:37017,maas-mw-p72-m0001.nam.nsroot.net:37017/GCG_ASIA_MY?ssl=true&authSource=admin');
INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name,param_value)
VALUES(30251,30084,'mongodb.db.name','GCG_ASIA_MY');
INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name,param_value)
VALUES(30252,30084,'mongodb.collection.name','EAP_IVR_PAYMENT_AND_TRANSFER');

INSERT INTO RTS3_APP_DS_EVENT(id, name, app_ds_id, event_type_code, description)
VALUES(30085, 'PINValidation', 30002,'PINValidation', 'TIBCO JMS Events');

INSERT INTO RTS3_EVENT_ACTION(id,app_event_id,action_type_code,exec_order)
VALUES(30085,30085,'SAVE_MONGO',1);

INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name,param_value)
VALUES(30253,30085,'mongodb.uri','mongodb://eap_mongodb_uat:$PASSWORD@maas-gt-p72-m0002.nam.nsroot.net:37017,maas-sw-p72-m0001.nam.nsroot.net:37017,maas-mw-p72-m0001.nam.nsroot.net:37017/GCG_ASIA_MY?ssl=true&authSource=admin');
INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name,param_value)
VALUES(30254,30085,'mongodb.db.name','GCG_ASIA_MY');
INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name,param_value)
VALUES(30255,30085,'mongodb.collection.name','EAP_IVR_PIN_VALIDATION');

INSERT INTO RTS3_APP_DS_EVENT(id, name, app_ds_id, event_type_code, description)
VALUES(30086, 'PreAuth', 30002,'PreAuth', 'TIBCO JMS Events');

INSERT INTO RTS3_EVENT_ACTION(id,app_event_id,action_type_code,exec_order)
VALUES(30086,30086,'SAVE_MONGO',1);

INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name,param_value)
VALUES(30256,30086,'mongodb.uri','mongodb://eap_mongodb_uat:$PASSWORD@maas-gt-p72-m0002.nam.nsroot.net:37017,maas-sw-p72-m0001.nam.nsroot.net:37017,maas-mw-p72-m0001.nam.nsroot.net:37017/GCG_ASIA_MY?ssl=true&authSource=admin');
INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name,param_value)
VALUES(30257,30086,'mongodb.db.name','GCG_ASIA_MY');
INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name,param_value)
VALUES(30258,30086,'mongodb.collection.name','EAP_IVR_PRE_AUTH');

INSERT INTO RTS3_APP_DS_EVENT(id, name, app_ds_id, event_type_code, description)
VALUES(30087, 'ReportLostStolen', 30002,'ReportLostStolen', 'TIBCO JMS Events');

INSERT INTO RTS3_EVENT_ACTION(id,app_event_id,action_type_code,exec_order)
VALUES(30087,30087,'SAVE_MONGO',1);

INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name,param_value)
VALUES(30259,30087,'mongodb.uri','mongodb://eap_mongodb_uat:$PASSWORD@maas-gt-p72-m0002.nam.nsroot.net:37017,maas-sw-p72-m0001.nam.nsroot.net:37017,maas-mw-p72-m0001.nam.nsroot.net:37017/GCG_ASIA_MY?ssl=true&authSource=admin');
INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name,param_value)
VALUES(30260,30087,'mongodb.db.name','GCG_ASIA_MY');
INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name,param_value)
VALUES(30261,30087,'mongodb.collection.name','EAP_IVR_REPORT_LOST_STOLEN');

INSERT INTO RTS3_APP_DS_EVENT(id, name, app_ds_id, event_type_code, description)
VALUES(30088, 'RewardRedemptionAccess', 30002,'RewardRedemptionAccess', 'TIBCO JMS Events');

INSERT INTO RTS3_EVENT_ACTION(id,app_event_id,action_type_code,exec_order)
VALUES(30088,30088,'SAVE_MONGO',1);

INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name,param_value)
VALUES(30262,30088,'mongodb.uri','mongodb://eap_mongodb_uat:$PASSWORD@maas-gt-p72-m0002.nam.nsroot.net:37017,maas-sw-p72-m0001.nam.nsroot.net:37017,maas-mw-p72-m0001.nam.nsroot.net:37017/GCG_ASIA_MY?ssl=true&authSource=admin');
INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name,param_value)
VALUES(30263,30088,'mongodb.db.name','GCG_ASIA_MY');
INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name,param_value)
VALUES(30264,30088,'mongodb.collection.name','EAP_IVR_REWARD_REDEMPTION_ACCESS');

INSERT INTO RTS3_APP_DS_EVENT(id, name, app_ds_id, event_type_code, description)
VALUES(30089, 'RewardRedemptionRequest', 30002,'RewardRedemptionRequest', 'TIBCO JMS Events');

INSERT INTO RTS3_EVENT_ACTION(id,app_event_id,action_type_code,exec_order)
VALUES(30089,30089,'SAVE_MONGO',1);

INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name,param_value)
VALUES(30265,30089,'mongodb.uri','mongodb://eap_mongodb_uat:$PASSWORD@maas-gt-p72-m0002.nam.nsroot.net:37017,maas-sw-p72-m0001.nam.nsroot.net:37017,maas-mw-p72-m0001.nam.nsroot.net:37017/GCG_ASIA_MY?ssl=true&authSource=admin');
INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name,param_value)
VALUES(30266,30089,'mongodb.db.name','GCG_ASIA_MY');
INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name,param_value)
VALUES(30267,30089,'mongodb.collection.name','EAP_IVR_REWARD_REDEMPTION_REQUEST');

INSERT INTO RTS3_APP_DS_EVENT(id, name, app_ds_id, event_type_code, description)
VALUES(30090, 'SDNMatchFound', 30002,'SDNMatchFound', 'TIBCO JMS Events');

INSERT INTO RTS3_EVENT_ACTION(id,app_event_id,action_type_code,exec_order)
VALUES(30090,30090,'SAVE_MONGO',1);

INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name,param_value)
VALUES(30268,30090,'mongodb.uri','mongodb://eap_mongodb_uat:$PASSWORD@maas-gt-p72-m0002.nam.nsroot.net:37017,maas-sw-p72-m0001.nam.nsroot.net:37017,maas-mw-p72-m0001.nam.nsroot.net:37017/GCG_ASIA_MY?ssl=true&authSource=admin');
INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name,param_value)
VALUES(30269,30090,'mongodb.db.name','GCG_ASIA_MY');
INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name,param_value)
VALUES(30270,30090,'mongodb.collection.name','EAP_IVR_SDN_MATCH_FOUND');

INSERT INTO RTS3_APP_DS_EVENT(id, name, app_ds_id, event_type_code, description)
VALUES(30091, 'SDNMatchResolved', 30002,'SDNMatchResolved', 'TIBCO JMS Events');

INSERT INTO RTS3_EVENT_ACTION(id,app_event_id,action_type_code,exec_order)
VALUES(30091,30091,'SAVE_MONGO',1);

INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name,param_value)
VALUES(30271,30091,'mongodb.uri','mongodb://eap_mongodb_uat:$PASSWORD@maas-gt-p72-m0002.nam.nsroot.net:37017,maas-sw-p72-m0001.nam.nsroot.net:37017,maas-mw-p72-m0001.nam.nsroot.net:37017/GCG_ASIA_MY?ssl=true&authSource=admin');
INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name,param_value)
VALUES(30272,30091,'mongodb.db.name','GCG_ASIA_MY');
INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name,param_value)
VALUES(30273,30091,'mongodb.collection.name','EAP_IVR_SDN_MATCH_RESOLVED');

INSERT INTO RTS3_APP_DS_EVENT(id, name, app_ds_id, event_type_code, description)
VALUES(30092, 'ServiceRequest', 30002,'ServiceRequest', 'TIBCO JMS Events');

INSERT INTO RTS3_EVENT_ACTION(id,app_event_id,action_type_code,exec_order)
VALUES(30092,30092,'SAVE_MONGO',1);

INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name,param_value)
VALUES(30274,30092,'mongodb.uri','mongodb://eap_mongodb_uat:$PASSWORD@maas-gt-p72-m0002.nam.nsroot.net:37017,maas-sw-p72-m0001.nam.nsroot.net:37017,maas-mw-p72-m0001.nam.nsroot.net:37017/GCG_ASIA_MY?ssl=true&authSource=admin');
INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name,param_value)
VALUES(30275,30092,'mongodb.db.name','GCG_ASIA_MY');
INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name,param_value)
VALUES(30276,30092,'mongodb.collection.name','EAP_IVR_SERVICE_REQUEST');

INSERT INTO RTS3_APP_DS_EVENT(id, name, app_ds_id, event_type_code, description)
VALUES(30093, 'SMSEmailOffers', 30002,'SMSEmailOffers', 'TIBCO JMS Events');

INSERT INTO RTS3_EVENT_ACTION(id,app_event_id,action_type_code,exec_order)
VALUES(30093,30093,'SAVE_MONGO',1);

INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name,param_value)
VALUES(30277,30093,'mongodb.uri','mongodb://eap_mongodb_uat:$PASSWORD@maas-gt-p72-m0002.nam.nsroot.net:37017,maas-sw-p72-m0001.nam.nsroot.net:37017,maas-mw-p72-m0001.nam.nsroot.net:37017/GCG_ASIA_MY?ssl=true&authSource=admin');
INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name,param_value)
VALUES(30278,30093,'mongodb.db.name','GCG_ASIA_MY');
INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name,param_value)
VALUES(30279,30093,'mongodb.collection.name','EAP_IVR_SMS_EMAIL_OFFERS');

INSERT INTO RTS3_APP_DS_EVENT(id, name, app_ds_id, event_type_code, description)
VALUES(30094, 'TPINCreateResetChangeIssuance', 30002,'TPINCreateResetChangeIssuance', 'TIBCO JMS Events');

INSERT INTO RTS3_EVENT_ACTION(id,app_event_id,action_type_code,exec_order)
VALUES(30094,30094,'SAVE_MONGO',1);

INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name,param_value)
VALUES(30280,30094,'mongodb.uri','mongodb://eap_mongodb_uat:$PASSWORD@maas-gt-p72-m0002.nam.nsroot.net:37017,maas-sw-p72-m0001.nam.nsroot.net:37017,maas-mw-p72-m0001.nam.nsroot.net:37017/GCG_ASIA_MY?ssl=true&authSource=admin');
INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name,param_value)
VALUES(30281,30094,'mongodb.db.name','GCG_ASIA_MY');
INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name,param_value)
VALUES(30282,30094,'mongodb.collection.name','EAP_IVR_TPIN_CREATE_RESET_CHANGE_ISSUANCE');

INSERT INTO RTS3_APP_DS_EVENT(id, name, app_ds_id, event_type_code, description)
VALUES(30095, 'ViewTransactionsHistory', 30002,'ViewTransactionsHistory', 'TIBCO JMS Events');

INSERT INTO RTS3_EVENT_ACTION(id,app_event_id,action_type_code,exec_order)
VALUES(30095,30095,'SAVE_MONGO',1);

INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name,param_value)
VALUES(30283,30095,'mongodb.uri','mongodb://eap_mongodb_uat:$PASSWORD@maas-gt-p72-m0002.nam.nsroot.net:37017,maas-sw-p72-m0001.nam.nsroot.net:37017,maas-mw-p72-m0001.nam.nsroot.net:37017/GCG_ASIA_MY?ssl=true&authSource=admin');
INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name,param_value)
VALUES(30284,30095,'mongodb.db.name','GCG_ASIA_MY');
INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name,param_value)
VALUES(30285,30095,'mongodb.collection.name','EAP_IVR_VIEW_TRANSACTIONS_HISTORY');


INSERT INTO RTS3_APP_DS_EVENT(id, name, app_ds_id, event_type_code, description)
VALUES(30096, 'CollectionsAlert', 30002,'CollectionsAlert', 'TIBCO JMS Events');

INSERT INTO RTS3_EVENT_ACTION(id,app_event_id,action_type_code,exec_order)
VALUES(30096,30096,'SAVE_MONGO',1);

INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name,param_value)
VALUES(30286,30096,'mongodb.uri','mongodb://eap_mongodb_uat:$PASSWORD@maas-gt-p72-m0002.nam.nsroot.net:37017,maas-sw-p72-m0001.nam.nsroot.net:37017,maas-mw-p72-m0001.nam.nsroot.net:37017/GCG_ASIA_MY?ssl=true&authSource=admin');
INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name,param_value)
VALUES(30287,30096,'mongodb.db.name','GCG_ASIA_MY');
INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name,param_value)
VALUES(30288,30096,'mongodb.collection.name','EAP_IVR_DWH_EVENT_SCHEMA');

INSERT INTO RTS3_APP_DS_EVENT(id, name, app_ds_id, event_type_code, description)
VALUES(30097, 'AnnualFeeCharged', 30002,'AnnualFeeCharged', 'TIBCO JMS Events');

INSERT INTO RTS3_EVENT_ACTION(id,app_event_id,action_type_code,exec_order)
VALUES(30097,30097,'SAVE_MONGO',1);

INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name,param_value)
VALUES(30289,30097,'mongodb.uri','mongodb://eap_mongodb_uat:$PASSWORD@maas-gt-p72-m0002.nam.nsroot.net:37017,maas-sw-p72-m0001.nam.nsroot.net:37017,maas-mw-p72-m0001.nam.nsroot.net:37017/GCG_ASIA_MY?ssl=true&authSource=admin');
INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name,param_value)
VALUES(30290,30097,'mongodb.db.name','GCG_ASIA_MY');
INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name,param_value)
VALUES(30291,30097,'mongodb.collection.name','EAP_IVR_DWH_EVENT_SCHEMA');

INSERT INTO RTS3_APP_DS_EVENT(id, name, app_ds_id, event_type_code, description)
VALUES(30098, 'DirectDebit', 30002,'DirectDebit', 'TIBCO JMS Events');

INSERT INTO RTS3_EVENT_ACTION(id,app_event_id,action_type_code,exec_order)
VALUES(30098,30098,'SAVE_MONGO',1);

INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name,param_value)
VALUES(30292,30098,'mongodb.uri','mongodb://eap_mongodb_uat:$PASSWORD@maas-gt-p72-m0002.nam.nsroot.net:37017,maas-sw-p72-m0001.nam.nsroot.net:37017,maas-mw-p72-m0001.nam.nsroot.net:37017/GCG_ASIA_MY?ssl=true&authSource=admin');
INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name,param_value)
VALUES(30293,30098,'mongodb.db.name','GCG_ASIA_MY');
INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name,param_value)
VALUES(30294,30098,'mongodb.collection.name','EAP_IVR_DWH_EVENT_SCHEMA');

INSERT INTO RTS3_APP_DS_EVENT(id, name, app_ds_id, event_type_code, description)
VALUES(30099, 'StandingInstructionExecution', 30002,'StandingInstructionExecution', 'TIBCO JMS Events');

INSERT INTO RTS3_EVENT_ACTION(id,app_event_id,action_type_code,exec_order)
VALUES(30099,30099,'SAVE_MONGO',1);

INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name,param_value)
VALUES(30295,30099,'mongodb.uri','mongodb://eap_mongodb_uat:$PASSWORD@maas-gt-p72-m0002.nam.nsroot.net:37017,maas-sw-p72-m0001.nam.nsroot.net:37017,maas-mw-p72-m0001.nam.nsroot.net:37017/GCG_ASIA_MY?ssl=true&authSource=admin');
INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name,param_value)
VALUES(30296,30099,'mongodb.db.name','GCG_ASIA_MY');
INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name,param_value)
VALUES(30297,30099,'mongodb.collection.name','EAP_IVR_DWH_EVENT_SCHEMA');

INSERT INTO RTS3_APP_DS_EVENT(id, name, app_ds_id, event_type_code, description)
VALUES(30100, 'Cardissuance', 30002,'Cardissuance', 'TIBCO JMS Events');

INSERT INTO RTS3_EVENT_ACTION(id,app_event_id,action_type_code,exec_order)
VALUES(30100,30100,'SAVE_MONGO',1);

INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name,param_value)
VALUES(30298,30100,'mongodb.uri','mongodb://eap_mongodb_uat:$PASSWORD@maas-gt-p72-m0002.nam.nsroot.net:37017,maas-sw-p72-m0001.nam.nsroot.net:37017,maas-mw-p72-m0001.nam.nsroot.net:37017/GCG_ASIA_MY?ssl=true&authSource=admin');
INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name,param_value)
VALUES(30299,30100,'mongodb.db.name','GCG_ASIA_MY');
INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name,param_value)
VALUES(30300,30100,'mongodb.collection.name','EAP_IVR_DWH_EVENT_SCHEMA');

INSERT INTO RTS3_APP_DS_EVENT(id, name, app_ds_id, event_type_code, description)
VALUES(30101, 'StatementGeneration', 30002,'StatementGeneration', 'TIBCO JMS Events');

INSERT INTO RTS3_EVENT_ACTION(id,app_event_id,action_type_code,exec_order)
VALUES(30101,30101,'SAVE_MONGO',1);

INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name,param_value)
VALUES(30301,30101,'mongodb.uri','mongodb://eap_mongodb_uat:$PASSWORD@maas-gt-p72-m0002.nam.nsroot.net:37017,maas-sw-p72-m0001.nam.nsroot.net:37017,maas-mw-p72-m0001.nam.nsroot.net:37017/GCG_ASIA_MY?ssl=true&authSource=admin');
INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name,param_value)
VALUES(30302,30101,'mongodb.db.name','GCG_ASIA_MY');
INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name,param_value)
VALUES(30303,30101,'mongodb.collection.name','EAP_IVR_DWH_EVENT_SCHEMA');

INSERT INTO RTS3_APP_DS_EVENT(id, name, app_ds_id, event_type_code, description)
VALUES(30102, 'LateFinanceCharge', 30002,'LateFinanceCharge', 'TIBCO JMS Events');

INSERT INTO RTS3_EVENT_ACTION(id,app_event_id,action_type_code,exec_order)
VALUES(30102,30102,'SAVE_MONGO',1);

INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name,param_value)
VALUES(30304,30102,'mongodb.uri','mongodb://eap_mongodb_uat:$PASSWORD@maas-gt-p72-m0002.nam.nsroot.net:37017,maas-sw-p72-m0001.nam.nsroot.net:37017,maas-mw-p72-m0001.nam.nsroot.net:37017/GCG_ASIA_MY?ssl=true&authSource=admin');
INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name,param_value)
VALUES(30305,30102,'mongodb.db.name','GCG_ASIA_MY');
INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name,param_value)
VALUES(30306,30102,'mongodb.collection.name','EAP_IVR_DWH_EVENT_SCHEMA');

INSERT INTO RTS3_APP_DS_EVENT(id, name, app_ds_id, event_type_code, description)
VALUES(30103, 'MinimunBalanceBankcharge', 30002,'MinimunBalanceBankcharge', 'TIBCO JMS Events');

INSERT INTO RTS3_EVENT_ACTION(id,app_event_id,action_type_code,exec_order)
VALUES(30103,30103,'SAVE_MONGO',1);

INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name,param_value)
VALUES(30307,30103,'mongodb.uri','mongodb://eap_mongodb_uat:$PASSWORD@maas-gt-p72-m0002.nam.nsroot.net:37017,maas-sw-p72-m0001.nam.nsroot.net:37017,maas-mw-p72-m0001.nam.nsroot.net:37017/GCG_ASIA_MY?ssl=true&authSource=admin');
INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name,param_value)
VALUES(30308,30103,'mongodb.db.name','GCG_ASIA_MY');
INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name,param_value)
VALUES(30309,30103,'mongodb.collection.name','EAP_IVR_DWH_EVENT_SCHEMA');

INSERT INTO RTS3_APP_DS_EVENT(id, name, app_ds_id, event_type_code, description)
VALUES(30104, 'PreEmbossCardIssued', 30002,'PreEmbossCardIssued', 'TIBCO JMS Events');

INSERT INTO RTS3_EVENT_ACTION(id,app_event_id,action_type_code,exec_order)
VALUES(30104,30104,'SAVE_MONGO',1);

INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name,param_value)
VALUES(30310,30104,'mongodb.uri','mongodb://eap_mongodb_uat:$PASSWORD@maas-gt-p72-m0002.nam.nsroot.net:37017,maas-sw-p72-m0001.nam.nsroot.net:37017,maas-mw-p72-m0001.nam.nsroot.net:37017/GCG_ASIA_MY?ssl=true&authSource=admin');
INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name,param_value)
VALUES(30311,30104,'mongodb.db.name','GCG_ASIA_MY');
INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name,param_value)
VALUES(30312,30104,'mongodb.collection.name','EAP_IVR_DWH_EVENT_SCHEMA');

INSERT INTO RTS3_APP_DS_EVENT(id, name, app_ds_id, event_type_code, description)
VALUES(30105, 'BankAccountStatusChange', 30002,'BankAccountStatusChange', 'TIBCO JMS Events');

INSERT INTO RTS3_EVENT_ACTION(id,app_event_id,action_type_code,exec_order)
VALUES(30105,30105,'SAVE_MONGO',1);

INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name,param_value)
VALUES(30313,30105,'mongodb.uri','mongodb://eap_mongodb_uat:$PASSWORD@maas-gt-p72-m0002.nam.nsroot.net:37017,maas-sw-p72-m0001.nam.nsroot.net:37017,maas-mw-p72-m0001.nam.nsroot.net:37017/GCG_ASIA_MY?ssl=true&authSource=admin');
INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name,param_value)
VALUES(30314,30105,'mongodb.db.name','GCG_ASIA_MY');
INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name,param_value)
VALUES(30315,30105,'mongodb.collection.name','EAP_IVR_DWH_EVENT_SCHEMA');

INSERT INTO RTS3_APP_DS_EVENT(id, name, app_ds_id, event_type_code, description)
VALUES(30106, 'CustomerWhereAbout', 30002,'CustomerWhereAbout', 'TIBCO JMS Events');

INSERT INTO RTS3_EVENT_ACTION(id,app_event_id,action_type_code,exec_order)
VALUES(30106,30106,'SAVE_MONGO',1);

INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name,param_value)
VALUES(30316,30106,'mongodb.uri','mongodb://eap_mongodb_uat:$PASSWORD@maas-gt-p72-m0002.nam.nsroot.net:37017,maas-sw-p72-m0001.nam.nsroot.net:37017,maas-mw-p72-m0001.nam.nsroot.net:37017/GCG_ASIA_MY?ssl=true&authSource=admin');
INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name,param_value)
VALUES(30317,30106,'mongodb.db.name','GCG_ASIA_MY');
INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name,param_value)
VALUES(30318,30106,'mongodb.collection.name','EAP_IVR_DWH_EVENT_SCHEMA');

INSERT INTO RTS3_APP_DS_EVENT(id, name, app_ds_id, event_type_code, description)
VALUES(30107, 'TDRollOver', 30002,'TDRollOver', 'TIBCO JMS Events');

INSERT INTO RTS3_EVENT_ACTION(id,app_event_id,action_type_code,exec_order)
VALUES(30107,30107,'SAVE_MONGO',1);

INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name,param_value)
VALUES(30319,30107,'mongodb.uri','mongodb://eap_mongodb_uat:$PASSWORD@maas-gt-p72-m0002.nam.nsroot.net:37017,maas-sw-p72-m0001.nam.nsroot.net:37017,maas-mw-p72-m0001.nam.nsroot.net:37017/GCG_ASIA_MY?ssl=true&authSource=admin');
INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name,param_value)
VALUES(30320,30107,'mongodb.db.name','GCG_ASIA_MY');
INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name,param_value)
VALUES(30321,30107,'mongodb.collection.name','EAP_IVR_DWH_EVENT_SCHEMA');

INSERT INTO RTS3_APP_DS_EVENT(id, name, app_ds_id, event_type_code, description)
VALUES(30108, 'CallFeedback', 30002,'CallFeedback', 'TIBCO JMS Events');

INSERT INTO RTS3_EVENT_ACTION(id,app_event_id,action_type_code,exec_order)
VALUES(30108,30108,'SAVE_MONGO',1);

INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name,param_value)
VALUES(30322,30108,'mongodb.uri','mongodb://eap_mongodb_uat:$PASSWORD@maas-gt-p72-m0002.nam.nsroot.net:37017,maas-sw-p72-m0001.nam.nsroot.net:37017,maas-mw-p72-m0001.nam.nsroot.net:37017/GCG_ASIA_MY?ssl=true&authSource=admin');
INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name,param_value)
VALUES(30323,30108,'mongodb.db.name','GCG_ASIA_MY');
INSERT INTO RTS3_EVENT_ACTION_DETAIL(id,event_action_id,param_name,param_value)
VALUES(30324,30108,'mongodb.collection.name','MONGO_IVR_AGNT_FEED_RSN_TXN_D');