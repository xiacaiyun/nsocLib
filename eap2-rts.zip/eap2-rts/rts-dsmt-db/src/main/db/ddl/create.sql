----------------------------------------------------------
-------------------[ Master/Code tables ]-----------------
----------------------------------------------------------
CREATE TABLE rts3_yesno_type (
       code VARCHAR(1) NOT NULL,
       name VARCHAR(20) NOT NULL,
       PRIMARY KEY(code)
);

CREATE TABLE rts3_param_type (
       code VARCHAR(20) NOT NULL,
       name VARCHAR(80) NOT NULL,
       PRIMARY KEY(code)
);

CREATE TABLE rts3_event_type (
       code VARCHAR(40) NOT NULL,
       name VARCHAR(80) NOT NULL,
       PRIMARY KEY(code)
);

CREATE TABLE rts3_datasource_type (
       code VARCHAR(20) NOT NULL,
       name VARCHAR(80) NOT NULL,
       PRIMARY KEY(code)
);

CREATE TABLE rts3_ds_param_type (
       code VARCHAR(80) NOT NULL,
       name VARCHAR(80) NOT NULL,
       datasource_type_code VARCHAR(20) NOT NULL,
       PRIMARY KEY(code),
       FOREIGN KEY(datasource_type_code) REFERENCES rts3_datasource_type(code)
);

CREATE TABLE rts3_param_master (
       name VARCHAR(200) NOT NULL,
       param_type_code VARCHAR(20) NOT NULL,
       PRIMARY KEY(name),
       FOREIGN KEY (param_type_code) REFERENCES rts3_param_type(code)
);

CREATE TABLE rts3_action_type (
       code VARCHAR(20) NOT NULL,
       name VARCHAR(80) NOT NULL,
       PRIMARY KEY(code)
);

----------------------------------------------------------
-------------------[ Transactional tables ]---------------
----------------------------------------------------------
CREATE TABLE rts3_mst_tenant (
	id INTEGER NOT NULL,
	name VARCHAR(80) NOT NULL,
	PRIMARY KEY(id)
);

CREATE TABLE rts3_tenant_param (
	id INTEGER NOT NULL,
    tenant_id INTEGER NOT NULL,
    param_type_code VARCHAR(20) NOT NULL,
    param_name VARCHAR(200) NOT NULL,
    param_value VARCHAR(2000) DEFAULT NULL,
    PRIMARY KEY(id),
    FOREIGN KEY (param_type_code) REFERENCES rts3_param_type(code),
    FOREIGN KEY (tenant_id) REFERENCES rts3_mst_tenant(id),
    FOREIGN KEY (param_name) REFERENCES rts3_param_master(name)
);

CREATE TABLE rts3_application (
       id INTEGER NOT NULL,
       name VARCHAR(80) NOT NULL,
       tenant_id INTEGER NOT NULL,
       description VARCHAR(400) DEFAULT NULL,
       void_ind VARCHAR(1) DEFAULT 'N',
       PRIMARY KEY(id),
       UNIQUE(name),
       FOREIGN KEY(tenant_id) REFERENCES rts3_mst_tenant(id),
       FOREIGN KEY(void_ind) REFERENCES rts3_yesno_type(code)
);

CREATE TABLE rts3_app_param (
       id INTEGER NOT NULL,
       param_type_code VARCHAR(20) NOT NULL,
       app_id INTEGER NOT NULL,
       param_name VARCHAR(200) NOT NULL,
       param_value VARCHAR(2000) DEFAULT NULL,
       description VARCHAR(200) DEFAULT NULL,
       PRIMARY KEY(id),
       FOREIGN KEY (param_type_code) REFERENCES rts3_param_type (code),
       FOREIGN KEY (app_id) REFERENCES rts3_application (id),
       FOREIGN KEY (param_name) REFERENCES rts3_param_master(name)
);

CREATE TABLE rts3_app_ds (
       id INTEGER NOT NULL,
       name VARCHAR(80) NOT NULL,
       app_id INTEGER NOT NULL,
       ds_type_code VARCHAR(20) NOT NULL,
       description VARCHAR(20) NOT NULL,
       default_event VARCHAR(40),
       PRIMARY KEY(id),
       UNIQUE(app_id, name),
       FOREIGN KEY (app_id) REFERENCES rts3_application(id),
       FOREIGN KEY (ds_type_code) REFERENCES rts3_datasource_type(code)
);

CREATE TABLE rts3_app_ds_detail (
       id INTEGER NOT NULL,
       app_ds_id INTEGER NOT NULL,  
       param_name VARCHAR(80) NOT NULL,
       param_value VARCHAR(400) DEFAULT NULL,
       value_encrypted VARCHAR(10) DEFAULT 'N',
       PRIMARY KEY(id),
       UNIQUE (app_ds_id, param_name),
       FOREIGN KEY (app_ds_id) REFERENCES rts3_app_ds(id),
       FOREIGN KEY (param_name) REFERENCES rts3_ds_param_type(code)
);

CREATE TABLE rts3_app_ds_event (
       id INTEGER NOT NULL,
       name VARCHAR(80) NOT NULL,
       app_ds_id INTEGER NOT NULL,
       event_type_code VARCHAR(40) NOT NULL,
       description VARCHAR(20) NOT NULL,
       PRIMARY KEY(id),
       UNIQUE(app_ds_id, name),
       FOREIGN KEY (app_ds_id) REFERENCES rts3_app_ds(id),
       FOREIGN KEY (event_type_code) REFERENCES rts3_event_type(code)
);


CREATE TABLE rts3_event_action (
       id INTEGER NOT NULL,
       app_event_id INTEGER NOT NULL,  
       action_type_code VARCHAR(20) NOT NULL,
       exec_order INTEGER NOT NULL,
       PRIMARY KEY(id),
       UNIQUE (app_event_id, exec_order),
       FOREIGN KEY (app_event_id) REFERENCES rts3_app_ds_event(id),
       FOREIGN KEY (action_type_code) REFERENCES rts3_action_type(code)
);

CREATE TABLE rts3_event_action_detail (
       id INTEGER NOT NULL,
       event_action_id INTEGER NOT NULL,  
       param_name VARCHAR(80) NOT NULL,
       param_value VARCHAR(400),
       value_encrypted VARCHAR(10) DEFAULT 'N',
       PRIMARY KEY(id),
       UNIQUE (event_action_id, param_name),
       FOREIGN KEY (event_action_id) REFERENCES rts3_event_action(id)
);

CREATE TABLE rts3_job_status_type (
	code VARCHAR(20) NOT NULL,
	status VARCHAR(20) NOT NULL,
	PRIMARY KEY(code)
);

CREATE TABLE rts3_job_status (
	code VARCHAR(20) NOT NULL,
	app_id INTEGER NOT NULL,
	job_id VARCHAR(20) NOT NULL,
	start_dt VARCHAR(20) NOT NULL,
	end_dt VARCHAR(20) NOT NULL,
	job_status_type_code VARCHAR(20) NOT NULL,
	job_url VARCHAR(400) DEFAULT NULL,
	job_log VARCHAR(2000) DEFAULT NULL,
	PRIMARY KEY(code),
	FOREIGN KEY (job_status_type_code) REFERENCES rts3_job_status_type (code)
);

CREATE TABLE rts3_uat1_yesno_type (
       code VARCHAR(1) NOT NULL,
       name VARCHAR(20) NOT NULL,
       PRIMARY KEY(code)
);

CREATE TABLE rts3_uat1_param_type (
       code VARCHAR(20) NOT NULL,
       name VARCHAR(80) NOT NULL,
       PRIMARY KEY(code)
);

CREATE TABLE rts3_uat1_event_type (
       code VARCHAR(40) NOT NULL,
       name VARCHAR(80) NOT NULL,
       PRIMARY KEY(code)
);

CREATE TABLE rts3_uat1_datasource_type (
       code VARCHAR(20) NOT NULL,
       name VARCHAR(80) NOT NULL,
       PRIMARY KEY(code)
);

CREATE TABLE rts3_uat1_ds_param_type (
       code VARCHAR(80) NOT NULL,
       name VARCHAR(80) NOT NULL,
       datasource_type_code VARCHAR(20) NOT NULL,
       PRIMARY KEY(code),
       FOREIGN KEY(datasource_type_code) REFERENCES rts3_uat1_datasource_type(code)
);

CREATE TABLE rts3_uat1_param_master (
       name VARCHAR(200) NOT NULL,
       param_type_code VARCHAR(20) NOT NULL,
       PRIMARY KEY(name),
       FOREIGN KEY (param_type_code) REFERENCES rts3_uat1_param_type(code)
);

CREATE TABLE rts3_uat1_action_type (
       code VARCHAR(20) NOT NULL,
       name VARCHAR(80) NOT NULL,
       PRIMARY KEY(code)
);

----------------------------------------------------------
-------------------[ Transactional tables ]---------------
----------------------------------------------------------
CREATE TABLE rts3_uat1_mst_tenant (
	id INTEGER NOT NULL,
	name VARCHAR(80) NOT NULL,
	PRIMARY KEY(id)
);

CREATE TABLE rts3_uat1_tenant_param (
	id INTEGER NOT NULL,
    tenant_id INTEGER NOT NULL,
    param_type_code VARCHAR(20) NOT NULL,
    param_name VARCHAR(200) NOT NULL,
    param_value VARCHAR(2000) DEFAULT NULL,
    PRIMARY KEY(id),
    FOREIGN KEY (param_type_code) REFERENCES rts3_uat1_param_type(code),
    FOREIGN KEY (tenant_id) REFERENCES rts3_uat1_mst_tenant(id),
    FOREIGN KEY (param_name) REFERENCES rts3_uat1_param_master(name)
);

CREATE TABLE rts3_uat1_application (
       id INTEGER NOT NULL,
       name VARCHAR(80) NOT NULL,
       tenant_id INTEGER NOT NULL,
       description VARCHAR(400) DEFAULT NULL,
       void_ind VARCHAR(1) DEFAULT 'N',
       PRIMARY KEY(id),
       UNIQUE(name),
       FOREIGN KEY(tenant_id) REFERENCES rts3_uat1_mst_tenant(id),
       FOREIGN KEY(void_ind) REFERENCES rts3_uat1_yesno_type(code)
);

CREATE TABLE rts3_uat1_app_param (
       id INTEGER NOT NULL,
       param_type_code VARCHAR(20) NOT NULL,
       app_id INTEGER NOT NULL,
       param_name VARCHAR(200) NOT NULL,
       param_value VARCHAR(2000) DEFAULT NULL,
       description VARCHAR(200) DEFAULT NULL,
       PRIMARY KEY(id),
       FOREIGN KEY (param_type_code) REFERENCES rts3_uat1_param_type (code),
       FOREIGN KEY (app_id) REFERENCES rts3_uat1_application (id),
       FOREIGN KEY (param_name) REFERENCES rts3_uat1_param_master(name)
);

CREATE TABLE rts3_uat1_app_ds (
       id INTEGER NOT NULL,
       name VARCHAR(80) NOT NULL,
       app_id INTEGER NOT NULL,
       ds_type_code VARCHAR(20) NOT NULL,
       description VARCHAR(20) NOT NULL,
       default_event VARCHAR(40),
       PRIMARY KEY(id),
       UNIQUE(app_id, name),
       FOREIGN KEY (app_id) REFERENCES rts3_uat1_application(id),
       FOREIGN KEY (ds_type_code) REFERENCES rts3_uat1_datasource_type(code)
);

CREATE TABLE rts3_uat1_app_ds_detail (
       id INTEGER NOT NULL,
       app_ds_id INTEGER NOT NULL,  
       param_name VARCHAR(80) NOT NULL,
       param_value VARCHAR(400) DEFAULT NULL,
       value_encrypted VARCHAR(10) DEFAULT 'N',
       PRIMARY KEY(id),
       UNIQUE (app_ds_id, param_name),
       FOREIGN KEY (app_ds_id) REFERENCES rts3_uat1_app_ds(id),
       FOREIGN KEY (param_name) REFERENCES rts3_uat1_ds_param_type(code)
);

CREATE TABLE rts3_uat1_app_ds_event (
       id INTEGER NOT NULL,
       name VARCHAR(80) NOT NULL,
       app_ds_id INTEGER NOT NULL,
       event_type_code VARCHAR(40) NOT NULL,
       description VARCHAR(20) NOT NULL,
       PRIMARY KEY(id),
       UNIQUE(app_ds_id, name),
       FOREIGN KEY (app_ds_id) REFERENCES rts3_uat1_app_ds(id),
       FOREIGN KEY (event_type_code) REFERENCES rts3_uat1_event_type(code)
);


CREATE TABLE rts3_uat1_event_action (
       id INTEGER NOT NULL,
       app_event_id INTEGER NOT NULL,  
       action_type_code VARCHAR(20) NOT NULL,
       exec_order INTEGER NOT NULL,
       PRIMARY KEY(id),
       UNIQUE (app_event_id, exec_order),
       FOREIGN KEY (app_event_id) REFERENCES rts3_uat1_app_ds_event(id),
       FOREIGN KEY (action_type_code) REFERENCES rts3_uat1_action_type(code)
);

CREATE TABLE rts3_uat1_event_action_detail (
       id INTEGER NOT NULL,
       event_action_id INTEGER NOT NULL,  
       param_name VARCHAR(80) NOT NULL,
       param_value VARCHAR(400),
       value_encrypted VARCHAR(10) DEFAULT 'N',
       PRIMARY KEY(id),
       UNIQUE (event_action_id, param_name),
       FOREIGN KEY (event_action_id) REFERENCES rts3_uat1_event_action(id)
);

CREATE TABLE rts3_uat1_job_status_type (
	code VARCHAR(20) NOT NULL,
	status VARCHAR(20) NOT NULL,
	PRIMARY KEY(code)
);

CREATE TABLE rts3_uat1_job_status (
	code VARCHAR(20) NOT NULL,
	app_id INTEGER NOT NULL,
	job_id VARCHAR(20) NOT NULL,
	start_dt VARCHAR(20) NOT NULL,
	end_dt VARCHAR(20) NOT NULL,
	job_status_type_code VARCHAR(20) NOT NULL,
	job_url VARCHAR(400) DEFAULT NULL,
	job_log VARCHAR(2000) DEFAULT NULL,
	PRIMARY KEY(code),
	FOREIGN KEY (job_status_type_code) REFERENCES rts3_uat1_job_status_type (code)
);
