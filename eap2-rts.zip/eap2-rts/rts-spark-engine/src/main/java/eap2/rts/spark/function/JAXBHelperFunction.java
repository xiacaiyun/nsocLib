package eap2.rts.spark.function;

import java.io.StringReader;
import java.io.StringWriter;
import java.net.URISyntaxException;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Marshaller;
import javax.xml.bind.Unmarshaller;
import javax.xml.validation.Schema;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.citi.api._private.v1.sales.customers.offers.fulfillments.senttoeap.UpdateOfferFullfillmentEapRequest;
import com.tibco.schemas.cop_elib.sharedresources.schemas.eventschema.epp.copeaprequest.COPEAPRequest;
import com.tibco.schemas.cop_elib.sharedresources.schemas.eventschema.epp.copeapresponse.COPEAPResponse;
import com.tibco.schemas.copsrainbow.sharedresources.schemas.eventschema.eapmodeloffer.EAPModelOffer;
import com.tibco.schemas.copsrainbow.sharedresources.schemas.eventschema.eapprodoffer.EAPProdOfferTemplate;
//import com.tibco.schemas.copsrainbow.sharedresources.schemas.eventschema.eaptrttemp.EAPTreatmentTemplate;
import com.tibco.schemas.copsrainbow.sharedresources.schemas.eventschema.mretransaction.TransactionMREReq;
import com.tibco.schemas.copsrainbow.sharedresources.schemas.eventschema.mretransaction.TransactionMRERes;
import com.tibco.schemas.cop_elib.sharedresources.schemas.eventschema.epp.eaptreatmenttemplate.EAPTreatmentTemplate;

import eap2.rts.spark.AppConstants;

/**
 * Helper class to parse XML using JaxB
 * 
 * @author sd79271
 */
public class JAXBHelperFunction {

	protected static Logger logger = LoggerFactory.getLogger(JAXBHelperFunction.class);

	private static Schema schema = null;

	public JAXBHelperFunction() {

	}

	public static String marshal(Object responseObj , String eventType) throws JAXBException, URISyntaxException {

		JAXBContext context;
		if (eventType.startsWith(AppConstants.CB_MRE)) {
			context = JAXBContext.newInstance(TransactionMRERes.class);
		}else if (eventType.startsWith(AppConstants.EPP)) {
			context = JAXBContext.newInstance(COPEAPResponse.class);
		}else{
			context=null;		
		}
		Marshaller m = context.createMarshaller();
		m.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, Boolean.TRUE);
		StringWriter sw = new StringWriter();
		m.marshal(responseObj, sw);
		String xmlString = sw.toString();
		return xmlString;

	}

	

	public static Object unmarshalRequestMessage(String eventType, String requestMessage) throws JAXBException {
		
		JAXBContext context;
		if (eventType.startsWith(AppConstants.CB_MRE)) {
			context = JAXBContext.newInstance(TransactionMREReq.class);
		}else if (eventType.startsWith(AppConstants.EPP)) {
			context = JAXBContext.newInstance(COPEAPRequest.class);
		}
		else if (eventType.startsWith(AppConstants.EPP_MOD)) {
			context = JAXBContext.newInstance(EAPModelOffer.class);
		}else if (eventType.startsWith(AppConstants.EPP_PROD)) {
			context = JAXBContext.newInstance(EAPProdOfferTemplate.class);
		}else if (eventType.startsWith(AppConstants.EPP_TRT)) {
			context = JAXBContext.newInstance(EAPTreatmentTemplate.class);
		}else if (eventType.startsWith(AppConstants.EPP_UOF)) {
			context = JAXBContext.newInstance(UpdateOfferFullfillmentEapRequest.class);
		}
		else{
			context=null;		}
		Unmarshaller unmarshaller = context.createUnmarshaller();
		Object obj = unmarshaller.unmarshal(new StringReader(requestMessage));
		return obj;
	}
}
