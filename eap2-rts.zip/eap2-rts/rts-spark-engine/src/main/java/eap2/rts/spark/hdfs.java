package eap2.rts.spark;

import java.io.IOException;
import java.util.Date;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.FileStatus;
import org.apache.hadoop.fs.FileSystem;
import org.apache.hadoop.fs.FileUtil;
import org.apache.hadoop.fs.Path;
/**
 * @author amalgjose
 *
 */
public class hdfs {
public static void main(String[] args) throws IOException {
         
        Configuration conf =new Configuration();
        conf.set("HDFS_ROOT_URL", "hdfs://gftsdev");
		conf.addResource(new Path("conf/core-site.xml"));
        conf.addResource(new Path("conf/mapred-site.xml"));
        conf.addResource(new Path("conf/hdfs=site.xml"));
        FileSystem fs = FileSystem.get(conf);
        Path sourcePath = new Path("/tmp/rts/python");
        Path destPath = new Path("/tmp/");
        if(!(fs.exists(sourcePath)))
        {
            System.out.println("No Such Source exists :"+sourcePath);
            return;
        }
         
        fs.copyToLocalFile(sourcePath, destPath);
         
    }


}


