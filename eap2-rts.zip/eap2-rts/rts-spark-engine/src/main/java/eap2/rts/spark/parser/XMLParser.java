/**
 * 
 */
package eap2.rts.spark.parser;

import java.io.IOException;

import javax.xml.bind.JAXBException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.citi.api._private.v1.sales.customers.offers.fulfillments.senttoeap.UpdateOfferFullfillmentEapRequest;
import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.tibco.schemas.cop_elib.sharedresources.schemas.eventschema.epp.copeaprequest.COPEAPRequest;
import com.tibco.schemas.copsrainbow.sharedresources.schemas.eventschema.eapmodeloffer.EAPModelOffer;
import com.tibco.schemas.copsrainbow.sharedresources.schemas.eventschema.eapprodoffer.EAPProdOfferTemplate;
//import com.tibco.schemas.copsrainbow.sharedresources.schemas.eventschema.eaptrttemp.EAPTreatmentTemplate;
import com.tibco.schemas.copsrainbow.sharedresources.schemas.eventschema.mretransaction.TransactionMREReq;
import com.tibco.schemas.cop_elib.sharedresources.schemas.eventschema.epp.eaptreatmenttemplate.EAPTreatmentTemplate;
import eap2.rts.spark.AppConstants;
import eap2.rts.spark.function.JAXBHelperFunction;

/**
 * @author as35686
 *
 */
public class XMLParser implements MessageParser {
	protected Logger logger = LoggerFactory.getLogger(XMLParser.class);

	public Object parse(String xmlString, String eventType)
			throws JsonParseException, JsonMappingException, IOException, JAXBException {
		
		
		if (eventType.contains(AppConstants.CB_MRE)) {
			TransactionMREReq transactionMREReq = (TransactionMREReq) JAXBHelperFunction
					.unmarshalRequestMessage(eventType, xmlString);
			
			return transactionMREReq;
		}if (eventType.contains(AppConstants.EPP)) {
			COPEAPRequest copeapRequest = (COPEAPRequest) JAXBHelperFunction
					.unmarshalRequestMessage(eventType, xmlString);
			
			return copeapRequest;
		}if (eventType.equals(AppConstants.EPP_MOD)) {
			EAPModelOffer eAPModelOffer = (EAPModelOffer) JAXBHelperFunction
					.unmarshalRequestMessage(eventType, xmlString);
			
			return eAPModelOffer;
		}
		if (eventType.equals(AppConstants.EPP_PROD)) {
			EAPProdOfferTemplate eAPProdOfferTemplate = (EAPProdOfferTemplate) JAXBHelperFunction
					.unmarshalRequestMessage(eventType, xmlString);
			
			return eAPProdOfferTemplate;
		}
		if (eventType.equals(AppConstants.EPP_TRT)) {
			EAPTreatmentTemplate eAPTreatmentTemplate = (EAPTreatmentTemplate) JAXBHelperFunction
					.unmarshalRequestMessage(eventType, xmlString);
			
			return eAPTreatmentTemplate;
		}
		if (eventType.equals(AppConstants.EPP_UOF)) {
			UpdateOfferFullfillmentEapRequest updateOfferFullfillmentEapRequest = (com.citi.api._private.v1.sales.customers.offers.fulfillments.senttoeap.UpdateOfferFullfillmentEapRequest) JAXBHelperFunction
					.unmarshalRequestMessage(eventType, xmlString);
			
			return updateOfferFullfillmentEapRequest;
		}
		
		
		else {
			return null;
		}

	}

}
