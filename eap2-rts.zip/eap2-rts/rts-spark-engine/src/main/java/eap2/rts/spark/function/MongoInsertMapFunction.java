package eap2.rts.spark.function;

import java.io.IOException;
import java.util.Calendar;
import java.util.HashMap;

import org.apache.hadoop.conf.Configuration;
import org.apache.spark.api.java.JavaPairRDD;
import org.apache.spark.api.java.JavaRDD;
import org.apache.spark.api.java.function.Function;
import org.apache.spark.api.java.function.PairFunction;
import org.bson.BSONObject;
import org.codehaus.jackson.JsonGenerationException;
import org.codehaus.jackson.map.JsonMappingException;
import org.codehaus.jackson.map.ObjectMapper;
import org.codehaus.jettison.json.JSONException;
import org.codehaus.jettison.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.mongodb.hadoop.MongoOutputFormat;
import com.mongodb.util.JSON;

import eap2.rts.common.event.dto.PossibleReasonRequest;
import scala.Tuple2;

public class MongoInsertMapFunction implements Function<JavaRDD<PossibleReasonRequest>, Void> {
	private static final long serialVersionUID = -7461389813405935477L;
	private static Logger sLogger = LoggerFactory.getLogger(MongoInsertMapFunction.class);
	private HashMap<String, String> mongoDbConfig;

	public MongoInsertMapFunction(HashMap<String, String> mongoConfig) {
		this.mongoDbConfig = mongoConfig;
	}

	public Void call(JavaRDD<PossibleReasonRequest> parsedObjectRdd) throws Exception {

		JavaPairRDD<Object, BSONObject> documents = parsedObjectRdd.mapToPair(new PairFunction<PossibleReasonRequest, Object, BSONObject>() {
			private static final long serialVersionUID = 5734678345064167902L;
			private ObjectMapper mapper = new ObjectMapper();

			public Tuple2<Object, BSONObject> call(PossibleReasonRequest parsedObj)
					throws JSONException, JsonGenerationException, JsonMappingException, IOException {
				BSONObject bsonObj = null;
				String jsonInString = mapper.writeValueAsString(parsedObj);
				JSONObject jsonObj = new JSONObject(jsonInString);
				
				try {
					bsonObj = (BSONObject) JSON.parse(jsonObj.toString());
				} catch (Exception e) {
					throw new RuntimeException("Error while mapping parsed object to BSON object\n", e);
				}
				return new Tuple2<Object, BSONObject>(Calendar.getInstance().getTime(), bsonObj);
			}
		});
		String mongoOutputURI = "mongodb://admin_mongodb:PASSWORD@maas-mw-d5-u0037:37017,maas-gt-d5-u0025:37017,maas-sw-d5-u0007:37017/test?ssl=true&authSource=admin";
		
		Configuration outputMongoConfig = new Configuration();
		outputMongoConfig.set("mongo.output.uri", mongoOutputURI);
		documents.saveAsNewAPIHadoopFile("", Object.class, BSONObject.class, MongoOutputFormat.class, outputMongoConfig);
		return null;
	}

}
