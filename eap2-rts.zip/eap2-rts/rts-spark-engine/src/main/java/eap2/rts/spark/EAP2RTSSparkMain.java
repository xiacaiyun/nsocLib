package eap2.rts.spark;

import java.io.IOException;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.Set;

import org.apache.log4j.Logger;
import org.apache.spark.SparkConf;
import org.apache.spark.api.java.JavaPairRDD;
import org.apache.spark.api.java.function.Function;
import org.apache.spark.api.java.function.Function2;
import org.apache.spark.api.java.function.PairFunction;
import org.apache.spark.broadcast.Broadcast;
import org.apache.spark.streaming.Durations;
import org.apache.spark.streaming.api.java.JavaDStream;
import org.apache.spark.streaming.api.java.JavaPairDStream;
import org.apache.spark.streaming.api.java.JavaReceiverInputDStream;
import org.apache.spark.streaming.api.java.JavaStreamingContext;

import com.fasterxml.jackson.core.JsonGenerationException;
import com.fasterxml.jackson.databind.ObjectMapper;

import eap2.rts.common.SysConstants;
import eap2.rts.common.appconfig.AppConfigService;
import eap2.rts.common.appconfig.dto.AppDS;
import eap2.rts.common.appconfig.dto.AppDSDetail;
import eap2.rts.common.appconfig.dto.AppDSEvent;
import eap2.rts.common.appconfig.dto.Application;
import eap2.rts.common.appconfig.dto.EventAction;
import eap2.rts.common.appconfig.dto.EventActionDetail;
import eap2.rts.common.event.dto.SimpleRequestObject;
import eap2.rts.pwp.PWPUtilMain;
import eap2.rts.spark.function.EventActionFunction;
import scala.Tuple2;
import shaded.parquet.org.codehaus.jackson.map.JsonMappingException;

/**
 * This is the main class which executes the Spark data processing engine.
 */
public class EAP2RTSSparkMain extends EAP2RTSSparkAbstract {
	private static final long serialVersionUID = 5815260794018554510L;
	private static Logger sLogger = Logger.getLogger(EAP2RTSSparkMain.class);
	public static  Map<String,String> appProps=null;
	static PWPUtilMain pwpUtilMain = new PWPUtilMain();
	/**
	 * @param args
	 * @throws Exception
	 */
	@SuppressWarnings("deprecation")
	public static void main(String[] args) throws Exception {
		sLogger.info("Starting EAP2RTSSparkRTMain.....");
		// 1. Collect input arguments
		Map<String, String> argMap = collectInputArguments(args);
		String propertiesFilename = argMap.get(AppConstants.ARG_APP_CONFIG_FILE_NAME);
		// 2. Load App Properties
		
	  appProps = loadAppProperties(propertiesFilename);
	  
	  String salt = appProps.get(SysConstants.PWP_SALT);
		String oraDBPassword = appProps.get(SysConstants.ORA_PASSWORD_PARAM);
		final String shutdownHour1 = appProps.get(SysConstants.SHUTDOWN_HOUR);
		int shutdownHour= Integer.parseInt(shutdownHour1);
		final String shutdownMinutes1 = appProps.get(SysConstants.SHUTDOWN_MINUTES);
		int shutdownMinutes= Integer.parseInt(shutdownMinutes1);
		String mongoDBPassword = appProps.get(SysConstants.MONGO_DB_PASSWORD);
		String mongo_password = pwpUtilMain.decrypt(salt, mongoDBPassword);
		
		if (appProps.get(SysConstants.IS_PASSWORD_ENCRYPTED).equals(SysConstants.YES_IND)) {
			PWPUtilMain pwpUtilMain = new PWPUtilMain();
			oraDBPassword = pwpUtilMain.decrypt(salt, oraDBPassword);
		}
		String mongoPassword = "";
		String tibcoPassword = "";
		Properties dbProperties = getDBProperties(appProps, propertiesFilename, oraDBPassword);
		// Make it runnable on windows os
		if (System.getProperty("os.name").startsWith("Windows")) {
			System.setProperty(AppConstants.HADOOP_HOME_DIR, appProps.get(AppConstants.HADOOP_HOME_DIR));
		}
		// 3. Load AppConfig SPARK_APP_NAME.
		AppConfigService appConfigService = new AppConfigService(dbProperties);
		final Application appConfig = appConfigService.getAppConfigByName(argMap.get(AppConstants.ARG_SPARK_APP_NAME), salt);
		
	//	String appCon = convertObjectToJson(appConfig);
	  //    logger.info(appCon);
		
		// 4. Instantiate Spark Streaming contexts
		Map<String, String> sparkParams = appConfig.getAppParamsByType(SysConstants.PARAM_TYPE_SPARK_CONF);
		SparkConf conf = new SparkConf();
	
		
		
		Set<String> paramNames = sparkParams.keySet();
		Iterator<String> iter = paramNames.iterator();
		while (iter.hasNext()) {
			String paramName = iter.next();
			String paramValue = sparkParams.get(paramName);
			logger.info("Setting Spark Conf. paramName=" + paramName + " paramValue" + paramValue);
			conf.set(paramName, paramValue);
		}
		if (System.getProperty("os.name").startsWith("Windows")) {
			conf.set("spark.master", "local[*]");
		}
		String duration = appConfig.getAppConf(AppConstants.APP_PARAM_SPARK_DUATION);
		logger.info("Spark Streaming micro-batch duratoin (in milliseconds) = " + duration);
		JavaStreamingContext jssc = new JavaStreamingContext(conf, Durations.milliseconds(Long.valueOf(duration)));
		
		Broadcast<Map<String, String>> broadcastAppProps = jssc.sparkContext().broadcast(appProps);
				
		
		
		// 5. Add the Event/Message Receivers
		List<AppDS> appDSList = appConfig.getAppDS();
		for (AppDS appDS : appDSList) {
			List<AppDSDetail> appDSDetails = appDS.getAppDSDetails();
			for (AppDSDetail appDSDetail : appDSDetails) {
				String paramName = appDSDetail.getParamName();
				if (AppConstants.QUEUE_PASSWORD.equals(paramName)) {
					tibcoPassword = appDSDetail.getParamValue();
				}
			}
			List<AppDSEvent> appDSEvents = appDS.getAppDSEvents();
			for (AppDSEvent event : appDSEvents) {
				List<EventAction> eventActions = event.getEventActions();
				for (EventAction action : eventActions) {
					String actionType = action.getActionTypeCode();
					List<EventActionDetail> eventActionDetails;
					logger.info("Action Type:" + actionType);
					eventActionDetails = action.getEventActionDetails();
					for (EventActionDetail eventActionDetail : eventActionDetails) {
						String paramName = eventActionDetail.getParamName();
						if (AppConstants.SAVE_MONGO.equals(actionType) || AppConstants.RET_MONGO.equals(actionType)
								|| AppConstants.SAVE_FLAT_MONGO.equals(actionType)) {
							if (AppConstants.MONGODB_DB_PASSWORD.equals(paramName)) {
								mongoPassword = eventActionDetail.getParamValue();
							} else if (AppConstants.MONGODB_URI.equals(paramName)) {
								String paramValue = eventActionDetail.getParamValue();
								eventActionDetail.setParamValue(paramValue.replace("$PASSWORD", mongoPassword));
							}
						}
					}
				}
			}
		}
		String msgBrokerType = appConfig.getAppConf(AppConstants.APP_MSG_BROKER_TYPE);
		logger.info("Message Broker type = " + msgBrokerType);
		JavaReceiverInputDStream<Tuple2<String, SimpleRequestObject>> stream = getJavaReceiverInputStream(jssc, appDSList, msgBrokerType,
				tibcoPassword, propertiesFilename);
		
		// 6. Apply Actions
		
		
		EventActionFunction actionFunction = new EventActionFunction(appDSList, tibcoPassword,broadcastAppProps, mongo_password);
		JavaDStream<Tuple2<String, Long>> countsRDD = stream.map(actionFunction);
		
		// 7. Publish statistics
		JavaPairDStream<String, Long> countPairRDD = countsRDD.mapToPair(new PairFunction<Tuple2<String, Long>, String, Long>() {
			private static final long serialVersionUID = 1506585920794114092L;

			public Tuple2<String, Long> call(Tuple2<String, Long> t) throws Exception {
				return new Tuple2<String, Long>(t._1, t._2);
			}
		}).reduceByKey(new Function2<Long, Long, Long>() {
			private static final long serialVersionUID = 7497651478821375182L;

			public Long call(Long v1, Long v2) throws Exception {
				return v1 + v2;
			}
		});
		countPairRDD.foreach(new Function<JavaPairRDD<String, Long>, Void>() {
			private static final long serialVersionUID = 958751338017265667L;

			public Void call(JavaPairRDD<String, Long> v1) throws Exception {
				Map<String, Long> counts = v1.collectAsMap();
				Iterator<String> iter = counts.keySet().iterator();
				while (iter.hasNext()) {
					String eventType = iter.next();
					Long count = counts.get(eventType);
					logger.info("Received event = " + eventType + " count=" + count);
				}
				return null;
			}
		});
		
		// 8. Start the Spark Streaming context and wait
		jssc.start();
		
		// 9. Add logic for graceful shutdown
		
		{
			long checkIntervalMillis = 10000;
		boolean isStopped = false;
		while (!isStopped) {
			isStopped = jssc.awaitTerminationOrTimeout(checkIntervalMillis);
			//sLogger.info(">>>>>>>>>>>>>>>>>>>>>isStopped>>" +isStopped);
			if (isStopped) {
				sLogger.info("Confirmed! The streaming context is stopped. Exiting application.");
			} 
			else {
				
				Date date = new Date();
				long elapsedTime = date.getTime() - jssc.sc().startTime();
				Calendar sysTime = GregorianCalendar.getInstance();
	              sysTime.setTime(date);
	            
	              Calendar shutdownTimeMin = GregorianCalendar.getInstance();
	              shutdownTimeMin.setTime(date);
	            shutdownTimeMin.set(Calendar.HOUR_OF_DAY, shutdownHour);
	              shutdownTimeMin.set(Calendar.MINUTE,shutdownMinutes);
	              
	              Calendar shutdownTimeMax = GregorianCalendar.getInstance();
	              shutdownTimeMax.setTime(date);
	              shutdownTimeMax.set(Calendar.HOUR_OF_DAY, shutdownHour);
	              shutdownTimeMax.set(Calendar.MINUTE,shutdownMinutes);
	              shutdownTimeMax.add(Calendar.MINUTE,5);
	             
	              if(elapsedTime > 43200000L && shutdownTimeMin.compareTo(sysTime) <= 0 && shutdownTimeMax.compareTo(sysTime) > 0){
	            	  if (!isStopped) {
	            	  sLogger.info("Stopping the Spark Streaming Context now.");
						jssc.stop(true, true);
						sLogger.info("Spark Streaming Context is stopped!!!!!!!");
	              
	       }
	}
}
}
				
				
		sLogger.info("Exiting EAP2-RTSSpark-Main.....");
		jssc.close();
	} 
		
	}

private static String convertObjectToJson(Application appConfig) throws JsonGenerationException, JsonMappingException, IOException  {
        
        ObjectMapper mapper = new ObjectMapper();
        String jsonString = "";
        jsonString = mapper.writeValueAsString(appConfig);
        
 return jsonString;
}


	}