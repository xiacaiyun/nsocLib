package eap2.rts.spark;

import java.util.HashMap;
import java.util.Map;

import org.apache.spark.SparkConf;
import org.apache.spark.storage.StorageLevel;
import org.apache.spark.streaming.Durations;
import org.apache.spark.streaming.api.java.JavaReceiverInputDStream;
import org.apache.spark.streaming.api.java.JavaStreamingContext;

import eap2.rts.pwp.PWPUtilMain;
import eap2.rts.spark.function.SparkMongoFunction;
import eap2.rts.spark.receiver.SparkMongoReceiver;

public class EAP2RTSSparkMongoMain {

	@SuppressWarnings("deprecation")
	public static void main(String[] args) {
		if (System.getProperty("os.name").startsWith("Windows")) {
			System.setProperty(AppConstants.HADOOP_HOME_DIR, "I:/hadoop-2.7.1");
		}
		PWPUtilMain pwpUtil = new PWPUtilMain();
		String mongoURI = args[0];
		String mongoDBName=args[1];
		String mongoDBCollection = args[2];
		String mongoDBPassword = args[3];
		String salt = args[4];
		String eventType=args[5];
		String connectionFactory=args[6];
		String providerUrl=args[7];
		String sslIdentity=args[8];
		String _tibcoPassword=args[9];
		String secProtocol=args[10];
		String sslVendor=args[11];
		String sslProvider=args[12];
		String sslAuthOnly=args[13];
		String tibcoSecVendor=args[14];
		String tibcoSecTrace=args[15];
		String sslDebugTrace=args[16];
		String sslTrace=args[17];
		String queueCF=args[18];
		String queueUsername=args[19];
		String queueName=args[20];
		String p12Enabled=args[21];
		String enableVerifyHost=args[22];
		int _responseDeadlineMinutes=Integer.parseInt(args[23]);
		try {
			mongoDBPassword = pwpUtil.decrypt(salt, mongoDBPassword);
			_tibcoPassword=pwpUtil.decrypt(salt, _tibcoPassword);
		} catch (Exception e) {
			e.printStackTrace();
		}
		Map<String,String> _tibcoConfig=new HashMap<String, String>();
		Map<String, String> _mongoDBConfiguration=new HashMap<String, String>();
		_tibcoConfig.put(AppConstants.CONN_FACTORY, connectionFactory);
		_tibcoConfig.put(AppConstants.PROVIDER_URL, providerUrl);
		_tibcoConfig.put(AppConstants.SSL_IDENTITY, sslIdentity);
		_tibcoConfig.put(AppConstants.SSL_PASSWORD, _tibcoPassword);
		_tibcoConfig.put(AppConstants.SEC_PROTOCOL, secProtocol);
		_tibcoConfig.put(AppConstants.ENABLE_VERIFY_HOST, enableVerifyHost);
		_tibcoConfig.put(AppConstants.SSL_VENDOR, sslVendor);
		_tibcoConfig.put(AppConstants.SSL_PROVIDER, sslProvider);
		_tibcoConfig.put(AppConstants.SSL_AUTH_ONLY, sslAuthOnly);
		_tibcoConfig.put(AppConstants.TIBCO_SEC_VENDOR, tibcoSecVendor);
		_tibcoConfig.put(AppConstants.TIBCO_SEC_TRACE, tibcoSecTrace);
		_tibcoConfig.put(AppConstants.SSL_DEBUG_TRACE, sslDebugTrace);
		_tibcoConfig.put(AppConstants.SSL_TRACE, sslTrace);
		_tibcoConfig.put(AppConstants.QUEUE_USERNAME, queueUsername);
		_tibcoConfig.put(AppConstants.QUEUE_PASSWORD,_tibcoPassword);
		_tibcoConfig.put(AppConstants.QUEUE_CF, queueCF);
		_tibcoConfig.put(AppConstants.QUEUE_NAME, queueName);
		_tibcoConfig.put(AppConstants.P12_ENABLED, p12Enabled);
		
		mongoURI = mongoURI.replace("@PASSWORD", mongoDBPassword);
		_mongoDBConfiguration.put(AppConstants.MONGODB_URI, mongoURI);
		_mongoDBConfiguration.put(AppConstants.MONGODB_DB_PASSWORD, mongoDBPassword);
		_mongoDBConfiguration.put(AppConstants.MONGODB_DB_NAME, mongoDBName);
		_mongoDBConfiguration.put(AppConstants.MONGODB_DB_COLLECTION, mongoDBCollection);
		SparkConf sc = new SparkConf().setAppName("MongoSparkConnectorTour");
		if (System.getProperty("os.name").startsWith("Windows")) {
			sc.set("spark.master", "local[*]");
		}
		JavaStreamingContext jssc = new JavaStreamingContext(sc, Durations.seconds(Long.valueOf(3)));
		JavaReceiverInputDStream<String> stream = jssc.receiverStream(new SparkMongoReceiver(StorageLevel.MEMORY_ONLY_2(), mongoURI, mongoDBCollection));
		stream.foreach(new SparkMongoFunction(_tibcoConfig, _mongoDBConfiguration, eventType,_responseDeadlineMinutes));
		
		jssc.start();
		jssc.awaitTermination();
		jssc.close();
	}

}
