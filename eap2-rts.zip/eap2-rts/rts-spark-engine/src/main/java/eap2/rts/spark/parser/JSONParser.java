package eap2.rts.spark.parser;

import java.io.IOException;
import java.io.Serializable;

import javax.xml.bind.JAXBException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;

import eap2.rts.common.event.dto.PossibleReasonRequest;
import eap2.rts.common.eventhub.dto.APINChangeRequest;
import eap2.rts.common.eventhub.dto.AccountLinkageRequest;
import eap2.rts.common.eventhub.dto.AccountSummaryRequest;
import eap2.rts.common.eventhub.dto.BillPaymentRequest;
import eap2.rts.common.eventhub.dto.CBOLMBOLRegistrationRequest;
import eap2.rts.common.eventhub.dto.CardActivationRequest;
import eap2.rts.common.eventhub.dto.CardBlockCodeUpdateRequest;
import eap2.rts.common.eventhub.dto.CardDeclineRequest;
import eap2.rts.common.eventhub.dto.ChargeDisputeRequest;
import eap2.rts.common.eventhub.dto.ChequeBounceRequest;
import eap2.rts.common.eventhub.dto.ChequeStopPaymentRequest;
import eap2.rts.common.eventhub.dto.CpoCallEndRequest;
import eap2.rts.common.eventhub.dto.CpoCallStartRequest;
import eap2.rts.common.eventhub.dto.CreditCardClosureRequest;
import eap2.rts.common.eventhub.dto.CreditCardReversalRequest;
import eap2.rts.common.eventhub.dto.CreditLimitIncreaseRequest;
import eap2.rts.common.eventhub.dto.CustHWTokenRequest;
import eap2.rts.common.eventhub.dto.CustLoginIDStatusChangeRequest;
import eap2.rts.common.eventhub.dto.CustomerLoginRequest;
import eap2.rts.common.eventhub.dto.DemographicChangeRequest;
import eap2.rts.common.eventhub.dto.DigiPassInitiationRequest;
import eap2.rts.common.eventhub.dto.EPPLOPOfferViewRequest;
import eap2.rts.common.eventhub.dto.EstatementDispatchRequest;
import eap2.rts.common.eventhub.dto.EstatementViewRequest;
import eap2.rts.common.eventhub.dto.ForgotUserIdAndPasswordRequest;
import eap2.rts.common.eventhub.dto.IVRCallEndRequest;
import eap2.rts.common.eventhub.dto.IVRCallStartRequest;
import eap2.rts.common.eventhub.dto.OnlineDirectDebitExecutionRequest;
import eap2.rts.common.eventhub.dto.OverseasCardActivationRequest;
import eap2.rts.common.eventhub.dto.PINValidationRequest;
import eap2.rts.common.eventhub.dto.PaymentAndTransferRequest;
import eap2.rts.common.eventhub.dto.PreAuthRequest;
import eap2.rts.common.eventhub.dto.ReportLostStolenRequest;
import eap2.rts.common.eventhub.dto.RewardRedemptionAccessRequest;
import eap2.rts.common.eventhub.dto.RewardRedemptionRequestRequest;
import eap2.rts.common.eventhub.dto.SDNMatchFoundRequest;
import eap2.rts.common.eventhub.dto.SDNMatchResolvedRequest;
import eap2.rts.common.eventhub.dto.SMSEmailOffersRequest;
import eap2.rts.common.eventhub.dto.ServiceRequestRequest;
import eap2.rts.common.eventhub.dto.TPINCreateResetChangeIssuanceRequest;
import eap2.rts.common.eventhub.dto.ViewTransactionsHistoryRequest;

import eap2.rts.common.eventhub.dto.IVRCallLogin;
import eap2.rts.spark.AppConstants;

public class JSONParser implements Serializable,MessageParser {
	protected Logger logger = LoggerFactory.getLogger(JSONParser.class);

	/**
	 * 
	 */
	private static final long serialVersionUID = 1505673637405118805L;

	public Object parse(String jsonString, String eventType) throws JsonParseException, JsonMappingException, IOException,JAXBException {
		ObjectMapper mapper = new ObjectMapper();
		mapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);

		if (AppConstants.EPP_POSS_RES.equals(eventType)) {
			PossibleReasonRequest possibleReasonRequest = mapper.readValue(jsonString, PossibleReasonRequest.class);
		
			return possibleReasonRequest;
		}else if(AppConstants.CARD_ACTIVATION.equals(eventType)){
			CardActivationRequest cardActivationRequest=mapper.readValue(jsonString, CardActivationRequest.class);
			
			return cardActivationRequest;
		}else if(AppConstants.ACCOUNT_LINKAGE.equals(eventType)){
			AccountLinkageRequest accountLinkageRequest=mapper.readValue(jsonString, AccountLinkageRequest.class);
			
			return accountLinkageRequest;
		}else if(AppConstants.ACCOUNT_SUMMARY.equals(eventType)){
			AccountSummaryRequest accountSummaryRequest=mapper.readValue(jsonString, AccountSummaryRequest.class);
			
			return accountSummaryRequest;
		}else if(AppConstants.APIN_CHANGE.equals(eventType)){
			APINChangeRequest apinChangeRequest=mapper.readValue(jsonString, APINChangeRequest.class);
			
			return apinChangeRequest;
		}else if(AppConstants.IVR_CALL_LOGIN.equals(eventType)){
			IVRCallLogin ivrCallLogin=mapper.readValue(jsonString, IVRCallLogin.class);
			//System.out.println(">>>>>>>>>>>>>inside json parse Event>>" +ivrCallLogin);
			return ivrCallLogin;
		}else if(AppConstants.BILL_PAYMENT.equals(eventType)){
			BillPaymentRequest billPaymentRequest=mapper.readValue(jsonString, BillPaymentRequest.class);
			
			return billPaymentRequest;
		}else if(AppConstants.CARD_BLOCK_CODE_UPDATE.equals(eventType)){
			CardBlockCodeUpdateRequest cardBlockCodeUpdateRequest=mapper.readValue(jsonString, CardBlockCodeUpdateRequest.class);
			
			return cardBlockCodeUpdateRequest;
		}else if(AppConstants.CARD_DECLINE.equals(eventType)){
			CardDeclineRequest cardDeclineRequest=mapper.readValue(jsonString, CardDeclineRequest.class);
			
			return cardDeclineRequest;
		}else if(AppConstants.CBOL_MBOL_REGISTRATION.equals(eventType)){
			CBOLMBOLRegistrationRequest cbolmbolRegistrationRequest=mapper.readValue(jsonString, CBOLMBOLRegistrationRequest.class);
			
			return cbolmbolRegistrationRequest;
		}else if(AppConstants.CHARGE_DISPUTE.equals(eventType)){
			ChargeDisputeRequest chargeDisputeRequest=mapper.readValue(jsonString, ChargeDisputeRequest.class);
			
			return chargeDisputeRequest;
		}else if(AppConstants.CHEQUE_BOUNCE_REQUEST.equals(eventType)){
			ChequeBounceRequest chequeBounceRequest=mapper.readValue(jsonString, ChequeBounceRequest.class);
			
			return chequeBounceRequest;
		}else if(AppConstants.CHEQUE_STOP_PAYMENT_REQUEST.equals(eventType)){
			ChequeStopPaymentRequest chequeStopPaymentRequest=mapper.readValue(jsonString, ChequeStopPaymentRequest.class);
			
			return chequeStopPaymentRequest;
		}else if(AppConstants.CPO_CALL_END.equals(eventType)){
			CpoCallEndRequest cpoCallEndRequest=mapper.readValue(jsonString, CpoCallEndRequest.class);
			
			return cpoCallEndRequest;
		}else if(AppConstants.CPO_CALL_START.equals(eventType)){
			CpoCallStartRequest cpoCallStartRequest=mapper.readValue(jsonString, CpoCallStartRequest.class);
			
			return cpoCallStartRequest;
		}else if(AppConstants.CREDIT_CARD_CLOSURE.equals(eventType)){
			CreditCardClosureRequest creditCardClosureRequest=mapper.readValue(jsonString, CreditCardClosureRequest.class);
			
			return creditCardClosureRequest;
		}else if(AppConstants.CREDIT_CARD_REVERSAL.equals(eventType)){
			CreditCardReversalRequest creditCardReversalRequest=mapper.readValue(jsonString, CreditCardReversalRequest.class);
			
			return creditCardReversalRequest;
		}else if(AppConstants.CREDIT_LIMIT_INCREASE.equals(eventType)){
			CreditLimitIncreaseRequest creditLimitIncreaseRequest=mapper.readValue(jsonString, CreditLimitIncreaseRequest.class);
			
			return creditLimitIncreaseRequest;
		}else if(AppConstants.CUST_HW_TOKEN.equals(eventType)){
			CustHWTokenRequest custHWTokenRequest=mapper.readValue(jsonString, CustHWTokenRequest.class);
			
			return custHWTokenRequest;
		}else if(AppConstants.CUST_LOGIN_ID_STATUS_CHANGE.equals(eventType)){
			CustLoginIDStatusChangeRequest custLoginIDStatusChangeRequest=mapper.readValue(jsonString, CustLoginIDStatusChangeRequest.class);
			
			return custLoginIDStatusChangeRequest;
		}else if(AppConstants.CUSTOMER_LOGIN.equals(eventType)){
			CustomerLoginRequest customerLoginRequest=mapper.readValue(jsonString, CustomerLoginRequest.class);
			
			return customerLoginRequest;
		}else if(AppConstants.DEMOGRAPHIC_CHANGE.equals(eventType)){
			DemographicChangeRequest demographicChangeRequest=mapper.readValue(jsonString, DemographicChangeRequest.class);
			
			return demographicChangeRequest;
		}else if(AppConstants.DIGIPASS_INITIATION.equals(eventType)){
			DigiPassInitiationRequest digiPassInitiationRequest=mapper.readValue(jsonString, DigiPassInitiationRequest.class);
			
			return digiPassInitiationRequest;
		}else if(AppConstants.EPPLOP_OFFER_VIEW.equals(eventType)){
			EPPLOPOfferViewRequest epplopOfferViewRequest=mapper.readValue(jsonString, EPPLOPOfferViewRequest.class);
			
			return epplopOfferViewRequest;
		}else if(AppConstants.ESTATEMENT_DISPATCH.equals(eventType)){
			EstatementDispatchRequest estatementDispatchRequest=mapper.readValue(jsonString, EstatementDispatchRequest.class);
			return estatementDispatchRequest;
		}else if(AppConstants.ESTATEMENT_VIEW.equals(eventType)){
			EstatementViewRequest estatementViewRequest=mapper.readValue(jsonString, EstatementViewRequest.class);
			return estatementViewRequest;
		}else if(AppConstants.FORGOT_USERID_AND_PASSWORD.equals(eventType)){
			ForgotUserIdAndPasswordRequest forgotUserIdAndPasswordRequest=mapper.readValue(jsonString, ForgotUserIdAndPasswordRequest.class);
			return forgotUserIdAndPasswordRequest;
		}else if(AppConstants.IVR_CALL_END.equals(eventType)){
			IVRCallEndRequest ivrCallEndRequest=mapper.readValue(jsonString, IVRCallEndRequest.class);
			return ivrCallEndRequest;
		}else if(AppConstants.IVR_CALL_START.equals(eventType)){
			IVRCallStartRequest ivrCallStartRequest=mapper.readValue(jsonString, IVRCallStartRequest.class);
			return ivrCallStartRequest;
		}else if(AppConstants.ONLINE_DIRECT_DEBIT_EXEC.equals(eventType)){
			OnlineDirectDebitExecutionRequest onlineDirectDebitExecutionRequest=mapper.readValue(jsonString, OnlineDirectDebitExecutionRequest.class);
			return onlineDirectDebitExecutionRequest;
		}else if(AppConstants.OVERSEAS_ACTIVATION.equals(eventType)){
			OverseasCardActivationRequest overseasCardActivationRequest=mapper.readValue(jsonString, OverseasCardActivationRequest.class);
			return overseasCardActivationRequest;
		}else if(AppConstants.PAYMENT_AND_TRANSFER.equals(eventType)){
			PaymentAndTransferRequest paymentAndTransferRequest=mapper.readValue(jsonString, PaymentAndTransferRequest.class);
			return paymentAndTransferRequest;
		}else if(AppConstants.PIN_VALIDATION.equals(eventType)){
			PINValidationRequest pinValidationRequest=mapper.readValue(jsonString, PINValidationRequest.class);
			return pinValidationRequest;
		}else if(AppConstants.PRE_AUTH.equals(eventType)){
			PreAuthRequest preAuthRequest=mapper.readValue(jsonString, PreAuthRequest.class);
			return preAuthRequest;
		}else if(AppConstants.REPORT_LOST_STOLEN.equals(eventType)){
			ReportLostStolenRequest reportLostStolenRequest=mapper.readValue(jsonString, ReportLostStolenRequest.class);
			return reportLostStolenRequest;
		}else if(AppConstants.REWARD_REDEMPTION_ACCESS.equals(eventType)){
			RewardRedemptionAccessRequest rewardRedemptionAccessRequest=mapper.readValue(jsonString, RewardRedemptionAccessRequest.class);
			return rewardRedemptionAccessRequest;
		}else if(AppConstants.REWARD_REDEMPTION_REQUEST.equals(eventType)){
			RewardRedemptionRequestRequest rewardRedemptionRequestRequest=mapper.readValue(jsonString, RewardRedemptionRequestRequest.class);
			return rewardRedemptionRequestRequest;
		}else if(AppConstants.SDN_MATCH_FOUND.equals(eventType)){
			SDNMatchFoundRequest sdnMatchFoundRequest=mapper.readValue(jsonString, SDNMatchFoundRequest.class);
			return sdnMatchFoundRequest;
		}else if(AppConstants.SDN_MATCH_RESOLVED.equals(eventType)){
			SDNMatchResolvedRequest sdnMatchResolvedRequest=mapper.readValue(jsonString, SDNMatchResolvedRequest.class);
			return sdnMatchResolvedRequest;
		}else if(AppConstants.SERVICE_REQUEST.equals(eventType)){
			ServiceRequestRequest serviceRequestRequest=mapper.readValue(jsonString, ServiceRequestRequest.class);
			return serviceRequestRequest;
		}else if(AppConstants.SMS_EMAIL_OFFERS.equals(eventType)){
			SMSEmailOffersRequest smsEmailOffersRequest=mapper.readValue(jsonString, SMSEmailOffersRequest.class);
			return smsEmailOffersRequest;
		}else if(AppConstants.TPIN_CREATE_RESET_CHANGE_ISSUANCE.equals(eventType)){
			TPINCreateResetChangeIssuanceRequest tpinCreateResetChangeIssuanceRequest=mapper.readValue(jsonString, TPINCreateResetChangeIssuanceRequest.class);
			return tpinCreateResetChangeIssuanceRequest;
		}else if(AppConstants.VIEW_TRANSACTION_HISTORY.equals(eventType)){
			ViewTransactionsHistoryRequest viewTransactionsHistoryRequest=mapper.readValue(jsonString, ViewTransactionsHistoryRequest.class);
			return viewTransactionsHistoryRequest;
		}else {
			logger.error("Cannot parse Object as unknown eventType");
			return null;
		}
	}

}
