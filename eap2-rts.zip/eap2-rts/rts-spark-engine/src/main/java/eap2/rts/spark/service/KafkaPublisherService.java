package eap2.rts.spark.service;

import java.util.Map;
import java.util.Properties;

import javax.jms.JMSException;

import org.apache.kafka.clients.CommonClientConfigs;
import org.apache.kafka.clients.producer.KafkaProducer;
import org.apache.kafka.clients.producer.Producer;
import org.apache.kafka.clients.producer.ProducerConfig;
import org.apache.kafka.clients.producer.ProducerRecord;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import eap2.rts.spark.AppConstants;

/**
 * @author bs34500
 */
public class KafkaPublisherService {
	private static final Logger logger = LoggerFactory.getLogger(KafkaPublisherService.class);
	private static KafkaPublisherService _instance = null;
	private Map<String, String> _kafkaBrokerConfig = null;
	private Properties _props = null;
	private Producer<String, String> _producer = null;

	/**
	 * @param kafkaBrokerConfig
	 */
	private KafkaPublisherService(Map<String, String> kafkaBrokerConfig) {
		this._kafkaBrokerConfig = kafkaBrokerConfig;
		_props = new Properties();
		_props.put(ProducerConfig.BOOTSTRAP_SERVERS_CONFIG, kafkaBrokerConfig.get(ProducerConfig.BOOTSTRAP_SERVERS_CONFIG));
		_props.put(CommonClientConfigs.SECURITY_PROTOCOL_CONFIG, kafkaBrokerConfig.get(CommonClientConfigs.SECURITY_PROTOCOL_CONFIG));
		_props.put(ProducerConfig.ACKS_CONFIG, kafkaBrokerConfig.get(ProducerConfig.ACKS_CONFIG));
		_props.put(ProducerConfig.VALUE_SERIALIZER_CLASS_CONFIG, kafkaBrokerConfig.get(ProducerConfig.VALUE_SERIALIZER_CLASS_CONFIG));
		_props.put(ProducerConfig.KEY_SERIALIZER_CLASS_CONFIG, kafkaBrokerConfig.get(ProducerConfig.KEY_SERIALIZER_CLASS_CONFIG));
	}

	/**
	 * @param kafkaBrokerConfig
	 * @return
	 * @throws Exception
	 */
	public static KafkaPublisherService getInstance(Map<String, String> kafkaBrokerConfig) throws Exception {
		if (_instance == null) {
			_instance = new KafkaPublisherService(kafkaBrokerConfig);
			_instance.open();
		}
		return _instance;
	}

	/**
	 * @throws Exception
	 */
	public void open() throws Exception {
		logger.info("Inside KafkaPublisherService->>>>>open->>>>>");
		_producer = new KafkaProducer<String, String>(_props);
	}

	/**
	 * @param messages
	 * @throws JMSException
	 */
	public void publish(String topic, String message) throws Exception {
		logger.info("Inside KafkaPublisherService->>>>>publish->>>>>");
		if (message == null) {
			return;
		}
		try {
			_kafkaBrokerConfig.get(AppConstants.KAFKA_TOPIC);
			ProducerRecord<String, String> data = new ProducerRecord<String, String>(topic, message);
			_producer.send(data);
			_producer.flush();
		} catch (Exception ex) {
			throw new Exception(ex);
		}
	}

	@Override
	protected void finalize() throws Throwable {
		try {
			if (_producer != null) {
				_producer.close();
			}
		} catch (Throwable throwable) {
			logger.error("Inside KafkaPublisherService->>>>>finalize->>>>>error>>starts");
			logger.error(throwable.getMessage());
			logger.error("Inside KafkaPublisherService->>>>>finalize->>>>>error>>ends");
			throw throwable;
		}
	}
}