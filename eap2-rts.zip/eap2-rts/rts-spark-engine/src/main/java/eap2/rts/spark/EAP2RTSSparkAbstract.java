package eap2.rts.spark;

import java.io.Serializable;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.Set;

import org.apache.commons.configuration.ConfigurationException;
import org.apache.spark.storage.StorageLevel;
import org.apache.spark.streaming.api.java.JavaReceiverInputDStream;
import org.apache.spark.streaming.api.java.JavaStreamingContext;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import eap2.rts.common.SysConstants;
import eap2.rts.common.appconfig.dto.AppDS;
import eap2.rts.common.appconfig.dto.AppDSDetail;
import eap2.rts.common.appconfig.dto.AppDSEvent;
import eap2.rts.common.event.dto.SimpleRequestObject;
import eap2.rts.common.util.AppPropUtility;
import eap2.rts.spark.receiver.SparkTibcoJMSReceiver;
import scala.Tuple2;


/**
 * @author bs34500
 */
public abstract class EAP2RTSSparkAbstract implements Serializable {

	private static final long serialVersionUID = 6723473198515509205L;

	protected static Logger logger = LoggerFactory.getLogger(EAP2RTSSparkAbstract.class);

	/**
	 * @param args
	 * @return
	 * @throws Exception
	 */
	protected static Map<String, String> collectInputArguments(String[] args) throws Exception {
		logger.info("Inside EAP2MRESparkAbstract-->collectInputArguments.....");
		Map<String, String> map = new HashMap<String, String>();
		try {

			map.put(AppConstants.ARG_SPARK_APP_NAME, args[0]);
			map.put(AppConstants.ARG_APP_CONFIG_FILE_NAME, args[1]);
			

		} catch (Exception e) {
			logger.error("Inside EAP2MRESparkAbstract->>>>>collectInputArguments->>>>>error>>starts");
			logger.error("An error has occured.", e);
			logger.error("Inside EAP2MRESparkAbstract->>>>>collectInputArguments->>>>>error>>ends");
			throw e;
		}
		return map;
	}

	/**
	 * @param appPropFileName
	 * @return
	 * @throws Exception
	 */
	public static Map<String, String> loadAppProperties(String appPropFileName) throws Exception {
		logger.info(">>>>>>>>>>>Inside EAP2MRESparkAbstract-->loadAppCongigs.....");
		Map<String, String> map = new HashMap<String, String>();
		try {
			map = AppPropUtility.loadProperties(appPropFileName);
		} catch (ConfigurationException e) {
			logger.error("Inside EAP2MRESparkAbstract->>>>>loadAppCongigs->>>>>error>>starts");
			logger.error("An error has occured.", e);
			logger.error("Inside EAP2MRESparkAbstract->>>>>loadAppCongigs->>>>>error>>ends");
			throw new Exception(e);
		}
		return map;
	}
	

	
	/**
	 * @param appProps
	 * @return
	 */
	protected static Properties getDBProperties(Map<String, String> appProps,String propertiesFilename,String dbPassword) {
		Properties dbProperties = new Properties();
		dbProperties.put(SysConstants.ORA_DRIVER_PARAM, appProps.get(SysConstants.ORA_DRIVER_PARAM));
		dbProperties.put(SysConstants.ORA_URL_PARAM, appProps.get(SysConstants.ORA_URL_PARAM));
		dbProperties.put(SysConstants.ORA_USER_PARAM, appProps.get(SysConstants.ORA_USER_PARAM));
		dbProperties.put(SysConstants.ORA_PASSWORD_PARAM, dbPassword);
		dbProperties.put(SysConstants.APP_BY_NAME, appProps.get(SysConstants.APP_BY_NAME));
		dbProperties.put(SysConstants.APP_BY_ID,appProps.get(SysConstants.APP_BY_ID));
		dbProperties.put(SysConstants.TENANT_APP_PARAMS_BY_ID,appProps.get(SysConstants.TENANT_APP_PARAMS_BY_ID));
	    dbProperties.put(SysConstants.APP_PARAMS_BY_ID,appProps.get(SysConstants.APP_PARAMS_BY_ID));
	    dbProperties.put(SysConstants.APP_EVENT_BY_APP_DS_ID,appProps.get(SysConstants.APP_EVENT_BY_APP_DS_ID));
		dbProperties.put(SysConstants.APP_EVENT_ACTION_BY_EVENT_ID ,appProps.get(SysConstants.APP_EVENT_ACTION_BY_EVENT_ID));
		dbProperties.put(SysConstants.ACTION_DET_BY_ACTION_ID,appProps.get(SysConstants.ACTION_DET_BY_ACTION_ID));
	    dbProperties.put(SysConstants.APP_DS_DET_BY_DS_ID ,appProps.get(SysConstants.APP_DS_DET_BY_DS_ID));
		dbProperties.put(SysConstants.APP_DS_BY_APP_ID,appProps.get(SysConstants.APP_DS_BY_APP_ID));
			
		return dbProperties;
	}

	/**
	 * @param jssc
	 * @param appEvents
	 * @param msgBrokerType
	 * @param tibcoPassword 
	 * @param propertiesFilename 
	 * @return
	 */
	protected static JavaReceiverInputDStream<Tuple2<String,SimpleRequestObject>> getJavaReceiverInputStream(JavaStreamingContext jssc, List<AppDS> appDSList, String msgBrokerType, String tibcoPassword, String propertiesFilename) {
		JavaReceiverInputDStream<Tuple2<String,SimpleRequestObject>> stream = null;
			
			if (AppConstants.TIBCO.equals(msgBrokerType)) {
				Map<String, Map<String, String>> eventConfigs = getTibcoEventConfig(appDSList);
				SparkTibcoJMSReceiver tibcoJMSReceiver = new SparkTibcoJMSReceiver(StorageLevel.MEMORY_ONLY_2(), eventConfigs,tibcoPassword,propertiesFilename);
				stream = jssc.receiverStream(tibcoJMSReceiver);
			}else if(AppConstants.KAFKA.equals(msgBrokerType)){
				Map<String, Map<String, String>> eventConfigs=getKafkaEventConfig(appDSList);
				Iterator<String> eventKeys=eventConfigs.keySet().iterator();
				while(eventKeys.hasNext()){
					String eventKey = eventKeys.next();
					Map<String, String> eventConfigDetails = eventConfigs.get(eventKey);
					Set<String> kafkaTopics=new HashSet<String>();
					String commaSeperatedTopics = eventConfigDetails.get(AppConstants.KAFKA_TOPICS);
					String[] topics = commaSeperatedTopics.split(",");
					for (String t : topics) {
						
						kafkaTopics.add(t);
					}
					eventConfigDetails.remove(AppConstants.KAFKA_TOPICS);
				}
				
			} else {
				throw new RuntimeException("Unknown Message Broker Type found.");
			}
		
		return stream;
	}

	private static Map<String, Map<String, String>> getKafkaEventConfig(
			List<AppDS> appDSList) {
		Map<String, Map<String, String>> dsConfigs = new HashMap<String, Map<String, String>>();
		for (AppDS appDS : appDSList) {
			Map<String, String> dsConfig = new HashMap<String, String>();
			dsConfig.put(AppConstants.DEFAULT_EVENT, appDS.getDefaultEvent());
			dsConfig.put(AppConstants.DS_ID, appDS.getId().toString());
			dsConfig.put(AppConstants.DS_NAME, appDS.getName());
			for (AppDSDetail appDSDetail : appDS.getAppDSDetails()) {
				if (appDSDetail != null) {
					dsConfig.put(appDSDetail.getParamName(), appDSDetail.getParamValue());
				}
			}
			dsConfigs.put(appDS.getId().toString(), dsConfig);
		}
		return dsConfigs;
	}

	/**
	 * @param appEvents
	 * @return
	 */
	private static Map<String, Map<String, String>> getTibcoEventConfig(List<AppDS> appDSList) {
		Map<String, Map<String, String>> dsConfigs = new HashMap<String, Map<String, String>>();
		for (AppDS appDS : appDSList) {
			Map<String, String> dsConfig = new HashMap<String, String>();
			dsConfig.put(AppConstants.DEFAULT_EVENT, appDS.getDefaultEvent());
			dsConfig.put(AppConstants.DS_ID, appDS.getId().toString());
			dsConfig.put(AppConstants.DS_NAME, appDS.getName());
			for (AppDSDetail appDSDetail : appDS.getAppDSDetails()) {
				if (appDSDetail != null) {
					dsConfig.put(appDSDetail.getParamName(), appDSDetail.getParamValue());
				}
			}
			dsConfigs.put(appDS.getId().toString(), dsConfig);
		}
		return dsConfigs;
	}
}
