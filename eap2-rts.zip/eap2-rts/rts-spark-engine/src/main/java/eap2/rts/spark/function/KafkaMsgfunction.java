package eap2.rts.spark.function;

import org.apache.spark.api.java.function.Function;

import scala.Tuple2;

public class KafkaMsgfunction implements Function<Tuple2<String, String>, Tuple2<String, String>> {
	private static final long serialVersionUID = 1L;

	public Tuple2<String, String> call(Tuple2<String, String> tuple2) {
		return tuple2;
	}
}