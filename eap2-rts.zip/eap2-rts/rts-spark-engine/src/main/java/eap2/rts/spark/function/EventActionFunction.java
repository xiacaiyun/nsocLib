package eap2.rts.spark.function;

import eap2.rts.spark.EAP2RTSSparkMain;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.text.SimpleDateFormat;
import java.time.ZonedDateTime;
import java.util.ArrayList;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.TimeUnit;

import org.apache.commons.beanutils.BeanUtils;
import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.FileStatus;
import org.apache.hadoop.fs.FileSystem;
import org.apache.hadoop.fs.Path;
import org.apache.log4j.Logger;
import org.apache.spark.api.java.function.Function;
import org.apache.spark.broadcast.Broadcast;
import org.codehaus.jackson.JsonGenerationException;
import org.codehaus.jackson.map.JsonMappingException;

import com.citi.api._private.v1.sales.customers.offers.fulfillments.senttoeap.UpdateOfferFullfillmentEapRequest;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.gson.Gson;
import com.tibco.schemas.cop_elib.sharedresources.schemas.eventschema.epp.copeaprequest.COPEAPRequest;
import com.tibco.schemas.cop_elib.sharedresources.schemas.eventschema.epp.copeapresponse.COPEAPResponse;
import com.tibco.schemas.copsrainbow.sharedresources.schemas.eventschema.eapmodeloffer.EAPModelOffer;
import com.tibco.schemas.copsrainbow.sharedresources.schemas.eventschema.eapprodoffer.EAPProdOfferTemplate;
//import com.tibco.schemas.copsrainbow.sharedresources.schemas.eventschema.eaptrttemp.EAPTreatmentTemplate;
import com.tibco.schemas.cop_elib.sharedresources.schemas.eventschema.epp.eaptreatmenttemplate.EAPTreatmentTemplate;
import com.tibco.schemas.copsrainbow.sharedresources.schemas.eventschema.mretransaction.TransactionMREReq;
import com.tibco.schemas.copsrainbow.sharedresources.schemas.eventschema.mretransaction.TransactionMRERes;

import eap2.rts.common.SysConstants;
import eap2.rts.common.appconfig.dto.AppDS;
import eap2.rts.common.appconfig.dto.AppDSEvent;
import eap2.rts.common.appconfig.dto.EventAction;
import eap2.rts.common.appconfig.dto.EventActionDetail;
import eap2.rts.common.event.dto.FlattenRequest;
import eap2.rts.common.event.dto.PossibleReasonRequest;
import eap2.rts.common.event.dto.PossibleReasonResponse;
import eap2.rts.common.event.dto.PossibleReasonResponseLog;
import eap2.rts.common.event.dto.PredictReason;
import eap2.rts.common.event.dto.SimpleRequestObject;
import eap2.rts.common.event.dto.TransactionMREFlatRes;
import eap2.rts.common.eventhub.dto.APINChangeFlat;
import eap2.rts.common.eventhub.dto.APINChangeRequest;
import eap2.rts.common.eventhub.dto.AccountLinkageFlat;
import eap2.rts.common.eventhub.dto.AccountLinkageRequest;
import eap2.rts.common.eventhub.dto.AccountSummaryFlat;
import eap2.rts.common.eventhub.dto.AccountSummaryRequest;
import eap2.rts.common.eventhub.dto.BillPaymentFlat;
import eap2.rts.common.eventhub.dto.BillPaymentRequest;
import eap2.rts.common.eventhub.dto.CBOLMBOLRegistrationFlat;
import eap2.rts.common.eventhub.dto.CBOLMBOLRegistrationRequest;
import eap2.rts.common.eventhub.dto.CardActivationFlat;
import eap2.rts.common.eventhub.dto.CardActivationRequest;
import eap2.rts.common.eventhub.dto.CardBlockCodeUpdateFlat;
import eap2.rts.common.eventhub.dto.CardBlockCodeUpdateRequest;
import eap2.rts.common.eventhub.dto.CardDeclineFlat;
import eap2.rts.common.eventhub.dto.CardDeclineRequest;
import eap2.rts.common.eventhub.dto.ChargeDisputeFlat;
import eap2.rts.common.eventhub.dto.ChargeDisputeRequest;
import eap2.rts.common.eventhub.dto.ChequeBounceFlat;
import eap2.rts.common.eventhub.dto.ChequeBounceRequest;
import eap2.rts.common.eventhub.dto.ChequeStopPaymentFlat;
import eap2.rts.common.eventhub.dto.ChequeStopPaymentRequest;
import eap2.rts.common.eventhub.dto.CpoCallEndFlat;
import eap2.rts.common.eventhub.dto.CpoCallEndRequest;
import eap2.rts.common.eventhub.dto.CpoCallStartFlat;
import eap2.rts.common.eventhub.dto.CpoCallStartRequest;
import eap2.rts.common.eventhub.dto.CreditCardClosureFlat;
import eap2.rts.common.eventhub.dto.CreditCardClosureRequest;
import eap2.rts.common.eventhub.dto.CreditCardReversalFlat;
import eap2.rts.common.eventhub.dto.CreditCardReversalRequest;
import eap2.rts.common.eventhub.dto.CreditLimitIncreaseFlat;
import eap2.rts.common.eventhub.dto.CreditLimitIncreaseRequest;
import eap2.rts.common.eventhub.dto.CustHWTokenFlat;
import eap2.rts.common.eventhub.dto.CustHWTokenRequest;
import eap2.rts.common.eventhub.dto.CustLoginIDStatusChangeFlat;
import eap2.rts.common.eventhub.dto.CustLoginIDStatusChangeRequest;
import eap2.rts.common.eventhub.dto.CustomerLoginFlat;
import eap2.rts.common.eventhub.dto.CustomerLoginRequest;
import eap2.rts.common.eventhub.dto.DemographicChangeFlat;
import eap2.rts.common.eventhub.dto.DemographicChangeRequest;
import eap2.rts.common.eventhub.dto.DigiPassInitiationFlat;
import eap2.rts.common.eventhub.dto.DigiPassInitiationRequest;
import eap2.rts.common.eventhub.dto.EPPLOPOfferViewFlat;
import eap2.rts.common.eventhub.dto.EPPLOPOfferViewRequest;
import eap2.rts.common.eventhub.dto.EstatementDispatchFlat;
import eap2.rts.common.eventhub.dto.EstatementDispatchRequest;
import eap2.rts.common.eventhub.dto.EstatementViewFlat;
import eap2.rts.common.eventhub.dto.EstatementViewRequest;
import eap2.rts.common.eventhub.dto.ForgotUserIdAndPasswordFlat;
import eap2.rts.common.eventhub.dto.ForgotUserIdAndPasswordRequest;
import eap2.rts.common.eventhub.dto.IVRCallEndFlat;
import eap2.rts.common.eventhub.dto.IVRCallEndRequest;
import eap2.rts.common.eventhub.dto.IVRCallStartFlat;
import eap2.rts.common.eventhub.dto.IVRCallStartRequest;
import eap2.rts.common.eventhub.dto.OnlineDirectDebitExecutionFlat;
import eap2.rts.common.eventhub.dto.OnlineDirectDebitExecutionRequest;
import eap2.rts.common.eventhub.dto.OverseasCardActivationFlat;
import eap2.rts.common.eventhub.dto.OverseasCardActivationRequest;
import eap2.rts.common.eventhub.dto.PINValidationFlat;
import eap2.rts.common.eventhub.dto.PINValidationRequest;
import eap2.rts.common.eventhub.dto.PaymentAndTransferFlat;
import eap2.rts.common.eventhub.dto.PaymentAndTransferRequest;
import eap2.rts.common.eventhub.dto.PreAuthFlat;
import eap2.rts.common.eventhub.dto.PreAuthRequest;
import eap2.rts.common.eventhub.dto.ReportLostStolenFlat;
import eap2.rts.common.eventhub.dto.ReportLostStolenRequest;
import eap2.rts.common.eventhub.dto.RewardRedemptionAccessFlat;
import eap2.rts.common.eventhub.dto.RewardRedemptionAccessRequest;
import eap2.rts.common.eventhub.dto.RewardRedemptionRequestFlat;
import eap2.rts.common.eventhub.dto.RewardRedemptionRequestRequest;
import eap2.rts.common.eventhub.dto.SDNMatchFoundFlat;
import eap2.rts.common.eventhub.dto.SDNMatchFoundRequest;
import eap2.rts.common.eventhub.dto.SDNMatchResolvedFlat;
import eap2.rts.common.eventhub.dto.SDNMatchResolvedRequest;
import eap2.rts.common.eventhub.dto.SMSEmailOffersFlat;
import eap2.rts.common.eventhub.dto.SMSEmailOffersRequest;
import eap2.rts.common.eventhub.dto.ServiceRequestFlat;
import eap2.rts.common.eventhub.dto.ServiceRequestRequest;
import eap2.rts.common.eventhub.dto.TPINCreateResetChangeIssuanceFlat;
import eap2.rts.common.eventhub.dto.TPINCreateResetChangeIssuanceRequest;
import eap2.rts.common.eventhub.dto.ViewTransactionsHistoryFlat;
import eap2.rts.common.eventhub.dto.ViewTransactionsHistoryRequest;

import eap2.rts.common.eventhub.dto.IVRCallLogin;
import eap2.rts.spark.AppConstants;
import eap2.rts.spark.parser.MessageParser;
import eap2.rts.spark.parser.ParserFactory;
import eap2.rts.spark.service.MongoDBService;
import eap2.rts.spark.service.TibcoEMSService;
import eap2.rts.spark.service.TibcoJMSService;
import jline.internal.Log;
import eap2.rts.spark.EAP2RTSSparkMain;
import eap2.rts.spark.EAP2RTSSparkAbstract;
import scala.Tuple2;

public class EventActionFunction implements Function<Tuple2<String, SimpleRequestObject>, Tuple2<String, Long>> {

	private static final long serialVersionUID = -8158137628339226542L;

	private List<AppDSEvent> _appEvents = new ArrayList<AppDSEvent>();
	private String _tibcoPassword = new String();
	private String mongo_Password = new String();
	private static Logger logger = Logger.getLogger(EventActionFunction.class);
	//EAP2RTSSparkMain sparkMain = new EAP2RTSSparkMain();
	
	Map<String, String> appProps = null;
	// private static appProps = new String();

	public EventActionFunction(List<AppDS> appDSList, String tibcoPassword,
			Broadcast<Map<String, String>> broadcastAppProps,String mongo_password) {
		for (AppDS appDS : appDSList) {
			List<AppDSEvent> appDSEventList = appDS.getAppDSEvents();
			for (AppDSEvent appDSEvent : appDSEventList) {
				this._appEvents.add(appDSEvent);
			}
		}
		this._tibcoPassword = tibcoPassword;
		appProps = broadcastAppProps.getValue();
		mongo_Password = mongo_password;
	}

	public String formatDate(GregorianCalendar calendar) {
		SimpleDateFormat df = new SimpleDateFormat(AppConstants.MIS_DATE_FORMAT);
		df.setCalendar(calendar);
		String dateFormatted = df.format(calendar.getTime());
		return dateFormatted;
	}

	public String parseDate(GregorianCalendar calendar) {
		SimpleDateFormat df = new SimpleDateFormat(AppConstants.MIS_DATE_FORMAT);
		df.setCalendar(calendar);
		String dateFormatted = df.format(calendar.getTime());
		return dateFormatted;
	}

	public Tuple2<String, Long> call(Tuple2<String, SimpleRequestObject> v1) throws Exception {

		String eventType = v1._1();

		List<EventAction> actions = getActions(eventType);
		SimpleRequestObject requestObj = v1._2();
		PossibleReasonResponse responseBody = new PossibleReasonResponse();
		PossibleReasonResponseLog possibleReasonResponseLog = new PossibleReasonResponseLog();
		List<PredictReason> reasonList = new ArrayList<PredictReason>();
		PossibleReasonRequest possibleReasonRequest = new PossibleReasonRequest();

		Map<String, String> tibcoConfig = new HashMap<String, String>();

		TransactionMREReq transactionMREReq = new TransactionMREReq();
		TransactionMRERes transactionMRERes = new TransactionMRERes();
		TransactionMREFlatRes transactionMREFlatRes = new TransactionMREFlatRes();

		COPEAPRequest copeapRequest = new COPEAPRequest();
		COPEAPResponse copeapResponse = new COPEAPResponse();

		FlattenRequest flattenRequest = new FlattenRequest();

		String collectionName = "";
		String errorCode = "";
		String errorDescription = "";
		String geoRecommendationString = "";
		String nonGeoRecommendationString = "";
		String requestMessage = requestObj.getMsgBody();
		String requestQueueName = requestObj.getRequestQueueName();
		String requestMessageId = requestObj.getMessageid();
		String requestDateTime = requestObj.getRequestDatetime();

		String flattenedString = new String();
		CardActivationRequest cardActivationRequest = new CardActivationRequest();
		AccountLinkageRequest accountLinkageRequest = new AccountLinkageRequest();
		AccountSummaryRequest accountSummaryRequest = new AccountSummaryRequest();
		APINChangeRequest apinChangeRequest = new APINChangeRequest();
		BillPaymentRequest billPaymentRequest = new BillPaymentRequest();
		CardBlockCodeUpdateRequest cardBlockCodeUpdateRequest = new CardBlockCodeUpdateRequest();
		CardDeclineRequest cardDeclineRequest = new CardDeclineRequest();
		CBOLMBOLRegistrationRequest cbolmbolRegistrationRequest = new CBOLMBOLRegistrationRequest();
		ChargeDisputeRequest chargeDisputeRequest = new ChargeDisputeRequest();
		ChequeBounceRequest chequeBounceRequest = new ChequeBounceRequest();
		ChequeStopPaymentRequest chequeStopPaymentRequest = new ChequeStopPaymentRequest();
		CpoCallEndRequest cpoCallEndRequest = new CpoCallEndRequest();
		CpoCallStartRequest cpoCallStartRequest = new CpoCallStartRequest();
		CreditCardClosureRequest creditCardClosureRequest = new CreditCardClosureRequest();
		CreditCardReversalRequest creditCardReversalRequest = new CreditCardReversalRequest();
		CreditLimitIncreaseRequest creditLimitIncreaseRequest = new CreditLimitIncreaseRequest();
		CustHWTokenRequest custHWTokenRequest = new CustHWTokenRequest();
		CustLoginIDStatusChangeRequest custLoginIDStatusChangeRequest = new CustLoginIDStatusChangeRequest();
		CustomerLoginRequest customerLoginRequest = new CustomerLoginRequest();
		DemographicChangeRequest demographicChangeRequest = new DemographicChangeRequest();
		DigiPassInitiationRequest digiPassInitiationRequest = new DigiPassInitiationRequest();
		EPPLOPOfferViewRequest epplopOfferViewRequest = new EPPLOPOfferViewRequest();
		EstatementDispatchRequest estatementDispatchRequest = new EstatementDispatchRequest();
		EstatementViewRequest estatementViewRequest = new EstatementViewRequest();
		ForgotUserIdAndPasswordRequest forgotUserIdAndPasswordRequest = new ForgotUserIdAndPasswordRequest();
		IVRCallEndRequest ivrCallEndRequest = new IVRCallEndRequest();
		IVRCallLogin ivrCallLogin = new IVRCallLogin();
		IVRCallStartRequest ivrCallStartRequest = new IVRCallStartRequest();
		OnlineDirectDebitExecutionRequest onlineDirectDebitExecutionRequest = new OnlineDirectDebitExecutionRequest();
		OverseasCardActivationRequest overseasCardActivationRequest = new OverseasCardActivationRequest();
		PaymentAndTransferRequest paymentAndTransferRequest = new PaymentAndTransferRequest();
		PINValidationRequest pinValidationRequest = new PINValidationRequest();
		PreAuthRequest preAuthRequest = new PreAuthRequest();
		ReportLostStolenRequest reportLostStolenRequest = new ReportLostStolenRequest();
		RewardRedemptionAccessRequest rewardRedemptionAccessRequest = new RewardRedemptionAccessRequest();
		RewardRedemptionRequestRequest rewardRedemptionRequestRequest = new RewardRedemptionRequestRequest();
		SDNMatchFoundRequest sdnMatchFoundRequest = new SDNMatchFoundRequest();
		SDNMatchResolvedRequest sdnMatchResolvedRequest = new SDNMatchResolvedRequest();
		ServiceRequestRequest serviceRequestRequest = new ServiceRequestRequest();
		SMSEmailOffersRequest smsEmailOffersRequest = new SMSEmailOffersRequest();
		TPINCreateResetChangeIssuanceRequest tpinCreateResetChangeIssuanceRequest = new TPINCreateResetChangeIssuanceRequest();
		ViewTransactionsHistoryRequest viewTransactionsHistoryRequest = new ViewTransactionsHistoryRequest();
		EAPModelOffer eAPModelOffer = new EAPModelOffer();
		EAPProdOfferTemplate eAPProdOfferTemplate = new EAPProdOfferTemplate();
		EAPTreatmentTemplate eAPTreatmentTemplate = new EAPTreatmentTemplate();
		UpdateOfferFullfillmentEapRequest updateOfferFullfillmentEapRequest = new UpdateOfferFullfillmentEapRequest();
		String copTransactionID = null;

		if (!(requestMessage == null || requestMessage.isEmpty())) {
			int i = 1;
			if (actions != null) {
				for (EventAction a : actions) {
					String actionType = a.getActionTypeCode();

					if (AppConstants.PUB_KAFKA.equals(actionType)) {

					} else if (AppConstants.PARSE_EVENT.equals(actionType)) {
						MessageParser parser = null;

						if (AppConstants.EPP_POSS_RES.equals(eventType)) {
							parser = ParserFactory.getParser("JSON");
							try {

								possibleReasonRequest = (PossibleReasonRequest) parser.parse(requestMessage, eventType);
								String customerID = possibleReasonRequest.getGetReason().getCustomerID();
								String countryCode = possibleReasonRequest.getGetReason().getCountryCode();
								responseBody.setCustomerid(customerID);
								responseBody.setCoutrycode(countryCode);
								possibleReasonResponseLog.setClnt_nbr(customerID);
								possibleReasonResponseLog.setCntry_cde(countryCode);
							} catch (Exception e) {
								errorCode = "400";
								errorDescription = "Invalid Input Data";
								responseBody.setErrorcode(errorCode);
								responseBody.setErrordescription(errorDescription);
								possibleReasonResponseLog.setErrorcode(errorCode);
								possibleReasonResponseLog.setErrordescription(errorDescription);
							}
						} else if (AppConstants.CARD_ACTIVATION.equals(eventType)) {
							parser = ParserFactory.getParser("JSON");
							try {
								cardActivationRequest = (CardActivationRequest) parser.parse(requestMessage, eventType);
							} catch (Exception e) {
								logger.error("Unable to parse CardActivationRequest Exception", e);
							}
						} else if (AppConstants.IVR_CALL_LOGIN.equals(eventType)) {
							parser = ParserFactory.getParser("JSON");
							try {

								ivrCallLogin = (IVRCallLogin) parser.parse(requestMessage, eventType);
								// logger.info(">>>>>>>>Parseeeeeee>>>>"+ivrCallLogin);
							} catch (Exception e) {
								logger.error("IVRCallLogin", e);
							}
						} else if (AppConstants.ACCOUNT_LINKAGE.equals(eventType)) {
							parser = ParserFactory.getParser("JSON");
							try {
								accountLinkageRequest = (AccountLinkageRequest) parser.parse(requestMessage, eventType);
							} catch (Exception e) {

								logger.error("Unable to parse AccountLinkageRequest Exception", e);
							}
						} else if (AppConstants.ACCOUNT_SUMMARY.equals(eventType)) {
							parser = ParserFactory.getParser("JSON");
							try {
								accountSummaryRequest = (AccountSummaryRequest) parser.parse(requestMessage, eventType);
							} catch (Exception e) {

								logger.error("Unable to parse AccountSummaryRequest Exception", e);
							}
						} else if (AppConstants.APIN_CHANGE.equals(eventType)) {
							parser = ParserFactory.getParser("JSON");
							try {
								apinChangeRequest = (APINChangeRequest) parser.parse(requestMessage, eventType);
							} catch (Exception e) {

								logger.error("Unable to parse APINChangeRequest Exception", e);
							}
						} else if (AppConstants.BILL_PAYMENT.equals(eventType)) {
							parser = ParserFactory.getParser("JSON");
							try {
								billPaymentRequest = (BillPaymentRequest) parser.parse(requestMessage, eventType);
							} catch (Exception e) {

								logger.error("Unable to parse BillPaymentRequest Exception", e);
							}
						} else if (AppConstants.CARD_BLOCK_CODE_UPDATE.equals(eventType)) {
							parser = ParserFactory.getParser("JSON");
							try {
								cardBlockCodeUpdateRequest = (CardBlockCodeUpdateRequest) parser.parse(requestMessage,
										eventType);
							} catch (Exception e) {

								logger.error("Unable to parse CardBlockCodeUpdateRequest Exception", e);
							}
						} else if (AppConstants.CARD_DECLINE.equals(eventType)) {
							parser = ParserFactory.getParser("JSON");
							try {
								cardDeclineRequest = (CardDeclineRequest) parser.parse(requestMessage, eventType);
							} catch (Exception e) {

								logger.error("Unable to parse CardDeclineRequest Exception", e);
							}
						} else if (AppConstants.CBOL_MBOL_REGISTRATION.equals(eventType)) {
							parser = ParserFactory.getParser("JSON");
							try {
								cbolmbolRegistrationRequest = (CBOLMBOLRegistrationRequest) parser.parse(requestMessage,
										eventType);
							} catch (Exception e) {

								logger.error("Unable to parse CBOLMBOLRegistrationRequest Exception", e);
							}
						} else if (AppConstants.CHARGE_DISPUTE.equals(eventType)) {
							parser = ParserFactory.getParser("JSON");
							try {
								chargeDisputeRequest = (ChargeDisputeRequest) parser.parse(requestMessage, eventType);
							} catch (Exception e) {

								logger.error("Unable to parse ChargeDisputeRequest Exception", e);
							}
						} else if (AppConstants.CHEQUE_BOUNCE_REQUEST.equals(eventType)) {
							parser = ParserFactory.getParser("JSON");
							try {
								chequeBounceRequest = (ChequeBounceRequest) parser.parse(requestMessage, eventType);
							} catch (Exception e) {

								logger.error("Unable to parse ChequeBounceRequest Exception", e);
							}
						} else if (AppConstants.CHEQUE_STOP_PAYMENT_REQUEST.equals(eventType)) {
							parser = ParserFactory.getParser("JSON");
							try {
								chequeStopPaymentRequest = (ChequeStopPaymentRequest) parser.parse(requestMessage,
										eventType);
							} catch (Exception e) {

								logger.error("Unable to parse ChequeStopPaymentRequest Exception", e);
							}
						} else if (AppConstants.CPO_CALL_END.equals(eventType)) {
							parser = ParserFactory.getParser("JSON");
							try {
								cpoCallEndRequest = (CpoCallEndRequest) parser.parse(requestMessage, eventType);
							} catch (Exception e) {

								logger.error("Unable to parse CpoCallEndRequest Exception", e);
							}
						} else if (AppConstants.CPO_CALL_START.equals(eventType)) {
							parser = ParserFactory.getParser("JSON");
							try {
								cpoCallStartRequest = (CpoCallStartRequest) parser.parse(requestMessage, eventType);
							} catch (Exception e) {

								logger.error("Unable to parse CpoCallStartRequest Exception", e);
							}
						} else if (AppConstants.CREDIT_CARD_CLOSURE.equals(eventType)) {
							parser = ParserFactory.getParser("JSON");
							try {
								creditCardClosureRequest = (CreditCardClosureRequest) parser.parse(requestMessage,
										eventType);
							} catch (Exception e) {

								logger.error("Unable to parse CreditCardClosureRequest Exception", e);
							}
						} else if (AppConstants.CREDIT_CARD_REVERSAL.equals(eventType)) {
							parser = ParserFactory.getParser("JSON");
							try {
								creditCardReversalRequest = (CreditCardReversalRequest) parser.parse(requestMessage,
										eventType);
							} catch (Exception e) {

								logger.error("Unable to parse CreditCardReversalRequest Exception", e);
							}
						} else if (AppConstants.CREDIT_LIMIT_INCREASE.equals(eventType)) {
							parser = ParserFactory.getParser("JSON");
							try {
								creditLimitIncreaseRequest = (CreditLimitIncreaseRequest) parser.parse(requestMessage,
										eventType);
							} catch (Exception e) {

								logger.error("Unable to parse CreditLimitIncreaseRequest Exception", e);
							}
						} else if (AppConstants.CUST_HW_TOKEN.equals(eventType)) {
							parser = ParserFactory.getParser("JSON");
							try {
								custHWTokenRequest = (CustHWTokenRequest) parser.parse(requestMessage, eventType);
							} catch (Exception e) {

								logger.error("Unable to parse CustHWTokenRequest Exception", e);
							}
						} else if (AppConstants.CUST_LOGIN_ID_STATUS_CHANGE.equals(eventType)) {
							parser = ParserFactory.getParser("JSON");
							try {
								custLoginIDStatusChangeRequest = (CustLoginIDStatusChangeRequest) parser
										.parse(requestMessage, eventType);
							} catch (Exception e) {

								logger.error("Unable to parse CustLoginIDStatusChangeRequest Exception", e);
							}
						} else if (AppConstants.CUSTOMER_LOGIN.equals(eventType)) {
							parser = ParserFactory.getParser("JSON");
							try {
								customerLoginRequest = (CustomerLoginRequest) parser.parse(requestMessage, eventType);
							} catch (Exception e) {

								logger.error("Unable to parse CustomerLoginRequest Exception", e);
							}
						} else if (AppConstants.DEMOGRAPHIC_CHANGE.equals(eventType)) {
							parser = ParserFactory.getParser("JSON");
							try {
								demographicChangeRequest = (DemographicChangeRequest) parser.parse(requestMessage,
										eventType);
							} catch (Exception e) {

								logger.error("Unable to parse DemographicChangeRequest Exception", e);
							}
						} else if (AppConstants.DIGIPASS_INITIATION.equals(eventType)) {
							parser = ParserFactory.getParser("JSON");
							try {
								digiPassInitiationRequest = (DigiPassInitiationRequest) parser.parse(requestMessage,
										eventType);
							} catch (Exception e) {

								logger.error("Unable to parse DigiPassInitiationRequest Exception", e);
							}
						} else if (AppConstants.EPPLOP_OFFER_VIEW.equals(eventType)) {
							parser = ParserFactory.getParser("JSON");
							try {
								epplopOfferViewRequest = (EPPLOPOfferViewRequest) parser.parse(requestMessage,
										eventType);
							} catch (Exception e) {

								logger.error("Unable to parse EPPLOPOfferViewRequest Exception", e);
							}
						} else if (AppConstants.ESTATEMENT_DISPATCH.equals(eventType)) {
							parser = ParserFactory.getParser("JSON");
							try {
								estatementDispatchRequest = (EstatementDispatchRequest) parser.parse(requestMessage,
										eventType);
							} catch (Exception e) {

								logger.error("Unable to parse EstatementDispatchRequest Exception", e);
							}
						} else if (AppConstants.ESTATEMENT_VIEW.equals(eventType)) {
							parser = ParserFactory.getParser("JSON");
							try {
								estatementViewRequest = (EstatementViewRequest) parser.parse(requestMessage, eventType);
							} catch (Exception e) {

								logger.error("Unable to parse EstatementViewRequest request Exception", e);
							}
						} else if (AppConstants.FORGOT_USERID_AND_PASSWORD.equals(eventType)) {
							parser = ParserFactory.getParser("JSON");
							try {
								forgotUserIdAndPasswordRequest = (ForgotUserIdAndPasswordRequest) parser
										.parse(requestMessage, eventType);
							} catch (Exception e) {

								logger.error("Unable to parse ForgotUserIdAndPasswordRequest Exception", e);
							}
						} else if (AppConstants.IVR_CALL_END.equals(eventType)) {
							parser = ParserFactory.getParser("JSON");
							try {
								ivrCallEndRequest = (IVRCallEndRequest) parser.parse(requestMessage, eventType);
							} catch (Exception e) {

								logger.error("Unable to parse IVRCallEndRequest Exception", e);
							}
						} else if (AppConstants.IVR_CALL_START.equals(eventType)) {
							parser = ParserFactory.getParser("JSON");
							try {
								ivrCallStartRequest = (IVRCallStartRequest) parser.parse(requestMessage, eventType);
							} catch (Exception e) {

								logger.error("Unable to parse IVRCallStartRequest Exception", e);
							}
						} else if (AppConstants.ONLINE_DIRECT_DEBIT_EXEC.equals(eventType)) {
							parser = ParserFactory.getParser("JSON");
							try {
								onlineDirectDebitExecutionRequest = (OnlineDirectDebitExecutionRequest) parser
										.parse(requestMessage, eventType);
							} catch (Exception e) {

								logger.error("Unable to parse OnlineDirectDebitExecutionRequest Exception", e);
							}
						} else if (AppConstants.OVERSEAS_ACTIVATION.equals(eventType)) {
							parser = ParserFactory.getParser("JSON");
							try {
								overseasCardActivationRequest = (OverseasCardActivationRequest) parser
										.parse(requestMessage, eventType);
							} catch (Exception e) {

								logger.error("Unable to parse OverseasCardActivationRequest Exception", e);
							}
						} else if (AppConstants.PAYMENT_AND_TRANSFER.equals(eventType)) {
							parser = ParserFactory.getParser("JSON");
							try {
								paymentAndTransferRequest = (PaymentAndTransferRequest) parser.parse(requestMessage,
										eventType);
							} catch (Exception e) {

								logger.error("Unable to parse PaymentAndTransferRequest Exception", e);
							}
						} else if (AppConstants.PIN_VALIDATION.equals(eventType)) {
							parser = ParserFactory.getParser("JSON");
							try {
								pinValidationRequest = (PINValidationRequest) parser.parse(requestMessage, eventType);
							} catch (Exception e) {

								logger.error("Unable to parse PINValidationRequest Exception", e);
							}
						} else if (AppConstants.PRE_AUTH.equals(eventType)) {
							parser = ParserFactory.getParser("JSON");
							try {
								preAuthRequest = (PreAuthRequest) parser.parse(requestMessage, eventType);
							} catch (Exception e) {

								logger.error("Unable to parse PreAuthRequest Exception", e);
							}
						} else if (AppConstants.REPORT_LOST_STOLEN.equals(eventType)) {
							parser = ParserFactory.getParser("JSON");
							try {
								reportLostStolenRequest = (ReportLostStolenRequest) parser.parse(requestMessage,
										eventType);
							} catch (Exception e) {

								logger.error("Unable to parse ReportLostStolenRequest Exception", e);
							}
						} else if (AppConstants.REWARD_REDEMPTION_ACCESS.equals(eventType)) {
							parser = ParserFactory.getParser("JSON");
							try {
								rewardRedemptionAccessRequest = (RewardRedemptionAccessRequest) parser
										.parse(requestMessage, eventType);
							} catch (Exception e) {

								logger.error("Unable to parse RewardRedemptionAccessRequest Exception", e);
							}
						} else if (AppConstants.REWARD_REDEMPTION_REQUEST.equals(eventType)) {
							parser = ParserFactory.getParser("JSON");
							try {
								rewardRedemptionRequestRequest = (RewardRedemptionRequestRequest) parser
										.parse(requestMessage, eventType);
							} catch (Exception e) {

								logger.error("Unable to parse RewardRedemptionRequestRequest Exception", e);
							}
						} else if (AppConstants.SDN_MATCH_FOUND.equals(eventType)) {
							parser = ParserFactory.getParser("JSON");
							try {
								sdnMatchFoundRequest = (SDNMatchFoundRequest) parser.parse(requestMessage, eventType);
							} catch (Exception e) {

								logger.error("Unable to parse SDNMatchFoundRequest Exception", e);
							}
						} else if (AppConstants.SDN_MATCH_RESOLVED.equals(eventType)) {
							parser = ParserFactory.getParser("JSON");
							try {
								sdnMatchResolvedRequest = (SDNMatchResolvedRequest) parser.parse(requestMessage,
										eventType);
							} catch (Exception e) {

								logger.error("Unable to parse SDNMatchResolvedRequest Exception", e);
							}
						} else if (AppConstants.SERVICE_REQUEST.equals(eventType)) {
							parser = ParserFactory.getParser("JSON");
							try {
								serviceRequestRequest = (ServiceRequestRequest) parser.parse(requestMessage, eventType);
							} catch (Exception e) {

								logger.error("Unable to parse ServiceRequestRequest Exception", e);
							}
						} else if (AppConstants.SMS_EMAIL_OFFERS.equals(eventType)) {
							parser = ParserFactory.getParser("JSON");
							try {
								smsEmailOffersRequest = (SMSEmailOffersRequest) parser.parse(requestMessage, eventType);
							} catch (Exception e) {

								logger.error("Unable to parse SMSEmailOffersRequest Exception", e);
							}
						} else if (AppConstants.TPIN_CREATE_RESET_CHANGE_ISSUANCE.equals(eventType)) {
							parser = ParserFactory.getParser("JSON");
							try {
								tpinCreateResetChangeIssuanceRequest = (TPINCreateResetChangeIssuanceRequest) parser
										.parse(requestMessage, eventType);
							} catch (Exception e) {

								logger.error("Unable to parse TPINCreateResetChangeIssuanceRequest Exception", e);
							}
						} else if (AppConstants.VIEW_TRANSACTION_HISTORY.equals(eventType)) {
							parser = ParserFactory.getParser("JSON");
							try {
								viewTransactionsHistoryRequest = (ViewTransactionsHistoryRequest) parser
										.parse(requestMessage, eventType);
							} catch (Exception e) {

								logger.error("Unable to parse ViewTransactionsHistoryRequest Exception", e);
							}
						} else if (eventType.startsWith(AppConstants.CB_MRE)) {
							parser = ParserFactory.getParser("XML");
							try {
								transactionMREReq = (TransactionMREReq) parser.parse(requestMessage, eventType);
								
								logger.info("parse message>>>>>>>>>>>>>>>." +transactionMREReq);
								
							} catch (Exception e) {

								logger.error("Unable to parse request Exception", e);
							}
						} else if (eventType.startsWith(AppConstants.EPP)) {
							parser = ParserFactory.getParser("XML");
							try {
								copeapRequest = (COPEAPRequest) parser.parse(requestMessage, eventType);
							} catch (Exception e) {

								logger.error("Unable to parse request Exception", e);
							}
						} else if (eventType.equals(AppConstants.EPP_MOD)) {
							parser = ParserFactory.getParser("XML");
							try {
								eAPModelOffer = (EAPModelOffer) parser.parse(requestMessage, eventType);
							} catch (Exception e) {

								logger.error("Unable to parse request Exception", e);
							}
						} else if (eventType.equals(AppConstants.EPP_PROD)) {
							parser = ParserFactory.getParser("XML");
							try {
								eAPProdOfferTemplate = (EAPProdOfferTemplate) parser.parse(requestMessage, eventType);
							} catch (Exception e) {

								logger.error("Unable to parse request Exception", e);
							}

						} else if (eventType.equals(AppConstants.EPP_TRT)) {
							parser = ParserFactory.getParser("XML");
							try {
								// logger.info("rEQUEST MESSSAGE>>>>>>>>>"
								// +requestMessage);
								eAPTreatmentTemplate = (EAPTreatmentTemplate) parser.parse(requestMessage, eventType);
								// logger.info("PARSE
								// EVENET>>>>>>>>>>>>>>>>>>>:"
								// +eAPTreatmentTemplate);

							} catch (Exception e) {

								logger.error("Unable to parse request Exception", e);
							}

						} else if (eventType.equals(AppConstants.EPP_UOF)) {
							parser = ParserFactory.getParser("XML");
							try {
								updateOfferFullfillmentEapRequest = (UpdateOfferFullfillmentEapRequest) parser
										.parse(requestMessage, eventType);
							} catch (Exception e) {

								logger.error("Unable to parse request Exception", e);
							}
						} else {
							try {
								throw new RuntimeException("Unknown Event Type Found: " + eventType);
							} catch (Exception e) {
								logger.error("Unknown Event Type Found: " + eventType);
							}
						}

					} else if (AppConstants.CALL_PYTHON_SCRIPT.equals(actionType)) {

						MessageParser parser = null;
						parser = ParserFactory.getParser("JSON");
						try {

							ivrCallLogin = (IVRCallLogin) parser.parse(requestMessage, eventType);
							//System.out.println(">>>>>>>>Parseeeeeee inside Python>>>>" + ivrCallLogin);
						} catch (Exception e) {
							logger.error("IVRCallLogin", e);
						}

						copyFromHdfsToLocal();
					
						// String salt = appProps.get(SysConstants.PWP_SALT);
					//	String mongoDBPassword = appProps.get(SysConstants.MONGO_DB_PASSWORD);
					//	String mongo_password = pwpUtilMain.decrypt(salt, mongoDBPassword);
						String python_path = appProps.get(SysConstants.PYTHON_PATH);
						String python_code = appProps.get(SysConstants.PYTHON_SCRIPT);
						String conf_file = appProps.get(SysConstants.PYTHON_CONF_FILE);
						String config_section_name = appProps.get(SysConstants.PYTHON_CONF_SECTION_NAME);
						String mongopass = mongo_Password;
						// String python_code =
						// "/data/1/gcgdma/bin/apps/IVR/RT/EAP/code/ivr_model_context.py";
						// String conf_file =
						// "/home/ss36531/IVR/ivr_model_context.conf";
						// String config_section_name= "eap_dev";
						String customerid = ivrCallLogin.getEvent().getStandard().getCustomerID();
						String serverDateTime = ivrCallLogin.getEvent().getStandard().getServerDateTime();
						// python35 /home/ss36531/IVR/ivr_model_context.py
						// 75002246 "2018-05-10 00:07:18.555"
						// /home/ss36531/IVR/ivr_model_context.conf eap_dev
						if (appProps.get(SysConstants.PYTHON_SAVING_SCORING_OUTPUT).equals(SysConstants.YES_IND)){
							callPythonScript(python_path,serverDateTime, python_code, conf_file, config_section_name, customerid, mongopass);

						}else{
							callPythonScriptWithoutSaveScore(python_path,serverDateTime, python_code, conf_file, config_section_name, customerid, mongopass);
						}

					//	callPythonScript(python_path,requestDateTime, python_code, conf_file, config_section_name, customerid, mongopass);

					}

					else if (AppConstants.SAVE_MONGO.equals(actionType)) {
						Map<String, String> mongoDBConfiguration = getMongoConfigs(a.getEventActionDetails());
						MongoDBService mongoService = null;
					
						try {
							mongoService = MongoDBService.getInstance(mongoDBConfiguration);
						} catch (Exception e) {

							logger.error("Unable to get instance of MongoDbService", e);
						}
						collectionName = mongoDBConfiguration.get(AppConstants.MONGODB_DB_COLLECTION);

						if (AppConstants.EPP_POSS_RES.equals(eventType)) {
							long timestamp = requestObj.getTimeStamp();

							String feedbackTime = formatDate(System.currentTimeMillis(),
									AppConstants.TIMESTAMP_DATE_FORMAT);
							String requestTime = formatDate(timestamp, AppConstants.TIMESTAMP_DATE_FORMAT);

							possibleReasonResponseLog.setResponse_dt_time(feedbackTime);
							possibleReasonResponseLog.setRequest_dt_time(requestTime);
							possibleReasonResponseLog.setResponse_queue(tibcoConfig.get(AppConstants.QUEUE_NAME));
							possibleReasonResponseLog.setRequest_queue(requestQueueName);
							possibleReasonResponseLog.setMessage_id(requestMessageId);
							try {
								requestMessage = convertObjectToJson(possibleReasonResponseLog, eventType, true);
							} catch (Exception e) {

								logger.error("Unable to convert object to JSON", e);
							}
						} else if (eventType.startsWith(AppConstants.CB_MRE)) {

							try {
								transactionMREReq.setRequestDateTime(requestDateTime);
								transactionMREReq.setResponseFlag("N");
								requestMessage = convertObjectToJson(transactionMREReq, eventType, true);
								
								logger.info("inside save mongo >>>>>>>>>>>....." +requestMessage);
							} catch (Exception e) {

								logger.error("Unable to convert object to JSON", e);
							}
						} else if (eventType.startsWith(AppConstants.EPP)) {

							try {
								copeapRequest.setCopRequestDateTime(requestDateTime);
								requestMessage = convertObjectToJson(copeapRequest, eventType, true);
							} catch (Exception e) {

								logger.error("Unable to convert object to JSON", e);
							}
						} else if (eventType.startsWith(AppConstants.EPP_MOD)) {

							try {
								requestMessage = convertObjectToJson(eAPModelOffer, eventType, true);
							} catch (Exception e) {

								logger.error("Unable to convert object to JSON", e);
							}
						} else if (eventType.startsWith(AppConstants.EPP_PROD)) {

							try {
								requestMessage = convertObjectToJson(eAPProdOfferTemplate, eventType, true);
							} catch (Exception e) {

								logger.error("Unable to convert object to JSON", e);
							}
						} else if (eventType.startsWith(AppConstants.EPP_TRT)) {

							try {
								requestMessage = convertObjectToJson(eAPTreatmentTemplate, eventType, true);
								// logger.info("JSON MESSAGE: >>>>>>>>>>>>>>.."
								// +requestMessage);
							} catch (Exception e) {

								logger.error("Unable to convert object to JSON", e);
							}
						} else if (eventType.startsWith(AppConstants.EPP_UOF)) {

							try {
								requestMessage = convertObjectToJson(updateOfferFullfillmentEapRequest, eventType,
										true);
							} catch (Exception e) {

								logger.error("Unable to convert object to JSON", e);
							}
						}

						mongoService.SaveDocument(collectionName, requestMessage);
						logger.info(">>>>>>>>>>>>>>>>>>>>...inside Save Mongo" + requestMessage);

					} else if (AppConstants.LOOKUP.equals(actionType)) {

						// Checking if date is back dated or not
						// String transactionDateString =
						// formatDate(transactionMREReq.getTransaction().getTransactionDetail().getTransactionDate().toGregorianCalendar());
						
						logger.info("inside lookuppppppppppp>"+transactionMREReq);
						Date transactionDate = transactionMREReq.getTransaction().getTransactionDetail().getTransactionDate().toGregorianCalendar().getTime();
						// Date transactionDate =
						
						ZonedDateTime now = ZonedDateTime.now();
						ZonedDateTime thirtyDaysAgo = now.plusDays(-50);
						if (transactionDate == null) {
							geoRecommendationString = AppConstants.DEFAULT_RESPONSE;
							nonGeoRecommendationString = AppConstants.DEFAULT_RESPONSE;
							transactionMREFlatRes.setStatus(AppConstants.INVALID_REQUEST);
						} else {
							if (transactionDate.toInstant().isBefore(thirtyDaysAgo.toInstant())) {
								transactionMREFlatRes.setStatus(AppConstants.BACK_DATED_REQUEST);
								geoRecommendationString = AppConstants.DEFAULT_RESPONSE;
								nonGeoRecommendationString = AppConstants.DEFAULT_RESPONSE;
								logger.info(">>>>>>>>>>>>>>>>>>>>>>>back dated request");
							} else {

								// Checking if crdAcceptRec or CustomerNumber
								// are null or blank
								String cardAcceptRec = transactionMREReq.getTransaction().getTransactionCard()
										.getCRDAcceptRec();

								String customerNumber = transactionMREReq.getCustomerNo();

								if (cardAcceptRec != "" || cardAcceptRec != null || customerNumber != ""
										|| customerNumber != null) {

									Map<String, String> mongoDBConfiguration = getMongoConfigs(
											a.getEventActionDetails());
									MongoDBService mongoService = null;
									try {
										mongoService = MongoDBService.getInstance(mongoDBConfiguration);
									} catch (Exception e) {

										logger.error("Unable to get instance of MongoDbService", e);
									}
									collectionName = mongoDBConfiguration.get(AppConstants.MONGODB_DB_COLLECTION);
									String[] collectionNames = collectionName.split(",");

									List<String> merchantDescList = mongoService
											.retriveMerchantDescription(transactionMREReq, collectionNames[0]);
									
									logger.info("MERCHANT DESCRIPTION LIST>>>>................" +merchantDescList);

									if (merchantDescList.size() > 0) {

										List<String> checkList = new ArrayList<String>();
										List<String> merchantNameList = new ArrayList<String>();
										for (String merchantDesc : merchantDescList) {
											String merchantDescTrimmed = merchantDesc.toUpperCase().trim()
													.replaceAll("( )+", " ");
											if (checkList.contains(merchantDescTrimmed)) {
												continue;
											} else {
												logger.info("MERCHANT DESCRIPTION trimmmed>>>>................" +merchantDescTrimmed);	
												String merchantName = mongoService.retriveMerchantName(
														transactionMREReq, merchantDescTrimmed, collectionNames[1],
														collectionNames[4]);
												if (!(merchantName.isEmpty() || merchantName == null
														|| merchantName.equals(""))) {

													checkList.add(merchantDescTrimmed);
													merchantNameList.add(merchantName);
												} else {
													logger.info(">No Merchant Name Found ");
												}
											}
										}
										
										logger.info("MERCHANT NAME LIST>>>>................" +merchantNameList);

										if (merchantNameList.size() > 0) {
											geoRecommendationString = mongoService.lookUpGeo(transactionMREReq,
													merchantNameList, collectionNames[2], collectionNames[3],
													collectionNames[4]);
											
											nonGeoRecommendationString = mongoService.lookUpNonGeo(transactionMREReq,
													merchantNameList, collectionNames[2], collectionNames[3],
													collectionNames[4]);
											
											transactionMREFlatRes.setStatus(AppConstants.SUCCESSFUL_PUBLSIH);
											
										} else {
											geoRecommendationString = AppConstants.DEFAULT_RESPONSE;
											nonGeoRecommendationString = AppConstants.DEFAULT_RESPONSE;
											transactionMREFlatRes.setStatus(AppConstants.DEFAULT_PUBLSIH);
											logger.error(
													">>>>>>>>>> No Valid Merchant Found for Lookup Logic >>>>>>>>>>>>>>>> ");
										}
									} else {
										geoRecommendationString = AppConstants.DEFAULT_RESPONSE;
										nonGeoRecommendationString = AppConstants.DEFAULT_RESPONSE;
										transactionMREFlatRes.setStatus(AppConstants.DEFAULT_PUBLSIH);
										logger.error(">>>>>>>>>> Could not perform Lookup Logic >>>>>>>>>>>>>>>>");
									}
								} else {
									geoRecommendationString = AppConstants.DEFAULT_RESPONSE;
									nonGeoRecommendationString = AppConstants.DEFAULT_RESPONSE;
									transactionMREFlatRes.setStatus(AppConstants.INVALID_REQUEST);
								}
							}
						}

					} else if (AppConstants.CALL_PYTHON_CODE.equals(actionType)) {
						Map<String, String> mongoDBConfiguration = getMongoConfigs(a.getEventActionDetails());
						collectionName = mongoDBConfiguration.get(AppConstants.MONGODB_DB_COLLECTION);
						MongoDBService mongoService = null;
						try {
							mongoService = MongoDBService.getInstance(mongoDBConfiguration);
						} catch (Exception e) {

							logger.error("Unable to get instance of MongoDbService", e);
						}
						Map<String, String> scoreMap = mongoService.lookupScore(copeapRequest.getCustomerNo(),
								collectionName);
						if (scoreMap.size() > 0) {

							/*
							 * copeapResponse.setCOPUUID(copeapRequest.
							 * getCOPUUID());
							 * copeapResponse.setECRMPrdCode(copeapRequest.
							 * getECRMPrdCode());
							 */
							copeapResponse.setScore(scoreMap.get("score"));
							copeapResponse.setTreatmentId(scoreMap.get("tempalte_id"));
							copeapResponse.setRecommendationType("N");
							copeapResponse.setFollowupDays("");
							copeapResponse.setModelReasonCode(copeapRequest.getCOPSReasonCode());
							copeapResponse.setModelReasonDescription(copeapRequest.getCOPSReasonDescription());

						} else {
							/*
							 * copeapResponse.setCOPUUID(copeapRequest.
							 * getCOPUUID());
							 * copeapResponse.setECRMPrdCode(copeapRequest.
							 * getECRMPrdCode());
							 */
							copeapResponse.setScore("");
							copeapResponse.setTreatmentId("");
							copeapResponse.setRecommendationType("N");
							copeapResponse.setFollowupDays("");
							copeapResponse.setModelReasonCode(copeapRequest.getCOPSReasonCode());
							copeapResponse.setModelReasonDescription(copeapRequest.getCOPSReasonDescription());

						}

					} else if (AppConstants.PUB_TIBCO.equals(actionType)) {
						if (errorCode.equals("")) {
							errorCode = "200";
							errorDescription = "Success";
						}
						String jsondata = null;
						if (eventType.startsWith(AppConstants.CB_MRE)) {

							try {
								BeanUtils.copyProperties(transactionMRERes, transactionMREReq);
							} catch (Exception e) {

								logger.error("Unable to copy objects", e);
							}

							// transactionMREReq.getGeoRecommendation();

							transactionMRERes.setGeoMerchantID(geoRecommendationString);
							// transactionMRERes.setNonGeoMerchantID("");
							// transactionMREReq.getNonGeoRecommendation();
							transactionMRERes.setNonGeoMerchantID(nonGeoRecommendationString);
							// transactionMRERes.setGeoMerchantID("");

							try {
								jsondata = JAXBHelperFunction.marshal(transactionMRERes, eventType);
							} catch (Exception e) {

								logger.error("Unable to convert object to JSON", e);
							}
						} else if (eventType.startsWith(AppConstants.EPP)) {

							try {
								BeanUtils.copyProperties(copeapResponse, copeapRequest);
							} catch (Exception e) {

								logger.error("Unable to copy objects", e);
							}

							// SET EXTRA FEILDS IN RESPONSE

							try {
								jsondata = JAXBHelperFunction.marshal(copeapResponse, eventType);
							} catch (Exception e) {

								logger.error("Unable to convert object to JSON", e);
							}
						} else {
							responseBody.setErrorcode(errorCode);
							responseBody.setErrordescription(errorDescription);
							possibleReasonResponseLog.setErrorcode(errorCode);
							possibleReasonResponseLog.setErrordescription(errorDescription);
							try {
								jsondata = convertObjectToJson(responseBody, eventType, false);
							} catch (Exception e) {

								logger.error("Unable to convert object to JSON", e);
							}
						}

						tibcoConfig = getTibcoConfigs(a.getEventActionDetails());
						if (tibcoConfig.get(AppConstants.P12_ENABLED).equals("false")) {
							try {
								TibcoJMSService.getInstance(tibcoConfig, _tibcoPassword).publish(jsondata,
										requestMessageId);
							} catch (Exception e) {

								logger.error("Unable to publish to tibco", e);
							}

						} else {
							try {
								TibcoEMSService.getInstance(tibcoConfig, _tibcoPassword).publish(jsondata,
										requestMessageId);
							} catch (Exception e) {

								logger.info("Unable to publish to tibco EMS queue>>>>>>>>>>>>>>>> SSL Based", e);
							}

						}
					} else if (AppConstants.SAVE_FLAT_MONGO.equals(actionType)) {

						if (eventType.startsWith(AppConstants.CB_MRE)) {
							transactionMREFlatRes = flattenRequest.getTransactionMREFlatRes(transactionMREFlatRes,
									transactionMRERes);
							String responseDateTime = formatDate(System.currentTimeMillis(),
									AppConstants.TIMESTAMP_DATE_FORMAT);
							copTransactionID = transactionMRERes.getCOPTransactionID();

							transactionMREFlatRes.setRequestDateTime(transactionMREReq.getRequestDateTime());
							transactionMREFlatRes.setResponseDateTime(responseDateTime);
							try {
								flattenedString = convertObjectToJson(transactionMREFlatRes, eventType, false);
							} catch (Exception e) {

								logger.error("Unable to convert object to JSON", e);
							}

						} else if (eventType.startsWith(AppConstants.EPP)) {
							// transactionMREFlatRes =
							// flattenRequest.getTransactionMREFlatRes(transactionMRERes);
							try {
								String responseDateTime = formatDate(System.currentTimeMillis(),
										AppConstants.TIMESTAMP_DATE_FORMAT);
								copeapResponse.setCopResponseDateTime(responseDateTime);
								flattenedString = convertObjectToJson(copeapResponse, eventType, false);
							} catch (Exception e) {

								logger.error("Unable to convert object to JSON", e);
							}
						} else if (eventType.equals(AppConstants.CARD_ACTIVATION)) {
							CardActivationFlat cardActivationFlat = flattenRequest
									.getCardActivationFlat(cardActivationRequest);
							try {
								flattenedString = convertObjectToJson(cardActivationFlat, eventType, false);
							} catch (Exception e) {

								logger.error("Unable to convert object to JSON", e);
							}
						} else if (eventType.equals(AppConstants.ACCOUNT_LINKAGE)) {
							AccountLinkageFlat accountLinkageFlat = flattenRequest
									.getAccountLinkageFlat(accountLinkageRequest);
							try {
								flattenedString = convertObjectToJson(accountLinkageFlat, eventType, false);
							} catch (Exception e) {

								logger.error("Unable to convert object to JSON", e);
							}
						} else if (eventType.equals(AppConstants.ACCOUNT_SUMMARY)) {
							AccountSummaryFlat accountSummaryFlat = flattenRequest
									.getAccountSummaryFlat(accountSummaryRequest);
							try {
								flattenedString = convertObjectToJson(accountSummaryFlat, eventType, false);
							} catch (Exception e) {

								logger.error("Unable to convert object to JSON", e);
							}
						} else if (eventType.equals(AppConstants.APIN_CHANGE)) {
							APINChangeFlat apinChangeFlat = flattenRequest.getAPINChangeFlat(apinChangeRequest);
							try {
								flattenedString = convertObjectToJson(apinChangeFlat, eventType, false);
							} catch (Exception e) {

								logger.error("Unable to convert object to JSON", e);
							}
						} else if (eventType.equals(AppConstants.BILL_PAYMENT)) {
							BillPaymentFlat billPaymentFlat = flattenRequest.getBillPaymentFlat(billPaymentRequest);
							try {
								flattenedString = convertObjectToJson(billPaymentFlat, eventType, false);
							} catch (Exception e) {

								logger.error("Unable to convert object to JSON", e);
							}
						} else if (eventType.equals(AppConstants.CARD_BLOCK_CODE_UPDATE)) {
							CardBlockCodeUpdateFlat cardBlockCodeUpdateFlat = flattenRequest
									.getCardBlockCodeUpdateFlat(cardBlockCodeUpdateRequest);
							try {
								flattenedString = convertObjectToJson(cardBlockCodeUpdateFlat, eventType, false);
							} catch (Exception e) {

								logger.error("Unable to convert object to JSON", e);
							}
						} else if (eventType.equals(AppConstants.CARD_DECLINE)) {
							CardDeclineFlat cardDeclineFlat = flattenRequest.getCardDeclineFlat(cardDeclineRequest);
							try {
								flattenedString = convertObjectToJson(cardDeclineFlat, eventType, false);
							} catch (Exception e) {

								logger.error("Unable to convert object to JSON", e);
							}
						} else if (eventType.equals(AppConstants.CBOL_MBOL_REGISTRATION)) {
							CBOLMBOLRegistrationFlat cbolmbolFlat = flattenRequest
									.getCBOLMBOLRegistrationFlat(cbolmbolRegistrationRequest);
							try {
								flattenedString = convertObjectToJson(cbolmbolFlat, eventType, false);
							} catch (Exception e) {

								logger.error("Unable to convert object to JSON", e);
							}
						} else if (eventType.equals(AppConstants.CHARGE_DISPUTE)) {
							ChargeDisputeFlat chargeDisputeFlat = flattenRequest
									.getChargeDisputeFlat(chargeDisputeRequest);
							try {
								flattenedString = convertObjectToJson(chargeDisputeFlat, eventType, false);
							} catch (Exception e) {

								logger.error("Unable to convert object to JSON", e);
							}
						} else if (eventType.equals(AppConstants.CHEQUE_BOUNCE_REQUEST)) {
							ChequeBounceFlat chequeBounceFlat = flattenRequest.getChequeBounceFlat(chequeBounceRequest);
							try {
								flattenedString = convertObjectToJson(chequeBounceFlat, eventType, false);
							} catch (Exception e) {

								logger.error("Unable to convert object to JSON", e);
							}
						} else if (eventType.equals(AppConstants.CHEQUE_STOP_PAYMENT_REQUEST)) {
							ChequeStopPaymentFlat chequeStopPaymentFlat = flattenRequest
									.getChequeStopPaymentFlat(chequeStopPaymentRequest);
							try {
								flattenedString = convertObjectToJson(chequeStopPaymentFlat, eventType, false);
							} catch (Exception e) {

								logger.error("Unable to convert object to JSON", e);
							}
						} else if (eventType.equals(AppConstants.CPO_CALL_END)) {
							CpoCallEndFlat cpoCallEndFlat = flattenRequest.getCpoCallEndFlat(cpoCallEndRequest);
							try {
								flattenedString = convertObjectToJson(cpoCallEndFlat, eventType, false);
							} catch (Exception e) {

								logger.error("Unable to convert object to JSON", e);
							}
						} else if (eventType.equals(AppConstants.CPO_CALL_START)) {
							CpoCallStartFlat cpoCallStartFlat = flattenRequest.getCpoCallStartFlat(cpoCallStartRequest);
							try {
								flattenedString = convertObjectToJson(cpoCallStartFlat, eventType, false);
							} catch (Exception e) {

								logger.error("Unable to convert object to JSON", e);
							}
						} else if (eventType.equals(AppConstants.CREDIT_CARD_CLOSURE)) {
							CreditCardClosureFlat creditCardClosureFlat = flattenRequest
									.getCreditCardClosureFlat(creditCardClosureRequest);
							try {
								flattenedString = convertObjectToJson(creditCardClosureFlat, eventType, false);
							} catch (Exception e) {

								logger.error("Unable to convert object to JSON", e);
							}
						} else if (eventType.equals(AppConstants.CREDIT_CARD_REVERSAL)) {
							CreditCardReversalFlat creditCardReversalFlat = flattenRequest
									.getCreditCardReversalFlat(creditCardReversalRequest);
							try {
								flattenedString = convertObjectToJson(creditCardReversalFlat, eventType, false);
							} catch (Exception e) {

								logger.error("Unable to convert object to JSON", e);
							}
						} else if (eventType.equals(AppConstants.CREDIT_LIMIT_INCREASE)) {
							CreditLimitIncreaseFlat creditLimitIncreaseFlat = flattenRequest
									.getCreditLimitIncreaseFlat(creditLimitIncreaseRequest);
							try {
								flattenedString = convertObjectToJson(creditLimitIncreaseFlat, eventType, false);
							} catch (Exception e) {

								logger.error("Unable to convert object to JSON", e);
							}
						} else if (eventType.equals(AppConstants.CUST_HW_TOKEN)) {
							CustHWTokenFlat custHWTokenFlat = flattenRequest.getCustHWTokenFlat(custHWTokenRequest);
							try {
								flattenedString = convertObjectToJson(custHWTokenFlat, eventType, false);
							} catch (Exception e) {

								logger.error("Unable to convert object to JSON", e);
							}
						} else if (eventType.equals(AppConstants.CUST_LOGIN_ID_STATUS_CHANGE)) {
							CustLoginIDStatusChangeFlat custLoginIDStatusChangeFlat = flattenRequest
									.getCustLoginIDStatusChangeFlat(custLoginIDStatusChangeRequest);
							try {
								flattenedString = convertObjectToJson(custLoginIDStatusChangeFlat, eventType, false);
							} catch (Exception e) {

								logger.error("Unable to convert object to JSON", e);
							}
						} else if (eventType.equals(AppConstants.CUSTOMER_LOGIN)) {
							CustomerLoginFlat customerLoginFlat = flattenRequest
									.getCustomerLoginFlat(customerLoginRequest);
							try {
								flattenedString = convertObjectToJson(customerLoginFlat, eventType, false);
							} catch (Exception e) {

								logger.error("Unable to convert object to JSON", e);
							}
						} else if (eventType.equals(AppConstants.DEMOGRAPHIC_CHANGE)) {
							DemographicChangeFlat demographicChangeFlat = flattenRequest
									.getDemographicChangeFlat(demographicChangeRequest);
							try {
								flattenedString = convertObjectToJson(demographicChangeFlat, eventType, false);
							} catch (Exception e) {

								logger.error("Unable to convert object to JSON", e);
							}
						} else if (eventType.equals(AppConstants.DIGIPASS_INITIATION)) {
							DigiPassInitiationFlat digiPassInitiationFlat = flattenRequest
									.getDigiPassInitiationFlat(digiPassInitiationRequest);
							try {
								flattenedString = convertObjectToJson(digiPassInitiationFlat, eventType, false);
							} catch (Exception e) {

								logger.error("Unable to convert object to JSON", e);
							}
						} else if (eventType.equals(AppConstants.EPPLOP_OFFER_VIEW)) {
							EPPLOPOfferViewFlat epplopOfferViewFlat = flattenRequest
									.getEPPLOPOfferViewFlat(epplopOfferViewRequest);
							try {
								flattenedString = convertObjectToJson(epplopOfferViewFlat, eventType, false);
							} catch (Exception e) {

								logger.error("Unable to convert object to JSON", e);
							}
						} else if (eventType.equals(AppConstants.ESTATEMENT_DISPATCH)) {
							EstatementDispatchFlat estatementDispatchFlat = flattenRequest
									.getEstatementDispatchFlat(estatementDispatchRequest);
							try {
								flattenedString = convertObjectToJson(estatementDispatchFlat, eventType, false);
							} catch (Exception e) {

								logger.error("Unable to convert object to JSON", e);
							}
						} else if (eventType.equals(AppConstants.ESTATEMENT_VIEW)) {
							EstatementViewFlat estatementViewFlat = flattenRequest
									.getEstatementViewFlat(estatementViewRequest);
							try {
								flattenedString = convertObjectToJson(estatementViewFlat, eventType, false);
							} catch (Exception e) {

								logger.error("Unable to convert object to JSON", e);
							}
						} else if (eventType.equals(AppConstants.FORGOT_USERID_AND_PASSWORD)) {
							ForgotUserIdAndPasswordFlat forgotUserIdAndPasswordFlat = flattenRequest
									.getForgotUserIdAndPasswordFlat(forgotUserIdAndPasswordRequest);
							try {
								flattenedString = convertObjectToJson(forgotUserIdAndPasswordFlat, eventType, false);
							} catch (Exception e) {

								logger.error("Unable to convert object to JSON", e);
							}
						} else if (eventType.equals(AppConstants.IVR_CALL_END)) {
							IVRCallEndFlat ivrCallEndFlat = flattenRequest.getIVRCallEndFlat(ivrCallEndRequest);
							try {
								flattenedString = convertObjectToJson(ivrCallEndFlat, eventType, false);
							} catch (Exception e) {

								logger.error("Unable to convert object to JSON", e);
							}
						} else if (eventType.equals(AppConstants.IVR_CALL_START)) {
							IVRCallStartFlat ivrCallStartFlat = flattenRequest.getIVRCallStartFlat(ivrCallStartRequest);
							try {
								flattenedString = convertObjectToJson(ivrCallStartFlat, eventType, false);
							} catch (Exception e) {

								logger.error("Unable to convert object to JSON", e);
							}
						} else if (eventType.equals(AppConstants.ONLINE_DIRECT_DEBIT_EXEC)) {
							OnlineDirectDebitExecutionFlat onlineDirectDebitExecutionFlat = flattenRequest
									.getOnlineDirectDebitExecutionFlat(onlineDirectDebitExecutionRequest);
							try {
								flattenedString = convertObjectToJson(onlineDirectDebitExecutionFlat, eventType, false);
							} catch (Exception e) {

								logger.error("Unable to convert object to JSON", e);
							}
						} else if (eventType.equals(AppConstants.OVERSEAS_ACTIVATION)) {
							OverseasCardActivationFlat overseasCardActivationFlat = flattenRequest
									.getOverseasCardActivationFlat(overseasCardActivationRequest);
							try {
								flattenedString = convertObjectToJson(overseasCardActivationFlat, eventType, false);
							} catch (Exception e) {

								logger.error("Unable to convert object to JSON", e);
							}
						} else if (eventType.equals(AppConstants.PAYMENT_AND_TRANSFER)) {
							PaymentAndTransferFlat paymentAndTransferFlat = flattenRequest
									.getPaymentAndTransferFlat(paymentAndTransferRequest);
							try {
								flattenedString = convertObjectToJson(paymentAndTransferFlat, eventType, false);
							} catch (Exception e) {

								logger.error("Unable to convert object to JSON", e);
							}
						} else if (eventType.equals(AppConstants.PIN_VALIDATION)) {
							PINValidationFlat pinValidationFlat = flattenRequest
									.getPinValidationFlat(pinValidationRequest);
							try {
								flattenedString = convertObjectToJson(pinValidationFlat, eventType, false);
							} catch (Exception e) {

								logger.error("Unable to convert object to JSON", e);
							}
						} else if (eventType.equals(AppConstants.PRE_AUTH)) {
							PreAuthFlat preAuthFlat = flattenRequest.getPreAuthFlat(preAuthRequest);
							try {
								flattenedString = convertObjectToJson(preAuthFlat, eventType, false);
							} catch (Exception e) {

								logger.error("Unable to convert object to JSON", e);
							}
						} else if (eventType.equals(AppConstants.REPORT_LOST_STOLEN)) {
							ReportLostStolenFlat reportLostStolenFlat = flattenRequest
									.getReportLostStolenFlat(reportLostStolenRequest);
							try {
								flattenedString = convertObjectToJson(reportLostStolenFlat, eventType, false);
							} catch (Exception e) {

								logger.error("Unable to convert object to JSON", e);
							}
						} else if (eventType.equals(AppConstants.REWARD_REDEMPTION_ACCESS)) {
							RewardRedemptionAccessFlat rewardRedemptionAccessFlat = flattenRequest
									.getRewardRedemptionAccessFlat(rewardRedemptionAccessRequest);
							try {
								flattenedString = convertObjectToJson(rewardRedemptionAccessFlat, eventType, false);
							} catch (Exception e) {

								logger.error("Unable to convert object to JSON", e);
							}
						} else if (eventType.equals(AppConstants.REWARD_REDEMPTION_REQUEST)) {
							RewardRedemptionRequestFlat rewardRedemptionRequestFlat = flattenRequest
									.getRewardRedemptionRequestFlat(rewardRedemptionRequestRequest);
							try {
								flattenedString = convertObjectToJson(rewardRedemptionRequestFlat, eventType, false);
							} catch (Exception e) {

								logger.error("Unable to convert object to JSON", e);
							}
						} else if (eventType.equals(AppConstants.SDN_MATCH_FOUND)) {
							SDNMatchFoundFlat sdnMatchFoundFlat = flattenRequest
									.getSDNMatchFoundFlat(sdnMatchFoundRequest);
							try {
								flattenedString = convertObjectToJson(sdnMatchFoundFlat, eventType, false);
							} catch (Exception e) {

								logger.error("Unable to convert object to JSON", e);
							}
						} else if (eventType.equals(AppConstants.SDN_MATCH_RESOLVED)) {
							SDNMatchResolvedFlat sdnMatchResolvedFlat = flattenRequest
									.getSDNMatchResolvedFlat(sdnMatchResolvedRequest);
							try {
								flattenedString = convertObjectToJson(sdnMatchResolvedFlat, eventType, false);
							} catch (Exception e) {

								logger.error("Unable to convert object to JSON", e);
							}
						} else if (eventType.equals(AppConstants.SERVICE_REQUEST)) {
							ServiceRequestFlat serviceRequestFlat = flattenRequest
									.getServiceRequestFlat(serviceRequestRequest);
							try {
								flattenedString = convertObjectToJson(serviceRequestFlat, eventType, false);
							} catch (Exception e) {

								logger.error("Unable to convert object to JSON", e);
							}
						} else if (eventType.equals(AppConstants.SMS_EMAIL_OFFERS)) {
							SMSEmailOffersFlat smsEmailOffersFlat = flattenRequest
									.getSMSEmailOffersFlat(smsEmailOffersRequest);
							try {
								flattenedString = convertObjectToJson(smsEmailOffersFlat, eventType, false);
							} catch (Exception e) {

								logger.error("Unable to convert object to JSON", e);
							}
						} else if (eventType.equals(AppConstants.TPIN_CREATE_RESET_CHANGE_ISSUANCE)) {
							TPINCreateResetChangeIssuanceFlat tpinCreateResetChangeIssuanceFlat = flattenRequest
									.getTPINCreateResetChangeIssuanceFlat(tpinCreateResetChangeIssuanceRequest);
							try {
								flattenedString = convertObjectToJson(tpinCreateResetChangeIssuanceFlat, eventType,
										false);
							} catch (Exception e) {

								logger.error("Unable to convert object to JSON", e);
							}
						} else if (eventType.equals(AppConstants.VIEW_TRANSACTION_HISTORY)) {
							ViewTransactionsHistoryFlat viewTransactionsHistoryFlat = flattenRequest
									.getViewTransactionsHistoryFlat(viewTransactionsHistoryRequest);
							try {
								flattenedString = convertObjectToJson(viewTransactionsHistoryFlat, eventType, false);
							} catch (Exception e) {

								logger.error("Unable to convert object to JSON", e);
							}
						}

						Map<String, String> mongoDBConfiguration = getMongoConfigs(a.getEventActionDetails());
						MongoDBService mongoService = null;
						try {
							mongoService = MongoDBService.getInstance(mongoDBConfiguration);
						} catch (Exception e) {

							logger.error("Unable to get instance of MongoDbService", e);
						}
						collectionName = mongoDBConfiguration.get(AppConstants.MONGODB_DB_COLLECTION);

						String[] collectionNames = collectionName.split(",");
						mongoService.SaveDocument(collectionNames[0], flattenedString);

						if (eventType.startsWith(AppConstants.CB_MRE)) {
							mongoService.updateResponseFlag(collectionNames[1], copTransactionID);
						}

					} else if (AppConstants.PROC_RECO.equals(actionType)) {
						throw new RuntimeException("Unknow action type :" + a.getActionTypeCode());
					} else if (AppConstants.RET_MONGO.equals(actionType)) {
						Map<String, String> mongoDBConfiguration = getMongoConfigs(a.getEventActionDetails());
						MongoDBService mongoService = null;
						try {
							mongoService = MongoDBService.getInstance(mongoDBConfiguration);
						} catch (Exception e) {

							logger.error("Unable to get instance of MongoDbService", e);
						}
						collectionName = mongoDBConfiguration.get(AppConstants.MONGODB_DB_COLLECTION);

						if (possibleReasonRequest.getGetReason() != null) {
							String customerId = possibleReasonRequest.getGetReason().getCustomerID();
							String countryCode = possibleReasonRequest.getGetReason().getCountryCode();
							reasonList = mongoService.retriveReasons(customerId, collectionName, countryCode);
						}

						if (reasonList.isEmpty()) {
							errorCode = "204";
							errorDescription = "No predictive reasons for customer";
						} else {
							responseBody.setPredictedreason(reasonList);
							possibleReasonResponseLog.setPredicted_reason(reasonList);
						}

					} else {
						logger.info("Unknown Event Action Type Found: " + actionType);
					}
					i++;
				}

			} else {
				try {
					throw new RuntimeException("Unknown Event Type Found with no actions: " + eventType);
				} catch (Exception e) {
					logger.error("Unknown Event Type Found with no actions: " + eventType);
					;
				}
			}
		}
		return new Tuple2<String, Long>(requestMessage, 1L);

	}

	private void callPythonScriptWithoutSaveScore(String python_path, String serverDateTime, String python_code,
			String conf_file, String config_section_name, String customerid, String mongo_Password) {
		
		try {
			//logger.info("Inside PythonsCRIPTTTTTTTTTT>>..");
			Process process = Runtime.getRuntime().exec(new String[] { python_path, python_code, customerid,
					"\"" + serverDateTime + "\"", conf_file, config_section_name, "-p", mongo_Password});

			InputStream stderr = process.getErrorStream();
			InputStreamReader isr = new InputStreamReader(stderr);
			BufferedReader br = new BufferedReader(isr);
			String line = null;
			logger.info("<ERROR>");
			while ((line = br.readLine()) != null)
				logger.info(line);
			logger.info("</ERROR>");
			int exitVal = process.waitFor();
			//logger.info("Process exitValue: " + exitVal);
			//logger.info("After processsssssssssssss >>..");
		} catch (Exception ex) {
			logger.info("Exception in PYTHON script" + ex);
			//System.out.println
		}
		
		
	}

	private void copyFromHdfsToLocal() throws IOException {

		//logger.info(">>>>>>>>INSIDE HDFSSSSS>>>>.....");
		Configuration conf = new Configuration();
		String hdfs_root_url = appProps.get(SysConstants.HDFS_ROOT_URL);
		conf.set("HDFS_ROOT_URL", hdfs_root_url );
		conf.addResource(new Path("/etc/hadoop/conf.cloudera.hdfs/core-site.xml"));
		conf.addResource(new Path("/etc/hadoop/conf.cloudera.hdfs/hdfs-site.xml"));
		conf.set("fs.hdfs.impl", "org.apache.hadoop.hdfs.DistributedFileSystem");
		conf.set("fs.file.impl", "org.apache.hadoop.fs.LocalFileSystem");
		conf.set("hadoop.security.authentication", "kerberos");
		conf.set("hadoop.security.authorization", "true");
		
		
		String file_local_path= appProps.get(SysConstants.FILES_LOCAL_PATH);
		Path local = new Path(file_local_path);
		String file_hdfs_path= appProps.get(SysConstants.FILE_HDFS_PATH);
		Path hdfs = new Path(file_hdfs_path);
		
		
		FileSystem fs = FileSystem.get(conf);
		FileStatus[] status = fs.listStatus(hdfs);
		for (int i = 0; i < status.length; i++) {
			//logger.info(status[i].getPath());
			fs.copyToLocalFile(false, status[i].getPath(), local,true);

		}
		// fs.close();

	}

	private void callPythonScript(String python_path,String serverDateTime, String python_code, String conf_file,
			String config_section_name, String customerid,String mongo_Password) {

		try {
			//logger.info("Inside PythonsCRIPTTTTTTTTTT>>..");
			Process process = Runtime.getRuntime().exec(new String[] { python_path, python_code, customerid,
					"\"" + serverDateTime + "\"", conf_file, config_section_name, "--export_rsn_cde", "-p", mongo_Password});

			// ("python35
			// /data/1/gcgdma/bin/apps/IVR/RT/EAP/code/ivr_model_context.py "
			// +customerid+"" +date+ "/home/ss36531/IVR/ivr_model_context.conf"
			// +config_section_name);
			// process.waitFor(3, TimeUnit.MINUTES);

			InputStream stderr = process.getErrorStream();
			InputStreamReader isr = new InputStreamReader(stderr);
			BufferedReader br = new BufferedReader(isr);
			String line = null;
			logger.info("<ERROR>");
			while ((line = br.readLine()) != null)
				logger.info(line);
			logger.info("</ERROR>");
			int exitVal = process.waitFor();
			//logger.info("Process exitValue: " + exitVal);
			//logger.info("After processsssssssssssss >>..");
		} catch (Exception ex) {
			logger.info("Exception in PYTHON script" + ex);
			//System.out.println
		}
	}

	private Map<String, String> getKafkaProducerConfigs(List<EventActionDetail> eventActionDetails) {
		Map<String, String> eventActionConfig = new HashMap<String, String>();

		for (EventActionDetail eventActionDetail : eventActionDetails) {
			if (AppConstants.BOOTSTRAP_SERVERS.equals(eventActionDetail.getParamName())) {
				eventActionConfig.put(eventActionDetail.getParamName(), eventActionDetail.getParamValue());
			} else if (AppConstants.ACK_MSG.equals(eventActionDetail.getParamName())) {
				eventActionConfig.put(eventActionDetail.getParamName(), eventActionDetail.getParamValue());
			} else if (AppConstants.KAFKA_SEC_PROTOCOL.equals(eventActionDetail.getParamName())) {
				eventActionConfig.put(eventActionDetail.getParamName(), eventActionDetail.getParamValue());
			} else if (AppConstants.KEY_SERIALIZER.equals(eventActionDetail.getParamName())) {
				eventActionConfig.put(eventActionDetail.getParamName(), eventActionDetail.getParamValue());
			} else if (AppConstants.VALUE_SERIALIZER.equals(eventActionDetail.getParamName())) {
				eventActionConfig.put(eventActionDetail.getParamName(), eventActionDetail.getParamValue());
			} else if (AppConstants.KAFKA_TOPICS.equals(eventActionDetail.getParamName())) {
				eventActionConfig.put(eventActionDetail.getParamName(), eventActionDetail.getParamValue());
			}
		}

		return eventActionConfig;
	}

	private Map<String, String> getTibcoConfigs(List<EventActionDetail> eventActionDetails) {
		Map<String, String> eventActionConfig = new HashMap<String, String>();
		for (EventActionDetail eventActionDetail : eventActionDetails) {
			if (AppConstants.CONN_FACTORY.equals(eventActionDetail.getParamName())) {
				eventActionConfig.put(eventActionDetail.getParamName(), eventActionDetail.getParamValue());
			} else if (AppConstants.PROVIDER_URL.equals(eventActionDetail.getParamName())) {
				eventActionConfig.put(eventActionDetail.getParamName(), eventActionDetail.getParamValue());
			} else if (AppConstants.SSL_IDENTITY.equals(eventActionDetail.getParamName())) {
				eventActionConfig.put(eventActionDetail.getParamName(), eventActionDetail.getParamValue());
			} else if (AppConstants.SSL_PASSWORD.equals(eventActionDetail.getParamName())) {
				eventActionConfig.put(eventActionDetail.getParamName(), eventActionDetail.getParamValue());
			} else if (AppConstants.SEC_PROTOCOL.equals(eventActionDetail.getParamName())) {
				eventActionConfig.put(eventActionDetail.getParamName(), eventActionDetail.getParamValue());
			} else if (AppConstants.ENABLE_VERIFY_HOST.equals(eventActionDetail.getParamName())) {
				eventActionConfig.put(eventActionDetail.getParamName(), eventActionDetail.getParamValue());
			} else if (AppConstants.SSL_VENDOR.equals(eventActionDetail.getParamName())) {
				eventActionConfig.put(eventActionDetail.getParamName(), eventActionDetail.getParamValue());
			} else if (AppConstants.SSL_PROVIDER.equals(eventActionDetail.getParamName())) {
				eventActionConfig.put(eventActionDetail.getParamName(), eventActionDetail.getParamValue());
			} else if (AppConstants.SSL_AUTH_ONLY.equals(eventActionDetail.getParamName())) {
				eventActionConfig.put(eventActionDetail.getParamName(), eventActionDetail.getParamValue());
			} else if (AppConstants.TIBCO_SEC_VENDOR.equals(eventActionDetail.getParamName())) {
				eventActionConfig.put(eventActionDetail.getParamName(), eventActionDetail.getParamValue());
			} else if (AppConstants.TIBCO_SEC_TRACE.equals(eventActionDetail.getParamName())) {
				eventActionConfig.put(eventActionDetail.getParamName(), eventActionDetail.getParamValue());
			} else if (AppConstants.SSL_DEBUG_TRACE.equals(eventActionDetail.getParamName())) {
				eventActionConfig.put(eventActionDetail.getParamName(), eventActionDetail.getParamValue());
			} else if (AppConstants.SSL_TRACE.equals(eventActionDetail.getParamName())) {
				eventActionConfig.put(eventActionDetail.getParamName(), eventActionDetail.getParamValue());
			} else if (AppConstants.QUEUE_USERNAME.equals(eventActionDetail.getParamName())) {
				eventActionConfig.put(eventActionDetail.getParamName(), eventActionDetail.getParamValue());
			} else if (AppConstants.QUEUE_PASSWORD.equals(eventActionDetail.getParamName())) {
				eventActionConfig.put(eventActionDetail.getParamName(), eventActionDetail.getParamValue());
			} else if (AppConstants.QUEUE_CF.equals(eventActionDetail.getParamName())) {
				eventActionConfig.put(eventActionDetail.getParamName(), eventActionDetail.getParamValue());
			} else if (AppConstants.QUEUE_NAME.equals(eventActionDetail.getParamName())) {
				eventActionConfig.put(eventActionDetail.getParamName(), eventActionDetail.getParamValue());
			} else if (AppConstants.P12_ENABLED.equals(eventActionDetail.getParamName())) {
				eventActionConfig.put(eventActionDetail.getParamName(), eventActionDetail.getParamValue());
			}
		}
		return eventActionConfig;
	}

	private Map<String, String> getMongoConfigs(List<EventActionDetail> eventActionDetails) {
		Map<String, String> eventActionConfig = new HashMap<String, String>();
		for (EventActionDetail eventActionDetail : eventActionDetails) {
			if (AppConstants.MONGODB_HOST.equals(eventActionDetail.getParamName())) {
				eventActionConfig.put(eventActionDetail.getParamName(), eventActionDetail.getParamValue());
			} else if (AppConstants.MONGODB_PORT.equals(eventActionDetail.getParamName())) {
				eventActionConfig.put(eventActionDetail.getParamName(), eventActionDetail.getParamValue());
			} else if (AppConstants.MONGODB_DB_NAME.equals(eventActionDetail.getParamName())) {
				eventActionConfig.put(eventActionDetail.getParamName(), eventActionDetail.getParamValue());
			} else if (AppConstants.MONGODB_DB_USER.equals(eventActionDetail.getParamName())) {
				eventActionConfig.put(eventActionDetail.getParamName(), eventActionDetail.getParamValue());
			} else if (AppConstants.MONGODB_DB_PASSWORD.equals(eventActionDetail.getParamName())) {
				eventActionConfig.put(eventActionDetail.getParamName(), eventActionDetail.getParamValue());
			} else if (AppConstants.MONGODB_URI.equals(eventActionDetail.getParamName())) {
				eventActionConfig.put(eventActionDetail.getParamName(), eventActionDetail.getParamValue());
			} else if (AppConstants.MONGODB_DB_COLLECTION.equals(eventActionDetail.getParamName())) {
				eventActionConfig.put(eventActionDetail.getParamName(), eventActionDetail.getParamValue());
			}
		}
		return eventActionConfig;
	}

	private String convertObjectToJson(Object object, String eventType, boolean possibleReasonLogCall)
			throws JsonGenerationException, JsonMappingException, IOException {
		ObjectMapper mapper = new ObjectMapper();
		String jsonString = "";
		if (AppConstants.EPP_POSS_RES.equals(eventType)) {
			if (possibleReasonLogCall) {
				PossibleReasonResponseLog posResponseLog = (PossibleReasonResponseLog) object;
				jsonString = mapper.writeValueAsString(posResponseLog);
			} else {
				PossibleReasonResponse posResponse = (PossibleReasonResponse) object;
				jsonString = mapper.writeValueAsString(posResponse);
			}
		} else if (eventType.startsWith(AppConstants.CB_MRE)) {
			Gson gObj = new Gson();
			if (possibleReasonLogCall) {
				TransactionMREReq transactionMREReq = (TransactionMREReq) object;
				jsonString = gObj.toJson(transactionMREReq);
			} else {
				TransactionMREFlatRes transactionMRERes = (TransactionMREFlatRes) object;
				jsonString = gObj.toJson(transactionMRERes);
			}

		} else if (eventType.startsWith(AppConstants.EPP)) {
			Gson gObj = new Gson();
			if (possibleReasonLogCall) {
				COPEAPRequest copeapRequest = (COPEAPRequest) object;
				jsonString = gObj.toJson(copeapRequest);
			} else {
				COPEAPResponse copeapResponse = (COPEAPResponse) object;
				jsonString = gObj.toJson(copeapResponse);
			}
		} else if (eventType.startsWith(AppConstants.EPP_MOD)) {
			Gson gObj = new Gson();
			if (possibleReasonLogCall) {
				EAPModelOffer eAPModelOffer = (EAPModelOffer) object;
				jsonString = gObj.toJson(eAPModelOffer);
			} else {
				EAPModelOffer eAPModelOffer = (EAPModelOffer) object;
				jsonString = gObj.toJson(eAPModelOffer);
			}
		} else if (eventType.startsWith(AppConstants.EPP_PROD)) {
			Gson gObj = new Gson();
			if (possibleReasonLogCall) {
				EAPProdOfferTemplate eAPProdOfferTemplate = (EAPProdOfferTemplate) object;
				jsonString = gObj.toJson(eAPProdOfferTemplate);
			} else {
				EAPProdOfferTemplate eAPProdOfferTemplate = (EAPProdOfferTemplate) object;
				jsonString = gObj.toJson(eAPProdOfferTemplate);
			}

		} else if (eventType.startsWith(AppConstants.EPP_TRT)) {
			Gson gObj = new Gson();
			if (possibleReasonLogCall) {
				EAPTreatmentTemplate eAPTreatmentTemplate = (EAPTreatmentTemplate) object;
				jsonString = gObj.toJson(eAPTreatmentTemplate);
			} else {
				EAPTreatmentTemplate eAPTreatmentTemplate = (EAPTreatmentTemplate) object;
				jsonString = gObj.toJson(eAPTreatmentTemplate);
			}
		} else if (eventType.startsWith(AppConstants.EPP_UOF)) {
			Gson gObj = new Gson();
			if (possibleReasonLogCall) {
				UpdateOfferFullfillmentEapRequest updateOfferFullfillmentEapRequest = (UpdateOfferFullfillmentEapRequest) object;
				jsonString = gObj.toJson(updateOfferFullfillmentEapRequest);
			} else {
				UpdateOfferFullfillmentEapRequest updateOfferFullfillmentEapRequest = (UpdateOfferFullfillmentEapRequest) object;
				jsonString = gObj.toJson(updateOfferFullfillmentEapRequest);
			}

		} else if (eventType.equals(AppConstants.CARD_ACTIVATION)) {
			CardActivationFlat cardActivationFlat = (CardActivationFlat) object;
			jsonString = mapper.writeValueAsString(cardActivationFlat);
		} else if (eventType.equals(AppConstants.ACCOUNT_LINKAGE)) {
			AccountLinkageFlat accountLinkageFlat = (AccountLinkageFlat) object;
			jsonString = mapper.writeValueAsString(accountLinkageFlat);
		} else if (eventType.equals(AppConstants.ACCOUNT_SUMMARY)) {
			AccountSummaryFlat accountSummaryFlat = (AccountSummaryFlat) object;
			jsonString = mapper.writeValueAsString(accountSummaryFlat);
		} else if (eventType.equals(AppConstants.APIN_CHANGE)) {
			APINChangeFlat apinChangeFlat = (APINChangeFlat) object;
			jsonString = mapper.writeValueAsString(apinChangeFlat);
		} else if (eventType.equals(AppConstants.BILL_PAYMENT)) {
			BillPaymentFlat billPaymentFlat = (BillPaymentFlat) object;
			jsonString = mapper.writeValueAsString(billPaymentFlat);
		} else if (eventType.equals(AppConstants.CARD_BLOCK_CODE_UPDATE)) {
			CardBlockCodeUpdateFlat cardBlockCodeUpdateFlat = (CardBlockCodeUpdateFlat) object;
			jsonString = mapper.writeValueAsString(cardBlockCodeUpdateFlat);
		} else if (eventType.equals(AppConstants.CARD_DECLINE)) {
			CardDeclineFlat cardDeclineFlat = (CardDeclineFlat) object;
			jsonString = mapper.writeValueAsString(cardDeclineFlat);
		} else if (eventType.equals(AppConstants.CBOL_MBOL_REGISTRATION)) {
			CBOLMBOLRegistrationFlat cbolmbolRegistrationFlat = (CBOLMBOLRegistrationFlat) object;
			jsonString = mapper.writeValueAsString(cbolmbolRegistrationFlat);
		} else if (eventType.equals(AppConstants.CHARGE_DISPUTE)) {
			ChargeDisputeFlat chargeDisputeFlat = (ChargeDisputeFlat) object;
			jsonString = mapper.writeValueAsString(chargeDisputeFlat);
		} else if (eventType.equals(AppConstants.CHEQUE_BOUNCE_REQUEST)) {
			ChequeBounceFlat chequeBounceFlat = (ChequeBounceFlat) object;
			jsonString = mapper.writeValueAsString(chequeBounceFlat);
		} else if (eventType.equals(AppConstants.CHEQUE_STOP_PAYMENT_REQUEST)) {
			ChequeStopPaymentFlat chequeStopPaymentFlat = (ChequeStopPaymentFlat) object;
			jsonString = mapper.writeValueAsString(chequeStopPaymentFlat);
		} else if (eventType.equals(AppConstants.CPO_CALL_END)) {
			CpoCallEndFlat cpoCallEndFlat = (CpoCallEndFlat) object;
			jsonString = mapper.writeValueAsString(cpoCallEndFlat);
		} else if (eventType.equals(AppConstants.CPO_CALL_START)) {
			CpoCallStartFlat cpoCallStartFlat = (CpoCallStartFlat) object;
			jsonString = mapper.writeValueAsString(cpoCallStartFlat);
		} else if (eventType.equals(AppConstants.CREDIT_CARD_CLOSURE)) {
			CreditCardClosureFlat creditCardClosureFlat = (CreditCardClosureFlat) object;
			jsonString = mapper.writeValueAsString(creditCardClosureFlat);
		} else if (eventType.equals(AppConstants.CREDIT_LIMIT_INCREASE)) {
			CreditLimitIncreaseFlat creditLimitIncreaseFlat = (CreditLimitIncreaseFlat) object;
			jsonString = mapper.writeValueAsString(creditLimitIncreaseFlat);
		} else if (eventType.equals(AppConstants.CUST_HW_TOKEN)) {
			CustHWTokenFlat custHWTokenFlat = (CustHWTokenFlat) object;
			jsonString = mapper.writeValueAsString(custHWTokenFlat);
		} else if (eventType.equals(AppConstants.CUST_LOGIN_ID_STATUS_CHANGE)) {
			CustLoginIDStatusChangeFlat custLoginIDStatusChangeFlat = (CustLoginIDStatusChangeFlat) object;
			jsonString = mapper.writeValueAsString(custLoginIDStatusChangeFlat);
		} else if (eventType.equals(AppConstants.CUSTOMER_LOGIN)) {
			CustomerLoginFlat customerLoginFlat = (CustomerLoginFlat) object;
			jsonString = mapper.writeValueAsString(customerLoginFlat);
		} else if (eventType.equals(AppConstants.DEMOGRAPHIC_CHANGE)) {
			DemographicChangeFlat demographicChangeFlat = (DemographicChangeFlat) object;
			jsonString = mapper.writeValueAsString(demographicChangeFlat);
		} else if (eventType.equals(AppConstants.DIGIPASS_INITIATION)) {
			DigiPassInitiationFlat digiPassInitiationFlat = (DigiPassInitiationFlat) object;
			jsonString = mapper.writeValueAsString(digiPassInitiationFlat);
		} else if (eventType.equals(AppConstants.EPPLOP_OFFER_VIEW)) {
			EPPLOPOfferViewFlat epplopOfferViewFlat = (EPPLOPOfferViewFlat) object;
			jsonString = mapper.writeValueAsString(epplopOfferViewFlat);
		} else if (eventType.equals(AppConstants.ESTATEMENT_DISPATCH)) {
			EstatementDispatchFlat estatementDispatchFlat = (EstatementDispatchFlat) object;
			jsonString = mapper.writeValueAsString(estatementDispatchFlat);
		} else if (eventType.equals(AppConstants.ESTATEMENT_VIEW)) {
			EstatementViewFlat estatementViewFlat = (EstatementViewFlat) object;
			jsonString = mapper.writeValueAsString(estatementViewFlat);
		} else if (eventType.equals(AppConstants.FORGOT_USERID_AND_PASSWORD)) {
			ForgotUserIdAndPasswordFlat forgotUserIdAndPasswordFlat = (ForgotUserIdAndPasswordFlat) object;
			jsonString = mapper.writeValueAsString(forgotUserIdAndPasswordFlat);
		} else if (eventType.equals(AppConstants.IVR_CALL_END)) {
			IVRCallEndFlat ivrCallEndFlat = (IVRCallEndFlat) object;
			jsonString = mapper.writeValueAsString(ivrCallEndFlat);
		} else if (eventType.equals(AppConstants.IVR_CALL_START)) {
			IVRCallStartFlat ivrCallStartFlat = (IVRCallStartFlat) object;
			jsonString = mapper.writeValueAsString(ivrCallStartFlat);
		} else if (eventType.equals(AppConstants.ONLINE_DIRECT_DEBIT_EXEC)) {
			OnlineDirectDebitExecutionFlat onlineDirectDebitExecutionFlat = (OnlineDirectDebitExecutionFlat) object;
			jsonString = mapper.writeValueAsString(onlineDirectDebitExecutionFlat);
		} else if (eventType.equals(AppConstants.OVERSEAS_ACTIVATION)) {
			OverseasCardActivationFlat overseasCardActivationFlat = (OverseasCardActivationFlat) object;
			jsonString = mapper.writeValueAsString(overseasCardActivationFlat);
		}

		return jsonString;

	}

	private String formatDate(long timeinMilliSec, String dateFormat) {
		SimpleDateFormat df = new SimpleDateFormat(dateFormat);
		GregorianCalendar cal = new GregorianCalendar();
		cal.setTimeInMillis(timeinMilliSec);
		String date = df.format(cal.getTime());

		return date;
	}

	private List<EventAction> getActions(String eventTypeCode) {
		List<EventAction> actions = null;
		for (AppDSEvent event : _appEvents) {
			if (eventTypeCode != null && eventTypeCode.equals(event.getEventTypeCode())) {
				actions = event.getEventActions();
			}
		}
		return actions;
	}

}
