package eap2.rts.spark;

public interface AppConstants {

	public String HADOOP_HOME_DIR = "hadoop.home.dir";
	
	//Spark Application configuration
	public String APP_PARAM_SPARK_DUATION = "app.spark.duration";
	public String APP_MSG_BROKER_TYPE = "app.spark.msg.broker.type";
	public String APP_TEMP_FOLDER = "app.temp.folder";
	public String APP_OUTPUT_FOLDER = "app.output.folder";

	//Input Argument
	public String ARG_SPARK_APP_NAME = "spark.app.name";
	public String ARG_APP_CONFIG_FILE_NAME = "ARG_APP_CONFIG_FILE_NAME";

	// Kafka Receiver params
	public String KAFKA_ZOOKEEPER_CONNECT = "zookeeper.connect";
	public String KAFKA_GROUP_ID = "group.id";
	public String KAFKA_METADATA_BROKER = "metadata.broker.list";
	public String KAFKA_SERIALIZER_CLASS = "serializer.class";
	public String KAFKA_REQUEST_REQUIRED_ACKS = "request.required.acks";
	public String KAFKA_TOPICS = "kafka.topics";

	//Message Broker Type
	public String TIBCO = "TIBCO";
	public String KAFKA = "KAFKA";
	
	//Event Action Type
	public String SAVE_MONGO = "SAVE_MONGO";
	public String SAVE_FLAT_MONGO = "SAVE_FLAT_MONGO";
	public String PUB_TIBCO = "PUB_TIBCO";
	public String PROC_RECO = "PROC_RECO";
	public String RET_MONGO = "RET_MONGO";
	public String PARSE_EVENT = "PARSE_EVENT";
	public String PUB_KAFKA = "PUB_KAFKA";
	public String LOOKUP = "LOOKUP";
	public String CALL_PYTHON_CODE = "CALL_PYTHON_CODE";
	public String CALL_PYTHON_SCRIPT = "CALL_PYTHON_SCRIPT";

	//MongoDB Connection Parameters
	public String MONGO_URI = "URI";
	
	//Tibco DS Queue Parameters
	public static String CONN_FACTORY="INITIAL_CONTEXT_FACTORY";
	public static String PROVIDER_URL="PROVIDER_URL";
	public static String SEC_PROTOCOL="com.tibco.tibjms.naming.security_protocol";
	public static String ENABLE_VERIFY_HOST="com.tibco.tibjms.naming.ssl_enable_verify_host";
	public static String SSL_VENDOR="com.tibco.tibjms.naming.ssl_vendor";
	public static String SSL_PROVIDER="com.sun.net.ssl.internal.ssl.Provider";
	public static String SSL_AUTH_ONLY="com.tibco.tibjms.naming.ssl_auth_only";
	public static String TIBCO_SEC_VENDOR="java.property.TIBCO_SECURITY_VENDOR";
	public static String TIBCO_SEC_TRACE="java.property.TIBCO_SECURITY_TRACE";
	public static String SSL_DEBUG_TRACE="com.tibco.tibjms.naming.ssl_debug_trace";
	public static String SSL_TRACE="com.tibco.tibjms.naming.ssl_trace";
	public static String SSL_IDENTITY="com.tibco.tibjms.naming.ssl_identity";
	public static String SSL_PASSWORD="com.tibco.tibjms.naming.ssl_password";
	public static String QUEUE_USERNAME="tibco.jms.queue.username";
	public static String QUEUE_PASSWORD="tibco.jms.queue.password";
	public static String QUEUE_CF="tibco.jms.queue.queueCF";
	public static String QUEUE_NAME="tibco.jms.inbound.queue.name";

	//App Constants
	public String DS_ID = "DS_ID";
	public String DEFAULT_EVENT = "DEFAULT_EVENT";
	public String DS_NAME = "DS_NAME";

	//MONGO_SAVE Action Details
	public String MONGODB_HOST = "mongodb.host.name";
	public String MONGODB_PORT = "mongodb.host.port";
	public String MONGODB_DB_NAME = "mongodb.db.name";
	public String MONGODB_DB_USER = "mongodb.db.user";
	public String MONGODB_DB_COLLECTION = "mongodb.collection.name";
	public String MONGODB_DB_PASSWORD = "mongodb.db.password";
	public String MONGODB_URI = "mongodb.uri";
	
//	Publish Kafka Event Details
	public String BOOTSTRAP_SERVERS = "bootstrap.servers";
	public String ACK_MSG = "acks";
	public String KAFKA_SEC_PROTOCOL = "security.protocol";
	public String KEY_SERIALIZER = "key.serializer";
	public String VALUE_SERIALIZER = "value.serializer";

//	Event Types
	public String EPP_POSS_RES = "EPP_POSS_RES";
	public String CB_MRE="CB_MRE_REQUEST";
// EPP Event types
	public String EPP = "EPP_REQUEST";
	public String EPP_MOD = "EAPModelOffer";
	public String EPP_PROD = "EAPProdOfferTemplate";
	public String EPP_TRT = "EAPTreatmentTemplate";
	public String EPP_UOF = "UpdateOfferFullfillmentEapRequest";
	
//	EventHub Event Types
	public String CARD_ACTIVATION="CardActivation";
	public String ACCOUNT_LINKAGE="AccountLinkage";
	public String ACCOUNT_SUMMARY="AccountSummary";
	public String APIN_CHANGE="APINChange";
	public String BILL_PAYMENT="BillPayment";
	public String CARD_BLOCK_CODE_UPDATE="CardBlockCodeUpdate";
	public String CARD_DECLINE="CardDecline";
	public String CBOL_MBOL_REGISTRATION="CBOLMBOLRegistration";
	public String CHARGE_DISPUTE="ChargeDispute";
	public String CHEQUE_BOUNCE_REQUEST="ChequeBounceRequest";
	public String CHEQUE_STOP_PAYMENT_REQUEST="ChequeStopPaymentRequest";
	public String CPO_CALL_END="CpoCallEnd";
	public String CPO_CALL_START="CpoCallStart";
	public String CREDIT_CARD_CLOSURE="CreditCardClosure";
	public String CREDIT_CARD_REVERSAL="CreditCardReversal";
	public String CREDIT_LIMIT_INCREASE="CreditLimitIncrease";
	public String CUST_HW_TOKEN="CustHWToken";
	public String CUST_LOGIN_ID_STATUS_CHANGE="CustLoginIDStatusChange";
	public String CUSTOMER_LOGIN="CustomerLogin";
	public String DEMOGRAPHIC_CHANGE="DemographicChange";
	public String DIGIPASS_INITIATION="DigiPassInitiation";
	public String EPPLOP_OFFER_VIEW="EPPLOPOfferView";
	public String ESTATEMENT_DISPATCH="EstatementDispatch";
	public String ESTATEMENT_VIEW="eStatementView";
	public String FORGOT_USERID_AND_PASSWORD="ForgotUserIdAndPassword";
	public String IVR_CALL_END="IVRCallEnd";
	public String IVR_CALL_START="IVRCallStart";
	public String ONLINE_DIRECT_DEBIT_EXEC="OnlineDirectDebitExecution";
	public String OVERSEAS_ACTIVATION="OverseasActivation";
	public String PAYMENT_AND_TRANSFER="PaymentAndTransfer";
	public String PIN_VALIDATION="PINValidation";
	public String PRE_AUTH="PreAuth";
	public String REPORT_LOST_STOLEN="ReportLostStolen";
	public String REWARD_REDEMPTION_ACCESS="RewardRedemptionAccess";
	public String REWARD_REDEMPTION_REQUEST="RewardRedemptionRequest";
	public String SDN_MATCH_FOUND="SDNMatchFound";
	public String SDN_MATCH_RESOLVED="SDNMatchResolved";
	public String SERVICE_REQUEST="ServiceRequest";
	public String SMS_EMAIL_OFFERS="SMSEmailOffers";
	public String TPIN_CREATE_RESET_CHANGE_ISSUANCE="TPINCreateResetChangeIssuance";
	public String VIEW_TRANSACTION_HISTORY="ViewTransactionsHistory";
	public String IVR_CALL_LOGIN="IVRCallLogin";
	
	public Object BOOTSTRAP_SERVERS_CONFIG = null;

	public Object ACKS_CONFIG = null;

	public Object SECURITY_PROTOCOL_CONFIG = null;

	public Object RETRIES_CONFIG = null;

	public Object BATCH_SIZE_CONFIG = null;

	public Object LINGER_MS_CONFIG = null;

	public Object BUFFER_MEMORY_CONFIG = null;

	public Object VALUE_SERIALIZER_CLASS_CONFIG = null;

	public Object REQUEST_TIMEOUT_MS_CONFIG = null;

	public Object MAX_BLOCK_MS_CONFIG = null;

	public Object KEY_SERIALIZER_CLASS_CONFIG = null;

	public Object KAFKA_TOPIC = "KAFKA_TOPIC";

	public String TIMESTAMP_DATE_FORMAT = "yyyy-MM-dd HH:mm:ss.SSS";
	public String MIS_DATE_FORMAT = "yyyy-MM-dd";

	public String LOG = "_LOG";

	public String SYS_SOURCE = "EAP";
	public String ORG_CODE = "GCG";

	public String ORA_PASS = "ORA_PASS";
	public String MONGO_PASS = "MONGO_PASS";
	public String TIBCO_PASS = "TIBCO_PASS";

	public String UAT_PROP = "eap2-rts-spark_uat.properties";
	public String PROD_PROP = "eap2-rts-spark_prod.properties";

	public String P12_ENABLED = "tibco.p12.enable";
	
	public String DEFAULT_RESPONSE = " , , , , , , , , , , , , , , , , , , , , ";
	
	public String SUCCESSFUL_PUBLSIH = "Successful Publish";
	public String DEFAULT_PUBLSIH = "Default Publish";
	public String INVALID_REQUEST = "Invalid Request";
	public String BACK_DATED_REQUEST = "Back Dated Request";
	

}