package eap2.rts.spark.service;

import java.util.Map;
import java.util.Properties;

import javax.jms.Connection;
import javax.jms.ConnectionFactory;
import javax.jms.JMSException;
import javax.jms.MessageProducer;
import javax.jms.Queue;
import javax.jms.Session;
import javax.jms.TextMessage;
import javax.naming.Context;
import javax.naming.InitialContext;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import eap2.rts.spark.AppConstants;

/**
 * This class implements functions to publish the message response back to SCM.
 * 
 * @author bs34500
 */
public class TibcoJMSService {

	private static final Logger logger = LoggerFactory.getLogger(TibcoJMSService.class);
	private static TibcoJMSService _instance = null;

	private ConnectionFactory _queueConnectionFactory = null;
	private Connection _queueConnection = null;
	private Queue _queue = null;
	private Session _queueSession = null;
	private MessageProducer _queueSender = null;
	private Properties env = new Properties();
	private Map<String, String> _tibcoJMSConfig;
	private String _tibcoPassword = new String();

	private TibcoJMSService(Map<String, String> tibcoJMSConfig , String tibcoPassword) {
		this._tibcoJMSConfig = tibcoJMSConfig;
		this._tibcoPassword = tibcoPassword;
		
		env.put(Context.INITIAL_CONTEXT_FACTORY, tibcoJMSConfig.get(AppConstants.CONN_FACTORY));
		env.put(Context.PROVIDER_URL, tibcoJMSConfig.get(AppConstants.PROVIDER_URL));
		env.put(Context.SECURITY_PRINCIPAL, tibcoJMSConfig.get(AppConstants.QUEUE_USERNAME));
		env.put(Context.SECURITY_CREDENTIALS, _tibcoPassword);
		env.put(AppConstants.SEC_PROTOCOL, tibcoJMSConfig.get(AppConstants.SEC_PROTOCOL));
		env.put(AppConstants.ENABLE_VERIFY_HOST, tibcoJMSConfig.get(AppConstants.ENABLE_VERIFY_HOST));
		env.put(AppConstants.SSL_VENDOR, tibcoJMSConfig.get(AppConstants.SSL_VENDOR));
		env.put(AppConstants.SSL_PROVIDER, tibcoJMSConfig.get(AppConstants.SSL_PROVIDER));
		env.put(AppConstants.SSL_AUTH_ONLY, tibcoJMSConfig.get(AppConstants.SSL_AUTH_ONLY));
		env.put(AppConstants.TIBCO_SEC_VENDOR, tibcoJMSConfig.get(AppConstants.TIBCO_SEC_VENDOR));
		}

	public static TibcoJMSService getInstance(Map<String, String> tibcoJMSConfig, String _tibcoPassword2) throws Exception {
		if (_instance == null) {
			_instance = new TibcoJMSService(tibcoJMSConfig,_tibcoPassword2);
			_instance.open();
		}
		return _instance;
	}

	public void open() throws Exception {
		try {
			Context ctx = new InitialContext(env);
			_queueConnectionFactory = (ConnectionFactory) ctx.lookup(_tibcoJMSConfig.get(AppConstants.QUEUE_CF));
			_queueConnection = (Connection) _queueConnectionFactory.createConnection(_tibcoJMSConfig.get(AppConstants.QUEUE_USERNAME),
					_tibcoPassword);
			_queueConnection.start();
		} catch (Exception e) {
			logger.error("Inside TibcoJMSPublisherService->>>>>open->>>>>error>>starts");
			logger.error("An error has occured.", e);
			logger.error("Inside TibcoJMSPublisherService->>>>>open->>>>>error>>ends");
			throw e;
		}
	}

	/**
	 * @param requestMessageId
	 * @param messages
	 * @throws JMSException
	 */
	public void publish(String message, String requestMessageId) throws JMSException {
		if (message == null) {
			return;
		}

		/*
		 * Create connection. Create session from connection. Create sender. Create text message. Send messages. Send
		 * non text message to end text messages. Close connection.
		 */
		try {
			_queueSession = _queueConnection.createSession(false, Session.AUTO_ACKNOWLEDGE);
			_queue= _queueSession.createQueue(_tibcoJMSConfig.get(AppConstants.QUEUE_NAME));
			_queueSender = _queueSession.createProducer(_queue);
			TextMessage textMessage = _queueSession.createTextMessage();
			textMessage.setText(message);
			textMessage.setJMSCorrelationID(requestMessageId);
			_queueSender.send(textMessage);
			_queueSender.close();
			_queueSession.close();
		} catch (JMSException e) {
			logger.error("Inside TibcoJMSPublisherService->>>>>publish->>>>>error>>starts");
			logger.error("An error has occured.", e);
			logger.error("Inside TibcoJMSPublisherService->>>>>publish->>>>>error>>ends");
			throw e;
		}
	}

	@Override
	protected void finalize() throws Throwable {
		try {
			if (_queueConnection != null) {
				_queueConnection.close();
			}
		} catch (Throwable throwable) {
			logger.error("Inside TibcoJMSPublisherService->>>>>finalize->>>>>error>>starts");
			logger.error(throwable.getMessage());
			logger.error("Inside TibcoJMSPublisherService->>>>>finalize->>>>>error>>ends");
			throw throwable;
		}
	}
}