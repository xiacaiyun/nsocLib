package eap2.rts.spark.function;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.List;
import java.util.Map;

import javax.xml.datatype.XMLGregorianCalendar;

import org.apache.commons.beanutils.BeanUtils;
import org.apache.commons.lang.time.DateUtils;
import org.apache.log4j.Logger;
import org.apache.spark.api.java.JavaRDD;
import org.apache.spark.api.java.function.Function;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.tibco.schemas.copsrainbow.sharedresources.schemas.eventschema.mretransaction.TransactionMREReq;
import com.tibco.schemas.copsrainbow.sharedresources.schemas.eventschema.mretransaction.TransactionMRERes;

import eap2.rts.common.event.dto.FlattenRequest;
import eap2.rts.common.event.dto.TransactionMREFlatRes;
import eap2.rts.spark.AppConstants;
import eap2.rts.spark.service.MongoDBService;
import eap2.rts.spark.service.XMLGregorianCalendarConvertor;

public class SparkMongoFunction implements Function<JavaRDD<String>, Void> {
	private static final long serialVersionUID = -2777632612439093594L;
	private static Logger logger = Logger.getLogger(SparkMongoFunction.class);
	private Map<String,String> _tibcoConfig;
	private Map<String, String> _mongoDBConfiguration;
	private String _eventType;
	private int _responseDeadlineMinutes;
	
	public SparkMongoFunction(Map<String,String> tibcoConfig,Map<String, String> mongoDBConfiguration,String eventType,int responseDeadlineMinutes){
		_tibcoConfig=tibcoConfig;
		_mongoDBConfiguration=mongoDBConfiguration;
		_eventType=eventType;
		_responseDeadlineMinutes=responseDeadlineMinutes;
	}
	
	public Void call(JavaRDD<String> jsonRDD) throws Exception {
		if(jsonRDD.count()>0){
			JavaRDD<String> distinctjsonRDD=jsonRDD.distinct();
		
			TransactionMREReq transactionMREReq=new TransactionMREReq();
			TransactionMRERes transactionMRERes=new TransactionMRERes();
			String geoRecommendationString="";		
			TransactionMREFlatRes transactionMREFlatRes=new TransactionMREFlatRes();
			FlattenRequest flattenRequest=new FlattenRequest();
			String flattenedString="";
			String jsondata="";
			String copTransactionID="";
			String _tibcoPassword=_tibcoConfig.get(AppConstants.QUEUE_PASSWORD);
			SimpleDateFormat df = new SimpleDateFormat(AppConstants.TIMESTAMP_DATE_FORMAT);
			GsonBuilder gson_builder = new GsonBuilder();
            gson_builder.registerTypeAdapter(XMLGregorianCalendar.class,
                    new XMLGregorianCalendarConvertor.Serializer());
            gson_builder.registerTypeAdapter(XMLGregorianCalendar.class,
                    new XMLGregorianCalendarConvertor.Deserializer());
            Gson gson = gson_builder.create();
			List<String> documents = distinctjsonRDD.collect();
			for(String doc: documents){
				transactionMREReq=gson.fromJson(doc, TransactionMREReq.class);
				String requestTime=transactionMREReq.getRequestDateTime();
				copTransactionID=transactionMREReq.getCOPTransactionID();
				if(requestTime==null || requestTime.isEmpty()){
					continue;
				}
				System.out.println(">>>>>>>Processed Document:\n" + doc);
				Date requestDate=df.parse(requestTime);
				Date currentDate=new Date();
				Date responseTimeLimit=DateUtils.addMinutes(requestDate, _responseDeadlineMinutes);
				if(currentDate.after(responseTimeLimit)){
					try {
						BeanUtils.copyProperties(transactionMRERes, transactionMREReq);
					} catch (Exception e) {
						e.printStackTrace();
						System.out.println("Unable to copy objects");
					}
					geoRecommendationString = AppConstants.DEFAULT_RESPONSE;
					transactionMREFlatRes.setStatus(AppConstants.DEFAULT_PUBLSIH);
					if (transactionMREReq.getGeoRecommendation().equals("Y")){
						transactionMRERes.setGeoMerchantID(geoRecommendationString);
						transactionMRERes.setNonGeoMerchantID("");
					}else if(transactionMREReq.getNonGeoRecommendation().equals("Y")){
						transactionMRERes.setNonGeoMerchantID(geoRecommendationString);
						transactionMRERes.setGeoMerchantID("");
					}

					try {
						jsondata = JAXBHelperFunction.marshal(transactionMRERes , _eventType);
					} catch (Exception e) {
						e.printStackTrace();
						logger.error("Unable to convert object to JSON");
					} 
//					try {
//						TibcoEMSService.getInstance(_tibcoConfig, _tibcoPassword).publish(jsondata,"");
//					} catch (Exception e) {
//						e.printStackTrace();
//						logger.info("Unable to publish to tibco EMS queue>>>>>>>>>>>>>>>> SSL Based");
//					}
					transactionMREFlatRes = flattenRequest.getTransactionMREFlatRes(transactionMREFlatRes, transactionMRERes);
					String responseDateTime = formatDate(System.currentTimeMillis(),AppConstants.TIMESTAMP_DATE_FORMAT);
					transactionMREFlatRes.setResponseDateTime(responseDateTime );
					transactionMREFlatRes.setResponseDateTime(responseDateTime );
					try {
						flattenedString=convertObjectToJson(transactionMREFlatRes, _eventType, false);
					} catch (Exception e) {
						e.printStackTrace();
						
						logger.error("Unable to convert object to JSON");
					}
					MongoDBService mongoService=null;
					try {
						mongoService = MongoDBService.getInstance(_mongoDBConfiguration);
					} catch (Exception e) {
						e.printStackTrace();
						logger.error("Unable to get instance of MongoDbService");
					}							
					String collectionName = _mongoDBConfiguration.get(AppConstants.MONGODB_DB_COLLECTION);
					String[] collectionNames=collectionName.split(",");
					mongoService.SaveDocument(collectionNames[1], flattenedString);
					
					mongoService.updateResponseFlag(collectionNames[0],copTransactionID);
				}
			}
		}
		
		return null;
	}

	private String convertObjectToJson(Object object, String _eventType2, boolean possibleReasonLogCall) {
		// TODO Auto-generated method stub
		
		String jsonString="";
		if(_eventType2.startsWith(AppConstants.CB_MRE)){
			Gson gObj = new Gson();
			if (possibleReasonLogCall) {
				TransactionMREReq transactionMREReq =(TransactionMREReq)object;
				jsonString = gObj.toJson(transactionMREReq);
			} else {
				TransactionMREFlatRes transactionMRERes =(TransactionMREFlatRes)object;
				jsonString = gObj.toJson(transactionMRERes);
			}
		}
	
		return jsonString;
	}
	
	private String formatDate(long timeinMilliSec, String dateFormat) {
		SimpleDateFormat df = new SimpleDateFormat(dateFormat);
		GregorianCalendar cal = new GregorianCalendar();
		cal.setTimeInMillis(timeinMilliSec);
		String date = df.format(cal.getTime());

		return date;
	}

}
