package eap2.rts.spark.service;

import java.lang.reflect.Type;

import javax.xml.datatype.DatatypeFactory;
import javax.xml.datatype.XMLGregorianCalendar;

import com.google.gson.JsonDeserializationContext;
import com.google.gson.JsonDeserializer;
import com.google.gson.JsonElement;
import com.google.gson.JsonPrimitive;
import com.google.gson.JsonSerializationContext;
import com.google.gson.JsonSerializer;

public class XMLGregorianCalendarConvertor {
    public static class Serializer implements JsonSerializer {
        public Serializer() {
            super();
        }
        public JsonElement serialize(Object t, Type type,
                JsonSerializationContext jsonSerializationContext) {
            XMLGregorianCalendar xgcal = (XMLGregorianCalendar) t;
            return new JsonPrimitive(xgcal.toXMLFormat());
        }
    }
    public static class Deserializer implements JsonDeserializer {
        public Object deserialize(JsonElement jsonElement, Type type,
                JsonDeserializationContext jsonDeserializationContext) {
            try {
            	String stringDate=jsonElement.getAsJsonObject().toString();
            	String actualDate=stringDate.substring(1,stringDate.lastIndexOf("}"));
            	String[] dateArray=actualDate.split(",");
            	String yearString=dateArray[0];
            	String monthString=dateArray[1];
            	String dayString=dateArray[2];
            	String hrsString=dateArray[3];
            	String minString=dateArray[4];
            	String secString=dateArray[5];
            	String timezoneString=dateArray[6];
            	
            	String[] yearStringArray=yearString.split(":");
            	String[] monthStringArray=monthString.split(":");
            	String[] dayStringArray=dayString.split(":");
            	String[] hrsStringArray=hrsString.split(":");
            	String[] minStringArray=minString.split(":");
            	String[] secStringArray=secString.split(":");
            	String[] timezoneStringArray=timezoneString.split(":");
            	
            	int year=Integer.parseInt(yearStringArray[1]);
            	int month=Integer.parseInt(monthStringArray[1]);;
            	int day=Integer.parseInt(dayStringArray[1]);;
            	int hrs=Integer.parseInt(hrsStringArray[1]);;
            	int min=Integer.parseInt(minStringArray[1]);;
            	int sec=Integer.parseInt(secStringArray[1]);;
            	int tz=Integer.parseInt(timezoneStringArray[1]);;
            	
                return DatatypeFactory.newInstance().newXMLGregorianCalendar(year,month,day,hrs,min,sec,000, tz);
            } catch (Exception e) {
            	e.printStackTrace();
                return null;
            }
        }
    }
}
