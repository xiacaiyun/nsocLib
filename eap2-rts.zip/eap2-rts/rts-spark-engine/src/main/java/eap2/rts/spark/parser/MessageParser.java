/**
 * 
 */
package eap2.rts.spark.parser;

import java.io.IOException;

import javax.xml.bind.JAXBException;

import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.databind.JsonMappingException;

/**
 * @author as35686
 *
 */
public interface MessageParser {
 Object parse(String jsonString, String eventType) throws JsonParseException, JsonMappingException, IOException,JAXBException;
}
