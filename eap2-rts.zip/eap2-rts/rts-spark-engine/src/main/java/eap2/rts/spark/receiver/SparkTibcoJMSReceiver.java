package eap2.rts.spark.receiver;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.apache.spark.storage.StorageLevel;
import org.apache.spark.streaming.receiver.Receiver;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import eap2.rts.common.event.dto.SimpleRequestObject;
import eap2.rts.spark.AppConstants;
import scala.Tuple2;

/**
 * @author bs34500
 */
public class SparkTibcoJMSReceiver extends Receiver<Tuple2<String, SimpleRequestObject>> {

	private static final long serialVersionUID = 2731593407916649533L;
	protected static final Logger logger = LoggerFactory.getLogger(SparkTibcoJMSReceiver.class);
	private Map<String, Map<String, String>> _appConfigs = null;
	private String _tibcoPassword = new String();
	private String _propertiesFilename = new String();
	private List<SparkTibcoJMSConsumer> jmsconsumers = new ArrayList<SparkTibcoJMSConsumer>();
	private List<SparkTibcoEMSConsumer> emsconsumers = new ArrayList<SparkTibcoEMSConsumer>();
	private List<Thread> _consumerThreads = new ArrayList<Thread>();

	public SparkTibcoJMSReceiver(StorageLevel storageLevel, Map<String, Map<String, String>> appConfigs, String tibcoPassword, String propertiesFilename) {
		super(storageLevel);
		this._appConfigs = appConfigs;
		this._tibcoPassword = tibcoPassword;
		this._propertiesFilename=propertiesFilename;
	}

	@Override
	public void onStart() {
		start();
	}

	public void start() {
		//logger.info("Inside SparkTibcoJMSReceiver->>>>>start->>>>>");
		Iterator<String> dsKeys = _appConfigs.keySet().iterator();
		while (dsKeys.hasNext()) {
			String dsKey = dsKeys.next();
			Map<String, String> dsConfig = _appConfigs.get(dsKey);
			SparkTibcoEMSConsumer emsQueueConsumer = null;
			if (dsConfig.get(AppConstants.P12_ENABLED).equals("false")) {
				SparkTibcoJMSConsumer jmsQueueConsumer = new SparkTibcoJMSConsumer(dsConfig, this, _tibcoPassword);
				jmsconsumers.add(jmsQueueConsumer);
			//	logger.info("Added JMS Consumer for DataSource =  " + dsKey);

				// Create exception handler
				Thread.UncaughtExceptionHandler eh = new Thread.UncaughtExceptionHandler() {
					public void uncaughtException(Thread th, Throwable ex) {
						// stop consumers
						for (SparkTibcoJMSConsumer jmsConsumer : jmsconsumers) {
							jmsConsumer.stop();
						}
						if (ex instanceof InterruptedException) {
							th.interrupt();
							stop("Stopping the SparkTibcoJMSReceiver due to " + ex);
						} else {
							restart("Restarting the SparkTibcoJMSReceiver ", ex, 3000);
						}
					}
				};

				for (SparkTibcoJMSConsumer jmsConsumer : jmsconsumers) {
					Thread consumerThread = new Thread(jmsConsumer);
					consumerThread.setDaemon(true);
					consumerThread.setUncaughtExceptionHandler(eh);
					consumerThread.start();
					_consumerThreads.add(consumerThread);
				}
			} else if (dsConfig.get(AppConstants.P12_ENABLED).equals("true")) {
				try {
					
					emsQueueConsumer = new SparkTibcoEMSConsumer(dsConfig, this, _tibcoPassword,_propertiesFilename);
					
				} catch (Exception e) {
					logger.error("SparkTibcoEMSConsumer-->>>>>Catch->>>>>starts->>>>>");
					logger.error("An error has occured", e);
				}
				emsconsumers.add(emsQueueConsumer);
			//	logger.info("Added EMS Consumer for DataSource =  " + dsKey);

				Thread.UncaughtExceptionHandler eh = new Thread.UncaughtExceptionHandler() {
					public void uncaughtException(Thread th, Throwable ex) {
						// stop consumers
						for (SparkTibcoEMSConsumer emsConsumer : emsconsumers) {
							emsConsumer.stop();
						}
						if (ex instanceof InterruptedException) {
							th.interrupt();
							stop("Stopping the SparkTibcoJMSReceiver due to " + ex);
						} else {
							restart("Restarting the SparkTibcoJMSReceiver ", ex, 3000);
						}
					}
				};

				for (SparkTibcoEMSConsumer emsConsumer : emsconsumers) {
					Thread consumerThread = new Thread(emsConsumer);
					consumerThread.setDaemon(true);
					consumerThread.setUncaughtExceptionHandler(eh);
					consumerThread.start();
					_consumerThreads.add(consumerThread);
				}
			}
		}

	}

	@Override
	public void onStop() {

	//	logger.info("Inside SparkTibcoJMSReceiver->>>>>start->>>>>");
		Iterator<String> dsKeys = _appConfigs.keySet().iterator();
		while (dsKeys.hasNext()) {
			String dsKey = dsKeys.next();
			Map<String, String> dsConfig = _appConfigs.get(dsKey);
			if (dsConfig.get(AppConstants.P12_ENABLED).equals("false")) {
				logger.info("SparkTibcoJMSReceiver->>>>>onStop->>>>>Debug->>>>>starts->>>>>");
				logger.info("Stoping JMS Receiver");
				logger.info("SparkTibcoJMSReceiver->>>>>onStop->>>>>Debug->>>>>ends->>>>>");
				for (SparkTibcoJMSConsumer jmsConsumer : jmsconsumers) {
					jmsConsumer.stop();
				}
				for (Thread consumerThread : _consumerThreads) {
					if (consumerThread.isAlive()) {
						consumerThread.interrupt();
					}
				}
			}

			else if (dsConfig.get(AppConstants.P12_ENABLED).equals("true")) {
				logger.info("SparkTibcoEMSReceiver->>>>>onStop->>>>>Debug->>>>>starts->>>>>");
				logger.info("Stoping EMS Receiver");
				logger.info("SparkTibcoEMSReceiver->>>>>onStop->>>>>Debug->>>>>ends->>>>>");

				for (SparkTibcoEMSConsumer emsConsumer : emsconsumers) {
					emsConsumer.stop();
				}
				for (Thread consumerThread : _consumerThreads) {
					if (consumerThread.isAlive()) {
						consumerThread.interrupt();
					}
				}

			}
		}

	}
}
