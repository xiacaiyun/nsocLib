/**
 * 
 */
package eap2.rts.spark.parser;

/**
 * @author as35686
 *
 */
public class ParserFactory {

	public static MessageParser getParser(String parserType) {
		MessageParser mParse = null;
		if (parserType.equalsIgnoreCase("JSON"))
			mParse = new JSONParser();
		else if (parserType.equalsIgnoreCase("XML"))
			mParse = new XMLParser();
		return mParse;
	}
}
