package eap2.rts.spark.service;

import java.io.File;
import java.util.Map;
import java.util.Properties;

import javax.jms.Connection;
import javax.jms.ConnectionFactory;
import javax.jms.JMSException;
import javax.jms.MessageProducer;
import javax.jms.Queue;
import javax.jms.Session;
import javax.jms.TextMessage;
import javax.naming.Context;
import javax.naming.InitialContext;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.FileSystem;
import org.apache.hadoop.fs.Path;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import eap2.rts.spark.AppConstants;

public class TibcoEMSService {

	private static final Logger logger = LoggerFactory.getLogger(TibcoEMSService.class);
	private static TibcoEMSService _instance = null;

	private ConnectionFactory _queueConnectionFactory = null;
	private Connection _queueConnection = null;
	private Queue _queue = null;
	private Session _queueSession = null;
	private MessageProducer _queueSender = null;
	private Properties env = new Properties();
	private Map<String, String> _tibcoEMSConfig;
	private String _tibcoPassword = new String();
	
	
	public static String copyP12File(String hdfs_path) throws Exception {
		String result = null;
		Configuration conf = new Configuration();
		FileSystem hdfsFileSystem = FileSystem.get(conf);
		Path hdfs = new Path(hdfs_path);
		
		String splitString[] = hdfs_path.split("/");
		
		String fid = splitString[4];
		String certName = splitString[6];
		
		Path local = new Path("/tmp/" + fid + "_p12Cert");
		File file = new File("/tmp/" + fid + "_p12Cert/"+certName);
		
		if (hdfsFileSystem.exists(hdfs)) {
			if (file.exists()) {
				result = "/tmp/" + fid + "_p12Cert/" + certName;
			} else {
				new File("/tmp/" + fid + "_p12Cert").mkdir();
				hdfsFileSystem.copyToLocalFile(false, hdfs, local, true);
				result = "/tmp/" + fid + "_p12Cert/" + certName;
			}
		} else {
			logger.info("Inside copyP12File->>>>> file does not exists in hdfs");
		}
		logger.info("Inside TibcoEMSService>>>>>> copyP12File->>>>>result->>>>>" + result);
		return result;
		
	}
	

	private TibcoEMSService(Map<String, String> tibcoEMSConfig , String tibcoPassword) throws Exception {
		this._tibcoEMSConfig = tibcoEMSConfig;
		this._tibcoPassword = tibcoPassword;
		
		env.put(Context.INITIAL_CONTEXT_FACTORY, _tibcoEMSConfig.get(AppConstants.CONN_FACTORY));
		env.put(Context.PROVIDER_URL, _tibcoEMSConfig.get(AppConstants.PROVIDER_URL));	
		env.put(Context.SECURITY_PRINCIPAL, _tibcoEMSConfig.get(AppConstants.QUEUE_USERNAME));
		env.put(Context.SECURITY_CREDENTIALS, _tibcoPassword);
		env.put(AppConstants.SEC_PROTOCOL, _tibcoEMSConfig.get(AppConstants.SEC_PROTOCOL));
		env.put(AppConstants.ENABLE_VERIFY_HOST, _tibcoEMSConfig.get(AppConstants.ENABLE_VERIFY_HOST));
		env.put(AppConstants.SSL_VENDOR, _tibcoEMSConfig.get(AppConstants.SSL_VENDOR));
		env.put(AppConstants.SSL_PROVIDER, _tibcoEMSConfig.get(AppConstants.SSL_PROVIDER));
		env.put(AppConstants.SSL_AUTH_ONLY, _tibcoEMSConfig.get(AppConstants.SSL_AUTH_ONLY));
		env.put(AppConstants.TIBCO_SEC_VENDOR, _tibcoEMSConfig.get(AppConstants.TIBCO_SEC_VENDOR));
		env.put(AppConstants.SSL_IDENTITY,copyP12File(_tibcoEMSConfig.get(AppConstants.SSL_IDENTITY)));
		env.put(AppConstants.SSL_PASSWORD,_tibcoPassword);
		
	}

	public static TibcoEMSService getInstance(Map<String, String> tibcoEMSConfig, String _tibcoPassword2) throws Exception {
		if (_instance == null) {
			_instance = new TibcoEMSService(tibcoEMSConfig,_tibcoPassword2);
			_instance.open();
		}
		return _instance;
	}

	public void open() throws Exception {
		try {
			Context ctx = new InitialContext(env);
			_queueConnectionFactory = (ConnectionFactory) ctx.lookup(_tibcoEMSConfig.get(AppConstants.QUEUE_CF));
			_queueConnection = _queueConnectionFactory.createConnection(_tibcoEMSConfig.get(AppConstants.QUEUE_USERNAME), _tibcoPassword);
			_queueConnection.start();
		} catch (Exception e) {
			logger.error("Inside TibcoEMSPublisherService->>>>>open->>>>>error>>starts");
			logger.error("An error has occured.", e);
			logger.error("Inside TibcoEMSPublisherService->>>>>open->>>>>error>>ends");
			throw e;
		}
	}

	/**
	 * @param requestMessageId
	 * @param messages
	 * @throws JMSException
	 */
	public void publish(String message, String requestMessageId) throws JMSException {
	//	logger.info("Inside TibcoEMSPublisherService->>>>>publish->>>>>");
		if (message == null) {
			return;
		}

		/*
		 * Create connection. Create session from connection. Create sender. Create text message. Send messages. Send
		 * non text message to end text messages. Close connection.
		 */
		try {
			_queueSession = _queueConnection.createSession(false, Session.AUTO_ACKNOWLEDGE);
			_queue= _queueSession.createQueue(_tibcoEMSConfig.get(AppConstants.QUEUE_NAME));
			_queueSender = _queueSession.createProducer(_queue);
			TextMessage textMessage = _queueSession.createTextMessage();
			textMessage.setText(message);
			textMessage.setJMSCorrelationID(requestMessageId);
			_queueSender.send(textMessage);
			_queueSender.close();
			_queueSession.close();
		} catch (JMSException e) {
			logger.error("Inside TibcoEMSPublisherService->>>>>publish->>>>>error>>starts");
			logger.error("An error has occured.", e);
			logger.error("Inside TibcoEMSPublisherService->>>>>publish->>>>>error>>ends");
			throw e;
		}
	}

	@Override
	protected void finalize() throws Throwable {
		try {
			if (_queueConnection != null) {
				_queueConnection.close();
			}
		} catch (Throwable throwable) {
			logger.error("Inside TibcoEMSPublisherService->>>>>finalize->>>>>error>>starts");
			logger.error(throwable.getMessage());
			logger.error("Inside TibcoEMSPublisherService->>>>>finalize->>>>>error>>ends");
			throw throwable;
		}
	}
}
