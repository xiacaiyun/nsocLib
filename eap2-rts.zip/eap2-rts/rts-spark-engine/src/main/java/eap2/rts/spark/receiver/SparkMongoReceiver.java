package eap2.rts.spark.receiver;

import org.apache.spark.storage.StorageLevel;
import org.apache.spark.streaming.receiver.Receiver;
import org.bson.Document;

import com.mongodb.BasicDBObject;
import com.mongodb.MongoClient;
import com.mongodb.MongoClientURI;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoCursor;
import com.mongodb.client.MongoDatabase;

public class SparkMongoReceiver extends Receiver<String> {
	private static final long serialVersionUID = 2820260326654589309L;
	private String dbURI = null;
	private String collectionName = null;

	public SparkMongoReceiver(StorageLevel storageLevel_, String dbURI_, String collectionName_) {
		super(storageLevel_);
		dbURI = dbURI_;
		
		collectionName = collectionName_;
	}

	@Override
	public void onStart() {
		new Thread()  {
		      @Override 
		      public void run() {
		        receive();
		      }
		    }.start();
	}

	@Override
	public void onStop() {
		// There is nothing much to do as the thread calling receive()
		// is designed to stop by itself isStopped() returns false
	}

	private void receive() {
		try {
			System.out.println("Inside Receive Mongo receiver");
			MongoClientURI uri = null;
			MongoClient mongoClient = null;
			MongoDatabase db = null;
			MongoCollection<Document> requestCollection = null;
			BasicDBObject query=new BasicDBObject();
			query.put("ResponseFlag", "N");

			try {
				// connect to the server
				uri = new MongoClientURI(dbURI);
				mongoClient = new MongoClient(uri);
				db = mongoClient.getDatabase(uri.getDatabase());
				String[] collectionNames=collectionName.split(",");
				requestCollection = db.getCollection(collectionNames[0]);
				// Until stopped or connection broken continue reading
				while (!isStopped()) {
					// Write Query here
					MongoCursor<Document> cursor = requestCollection.find(query).iterator();
					while (cursor.hasNext()) {
						Document doc = cursor.next();
						String json = doc.toJson();
						//System.out.println("JSON Record Received: " + json);
						store(json);
					}
					cursor.close();
				}
				Thread.sleep(300);
			} finally {
				mongoClient.close();
			}
			// Restart in an attempt to connect again when server is active again
			restart("Trying to connect again");
		} catch (Exception ce) {
			// restart if could not connect to server
			restart("Could not connect", ce);
		} catch (Throwable t) {
			restart("Error receiving data", t);
		}
	}
}