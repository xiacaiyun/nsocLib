package eap2.rts.spark;

import org.apache.spark.SparkConf;
import org.slf4j.LoggerFactory;
import java.util.logging.Logger;
import eap2.rts.common.SysConstants;
import scala.Tuple2;

import org.apache.hadoop.fs.FileStatus;
import org.apache.hadoop.fs.FileSystem;
import org.apache.hadoop.fs.FileUtil;
import org.apache.log4j.Category;


import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.URI;

import org.apache.commons.io.FileSystemUtils;
import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.FileSystem;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.IOUtils;
import eap2.rts.pwp.PWPUtilMain;


public class pytest {
	

    public static void main(String[] args) throws IOException {
     
        try {
        	
        
        Configuration conf = new Configuration();
        conf.set("HDFS_ROOT_URL", "hdfs://gcgmwdcdev");
		conf.addResource(new Path("/etc/hadoop/conf.cloudera.hdfs/core-site.xml"));
		conf.addResource(new Path("/etc/hadoop/conf.cloudera.hdfs/hdfs-site.xml"));
		conf.set("fs.hdfs.impl", "org.apache.hadoop.hdfs.DistributedFileSystem");
		conf.set("fs.file.impl", "org.apache.hadoop.fs.LocalFileSystem");
		conf.set("hadoop.security.authentication", "kerberos");
		conf.set("hadoop.security.authorization", "true");
		 Path local = new Path("/tmp/");
		 
	//	String local1 = "/tmp/ivr_code/";
		String hdfs =	"/tmp/rts/python/";
		       FileSystem fs = FileSystem.get(conf);
		     //  fs.create(local);
		       
		     // boolean  localr =       new File("/tmp/ivr_code/").mkdir();
		   // boolean path =    fs.mkdirs(local);
		 
		        FileStatus[] status = fs.listStatus(new Path("/tmp/rts/python/"));
		        for(int i=0;i<status.length;i++){
		            System.out.println(status[i].getPath());
		          //  System.out.println(local1);
		            fs.copyToLocalFile(false, status[i].getPath(),local, true);
		        
		        }
		        
		    
		        
		    /*    FileSystem fs = FileSystem.get(conf);
		        File dir = new File(hdfs);
		        for (File file : dir.listFiles()) {
	                fs.copyToLocalFile(new Path(file.getPath()),
	                        new Path(local, file.getName()));
	            }
		        
		        	FileSystem fs = FileSystem.get(conf);
		OutputStream os = fs.create(local);
		InputStream is = new BufferedInputStream(new FileInputStream(hdfs));//Data set is getting copied into input stream through buffer mechanism.
		IOUtils.copyBytes(is, os, conf);
		        
		        
		        */
		      
		        
		     //   fs.close();
		        String python_code = "/tmp/ivr_model_context.py";
				String conf_file = "/tmp/ivr_model_context.conf";
				String config_section_name = "eap_dev";
				// String python_code =
				// "/data/1/gcgdma/bin/apps/IVR/RT/EAP/code/ivr_model_context.py";
				// String conf_file =
				// "/home/ss36531/IVR/ivr_model_context.conf";
				// String config_section_name= "eap_dev";
				String customerid = "75002246";

				// python35 /home/ss36531/IVR/ivr_model_context.py
				// 75002246
				String requestDateTime = "2018-05-10 00:07:18.555";
				// /home/ss36531/IVR/ivr_model_context.conf eap_dev

				callPythonScript(requestDateTime, python_code, conf_file, config_section_name, customerid);
		       
		
        }
		       
		    catch (IOException e) {
		        e.printStackTrace();
		    }
		   
    }        
	   // FileUtil.copy(hdfsFileSystem, hdfs, localFileSystem, local, false, false, conf);
	    
//FileUtil.copy(hdfsFileSystem, hdfs, local, false, conf);
	/*  FileSystem hdfsFileSystem = FileSystem.get(conf);
		
	  //  FileSystem localFileSystem  = local.getFileSystem(conf1);
	    Path hdfs = new Path("/tmp/rts/python/");
	    Path local = new Path("/tmp/rts/");
	    
        hdfsFileSystem.copyToLocalFile(false,hdfs, local,true);
        }
	       
	    catch (IOException e) {
	        e.printStackTrace();
	    }
	 * 
	 *   
	 *   if (hdfsFileSystem.exists(hdfs))
	 */
	    
	       // hdfsFileSystem.copyToLocalFile(false,hdfs, local,true);
	        
	    
	  /*  else {
			throw new RuntimeException("Unable to find files in path: " + hdfs);
		}
	  
	    hdfsFileSystem.close();
    /opt/cloudera/parcels/citiconda3-1.1.2/bin/python3
    
    */
    
    private static void callPythonScript(String requestDateTime, String python_code, String conf_file,
			String config_section_name, String customerid) {

		
		try {
			
			
			
			System.out.println("Inside PythonsCRIPTTTTTTTTTT>>..");
			Process process = Runtime.getRuntime().exec(new String[] { "python35", python_code, customerid,
					"\"" + requestDateTime + "\"", conf_file, config_section_name,"--export_rsn_cde", "-p", "P5MwnVbm" });

			// ("python35
			// /data/1/gcgdma/bin/apps/IVR/RT/EAP/code/ivr_model_context.py "
			// +customerid+"" +date+ "/home/ss36531/IVR/ivr_model_context.conf"
			// +config_section_name);
			// process.waitFor(3, TimeUnit.MINUTES);

			InputStream stderr = process.getErrorStream();
			InputStreamReader isr = new InputStreamReader(stderr);
			BufferedReader br = new BufferedReader(isr);
			String line = null;
			System.out.println("<ERROR>");
			while ((line = br.readLine()) != null)
				System.out.println(line);
			System.out.println("</ERROR>");
			int exitVal = process.waitFor();
			System.out.println("Process exitValue: " + exitVal);
			System.out.println("After processsssssssssssss >>..");
		} catch (Exception ex) {
			System.out.println("Exception in PYTHON script" + ex);
		}
	}
    
}