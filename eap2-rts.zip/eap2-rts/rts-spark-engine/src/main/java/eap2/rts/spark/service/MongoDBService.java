/**
 * 
 */
package eap2.rts.spark.service;

import java.io.Serializable;
import java.text.SimpleDateFormat;
import java.time.ZonedDateTime;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Collection;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.regex.Pattern;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Category;
import org.apache.log4j.Logger;

import com.mongodb.BasicDBList;

import com.mongodb.BasicDBObject;
import com.mongodb.DB;
import com.mongodb.DBCollection;
import com.mongodb.DBCursor;
import com.mongodb.DBObject;
import com.mongodb.MongoClient;
import com.mongodb.MongoClientURI;
import com.mongodb.util.JSON;
import com.tibco.schemas.copsrainbow.sharedresources.schemas.eventschema.mretransaction.TransactionMREReq;

import eap2.rts.common.event.dto.PredictReason;
import eap2.rts.spark.AppConstants;

/**
 * @author bs34500
 */
public class MongoDBService implements Serializable {
	private static final long serialVersionUID = -3748631202108050372L;
	private static Logger sLogger = Logger.getLogger(MongoDBService.class);
	private static MongoDBService _instance = null;
	private Map<String, String> _mongoDBConfiguration = null;
	private MongoClient mongoClient = null;
	private DB mongoDB = null;

	private MongoDBService(Map<String, String> mongoDBConfiguration) throws Exception {
		this._mongoDBConfiguration = mongoDBConfiguration;
		init();
	}

	private void init() throws Exception {
		String mongoDBURI = _mongoDBConfiguration.get(AppConstants.MONGODB_URI);
		String mongoDBName = _mongoDBConfiguration.get(AppConstants.MONGODB_DB_NAME);
		MongoClientURI uriObj = new MongoClientURI(mongoDBURI);
		mongoClient = new MongoClient(uriObj);
		mongoDB = mongoClient.getDB(mongoDBName);
		
	}

	public static MongoDBService getInstance(Map<String, String> mongoDBConfiguration) throws Exception {
		if (_instance == null) {
			_instance = new MongoDBService(mongoDBConfiguration);
		}
		return _instance;
	}

	public void SaveDocument(String collectionName, String json) {
		DBObject dbObject = (DBObject) JSON.parse(json);
		DBCollection collection = mongoDB.getCollection(collectionName);
		collection.insert(dbObject);
		
	}
	
	public void deleteCollection(String collectionName) {
		DBCollection collection = mongoDB.getCollection(collectionName);
		collection.drop();
	}

	public List<PredictReason> retriveReasons(String customerID, String collectionName, String countryCode) {
		DBCollection collection = mongoDB.getCollection(collectionName);
		List<PredictReason> reasonList = new ArrayList<PredictReason>();
		DBObject query = new BasicDBObject();
		query.put("clnt_nbr", customerID);
		query.put("cntry_cde", countryCode);
		DBCursor cursor = collection.find(query);
		while (cursor.hasNext()) {
			BasicDBObject record = new BasicDBObject();
			PredictReason reason1 = new PredictReason();
			PredictReason reason2 = new PredictReason();
			PredictReason reason3 = new PredictReason();
			record = (BasicDBObject) cursor.next();
			reason1.setReasoncode(record.getString("call_rsn_cd_1"));
			reason2.setReasoncode(record.getString("call_rsn_cd_2"));
			reason3.setReasoncode(record.getString("call_rsn_cd_3"));
			reason1.setReasondescription(record.getString("call_rsn_1"));
			reason2.setReasondescription(record.getString("call_rsn_2"));
			reason3.setReasondescription(record.getString("call_rsn_3"));
			reason1.setContext(record.getString("context_1"));
			reason2.setContext(record.getString("context_2"));
			reason3.setContext(record.getString("context_3"));
			reasonList.add(reason1);
			reasonList.add(reason2);
			reasonList.add(reason3);
			
		}
		int count = cursor.count();
		if(cursor != null){
		cursor.close();
		}
		return reasonList;
	}

	public void retriveRecord(String collectionName) {
		DBCollection collection = mongoDB.getCollection(collectionName);
		
		DBCursor cursor = collection.find();
		int i = 1;
		while (cursor.hasNext()) {
			i++;
		}
		int count = cursor.count();
		}
	public List<String> retriveMerchantDescription(TransactionMREReq transactionMREReq,String collectionName) {

		String grbCustomerNumber = transactionMREReq.getCustomerNo();
		String countryCode = transactionMREReq.getTransaction().getTransactionCard().getCountryCode();
		
		DBCollection collection = mongoDB.getCollection(collectionName);
				
		
		List<String> merchantDesriptionList = new ArrayList<String>();
		DBObject query=new BasicDBObject(); 
		
		Calendar cal =Calendar.getInstance();
		
		cal.add(cal.DATE, -50);
		SimpleDateFormat df=new SimpleDateFormat(AppConstants.MIS_DATE_FORMAT);
		String date=df.format(cal.getTime());
		
		String[] dateArray1=date.split("-");
		int year=Integer.parseInt(dateArray1[0]);
		int month=Integer.parseInt(dateArray1[1]);
		int day=Integer.parseInt(dateArray1[2]);
		


		DBObject yearTimespan = new BasicDBObject();
		yearTimespan.put("$gt", year);
		DBObject monthTimespan = new BasicDBObject();
		monthTimespan.put("$gt", month);
		DBObject dayTimespan = new BasicDBObject();
		dayTimespan.put("$gte", day);
		query.put("transaction.transactionDetail.transactionDate.year", yearTimespan);
		query.put("customerNo", grbCustomerNumber);
		query.put("transaction.transactionCard.countryCode", countryCode);
		
		DBCursor cursor = collection.find(query);
		while (cursor.hasNext()) {
			BasicDBObject record = (BasicDBObject) cursor.next();
			merchantDesriptionList.add(getFieldFromCursor(record, "transaction.transactionCard.crdAcceptRec").toString());
			
		}

		
		DBObject query1=new BasicDBObject();
		query1.put("transaction.transactionDetail.transactionDate.year", year);
		query1.put("transaction.transactionDetail.transactionDate.month", monthTimespan);
		query1.put("customerNo", grbCustomerNumber);
		query1.put("transaction.transactionCard.countryCode", countryCode);
		
		DBCursor cursor1 = collection.find(query1);
		while (cursor1.hasNext()) {
			BasicDBObject record = (BasicDBObject) cursor1.next();
			merchantDesriptionList.add(getFieldFromCursor(record, "transaction.transactionCard.crdAcceptRec").toString());
			
		}

		DBObject query2=new BasicDBObject();
		query2.put("transaction.transactionDetail.transactionDate.year", year);
		query2.put("transaction.transactionDetail.transactionDate.month", month);
		query2.put("transaction.transactionDetail.transactionDate.day", dayTimespan);
		query2.put("customerNo", grbCustomerNumber);
		query2.put("transaction.transactionCard.countryCode", countryCode);
		
		DBCursor cursor2 = collection.find(query2);
		while (cursor2.hasNext()) {
			BasicDBObject record = (BasicDBObject) cursor2.next();
			merchantDesriptionList.add(getFieldFromCursor(record, "transaction.transactionCard.crdAcceptRec").toString());
			
		}
		int count = cursor.count();
		int count1= cursor1.count();
		int count2 = cursor2.count();
		int totalCount=count+count1+count2;
		if(cursor != null || cursor1!=null || cursor2!=null ){
			cursor.close();
			cursor1.close();
			cursor2.close();
		
		}
		System.out.println("merchantDesriptionList>>>>>>>>>>>>>>>>>.. Inside func" +merchantDesriptionList);
		
		return merchantDesriptionList;
		
	}

	public String retriveMerchantName(TransactionMREReq transactionMREReq,String merchantDescription,String collectionName, String collectionName1) {
		
		String isoCode=transactionMREReq.getTransaction().getTransactionCard().getCountryCode();
		
		DBCollection collection1 = mongoDB.getCollection(collectionName1);
		String countryCode=null;
		DBObject query12=new BasicDBObject();
		query12.put("isocode",isoCode);
		BasicDBObject record12=(BasicDBObject)collection1.findOne(query12);
		
		
		if(record12!=null){
	       countryCode = getFieldFromCursor(record12, "Alpha2").toString();   
	       System.out.println("Country codeee>>>>" +countryCode);
		}
		
		DBCollection collection = mongoDB.getCollection(collectionName);
		String merchantName = new String();
		DBObject query=new BasicDBObject();
		query.put("description", merchantDescription);
		query.put("country_code", countryCode);
		DBCursor cursor = collection.find(query);
		
		System.out.println("cursor>>>>....."+ cursor.toString());
		while (cursor.hasNext()) {
			BasicDBObject record = (BasicDBObject) cursor.next();
			merchantName=getFieldFromCursor(record, "merchant_nm").toString();
			System.out.println("Merchant Nameee>>>" +merchantName);
			
		}
		int count = cursor.count();
		if(cursor != null){
			cursor.close();
			}
			
		return merchantName;
	}
	private Object getFieldFromCursor(DBObject o, String fieldName) {

		final String[] fieldParts = StringUtils.split(fieldName, '.');

		int i = 1;
		Object val = o.get(fieldParts[0]);

		while(i < fieldParts.length && val instanceof DBObject) {
			val = ((DBObject)val).get(fieldParts[i]);
			i++;
		}
		if(val==null){
			val="";
		}
		return val;
	}
	public String lookUpGeo(TransactionMREReq transactionMREReq,List<String> merchants,String collectionName1,String collectionName2,String collectionName3) {  
	DBCollection collection = mongoDB.getCollection(collectionName1);
	DBCollection merchantNormalizedCollection = mongoDB.getCollection(collectionName2);
	StringBuffer geoRecommendationString=new StringBuffer();
	String isoCode=transactionMREReq.getTransaction().getTransactionCard().getCountryCode();
	
	DBCollection collection1 = mongoDB.getCollection(collectionName3);
	String countryCode=null;
	DBObject query12=new BasicDBObject();
	query12.put("isocode",isoCode);
	BasicDBObject record12=(BasicDBObject)collection1.findOne(query12);
	if(record12!=null){
       countryCode = getFieldFromCursor(record12, "Alpha2").toString();   
	}		
	//  String[] merchants = "WESTIN;W BANGKOK;VILLA MARKET".split(";");
	if(merchants.size()>0){
		BasicDBList or = new BasicDBList();
		for(String merchant : merchants){
			if(merchant.isEmpty() || merchant == null || merchant.equals("")){
				continue;
			}
			DBObject clause1 = new BasicDBObject("sequence", Pattern.compile(Pattern.quote(merchant), Pattern.CASE_INSENSITIVE));
			or.add(clause1);
		}

		DBObject query = new BasicDBObject();
		query.put("$or", or);
		query.put("country_code",countryCode);
		DBCursor cursor = collection.find(query).sort(new BasicDBObject("confidence",-1)).sort(new BasicDBObject("support",-1)).limit(2000);
		int count=0;
		List<BasicDBObject> matchedRecordList=new ArrayList<BasicDBObject>();
		while(cursor.hasNext()){
			BasicDBObject record = (BasicDBObject) cursor.next();
			String sequence=getFieldFromCursor(record, "sequence").toString();
			String[] sequenceArray=sequence.split(":");
			List<String> lookupList=new ArrayList<String>();
			for(String sequenceString:sequenceArray){
				if(merchants.contains(sequenceString)){
					lookupList.add(sequenceString);
				}
			}
			int lookupListSize=lookupList.size();
			
			System.out.println("Lookuplist >>>>>>>>>>>>>>>" +lookupList);
			
			int sequenceArraySize=sequenceArray.length;
			if(lookupListSize==sequenceArraySize){
				matchedRecordList.add(record);
				count++;
			}
			System.out.println("matchedRecordList >>>>>>>>>>>>>>>" +matchedRecordList);
		}
		
			


		String merchantName;
		String merchantId;
		Set<String> matchedRecordSet = new HashSet<String>();
		List<BasicDBObject> recommendationList=new ArrayList<BasicDBObject>();
		
		
		for(BasicDBObject obj: matchedRecordList){
			String merchant=getFieldFromCursor(obj, "merchant_nm").toString();
			if(matchedRecordSet.contains(merchant)){
				continue;
			}else{
				matchedRecordSet.add(merchant);
				recommendationList.add(obj);
			}
		}
		
		System.out.println("matchedRecordSet >>>>>>>>>>>>>>>" +matchedRecordSet);
		System.out.println("recommendationList >>>>>>>>>>>>>>>" +recommendationList);
		
		int size=recommendationList.size();
		System.out.println("Size:::;>>>>. " +size);
		
		if(size>30){
			for(int counter=0;counter<30;counter++){
				BasicDBObject matchedrecord = (BasicDBObject) recommendationList.get(counter);
				merchantName=getFieldFromCursor(matchedrecord, "merchant_nm").toString();
				DBObject merchantNameQuery=new BasicDBObject();
				merchantNameQuery.put("merchant_nm", merchantName);
				merchantNameQuery.put("country_code", countryCode);
				BasicDBObject record=(BasicDBObject)merchantNormalizedCollection.findOne(merchantNameQuery);
				if(record!=null){
					merchantId=getFieldFromCursor(record, "ref_id").toString();
					geoRecommendationString.append(merchantId);   
					System.out.println("merchantId:::;>>>>. " +merchantId);
					
				}
				if(counter!=29){
					geoRecommendationString.append(",");
				}

			}
		}else if(size<=30){

			for(int counter=0;counter<size;counter++){
				BasicDBObject matchedrecord = (BasicDBObject) recommendationList.get(counter);
				merchantName=getFieldFromCursor(matchedrecord, "merchant_nm").toString();
				DBObject merchantNameQuery=new BasicDBObject();
				merchantNameQuery.put("merchant_nm", merchantName);
				merchantNameQuery.put("country_code", countryCode);
				BasicDBObject record=(BasicDBObject)merchantNormalizedCollection.findOne(merchantNameQuery);
				if(record!=null){
					merchantId=getFieldFromCursor(record, "ref_id").toString();
					geoRecommendationString.append(merchantId);   
					
					System.out.println("merchantId:::;>>>>. " +merchantId);
				}
				if(counter!=size-1){
					geoRecommendationString.append(",");
				}
			}

			int counter=1;
			while(counter<=30-size){
				geoRecommendationString.append(",");
				counter++;
			}
		}
		String geoString = transactionMREReq.getGeoRecommendation();
		String geoRecString= geoRecommendationString.toString();	
	    String[] s2 = geoString.split(",");
	    String[] s1 = geoRecString.split(","); 
	    ArrayList<String> geoRecommendationStringNew = new ArrayList(Arrays.asList(s1));
	        for (String s : s2) {
	           if (geoRecommendationStringNew.contains(s)) {
	        	   geoRecommendationStringNew.remove(s);
	               } 
	              }  
	        size = geoRecommendationStringNew.size();   
		StringBuffer geoRecommendationStringfinal=new StringBuffer();
		
		if(size>20){
			for(int counter=0;counter<20;counter++){
				String str= geoRecommendationStringNew.get(counter);
					geoRecommendationStringfinal.append(str);   
				if(counter!=19)
					geoRecommendationStringfinal.append(",");			

			}
	}
		else if(size<=20){

			for(int counter=0;counter<size;counter++){
				String str= geoRecommendationStringNew.get(counter);
					geoRecommendationStringfinal.append(str);
				if(counter!=size-1)
					geoRecommendationStringfinal.append(",");
				
			}		
			int counter=1;
			while(counter<=20-size){
				geoRecommendationStringfinal.append(",");
				counter++;
			}
		}
		if(cursor != null){
			cursor.close();
			}
		geoRecommendationString=geoRecommendationStringfinal;
	}else{
		int counter=1;
		while(counter<=30){
			geoRecommendationString.append(",");
			counter++;
		}
	}
	
	System.out.println("Inside geo recom>>>>>>>>>>..."+geoRecommendationString.toString());
	
	return geoRecommendationString.toString();

	}
	public String lookUpNonGeo(TransactionMREReq transactionMREReq,List<String> merchants,String collectionName1,String collectionName2,String collectionName3) {  
		DBCollection collection = mongoDB.getCollection(collectionName1);
		DBCollection merchantNormalizedCollection = mongoDB.getCollection(collectionName2);
		StringBuffer geoRecommendationString=new StringBuffer();
		String isoCode=transactionMREReq.getTransaction().getTransactionCard().getCountryCode();
		
		DBCollection collection1 = mongoDB.getCollection(collectionName3);
		String countryCode=null;
		DBObject query12=new BasicDBObject();
		query12.put("isocode",isoCode);
		BasicDBObject record12=(BasicDBObject)collection1.findOne(query12);
		if(record12!=null){
	       countryCode = getFieldFromCursor(record12, "Alpha2").toString();   
		}		
		//  String[] merchants = "WESTIN;W BANGKOK;VILLA MARKET".split(";");
		if(merchants.size()>0){
			BasicDBList or = new BasicDBList();
			for(String merchant : merchants){
				if(merchant.isEmpty() || merchant == null || merchant.equals("")){
					continue;
				}
				DBObject clause1 = new BasicDBObject("sequence", Pattern.compile(Pattern.quote(merchant), Pattern.CASE_INSENSITIVE));
				or.add(clause1);
			}

			DBObject query = new BasicDBObject();
			query.put("$or", or);
			query.put("country_code",countryCode);
			DBCursor cursor = collection.find(query).sort(new BasicDBObject("confidence",-1)).sort(new BasicDBObject("support",-1)).limit(2000);
			int count=0;
			List<BasicDBObject> matchedRecordList=new ArrayList<BasicDBObject>();
			while(cursor.hasNext()){
				BasicDBObject record = (BasicDBObject) cursor.next();
				String sequence=getFieldFromCursor(record, "sequence").toString();
				String[] sequenceArray=sequence.split(":");
				List<String> lookupList=new ArrayList<String>();
				for(String sequenceString:sequenceArray){
					if(merchants.contains(sequenceString)){
						lookupList.add(sequenceString);
					}
				}
				int lookupListSize=lookupList.size();
				int sequenceArraySize=sequenceArray.length;
				if(lookupListSize==sequenceArraySize){
					matchedRecordList.add(record);
					count++;
				}

			}


			String merchantName;
			String merchantId;
			Set<String> matchedRecordSet = new HashSet<String>();
			List<BasicDBObject> recommendationList=new ArrayList<BasicDBObject>();
			
			
			for(BasicDBObject obj: matchedRecordList){
				String merchant=getFieldFromCursor(obj, "merchant_nm").toString();
				if(matchedRecordSet.contains(merchant)){
					continue;
				}else{
					matchedRecordSet.add(merchant);
					recommendationList.add(obj);
				}
			}
			
			
			int size=recommendationList.size();
			if(size>30){
				for(int counter=0;counter<30;counter++){
					BasicDBObject matchedrecord = (BasicDBObject) recommendationList.get(counter);
					merchantName=getFieldFromCursor(matchedrecord, "merchant_nm").toString();
					DBObject merchantNameQuery=new BasicDBObject();
					merchantNameQuery.put("merchant_nm", merchantName);
					merchantNameQuery.put("country_code", countryCode);
					BasicDBObject record=(BasicDBObject)merchantNormalizedCollection.findOne(merchantNameQuery);
					if(record!=null){
						merchantId=getFieldFromCursor(record, "ref_id").toString();
						geoRecommendationString.append(merchantId);   
					}
					if(counter!=29){
						geoRecommendationString.append(",");
					}

				}
			}else if(size<=30){

				for(int counter=0;counter<size;counter++){
					BasicDBObject matchedrecord = (BasicDBObject) recommendationList.get(counter);
					merchantName=getFieldFromCursor(matchedrecord, "merchant_nm").toString();
					DBObject merchantNameQuery=new BasicDBObject();
					merchantNameQuery.put("merchant_nm", merchantName);
					merchantNameQuery.put("country_code", countryCode);
					BasicDBObject record=(BasicDBObject)merchantNormalizedCollection.findOne(merchantNameQuery);
					if(record!=null){
						merchantId=getFieldFromCursor(record, "ref_id").toString();
						geoRecommendationString.append(merchantId);   
					}
					if(counter!=size-1){
						geoRecommendationString.append(",");
					}
				}

				int counter=1;
				while(counter<=30-size){
					geoRecommendationString.append(",");
					counter++;
				}
			}
			String geoString = transactionMREReq.getNonGeoRecommendation();
			String geoRecString= geoRecommendationString.toString();	
		    String[] s2 = geoString.split(",");
		    String[] s1 = geoRecString.split(","); 
		    ArrayList<String> geoRecommendationStringNew = new ArrayList(Arrays.asList(s1));
		        for (String s : s2) {
		           if (geoRecommendationStringNew.contains(s)) {
		        	   geoRecommendationStringNew.remove(s);
		               } 
		              }  
		        size = geoRecommendationStringNew.size();   
	StringBuffer geoRecommendationStringfinal=new StringBuffer();
			
			if(size>20){
				for(int counter=0;counter<20;counter++){
					String str= geoRecommendationStringNew.get(counter);
						geoRecommendationStringfinal.append(str);   
					if(counter!=19)
						geoRecommendationStringfinal.append(",");			

				}
		}
			else if(size<=20){

				for(int counter=0;counter<size;counter++){
					String str= geoRecommendationStringNew.get(counter);
						geoRecommendationStringfinal.append(str);
					if(counter!=size-1)
						geoRecommendationStringfinal.append(",");
					
				}		
				int counter=1;
				while(counter<=20-size){
					geoRecommendationStringfinal.append(",");
					counter++;
				}
			}
			if(cursor != null){
				cursor.close();
				}
		geoRecommendationString=geoRecommendationStringfinal;
		}else{
			int counter=1;
			while(counter<=30){
				geoRecommendationString.append(",");
				counter++;
			}
		}
		
		System.out.println("Inside non geo recom>>>>>>>>>>..."+geoRecommendationString.toString());
		
		return geoRecommendationString.toString();

		}

	public Map<String, String> lookupScore(String customerNumber,String collectionName) {
		DBCollection collection = mongoDB.getCollection(collectionName);
		String score = new String();
		String template=new String();
		DBObject query=new BasicDBObject();
		Map<String, String> scoreMap=new HashMap<String, String>();
		query.put("customer_number", customerNumber);
		BasicDBObject record =(BasicDBObject)collection.findOne(query);

		if(record != null){
			score = getFieldFromCursor(record, "score").toString();
			template = getFieldFromCursor(record, "tempalte_id").toString();
			scoreMap.put("score", score);
			scoreMap.put("tempalte_id", template);
		}
		
		return scoreMap;
	}

	public void updateResponseFlag(String collectionName, String copTransactionID) {

		DBCollection collection = mongoDB.getCollection(collectionName);
		
		BasicDBObject newDocument = new BasicDBObject();
		newDocument.append("$set", new BasicDBObject().append("ResponseFlag", "Y"));
		BasicDBObject searchQuery = new BasicDBObject().append("copTransactionID", copTransactionID).append("ResponseFlag", "N");
		
		collection.update(searchQuery, newDocument);
		
	}
	protected void finalize() throws Throwable {
		try {
			if (mongoClient != null ) {
				mongoClient.close();
			}
		} catch (Throwable throwable) {
			sLogger.error("Inside MongoDbService->>>>>finalize->>>>>error>>starts");
			sLogger.error(throwable.getMessage());
			sLogger.error("Inside MongoDbService->>>>>finalize->>>>>error>>ends");
			throw throwable;
		}
	}

}