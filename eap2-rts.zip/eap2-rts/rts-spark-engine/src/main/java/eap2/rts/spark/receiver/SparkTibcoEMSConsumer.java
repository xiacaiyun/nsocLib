package eap2.rts.spark.receiver;

import java.io.File;
import java.text.SimpleDateFormat;
import java.util.GregorianCalendar;
import java.util.Map;
import java.util.Properties;

import javax.jms.Connection;
import javax.jms.ConnectionFactory;
import javax.jms.ExceptionListener;
import javax.jms.JMSException;
import javax.jms.Message;
import javax.jms.MessageConsumer;
import javax.jms.MessageListener;
import javax.jms.Queue;
import javax.jms.Session;
import javax.jms.TextMessage;
import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.FileSystem;
import org.apache.hadoop.fs.Path;
import org.apache.spark.streaming.receiver.Receiver;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import eap2.rts.common.event.dto.SimpleRequestObject;
import eap2.rts.spark.AppConstants;
import scala.Tuple2;

public class SparkTibcoEMSConsumer implements Runnable {

	protected static final Logger logger = LoggerFactory.getLogger(SparkTibcoEMSConsumer.class);
	private Map<String, String> _eventConfig;
	private Receiver<Tuple2<String,SimpleRequestObject>> _reciever;
	private Properties env = new Properties();
	private Connection _jmsConnection;
	private MessageConsumer _jmsMessageConsumer;
	private Session _jmsSession;
	private String _tibcoPassword = new String();
	private Queue _jmsQueue;
	
	
	private String formatDate(long timeinMilliSec, String dateFormat) {
		SimpleDateFormat df = new SimpleDateFormat(dateFormat);
		GregorianCalendar cal = new GregorianCalendar();
		cal.setTimeInMillis(timeinMilliSec);
		String date = df.format(cal.getTime());

		return date;
	}
	
	public static String copyP12File(String hdfs_path, String _propertiesFilename) throws Exception {
		Configuration conf = new Configuration();
		FileSystem hdfsFileSystem = FileSystem.get(conf);

		String result = null;

		Path hdfs = new Path(hdfs_path);
		
		if(_propertiesFilename.equals(AppConstants.UAT_PROP)){
			
			String splitString[] = hdfs_path.split("/");
			String fid = splitString[4];
			
			Path local = new Path("/tmp/" + fid + "_p12Cert");
			File file = new File("/tmp/" + fid + "_p12Cert/UAT_EAP_USR.ca1.p12");

			
			if (hdfsFileSystem.exists(hdfs)) {
				if (file.exists()) {
					result = "/tmp/" + fid + "_p12Cert/UAT_EAP_USR.ca1.p12";
				} else {
					new File("/tmp/" + fid + "_p12Cert").mkdir();
					hdfsFileSystem.copyToLocalFile(false, hdfs, local, true);
					result = "/tmp/" + fid + "_p12Cert/UAT_EAP_USR.ca1.p12";
				}
			} else {
				logger.info("Inside copyP12File->>>>> file does not exists in hdfs");
				result = null;
			}
		}else if(_propertiesFilename.equals(AppConstants.PROD_PROP)){
			
			String splitString[] = hdfs_path.split("/");
			String fid = splitString[4];
			
			Path local = new Path("/tmp/" + fid + "_p12Cert");
			File file = new File("/tmp/" + fid + "_p12Cert/PROD_EAP_USR.ca1.p12");

			
			if (hdfsFileSystem.exists(hdfs)) {
				if (file.exists()) {
					result = "/tmp/" + fid + "_p12Cert/PROD_EAP_USR.ca1.p12";
				} else {
					new File("/tmp/" + fid + "_p12Cert").mkdir();
					hdfsFileSystem.copyToLocalFile(false, hdfs, local, true);
					result = "/tmp/" + fid + "_p12Cert/PROD_EAP_USR.ca1.p12";
				}
			} else {
				logger.info("Inside copyP12File->>>>> file does not exists in hdfs");
				result = null;
			}
		}else{
			
			String splitString[] = hdfs_path.split("/");
			String fid = splitString[4];
			
			Path local = new Path("/tmp/" + fid + "_p12Cert");
			File file = new File("/tmp/" + fid + "_p12Cert/DIT_EAP_USR.ca1.p12");

			
			if (hdfsFileSystem.exists(hdfs)) {
				if (file.exists()) {
				
					result = "/tmp/" + fid + "_p12Cert/DIT_EAP_USR.ca1.p12";
				} else {
				
					new File("/tmp/" + fid + "_p12Cert").mkdir();
					hdfsFileSystem.copyToLocalFile(false, hdfs, local, true);
					result = "/tmp/" + fid + "_p12Cert/DIT_EAP_USR.ca1.p12";
				}
			} else {
				logger.info("Inside copyP12File->>>>> file does not exists in hdfs");
				result = null;
			}
		}
		

		return result;

	}
	
	

	public SparkTibcoEMSConsumer(Map<String, String> appConfig, Receiver<Tuple2<String,SimpleRequestObject>> reciever, String tibcoPassword, String _propertiesFilename) throws Exception {
		
		this._eventConfig = appConfig;
		this._reciever = reciever;
		this._tibcoPassword = tibcoPassword;
		
		env.put(Context.INITIAL_CONTEXT_FACTORY, _eventConfig.get(AppConstants.CONN_FACTORY));
		env.put(Context.PROVIDER_URL, _eventConfig.get(AppConstants.PROVIDER_URL));	
		env.put(Context.SECURITY_PRINCIPAL, _eventConfig.get(AppConstants.QUEUE_USERNAME));
		env.put(Context.SECURITY_CREDENTIALS, _tibcoPassword);
		env.put(AppConstants.SEC_PROTOCOL, _eventConfig.get(AppConstants.SEC_PROTOCOL));
		env.put(AppConstants.ENABLE_VERIFY_HOST, _eventConfig.get(AppConstants.ENABLE_VERIFY_HOST));
		env.put(AppConstants.SSL_VENDOR, _eventConfig.get(AppConstants.SSL_VENDOR));
		env.put(AppConstants.SSL_PROVIDER, _eventConfig.get(AppConstants.SSL_PROVIDER));
		env.put(AppConstants.SSL_AUTH_ONLY, _eventConfig.get(AppConstants.SSL_AUTH_ONLY));
		env.put(AppConstants.TIBCO_SEC_VENDOR, _eventConfig.get(AppConstants.TIBCO_SEC_VENDOR));
		env.put(AppConstants.TIBCO_SEC_TRACE, _eventConfig.get(AppConstants.TIBCO_SEC_TRACE));
		env.put(AppConstants.SSL_IDENTITY,copyP12File(_eventConfig.get(AppConstants.SSL_IDENTITY),_propertiesFilename));		
				
	}

	public void run() {
	
		try {
			Context ctx = new InitialContext(env);
			ConnectionFactory factory = (ConnectionFactory) ctx.lookup(_eventConfig.get(AppConstants.QUEUE_CF));
			_jmsConnection = factory.createConnection(_eventConfig.get(AppConstants.QUEUE_USERNAME), _tibcoPassword);
			_jmsConnection.start();
			_jmsSession = _jmsConnection.createSession(false, Session.CLIENT_ACKNOWLEDGE);
			_jmsQueue = _jmsSession.createQueue(_eventConfig.get(AppConstants.QUEUE_NAME));
			_jmsMessageConsumer = _jmsSession.createConsumer(_jmsQueue);
			_jmsConnection.setExceptionListener(new JMSConExceptionListener());
			_jmsMessageConsumer.setMessageListener(new TibcoMessageListener());
		} catch (JMSException e) {
			logger.error("SparkTibcoEMSConsumer->>>>>run->>>>>Debug->>>>>starts->>>>>");
			logger.error("An error has occured", e);
			logger.error("SparkTibcoEMSConsumer->>>>>run->>>>>Debug->>>>>ends->>>>>");
			throw new RuntimeException(e);
		} catch (NamingException e) {
			logger.error("SparkTibcoEMSConsumer->>>>>run->>>>>Debug->>>>>starts->>>>>");
			logger.error("An error has occured", e);
			logger.error("SparkTibcoEMSConsumer->>>>>run->>>>>Debug->>>>>ends->>>>>");
			throw new RuntimeException(e);
		}
		
		while (!_reciever.isStopped()) {
			try {
				Thread.sleep(300);
			} catch (InterruptedException e) {
				logger.error("SparkTibcoEMSConsumer->>>>>run->>>>>Debug->>>>>starts->>>>>");
				logger.error("An error has occured", e);
				logger.error("SparkTibcoEMSConsumer->>>>>run->>>>>Debug->>>>>ends->>>>>");
			}
		}
	}

	public void stop() {
		logger.info("SparkTibcoEMSReceiver->>>>>onStop->>>>>Debug->>>>>starts->>>>>");
		logger.info("Stoping EMS Receiver");
		logger.info("SparkTibcoEMSReceiver->>>>>onStop->>>>>Debug->>>>>ends->>>>>");
		try {
			_jmsQueue = null;
			if (_jmsMessageConsumer != null) {
				_jmsMessageConsumer.close();
				_jmsMessageConsumer = null;
			}

			if (_jmsSession != null) {
				_jmsSession.close();
				_jmsSession = null;
			}

			if (_jmsConnection != null) {
				_jmsConnection.close();
				_jmsConnection = null;
			}
		} catch (JMSException e) {
			logger.error("SparkTibcoEMSConsumer->>>>>finalize->>>>>Debug->>>>>starts->>>>>");
			logger.error("An error has occured", e);
			logger.error("SparkTibcoEMSConsumer->>>>>finalize->>>>>Debug->>>>>ends->>>>>");
		}
	}

	/**
	 * @author bs34500
	 */
	private final class TibcoMessageListener implements MessageListener {
		public void onMessage(Message msg) {
			try {
				TextMessage tm = (TextMessage) msg;
				Tuple2<String,SimpleRequestObject> message;
				SimpleRequestObject request = new SimpleRequestObject();
				String requestQueueName="citi.gcg.apac.eventcloud.consumer.eap";
				request.setMessageid(tm.getJMSMessageID());
				request.setRequestQueueName(requestQueueName);
				request.setTimeStamp(tm.getJMSTimestamp());
				request.setMsgBody(tm.getText());
				request.setRequestDatetime(formatDate(System.currentTimeMillis(),AppConstants.TIMESTAMP_DATE_FORMAT));
				String eventType=tm.getStringProperty("EventID");
				if(eventType==null){
					message = new Tuple2<String,SimpleRequestObject>(_eventConfig.get(AppConstants.DEFAULT_EVENT), request);
				}else{
					message = new Tuple2<String,SimpleRequestObject>(eventType, request);
				}
				_reciever.store(message);
				msg.acknowledge();
			} catch (JMSException ex) {
				logger.error("SparkTibcoEMSConsumer->>>>>run->>>>>Debug->>>>>starts->>>>>");
				logger.error("An error has occured", ex);
				logger.error("SparkTibcoEMSConsumer->>>>>run->>>>>Debug->>>>>ends->>>>>");
				_reciever.restart("Problem initializing connection", ex);
			}
		}
	}

	/**
	 * @author bs34500
	 */
	final private class JMSConExceptionListener implements ExceptionListener {
		public void onException(JMSException exp) {
			logger.info("EMS Reciver Exception Listner Begining.");
			logger.error("Connection ExceptionListener fired, attempting restart.", exp);
			_reciever.restart("Connection ExceptionListener fired, attempting restart.");
		}
	}


}
