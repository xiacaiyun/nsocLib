package eap2.rts.pwp;

import java.security.SecureRandom;

import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.PBEKeySpec;
import javax.crypto.spec.SecretKeySpec;
import javax.xml.bind.DatatypeConverter;

public class PWPUtilMain {
	private static byte[] iv = { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 };
	private static IvParameterSpec ivspec = new IvParameterSpec(iv);
	private static char[] rtsSecret = "rtsS3cr3t2017".toCharArray();

	public static void main(String[] args) throws Exception {
		String opType = null;
		PWPUtilMain pwp = new PWPUtilMain();

		if (args.length > 0) {
			opType = args[0];
		} else {
			pwp.stop();
		}

		if (PWPConstants.OP_TYPE_SALT.equals(opType)) {
			System.out.println("Salt:\n" + pwp.getSalt());
		} else if (PWPConstants.OP_TYPE_ENCRYPT.equals(opType)) {
			if (args.length == 3) {
				String salt = args[1];
				String password = args[2];
				System.out.println("Encrypted Password:\n" + pwp.encrypt(salt, password));
			} else {
				pwp.stop();
			}
		} else if (PWPConstants.OP_TYPE_DECRYPT.equals(opType)) {
			if (args.length == 3) {
				String salt = args[1];
				String password = args[2];
				System.out.println("Decrypted Password:\n" + pwp.decrypt(salt, password));
			} else {
				pwp.stop();
			}
		} else {
			pwp.stop();
		}
	}

	public void stop() {
		System.out.println("Invalid Inputs.");
		System.out.println("Usage: PWPUtilMain <OpType> <Salt> <Password>");
		System.exit(-1);
	}

	public String encrypt(String salt, String password) throws Exception {
		byte[] saltByte = DatatypeConverter.parseBase64Binary(salt);
		byte[] data = password.getBytes();
		String encryptedByte = m1_(data, rtsSecret, saltByte, 1);
		String encryptedPassword = new String(encryptedByte);
		return encryptedPassword;
	}

	public String decrypt(String salt, String password) throws Exception {
		byte[] encryptedPsw = DatatypeConverter.parseBase64Binary(password);
		byte[] saltByte = DatatypeConverter.parseBase64Binary(salt);
		String decryptedPassword = m2_(encryptedPsw, rtsSecret, saltByte);
		return decryptedPassword;
	}

	public String getSalt() throws Exception {
		SecureRandom sr = new SecureRandom();
		byte[] salt = new byte[20];
		sr.nextBytes(salt);
		return DatatypeConverter.printBase64Binary(salt);
	}

	public String m1_(byte[] data, char[] password, byte[] saltBytes, int noIterations) throws Exception {
		String method = "PBKDF2WithHmacSHA1";
		SecretKeyFactory skf = SecretKeyFactory.getInstance(method);
		PBEKeySpec spec = new PBEKeySpec(password, saltBytes, noIterations, 128);
		SecretKey secretKey = skf.generateSecret(spec);
		SecretKeySpec secretSpec = new SecretKeySpec(secretKey.getEncoded(), "AES");
		Cipher cipher = Cipher.getInstance("AES/CBC/PKCS5Padding");
		cipher.init(Cipher.ENCRYPT_MODE, secretSpec, ivspec);
		byte[] encryptedTextBytes = cipher.doFinal(data);
		return DatatypeConverter.printBase64Binary(encryptedTextBytes);
	}

	public String m2_(byte[] encryptedTextBytes, char[] password, byte[] saltBytes) throws Exception {
		String method = "PBKDF2WithHmacSHA1";
		SecretKeyFactory skf = SecretKeyFactory.getInstance(method);
		PBEKeySpec spec = new PBEKeySpec(password, saltBytes, 1, 128);
		SecretKey secretKey = skf.generateSecret(spec);
		SecretKeySpec secretSpec = new SecretKeySpec(secretKey.getEncoded(), "AES");
		Cipher cipher = Cipher.getInstance("AES/CBC/PKCS5Padding");
		cipher.init(Cipher.DECRYPT_MODE, secretSpec, ivspec);
		byte[] decryptedTextBytes = null;
		decryptedTextBytes = cipher.doFinal(encryptedTextBytes);
		return new String(decryptedTextBytes);
	}
}
