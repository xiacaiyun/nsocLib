package eap2.rts.pwp;

public interface PWPConstants {
	public String OP_TYPE_SALT = "salt";
	public String OP_TYPE_ENCRYPT = "encrypt";
	public String OP_TYPE_DECRYPT = "decrypt";
}
