package cn.nsoc.common.applib.entity;

import org.springframework.util.StringUtils;

/**
 * Created by bobwang on 11/7/16.
 */

// use httpMethod
@Deprecated
public enum HttpVerb {
    GET,

    POST,

    HEAD,

    DELETE,

    OPTIONS,

    PATCH,

    PUT;


    public static HttpVerb convert(String text, HttpVerb defVal) {
        if (!StringUtils.hasText(text)) {
            return defVal;
        }
        String verbText = text.trim();
        if (verbText.compareToIgnoreCase(GET.name()) == 0) {
            return GET;
        }
        if (verbText.compareToIgnoreCase(POST.name()) == 0) {
            return POST;
        }
        if (verbText.compareToIgnoreCase(HEAD.name()) == 0) {
            return HEAD;
        }
        if (verbText.compareToIgnoreCase(DELETE.name()) == 0) {
            return DELETE;
        }
        if (verbText.compareToIgnoreCase(OPTIONS.name()) == 0) {
            return OPTIONS;
        }
        if (verbText.compareToIgnoreCase(PATCH.name()) == 0) {
            return PATCH;
        }
        if (verbText.compareToIgnoreCase(PUT.name()) == 0) {
            return PUT;
        }
        return GET;
    }

}
