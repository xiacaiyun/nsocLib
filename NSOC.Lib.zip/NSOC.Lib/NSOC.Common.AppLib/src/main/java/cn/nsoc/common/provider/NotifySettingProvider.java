package cn.nsoc.common.provider;

import cn.nsoc.base.entity.sys.NSException;
import cn.nsoc.common.applib.controls.AppDataExProvider;
import cn.nsoc.common.applib.entity.NSOCConsts;
import cn.nsoc.common.applib.entity.notifysetting.Notifysetting;
import cn.nsoc.common.applib.entity.notifysetting.NotifysettingCollection;
import cn.nsoc.common.storer.biz.PageContext;
import cn.nsoc.common.util.Misc;
import cn.nsoc.common.util.NApiProxy;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by Administrator on 2017/2/27.
 */
public class NotifySettingProvider {
    public static final String url_list = "/napi/internal/mail/notifysettinglist?pageId=%s&countPerPage=%s";
    private NApiProxy nApiProxy;

    public NotifySettingProvider() {
        nApiProxy = NApiProxy.getInstance();
    }


    public static class NotifySettingModel {
        public int SettingID;
        public String Mobiles;
        public String CreateDate;
        public String Name;
        public int IsSendSMS;
        public int CreateBy;
        public int EmailToAssignUser;
        public String Emails;
        public int IsSendEmail;
        public int IsBuzz;
        public int SMSToAssignUser;
    }


    @SuppressWarnings("unchecked")
    public NotifysettingCollection listNotifySetting(Integer pageId, Integer countperpage) throws NSException {
        List<Notifysetting> objlist = new ArrayList<>();
        PageContext pCtx;
        String url = String.format(url_list,
                pageId == null ? "" : pageId,
                countperpage == null ? "" : countperpage);
        String html = AppDataExProvider.get(url, NSOCConsts.AlertShortName);
        Object[] result = nApiProxy.parserPagerData(html, PageContext.class, NotifySettingModel[].class);
        NotifysettingCollection coll = new NotifysettingCollection();
        if(result[0] == null){
            return coll;
        }
        List<NotifySettingModel> listm = (List<NotifySettingModel>) result[0];
        pCtx = (PageContext) result[1];
        for (NotifySettingModel wm : listm) {
            Notifysetting ns = new Notifysetting();
            Misc.objectCopy(wm, ns);
            ns.setCreateDate(Misc.parseISODateTime(wm.CreateDate));
            objlist.add(ns);
        }
        coll.addAll(objlist);
        if (pCtx != null) {
            coll.getQuery().totalCount = pCtx.getTotalCount();
        }
        return coll;
    }

    @SuppressWarnings("unchecked")
    public Notifysetting fetchNotifySetting(Integer id) throws NSException {
        if(id == null || id <= 0){
            return null;
        }
        NotifysettingCollection notifysettings = listNotifySetting(0, Integer.MAX_VALUE);
        return notifysettings.Find(id);
    }
}
