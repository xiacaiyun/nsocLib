package cn.nsoc.common.applib.controls;

/**
 * Created by sam on 16-6-21.
 */
public class JsonRet {
    private boolean ret;
    private String msg;
    private Object data;
    private Object qs;
    private Object pager;
    private int code;

    public static final int RET_SUCCEED_CODE = 0;
    public static final int RET_FAILED_CODE = 0x8FF0FFFF;

    public JsonRet(Object data) {
        this(true, null, data, null, RET_SUCCEED_CODE);
    }

    public JsonRet(int code, final Object data) {
        this(code == RET_SUCCEED_CODE, null, data, null, code);
    }

    public JsonRet(int code, final String msg) {
        this(code == RET_SUCCEED_CODE, msg, null, null, code);
    }

    public JsonRet(int code, final Object data, final Object pager) {
        this(code == RET_SUCCEED_CODE, null, data, pager, code);
    }

    public JsonRet(Object data, Object pager) {
        this(true, null, data, pager, RET_SUCCEED_CODE);
    }

    public JsonRet(boolean ret, String msg) {
        this(ret, msg, null, null, ret ? RET_SUCCEED_CODE : RET_FAILED_CODE);
    }

    public JsonRet(boolean ret, String msg, Object data) {
        this(ret, msg, data, null, ret ? RET_SUCCEED_CODE : RET_FAILED_CODE);
    }

    public JsonRet(boolean ret, String msg, Object data, Object pager, int code) {
        this.ret = ret;
        this.data = data;
        this.msg = msg;
        this.pager = pager;
        this.code = code;
    }

    public int getCode() {
        return code;
    }

    public void setCode(int newVal) {
        code = newVal;
    }

    public boolean isRet() {
        return ret;
    }

    public void setRet(boolean ret) {
        this.ret = ret;
    }

    public String getMsg() {
        return msg;
    }

    public void setMsg(String msg) {
        this.msg = msg;
    }

    public Object getData() {
        return data;
    }

    public void setData(Object data) {
        this.data = data;
    }

    public Object getQs() {
        return qs;
    }

    public void setQs(Object qs) {
        this.qs = qs;
    }

    public Object getPager() {
        return pager;
    }

    public void setPager(Object pager) {

        this.pager = pager;
    }
}
