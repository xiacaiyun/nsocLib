package cn.nsoc.common.applib.rights;

/**
 * Created by sam on 16-10-9.
 */
public enum RightsValEnum {
    CenterControl(0x00000001, "中心设置"),
    UserManage(0x00000004, "用户管理"),


    AppSetting(0x00010000, "应用管理"),
    SystemSetting(0x00020000, "系统管理"),
    ViewData(0x00040000, "查看数据"),


    NoRights(0x00000000, "没有权限"),
    AllRights(0xffffffff, "所有权限");

    private final int val;
    private final String text;

    RightsValEnum(int val, String text) {
        this.val = val;
        this.text = text;
    }

    public int getVal() {
        return val;
    }

    public String getText() {
        return text;
    }

    public static int combine(RightsValEnum[] rights) {
        int v = 0;
        if (rights != null) {
            for (RightsValEnum right : rights) {
                v |= right.getVal();
            }
        }
        return v;
    }


}
