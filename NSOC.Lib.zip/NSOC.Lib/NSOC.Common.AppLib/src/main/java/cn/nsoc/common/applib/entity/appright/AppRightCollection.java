package cn.nsoc.common.applib.entity.appright;

import cn.nsoc.common.storer.EntityCollection;

public class AppRightCollection extends EntityCollection<AppRight, AppRightQuery> {
    public AppRightCollection() {
        super(AppRight.class, AppRightQuery.class);
    }

    public AppRightCollection(AppRightQuery query) {
        this();
        this.setQuery(query);
    }
}

