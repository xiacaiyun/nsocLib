package cn.nsoc.common.applib.membership;

import cn.nsoc.base.entity.sys.NSException;
import cn.nsoc.common.applib.controls.JsonRet;
import cn.nsoc.common.applib.entity.user.NUserInfo;
import cn.nsoc.common.applib.rights.RightsContext;
import cn.nsoc.common.util.Misc;
import cn.nsoc.common.util.NApiProxy;
import org.springframework.util.Assert;

import java.util.Map;

/**
 * Created by sam on 16-6-6.
 */
@SuppressWarnings("unchecked")
public class UserInfoProvider {


    static final String URL_GetUser = "/napi/internal/user/get/%d";
    static final String URL_GetUserRights = "/napi/internal/user/getrights?id=%d";
    static final String URL_GetUserThirdRights = "/napi/internal/user/getthirdrights?id=%d";

    private NApiProxy nApiProxy;

    public UserInfoProvider(NApiProxy nApiProxy) {
        Assert.notNull(nApiProxy);

        this.nApiProxy = nApiProxy;
    }

    public NUserInfo getUser(int userId) throws NSException {
        String url = String.format(URL_GetUser, userId);
        String html = this.nApiProxy.get(url);
        JsonRet r = Misc.fromJson(html, JsonRet.class);
        if ((r != null) && r.isRet() && r.getData() != null) {
            return Misc.fromJson(Misc.toJson(r.getData()), NUserInfo.class);
        }
        return null;
    }


    public RightsContext getRights(int userId) throws NSException {
        String url = String.format(URL_GetUserRights, userId);
        String html = this.nApiProxy.get(url);
        RightsContext result = new RightsContext();

        JsonRet ret = Misc.fromJson(html, JsonRet.class);
        if (ret == null || !ret.isRet()) {
            throw new NSException("返回结果错误");
        }

        Map<String, Object> vals = (Map<String, Object>) ret.getData();

        if (vals.containsKey("userRights")) {
            result.userRights = Misc.getObjectFromMapItem((Map<String, Object>) vals.get("userRights"), RightsContext.RightsItem.class);
        }
        if (vals.containsKey("rolesRights")) {
            result.rolesRights = Misc.getObjectFromMapItem((Map<String, Object>) vals.get("rolesRights"), RightsContext.RightsItem.class);
        }

        return result;
    }

    public Object getThirdRights(int userId) throws NSException {
        String url = String.format(URL_GetUserThirdRights, userId);
        String html = this.nApiProxy.get(url);
        JsonRet r = Misc.fromJson(html, JsonRet.class);
        if ((r != null) && r.isRet()) {
            return r.getData();
        }
        return null;
    }
}