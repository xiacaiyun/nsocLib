package cn.nsoc.common.applib.filter;

import cn.nsoc.base.entity.sys.NSException;
import cn.nsoc.common.applib.controls.JsonRet;
import cn.nsoc.common.applib.error.ErrorType;
import cn.nsoc.common.applib.rights.Right;
import cn.nsoc.common.applib.rights.RightSetMask;
import cn.nsoc.common.applib.rights.RightsContext;
import cn.nsoc.common.applib.rights.RightsValEnum;
import cn.nsoc.common.auth.NsocUser;
import cn.nsoc.common.provider.UserRightsProvider;
import cn.nsoc.common.util.Misc;
import cn.nsoc.common.util.RSACryptoServiceProvider;
import org.springframework.util.StringUtils;
import org.springframework.web.method.HandlerMethod;
import org.springframework.web.servlet.handler.HandlerInterceptorAdapter;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;
import java.time.LocalDateTime;
import java.util.EnumSet;
import java.util.UUID;

/**
 * Created by sam on 16-10-8.
 */
public abstract class BaseRightCheckInterceptor extends HandlerInterceptorAdapter {

    static final String MIME_JSON = "application/json";
    static final String MIME_HTML = "text/html";


    protected class RightFlag {
        private Integer allowRight;

        private boolean enableAppEx = false;

        private boolean allowAnonymous = false;

        private boolean allowAllLoginedUser = false;

        public int getRight() {
            return (getAllowRight() == null) ? -1 : getAllowRight();
        }

        public void setAllowRight(int allowRight) {
            this.allowRight = allowRight;
        }

        public Integer getAllowRight() {
            return allowRight;
        }

        public void setAllowRight(Integer allowRight) {
            this.allowRight = allowRight;
        }

        public boolean isEnableAppEx() {
            return enableAppEx;
        }

        public void setEnableAppEx(boolean enableAppEx) {
            this.enableAppEx = enableAppEx;
        }

        public boolean isAllowAnonymous() {
            return allowAnonymous;
        }

        public void setAllowAnonymous(boolean allowAnonymous) {
            this.allowAnonymous = allowAnonymous;
        }

        public boolean isAllowAllLoginedUser() {
            return allowAllLoginedUser;
        }

        public void setAllowAllLoginedUser(boolean allowAllLoginedUser) {
            this.allowAllLoginedUser = allowAllLoginedUser;
        }
    }

    @Override
    public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler) throws NSException {

        if (handler.getClass().isAssignableFrom(HandlerMethod.class)) {
            HandlerMethod h = (HandlerMethod) handler;

            RightFlag flag = new RightFlag();
            mergeRight(flag, h.getBeanType().getAnnotation(Right.class));
            mergeRight(flag, h.getMethodAnnotation(Right.class));

            if (flag.isAllowAnonymous())
                return true;

            try {
                NsocUser user = NsocUser.getCurrentUser();
                if (user == null) {
                    if (flag.isEnableAppEx() && checkAppEx(request)) {
                        return true;
                    } else {
                        onForbidden(request, response);
                        return false;
                    }
                } else {

                    if ((flag.getRight() == -1) || flag.isAllowAllLoginedUser())
                        return true;

                    if (checkUserRight(flag, user)) {
                        return true;
                    } else {
                        onForbidden(request, response);
                        return false;
                    }
                }
            } catch (Exception ex) {
                throw new NSException(ex);
            }
        }
        return true;

    }


    protected abstract String getAppRSAKey(UUID appId) throws NSException;

    protected boolean checkAppEx(HttpServletRequest request) throws NSException {

        UUID appId = Misc.uuidFromString(request.getHeader("APPID"));
        String verifyKey = request.getHeader("APPVRY");

        request.setAttribute("APPID", appId);

        if ((appId == null) || !StringUtils.hasText(verifyKey))
            return false;

        String rsakey = getAppRSAKey(appId);
        if (!StringUtils.hasText(rsakey))
            return false;

        RSACryptoServiceProvider rsa = new RSACryptoServiceProvider();
        rsa.fromXmlString(rsakey);

        String vk = rsa.decyrpt(verifyKey);
        LocalDateTime dt = Misc.parseISODateTime(vk);
        if (dt == null)
            return false;

//      暂时不校验时间戳
//        LocalDateTime now = ZonedDateTime.now(ZoneOffset.UTC).toLocalDateTime()
//        if (Math.abs(Duration.between(dt, now).getSeconds()) < 86400)
//            return true
//        else
//            return false
        return true;
    }

    protected boolean checkUserRight(RightFlag flag, NsocUser user) throws NSException {
        return this.checkAppUserRight(flag, user);
    }


    protected boolean checkAppUserRight(RightFlag flag, NsocUser user) throws NSException {
        if (user == null) {
            return false;
        }

        RightsContext rightCtx = new UserRightsProvider().getUserRights(user.getUserId());
        return rightCtx != null && rightCtx.checkRight(flag.getRight());

    }


    protected void onForbidden(HttpServletRequest request, HttpServletResponse response) throws IOException {

        String accept = request.getHeader("Accept");
        if (StringUtils.hasText(accept) && (accept.contains(MIME_JSON))) {
            response.setContentType(MIME_JSON);
            response.setCharacterEncoding("utf-8");

            PrintWriter out = response.getWriter();
            out.write(Misc.toJson(new JsonRet(false, ErrorType.accessDeny.getText())));
            out.close();

        } else {
            response.sendRedirect(request.getContextPath() + "/error?type=" + ErrorType.accessDeny.name());
        }
    }


    protected RightFlag mergeRight(RightFlag flag, Right annotation) {
        if (annotation == null) {
            return flag;
        }

        RightSetMask[] masks = annotation.mask();
        if (masks.length == 0)
            masks = EnumSet.allOf(RightSetMask.class).toArray(new RightSetMask[]{});


        for (RightSetMask m : masks) {
            switch (m) {
                case AllowRight: {
                    int v = RightsValEnum.combine(annotation.allowRight());
                    if (v != 0) {
                        flag.setAllowRight(v);
                    }
                }
                break;
                case AllowAnonymous:
                    flag.setAllowAnonymous(annotation.allowAnonymous());
                    break;
                case EnableAppEx:
                    flag.setEnableAppEx(annotation.enableAppEx());
                    break;
                case AllowAllLoginedUser:
                    flag.setAllowAllLoginedUser(annotation.allowAllLoginedUser());
                    break;
            }
        }
        return flag;
    }
}
