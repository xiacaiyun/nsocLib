package cn.nsoc.common.applib.controls;

import cn.nsoc.common.storer.EntityCollection;

/**
 * Created by sam on 16-6-7.
 */
//move to lib storer
@Deprecated
public class PageContext {
    private int curPage = 1;
    private int countPerPage = 20;
    private long totalCount;
    private int totalPage;

    public void setTotalPage(int totalPage) {
        this.totalPage = totalPage;
    }

    public int getCountCurPage() {
        return countCurPage;
    }

    public void setCountCurPage(int countCurPage) {
        this.countCurPage = countCurPage;
    }

    private int countCurPage;

    public PageContext(IPager m) {
        this((m == null) ? null : m.getPageId(),
                (m == null) ? null : m.getCountPerPage());
    }

    public PageContext(Integer pageId, Integer countperpage) {
        if (pageId != null) {
            setCurPage(pageId);
        }
        if (countperpage != null) {
            setCountPerPage(countperpage);
        }
    }

    public int getCurPage() {
        return curPage;
    }

    public void setCurPage(int value) {
        if (value > 0)
            curPage = value;
    }

    public int getTotalPage() {
        return totalPage;
    }

    private void setTotalPage() {
        if (countPerPage > 0)
            totalPage = ((int) getTotalCount() + countPerPage - 1) / countPerPage;
    }

    public int getStart() {
        return (curPage - 1) * countPerPage;
    }

    public boolean CheckExceed() {
        if (curPage > totalPage) {
            curPage = totalPage;
            return true;
        } else
            return false;
    }

    public int getCountPerPage() {
        return countPerPage;
    }

    public void setCountPerPage(int value) {
        if (value > 0) {
            countPerPage = value;
            setTotalPage();
        }
    }

    public long getTotalCount() {
        return totalCount;
    }

    public void setTotalCount(long totalCount) {
        this.totalCount = totalCount;
        setTotalPage();
    }

    public void setCollection(EntityCollection coll) {
        setCountCurPage(coll.size());
        setTotalCount(coll.getQuery().totalCount);
    }
}