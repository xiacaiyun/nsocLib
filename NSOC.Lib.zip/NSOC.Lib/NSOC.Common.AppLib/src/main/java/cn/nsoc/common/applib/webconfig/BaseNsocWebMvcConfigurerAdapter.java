package cn.nsoc.common.applib.webconfig;

import cn.nsoc.common.applib.filter.RequestAPMInterceptor;
import org.apache.log4j.Logger;
import org.springframework.context.annotation.Bean;
import org.springframework.context.support.PropertySourcesPlaceholderConfigurer;
import org.springframework.http.HttpHeaders;
import org.springframework.util.StringUtils;
import org.springframework.web.multipart.commons.CommonsMultipartResolver;
import org.springframework.web.servlet.ViewResolver;
import org.springframework.web.servlet.config.annotation.CorsRegistry;
import org.springframework.web.servlet.config.annotation.InterceptorRegistry;
import org.springframework.web.servlet.config.annotation.ResourceHandlerRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurerAdapter;
import org.springframework.web.servlet.view.InternalResourceViewResolver;
import org.springframework.web.servlet.view.JstlView;

/**
 * Created by sam on 16-9-22.
 */
public abstract class BaseNsocWebMvcConfigurerAdapter extends WebMvcConfigurerAdapter {

    private static final Logger logger = Logger.getLogger(BaseNsocWebMvcConfigurerAdapter.class);

    protected BaseAppConfig getAppConfig() {
        return null;
    }

    @Bean
    public CommonsMultipartResolver multipartResolver() {
        return new CommonsMultipartResolver();
    }

    @Bean
    public static PropertySourcesPlaceholderConfigurer propertyConfigInDev() {
        // why static ,see http://docs.spring.io/autorepo/docs/spring/4.1.3.RELEASE/javadoc-api/org/springframework/context/annotation/Bean.html
        return new PropertySourcesPlaceholderConfigurer();
    }


    @Bean
    public ViewResolver viewResolver() {
        InternalResourceViewResolver rv = new InternalResourceViewResolver();
        rv.setViewClass(JstlView.class);
        rv.setPrefix("/WEB-INF/view/");
        rv.setSuffix(".jsp");
        return rv;
    }

    @Override
    public void addCorsMappings(CorsRegistry registry) {

        BaseAppConfig appConfig = getAppConfig();
        String allowOrigins = "*";

        if (appConfig != null) {
            if (appConfig.security_disableCors) {
                return;
            }

            if (StringUtils.hasText(appConfig.security_corsAllowOrigins)) {
                allowOrigins = appConfig.security_corsAllowOrigins.trim();
            }
        }

        registry.addMapping("/**")
                .allowedOrigins(allowOrigins)
                .allowedMethods("GET", "POST", "PUT", "OPTIONS")
                .allowedHeaders("*")
                .exposedHeaders(HttpHeaders.SET_COOKIE)
                .allowCredentials(true)
                .maxAge(3600);
    }

    @Override
    public void addResourceHandlers(ResourceHandlerRegistry registry) {
        registry.addResourceHandler("/static/**").addResourceLocations("/static/");
    }

    @Override
    public void addInterceptors(InterceptorRegistry registry) {
        super.addInterceptors(registry);

        if (logger.isInfoEnabled()){
            registry.addInterceptor(new RequestAPMInterceptor());
        }
    }
}
