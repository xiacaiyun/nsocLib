package cn.nsoc.common.auth;

import org.springframework.security.authentication.RememberMeAuthenticationToken;
import org.springframework.security.core.GrantedAuthority;

import java.util.Collection;

/**
 * Created by sam on 16-10-8.
 */
public class NsocRememberMeAuthenticationToken extends RememberMeAuthenticationToken {

    private NsocUser user;

    public NsocRememberMeAuthenticationToken(String key, Object principal, Collection<? extends GrantedAuthority> authorities) {
        super(key, principal, authorities);
    }

    public NsocUser getUser() {
        return user;
    }

    public void setUser(NsocUser user) {
        this.user = user;
    }
}
