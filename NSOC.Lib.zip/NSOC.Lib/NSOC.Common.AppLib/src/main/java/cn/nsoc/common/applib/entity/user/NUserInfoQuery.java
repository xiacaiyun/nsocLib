package cn.nsoc.common.applib.entity.user;

import cn.nsoc.common.storer.EntityQuery;

/**
 * Created by sam on 16-6-8.
 */
public class NUserInfoQuery extends EntityQuery {

    public String UserNameToMatch;
}
