package cn.nsoc.common.applib.entity.sys;

import cn.nsoc.common.storer.EntityCollection;

/**
 * Created by sam on 16-7-14.
 */
public class SysParamCollection extends EntityCollection<SysParam, SysParamQuery> {

    public SysParamCollection() {
        super(SysParam.class, SysParamQuery.class);
    }

    public SysParamCollection(SysParamQuery query) {
        this();
        setQuery(query);
    }

}
