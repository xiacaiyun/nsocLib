package cn.nsoc.common.applib.framework.exchange;

/**
 * Created by sam on 16-6-4.
 */
public class ExchangeUrl {
    public static final String APP_VERIFY_TOKEN = "/account/appverifytoken";
    public static final String UPDATE_APP_INFO = "/napi/internal/napp/updateappinfo";


    private ExchangeUrl() {

    }
}
