package cn.nsoc.common.applib.entity.sys;

import cn.nsoc.common.storer.annotation.DbField;
import cn.nsoc.common.storer.annotation.DbTable;

/**
 * Created by sam on 16-7-11.
 */
@DbTable(name = "sys_param")
public class SysParam {

    @DbField(isKey = true, isAutoIncrement = false)
    public String ParamKey;

    public String ParamValue;

}

