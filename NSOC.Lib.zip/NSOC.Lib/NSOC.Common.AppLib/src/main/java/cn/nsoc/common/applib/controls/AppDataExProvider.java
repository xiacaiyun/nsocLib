package cn.nsoc.common.applib.controls;

import cn.nsoc.base.entity.define.NSExceptionCode;
import cn.nsoc.base.entity.sys.NSException;
import cn.nsoc.common.applib.framework.exchange.AppExchangeInfo;
import cn.nsoc.common.applib.framework.exchange.ExRequestInfoModel;
import cn.nsoc.common.conveyor.BaseCacheManager;
import cn.nsoc.common.conveyor.CounterPolicyImpl;
import cn.nsoc.common.util.Misc;
import cn.nsoc.common.util.NApiProxy;
import org.apache.log4j.Logger;
import org.springframework.util.Assert;
import org.springframework.util.StringUtils;

import java.net.URI;
import java.net.URLEncoder;
import java.util.*;

/**
 * Created by sam on 16-7-31.
 */
public class AppDataExProvider {
    private static final Logger logger = Logger.getLogger(AppDataExProvider.class);

    protected static class AppDataCache extends BaseCacheManager<String, List<AppExchangeInfo>, String> {

        public AppDataCache() {
            super(new CounterPolicyImpl(100, 0, 600, 0));
        }


        @Override
        public String onTransform(String src) throws NSException {
            return src;
        }

        @Override
        public List<AppExchangeInfo> onLoad(String key, String searchKey) throws NSException {
            try {
                String html = NApiProxy.getInstance().get(URL_LISTAPPEXCHANGEINFO);
                JsonRet ret = Misc.fromJson(html, JsonRet.class);
                if ((ret == null) || (ret.getData() == null))
                    return new ArrayList<>();

                return Misc.fromJsonToList(Misc.toJson(ret.getData()), AppExchangeInfo[].class);
            } catch (Exception exp) {
                throw new NSException(NSExceptionCode.Runtime_Error, exp);
            }
        }

        public static AppDataCache createCache() {
            try {
                AppDataCache cache = new AppDataCache();
                cache.start();
                return cache;
            } catch (NSException ex) {
                logger.info("error to create AppDataCache");
                Misc.ignoreException(ex);
                return null;
            }
        }
    }

    protected static final AppDataCache cache = AppDataCache.createCache();
    static final String URL_LISTAPPEXCHANGEINFO = "/napi/internal/napp/listappexchangeinfo";


    private AppDataExProvider() {

    }

    public static Map<String, AppExchangeInfo> listNAppExchangeInfo() throws NSException {
        HashMap<String, AppExchangeInfo> map = new HashMap<>();
        Assert.notNull(cache);
        List<AppExchangeInfo> list = cache.search("all");

        list.forEach(p -> map.put(p.getShortName(), p));
        return map;
    }

    public static AppExchangeInfo getAppExchangeInfo(String shortname) throws NSException {
        AppExchangeInfo o = null;
        if (StringUtils.hasText(shortname)) {
            Map<String, AppExchangeInfo> map = listNAppExchangeInfo();
            o = map.getOrDefault(shortname, null);
        }
        return o;
    }

    public static AppExchangeInfo getAppExchangeInfo(UUID appId) throws NSException {
        if (appId != null) {
            Map<String, AppExchangeInfo> map = listNAppExchangeInfo();
            for (AppExchangeInfo app : map.values()) {
                if (app.getAppID().equals(appId))
                    return app;
            }
        }
        return null;
    }

    public static String get(String url, String appname) throws NSException {
        AppExchangeInfo exi = getAppExchangeInfo(appname);
        if (exi == null) {
            return Misc.toJson(new JsonRet(false, "没有这个APP！"));
        }

        try {
            NApiProxy nApiProxy = NApiProxy.getInstance();
            String urlRoot = null;
            URI root = new URI(url);
            if (!root.isAbsolute()) {
                urlRoot = new URI(nApiProxy.getFrameworkRoot()).resolve(exi.getAppUrl()).toString();
            }
            return nApiProxy.get(url, urlRoot, exi.getPublicKey());
        } catch (Exception ex) {
            throw new NSException(ex);
        }
    }

    public static String post(String url, String data, String appname) throws NSException {
        AppExchangeInfo exi = getAppExchangeInfo(appname);
        if (exi == null) {
            return Misc.toJson(new JsonRet(false, "没有这个APP！"));
        }

        try {
            NApiProxy nApiProxy = NApiProxy.getInstance();

            String urlRoot = null;

            URI root = new URI(url);
            if (!root.isAbsolute()) {
                urlRoot = new URI(nApiProxy.getFrameworkRoot()).resolve(exi.getAppUrl()).toString();
            }
            return nApiProxy.post(url, data, urlRoot, exi.getPublicKey());
        } catch (Exception ex) {
            throw new NSException(ex);
        }
    }

    public static String post(ExRequestInfoModel exinfo, String data) throws NSException {
        return post(String.format("/napi/internal/%s/%s", exinfo.getExController(), exinfo.getExAction()), data, exinfo.getExApp());
    }


    private static String buildNapiUrl(ExRequestInfoModel exinfo, Map<String, String> routeValues) {
        StringBuilder sb = new StringBuilder();
        sb.append(String.format("/napi/internal/%s/%s", exinfo.getExController(), exinfo.getExAction()));

        if ((routeValues != null) && (routeValues.size() > 0)) {
            List<String> list = new ArrayList<>();
            routeValues.forEach((k, v) -> {
                try {
                    if (StringUtils.hasText(k) && StringUtils.hasText(v)) {
                        list.add(String.format("%s=%s", k, URLEncoder.encode(v, "UTF-8")));
                    }
                } catch (Exception ignored) {
                    Misc.ignoreException(ignored);
                }
            });

            if (!list.isEmpty()) {
                sb.append("?");
                sb.append(String.join("&", list));
            }
        }
        return sb.toString();
    }

    public static String post(ExRequestInfoModel exinfo, Map<String, String> routeValues, String data) throws NSException {
        return post(buildNapiUrl(exinfo, routeValues), data, exinfo.getExApp());
    }

    public static String get(ExRequestInfoModel exinfo, Map<String, String> routeValues) throws NSException {
        return get(buildNapiUrl(exinfo, routeValues), exinfo.getExApp());
    }

    public static String getAppUrl(String url, String appname) throws NSException {
        try {
            AppExchangeInfo exi = getAppExchangeInfo(appname);
            if (exi == null) {
                return null;
            }

            NApiProxy nApiProxy = NApiProxy.getInstance();

            URI root = new URI(exi.getAppUrl());
            if (!root.isAbsolute()) {

                URI tmp = new URI(nApiProxy.getFrameworkRoot());
                root = tmp.resolve(exi.getAppUrl());
            }

            return root.toString() + url;
        } catch (Exception ex) {
            throw new NSException(ex);
        }
    }
}
