package cn.nsoc.common.applib.entity;

/**
 * Created by fengww on 11/7/16.
 */
public enum AlarmLevelEnum {
    info(0, "一般"),
    low(10, "低"),
    mid(20, "中"),
    high(30, "高");


    private final int val;

    private final String msg;

    AlarmLevelEnum(int val, String msg) {
        this.val = val;
        this.msg = msg;
    }

    public static AlarmLevelEnum getByVal(int val, AlarmLevelEnum defaultItem) {
        for (AlarmLevelEnum iter : values()) {
            if (iter.getVal() == val) {
                return iter;
            }
        }
        return defaultItem;
    }


    public int getVal() {
        return val;
    }

    public String getMsg() {
        return msg;
    }
}

