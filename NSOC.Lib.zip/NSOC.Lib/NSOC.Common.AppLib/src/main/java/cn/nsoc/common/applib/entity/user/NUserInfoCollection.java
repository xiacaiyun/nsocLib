package cn.nsoc.common.applib.entity.user;

import cn.nsoc.common.storer.EntityCollection;

/**
 * Created by sam on 16-6-6.
 */

public class NUserInfoCollection extends EntityCollection<NUserInfo, NUserInfoQuery> {
    public NUserInfoCollection() {
        super(NUserInfo.class, NUserInfoQuery.class);
    }
}
