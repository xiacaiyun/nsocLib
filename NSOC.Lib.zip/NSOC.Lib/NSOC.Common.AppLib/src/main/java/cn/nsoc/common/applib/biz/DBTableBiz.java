package cn.nsoc.common.applib.biz;

import cn.nsoc.base.entity.sys.NSException;
import cn.nsoc.common.applib.entity.dbtableinfo.DBTableInfoCollection;
import cn.nsoc.common.applib.entity.dbtableinfo.DBTableInfoQuery;
import cn.nsoc.common.applib.entity.partition.DBTablePartition;
import cn.nsoc.common.applib.entity.partition.DBTablePartitionCollection;
import cn.nsoc.common.applib.entity.partition.DBTablePartitionQuery;
import cn.nsoc.common.storer.db.DbSelectBuilder;
import cn.nsoc.common.storer.db.JdbcDbStorer;
import cn.nsoc.common.util.Misc;
import org.apache.log4j.Logger;


public class DBTableBiz {
    private JdbcDbStorer dbStorer;

    //for cpic
    private static final String cmdAlter = "ALTER";


    public DBTableBiz() {
        dbStorer = JdbcDbStorer.getInstance();
    }

    public DBTableBiz(JdbcDbStorer dbStorer) {
        this.dbStorer = dbStorer;
    }

    public DBTableInfoCollection loadInfo(DBTableInfoCollection me) throws NSException {
        DBTableInfoQuery query = me.getQuery();
        query.orderBy = DBTableInfoQuery.OrderByEnum.Scheme_TableName;
        DbSelectBuilder sb = new DbSelectBuilder(dbStorer, new String[]{"Engine"});
        query.selectFields = sb;
        sb.addField("Scheme", "TABLE_SCHEMA");
        sb.addField("TableName", "Table_Name");
        sb.addField("Rows", "Table_Rows");
        sb.addField("DataLength", "Data_Length");
        sb.addField("IndexLength", "Index_Length");
        sb.addField("AutoIncrementID", "Auto_Increment");

        return (DBTableInfoCollection) dbStorer.load(me);
    }

    public DBTablePartitionCollection loadPartition(DBTablePartitionCollection me) throws NSException {
        DBTablePartitionQuery query = me.getQuery();
        query.orderBy = DBTablePartitionQuery.OrderByEnum.Scheme_TableName_OrderPos;
        DbSelectBuilder sb = new DbSelectBuilder(dbStorer, null);
        query.selectFields = sb;
        sb.addField("Scheme", "TABLE_SCHEMA");
        sb.addField("TableName", "Table_Name");
        sb.addField("Rows", "Table_Rows");
        sb.addField("DataLength", "Data_Length");
        sb.addField("IndexLength", "Index_Length");
        sb.addField("PartitionName", "PARTITION_NAME");
        sb.addField("OrderPos", "PARTITION_ORDINAL_POSITION");
        sb.addField("PartitionDescription", "PARTITION_DESCRIPTION");
        return (DBTablePartitionCollection) dbStorer.load(me);
    }

    public boolean delete(DBTablePartition dbTablePartition) {

        String sql = String.format("%s TABLE %s.%s DROP PARTITION %s",
                cmdAlter,
                dbTablePartition.getScheme(),
                dbTablePartition.getTableName(),
                dbTablePartition.getPartitionName());

        try {
            dbStorer.exec(sql);
            return true;
        } catch (Exception e) {
            Logger.getLogger(DBTableBiz.class).warn(e.getMessage());
            Misc.ignoreException(e);
            return false;
        }
    }

    public boolean update(DBTablePartition dbTablePartition) {

        String sql = String.format("%s TABLE %s.%s REORGANIZE PARTITION %s INTO " +
                        "(PARTITION %s VALUES LESS THAN (%s),PARTITION %s VALUES LESS THAN (%s),PARTITION pMax VALUES LESS THAN MAXVALUE)",
                cmdAlter,
                dbTablePartition.getScheme(),
                dbTablePartition.getTableName(),
                dbTablePartition.getPartitionName(),
                dbTablePartition.getPartitionName1(),
                dbTablePartition.getValue1(),
                dbTablePartition.getPartitionName2(),
                dbTablePartition.getValue2()
        );

        try {
            dbStorer.exec(sql);
            return true;
        } catch (Exception e) {
            Logger.getLogger(DBTableBiz.class).warn(e.getMessage());
            Misc.ignoreException(e);
            return false;
        }
    }

    public boolean insert(DBTablePartition dbTablePartition) {


        String sql = String.format("%s TABLE %s.%s ADD PARTITION " +
                        "(PARTITION %s VALUES LESS THAN (%s))",
                cmdAlter,
                dbTablePartition.getScheme(),
                dbTablePartition.getTableName(),
                dbTablePartition.getPartitionName(),
                dbTablePartition.getValue1()
        );

        try {
            dbStorer.exec(sql);
            return true;
        } catch (Exception e) {
            Logger.getLogger(DBTableBiz.class).warn(e.getMessage());
            Misc.ignoreException(e);
            return false;
        }
    }
}
