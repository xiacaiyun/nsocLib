package cn.nsoc.common.applib.entity;

import cn.nsoc.common.storer.annotation.DbField;
import cn.nsoc.common.storer.annotation.DbTable;

import java.math.BigInteger;
import java.time.LocalDateTime;

/**
 * Created by sam on 16-12-2.
 */
public class CAppLog {
    private CAppLog() {

    }

    @DbTable(name = "app_log")
    public static class Entity {

        @DbField(isKey = true)
        private BigInteger LogID;

        private LocalDateTime HappenTime;

        private String LogName;

        private String Message;

        public BigInteger getLogID() {
            return LogID;
        }

        public void setLogID(BigInteger logID) {
            LogID = logID;
        }

        public LocalDateTime getHappenTime() {
            return HappenTime;
        }

        public void setHappenTime(LocalDateTime happenTime) {
            HappenTime = happenTime;
        }

        public String getLogName() {
            return LogName;
        }

        public void setLogName(String logName) {
            LogName = logName;
        }

        public String getMessage() {
            return Message;
        }

        public void setMessage(String message) {
            Message = message;
        }
    }
}
