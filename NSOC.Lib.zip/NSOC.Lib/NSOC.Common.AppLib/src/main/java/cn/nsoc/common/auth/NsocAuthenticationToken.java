package cn.nsoc.common.auth;

import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.GrantedAuthority;

import java.util.ArrayList;
import java.util.Collection;

/**
 * Created by sam on 16-10-8.
 */
@SuppressWarnings("unchecked")
public class NsocAuthenticationToken extends UsernamePasswordAuthenticationToken {

    private NsocUser user;


    public NsocAuthenticationToken(Object principal, Object credentials) {
        super(principal, credentials, new ArrayList<>());
    }

    public NsocAuthenticationToken(Object principal, Object credentials, Collection<? extends GrantedAuthority> authorities) {
        super(principal, credentials, authorities);
    }

    public NsocUser getUser() {
        return user;
    }

    public void setUser(NsocUser user) {
        this.user = user;
    }

}