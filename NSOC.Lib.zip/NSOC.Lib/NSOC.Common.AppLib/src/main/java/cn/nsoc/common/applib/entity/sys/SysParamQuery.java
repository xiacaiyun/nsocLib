package cn.nsoc.common.applib.entity.sys;

import cn.nsoc.common.storer.EntityQuery;

/**
 * Created by sam on 16-7-14.
 */
public class SysParamQuery extends EntityQuery {
    public String ParamKey;
}
