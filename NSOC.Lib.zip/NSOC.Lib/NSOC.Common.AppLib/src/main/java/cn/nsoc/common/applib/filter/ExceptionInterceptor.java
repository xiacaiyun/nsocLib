package cn.nsoc.common.applib.filter;

import cn.nsoc.base.entity.sys.NSException;
import cn.nsoc.common.applib.controls.AppExceptionContext;
import cn.nsoc.common.applib.controls.JsonRet;
import cn.nsoc.common.applib.error.ErrorType;
import cn.nsoc.common.util.Misc;
import cn.nsoc.common.util.NApiProxy;
import org.apache.log4j.Logger;
import org.springframework.util.StringUtils;
import org.springframework.web.servlet.handler.HandlerInterceptorAdapter;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.PrintWriter;
import java.time.LocalDateTime;


/**
 * Created by sam on 16-9-20.
 */
public class ExceptionInterceptor extends HandlerInterceptorAdapter {

    private String appname;

    static final String MIME_JSON = "application/json";
    static final String MIME_HTML = "text/html";
    static final String URL_REPORT = "/napi/public/exception/report";
    static final Logger logger = Logger.getLogger(ExceptionInterceptor.class);


    public ExceptionInterceptor(String appname) {
        super();

        this.appname = appname;
    }

    @Override
    public void afterCompletion(HttpServletRequest request, HttpServletResponse response, Object handler, Exception ex) {

        if (ex != null) {

            StringBuilder expBuilder = new StringBuilder();
            try {
                AppExceptionContext aeCtx = new AppExceptionContext();
                aeCtx.setHappenTime(Misc.toStdString(LocalDateTime.now()));
                aeCtx.setErrorName("App Exception");

                expBuilder.append(String.format("url:%s%n", request.getRequestURI()));
                expBuilder.append(String.format("message:%s%n", ex));

//              注释  StringWriter errors = new StringWriter()
//              注释   ex.printStackTrace(new PrintWriter(errors))
//              注释   expBuilder.append(String.format("stack:%s", errors.toString()))

                aeCtx.setMessage(expBuilder.toString());
                aeCtx.setAppName(this.appname);

                saveException(aeCtx);

                //spring will continue to transfer ex to other Interceptor, so must send null here to stop others process the exception
                super.afterCompletion(request, response, handler, null);
            } catch (Exception exp) {
                logger.error(String.format("[%s] %s %s", LocalDateTime.now(),
                        exp.getMessage(),
                        expBuilder.toString()));
                Misc.ignoreException(exp);
            } finally {
                processError(request, response);

            }
        }
    }


    private void processError(HttpServletRequest request, HttpServletResponse response) {
        try {

            String accept = request.getHeader("Accept");
            if (StringUtils.hasText(accept) && (accept.contains(MIME_JSON))) {
                response.setContentType(MIME_JSON);
                response.setCharacterEncoding("utf-8");

                PrintWriter out = response.getWriter();
                out.write(Misc.toJson(new JsonRet(false, ErrorType.systemError.getText())));
                out.close();

            } else {

                response.setContentType(MIME_HTML);
                response.setCharacterEncoding("utf-8");
                PrintWriter out = response.getWriter();
                out.write("<script type=\"text/javascript\">");
                out.write(String.format("window.location = '%s' ;", request.getContextPath() + "/error?type=" + ErrorType.systemError.name()));
                out.write("</script>");
                out.close();

            }
        } catch (Exception ex) {
            logger.error(String.format("[%s] %s", LocalDateTime.now(),
                    ex.getMessage()));
            Misc.ignoreException(ex);

        }
    }

    protected void saveException(AppExceptionContext aeCtx) throws NSException {
        NApiProxy.getInstance().post(URL_REPORT, Misc.toJson(aeCtx));
    }
}
