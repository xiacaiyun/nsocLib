package cn.nsoc.common.applib.entity.dbtableinfo;

import cn.nsoc.common.storer.annotation.DbTable;


/**
 * Created by jz on 10/24/16.
 */
@DbTable(name = "information_schema.tables")
public class DBTableInfo {
    private String Scheme;
    private String Engine;
    private String TableName;
    private Integer Rows;
    private Long DataLength;
    private Long IndexLength;
    private Integer AutoIncrementID;
    private String DataSpace;
    private String IndexSpace;
    private String TotalSpace;

    public String getScheme() {
        return Scheme;
    }

    public void setScheme(String scheme) {
        Scheme = scheme;
    }

    public String getEngine() {
        return Engine;
    }

    public void setEngine(String engine) {
        Engine = engine;
    }

    public String getTableName() {
        return TableName;
    }

    public void setTableName(String tableName) {
        TableName = tableName;
    }

    public Integer getRows() {
        return Rows;
    }

    public void setRows(Integer rows) {
        Rows = rows;
    }

    public Long getDataLength() {
        return DataLength;
    }

    public void setDataLength(Long dataLength) {
        DataLength = dataLength;
    }

    public Long getIndexLength() {
        return IndexLength;
    }

    public void setIndexLength(Long indexLength) {
        IndexLength = indexLength;
    }

    public Integer getAutoIncrementID() {
        return AutoIncrementID;
    }

    public void setAutoIncrementID(Integer autoIncrementID) {
        AutoIncrementID = autoIncrementID;
    }

    public String getDataSpace() {
        return DataSpace;
    }

    public void setDataSpace(String dataSpace) {
        DataSpace = dataSpace;
    }

    public String getIndexSpace() {
        return IndexSpace;
    }

    public void setIndexSpace(String indexSpace) {
        IndexSpace = indexSpace;
    }

    public String getTotalSpace() {
        return TotalSpace;
    }

    public void setTotalSpace(String totalSpace) {
        TotalSpace = totalSpace;
    }
}
