package cn.nsoc.common.applib.webconfig;

import org.apache.commons.dbcp2.BasicDataSource;
import org.apache.log4j.Logger;

import java.sql.Driver;
import java.sql.DriverManager;
import java.sql.SQLException;

/**
 * Created by sam on 17-9-24.
 */
public class NsocDataSource extends BasicDataSource {
    private static final Logger logger = Logger.getLogger(NsocDataSource.class);

    // driver is null, getDriverClassLoader() is null
    @Override
    public synchronized void close() throws SQLException {

        logger.debug("NsocDatasource is closing");

        String url = this.getUrl();

        super.close();

        Driver driver = DriverManager.getDriver(url);
        if (driver != null) {
            DriverManager.deregisterDriver(driver);
            logger.debug(String.format("DriverManager.deregisterDrivered: %s",driver));
        }
    }
}
