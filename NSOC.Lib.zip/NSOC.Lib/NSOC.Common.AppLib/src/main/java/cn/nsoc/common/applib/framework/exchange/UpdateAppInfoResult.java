package cn.nsoc.common.applib.framework.exchange;

/**
 * Created by sam on 16-7-19.
 */
public class UpdateAppInfoResult extends BaseResult {
    private String RSAKey;

    public String getRSAKey() {
        return RSAKey;
    }

    public void setRSAKey(String RSAKey) {
        this.RSAKey = RSAKey;
    }
}