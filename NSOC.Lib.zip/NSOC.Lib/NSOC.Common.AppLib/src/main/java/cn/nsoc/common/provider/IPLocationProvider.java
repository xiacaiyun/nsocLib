package cn.nsoc.common.provider;

import cn.nsoc.base.entity.sys.NSException;
import cn.nsoc.common.applib.controls.JsonRet;
import cn.nsoc.common.applib.entity.IpLocation;
import cn.nsoc.common.util.Misc;
import cn.nsoc.common.util.NApiProxy;
import org.springframework.util.Assert;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by sam on 16-9-30.
 */
public class IPLocationProvider {
    static final String URL_GETIP = "/pub/napi/internal/iplocation/lookup";

    private NApiProxy nApiProxy;

    public IPLocationProvider(NApiProxy nApiProxy) {
        Assert.notNull(nApiProxy);

        this.nApiProxy = nApiProxy;
    }

    public IPLocationProvider(String frameworkRoot, String pubAddress) {
        this.nApiProxy = new NApiProxy(frameworkRoot, null, null);
    }

    public List<IpLocation> getIPs(String[] iparr) throws NSException {
        StringBuilder sb = new StringBuilder("[");
        for (String ip : iparr) {
            sb.append("\"").append(ip).append("\",");
        }
        sb.deleteCharAt(sb.length() - 1);
        sb.append("]");
        String html = this.nApiProxy.post(URL_GETIP, "{\"iplist\": " + sb.toString() + "}");
        JsonRet r = Misc.fromJson(html, JsonRet.class);
        if ((r != null) && r.isRet() && r.getData() != null) {
            return Misc.fromJsonToList(Misc.toJson(r.getData()), IpLocation[].class);
        }
        return new ArrayList<>();
    }

    public List<IpLocation> getIPs(String ipList) throws NSException {
        String[] iparr = ipList.split(",");
        return getIPs(iparr);
    }
}

