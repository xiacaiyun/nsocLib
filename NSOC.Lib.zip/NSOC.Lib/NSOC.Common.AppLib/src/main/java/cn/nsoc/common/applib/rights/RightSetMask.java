package cn.nsoc.common.applib.rights;

/**
 * Created by sam on 16-8-10.
 */
public enum RightSetMask {

    AllowRight,
    //DenyRight, 不需要deny
    EnableAppEx,
    AllowAnonymous,
    AllowAllLoginedUser
}
