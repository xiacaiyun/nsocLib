package cn.nsoc.common.applib.entity.category;

/**
 * Created by xiacaiyun on 2016/10/18.
 */
public abstract class CategoryTemplate {

    public CategoryTemplate() {
        setVisible(true);
    }

    private int GroupID;
    private int ParentID;
    private int Level;
    private String Name;
    private boolean IsDeleted;
    private String TracePath;
    private String Memo;
    private int SortOrder;
    private boolean IsVisible;
    /// <summary>
    /// for use of delete
    /// </summary>
    private String Descendants;


    public boolean IsRoot() {
        return (getParentID() == 0);
    }


    public int GetRootID() {
        if (IsRoot())
            return getGroupID();

        return Integer.parseInt(getTracePath().split("\\_")[0]);
    }


    public int getGroupID() {
        return GroupID;
    }

    public void setGroupID(int groupID) {
        GroupID = groupID;
    }

    public int getParentID() {
        return ParentID;
    }

    public void setParentID(int parentID) {
        ParentID = parentID;
    }

    public int getLevel() {
        return Level;
    }

    public void setLevel(int level) {
        Level = level;
    }

    public String getName() {
        return Name;
    }

    public void setName(String name) {
        Name = name;
    }

    public boolean isDeleted() {
        return IsDeleted;
    }

    public void setDeleted(boolean deleted) {
        IsDeleted = deleted;
    }

    public String getTracePath() {
        return TracePath;
    }

    public void setTracePath(String tracePath) {
        TracePath = tracePath;
    }

    public String getMemo() {
        return Memo;
    }

    public void setMemo(String memo) {
        Memo = memo;
    }

    public int getSortOrder() {
        return SortOrder;
    }

    public void setSortOrder(int sortOrder) {
        SortOrder = sortOrder;
    }

    public boolean isVisible() {
        return IsVisible;
    }

    public void setVisible(boolean visible) {
        IsVisible = visible;
    }

    public String getDescendants() {
        return Descendants;
    }

    public void setDescendants(String descendants) {
        Descendants = descendants;
    }
}
