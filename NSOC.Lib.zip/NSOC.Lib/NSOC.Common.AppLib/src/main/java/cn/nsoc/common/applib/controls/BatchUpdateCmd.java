package cn.nsoc.common.applib.controls;

/**
 * Created by sam on 16-8-4.
 */
public enum BatchUpdateCmd {
    delete,
    append,
    remove,
    discard,
    release,
    update,
    favorite,
    unfavorite,
    process,
    confirm,
    start,
    pause,
    export
}
