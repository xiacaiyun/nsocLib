package cn.nsoc.common.applib.entity.notifysetting;

import cn.nsoc.common.storer.EntityQuery;

public class NotifysettingQuery extends EntityQuery {
    public enum OrderBy {
        Name,
        SettingID__asc
    }

    private Integer SettingID;

    public int getSettingID() {
        return SettingID;
    }

    public void setSettingID(int SettingID) {
        this.SettingID = SettingID;
    }

}

