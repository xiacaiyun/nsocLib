package cn.nsoc.common.auth;

import cn.nsoc.common.applib.entity.config.AppRuntimeConfig;
import cn.nsoc.common.applib.error.ErrorType;
import cn.nsoc.common.applib.webconfig.BaseNsocWebSecurityConfigurerAdapter;
import cn.nsoc.common.util.Misc;
import org.springframework.security.web.util.matcher.AntPathRequestMatcher;
import org.springframework.util.Assert;
import org.springframework.util.StringUtils;
import org.springframework.web.filter.GenericFilterBean;

import javax.servlet.FilterChain;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

/**
 * Created by sam on 16-10-21.
 */
public class NsocLicenseProcessionFilter extends GenericFilterBean {

    private String setLicenseUrl = null;
    private List<AntPathRequestMatcher> skipUrlsMatchers = null;

    private BaseNsocWebSecurityConfigurerAdapter config = null;

    public NsocLicenseProcessionFilter(String setLicenseUrl, BaseNsocWebSecurityConfigurerAdapter config, String[] skipUrls) {
        Assert.hasText(setLicenseUrl);
        this.config = config;
        this.setLicenseUrl = setLicenseUrl;
        skipUrlsMatchers = new ArrayList<>();
        skipUrlsMatchers.add(new AntPathRequestMatcher(setLicenseUrl));

        if (skipUrls != null) {
            for (String url : skipUrls) {
                skipUrlsMatchers.add(new AntPathRequestMatcher(url));
            }
        }
    }

    private boolean isSkipRequest(HttpServletRequest request) {
        for (AntPathRequestMatcher matcher : skipUrlsMatchers) {
            if (matcher.matches(request))
                return true;
        }
        return false;
    }

    protected boolean checkLicense() throws ServletException {
        try {
            if (!config.checkLicense())
                return false;
            AppRuntimeConfig ac = AppRuntimeConfig.Current();
            return StringUtils.hasText(ac.getRSAKey());
        } catch (Exception ex) {
            throw new ServletException("checkLicense error", ex);
        }
    }

    @Override
    public void doFilter(ServletRequest req, ServletResponse res, FilterChain chain) throws IOException, ServletException {
        HttpServletRequest request = (HttpServletRequest) req;
        HttpServletResponse response = (HttpServletResponse) res;

        boolean bLicenseOk;
        try {
            bLicenseOk = isSkipRequest(request) || this.checkLicense();
        } catch (Exception ex) {
            response.sendRedirect(request.getContextPath() + "/error?type=" + ErrorType.dbError.name());
            Misc.ignoreException(ex);
            return;
        }

        if (bLicenseOk) {
            chain.doFilter(request, response);
        } else {
            if (this.logger.isDebugEnabled()) {
                this.logger.debug("License not installed");
            }

            response.sendRedirect(request.getContextPath() + setLicenseUrl);
        }
    }
}
