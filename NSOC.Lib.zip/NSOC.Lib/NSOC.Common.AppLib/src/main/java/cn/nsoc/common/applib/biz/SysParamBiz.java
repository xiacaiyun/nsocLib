package cn.nsoc.common.applib.biz;

import cn.nsoc.base.entity.sys.NSException;
import cn.nsoc.common.applib.entity.sys.SysParam;
import cn.nsoc.common.applib.entity.sys.SysParamCollection;
import cn.nsoc.common.applib.entity.sys.SysParamQuery;
import cn.nsoc.common.storer.db.DbInsertBuilder;
import cn.nsoc.common.storer.db.JdbcDbStorer;
import cn.nsoc.common.storer.option.InsertOption;
import cn.nsoc.common.storer.option.UpdateOperator;
import org.springframework.util.Assert;

/**
 * Created by sam on 16-7-14.
 */
public class SysParamBiz {

    private SysParamBiz() {

    }

    public static SysParamCollection load(SysParamCollection me) throws NSException {
        return (SysParamCollection) JdbcDbStorer.getInstance().load(me);
    }

    public static boolean insert(SysParam me) throws NSException {
        JdbcDbStorer dbStorer = JdbcDbStorer.getInstance();

        DbInsertBuilder builder = new DbInsertBuilder(dbStorer);
        builder.setInsertOption(InsertOption.UpdateOnDuplicate);
        builder.append("ParamValue", UpdateOperator.Set);

        return dbStorer.insert(me, builder);
    }

    public static SysParam get(String key) throws NSException {
        Assert.hasLength(key);
        SysParamQuery query = new SysParamQuery();
        query.ParamKey = key;
        SysParamCollection coll = load(new SysParamCollection(query));
        return coll.isEmpty() ? null : coll.get(0);
    }
}
