package cn.nsoc.common.auth;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.AuthenticationProvider;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.AuthenticationException;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;

/**
 * Created by sam on 16-10-8.
 */
public class NsocAppAuthenticationProvider implements AuthenticationProvider {

    @Autowired
    private UserDetailsService nsocUserService;


    @Override
    public Authentication authenticate(Authentication authentication) throws AuthenticationException {

        if (authentication instanceof NsocRememberMeAuthenticationToken) {

            NsocUser userdetails = ((NsocRememberMeAuthenticationToken) authentication).getUser();
            NsocAuthenticationToken token = new NsocAuthenticationToken(userdetails.getUsername(), authentication.getAuthorities());
            token.setUser(userdetails);

            return token;
        } else if (authentication instanceof NsocSSOAuthenticationToken) {

            UserDetails userdetails = nsocUserService.loadUserByUsername(authentication.getName());

            NsocAuthenticationToken newtoken = new NsocAuthenticationToken(userdetails.getUsername(), authentication.getAuthorities());
            newtoken.setUser((NsocUser) userdetails);

            return newtoken;
        }
        return authentication;
    }

    @Override
    public boolean supports(Class<?> aClass) {
        return aClass.equals(NsocAuthenticationToken.class)
                || aClass.equals(NsocRememberMeAuthenticationToken.class)
                || aClass.equals(NsocSSOAuthenticationToken.class);
    }
}
