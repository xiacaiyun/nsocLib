package cn.nsoc.common.applib.framework.auth;

import java.util.UUID;

/**
 * Created by sam on 16-6-4.
 */
public class VerifyTokenRequest {

    private UUID AppID;

    private UUID SessionID;

    private String Token;

    private String Sign;

    public UUID getAppID() {
        return AppID;
    }

    public void setAppID(UUID appID) {
        AppID = appID;
    }

    public UUID getSessionID() {
        return SessionID;
    }

    public void setSessionID(UUID sessionID) {
        SessionID = sessionID;
    }

    public String getToken() {
        return Token;
    }

    public void setToken(String token) {
        Token = token;
    }

    public String getSign() {
        return Sign;
    }

    public void setSign(String sign) {
        Sign = sign;
    }
}
