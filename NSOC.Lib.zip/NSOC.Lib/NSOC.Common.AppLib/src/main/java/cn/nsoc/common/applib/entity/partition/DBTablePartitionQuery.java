package cn.nsoc.common.applib.entity.partition;

/**
 * Created by jz on 2017/4/11.
 */

import cn.nsoc.common.storer.EntityQuery;
import cn.nsoc.common.storer.annotation.DbQuery;
import cn.nsoc.common.storer.annotation.QueryOperator;

import java.util.List;

public class DBTablePartitionQuery extends EntityQuery {

    public enum OrderByEnum {
        Scheme_TableName_OrderPos
    }

    @DbQuery(
            Operator = QueryOperator.In
    )
    private List<String> SchemeIDList;
    @DbQuery(
            Operator = QueryOperator.In
    )
    private List<String> TABLE_NAMEIDList;
    private String TABLE_SCHEMA;

    @DbQuery(Operator = QueryOperator.In)
    private List<String> TABLE_SCHEMAIDList;

    public DBTablePartitionQuery() {
        // empty
    }

    public List<String> getSchemeIDList() {
        return SchemeIDList;
    }

    public void setSchemeIDList(List<String> schemeIDList) {
        SchemeIDList = schemeIDList;
    }

    public List<String> getTABLE_NAMEIDList() {
        return TABLE_NAMEIDList;
    }

    public void setTABLE_NAMEIDList(List<String> TABLE_NAMEIDList) {
        this.TABLE_NAMEIDList = TABLE_NAMEIDList;
    }

    public String getTABLE_SCHEMA() {
        return TABLE_SCHEMA;
    }

    public void setTABLE_SCHEMA(String TABLE_SCHEMA) {
        this.TABLE_SCHEMA = TABLE_SCHEMA;
    }

    public List<String> getTABLE_SCHEMAIDList() {
        return TABLE_SCHEMAIDList;
    }

    public void setTABLE_SCHEMAIDList(List<String> TABLE_SCHEMAIDList) {
        this.TABLE_SCHEMAIDList = TABLE_SCHEMAIDList;
    }


}

