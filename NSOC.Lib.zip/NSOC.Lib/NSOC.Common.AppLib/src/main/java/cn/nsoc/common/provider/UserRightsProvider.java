package cn.nsoc.common.provider;

import cn.nsoc.base.entity.sys.NSException;
import cn.nsoc.common.applib.membership.UserInfoProvider;
import cn.nsoc.common.applib.rights.RightsContext;
import cn.nsoc.common.auth.NsocUser;
import cn.nsoc.common.conveyor.cache.LazyCache;
import cn.nsoc.common.util.NApiProxy;

import java.util.function.Function;

/**
 * Created by sam on 16-10-12.
 */
public class UserRightsProvider {

    static LazyCache cache = LazyCache.createCache(null);
    private Function<Object, Object> getRightsContext = userId -> {
        try {
            return new UserInfoProvider(NApiProxy.getInstance()).getRights((Integer) userId);
        } catch (Exception ex) {
            return ex;
        }
    };


    public RightsContext getUserRights(int userId) throws NSException {
        return getUserRights(userId, false);
    }

    public RightsContext getUserRights(int userId, boolean nocache) throws NSException {

        if (nocache || (cache == null)) {
            Object val = getRightsContext.apply(userId);
            if (val instanceof Exception) {
                throw new NSException((Exception) val);
            } else {
                return (RightsContext) val;
            }
        } else {
            return (RightsContext) cache.getOrLoad(Integer.toString(userId), getRightsContext, userId);
        }
    }


    public RightsContext getUserRights(NsocUser user) throws NSException {
        RightsContext rightsContext = user.getRights();
        if (rightsContext == null) {
            rightsContext = getUserRights(user.getUserId(), false);
            user.setRights(rightsContext);
        }
        return rightsContext;
    }
}
