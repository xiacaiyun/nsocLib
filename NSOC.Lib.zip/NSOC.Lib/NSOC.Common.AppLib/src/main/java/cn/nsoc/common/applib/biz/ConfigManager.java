package cn.nsoc.common.applib.biz;

import cn.nsoc.base.entity.define.NSExceptionCode;
import cn.nsoc.base.entity.sys.NSException;
import cn.nsoc.common.applib.entity.config.Config;
import cn.nsoc.common.applib.entity.sys.SysParam;
import cn.nsoc.common.conveyor.BaseCacheManager;
import cn.nsoc.common.conveyor.CounterPolicyImpl;
import cn.nsoc.common.util.Misc;
import org.springframework.util.StringUtils;

/**
 * Created by sam on 16-7-14.
 */
public class ConfigManager {

    private ConfigManager() {

    }

    public static class ConfigCache extends BaseCacheManager<String, Config, Class<? extends Config>> {
        public ConfigCache() {
            super(new CounterPolicyImpl(100, 0, 600, 0));
        }


        @Override
        public String onTransform(Class<? extends Config> src) throws NSException {
            return src.getSimpleName();
        }

        @Override
        public Config onLoad(String key, Class<? extends Config> searchKey) throws NSException {
            try {
                return ConfigManager.loadConfig(searchKey);
            } catch (Exception ex) {
                throw new NSException(NSExceptionCode.Biz_Cache_Get_Failed, ex);
            }
        }

        public static ConfigCache createCache() throws NSException {
            ConfigCache cache = new ConfigCache();
            cache.start();
            return cache;
        }
    }

    private static ConfigCache cache;

    static ConfigCache getCache() throws NSException {
        if (cache == null) {
            cache = new ConfigCache();
            cache.start();
        }
        return cache;
    }

    @SuppressWarnings("unchecked")
    public static <T extends Config> T getConfig(Class<T> tClass) throws NSException {
        return (T) getCache().search(tClass);
    }

    private static <T extends Config> T loadConfig(Class<T> tClass) throws NSException {
        T config = null;

        SysParam p = SysParamBiz.get(tClass.getSimpleName());

        if ((p != null) && StringUtils.hasText(p.ParamValue))
            config = Misc.fromJson(p.ParamValue, tClass);

        try {
            if (config == null)
                config = tClass.newInstance();

            return config;
        } catch (Exception ex) {
            throw new NSException(ex);
        }
    }

    @SuppressWarnings("unchecked")
    public static void modifyConfig(Config config) throws NSException {

        Class tClass = config.getClass();

        SysParam p = new SysParam();
        p.ParamKey = tClass.getSimpleName();
        p.ParamValue = Misc.toJson(config);
        SysParamBiz.insert(p);

        getCache().remove(tClass);
    }
}

