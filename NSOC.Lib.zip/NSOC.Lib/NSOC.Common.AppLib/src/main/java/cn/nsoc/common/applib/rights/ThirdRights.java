package cn.nsoc.common.applib.rights;

import cn.nsoc.common.provider.IThirdRightProvider;

/**
 * Created by sam on 17-5-2.
 */
public class ThirdRights {

    private IThirdRightProvider rightProvider;

    private Object rights;

    public boolean isAvailable() {
        return getRightProvider() != null;
    }

    public void setRights(Object rights) {
        this.rights = getRightProvider().parse(rights);
    }


    public Object getRights() {
        return isAvailable() ? rights : null;
    }

    public IThirdRightProvider getRightProvider() {
        return rightProvider;
    }

    public void setRightProvider(IThirdRightProvider rightProvider) {
        this.rightProvider = rightProvider;
    }
}
