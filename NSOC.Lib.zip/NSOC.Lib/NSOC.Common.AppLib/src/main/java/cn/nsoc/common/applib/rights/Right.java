package cn.nsoc.common.applib.rights;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

/**
 * Created by sam on 16-8-9.
 * <p>
 * usage:
 * 1) if (not set) allowRight = all rights
 * 2) if (multiple rights)  need set RightSetMask, otherwise value will be overrided;
 */
@Target({ElementType.METHOD, ElementType.TYPE})
@Retention(RetentionPolicy.RUNTIME)
public @interface Right {

    RightsValEnum[] allowRight() default {};

    boolean enableAppEx() default false;

    boolean allowAllLoginedUser() default false;

    boolean allowAnonymous() default false;

    RightSetMask[] mask() default {};
}
