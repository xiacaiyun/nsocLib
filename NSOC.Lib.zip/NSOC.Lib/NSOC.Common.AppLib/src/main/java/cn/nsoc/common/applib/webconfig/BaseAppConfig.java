package cn.nsoc.common.applib.webconfig;

import cn.nsoc.base.entity.sys.NSException;
import cn.nsoc.common.util.Misc;
import cn.nsoc.common.util.RSACryptoServiceProvider;
import cn.nsoc.common.util.ThreeDESCryptoServiceProvider;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.util.Assert;
import org.springframework.util.StringUtils;

/**
 * Created by sam on 16-10-8.
 */
public abstract class BaseAppConfig {

    private static final byte[] propertyPasswordkey = Misc.hexStringToByteArray("2998EA66DCCCC7B156DC9F369D9A41482998EA66DCCCC7B1");


    public String getEncryptValue(String value) throws NSException {
        if (StringUtils.hasText(value) && StringUtils.hasText(security_passwordEncryptMethod)) {
            switch (security_passwordEncryptMethod) {
                case "3des":
                    return ThreeDESCryptoServiceProvider.decrypt(value, propertyPasswordkey);
                default:
                    break;
            }
        }
        return value;
    }

    // Spring EL方式 or  PlaceHolder方式 注解表示法

    private byte[] machineKey;

    private byte[] encryptKey;


    @Value("${machineKey}")
    public void setMachineKey(String machineKey) {
        Assert.hasText(machineKey, "AppConfig.machineKey 不能为空！");
        byte[] bytes = Misc.hexStringToByteArray(machineKey.trim());
        if ((bytes == null) || (bytes.length != 16))
            throw new IllegalArgumentException("AppConfig.machineKey 参数不准确！");


        this.machineKey = bytes;
    }

    public byte[] getMachineKey() {
        return this.machineKey;
    }

    @Value("${encryptKey}")
    public void setEncrptKey(String encryptKey) {
        Assert.hasText(encryptKey, "AppConfig.encrptKey 不能为空！");
        byte[] bytes = Misc.hexStringToByteArray(encryptKey.trim());
        if ((bytes == null) || (bytes.length != 16))
            throw new IllegalArgumentException("AppConfig.encryptKey 参数不准确！");


        this.encryptKey = bytes;
    }


    private RSACryptoServiceProvider webrsa;

    @Value("${webJsRsaKey:#{null}}")
    public void setWebJsRsaKey(String webJsRsaKey) throws NSException {
        if (StringUtils.hasText(webJsRsaKey)) {
            webrsa = new RSACryptoServiceProvider();
            webrsa.fromXmlString(webJsRsaKey);
        }
    }

    public RSACryptoServiceProvider getWebJsRsaKey() {
        return webrsa;
    }


    public byte[] getEncryptKey() {
        return this.encryptKey;
    }

    @Value("${nsoc.driverClassName}")
    public String nsoc_driverClassName;
    @Value("${nsoc.url}")
    public String nsoc_url;
    @Value("${nsoc.username}")
    public String nsoc_username;
    @Value("${nsoc.password}")
    public String nsoc_password;
    @Value("${nsoc.initialSize}")
    public int nsoc_initialSize;


    @Value("${nsoc.maxtotal: 500}")
    public int nsoc_maxtotal;
    @Value("${nsoc.maxidle:50}")
    public int nsoc_maxidle;
    @Value("${nsoc.minidle:10}")
    public int nsoc_minidle;
    @Value("${nsoc.minevictableidletimemillis:1800000}")
    public int nsoc_minevictableidletimemillis;


    @Value("${nsoc_r.url:#{null}}")
    public String nsocreadonly_url;
    @Value("${nsoc_r.username:#{null}}")
    public String nsocreadonly_username;
    @Value("${nsoc_r.password:#{null}}")
    public String nsocreadonly_password;


    private int security_sessionTimeout = 0;

    @Value("${security.sessionTimeout: 0}")
    public void setSecurity_sessionTimeout(Integer security_sessionTimeout) {
        if (security_sessionTimeout != null && security_sessionTimeout > 0) {
            this.security_sessionTimeout = security_sessionTimeout;
        }
    }

    public int getSecurity_sessionTimeout() {
        return security_sessionTimeout;
    }


    public String security_passwordEncryptMethod = null;

    @Value("${security.passwordEncryptMethod:#{null}}")
    public void setSecurity_passwordEncryptMethod(String security_passwordEncryptMethod) {

        if (!StringUtils.hasText(security_passwordEncryptMethod))
            return;

        String method = security_passwordEncryptMethod.toLowerCase().trim();
        switch (method) {
            case "3des":
                //case "aes":
                this.security_passwordEncryptMethod = method;
                break;
            default:
                throw new IllegalArgumentException("AppConfig.security.passwordEncryptMethod 参数不准确！");
        }
    }


    @Value("${fixJDK8visitSslV2:false}")
    public boolean fixJDK8visitSslV2 = false;


    @Value("${security.disableCors:false}")
    public boolean security_disableCors;

    @Value("${security.corsAllowOrigins:*}")
    public String security_corsAllowOrigins;


    @Value("${app.usethirdright: false }")
    public boolean app_usethirdright;


}
