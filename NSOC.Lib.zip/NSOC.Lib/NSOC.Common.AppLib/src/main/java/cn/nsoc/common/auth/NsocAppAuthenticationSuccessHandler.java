package cn.nsoc.common.auth;

import cn.nsoc.common.util.Misc;
import org.springframework.security.core.Authentication;
import org.springframework.security.web.authentication.AuthenticationSuccessHandler;
import org.springframework.util.Base64Utils;
import org.springframework.util.StringUtils;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

/**
 * Created by sam on 16-10-8.
 */
public class NsocAppAuthenticationSuccessHandler implements AuthenticationSuccessHandler {
    private String retUrlParameter = "ReturnUrl";

    @Override
    public void onAuthenticationSuccess(HttpServletRequest request, HttpServletResponse response, Authentication authentication) throws IOException, ServletException {
        try {
            String returnUrl = request.getParameter(retUrlParameter);
            response.sendRedirect(StringUtils.hasText(returnUrl) ?
                    new String(Base64Utils.decodeFromUrlSafeString(returnUrl))
                    : request.getContextPath());
        } catch (IOException e) {
            Misc.ignoreException(e);
        }
    }
}
