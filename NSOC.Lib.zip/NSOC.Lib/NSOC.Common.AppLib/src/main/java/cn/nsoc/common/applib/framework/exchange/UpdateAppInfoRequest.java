package cn.nsoc.common.applib.framework.exchange;

import java.util.UUID;

/**
 * Created by sam on 16-7-19.
 */
public class UpdateAppInfoRequest {
    private String Username;

    private String Password;

    private boolean UpdateLicense;

    private boolean SynKey;

    private boolean ChangeKey;

    private String Lic;

    private UUID AppID;

    private String AppUrl;

    private String AppShortName;

    private String AppName;

    public String getUsername() {
        return Username;
    }

    public void setUsername(String username) {
        Username = username;
    }

    public String getPassword() {
        return Password;
    }

    public void setPassword(String password) {
        Password = password;
    }

    public boolean isUpdateLicense() {
        return UpdateLicense;
    }

    public void setUpdateLicense(boolean updateLicense) {
        UpdateLicense = updateLicense;
    }

    public boolean isSynKey() {
        return SynKey;
    }

    public void setSynKey(boolean synKey) {
        SynKey = synKey;
    }

    public boolean isChangeKey() {
        return ChangeKey;
    }

    public void setChangeKey(boolean changeKey) {
        ChangeKey = changeKey;
    }

    public String getLic() {
        return Lic;
    }

    public void setLic(String lic) {
        Lic = lic;
    }

    public UUID getAppID() {
        return AppID;
    }

    public void setAppID(UUID appID) {
        AppID = appID;
    }

    public String getAppUrl() {
        return AppUrl;
    }

    public void setAppUrl(String appUrl) {
        AppUrl = appUrl;
    }

    public String getAppShortName() {
        return AppShortName;
    }

    public void setAppShortName(String appShortName) {
        AppShortName = appShortName;
    }

    public String getAppName() {
        return AppName;
    }

    public void setAppName(String appName) {
        AppName = appName;
    }
}