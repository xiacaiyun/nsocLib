package cn.nsoc.common.applib.controls;

import java.util.List;

/**
 * Created by bobwang on 9/28/16.
 */
@Deprecated
public class PagedResult<T> {
    public List<T> Vals;
    public Long TotalCount;

    public PagedResult(List<T> vals, long totalCount) {
        this.Vals = vals;
        this.TotalCount = totalCount;
    }

}

