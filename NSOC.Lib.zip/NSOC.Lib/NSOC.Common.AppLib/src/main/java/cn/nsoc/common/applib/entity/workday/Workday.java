package cn.nsoc.common.applib.entity.workday;

import cn.nsoc.common.storer.annotation.DbField;

import java.time.LocalDateTime;

public class Workday {
    @DbField(isKey = true)
    private int WorkDayID;
    private int CreateBy;
    private LocalDateTime CreateDate;
    private String Name;
    private String MonTime;
    private String TuesTime;
    private String WedTime;
    private String ThurTime;
    private String FriTime;
    private String SatTime;
    private String SunTime;
    private String AppID;
    private int IsPublic;

    public int getWorkDayID() {
        return WorkDayID;
    }

    public void setWorkDayID(int WorkDayID) {
        this.WorkDayID = WorkDayID;
    }

    public int getCreateBy() {
        return CreateBy;
    }

    public void setCreateBy(int CreateBy) {
        this.CreateBy = CreateBy;
    }

    public LocalDateTime getCreateDate() {
        return CreateDate;
    }

    public void setCreateDate(LocalDateTime CreateDate) {
        this.CreateDate = CreateDate;
    }

    public String getName() {
        return Name;
    }

    public void setName(String Name) {
        this.Name = Name;
    }

    public String getMonTime() {
        return MonTime;
    }

    public void setMonTime(String MonTime) {
        this.MonTime = MonTime;
    }

    public String getTuesTime() {
        return TuesTime;
    }

    public void setTuesTime(String TuesTime) {
        this.TuesTime = TuesTime;
    }

    public String getWedTime() {
        return WedTime;
    }

    public void setWedTime(String WedTime) {
        this.WedTime = WedTime;
    }

    public String getThurTime() {
        return ThurTime;
    }

    public void setThurTime(String ThurTime) {
        this.ThurTime = ThurTime;
    }

    public String getFriTime() {
        return FriTime;
    }

    public void setFriTime(String FriTime) {
        this.FriTime = FriTime;
    }

    public String getSatTime() {
        return SatTime;
    }

    public void setSatTime(String SatTime) {
        this.SatTime = SatTime;
    }

    public String getSunTime() {
        return SunTime;
    }

    public void setSunTime(String SunTime) {
        this.SunTime = SunTime;
    }

    public String getAppID() {
        return AppID;
    }

    public void setAppID(String AppID) {
        this.AppID = AppID;
    }

    public int getIsPublic() {
        return IsPublic;
    }

    public void setIsPublic(int IsPublic) {
        this.IsPublic = IsPublic;
    }

}

