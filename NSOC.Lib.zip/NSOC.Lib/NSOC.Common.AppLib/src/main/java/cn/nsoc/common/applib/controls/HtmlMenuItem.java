package cn.nsoc.common.applib.controls;

/**
 * Created by xiacaiyun on 2016/12/8.
 */
@Deprecated
public class HtmlMenuItem {
    public HtmlMenuItem() {

    }

    public String Name;
    public MenuItemType Type;
    public String Url;


    public enum MenuItemType {
        Item(0),
        Separator(1);
        private final int val;

        MenuItemType(int val) {
            this.val = val;
        }

        public int getVal() {
            return val;
        }


    }
}
