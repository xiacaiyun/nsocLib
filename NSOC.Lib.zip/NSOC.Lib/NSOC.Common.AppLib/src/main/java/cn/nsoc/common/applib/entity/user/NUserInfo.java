package cn.nsoc.common.applib.entity.user;

import cn.nsoc.common.applib.rights.RightsContext;

/**
 * Created by sam on 16-6-6.
 */
public class NUserInfo {
    public String Email;

    public String FullName;

    public int ID;

    public String Mobile;

    public String PKID;

    public String UserName;

    public RightsContext rights;
}

