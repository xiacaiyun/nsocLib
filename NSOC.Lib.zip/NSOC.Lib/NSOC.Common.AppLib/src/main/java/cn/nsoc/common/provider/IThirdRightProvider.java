package cn.nsoc.common.provider;

/**
 * Created by sam on 17-5-2.
 */
public interface IThirdRightProvider {
    Object parse(Object data);
}
