package cn.nsoc.common.applib.controller;

import cn.nsoc.base.entity.sys.NSException;
import cn.nsoc.common.util.ExportHelper;
import org.springframework.util.StringUtils;

import javax.servlet.http.HttpServletResponse;
import java.io.PrintWriter;

/**
 * Created by xiacaiyun on 2016/12/9.
 */
public class NController {
    public static final String xlsext = ".xls";

    public static void exportToExcel(HttpServletResponse response, String txtExcel, String fileName) throws NSException {
        try {
            String tempfilename;
            if (StringUtils.hasText(fileName) && !fileName.endsWith(xlsext))
                tempfilename = fileName + xlsext;
            else
                tempfilename = fileName;
            response.setContentType(ExportHelper.MIME_EXCEL);
            response.setHeader("Content-Disposition", "attachment; filename=\"" + new String((tempfilename).getBytes("UTF-8"), "ISO8859-1") + "\"");
            response.setCharacterEncoding("utf-8");
            PrintWriter out = response.getWriter();
            out.write('\ufeff');
            out.write(txtExcel);
            out.close();
        } catch (Exception ex) {
            throw new NSException(ex);
        }
    }

    public static void exportToCsv(HttpServletResponse response, String txtExcel, String fileName) throws NSException {
        try {
            String tempfilename;
            if (StringUtils.hasText(fileName) && !fileName.endsWith(".csv"))
                tempfilename = fileName + ".csv";
            else
                tempfilename = fileName;
            response.setContentType(ExportHelper.MIME_EXCEL);
            response.setHeader("Content-Disposition", "attachment; filename=\"" + new String((tempfilename).getBytes("UTF-8"), "ISO8859-1") + "\"");
            response.setCharacterEncoding("utf-8");
            PrintWriter out = response.getWriter();
            out.write('\ufeff'); //因excel默认gb2312格式不认utf-8，﻿﻿﻿\ufeff是unicode的两个字节帮助认出csv的utf-8
            out.write(txtExcel);
            out.close();
        } catch (Exception ex) {
            throw new NSException(ex);
        }
    }
}
