package cn.nsoc.common.applib.controls;

/**
 * Created by bobwang on 9/28/16.
 */
@Deprecated
public class PairResult<T, Y> {
    public T memKey;
    public Y memVal;

    public PairResult(T key, Y val) {
        memKey = key;
        memVal = val;
    }
}
