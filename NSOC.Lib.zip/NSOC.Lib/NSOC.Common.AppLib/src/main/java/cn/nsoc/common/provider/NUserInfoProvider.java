package cn.nsoc.common.provider;

import cn.nsoc.base.entity.sys.NSException;
import cn.nsoc.common.applib.entity.user.NUserInfo;
import cn.nsoc.common.applib.entity.user.NUserInfoCollection;
import cn.nsoc.common.storer.biz.PageContext;
import cn.nsoc.common.util.NApiProxy;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by xiacaiyun on 2016/12/15.
 */
public class NUserInfoProvider {
    public static final String url_list = "/napi/internal/user/list?userName=%s&roleID=%s&userIds=%s&pageId=%s&countPerPage=%s";

    private NApiProxy nApiProxy;

    public NUserInfoProvider() {
        nApiProxy = NApiProxy.getInstance();
    }

    public NUserInfoProvider(NApiProxy nApiProxy) {
        this.nApiProxy = nApiProxy;
    }

    public NUserInfoCollection ListUser(String userName, Integer roleID, String userIds, Integer pageId, Integer countperpage) throws NSException {
        List<NUserInfo> objlist = new ArrayList<>();
        PageContext pctx;
        String url = String.format(url_list,
                userName == null ? "" : userName,
                roleID == null ? "" : roleID,
                userIds == null ? "" : userIds,
                pageId == null ? "" : pageId,
                countperpage == null ? "" : countperpage);
        String html = nApiProxy.get(url);
        Object[] result = nApiProxy.parserPagerData(html, PageContext.class, NUserInfo[].class);
        NUserInfoCollection coll = new NUserInfoCollection();
        coll.getQuery().UserNameToMatch = userName;
        if (result != null) {
            if (result[0] != null) {
                for (Object o : ((List) result[0]).toArray()) {
                    NUserInfo tmp = (NUserInfo) o;
                    objlist.add(tmp);
                }
            }
            coll.addAll(objlist);
            if (result[1] != null) {
                pctx = ((PageContext) (result[1]));
                coll.getQuery().totalCount = pctx.getTotalCount();
            }
        }
        return coll;
    }


    public NUserInfo getUserByid(int userId) throws NSException {
        NUserInfoCollection infos = ListUser(null, null,String.valueOf(userId), 0, Integer.MAX_VALUE);
        return infos.firstOrDefault();
    }
}
