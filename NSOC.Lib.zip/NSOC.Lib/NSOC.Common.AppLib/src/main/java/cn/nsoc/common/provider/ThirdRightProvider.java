package cn.nsoc.common.provider;

import cn.nsoc.base.entity.sys.NSException;
import cn.nsoc.common.applib.membership.UserInfoProvider;
import cn.nsoc.common.applib.rights.ThirdRights;
import cn.nsoc.common.conveyor.cache.LazyCache;
import cn.nsoc.common.util.NApiProxy;

import java.util.function.Function;

/**
 * Created by sam on 17-5-2.
 */
public class ThirdRightProvider {

    static LazyCache cache = LazyCache.createCache(null);
    private Function<Object, Object> getThirdRights = userId -> {
        try {
            return new UserInfoProvider(NApiProxy.getInstance()).getThirdRights((Integer) userId);
        } catch (Exception ex) {
            return ex;
        }
    };

    public <T extends ThirdRights> T getUserAppRights(T thirdRights, IThirdRightProvider thirdRightProvider, int userId, boolean nocache) throws NSException {
        thirdRights.setRightProvider(thirdRightProvider);
        if (thirdRightProvider == null)
            return thirdRights;

        if (userId <= 0)
            return thirdRights;


        Object rights;
        if (nocache || (cache == null)) {
            Object val = getThirdRights.apply(userId);
            if (val instanceof Exception) {
                throw new NSException((Exception) val);
            } else {
                rights = val;
            }
        } else {
            rights = cache.getOrLoad(Integer.toString(userId), getThirdRights, userId);
        }

        thirdRights.setRights(rights);
        return thirdRights;
    }

    public <T extends ThirdRights> T getUserAppRights(T thirdRights, IThirdRightProvider thirdRightProvider, int userId) throws NSException {
        return getUserAppRights(thirdRights, thirdRightProvider, userId, false);
    }
}
