package cn.nsoc.common.auth;

import cn.nsoc.common.applib.controls.JsonRet;
import cn.nsoc.common.applib.error.ErrorType;
import cn.nsoc.common.util.Misc;
import org.apache.log4j.Logger;
import org.springframework.http.HttpStatus;
import org.springframework.security.core.AuthenticationException;
import org.springframework.security.web.authentication.LoginUrlAuthenticationEntryPoint;
import org.springframework.security.web.util.RedirectUrlBuilder;
import org.springframework.util.Assert;
import org.springframework.util.Base64Utils;
import org.springframework.util.StringUtils;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.UUID;

/**
 * Created by sam on 16-10-8.
 */
public class NsocAppLoginUrlAuthenticationEntryPoint extends LoginUrlAuthenticationEntryPoint {

    private static final Logger logger = Logger.getLogger(NsocAppLoginUrlAuthenticationEntryPoint.class);

    private String appLoginUrl;
    private UUID appId;

    public NsocAppLoginUrlAuthenticationEntryPoint(String loginFormUrl, String appLoginUrl, UUID appId) {
        super(loginFormUrl);
        Assert.hasText(appLoginUrl);
        Assert.notNull(appId);

        this.appLoginUrl = appLoginUrl;
        this.appId = appId;
    }

    @Override
    public void commence(HttpServletRequest request, HttpServletResponse response, AuthenticationException authException) throws IOException, ServletException {

        String accept = request.getHeader("Accept");
        if(StringUtils.hasText(accept) && accept.contains("application/json")) {
            response.setContentType("application/json");
            response.setCharacterEncoding("utf-8");
            response.setStatus(HttpStatus.UNAUTHORIZED.value());
            PrintWriter out = response.getWriter();
            out.write(Misc.toJson(new JsonRet(false, ErrorType.needLogin.getText())));
            out.close();
        } else {
            super.commence(request, response, authException);
        }
    }

    @Override
    protected String buildRedirectUrlToLoginPage(HttpServletRequest request, HttpServletResponse response, AuthenticationException authException) {

        int serverPort = request.getServerPort();
        String scheme = request.getScheme();
        RedirectUrlBuilder urlBuilder = new RedirectUrlBuilder();
        urlBuilder.setScheme(scheme);
        urlBuilder.setServerName(request.getServerName());
        urlBuilder.setPort(serverPort);
        urlBuilder.setContextPath(request.getContextPath());
        urlBuilder.setPathInfo(this.getLoginFormUrl());

        StringBuffer sbUrl = request.getRequestURL();
        if (StringUtils.hasText(request.getQueryString())) {
            sbUrl.append("?").append(request.getQueryString());
        }

        urlBuilder.setQuery("ReturnUrl=" + Base64Utils.encodeToUrlSafeString(sbUrl.toString().getBytes()));

        if (isForceHttps() && "http".equals(scheme)) {
            Integer httpsPort = getPortMapper().lookupHttpsPort(serverPort);
            if (httpsPort != null) {
                urlBuilder.setScheme("https");
                urlBuilder.setPort(httpsPort);
            } else {
                logger.warn("Unable to redirect to HTTPS as no port mapping found for HTTP port " + serverPort);
            }
        }

        return String.format("%s?AppID=%s&AppUrl=%s",
                this.appLoginUrl,
                Misc.toStdString(this.appId),
                Base64Utils.encodeToUrlSafeString(urlBuilder.getUrl().getBytes()));
    }
}
