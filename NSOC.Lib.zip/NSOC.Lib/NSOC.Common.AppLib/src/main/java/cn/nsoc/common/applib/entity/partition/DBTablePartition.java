package cn.nsoc.common.applib.entity.partition;

/**
 * Created by jz on 2017/4/11.
 */

import cn.nsoc.common.storer.annotation.DbField;
import cn.nsoc.common.storer.annotation.DbTable;
import cn.nsoc.common.util.Misc;

@DbTable(
        name = "information_schema.partitions"
)
public class DBTablePartition {
    private String Scheme;
    private String TableName;
    private String PartitionName;
    private Integer OrderPos;
    private Integer Rows;
    private Long DataLength;
    private Long IndexLength;
    private String PartitionDescription;
    private String DataSpace;
    private String IndexSpace;
    private String TotalSpace;
    @DbField(
            isRequired = false
    )
    private String value1;
    @DbField(
            isRequired = false
    )
    private String value2;
    @DbField(
            isRequired = false
    )
    private String partitionName2;

    @DbField(
            isRequired = false
    )
    private String partitionName1;

    public String getScheme() {
        return this.Scheme;
    }

    public void setScheme(String scheme) {
        this.Scheme = scheme;
    }

    public String getTableName() {
        return this.TableName;
    }

    public void setTableName(String tableName) {
        this.TableName = tableName;
    }

    public String getPartitionName() {
        return this.PartitionName;
    }

    public void setPartitionName(String partitionName) {
        this.PartitionName = partitionName;
    }

    public Integer getOrderPos() {
        return this.OrderPos;
    }

    public void setOrderPos(Integer orderPos) {
        this.OrderPos = orderPos;
    }

    public Integer getRows() {
        return this.Rows;
    }

    public void setRows(Integer rows) {
        this.Rows = rows;
    }

    public Long getDataLength() {
        return this.DataLength;
    }

    public void setDataLength(Long dataLength) {
        this.DataLength = dataLength;
    }

    public Long getIndexLength() {
        return this.IndexLength;
    }

    public void setIndexLength(Long indexLength) {
        this.IndexLength = indexLength;
    }

    public String getPartitionDescription() {
        return this.PartitionDescription;
    }

    public void setPartitionDescription(String partitionDescription) {
        this.PartitionDescription = partitionDescription;
    }

    public String getDataSpace() {
        return Misc.convertByteString(this.DataLength);
    }

    public void setDataSpace(String dataSpace) {
        this.DataSpace = dataSpace;
    }

    public String getIndexSpace() {
        return Misc.convertByteString(this.IndexLength);
    }

    public void setIndexSpace(String indexSpace) {
        this.IndexSpace = indexSpace;
    }

    public String getTotalSpace() {
        return Misc.convertByteString(this.IndexLength + this.DataLength);
    }

    public void setTotalSpace(String totalSpace) {
        this.TotalSpace = totalSpace;
    }

    public String getValue1() {
        return this.value1;
    }

    public void setValue1(String value1) {
        this.value1 = value1;
    }

    public String getValue2() {
        return this.value2;
    }

    public void setValue2(String value2) {
        this.value2 = value2;
    }

    public String getPartitionName2() {
        return this.partitionName2;
    }

    public void setPartitionName2(String partitionName2) {
        this.partitionName2 = partitionName2;
    }

    public String getPartitionName1() {
        return partitionName1;
    }

    public void setPartitionName1(String partitionName1) {
        this.partitionName1 = partitionName1;
    }
}

