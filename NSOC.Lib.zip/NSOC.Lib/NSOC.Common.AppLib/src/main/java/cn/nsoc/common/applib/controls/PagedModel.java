package cn.nsoc.common.applib.controls;

/**
 * Created by sam on 17-2-7.
 * 分页Model,用于分页的List
 */
//move to storer
@Deprecated
public class PagedModel implements IPager {

    private Integer pageId;

    private Integer countPerPage;

    @Override
    public Integer getPageId() {
        return pageId;
    }

    @Override
    public void setPageId(Integer pageId) {
        this.pageId = pageId;
    }

    @Override
    public Integer getCountPerPage() {
        return countPerPage;
    }

    @Override
    public void setCountPerPage(Integer countPerPage) {
        this.countPerPage = countPerPage;
    }
}
