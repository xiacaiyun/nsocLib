package cn.nsoc.common.auth;

import cn.nsoc.common.applib.rights.RightsContext;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.User;
import org.springframework.util.StringUtils;

import java.util.Collection;

/**
 * Created by sam on 16-10-8.
 */
public class NsocUser extends User {

    private String displayName;
    private int userId;
    private transient RightsContext rights;


    public NsocUser(String username, String displayName, int userId, Collection<? extends GrantedAuthority> authorities) {
        super(username, "", authorities);
        this.setDisplayName(displayName);
        this.setUserId(userId);
    }

    public String getDisplayName() {
        return StringUtils.hasText(this.displayName) ? displayName : this.getUsername();
    }

    public void setDisplayName(String displayName) {
        this.displayName = displayName;
    }

    public static NsocUser getCurrentUser() {

        Authentication auth = SecurityContextHolder.getContext().getAuthentication();
        if (auth instanceof NsocAuthenticationToken) {
            NsocAuthenticationToken token = (NsocAuthenticationToken) auth;
            return token.getUser();
        } else
            return null;
    }

    public RightsContext getRights() {
        return rights;
    }

    public void setRights(RightsContext rights) {
        this.rights = rights;
    }

    public int getUserId() {
        return userId;
    }

    private void setUserId(int userId) {
        this.userId = userId;
    }
}
