package cn.nsoc.common.applib.framework.exchange;

/**
 * Created by sam on 16-6-4.
 */
public class BaseResult {

    private boolean Ret;

    private String Message;

    public boolean isRet() {
        return Ret;
    }

    public void setRet(boolean ret) {
        Ret = ret;
    }

    public String getMessage() {
        return Message;
    }

    public void setMessage(String message) {
        Message = message;
    }
}
