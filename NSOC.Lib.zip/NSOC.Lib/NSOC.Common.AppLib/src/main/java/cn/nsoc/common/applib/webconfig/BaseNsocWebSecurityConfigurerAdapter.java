package cn.nsoc.common.applib.webconfig;

import cn.nsoc.base.entity.sys.NSException;
import cn.nsoc.common.applib.entity.config.AppRuntimeConfig;
import cn.nsoc.common.auth.*;
import cn.nsoc.common.provider.UserRightsProvider;
import cn.nsoc.common.storer.db.JdbcDbStorer;
import cn.nsoc.common.util.Misc;
import cn.nsoc.common.util.NApiProxy;
import org.apache.log4j.Logger;
import org.springframework.context.annotation.Bean;
import org.springframework.http.HttpMethod;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.builders.WebSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;
import org.springframework.security.config.http.SessionCreationPolicy;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.web.authentication.UsernamePasswordAuthenticationFilter;
import org.springframework.util.StringUtils;

import java.util.UUID;
import java.util.function.Supplier;

/**
 * Created by sam on 16-10-8.
 */
public abstract class BaseNsocWebSecurityConfigurerAdapter extends WebSecurityConfigurerAdapter {

    private static final Logger logger = Logger.getLogger(BaseNsocWebSecurityConfigurerAdapter.class);

    private static final String LOGIN_PAGE = "/account/ssologin";
    private static final String LOGOUT_PAGE = "/account/logout";
    private static final String SET_LICENSE_URL = "/license";
    private static final String ERROR_URL = "/error";

    protected abstract UUID getAppId();

    protected abstract BaseAppConfig getAppConfig();

    protected abstract String getFrameworkRoot();

    public abstract boolean checkLicense() throws NSException;

    protected void addAppfilters(HttpSecurity http) {
        http.addFilterBefore(new NsocLicenseProcessionFilter(SET_LICENSE_URL, this,
                new String[]{
                        ERROR_URL,
                        "/napi/public/setting/?etFramework"
                }), UsernamePasswordAuthenticationFilter.class);
    }


    @Bean
    public NsocAppAuthenticationProvider nsocAuthenticationProvider() {
        return new NsocAppAuthenticationProvider();
    }

    @Bean
    public UserDetailsService nsocUserService() {
        return new NsocAppUserService();
    }

    @Bean
    public UserRightsProvider userRightsProvider() {
        return new UserRightsProvider();
    }

    @Bean
    public NsocRememberMeServices rememberMeServices() {

        BaseAppConfig appConfig = getAppConfig();

        NsocRememberMeServices rmsvc = new NsocRememberMeServices(
                Misc.byteArrayToHexString(getAppConfig().getEncryptKey()),
                appConfig.getMachineKey(),
                nsocUserService());

        if (appConfig.getSecurity_sessionTimeout() > 0)
            rmsvc.setTokenValiditySeconds(appConfig.getSecurity_sessionTimeout());

        rmsvc.setCookieName(".NSOCAuth_J");
        rmsvc.setTicketCookieName(".NSOCAuth_Ticket");
        return rmsvc;
    }

    @Override
    public void configure(WebSecurity web) throws NSException {
        web.ignoring().antMatchers("/static/**");
    }

    @Override
    protected void configure(HttpSecurity http) throws NSException {
        initApp();
        NsocRememberMeServices rmsvc = rememberMeServices();

        addAppfilters(http);

        try {
            http.addFilterAt(getAuthenticationProcessingFilter(LOGIN_PAGE, rmsvc), UsernamePasswordAuthenticationFilter.class)
                    .sessionManagement().sessionCreationPolicy(SessionCreationPolicy.STATELESS).and()
                    .csrf().disable().headers().frameOptions().sameOrigin().and()
                    .authorizeRequests().antMatchers(
                    "/napi/internal/**",
                    "/napi/public/**",
                    "/account/**",
                    ERROR_URL,
                    SET_LICENSE_URL
            ).permitAll()
                    .antMatchers(HttpMethod.OPTIONS).permitAll()
                    .anyRequest().authenticated().and()
                    .formLogin().and()
                    .rememberMe().rememberMeServices(rmsvc).and()
                    .logout().logoutUrl(LOGOUT_PAGE)
                    .logoutSuccessHandler((request, response, auth) -> {
                        String redirectUrl = getFrameworkRoot() + "/account/logout";
                        response.sendRedirect(redirectUrl);
                    })
                    .and()
                    .exceptionHandling()
                    .authenticationEntryPoint(
                            new NsocAppLoginUrlAuthenticationEntryPoint(
                                    LOGIN_PAGE
                                    , getFrameworkRoot() + "/account/applogin"
                                    , this.getAppId()));
        } catch (Exception ex) {
            throw new NSException(ex);
        }

    }


    @Bean
    public NsocDataSource nsocDataSource(){
        BaseAppConfig appConfig = getAppConfig();

        if (!StringUtils.hasText(appConfig.nsoc_driverClassName)) {
            logger.error("nsoc.driverClassName is empty.");
            return null;
        }
        if (!StringUtils.hasText(appConfig.nsoc_url)){
            logger.error("nsoc.url is empty.");
            return null;
        }

        String dbpwd;
        try {

            dbpwd = appConfig.getEncryptValue(appConfig.nsoc_password);
        }
        catch (Exception ex){
            logger.error(String.format("error to decrypt datasource password. err: %s" ,ex));
            return null;
        }

        NsocDataSource ds = new NsocDataSource();
        ds.setDriverClassName(appConfig.nsoc_driverClassName);
        ds.setUrl(appConfig.nsoc_url);
        ds.setUsername(appConfig.nsoc_username);
        ds.setMaxTotal(appConfig.nsoc_maxtotal);
        ds.setMaxIdle(appConfig.nsoc_maxidle);
        ds.setMinIdle(appConfig.nsoc_minidle);
        ds.setMinEvictableIdleTimeMillis(appConfig.nsoc_minevictableidletimemillis);
        ds.setPassword(dbpwd);
        ds.setInitialSize(appConfig.nsoc_initialSize);

        logger.info("nsoc data source is created.");
        return ds;
    }

    @Bean
    public NsocDataSource nsocReadonlyDataSource(){
        BaseAppConfig appConfig = getAppConfig();

        if (!StringUtils.hasText(appConfig.nsocreadonly_url)){
            return null;
        }

        if (!StringUtils.hasText(appConfig.nsoc_driverClassName)) {
            logger.error("nsoc.driverClassName is empty.");
            return null;
        }

        String dbpwd;
        try {
            dbpwd = appConfig.getEncryptValue(appConfig.nsocreadonly_password);
        }
        catch (Exception ex){
            logger.error(String.format("error to decript datasource password. err: %s" ,ex));
            return null;
        }

        NsocDataSource ds = new NsocDataSource();
        ds.setDriverClassName(appConfig.nsoc_driverClassName);
        ds.setUrl(appConfig.nsocreadonly_url);
        ds.setUsername(appConfig.nsocreadonly_username);
        ds.setMaxTotal(appConfig.nsoc_maxtotal);
        ds.setMaxIdle(appConfig.nsoc_maxidle);
        ds.setMinIdle(appConfig.nsoc_minidle);
        ds.setMinEvictableIdleTimeMillis(appConfig.nsoc_minevictableidletimemillis);
        ds.setPassword(dbpwd);
        ds.setInitialSize(appConfig.nsoc_initialSize);

        logger.info("nsoc readonly data source is created.");
        return ds;
    }


    protected void initApp() throws NSException {

        NsocDataSource dsNsoc = nsocDataSource();
        NsocDataSource dsNsocReadonly = nsocReadonlyDataSource();
        JdbcDbStorer readonlyHandler = null;
        if (dsNsocReadonly != null) {
            readonlyHandler = JdbcDbStorer.createJdbcDbStorer("mysql", dsNsocReadonly);
        }
        JdbcDbStorer.setDefaultHandler(JdbcDbStorer.createJdbcDbStorer("mysql", dsNsoc), readonlyHandler);

        Supplier<String> rsakeySupplier = () -> {
            try {
                return AppRuntimeConfig.Current().getRSAKey();
            } catch (Exception ex) {
                Misc.ignoreException(ex);
                return null;
            }
        };
        NApiProxy.setInstance(new NApiProxy(getFrameworkRoot(),
                rsakeySupplier,
                this.getAppId()));
    }

    protected NsocAppSsoAuthenticationFilter getAuthenticationProcessingFilter(String loginPage, NsocRememberMeServices rmsvc) throws NSException {
        try {
            NsocAppSsoAuthenticationFilter ssofilter = new NsocAppSsoAuthenticationFilter(loginPage, this.getAppId());
            ssofilter.setAuthenticationManager(this.authenticationManager());
            ssofilter.setRememberMeServices(rmsvc);
            ssofilter.setAuthenticationSuccessHandler(new NsocAppAuthenticationSuccessHandler());
            return ssofilter;
        } catch (Exception ex) {
            throw new NSException(ex);
        }
    }
}