package cn.nsoc.common.applib.rights;

import cn.nsoc.base.entity.sys.NSException;

/**
 * Created by bobwang on 9/12/16.
 */
public class RightsContext {

    public static class RightsItem {
        private Integer AllowValue;
        private Integer DenyValue;

        public RightsItem() {
        }

        public RightsItem(int allowValue, int denyValue) {
            setAllowValue(allowValue);
            setDenyValue(denyValue);
        }

        public Integer getAllowValue() {
            return AllowValue;
        }

        public void setAllowValue(Integer allowValue) {
            AllowValue = allowValue;
        }

        public Integer getDenyValue() {
            return DenyValue;
        }

        public void setDenyValue(Integer denyValue) {
            DenyValue = denyValue;
        }
    }

    public RightsItem userRights = new RightsItem();
    public RightsItem rolesRights = new RightsItem();

    public void setUserRights(int allowValue, int denyValue) {
        userRights.setAllowValue(allowValue);
        userRights.setDenyValue(denyValue);
    }

    public void setRoleRights(int allowValue, int denyValue) {
        if (rolesRights.getAllowValue() == null)
            rolesRights.setAllowValue(allowValue);
        else
            rolesRights.setAllowValue(rolesRights.getAllowValue() | allowValue);

        if (rolesRights.getDenyValue() == null)
            rolesRights.setDenyValue(denyValue);
        else
            rolesRights.setDenyValue(rolesRights.getDenyValue() | denyValue);
    }


    public boolean checkRight(int val) throws NSException {
        Boolean temp = checkRight(val, userRights);
        if (temp != null) {
            return temp;
        }

        temp = checkRight(val, rolesRights);
        if (temp != null) {
            return temp;
        }
        return false;
    }

    private Boolean checkRight(int val, RightsItem rightsItem) throws NSException {
        if (val == 0)
            throw new NSException("值不能为 0 ！");

        if ((rightsItem.getDenyValue() != null) && ((rightsItem.getDenyValue() & val) != 0))
            return false;

        if ((rightsItem.getAllowValue() != null) && ((rightsItem.getAllowValue() & val) != 0))
            return true;

        return null;
    }
}
