package cn.nsoc.common.applib.controls;

import cn.nsoc.base.entity.define.NSExceptionCode;
import cn.nsoc.base.entity.sys.NSException;
import cn.nsoc.common.applib.biz.DBTableBiz;
import cn.nsoc.common.applib.entity.partition.DBTablePartition;
import cn.nsoc.common.applib.entity.partition.DBTablePartitionCollection;
import cn.nsoc.common.applib.entity.partition.DBTablePartitionQuery;
import cn.nsoc.common.applib.entity.sys.DBPartitionPeriod;
import cn.nsoc.common.storer.db.JdbcDbStorer;
import cn.nsoc.common.util.Misc;
import com.google.common.primitives.Longs;
import org.joda.time.Days;
import org.joda.time.LocalDate;
import org.joda.time.Months;
import org.joda.time.Years;
import org.joda.time.format.DateTimeFormat;
import org.springframework.util.StringUtils;

import java.time.LocalDateTime;
import java.util.*;
import java.util.stream.Collectors;

/**
 * Created by jz on 4/5/17.
 */
public class DBTableMaintainer {

    private DBTableBiz dbTableBiz;

    public DBTableMaintainer(JdbcDbStorer dbStorer) {

        dbTableBiz = new DBTableBiz(dbStorer);
    }

    @SuppressWarnings("unchecked")
    public DBTablePartitionCollection loadPartitionCollection(String scheme) throws NSException {

        DBTablePartitionQuery pQuery = new DBTablePartitionQuery();
        try {
            List schemes = new ArrayList<String>();
            schemes.add(scheme);
            pQuery.setTABLE_SCHEMAIDList(schemes);
            return dbTableBiz.loadPartition(new DBTablePartitionCollection(pQuery));
        } catch (Exception e) {
            throw new NSException(NSExceptionCode.Analyzer_Siems_UnDefine, e);
        }
    }

    public boolean checkTable(LocalDate today, String tblname, String scheme, DBPartitionPeriod period, int units, DBTablePartitionCollection pcoll) throws NSException {
        LocalDate nextTimeStamp1 = calcNextTimestamp(today, period);
        LocalDate nextTimeStamp2 = calcNextTimestamp(nextTimeStamp1, period);

        //如有不规范的分区,先删除，等下一次循环再走下面逻辑
        boolean error = false;
        List<DBTablePartition> nextparts = new ArrayList<>();

        List<DBTablePartition> partitions = pcoll.
                stream().
                filter(p -> p.getTableName().equals(tblname) && p.getScheme().equals(scheme)).collect(Collectors.toList());
        partitions.sort(Comparator.comparing(DBTablePartition::getOrderPos));

        for (DBTablePartition partition : partitions) {

            if (StringUtils.isEmpty(partition.getPartitionDescription())) {
                continue;
            }
            Long timestamp = getnTimestamp(partition);

            if (timestamp.compareTo(Long.MAX_VALUE) == 0) {
                dbTableBiz.delete(partition);
                error = true;
            } else {

                Date date = new Date(timestamp);
                Calendar time = Calendar.getInstance();
                time.setTime(date);

                LocalDate localDate = LocalDate.fromCalendarFields(time);

                if (isPartitionExpired(localDate, today, period, units)) {
                    dbTableBiz.delete(partition); //如有过期的分区，删除
                }

                if (localDate.compareTo(nextTimeStamp1) >= 0) {
                    if (nextparts.size() >= 2) {
                        dbTableBiz.delete(partition);
                    } else {
                        nextparts.add(partition);
                    }
                }
            }
        }

        if (error || partitions.isEmpty()) {
            return false;
        }

        if (nextparts.isEmpty()) {
            //没有当前和下一个分区，则创建
            DBTablePartition partitionOne = new DBTablePartition();
            partitionOne.setTableName(tblname);
            partitionOne.setScheme(scheme);
            partitionOne.setValue1(String.valueOf(nextTimeStamp1.toDateTimeAtStartOfDay().getMillis() / 1000));
            partitionOne.setPartitionName(makeUniquepartitionName(nextTimeStamp1, partitions));
            dbTableBiz.insert(partitionOne);

            DBTablePartition partitionTwo = new DBTablePartition();
            partitionTwo.setTableName(tblname);
            partitionTwo.setScheme(scheme);
            partitionTwo.setValue1(String.valueOf(nextTimeStamp2.toDateTimeAtStartOfDay().getMillis() / 1000));
            partitionTwo.setPartitionName(makeUniquepartitionName(nextTimeStamp2, partitions));
            dbTableBiz.insert(partitionTwo);


        } else if (nextparts.size() == 1) {
            Long aLong = getnTimestamp(nextparts.get(0));

            Date aDate = new Date(aLong);
            Calendar aTime = Calendar.getInstance();
            aTime.setTime(aDate);
            LocalDate aLocalDate = LocalDate.fromCalendarFields(aTime);

            if (aLocalDate.compareTo(nextTimeStamp1) == 0) {
                DBTablePartition partitionTwo = new DBTablePartition();
                partitionTwo.setTableName(tblname);
                partitionTwo.setScheme(scheme);
                partitionTwo.setValue1(String.valueOf(nextTimeStamp2.toDateTimeAtStartOfDay().getMillis() / 1000));
                partitionTwo.setPartitionName(makeUniquepartitionName(nextTimeStamp2, partitions));
                dbTableBiz.insert(partitionTwo);
            } else {
                DBTablePartition partitionTwo = new DBTablePartition();
                Misc.objectCopy(nextparts.get(0), partitionTwo);
                partitionTwo.setScheme(scheme);
                partitionTwo.setValue1(String.valueOf(nextTimeStamp1.toDateTimeAtStartOfDay().getMillis() / 1000));
                partitionTwo.setValue2(String.valueOf(nextTimeStamp2.toDateTimeAtStartOfDay().getMillis() / 1000));

                partitionTwo.setPartitionName1(makeUniquepartitionName(nextTimeStamp1, partitions));
                partitionTwo.setPartitionName2(makeUniquepartitionName(nextTimeStamp2, partitions));
                dbTableBiz.update(partitionTwo);
            }

        } else {
            DBTablePartition p1 = nextparts.get(0);
            DBTablePartition p2 = nextparts.get(1);

            Long aLong = getnTimestamp(p1);
            Long bLong = getnTimestamp(p2);

            Date aDate = new Date(aLong);
            Date bDate = new Date(bLong);

            Calendar aTime = Calendar.getInstance();
            aTime.setTime(aDate);
            LocalDate dt1 = LocalDate.fromCalendarFields(aTime);
            aTime.setTime(bDate);
            LocalDate dt2 = LocalDate.fromCalendarFields(aTime);

            if (dt1.compareTo(nextTimeStamp1) != 0 || dt2.compareTo(nextTimeStamp2) != 0) {
                dbTableBiz.delete(p2);

                DBTablePartition partitionTwo = new DBTablePartition();
                Misc.objectCopy(p1, partitionTwo);
                partitionTwo.setValue1(String.valueOf(nextTimeStamp1.toDateTimeAtStartOfDay().getMillis() / 1000));
                partitionTwo.setScheme(scheme);
                partitionTwo.setValue2(String.valueOf(nextTimeStamp2.toDateTimeAtStartOfDay().getMillis() / 1000));
                partitionTwo.setPartitionName1(makeUniquepartitionName(nextTimeStamp1, partitions));
                partitionTwo.setPartitionName2(makeUniquepartitionName(nextTimeStamp2, partitions));
                dbTableBiz.update(partitionTwo);
            }

        }

        return true;
    }

    private String makeUniquepartitionName(LocalDate nextTime, List<DBTablePartition> partitions) {

        org.joda.time.format.DateTimeFormatter formatter = DateTimeFormat.forPattern("yyyyMMdd");

        String format = formatter.print(nextTime);
        String name = String.format("p%s", format);

        if (partitions.stream().anyMatch(p -> name.equals(p.getPartitionName()))) {
            return String.format("%s_%s", name, LocalDateTime.now().getSecond());
        } else {
            return name;
        }
    }

    private boolean isPartitionExpired(LocalDate dt, LocalDate target, DBPartitionPeriod period, int units) throws NSException {

        switch (period) {
            case Day:
                return Days.daysBetween(dt, target).getDays() > units;
            case Week:
                return Days.daysBetween(dt, target).getDays() > (units * 7 + target.getDayOfWeek());
            case Month:
                return Months.monthsBetween(dt, target).getMonths() > units;
            case Year:
                return Years.yearsBetween(dt, target).getYears() > units;
            default:
                throw new NSException(NSExceptionCode.Analyzer_Siems_UnDefine, "不可能");
        }
    }

    private Long getnTimestamp(DBTablePartition partition) {
        return "MAXVALUE".equals(partition.getPartitionDescription())
                ? Long.MAX_VALUE
                : Longs.tryParse(partition.getPartitionDescription()) * 1000;
    }

    public LocalDate calcNextTimestamp(LocalDate dt, DBPartitionPeriod period) throws NSException {
        int units = 1;
        switch (period) {
            case Day:
                return dt.plusDays(units);

            case Week:
                return dt.plusDays(units * 7 - dt.getDayOfWeek());

            case Month:
                return dt.minusDays(dt.getDayOfMonth() - 1).plusMonths(units);

            case Year:
                return dt.minusDays(dt.getDayOfYear() - 1).plusYears(1);
            default:
                throw new NSException(NSExceptionCode.Analyzer_Siems_UnDefine, "不可能");
        }
    }
}
