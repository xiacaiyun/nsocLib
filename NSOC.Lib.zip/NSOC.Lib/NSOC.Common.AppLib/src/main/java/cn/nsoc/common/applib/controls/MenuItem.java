package cn.nsoc.common.applib.controls;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by sam on 16-9-19.
 */
public class MenuItem {
    private String name;
    private String state;
    private List<MenuItem> submenu;

    public MenuItem() {
    }

    public MenuItem(String name, String state) {
        this.setName(name);
        this.setState(state);
    }

    public void addSubMenu(MenuItem mi) {
        if (getSubmenu() == null) {
            setSubmenu(new ArrayList<>());
        }
        getSubmenu().add(mi);
    }

    public void addSubMenu(String name, String state) {
        addSubMenu(new MenuItem(name, state));
    }

    public List<MenuItem> getSubmenu() {
        return submenu;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getState() {
        return state;
    }

    public void setState(String state) {
        this.state = state;
    }

    public void setSubmenu(List<MenuItem> submenu) {
        this.submenu = submenu;
    }
}
