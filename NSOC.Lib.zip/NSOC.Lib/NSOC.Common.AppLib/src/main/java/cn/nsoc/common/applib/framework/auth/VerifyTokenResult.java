package cn.nsoc.common.applib.framework.auth;

import cn.nsoc.common.applib.framework.exchange.BaseResult;

/**
 * Created by sam on 16-6-4.
 */
public class VerifyTokenResult extends BaseResult {
    private int UserID;

    public int getUserID() {
        return UserID;
    }

    public void setUserID(int userID) {
        UserID = userID;
    }
}
