package cn.nsoc.common.applib.framework.exchange;

import java.util.UUID;

/**
 * Created by sam on 16-7-18.
 */
public class AppExchangeInfo {
    private UUID AppID;
    private String AppUrl;
    private String Name;
    private String PublicKey;
    private String ShortName;

    public UUID getAppID() {
        return AppID;
    }

    public void setAppID(UUID appID) {
        AppID = appID;
    }

    public String getAppUrl() {
        return AppUrl;
    }

    public void setAppUrl(String appUrl) {
        AppUrl = appUrl;
    }

    public String getName() {
        return Name;
    }

    public void setName(String name) {
        Name = name;
    }

    public String getPublicKey() {
        return PublicKey;
    }

    public void setPublicKey(String publicKey) {
        PublicKey = publicKey;
    }

    public String getShortName() {
        return ShortName;
    }

    public void setShortName(String shortName) {
        ShortName = shortName;
    }
}
