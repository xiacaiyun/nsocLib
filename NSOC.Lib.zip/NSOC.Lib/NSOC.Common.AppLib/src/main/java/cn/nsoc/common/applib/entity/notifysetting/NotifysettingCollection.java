package cn.nsoc.common.applib.entity.notifysetting;

import cn.nsoc.common.storer.EntityCollection;

public class NotifysettingCollection extends EntityCollection<Notifysetting, NotifysettingQuery> {
    public NotifysettingCollection() {
        super(Notifysetting.class, NotifysettingQuery.class);
    }

    public NotifysettingCollection(NotifysettingQuery query) {
        this();
        this.setQuery(query);
    }

    public Notifysetting Find(int id) {
        return this.stream().filter(e -> e.getSettingID() == id).findFirst().orElse(null);
    }
}

