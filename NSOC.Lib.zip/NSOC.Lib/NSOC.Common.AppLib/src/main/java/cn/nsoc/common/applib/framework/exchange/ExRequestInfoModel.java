package cn.nsoc.common.applib.framework.exchange;

/**
 * Created by sam on 16-7-31.
 */
public class ExRequestInfoModel {
    //@NotBlank
    private String ExAction;

    //@NotBlank
    private String ExController;

    //@NotBlank
    private String ExApp;

    public String getExAction() {
        return ExAction;
    }

    public void setExAction(String exAction) {
        ExAction = exAction;
    }

    public String getExController() {
        return ExController;
    }

    public void setExController(String exController) {
        ExController = exController;
    }

    public String getExApp() {
        return ExApp;
    }

    public void setExApp(String exApp) {
        ExApp = exApp;
    }
}
