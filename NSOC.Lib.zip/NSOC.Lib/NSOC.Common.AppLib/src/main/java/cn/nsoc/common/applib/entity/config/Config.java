package cn.nsoc.common.applib.entity.config;

/**
 * Created by sam on 16-7-14.
 */
public interface Config {
}
