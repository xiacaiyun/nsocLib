package cn.nsoc.common.applib.controls;

/**
 * Created by sam on 17-2-7.
 */
//move to lib storer
@Deprecated
public interface IPager {
    Integer getPageId();

    void setPageId(Integer pageId);

    Integer getCountPerPage();

    void setCountPerPage(Integer countPerPage);
}
