//package cn.nsoc.common.compatibility;
//
//import cn.nsoc.base.entity.sys.NSException;
//import cn.nsoc.common.util.Misc;
//
//import java.lang.reflect.Field;
//import java.lang.reflect.Modifier;
//import java.security.Permission;
//import java.security.PermissionCollection;
//import java.util.Map;
//
///**
// * Created by sam on 17-3-3.
// */
//public class RemoveCryptographyRestrictions {
//
//    private static volatile RemoveCryptographyRestrictions INSTANCE = null;
//
//    public static synchronized void init() throws NSException {
//        if (INSTANCE == null) {
//            INSTANCE = new RemoveCryptographyRestrictions();
//        }
//    }
//
//    private RemoveCryptographyRestrictions() throws NSException {
//        Class<?> jceSecurity = getClazz("javax.crypto.JceSecurity");
//        Class<?> cryptoPermissions = getClazz("javax.crypto.CryptoPermissions");
//        Class<?> cryptoAllPermission = getClazz("javax.crypto.CryptoAllPermission");
//        if (jceSecurity == null || cryptoPermissions == null || cryptoAllPermission == null)
//            return;
//        setFinalStaticValue(jceSecurity, "isRestricted", false);
//        PermissionCollection defaultPolicy = getFieldValue(jceSecurity, "defaultPolicy", null, PermissionCollection.class);
//        Map<?, ?> map = getFieldValue(cryptoPermissions, "perms", defaultPolicy, Map.class);
//        map.clear();
//        Permission permission = getFieldValue(cryptoAllPermission, "INSTANCE", null, Permission.class);
//        defaultPolicy.add(permission);
//    }
//
//    private Class<?> getClazz(String className) {
//        Class<?> clazz = null;
//        try {
//            clazz = Class.forName(className);
//        } catch (Exception ignored) {
//            Misc.ignoreException(ignored);
//        }
//        return clazz;
//    }
//
//    private void setFinalStaticValue(Class<?> srcClazz, String fieldName, Object newValue) throws NSException {
//        try {
//            Field field = srcClazz.getDeclaredField(fieldName);
//            field.setAccessible(true);
//            Field modifiersField = Field.class.getDeclaredField("modifiers");
//            modifiersField.setAccessible(true);
//            modifiersField.setInt(field, field.getModifiers() & ~Modifier.FINAL);
//            field.set(null, newValue);
//        } catch (Exception ex) {
//            throw new NSException(ex);
//        }
//    }
//
//    private <T> T getFieldValue(Class<?> srcClazz, String fieldName, Object owner, Class<T> dstClazz) throws NSException {
//        try {
//            Field field = srcClazz.getDeclaredField(fieldName);
//            field.setAccessible(true);
//            return dstClazz.cast(field.get(owner));
//        } catch (Exception ex) {
//            throw new NSException(ex);
//        }
//    }
//}
