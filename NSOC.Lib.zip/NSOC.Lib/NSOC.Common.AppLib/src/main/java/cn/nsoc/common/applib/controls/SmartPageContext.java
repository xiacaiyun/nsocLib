package cn.nsoc.common.applib.controls;

import org.springframework.util.StringUtils;

import java.util.*;
import java.util.function.Predicate;

/**
 * Created by xiacaiyun on 2016/12/8.
 */

//move to lib storer
@Deprecated
public class SmartPageContext extends PageContext {

    public static final String SplitChar = ",";
    public static final String ItemSplitChar = "-";
    private Map<Integer, String> _pageRecIds;

    public SmartPageContext(Integer pageId, Integer countperpage, String pagerecids) {
        super(pageId, countperpage);
        ClearRecordID();
        if ((this.getCurPage() > 1) && StringUtils.hasText(pagerecids)) {
            for (String pItem : pagerecids.split(SplitChar)) {
                if (!StringUtils.hasText(pItem) || (!pItem.contains(ItemSplitChar)))
                    continue;
                String[] items = pItem.split(ItemSplitChar);
                Integer idx = Integer.valueOf(items[0]);
                String val = items[1].trim();
                if (idx != null && StringUtils.hasText(val)) {
                    _pageRecIds.put(idx, val);
                }
            }
        }

    }

    public static String get_pageRecIds(Map<Integer, String> _pageRecIds) {
        List<String> list = new ArrayList<>();
        for (Map.Entry<Integer, String> m : _pageRecIds.entrySet()) {
            String tmp = String.format("%s%s%s", m.getKey(), ItemSplitChar, m.getValue());
            list.add(tmp);
        }
        return String.join(SplitChar, list);
    }

    public static class SmartPageOffsetModel {
        String recId;
        int SmartPageOffset;

        public String getRecId() {
            return recId;
        }

        public void setRecId(String recId) {
            this.recId = recId;
        }

        public int getSmartPageOffset() {
            return SmartPageOffset;
        }

        public void setSmartPageOffset(int smartPageOffset) {
            SmartPageOffset = smartPageOffset;
        }
    }

    public SmartPageOffsetModel GetSmartPageOffset() {
        SmartPageOffsetModel model = new SmartPageOffsetModel();
        int curpage = getCurPage();
        // if not found kvp = {0,null}
        Predicate<Map.Entry<Integer, String>> Filter = p -> (p.getKey() < curpage) && StringUtils.hasText(p.getValue());
        Map.Entry<Integer, String> kvp = _pageRecIds.entrySet().stream().filter(Filter).
                sorted(Comparator.comparing(Map.Entry::getKey)).findFirst().orElse(null);
        if (kvp != null) {
            model.recId = kvp.getValue();
            model.SmartPageOffset = kvp.getKey();
        }
        return model;
    }

    public int ClearRecordID() {
        _pageRecIds = new HashMap<>();
        return 0;
    }

    public void SetRecordID(int pageId, String recId) {
        _pageRecIds.put(pageId, recId);
    }
//    public static void main(String[] args){
//         Map<Integer, String> _pageRecIds = new HashMap<>();
//        _pageRecIds.put(1,"one");
//        _pageRecIds.put(2,"two");
//        get_pageRecIds(_pageRecIds);
//
//    }

}
