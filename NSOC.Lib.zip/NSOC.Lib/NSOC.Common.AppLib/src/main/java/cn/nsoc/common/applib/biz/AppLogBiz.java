package cn.nsoc.common.applib.biz;

import cn.nsoc.common.applib.entity.CAppLog;
import cn.nsoc.common.storer.biz.BaseBiz;
import cn.nsoc.common.storer.db.JdbcDbStorer;
import cn.nsoc.common.util.Misc;

import java.time.LocalDateTime;

/**
 * Created by sam on 16-12-2.
 */
public class AppLogBiz extends BaseBiz {


    public boolean log(String name, String message) {
        CAppLog.Entity o = new CAppLog.Entity();
        o.setHappenTime(LocalDateTime.now());
        o.setLogName(name);
        o.setMessage(message);
        return insert(o);
    }

    public boolean insert(CAppLog.Entity me) {

        try {
            return JdbcDbStorer.getInstance().insert(me);
        } catch (Exception ex) {
            Misc.ignoreException(ex);
            return false;
        }
    }
}
