package cn.nsoc.common.applib.entity.appright;

/**
 * Created by sam on 16-8-10.
 */
public enum AppRightType {
    User(1, "用户"),
    Role(2, "角色");

    private final int value;
    private final String text;

    AppRightType(int v, String t) {
        this.value = v;
        this.text = t;
    }

    public int getValue() {
        return this.value;
    }

    public String getText() {
        return this.text;
    }

    public static AppRightType convert(int val) {
        switch (val) {
            case 1:
                return User;
            case 2:
                return Role;
            default:
                return null;
        }
    }

}
