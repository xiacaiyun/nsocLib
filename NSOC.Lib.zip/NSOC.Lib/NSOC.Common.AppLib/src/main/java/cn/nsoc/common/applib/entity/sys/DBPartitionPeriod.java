package cn.nsoc.common.applib.entity.sys;

/**
 * Created by xiacaiyun on 2016/12/9.
 */
public enum DBPartitionPeriod {
    Day(0, "日"),
    Week(1, "周"),
    Month(2, "月"),
    Year(3, "年");

    public int getVal() {
        return val;
    }

    public String getMsg() {
        return msg;
    }

    private final int val;

    private final String msg;

    DBPartitionPeriod(int val, String msg) {
        this.val = val;
        this.msg = msg;
    }
}
