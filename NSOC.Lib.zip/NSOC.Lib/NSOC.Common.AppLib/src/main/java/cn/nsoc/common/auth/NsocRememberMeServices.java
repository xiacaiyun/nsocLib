package cn.nsoc.common.auth;

import cn.nsoc.base.entity.sys.NSException;
import cn.nsoc.common.util.AESCryptServiceProvider;
import cn.nsoc.common.util.Misc;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.web.authentication.rememberme.InvalidCookieException;
import org.springframework.security.web.authentication.rememberme.TokenBasedRememberMeServices;
import org.springframework.util.Assert;
import org.springframework.util.ReflectionUtils;
import org.springframework.util.StringUtils;

import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;

/**
 * Created by sam on 16-10-8.
 */
public class NsocRememberMeServices extends TokenBasedRememberMeServices {

    private String cookieRootPath = "/";
    private Method setHttpOnlyMethod2;
    private byte[] machineKey;
    private String ticketCookieName = ".NSOCAuth_Ticket";
    private boolean useSessionExpired = false;


    public NsocRememberMeServices(String key, byte[] machineKey, UserDetailsService userDetailsService) {
        super(key, userDetailsService);

        Assert.notNull(machineKey);

        this.setHttpOnlyMethod2 = ReflectionUtils.findMethod(Cookie.class, "setHttpOnly", Boolean.TYPE);
        this.machineKey = machineKey;
    }


    @Override
    public void setTokenValiditySeconds(int tokenValiditySeconds) {
        if ((tokenValiditySeconds < 1209600) && (tokenValiditySeconds > 0)) {
            useSessionExpired = true;
            super.setTokenValiditySeconds(tokenValiditySeconds);
        } else {
            useSessionExpired = false;
            super.setTokenValiditySeconds(Math.max(1209600, tokenValiditySeconds));
        }
    }

    @Override
    protected UserDetails processAutoLoginCookie(String[] cookieTokens, HttpServletRequest request, HttpServletResponse response) {
        if (cookieTokens.length < 2) {
            throw new InvalidCookieException("Cookie token did not contain 2 tokens, but contained \'" + Arrays.asList(cookieTokens) + "\'");
        }

        try {
            String data = AESCryptServiceProvider.decrypt(cookieTokens[0], this.getKey(), this.machineKey);

            List<String> list = null;
            if (StringUtils.hasText(data)) {
                list = Misc.fromJsonToList(data, String[].class);
                if (list.size() < 4) {
                    list = null;
                }
            }
            if (list == null) {
                throw new NSException("cookie错误");
            }

            if (this.useSessionExpired) {
                String ticketStr = getTicket(request, list.get(1));
                Long tokenExpiryTime = null;
                if (StringUtils.hasText(ticketStr)) {
                    tokenExpiryTime = Long.parseLong(ticketStr);
                }
                if ((tokenExpiryTime == null) || (this.isTokenExpired(tokenExpiryTime))) {
                    throw new NSException("Cookie 已过期");
                }

                if (tokenExpiryTime < (System.currentTimeMillis() + 1000L * (this.getTokenValiditySeconds() - 1))) {
                    setTicket(response, list.get(1));
                }
            }

            int userId = Integer.parseInt(list.get(2));
            String username = list.get(3);
            String displayName = cookieTokens[1];

            Assert.hasText(username);
            Assert.isTrue(userId > 0);
            return new NsocUser(username, displayName, userId, new ArrayList<>());
        } catch (Exception ex) {
            Misc.ignoreException(ex);
            throw new InvalidCookieException(String.format("cookie错误:%s", ex.getMessage()));
        }

    }


    private void setTicket(HttpServletResponse response, String salt) {

        int maxAge = -1;
        long expiryTime = System.currentTimeMillis() + 1000L * (long) this.getTokenValiditySeconds();

        try {
            String str = AESCryptServiceProvider.encrypt(Long.toString(expiryTime),
                    Misc.getMD5(this.getKey() + salt), this.machineKey);

            String cookieValue = this.encodeCookie(new String[]{str});

            Cookie cookie = new Cookie(this.getTicketCookieName(), cookieValue);
            cookie.setMaxAge(maxAge);
            cookie.setPath(this.cookieRootPath);

            cookie.setVersion(1);

            if (this.setHttpOnlyMethod2 != null) {
                ReflectionUtils.invokeMethod(this.setHttpOnlyMethod2, cookie, Boolean.TRUE);
            } else if (this.logger.isDebugEnabled()) {
                this.logger.debug("Note: Cookie will not be marked as HttpOnly because you are not using Servlet 3.0 (Cookie#setHttpOnly(boolean) was not found).");
            }
            response.addCookie(cookie);
        } catch (Exception ex) {
            logger.error(ex.getMessage());
            Misc.ignoreException(ex);
        }
    }

    private String getTicket(HttpServletRequest request, String salt) {
        Cookie[] cookies = request.getCookies();

        if (!StringUtils.hasText(this.ticketCookieName) || (cookies == null) || (cookies.length == 0)) {
            return null;
        }


        for (Cookie cookie : cookies) {
            if (!this.ticketCookieName.equals(cookie.getName())) {
                continue;
            }

            String value = cookie.getValue();
            if (StringUtils.hasText(value)) {
                try {
                    String[] cookieValue = this.decodeCookie(value);
                    if (cookieValue.length > 0) {
                        String ticketStr = cookieValue[0];
                        return AESCryptServiceProvider.decrypt(ticketStr, Misc.getMD5(this.getKey() + salt), this.machineKey);
                    }
                } catch (Exception ex) {
                    Misc.ignoreException(ex);
                }
            }
        }

        return null;
    }

    @Override
    protected String makeTokenSignature(long tokenExpiryTime, String username, String userId) {

        List<String> list = new ArrayList<>();
        list.add(Misc.getMD5(this.getKey() + tokenExpiryTime + username + userId));
        list.add(Long.toString(tokenExpiryTime));
        list.add(userId);
        list.add(username);

        try {
            return AESCryptServiceProvider.encrypt(Misc.toJson(list), this.getKey(), this.machineKey);
        } catch (Exception e) {
            logger.error(e);
            return null;
        }
    }


    @Override
    public void onLoginSuccess(HttpServletRequest request, HttpServletResponse response, Authentication successfulAuthentication) {
        String username = this.retrieveUserName(successfulAuthentication);
        if (!StringUtils.hasLength(username)) {
            this.logger.debug("Unable to retrieve username");
        } else {


            NsocAuthenticationToken nsocToken = (NsocAuthenticationToken) successfulAuthentication;
            NsocUser userdetails = nsocToken.getUser();

            int tokenLifetime1 = this.calculateLoginLifetime(request, successfulAuthentication);
            long expiryTime = System.currentTimeMillis();
            expiryTime += 1000L * (long) tokenLifetime1;
            String signatureValue = this.makeTokenSignature(expiryTime, userdetails.getUsername(), Integer.toString(userdetails.getUserId()));
            this.setCookie(new String[]{signatureValue, userdetails.getDisplayName()}, -1, request, response);
            if (this.logger.isDebugEnabled()) {
                this.logger.debug("Added remember-me cookie for member \'" + username + "\', expiry: \'" + new Date(expiryTime) + "\'");
            }

            if (this.useSessionExpired) {
                setTicket(response, Long.toString(expiryTime));
            }
        }
    }

    @Override
    protected Authentication createSuccessfulAuthentication(HttpServletRequest request, UserDetails user) {

        NsocRememberMeAuthenticationToken token = new NsocRememberMeAuthenticationToken(this.getKey(), user.getUsername(), user.getAuthorities());
        token.setUser((NsocUser) user);
        token.setDetails(getAuthenticationDetailsSource().buildDetails(request));
        return token;
    }

    @Override
    protected boolean rememberMeRequested(HttpServletRequest request, String parameter) {
        return true;
    }

    @Override
    protected void setCookie(String[] tokens, int maxAge, HttpServletRequest request, HttpServletResponse response) {

        String cookieValue = this.encodeCookie(tokens);
        Cookie cookie = new Cookie(this.getCookieName(), cookieValue);
        cookie.setMaxAge(maxAge);
        cookie.setPath(this.cookieRootPath);

        if (maxAge < 1) {
            cookie.setVersion(1);
        }

        if (this.setHttpOnlyMethod2 != null) {
            ReflectionUtils.invokeMethod(this.setHttpOnlyMethod2, cookie, Boolean.TRUE);
        } else if (this.logger.isDebugEnabled()) {
            this.logger.debug("Note: Cookie will not be marked as HttpOnly because you are not using Servlet 3.0 (Cookie#setHttpOnly(boolean) was not found).");
        }

        response.addCookie(cookie);
    }


    @Override
    protected void cancelCookie(HttpServletRequest request, HttpServletResponse response) {
        this.logger.debug("Cancelling cookie");
        Cookie cookie = new Cookie(this.getCookieName(), null);
        cookie.setMaxAge(0);
        cookie.setPath(this.cookieRootPath);
        response.addCookie(cookie);

        if (this.useSessionExpired) {
            cancelTicket(response);
        }
    }


    private void cancelTicket(HttpServletResponse response) {
        Cookie cookie = new Cookie(this.getTicketCookieName(), null);
        cookie.setMaxAge(0);
        cookie.setPath(this.cookieRootPath);
        response.addCookie(cookie);
    }

    public String getTicketCookieName() {
        return ticketCookieName;
    }

    public void setTicketCookieName(String ticketCookieName) {
        this.ticketCookieName = ticketCookieName;
    }
}
