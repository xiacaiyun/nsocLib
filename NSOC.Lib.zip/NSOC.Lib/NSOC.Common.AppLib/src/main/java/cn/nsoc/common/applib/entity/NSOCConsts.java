package cn.nsoc.common.applib.entity;

import java.util.UUID;

/**
 * Created by sam on 16-8-4.
 */
public class NSOCConsts {
    public static final String AdminRoleName = "系统管理员";
    public static final String ScreenShortName = "Screen";
    public static final String AlertShortName = "Alert";
    public static final String AssetShortName = "Asset";
    public static final String BizMonShortName = "BizMon";
    public static final String MonitorShortName = "Monitor";
    public static final String CompanyName = "上海悦程信息技术有限公司";
    public static final String FrameworkName = "NSOC产品管理中心";
    public static final String FrameworkShortName = "管理中心";
    public static final String SolutionName = "NSOC大数据分析系统";
    public static final String UnknownAssetType = "未知设备";
    public static final String UrlNSOC = "http://www.nsoc.cn";
    public static final UUID AssetAppID = UUID.fromString("5199b764-9d1a-4322-abd6-86b1a450d82b");
    public static final UUID MonitorAppID = UUID.fromString("6C96F508-307B-4373-94DC-0B5E4A6F166E");
    //    public static final UUID ScreenAppID = UUID.fromString("8308a587-a106-41e4-a7d8-8c2ce819c2a8");
//    public static final UUID BizMonAppID = UUID.fromString("f66d0beb-23f6-4e0f-a574-fcbe0d4d008f");
    //临时用法，不安全
    public static final String ExQSNsocUserID = "nsoccuruserid";
    //临时用法，不安全
    public static final String ExQSNsocAppsetting = "nsocappsetting";
}
