
package cn.nsoc.common.provider;

import cn.nsoc.base.entity.sys.NSException;
import cn.nsoc.common.applib.entity.workday.Workday;
import cn.nsoc.common.applib.entity.workday.WorkdayCollection;
import cn.nsoc.common.storer.biz.PageContext;
import cn.nsoc.common.util.Misc;
import cn.nsoc.common.util.NApiProxy;
import com.google.gson.JsonObject;
import org.springframework.util.Assert;

import java.util.ArrayList;
import java.util.List;

@SuppressWarnings("unchecked")
public class WorkDayProvider {
    static final String URL_GET = "/napi/internal/setting/schedule/ApiGet/%d";
    static final String URL_UPDATE = "/napi/internal/setting/schedule/ApiUpdate";
    static final String URL_ERASE = "/napi/internal/setting/schedule/ApiErase/%d?creatorId=%d&creator=%s";
    static final String URL_LIST = "/napi/internal/setting/schedule/list?pageId=%d&countPerPage=%d";

    private NApiProxy nApiProxy;

    public WorkDayProvider(NApiProxy nApiProxy) {
        Assert.notNull(nApiProxy);
        this.nApiProxy = nApiProxy;
    }

    public WorkDayProvider() {
        nApiProxy = NApiProxy.getInstance();
    }

    public WorkDayProvider(String frameworkRoot, String pubAddress) {
        this.nApiProxy = new NApiProxy(frameworkRoot, null, null);
    }

    public static class WorkDayModel {
        private Integer id;
        private String Name;
        private String MonTime;
        private String TuesTime;
        private String WedTime;
        private String ThurTime;
        private String FriTime;
        private String SatTime;
        private String SunTime;

        public Integer getId() {
            return id;
        }

        public void setId(Integer id) {
            this.id = id;
        }

        public String getName() {
            return Name;
        }

        public void setName(String name) {
            Name = name;
        }

        public String getMonTime() {
            return MonTime;
        }

        public void setMonTime(String monTime) {
            MonTime = monTime;
        }

        public String getTuesTime() {
            return TuesTime;
        }

        public void setTuesTime(String tuesTime) {
            TuesTime = tuesTime;
        }

        public String getWedTime() {
            return WedTime;
        }

        public void setWedTime(String wedTime) {
            WedTime = wedTime;
        }

        public String getThurTime() {
            return ThurTime;
        }

        public void setThurTime(String thurTime) {
            ThurTime = thurTime;
        }

        public String getFriTime() {
            return FriTime;
        }

        public void setFriTime(String friTime) {
            FriTime = friTime;
        }

        public String getSatTime() {
            return SatTime;
        }

        public void setSatTime(String satTime) {
            SatTime = satTime;
        }

        public String getSunTime() {
            return SunTime;
        }

        public void setSunTime(String sunTime) {
            SunTime = sunTime;
        }
    }

    public Workday get(int id) throws NSException {
        String url = String.format(URL_GET, id);
        String html = nApiProxy.get(url);
        return Misc.fromJson(html, Workday.class);
    }

    public JsonObject update(Object m) throws NSException {
        String html = nApiProxy.post(URL_UPDATE, Misc.toJson(m));
        return Misc.fromJson(html, JsonObject.class);
    }

    public JsonObject delete(int id, int creatorId, String creator) throws NSException {
        String url = String.format(URL_ERASE, id, creatorId, creator);
        String html = nApiProxy.post(url, null);
        return Misc.fromJson(html, JsonObject.class);
    }

    public WorkdayCollection List(int pageId, int countperpage) throws NSException {
        String url = String.format(URL_LIST, pageId, countperpage);
        String html = nApiProxy.get(url);
        List<Workday> list = new ArrayList<>();
        PageContext pCtx;
        Object[] objects = nApiProxy.parserPagerData(html, PageContext.class, WorkDayModel[].class);
        List<WorkDayModel> listm = (List<WorkDayModel>) objects[0];
        pCtx = (PageContext) objects[1];
        WorkdayCollection coll = new WorkdayCollection();
        if (objects[0] != null) {
            for (WorkDayModel wm : listm) {
                Workday workday = new Workday();
                Misc.objectCopy(wm, workday);
                workday.setWorkDayID(wm.getId());
                list.add(workday);
            }
        }
        coll.addAll(list);
        if (pCtx != null) {
            coll.getQuery().totalCount = pCtx.getTotalCount();
        }
        return coll;
    }

}

