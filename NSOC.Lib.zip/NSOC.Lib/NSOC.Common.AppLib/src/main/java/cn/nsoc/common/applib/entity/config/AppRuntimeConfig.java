package cn.nsoc.common.applib.entity.config;

import cn.nsoc.base.entity.sys.NSException;
import cn.nsoc.common.applib.biz.ConfigManager;
import cn.nsoc.common.util.Misc;

/**
 * Created by sam on 16-7-14.
 */
public class AppRuntimeConfig implements Config {

    private String AppUrl;

    private String RSAKey;

    private boolean UseFrameworkSMTP;

    private String SMTPConfig;

    private String AnalysisConfig;

    public void Save() {
        try {
            ConfigManager.modifyConfig(this);
        } catch (Exception ex) {
            Misc.ignoreException(ex);
        }
    }

    public AppRuntimeConfig() {
        setUseFrameworkSMTP(true);
    }

    public static AppRuntimeConfig Current() throws NSException {
        return ConfigManager.getConfig(AppRuntimeConfig.class);
    }

    public String getAppUrl() {
        return AppUrl;
    }

    public void setAppUrl(String appUrl) {
        AppUrl = appUrl;
    }

    public String getRSAKey() {
        return RSAKey;
    }

    public void setRSAKey(String RSAKey) {
        this.RSAKey = RSAKey;
    }

    public boolean isUseFrameworkSMTP() {
        return UseFrameworkSMTP;
    }

    public void setUseFrameworkSMTP(boolean useFrameworkSMTP) {
        UseFrameworkSMTP = useFrameworkSMTP;
    }

    public String getSMTPConfig() {
        return SMTPConfig;
    }

    public void setSMTPConfig(String SMTPConfig) {
        this.SMTPConfig = SMTPConfig;
    }

    public String getAnalysisConfig() {
        return AnalysisConfig;
    }

    public void setAnalysisConfig(String analysisConfig) {
        AnalysisConfig = analysisConfig;
    }
}
