package cn.nsoc.common.applib.filter;

import cn.nsoc.common.util.Misc;
import org.apache.log4j.Logger;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.handler.HandlerInterceptorAdapter;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.time.Duration;
import java.time.LocalDateTime;

/**
 * Created by sam on 17-8-10.
 */
public class RequestAPMInterceptor extends HandlerInterceptorAdapter {

    private static final Logger logger = Logger.getLogger("RequestAPM");
    private static final long REQUEST_WARNING_DURATION = 12000;


    private LocalDateTime dtStart;

    @Override
    public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler) throws Exception {

        dtStart = LocalDateTime.now();

        if (logger.isTraceEnabled()) {
            String querystring = (request.getQueryString() == null) ? "" : String.format("?%s", request.getQueryString());
            logger.trace(String.format("[%s] req_begin %s%s,%s",
                    dtStart.toString(),
                    request.getRequestURI(),
                    querystring,
                    request.getMethod()
            ));
        }
        return super.preHandle(request, response, handler);
    }

    @Override
    public void postHandle(HttpServletRequest request, HttpServletResponse response, Object handler, ModelAndView modelAndView) throws Exception {
        super.postHandle(request, response, handler, modelAndView);
    }

    @Override
    public void afterCompletion(HttpServletRequest request, HttpServletResponse response, Object handler, Exception ex) throws Exception {

        LocalDateTime dtEnd = LocalDateTime.now();
        long duration = Duration.between(dtStart,dtEnd).toMillis();

        if (logger.isTraceEnabled()) {

            String message = (ex == null) ? "" : String.format("with exception:%s", ex);
            logger.trace(String.format("[%s] req_end   %s, spends %dms, begin at [%s]. %s",
                    dtEnd.toString(),
                    request.getRequestURI(),
                    duration,
                    dtStart.toString(),
                    message)
            );
        }

        if (duration > REQUEST_WARNING_DURATION){
            logger.warn(String.format("long time request: %s %s,%s, spends %dms",
                    request.getRequestURI(),
                    Misc.emptyElse(request.getQueryString(),""),
                    request.getMethod(),
                    duration));
        }

        super.afterCompletion(request, response, handler, ex);
    }
}
