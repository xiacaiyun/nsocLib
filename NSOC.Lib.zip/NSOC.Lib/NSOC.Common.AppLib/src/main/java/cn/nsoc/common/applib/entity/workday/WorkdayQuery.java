package cn.nsoc.common.applib.entity.workday;

import cn.nsoc.common.storer.EntityQuery;

public class WorkdayQuery extends EntityQuery {
    public enum OrderBy {
        Name
    }

    private Integer WorkDayID;

    public int getWorkDayID() {
        return WorkDayID;
    }

    public void setWorkDayID(int WorkDayID) {
        this.WorkDayID = WorkDayID;
    }

}

