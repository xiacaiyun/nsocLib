package cn.nsoc.common.applib.controls;

import org.springframework.context.support.DefaultMessageSourceResolvable;
import org.springframework.validation.Errors;

import java.util.stream.Collectors;

/**
 * Created by fengweiwei on 10/14/16.
 */
public class WebHelper {

    public static JsonRet checkParamErrors(Errors errors) {

        if (errors.hasErrors()) {
            return new JsonRet(false, errors.getAllErrors().stream()
                    .map(DefaultMessageSourceResolvable::getDefaultMessage)
                    .collect(Collectors.joining("\n")));
        } else
            return null;
    }
}
