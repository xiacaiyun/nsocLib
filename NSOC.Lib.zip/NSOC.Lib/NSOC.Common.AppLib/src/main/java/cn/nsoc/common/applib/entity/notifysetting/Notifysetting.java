package cn.nsoc.common.applib.entity.notifysetting;

import cn.nsoc.common.storer.annotation.DbField;

import java.time.LocalDateTime;

public class Notifysetting {
    @DbField(isKey = true)
    private int SettingID;
    private String Mobiles;
    private LocalDateTime CreateDate;
    private String Name;
    private int IsSendSMS;
    private int CreateBy;
    private int EmailToAssignUser;
    private String Emails;
    private int IsSendEmail;
    private int IsBuzz;
    private int SMSToAssignUser;

    public int getSettingID() {
        return SettingID;
    }

    public void setSettingID(int SettingID) {
        this.SettingID = SettingID;
    }

    public String getMobiles() {
        return Mobiles;
    }

    public void setMobiles(String Mobiles) {
        this.Mobiles = Mobiles;
    }

    public LocalDateTime getCreateDate() {
        return CreateDate;
    }

    public void setCreateDate(LocalDateTime CreateDate) {
        this.CreateDate = CreateDate;
    }

    public String getName() {
        return Name;
    }

    public void setName(String Name) {
        this.Name = Name;
    }

    public int getIsSendSMS() {
        return IsSendSMS;
    }

    public void setIsSendSMS(int IsSendSMS) {
        this.IsSendSMS = IsSendSMS;
    }

    public int getCreateBy() {
        return CreateBy;
    }

    public void setCreateBy(int CreateBy) {
        this.CreateBy = CreateBy;
    }

    public int getEmailToAssignUser() {
        return EmailToAssignUser;
    }

    public void setEmailToAssignUser(int EmailToAssignUser) {
        this.EmailToAssignUser = EmailToAssignUser;
    }

    public String getEmails() {
        return Emails;
    }

    public void setEmails(String Emails) {
        this.Emails = Emails;
    }

    public int getIsSendEmail() {
        return IsSendEmail;
    }

    public void setIsSendEmail(int IsSendEmail) {
        this.IsSendEmail = IsSendEmail;
    }

    public int getIsBuzz() {
        return IsBuzz;
    }

    public void setIsBuzz(int IsBuzz) {
        this.IsBuzz = IsBuzz;
    }

    public int getSMSToAssignUser() {
        return SMSToAssignUser;
    }

    public void setSMSToAssignUser(int SMSToAssignUser) {
        this.SMSToAssignUser = SMSToAssignUser;
    }

}

