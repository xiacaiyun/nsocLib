package cn.nsoc.common.auth;

import cn.nsoc.common.applib.entity.user.NUserInfo;
import cn.nsoc.common.applib.membership.UserInfoProvider;
import cn.nsoc.common.util.Misc;
import cn.nsoc.common.util.NApiProxy;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.util.StringUtils;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Collection;

/**
 * Created by sam on 16-10-8.
 */
public class NsocAppUserService implements UserDetailsService {

    private static final Log logger = LogFactory.getLog(NsocAppUserService.class);


    @Override
    public UserDetails loadUserByUsername(String userId) throws UsernameNotFoundException {

        logger.debug(LocalDateTime.now().toLocalTime() + " NsocAppUserService.loadUserByUsername_" + userId);
        try {
            if (StringUtils.hasText(userId)) {
                int nUserId = Integer.parseInt(userId);
                if (nUserId > 0) {

                    UserInfoProvider uip = new UserInfoProvider(NApiProxy.getInstance());
                    NUserInfo u = uip.getUser(nUserId);

                    if (u != null) {
                        Collection<GrantedAuthority> auth = new ArrayList<>();
                        return new NsocUser(u.UserName, u.FullName, nUserId, auth);
                    }
                }
            }

            throw new UsernameNotFoundException(userId + " 用户不存在");
        } catch (Exception e) {
            Misc.ignoreException(e);
            throw new UsernameNotFoundException(userId + " " + e.getMessage());
        }
    }

}