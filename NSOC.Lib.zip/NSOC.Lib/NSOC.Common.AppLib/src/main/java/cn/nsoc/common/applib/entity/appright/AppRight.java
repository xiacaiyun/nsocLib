package cn.nsoc.common.applib.entity.appright;

import cn.nsoc.common.storer.annotation.DbField;

public class AppRight {
    @DbField(isKey = true)
    private int ID;
    private int ObjectType;
    private String ObjectID;
    private String Name;
    private int AllowValue;
    private int DenyValue;
    private String AppID;

    public int getID() {
        return ID;
    }

    public void setID(int ID) {
        this.ID = ID;
    }

    public int getObjectType() {
        return ObjectType;
    }

    public void setObjectType(int objectType) {
        ObjectType = objectType;
    }

    public String getObjectID() {
        return ObjectID;
    }

    public void setObjectID(String objectID) {
        ObjectID = objectID;
    }

    public String getName() {
        return Name;
    }

    public void setName(String name) {
        Name = name;
    }

    public int getAllowValue() {
        return AllowValue;
    }

    public void setAllowValue(int allowValue) {
        AllowValue = allowValue;
    }

    public int getDenyValue() {
        return DenyValue;
    }

    public void setDenyValue(int denyValue) {
        DenyValue = denyValue;
    }

    public String getAppID() {
        return AppID;
    }

    public void setAppID(String appID) {
        AppID = appID;
    }
}

