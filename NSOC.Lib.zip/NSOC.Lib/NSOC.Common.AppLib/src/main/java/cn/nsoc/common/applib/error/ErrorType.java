package cn.nsoc.common.applib.error;

/**
 * Created by sam on 16-10-22.
 */
public enum ErrorType {
    accessDeny("没有权限访问！"),
    systemError("系统错误！"),
    wrongParams("参数错误！"),
    dbError("数据库连接出错！"),
    needLogin("请登录后再访问！");


    private String text;
    private String description;

    ErrorType(String text) {
        this.text = text;
        this.description = "";
    }

    ErrorType(String text, String description) {
        this.text = text;
        this.description = description;
    }

    public String getText() {
        return text;
    }

    public String getDescription() {
        return description;
    }
}
