package cn.nsoc.common.applib.entity.appright;

import cn.nsoc.common.storer.EntityQuery;
import cn.nsoc.common.storer.annotation.DbQuery;
import cn.nsoc.common.storer.annotation.QueryOperator;

import java.util.List;

public class AppRightQuery extends EntityQuery {

    public enum OrderBy {
        Name
    }

    private Integer ObjectType;
    private String ObjectID;
    private String AppID;
    private Integer ID;
    private String Name;

    @DbQuery(Operator = QueryOperator.In)
    private List<String> ObjectIDIDList;


    public Integer getObjectType() {
        return ObjectType;
    }

    public void setObjectType(Integer objectType) {
        ObjectType = objectType;
    }

    public String getObjectID() {
        return ObjectID;
    }

    public void setObjectID(String objectID) {
        ObjectID = objectID;
    }

    public String getAppID() {
        return AppID;
    }

    public void setAppID(String appID) {
        AppID = appID;
    }

    public Integer getID() {
        return ID;
    }

    public void setID(Integer ID) {
        this.ID = ID;
    }

    public String getName() {
        return Name;
    }

    public void setName(String name) {
        Name = name;
    }

    public List<String> getObjectIDIDList() {
        return ObjectIDIDList;
    }

    public void setObjectIDIDList(List<String> objectIDIDList) {
        ObjectIDIDList = objectIDIDList;
    }
}

