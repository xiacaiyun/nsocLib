package cn.nsoc.common.applib.controls;

/**
 * Created by bobwang on 9/19/16.
 */
public class AppExceptionContext {
    private String ErrorName;
    private String HappenTime;
    private String Message;
    private String AppName;


    public String getErrorName() {
        return ErrorName;
    }

    public void setErrorName(String errorName) {
        ErrorName = errorName;
    }

    public String getHappenTime() {
        return HappenTime;
    }

    public void setHappenTime(String happenTime) {
        HappenTime = happenTime;
    }

    public String getMessage() {
        return Message;
    }

    public void setMessage(String message) {
        Message = message;
    }

    public String getAppName() {
        return AppName;
    }

    public void setAppName(String appName) {
        AppName = appName;
    }
}
