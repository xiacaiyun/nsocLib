package cn.nsoc.common.applib.entity.partition;

/**
 * Created by jz on 2017/4/11.
 */

import cn.nsoc.common.storer.EntityCollection;

public class DBTablePartitionCollection extends EntityCollection<DBTablePartition, DBTablePartitionQuery> {
    public DBTablePartitionCollection() {
        super(DBTablePartition.class, DBTablePartitionQuery.class);
    }

    public DBTablePartitionCollection(DBTablePartitionQuery query) {
        this();
        this.setQuery(query);
    }
}
