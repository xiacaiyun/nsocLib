package cn.nsoc.common.auth;

import cn.nsoc.base.entity.sys.NSException;
import cn.nsoc.common.applib.entity.config.AppRuntimeConfig;
import cn.nsoc.common.applib.framework.auth.VerifyTokenRequest;
import cn.nsoc.common.applib.framework.auth.VerifyTokenResult;
import cn.nsoc.common.applib.framework.exchange.ExchangeUrl;
import cn.nsoc.common.util.Misc;
import cn.nsoc.common.util.NApiProxy;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.AuthenticationException;
import org.springframework.security.web.authentication.AbstractAuthenticationProcessingFilter;
import org.springframework.security.web.util.matcher.AntPathRequestMatcher;
import org.springframework.util.Assert;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.UUID;

/**
 * Created by sam on 16-10-8.
 */
public class NsocAppSsoAuthenticationFilter extends AbstractAuthenticationProcessingFilter {


    private UUID appId;


    public NsocAppSsoAuthenticationFilter(String loginPage, UUID appId) {
        super(new AntPathRequestMatcher(loginPage));
        Assert.notNull(appId);
        this.appId = appId;
    }

    @Override
    public Authentication attemptAuthentication(HttpServletRequest request, HttpServletResponse response) throws AuthenticationException, IOException, ServletException {

        String sessionId = request.getParameter("SessionID");
        String token = request.getParameter("Token");

        Assert.hasLength(sessionId);
        Assert.hasLength(token);

        VerifyTokenRequest req = new VerifyTokenRequest();

        try {
            AppRuntimeConfig ac = AppRuntimeConfig.Current();
            req.setSign(Misc.rsaEncrypt(token, ac.getRSAKey()));
            req.setAppID(this.appId);
            req.setToken(token);
            req.setSessionID(Misc.uuidFromString(sessionId));

            String html = NApiProxy.getInstance().post(ExchangeUrl.APP_VERIFY_TOKEN, Misc.toJson(req));
            VerifyTokenResult result = Misc.fromJson(html, VerifyTokenResult.class);
            if (result == null) {
                throw new NSException("返回结果为空");
            }

            if (result.isRet()) {
                NsocSSOAuthenticationToken authRequest = new NsocSSOAuthenticationToken(result.getUserID());
                authRequest.setDetails(request);
                return this.getAuthenticationManager().authenticate(authRequest);

            } else
                throw new NSException(result.getMessage());
        } catch (Exception e) {
            throw new ServletException(e);
        }
    }
}
