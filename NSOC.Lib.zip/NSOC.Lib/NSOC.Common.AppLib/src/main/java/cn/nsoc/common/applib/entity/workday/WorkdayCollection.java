package cn.nsoc.common.applib.entity.workday;

import cn.nsoc.common.storer.EntityCollection;

public class WorkdayCollection extends EntityCollection<Workday, WorkdayQuery> {
    public WorkdayCollection() {
        super(Workday.class, WorkdayQuery.class);
    }

    public WorkdayCollection(WorkdayQuery query) {
        this();
        this.setQuery(query);
    }
}

