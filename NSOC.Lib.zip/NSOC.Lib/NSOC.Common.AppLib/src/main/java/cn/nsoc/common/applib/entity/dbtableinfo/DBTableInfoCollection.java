package cn.nsoc.common.applib.entity.dbtableinfo;

import cn.nsoc.common.storer.EntityCollection;

/**
 * Created by jz on 10/24/16.
 */
public class DBTableInfoCollection extends EntityCollection<DBTableInfo, DBTableInfoQuery> {
    public DBTableInfoCollection() {
        super(DBTableInfo.class, DBTableInfoQuery.class);
    }

    public DBTableInfoCollection(DBTableInfoQuery query) {
        this();
        this.setQuery(query);
    }
}
