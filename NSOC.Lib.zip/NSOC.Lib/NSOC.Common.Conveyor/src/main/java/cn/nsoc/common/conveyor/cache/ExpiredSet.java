package cn.nsoc.common.conveyor.cache;

import cn.nsoc.base.entity.sys.NSException;
import cn.nsoc.common.conveyor.ConveyorImpl;
import cn.nsoc.common.conveyor.CounterPolicyImpl;
import cn.nsoc.common.conveyor.IKeyTransform;
import cn.nsoc.common.conveyor.IQuickFetch;

/**
 * Created by bobwang on 8/11/17.
 */
public class ExpiredSet<T> extends ConveyorImpl<T, T, T> {

    class Transform<T> implements IKeyTransform<T, T> {
        @Override
        public T onTransform(T src) throws NSException {
            return src;
        }
    }

    class QuickFetchImpl<T> implements IQuickFetch<T, T, T> {
        @Override
        public T onLoad(T key, T searchKey) throws NSException {
            return key;
        }
    }

    protected long DEF_MAXIMUM_SIZE        = 100 * 1024L;
    protected long DEF_EXPIRE_AFTER_ACCESS = 60 * 60L;
    protected long DEF_EXPIRE_AFTER_WRITE  = 60 * 60L;
    protected int  DEF_CONCURRENCY_LEVEL   = 8;

    @SuppressWarnings("unchecked")
    public ExpiredSet(long maximumSize, long expireAfterAccess, long expireAfterWrite) {
        try {
            initialize(new QuickFetchImpl()
                    , new Transform()
                    , new CounterPolicyImpl(maximumSize == 0 ? DEF_MAXIMUM_SIZE : maximumSize
                    , expireAfterAccess == 0 ? DEF_EXPIRE_AFTER_ACCESS : expireAfterAccess
                    , expireAfterWrite == 0 ? DEF_EXPIRE_AFTER_WRITE : expireAfterWrite
                    , DEF_CONCURRENCY_LEVEL)
                    , null);
        }
        catch (NSException exp){
            ignoreException(exp);
        }
    }


    private void ignoreException(NSException exp){
        // for sonar
    }

    private synchronized void update(T key) throws NSException{
        search(key);
    }

    public boolean add(T key) throws NSException {
        T objResult = getIfPresent(key);
        if (objResult == null) {
            update(key);
            return true;
        }
        return false;
    }
}