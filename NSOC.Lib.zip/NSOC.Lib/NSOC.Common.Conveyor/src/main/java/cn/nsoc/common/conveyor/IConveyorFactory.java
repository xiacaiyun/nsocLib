package cn.nsoc.common.conveyor;


import cn.nsoc.base.entity.sys.NSException;

/**
 * Created by bobwang on 11/4/16.
 */
public interface IConveyorFactory<T, U, R> {
    void initialize(IQuickFetch<T, U, R> fetch
            , IKeyTransform<T, R> transform
            , ICounterPolicy policy
            , IDataInitialize<T, U> initializer) throws NSException;

    void shutdown();
}
