package cn.nsoc.common.conveyor;

import cn.nsoc.base.entity.sys.NSException;
import org.apache.log4j.Logger;


/**
 * Created by sam on 17-5-17.
 */
public class GlobalOutputCache {

    private static final Logger logger = Logger.getLogger(GlobalOutputCache.class);
    private static final GCache handlerSecond = createGCache(1);
    private static final GCache handlerTenSecond = createGCache(10);
    private static final GCache handlerMinute = createGCache(60);
    private static final GCache handlerTenMinute = createGCache(600);


    private GlobalOutputCache() {
    }

    private static GCache createGCache(int expireAfterWrite) {
        GCache handler = new GCache(new CounterPolicyImpl(1000, 0, expireAfterWrite, 0));
        try {
            handler.start();
        } catch (NSException e) {
            logger.error(String.format("error to init GlobalOutputCache: %d sec ", expireAfterWrite));
            //因为这里没有initializer，可以不用 handler = null
            ignoreException(e);

        }
        return handler;
    }

    public static class GCache extends BaseCacheManager<String, Object, String> {

        public GCache(CounterPolicyImpl policy) {
            super(policy);
        }

        @Override
        public String onTransform(String src) throws NSException {
            return src;
        }

        @Override
        public Object onLoad(String key, String searchKey) throws NSException {
            return new Object();
        }
    }

    private static void ignoreException(Exception ex) {
        // for sonar
    }

    public static GCache getHandlerSecond() {
        return handlerSecond;
    }

    public static GCache getHandlerTenSecond() {
        return handlerTenSecond;
    }

    public static GCache getHandlerMinute() {
        return handlerMinute;
    }

    public static GCache getHandlerTenMinute() {
        return handlerTenMinute;
    }

}
