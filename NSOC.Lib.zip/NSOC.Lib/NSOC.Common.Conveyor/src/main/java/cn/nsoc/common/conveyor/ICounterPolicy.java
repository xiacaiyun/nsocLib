package cn.nsoc.common.conveyor;

/**
 * Created by bobwang on 11/4/16.
 */
public interface ICounterPolicy {
    long onSetMaximumSize();

    long onSetExpireAfterAccess();

    long onSetExpireAfterWrite();

    int onSetConcurrencyLevel();

}
