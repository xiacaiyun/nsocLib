package cn.nsoc.common.conveyor;

/**
 * Created by bobwang on 11/9/16.
 */
public class CounterPolicyImpl implements ICounterPolicy {

    private long maxinumSize = 0;
    private long expireAfterAccess = 0;
    private long expireAfterWrite = 0;
    private int concurrencyLevel = 0;

    public CounterPolicyImpl() {
    }

    public CounterPolicyImpl(long maxinumSize, long expireAfterAccess, long expireAfterWrite, int concurrencyLevel) {
        this.maxinumSize = maxinumSize;
        this.expireAfterAccess = expireAfterAccess;
        this.expireAfterWrite = expireAfterWrite;
        this.concurrencyLevel = concurrencyLevel;
    }

    @Override
    public long onSetMaximumSize() {
        return maxinumSize;
    }

    @Override
    public long onSetExpireAfterAccess() {
        return expireAfterAccess;
    }

    @Override
    public long onSetExpireAfterWrite() {
        return expireAfterWrite;
    }

    @Override
    public int onSetConcurrencyLevel() {
        return concurrencyLevel;
    }
}
