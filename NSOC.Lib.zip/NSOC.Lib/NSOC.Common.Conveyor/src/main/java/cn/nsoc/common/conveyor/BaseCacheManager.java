package cn.nsoc.common.conveyor;

import cn.nsoc.base.entity.sys.NSException;

/**
 * Created by sam on 16-12-28.
 */
public abstract class BaseCacheManager<T, U, R> extends ConveyorImpl<T, U, R>
        implements IQuickFetch<T, U, R>, IKeyTransform<T, R> {

    private CounterPolicyImpl policy;

    public BaseCacheManager() {
    }

    public BaseCacheManager(CounterPolicyImpl policy) {
        super();
        this.policy = policy;
    }

    public void start() throws NSException {
        if (policy == null) {
            policy = new CounterPolicyImpl(100, 0, 60, 0);
        }
        initialize(this, this, policy, null);
    }
}