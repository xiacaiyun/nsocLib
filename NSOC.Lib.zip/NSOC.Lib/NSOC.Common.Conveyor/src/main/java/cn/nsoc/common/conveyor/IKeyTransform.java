package cn.nsoc.common.conveyor;

import cn.nsoc.base.entity.sys.NSException;

/**
 * Created by bobwang on 11/4/16.
 */
public interface IKeyTransform<T, R> {
    T onTransform(R src) throws NSException;
}
