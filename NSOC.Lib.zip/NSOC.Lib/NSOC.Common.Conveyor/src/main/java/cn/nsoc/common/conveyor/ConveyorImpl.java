package cn.nsoc.common.conveyor;

import cn.nsoc.base.entity.biz.IConveyor;
import cn.nsoc.base.entity.define.NSExceptionCode;
import cn.nsoc.base.entity.sys.NSException;
import com.google.common.cache.Cache;
import com.google.common.cache.CacheBuilder;
import com.google.common.cache.RemovalListener;
import org.apache.commons.lang3.tuple.ImmutablePair;
import org.apache.log4j.Logger;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.TimeUnit;

/**
 * Created by bobwang on 11/9/16.
 */

public class ConveyorImpl<T, U, R> implements IConveyorFactory<T, U, R>, IConveyor<T, U, R> {

    static class FetchForward<T, U, R> implements Callable {
        IQuickFetch quickFetch;
        T genKey;
        R searchKey;

        public FetchForward(IQuickFetch fetch, T objSearch, R key) {
            quickFetch = fetch;
            genKey = objSearch;
            searchKey = key;
        }

        @SuppressWarnings("unchecked")
        @Override
        public U call() throws NSException {
            try {
                return (U) quickFetch.onLoad(genKey, searchKey);
            } catch (Exception exp) {
                throw new NSException(NSExceptionCode.Biz_Cache_Get_Failed, exp);
            }
        }
    }

    protected IQuickFetch fetch;
    protected IKeyTransform transform;
    protected Cache<T, U> cache;
    private static final Logger appLogger = Logger.getLogger(ConveyorImpl.class);

    public ConveyorImpl() {
    }

    @SuppressWarnings("unchecked")
    @Override
    public void initialize(IQuickFetch fetch
            , IKeyTransform transform
            , ICounterPolicy policy
            , IDataInitialize initializer) throws NSException {

        this.transform = transform;
        this.fetch = fetch;

        long expiredSec = policy.onSetExpireAfterAccess();
        long maxSize = policy.onSetMaximumSize();
        int concurrencyLevel = policy.onSetConcurrencyLevel();
        long expiredSecAfterWrite = policy.onSetExpireAfterWrite();

        CacheBuilder<Object, Object> builder = CacheBuilder.newBuilder();
        if (expiredSec != 0) {
            builder.expireAfterAccess(expiredSec, TimeUnit.SECONDS);
        }
        if (expiredSecAfterWrite != 0) {
            builder.expireAfterWrite(expiredSecAfterWrite, TimeUnit.SECONDS);
        }
        if (maxSize != 0) {
            builder.maximumSize(maxSize);
        }
        if (concurrencyLevel > 0) {
            builder.concurrencyLevel(concurrencyLevel);
        }
        builder.removalListener((RemovalListener<T, U>) notification -> {
        });
        cache = builder.build();

        if (initializer != null) {
            List<ImmutablePair<T, U>> results = initializer.onGetSnap();
            if (results != null) {
                for (ImmutablePair<T, U> pair : results) {
                    if (transform != null) {
                        T searchKey = (T) transform.onTransform(pair.getLeft());
                        cache.put(searchKey, pair.getRight());
                    } else {
                        cache.put(pair.getLeft(), pair.getRight());
                    }
                }
            }
        }
    }

    @Override
    public U search(R key) throws NSException {
        try {
            T objSearch = (T) transform.onTransform(key);
            FetchForward<T, U, R> forward = new FetchForward<>(fetch, objSearch, key);
            return (U) cache.get(objSearch, forward);
        } catch (ExecutionException exp) {
            throw new NSException(NSExceptionCode.Biz_Cache_Get_Failed, exp);
        }
    }


    @Override
    public U search(R partialKey1, R partialKey2) throws NSException {
        return null;
    }

    @Override
    public U search(R[] partialKeys) throws NSException {
        return null;
    }

    @Override
    public List<U> searchMutiple(Set<R> keys) throws NSException {
        return new ArrayList<>();
    }

    @Override
    public List<U> getValues() throws NSException {
        return new ArrayList<>();
    }

    @Override
    public List<T> getKeys() throws NSException {
        return new ArrayList<>();
    }

    @SuppressWarnings("unchecked")
    @Override
    public void remove(R searchkey) throws NSException {
        T objSearch = (T) transform.onTransform(searchkey);
        cache.invalidate(objSearch);
    }


    public void removeByKey(T key) {
        cache.invalidate(key);
    }


    @Override
    public void shutdown() {
        //empty
    }


    public U getIfPresent(T key) {
        return cache.getIfPresent(key);
    }

    public void put(T var1, U var2) {
        cache.put(var1, var2);
    }
}


