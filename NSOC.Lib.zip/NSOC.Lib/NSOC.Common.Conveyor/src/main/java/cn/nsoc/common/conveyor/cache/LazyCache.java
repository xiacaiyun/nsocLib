package cn.nsoc.common.conveyor.cache;

import cn.nsoc.base.entity.sys.NSException;
import cn.nsoc.common.conveyor.BaseCacheManager;
import cn.nsoc.common.conveyor.CounterPolicyImpl;
import org.apache.log4j.Logger;

import java.util.function.Function;

/**
 * Created by sam on 17-5-26.
 */
public class LazyCache {

    private static final Logger logger = Logger.getLogger(LazyCache.class);
    private InnerCache cache = null;


    private class InnerCache extends BaseCacheManager<String, Object, LazyKey> {

        private Object emptyObject = new Object();

        public InnerCache(CounterPolicyImpl policy) {
            super(policy);
        }

        @Override
        public String onTransform(LazyKey src) throws NSException {
            return src.getKey();
        }

        @Override
        public Object onLoad(String key, LazyKey searchKey) {

            Object val = null;
            if (searchKey.getLoader() != null) {
                val = searchKey.getLoader().apply(searchKey.getParameters());
            }
            if (val == null)
                return emptyObject;
            else
                return val;
        }

        public boolean isEmpty(Object obj) {
            return emptyObject.equals(obj);
        }
    }


    private LazyCache(CounterPolicyImpl policy) throws NSException {
        cache = new InnerCache(policy);
        cache.start();
    }

    public static LazyCache createCache(CounterPolicyImpl policy) {

        CounterPolicyImpl p = policy;
        if (policy == null) {
            p = new CounterPolicyImpl(1000, 0, 60, 0);
        }
        try {
            return new LazyCache(p);
        } catch (NSException e) {
            logger.error(String.format("error to init LazyCache: %s ", e));
            return null;
            //因为这里没有initializer，可以不用 handler = null
        }
    }

    public Object get(String key) {
        return cache.getIfPresent(key);
    }

    public Object getOrLoad(String key, Function<Object, Object> loader, Object parameters) throws NSException {
        LazyKey lazyKey = new LazyKey(key, loader, parameters);
        Object val = cache.search(lazyKey);


        if (cache.isEmpty(val)) {
            cache.removeByKey(key);
            return null;
        }
        if (val instanceof Exception) {
            cache.removeByKey(key);
            throw new NSException((Exception) val);
        }

        return val;
    }

    public void remove(String key) {
        cache.removeByKey(key);
    }
}
