package cn.nsoc.common.conveyor;

import cn.nsoc.base.entity.sys.NSException;
import org.apache.commons.lang3.tuple.ImmutablePair;

import java.util.List;

/**
 * Created by bobwang on 11/4/16.
 */
public interface IDataInitialize<T, U> {
    List<ImmutablePair<T, U>> onGetSnap() throws NSException;
}
