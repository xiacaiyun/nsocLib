package cn.nsoc.common.conveyor.cache;

import java.util.function.Function;

/**
 * Created by sam on 17-5-26.
 */
public class LazyKey {
    private String key;
    private Object parameters;
    private Function<Object, Object> loader;

    public LazyKey(String key, Function<Object, Object> loader, Object parameters) {
        setKey(key);
        setLoader(loader);
        setParameters(parameters);
    }

    public String getKey() {
        return key;
    }


    public void setKey(String key) {
        this.key = key;
    }

    public Function<Object, Object> getLoader() {
        return loader;
    }

    public void setLoader(Function<Object, Object> loader) {
        this.loader = loader;
    }

    public Object getParameters() {
        return parameters;
    }

    public void setParameters(Object parameters) {
        this.parameters = parameters;
    }
}
