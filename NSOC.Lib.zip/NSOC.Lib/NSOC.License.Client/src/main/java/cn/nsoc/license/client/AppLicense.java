package cn.nsoc.license.client;

import cn.nsoc.base.entity.sys.NSException;
import cn.nsoc.common.util.Misc;
import org.dom4j.Document;
import org.dom4j.DocumentHelper;
import org.dom4j.Element;
import org.springframework.core.io.Resource;
import org.springframework.util.StringUtils;

/**
 * Created by sam on 16-7-5.
 */
public class AppLicense {
    static final String LIC_FILENAME = "/license.lic";

    private static AppLicense instance = null;
    private License license;


    public static AppLicense getInstance() {
        if (instance == null)
            instance = new AppLicense();
        return instance;
    }


    public License getLicense() throws NSException {
        if (license == null) {
            try {
                Resource rlic = Misc.getLocalFile(LIC_FILENAME);
                if (rlic.exists()) {
                    license = parseLicense(Misc.readFile(rlic.getFile()));
                }
            } catch (Exception ex) {
                throw new NSException(ex);
            }
        }
        return license;
    }

    public void resetLicense() {
        license = null;
    }

    public static License parseLicense(String xml) throws NSException {
        if (!StringUtils.hasText(xml))
            return null;

        try {
            Document doc = DocumentHelper.parseText(xml);
            Element topElement = doc.getRootElement();

            LicenseParser lp = new LicenseParser();
            return lp.Parse(topElement.getTextTrim());
        } catch (Exception ex) {
            throw new NSException(ex);
        }
    }


    public static void saveLicenseFile(String dir, String content) throws NSException {
        Misc.directWriteFile(StringUtils.trimTrailingCharacter(dir.trim(), '/') + LIC_FILENAME, content);
    }
}
