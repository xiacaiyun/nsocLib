package cn.nsoc.license.client;

import cn.nsoc.base.entity.sys.NSException;

import java.time.LocalDateTime;
import java.util.List;
import java.util.UUID;

/**
 * Created by sam on 16-7-5.
 */
public class License {

    public UUID LicenseID;
    public String CustomerName;
    public int LicenseType;
    public String LicenseTypeName;
    public boolean NeverExpired;
    public LocalDateTime JavaStartDate;
    public String StartDate;
    public Integer ExpiredDays;
    public String PublicKey;
    public List<AppModule> AppModules;

    public boolean isExpired(LocalDateTime dt) throws NSException {

        if (NeverExpired)
            return false;

        if (ExpiredDays == null)
            throw new NSException("不正确的许可证！");

        return JavaStartDate.toLocalDate().plusDays(ExpiredDays).isBefore(dt.toLocalDate());
    }

    public boolean isValidApp(UUID appId) {
        return appId != null && AppModules.stream().anyMatch(p -> appId.equals(p.AppID));
    }

    public boolean hasModule(UUID moduleId) {
        return AppModules.stream()
                .anyMatch(p -> (p.Modules != null)
                        && p.Modules.stream()
                        .anyMatch(subp -> subp.equals(moduleId)));
    }

    public class AppModule {
        public UUID AppID;

        public List<UUID> Modules;

        public String Version;
    }

}