package cn.nsoc.license.client;

import cn.nsoc.base.entity.sys.NSException;
import cn.nsoc.common.util.AESCryptServiceProvider;
import cn.nsoc.common.util.Misc;
import cn.nsoc.common.util.RSACryptoServiceProvider;
import org.springframework.util.Base64Utils;
import org.springframework.util.StringUtils;

import java.io.UnsupportedEncodingException;

/**
 * Created by sam on 16-7-5.
 */
public class LicenseParser {
    public byte[] GetKey() {
        return Misc.hexStringToByteArray("0E98DC3120114CB3AE9CC38DBECCFED3");
    }

    public byte[] GetIV() {
        return Misc.hexStringToByteArray("8CE2966DF00949ED9CA136F05AC2E0D2");
    }

    public License Parse(String code) throws NSException, UnsupportedEncodingException {
        if (!StringUtils.hasText(code))
            throw new NSException("数据不能为空！");

        String plainText = DecodeLicense(code);
        LicensePackage pkg = Misc.fromJson(plainText, LicensePackage.class);
        if (pkg == null) {
            throw new NSException("数据格式不正确！");
        }
        RSACryptoServiceProvider ras = new RSACryptoServiceProvider();

        ras.fromXmlString(pkg.Key);

        License lic = null;
        if (ras.verifyData(pkg.Data.getBytes("UTF-8"),
                Base64Utils.decodeFromString(pkg.Sign))) {
            lic = Misc.fromJson(pkg.Data, License.class);
            if (lic != null) {
                lic.JavaStartDate = Misc.parseDotNetDateTime(lic.StartDate);
            }
        }
        return lic;
    }

    private String DecodeLicense(String code) throws NSException {
        return AESCryptServiceProvider.decrypt(code, GetKey(), GetIV());
    }

}
