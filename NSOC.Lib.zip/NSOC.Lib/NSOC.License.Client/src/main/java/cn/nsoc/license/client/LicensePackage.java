package cn.nsoc.license.client;

/**
 * Created by sam on 16-7-6.
 */
public class LicensePackage {
    public String Ver;

    public String Data;

    public String Sign;

    public String Key;
}
