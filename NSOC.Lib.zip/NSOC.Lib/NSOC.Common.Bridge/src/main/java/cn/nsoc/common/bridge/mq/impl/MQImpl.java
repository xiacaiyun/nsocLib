package cn.nsoc.common.bridge.mq.impl;

import cn.nsoc.base.entity.sys.NSException;
import cn.nsoc.common.bridge.mq.entity.IFactory;
import cn.nsoc.common.bridge.mq.entity.IMessageQueue;
import com.rabbitmq.client.ConnectionFactory;
import org.springframework.util.StringUtils;


/**
 * Created by bobwang on 11/22/16.
 */
public class MQImpl implements IMessageQueue {


    @Override
    public IFactory createFactory(String uri) throws NSException {
        try {
            ConnectionFactory factory = new ConnectionFactory();
            factory.setUri(uri);
            factory.setAutomaticRecoveryEnabled(true);
            return new FactoryImpl(factory);
        } catch (Exception ex) {
            throw new NSException(ex);
        }
    }

    @Override
    public IFactory createFactory(String host, int port, String virtualHost, String userName, String password)
            throws NSException {
        ConnectionFactory factory = new ConnectionFactory();
        factory.setAutomaticRecoveryEnabled(true);
        if (StringUtils.hasText(host)) {
            factory.setHost(host);
        }
        if (port > 0) {
            factory.setPort(port);
        }
        if (StringUtils.hasText(virtualHost)) {
            factory.setVirtualHost(virtualHost);
        }
        if (StringUtils.hasText(userName)) {
            factory.setUsername(userName);
        }
        if (StringUtils.hasText(password)) {
            factory.setPassword(password);
        }
        factory.setRequestedHeartbeat(30);
        return new FactoryImpl(factory);
    }
}
