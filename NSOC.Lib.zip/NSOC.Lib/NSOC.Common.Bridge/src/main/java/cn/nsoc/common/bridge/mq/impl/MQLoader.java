package cn.nsoc.common.bridge.mq.impl;

import cn.nsoc.common.bridge.mq.entity.IMessageQueue;

/**
 * Created by bobwang on 11/23/16.
 */
public class MQLoader {

    public static IMessageQueue create() {
        return new MQImpl();
    }

}
