package cn.nsoc.common.bridge.mq.impl;

import cn.nsoc.base.entity.sys.NSException;
import cn.nsoc.common.bridge.mq.entity.IOutMessage;
import cn.nsoc.common.bridge.mq.entity.IPublish;
import cn.nsoc.common.util.Misc;
import com.rabbitmq.client.Channel;
import com.rabbitmq.client.Connection;

import java.io.IOException;
import java.nio.charset.Charset;
import java.util.concurrent.*;
import java.util.concurrent.atomic.AtomicReference;

/**
 * Created by bobwang on 11/22/16.
 */
public class PublishImpl implements IPublish {
    protected Connection connection;
    protected Channel channel;
    protected Charset encoder;
    private ExecutorService jobExecutor;
    private BlockingQueue<IOutMessage> workingQueue;
    volatile boolean exited;
    AtomicReference<Exception> backExp;

    class SBSQueueThread implements Runnable {
        @Override
        public void run() {
            while (!exited) {
                try {
                    IOutMessage gotVal = workingQueue.poll(30, TimeUnit.SECONDS);
                    if (gotVal != null) {
                        onSend(gotVal);
                    }
                } catch (InterruptedException ignored) {
                    Misc.ignoreException(ignored);
                    Thread.currentThread().interrupt();
                } catch (Exception exp) {
                    backExp.set(exp);
                }
            }
        }
    }

    public PublishImpl(Connection conn, Channel ch) {
        connection = conn;
        channel = ch;
        encoder = Charset.forName("UTF-8");
        exited = false;
        workingQueue = new LinkedBlockingQueue<>();
        backExp = new AtomicReference<>();
    }

    protected void prepareSend(IOutMessage msg) throws NSException {
        Exception prevExp = backExp.get();
        if (prevExp != null) {
            backExp.set(null);
            throw new NSException(prevExp);
        }
        workingQueue.add(msg);
    }

    protected void onSend(IOutMessage msg) throws IOException {
        // for override
    }

    public void start() {
        jobExecutor = Executors.newSingleThreadExecutor();
        jobExecutor.execute(new SBSQueueThread());
    }

    @Override
    public void send(String message) throws NSException {
        throw new NSException("publish type is bad");
    }

    @Override
    public void send(String routingKey, String message) throws NSException {
        throw new NSException("publish type is bad");
    }

    @Override
    public void shutdown() {
        exited = true;
        if (jobExecutor != null) {
            jobExecutor.shutdownNow();
        }
        if (channel != null) {
            try {
                channel.close();
            } catch (IOException | TimeoutException ignored) {
                Misc.ignoreException(ignored);
            }
            channel = null;
        }
        if (connection != null) {
            try {
                connection.close();
            } catch (IOException ignored) {
                Misc.ignoreException(ignored);
            }
            connection = null;
        }
    }
}
