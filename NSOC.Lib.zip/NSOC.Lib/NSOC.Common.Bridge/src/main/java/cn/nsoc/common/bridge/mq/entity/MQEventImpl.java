package cn.nsoc.common.bridge.mq.entity;

/**
 * Created by bobwang on 11/22/16.
 */
public class MQEventImpl implements IMessageQueueEvent {
    @Override
    public void onClientInstance(IClient client) {

    }

    @Override
    public void onError(Exception exp) {

    }

    @Override
    public void onDataArrived(String key, String buffer) {

    }
}
