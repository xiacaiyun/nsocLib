package cn.nsoc.common.bridge.mq.impl;

import cn.nsoc.common.bridge.mq.entity.IMessageQueueEvent;
import com.rabbitmq.client.AMQP;
import com.rabbitmq.client.Channel;
import com.rabbitmq.client.DefaultConsumer;
import com.rabbitmq.client.Envelope;

import java.io.IOException;
import java.nio.charset.Charset;

/**
 * Created by bobwang on 11/23/16.
 */
public class ForwardConsumer extends DefaultConsumer {

    IMessageQueueEvent handler;
    boolean autoAck;
    Charset encoder;

    public ForwardConsumer(Channel channel, IMessageQueueEvent ev, boolean ack) {
        super(channel);
        handler = ev;
        autoAck = ack;
        encoder = Charset.forName("UTF-8");
    }

    @Override
    public void handleDelivery(String consumerTag, Envelope envelope, AMQP.BasicProperties properties, byte[] body)
            throws IOException {
        String routingKey = envelope.getRoutingKey();
        long deliveryTag = envelope.getDeliveryTag();


        handler.onDataArrived(routingKey, new String(body, encoder));

        if (!autoAck) {
            getChannel().basicAck(deliveryTag, false);
        }
    }

}
