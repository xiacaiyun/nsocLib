package cn.nsoc.common.bridge.mq.entity;

/**
 * Created by bobwang on 11/23/16.
 */
public interface IOutMessage {
}
