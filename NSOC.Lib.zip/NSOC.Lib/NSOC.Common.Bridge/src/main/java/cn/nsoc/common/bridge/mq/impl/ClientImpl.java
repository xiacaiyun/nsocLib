package cn.nsoc.common.bridge.mq.impl;

import cn.nsoc.common.bridge.mq.entity.IClient;
import cn.nsoc.common.bridge.mq.entity.IMessageQueueEvent;
import cn.nsoc.common.util.Misc;
import com.rabbitmq.client.Channel;
import com.rabbitmq.client.Connection;

import java.io.IOException;
import java.util.concurrent.TimeoutException;

/**
 * Created by bobwang on 11/22/16.
 */
public class ClientImpl implements IClient {
    protected Connection connection;
    protected Channel channel;
    ForwardConsumer consumer;

    public ClientImpl(Connection conn, Channel ch) {
        connection = conn;
        channel = ch;
    }

    public void setConsumer(boolean ack, String queueName, IMessageQueueEvent ev) throws IOException {
        consumer = new ForwardConsumer(channel, ev, ack);
        channel.basicConsume(queueName, ack, consumer);
    }


    @Override
    public void subscribeTopic(String topic) throws IOException {
        // empty
    }

    @Override
    public void unSubscribeTopic(String topic) throws IOException {
        // empty
    }

    @Override
    public void shutdown() {
        if (channel != null) {
            try {
                channel.close();
            } catch (IOException | TimeoutException ignored) {
                Misc.ignoreException(ignored);
            }
            channel = null;
        }
        if (connection != null) {
            try {
                connection.close();
            } catch (IOException ignored) {
                Misc.ignoreException(ignored);
            }
            connection = null;
        }
    }
}
