package cn.nsoc.common.bridge.libwrap;

import cn.nsoc.base.entity.biz.IStoreParameter;
import cn.nsoc.base.entity.sys.NSException;
import cn.nsoc.common.bridge.dyncloader.DyncEntityGen;
import cn.nsoc.common.storer.db.JdbcDbStorer;
import cn.nsoc.common.storer.entity.MetaDesc;
import cn.nsoc.common.storer.meta.StoreMetaImpl;
import cn.nsoc.common.util.Misc;
import org.apache.commons.dbcp2.BasicDataSource;

import java.io.File;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.nio.file.Paths;

/**
 * Created by bobwang on 10/24/16.
 */
public class Libwrap {
    private Libwrap() {

    }

    public static JdbcDbStorer createDbStore(IStoreParameter parameter) throws NSException {
        BasicDataSource dsNsoc = new BasicDataSource();
        dsNsoc.setDriverClassName(parameter.getDriverClassName());
        dsNsoc.setUrl(parameter.getAddress());
        dsNsoc.setUsername(parameter.getAccount());
        dsNsoc.setPassword(parameter.getPassword());
        dsNsoc.setInitialSize(parameter.getInitialSize());
        return JdbcDbStorer.createJdbcDbStorer("mysql", dsNsoc);
    }

    static String getMetaHash(MetaDesc desc) {
        StringBuilder metaBuilder = new StringBuilder(1024);
        for (MetaDesc.ItemDesc item : desc.getEntrys()) {
            metaBuilder.append(item.toString());
        }
        return Misc.getMD5(metaBuilder.toString());
    }

    static String getClassFileHash(String outputPath, String tableName, String clsName) {
        String clsFileName = Paths.get(outputPath, String.format("%s.class", clsName)).toString();
        File classFile = new File(clsFileName);
        StringBuilder classFileBuilder = new StringBuilder(1024);
        if (classFile.exists()) {
            try {
                String[] lines = Misc.readFileLines(classFile, "UTF-8");
                for (String item : lines) {
                    classFileBuilder.append(item);
                }
                return Misc.getMD5(classFileBuilder.toString());
            } catch (Exception ignored) {
                Misc.ignoreException(ignored);
            }
        }
        return null;
    }

    public static Class genEntityClass(JdbcDbStorer storer, String tableName, String targetPath, String schema) throws NSException {
        boolean alwayNew = true;

        String metaCurrentHash;
        String classCurrentHash;
        String outputPath = Paths.get(targetPath, "gen").toString();

        String clsName = String.format("nsoc_dyn_%s", tableName);

        File opFile = new File(outputPath);
        if (!opFile.exists()) {
            opFile.mkdir();
        }

        try {

            StoreMetaImpl metaImpl = new StoreMetaImpl();
            MetaDesc desc = metaImpl.getEntityDesc(storer, tableName, schema);

            metaCurrentHash = getMetaHash(desc);
            classCurrentHash = getClassFileHash(outputPath, tableName, clsName);


            String statFileName = Paths.get(outputPath, String.format("%s.sig", clsName)).toString();
            File statFile = new File(statFileName);
            if (statFile.exists()) {
                String[] lines = Misc.readFileLines(statFile, "UTF-8");
                if (lines.length == 2) {
                    if (metaCurrentHash != null
                            && !metaCurrentHash.isEmpty()
                            && metaCurrentHash.compareTo(lines[0]) == 0) {
                        if (classCurrentHash != null
                                && !classCurrentHash.isEmpty()
                                && classCurrentHash.compareTo(lines[1]) == 0) {
                            alwayNew = false;
                        }
                    }
                }
            }

            DyncEntityGen gen = new DyncEntityGen();
            Class targetCls = gen.genTableEntity(tableName, clsName, outputPath, desc, alwayNew);
            if (targetCls != null) {
                StringWriter writer = new StringWriter();
                PrintWriter out = new PrintWriter(writer);
                out.println(metaCurrentHash);
                classCurrentHash = getClassFileHash(outputPath, tableName, clsName);
                out.println(classCurrentHash);
                out.close();
                Misc.directWriteFile(statFileName, writer.toString());
            }
            return targetCls;
        } catch (Exception ex) {
            throw new NSException(ex);
        }
    }
}
