package cn.nsoc.common.bridge.mq.apply;

import cn.nsoc.base.entity.sys.NSException;
import cn.nsoc.common.bridge.mq.entity.IOutMessage;
import cn.nsoc.common.bridge.mq.impl.PublishImpl;
import com.rabbitmq.client.Channel;
import com.rabbitmq.client.Connection;
import com.rabbitmq.client.MessageProperties;

import java.io.IOException;

/**
 * Created by bobwang on 11/22/16.
 */
public class SingleConsumerPublish extends PublishImpl {
    String exName;
    String queueName;

    public SingleConsumerPublish(Connection conn, Channel ch, String exchangeName, String qName) {
        super(conn, ch);
        this.queueName = qName;
        exName = exchangeName;
    }

    @Override
    public void send(String message) throws NSException {
        prepareSend(new SingleConsumerMsg(message));
    }

    @Override
    protected void onSend(IOutMessage msg) throws IOException {
        SingleConsumerMsg consMsg = (SingleConsumerMsg) msg;
        channel.basicPublish(""
                , queueName
                , MessageProperties.PERSISTENT_TEXT_PLAIN
                , consMsg.getMessage().getBytes(encoder));
    }
}
