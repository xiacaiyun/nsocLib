package cn.nsoc.common.bridge.mq.impl;

import cn.nsoc.base.entity.sys.NSException;
import cn.nsoc.common.bridge.mq.apply.SingleConsumerClient;
import cn.nsoc.common.bridge.mq.apply.SingleConsumerPublish;
import cn.nsoc.common.bridge.mq.apply.TopicClient;
import cn.nsoc.common.bridge.mq.apply.TopicPublish;
import cn.nsoc.common.bridge.mq.entity.IClient;
import cn.nsoc.common.bridge.mq.entity.IFactory;
import cn.nsoc.common.bridge.mq.entity.IMessageQueueEvent;
import cn.nsoc.common.bridge.mq.entity.IPublish;
import com.rabbitmq.client.*;

import java.util.HashMap;
import java.util.Map;

/**
 * Created by bobwang on 11/22/16.
 */
public class FactoryImpl implements IFactory {
    ConnectionFactory factory;

    public FactoryImpl(ConnectionFactory fact) {
        factory = fact;
    }

    class ShutdownListenerHandle implements ShutdownListener {

        private String queueName;
        private Long ttl;
        private IMessageQueueEvent event;

        public ShutdownListenerHandle(String queueName, Long ttl, IMessageQueueEvent event) {
            this.queueName = queueName;
            this.ttl = ttl;
            this.event = event;
        }

        @Override
        public void shutdownCompleted(ShutdownSignalException e) {
            try {
                IClient newClient = createClient(queueName, ttl, event);
                event.onClientInstance(newClient);
            } catch (NSException exp) {
                event.onError(exp);
            }
        }
    }

    @Override
    public IClient createClient(String queueName, Long ttl, IMessageQueueEvent event) throws NSException {
        try {
            Connection connection = factory.newConnection();
            Channel channel = connection.createChannel();

            Map<String, Object> args;
            if (ttl == null) {
                channel.queueDeclarePassive(queueName);
            } else {
                args = new HashMap<>();
                args.put("x-message-ttl", ttl);
                channel.queueDeclare(queueName, true, false, false, args);
            }

            channel.basicQos(1);
            ClientImpl client = new SingleConsumerClient(connection, channel);
            client.setConsumer(false, queueName, event);
            return client;

        } catch (Exception ex) {
            throw new NSException(ex);
        }
    }


    @Override
    public IClient createTopicClient(String exchangeName, String topicName, IMessageQueueEvent event) throws NSException {
        try {
            Connection connection = factory.newConnection();
            Channel channel = connection.createChannel();
            channel.exchangeDeclare(exchangeName, "direct");
            String queueName = channel.queueDeclare().getQueue();
            channel.queueBind(queueName, exchangeName, topicName);
            ClientImpl client = new TopicClient(connection, channel, exchangeName, queueName);
            client.setConsumer(true, queueName, event);
            return client;
        } catch (Exception ex) {
            throw new NSException(ex);
        }
    }

    @Override
    public IPublish createPublish(String exchangeName, String queueName, boolean distToAll, Long ttl)
            throws NSException {
        try {
            Connection connection = factory.newConnection();
            Channel channel = connection.createChannel();
            PublishImpl publish;
            if (distToAll) {
                channel.exchangeDeclare(exchangeName, "direct");
                publish = new TopicPublish(connection, channel, exchangeName);
            } else {
                Map<String, Object> args;
                if (ttl == null) {
                    channel.queueDeclare(queueName, true, false, false, null);
                } else {
                    args = new HashMap<>();
                    args.put("x-message-ttl", ttl);
                    channel.queueDeclare(queueName, true, false, false, args);
                }
                publish = new SingleConsumerPublish(connection, channel, exchangeName, queueName);
            }
            publish.start();
            return publish;
        } catch (Exception ex) {
            throw new NSException(ex);
        }
    }
}
