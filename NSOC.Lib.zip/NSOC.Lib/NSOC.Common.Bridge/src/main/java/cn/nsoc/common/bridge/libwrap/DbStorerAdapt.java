package cn.nsoc.common.bridge.libwrap;

import cn.nsoc.base.entity.container.NSDataMap;
import cn.nsoc.base.entity.sys.NSException;
import cn.nsoc.common.storer.db.DbInsertBuilder;
import cn.nsoc.common.storer.db.JdbcDbStorer;
import cn.nsoc.common.storer.option.InsertOption;
import cn.nsoc.common.storer.option.UpdateOperator;

import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.List;

/**
 * Created by bobwang on 10/24/16.
 */
public class DbStorerAdapt {
    JdbcDbStorer dbStorer;
    List<Object> objEntities;
    Class entityDef;


    public DbStorerAdapt(JdbcDbStorer storer, Class entity) {
        dbStorer = storer;
        entityDef = entity;

    }

    public void startBatch() {
        objEntities = new ArrayList<>();
    }

    Object convertValue(Class<?> dst, Object val) {
        if (val instanceof Integer) {
            if (dst.getName().compareTo(Long.class.getName()) == 0) {
                return Long.parseLong(val.toString());
            }
        } else if (val instanceof Long) {
            if (dst.getName().compareTo(Integer.class.getName()) == 0) {
                return Integer.parseInt(val.toString());
            }
        }
        return null;
    }

    public void insertEntity(NSDataMap<String, Object> dataMap) throws NSException {
        try {
            Object entity = entityDef.newInstance();
            Field[] fds = entity.getClass().getFields();

            for (Field fd : fds) {
                Object fdVal = dataMap.getOrDefault(fd.getName(), null);
                if (fdVal == null)
                    continue;

                fd.setAccessible(true);
                do {
                    try {
                        fd.set(entity, fdVal);
                        break;
                    } catch (Exception exp) {
                        if (!fdVal.getClass().equals(fd.getType())) {
                            Object convertVal = convertValue(fd.getType(), fdVal);
                            if (convertVal == null)
                                throw exp;

                            fd.set(entity, convertVal);
                            break;
                        }
                    }
                } while (true);
            }

            objEntities.add(entity);
        } catch (Exception ex) {
            throw new NSException(ex);
        }
    }

    public boolean closeStartBatch(List<String> accumulations, List<String> updates) throws NSException {
        boolean bRet;

        if (accumulations == null && updates == null) {
            bRet = dbStorer.batchInsert(objEntities);
        } else {
            DbInsertBuilder builder = new DbInsertBuilder(dbStorer);
            builder.setInsertOption(InsertOption.UpdateOnDuplicate);
            if (accumulations != null) {
                for (String accu : accumulations) {
                    builder.append(accu, UpdateOperator.Add);
                }
            }
            if (updates != null) {
                for (String update : updates) {
                    builder.append(update, UpdateOperator.Set);
                }
            }
            bRet = dbStorer.batchInsert(objEntities, builder);
        }
        objEntities.clear();
        objEntities = null;
        return bRet;
    }
}
