package cn.nsoc.common.bridge.ws;


import javax.xml.namespace.QName;
import javax.xml.rpc.Call;
import javax.xml.rpc.Service;
import javax.xml.rpc.ServiceException;
import javax.xml.rpc.ServiceFactory;

/**
 * Created by bobwang on 4/27/17.
 */
public class JAXClient {

    private String endpoint;
    private String bindingStyle;
    private String namespace;
    private String parameterStyle;
    private ServiceFactory serviceFactory;
    private Service service;
    private QName portQN;


    public JAXClient() {
        //empty
    }

    public void initialize(String bindingStyle, String parameterStyle, String endpoint, String ns, String svrName, String port) throws ServiceException {
        this.bindingStyle = bindingStyle;
        this.parameterStyle = parameterStyle;
        this.namespace = ns;
        this.endpoint = endpoint;
        QName svrDN = new QName(ns, svrName);
        portQN = new QName(ns, port);
        serviceFactory = ServiceFactory.newInstance();
        service = serviceFactory.createService(svrDN);
    }

    protected Call createCall(String operationName) throws ServiceException {

        Call call = service.createCall();

        call.setPortTypeName(portQN);
        call.setOperationName(new QName(namespace, operationName));
        call.setTargetEndpointAddress(endpoint);
        call.removeAllParameters();
        call.setProperty(Call.ENCODINGSTYLE_URI_PROPERTY, "");
        call.setProperty(Call.OPERATION_STYLE_PROPERTY, bindingStyle);
        call.setProperty(Call.OPERATION_STYLE_PROPERTY, parameterStyle);
        return call;
    }
}
