package cn.nsoc.common.bridge.dyncloader;

import cn.nsoc.common.util.Misc;
import org.apache.log4j.Logger;

import java.io.*;

/**
 * Created by bobwang on 10/24/16.
 */
public class FileSystemClassLoader extends ClassLoader {
    static final Logger logger = Logger.getLogger(FileSystemClassLoader.class);

    private String rootDir;

    public FileSystemClassLoader(String rootDir) {
        this.rootDir = rootDir;
    }

    @Override
    protected Class<?> findClass(String name) throws ClassNotFoundException {
        byte[] classData = getClassData(name);
        if ((classData == null) || classData.length == 0) {
            throw new ClassNotFoundException();
        } else {
            return defineClass(name, classData, 0, classData.length);
        }
    }

    private byte[] getClassData(String className) {
        String path = classNameToPath(className);
        try (InputStream ins = new FileInputStream(path)) {

            ByteArrayOutputStream baos = new ByteArrayOutputStream();
            int bufferSize = 1024;
            byte[] buffer = new byte[bufferSize];
            int bytesNumRead;
            while ((bytesNumRead = ins.read(buffer)) != -1) {
                baos.write(buffer, 0, bytesNumRead);
            }
            ins.close();
            return baos.toByteArray();
        } catch (IOException ignored) {
            logger.error(ignored.getMessage());
            Misc.ignoreException(ignored);
        }
        return new byte[]{};
    }

    private String classNameToPath(String className) {
        return rootDir + File.separatorChar
                + className.replace('.', File.separatorChar) + ".class";
    }
}
