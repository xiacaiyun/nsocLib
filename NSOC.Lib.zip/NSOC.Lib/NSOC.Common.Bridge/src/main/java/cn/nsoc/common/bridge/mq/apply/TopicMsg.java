package cn.nsoc.common.bridge.mq.apply;

import cn.nsoc.common.bridge.mq.entity.IOutMessage;

/**
 * Created by bobwang on 11/23/16.
 */
public class TopicMsg implements IOutMessage {
    private String routingKey;
    private String message;

    public TopicMsg(String key, String msg) {
        routingKey = key;
        message = msg;
    }

    public String getRoutingKey() {
        return routingKey;
    }

    public String getMessage() {
        return message;
    }
}
