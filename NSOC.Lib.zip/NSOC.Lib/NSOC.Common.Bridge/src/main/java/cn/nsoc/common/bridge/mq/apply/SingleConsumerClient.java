package cn.nsoc.common.bridge.mq.apply;

import cn.nsoc.common.bridge.mq.impl.ClientImpl;
import com.rabbitmq.client.Channel;
import com.rabbitmq.client.Connection;

/**
 * Created by bobwang on 11/23/16.
 */
public class SingleConsumerClient extends ClientImpl {

    public SingleConsumerClient(Connection conn, Channel ch) {
        super(conn, ch);
    }
}
