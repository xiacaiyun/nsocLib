package cn.nsoc.common.bridge.rule;


import cn.nsoc.base.entity.container.ObjectDictionary;
import cn.nsoc.base.entity.container.PropertyConfigure;
import cn.nsoc.base.entity.define.NSSystemDefine;
import cn.nsoc.base.entity.sys.NSException;
import cn.nsoc.common.util.JsonConverter;
import org.apache.log4j.Logger;
import org.springframework.util.StringUtils;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

/**
 * Created by bobwang on 12/20/16.
 */
public class WorkflowVisitor {

    interface INodeOper {
        void addNode(TreeNode node);
    }

    public static class TreeNode implements INodeOper {
        protected String flowName;
        protected String wfLibText;
        protected String wfClsText;
        protected PropertyConfigure wfProps;
        protected String psLibText;
        protected String psClsText;
        protected PropertyConfigure psProps;
        protected List<TreeNode> subs;

        public TreeNode(String name, String wfLib, String wfCls, PropertyConfigure props) {
            flowName = name;
            wfLibText = wfLib;
            wfClsText = wfCls;
            wfProps = props;
            subs = new ArrayList<>();
        }

        public void addPersistSetting(String psLib, String psCls, PropertyConfigure props) {
            psLibText = psLib;
            psClsText = psCls;
            psProps = props;
        }

        @Override
        public void addNode(TreeNode node) {
            subs.add(node);
        }

        public Iterable<TreeNode> enumNode() {
            return subs;
        }

        public boolean hasChild() {
            return !subs.isEmpty();
        }

        public String getFlowName() {
            return flowName;
        }

        public String getWfLib() {
            return wfLibText;
        }

        public String getWfCls() {
            return wfClsText;
        }

        public String getPsLib() {
            return psLibText;
        }

        public String getPsCls() {
            return psClsText;
        }

        public PropertyConfigure getWfProps() {
            return wfProps;
        }

        public PropertyConfigure getPsProps() {
            return psProps;
        }
    }

    public static class TreeRoot implements INodeOper {
        protected List<TreeNode> subs;

        public TreeRoot() {
            subs = new ArrayList<>();
        }

        @Override
        public void addNode(TreeNode node) {
            subs.add(node);
        }

        public Iterable<TreeNode> enumNode() {
            return subs;
        }
    }

    public static class Ret {
        private String name;
        private String storeType;
        private String table;

        public String getName() {
            return name;
        }

        public void setName(String name) {
            this.name = name;
        }

        public String getStoreType() {
            return storeType;
        }

        public void setStoreType(String storeType) {
            this.storeType = storeType;
        }

        public String getTable() {
            return table;
        }

        public void setTable(String table) {
            this.table = table;
        }
    }

    private Logger appLogger;

    public WorkflowVisitor() {
        appLogger = Logger.getLogger(WorkflowVisitor.class);
    }

    public TreeRoot visit(List<ObjectDictionary> dicts) {
        TreeRoot rootNode = new TreeRoot();
        genFlow(dicts, rootNode);
        return rootNode;
    }

    public TreeRoot visit(String jsonCfg) throws NSException {
        JsonConverter converter = new JsonConverter();
        return visit(converter.fromText(jsonCfg).getArrayObject("workflow"));
    }

    void enumTreeNode(Iterable<WorkflowVisitor.TreeNode> nodes, List<Ret> items) {
        for (WorkflowVisitor.TreeNode tn : nodes) {
            if ("cn.nsoc.nspider.analyzer.jsonsave.JsonSaveAnalyzer".equalsIgnoreCase(tn.getWfCls())) {
                Ret ret = new Ret();
                if (tn.getPsProps() != null) {
                    String name = tn.getFlowName();
                    if (StringUtils.hasText(name)) {
                        ret.setName(name);
                    }
                    String tbName = tn.getPsProps().getValAsString("table", "");
                    if (StringUtils.hasText(tbName)) {
                        ret.setTable(tbName);
                    }
                    String storeType = tn.getPsProps().getValAsString("store-type", "");
                    if (StringUtils.hasText(storeType)) {
                        ret.setStoreType(storeType);
                    }
                    items.add(ret);
                }
            }
            if (tn.hasChild()) {
                enumTreeNode(tn.enumNode(), items);
            }
        }
    }

    public List<Ret> getDyncTableNameList(String jsonCfg) throws NSException {
        TreeRoot rootNode = visit(jsonCfg);
        List<Ret> items = new ArrayList<>();
        enumTreeNode(rootNode.enumNode(), items);
        return items.stream().distinct().collect(Collectors.toList());
    }

    @SuppressWarnings("unchecked")
    boolean genFlow(List<ObjectDictionary> dicts, INodeOper nodeOper) {
        boolean bExec = true;
        for (ObjectDictionary subDict : dicts) {

            String flowName;
            String wfLibText;
            String wfClsText;
            String persistLibText;
            String persistClsText;
            PropertyConfigure wfProps = new PropertyConfigure(subDict.mapVals());

            flowName = wfProps.getValAsString("name", "");
            wfLibText = wfProps.getValAsString(NSSystemDefine.Object_Lib_Key);
            wfClsText = wfProps.getValAsString(NSSystemDefine.Object_Class_Key);

            TreeNode tn = new TreeNode(flowName, wfLibText, wfClsText, wfProps);

            if (wfProps.existKey("persist")) {
                ObjectDictionary persistDict = (ObjectDictionary) wfProps.getVal("persist");
                PropertyConfigure persistProps = new PropertyConfigure(persistDict.mapVals());
                if (persistProps.getValAsBoolean("enable", false)) {
                    persistLibText = persistProps.getValAsString(NSSystemDefine.Object_Lib_Key);
                    persistClsText = persistProps.getValAsString(NSSystemDefine.Object_Class_Key);
                    ObjectDictionary configDict = (ObjectDictionary) persistProps.getVal(NSSystemDefine.Object_Config_Key);
                    PropertyConfigure configProps = new PropertyConfigure(configDict.mapVals());
                    tn.addPersistSetting(persistLibText, persistClsText, configProps);
                }
            }

            if (wfProps.existKey("steps")) {
                List<ObjectDictionary> steps = (List<ObjectDictionary>) wfProps.getVal("steps");
                bExec = genFlow(steps, tn);
            }

            if (bExec) {
                nodeOper.addNode(tn);
            }

            if (!bExec) {
                appLogger.warn(String.format("workflow %s init break", flowName));
                break;
            }
        }
        return bExec;
    }
}
