package cn.nsoc.common.bridge.mq.apply;

import cn.nsoc.common.bridge.mq.entity.IOutMessage;

/**
 * Created by bobwang on 11/23/16.
 */
public class SingleConsumerMsg implements IOutMessage {
    private String message;

    public SingleConsumerMsg(String msg) {
        message = msg;
    }

    public String getMessage() {
        return message;
    }
}
