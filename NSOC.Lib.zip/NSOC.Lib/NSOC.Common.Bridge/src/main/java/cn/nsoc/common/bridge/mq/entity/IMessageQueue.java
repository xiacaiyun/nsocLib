package cn.nsoc.common.bridge.mq.entity;

import cn.nsoc.base.entity.sys.NSException;

/**
 * Created by bobwang on 11/22/16.
 */
public interface IMessageQueue {
    IFactory createFactory(String uri) throws NSException;

    IFactory createFactory(String host, int port, String virtualHost, String userName, String password) throws NSException;
}
