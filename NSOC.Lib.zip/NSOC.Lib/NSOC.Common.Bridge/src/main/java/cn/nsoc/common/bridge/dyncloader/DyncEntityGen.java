package cn.nsoc.common.bridge.dyncloader;

import cn.nsoc.base.entity.sys.NSException;
import cn.nsoc.common.storer.entity.MetaDesc;

import javax.tools.DiagnosticCollector;
import javax.tools.JavaCompiler;
import javax.tools.JavaFileObject;
import javax.tools.ToolProvider;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.math.BigDecimal;
import java.math.BigInteger;
import java.nio.file.Paths;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.Arrays;
import java.util.Collections;

/**
 * Created by bobwang on 10/24/16.
 */
public class DyncEntityGen {
    JavaCompiler compiler;

    public DyncEntityGen() {
        compiler = ToolProvider.getSystemJavaCompiler();
    }

    public Class genTableEntity(String tableName, String clsName, String outputPath, MetaDesc desc, boolean alwayNew) throws ClassNotFoundException, NSException {
        Class genCls = null;
        DiagnosticCollector<JavaFileObject> diagnostics = new DiagnosticCollector<>();
        FileSystemClassLoader loader = new FileSystemClassLoader(outputPath);
        if (!alwayNew) {
            if (Paths.get(outputPath, String.format("%s%s", clsName, ".class")).toFile().exists()) {
                genCls = loader.loadClass(clsName);
            }
        } else {
            StringWriter writer = new StringWriter();
            PrintWriter out = new PrintWriter(writer);

            out.println("import java.time.LocalDateTime;");
            out.println("import java.time.LocalDate;");
            out.println("import java.math.BigInteger;");
            out.println("import java.math.BigDecimal;");
            out.println("import cn.nsoc.common.storer.annotation.DbField;");
            out.println("import cn.nsoc.common.storer.annotation.DbTable;");
            out.println(String.format("@DbTable(name = \"%s\")", tableName));
            out.println(String.format("public class %s {", clsName));
            for (MetaDesc.ItemDesc iter : desc.getEntrys()) {
                if (iter.IsKey && iter.IsAutocrement) {
                    out.println("@DbField(isKey = true,isAutoIncrement = true)");
                } else if (iter.IsKey) {
                    out.println("@DbField(isKey = true,isAutoIncrement = false)");
                }
                String lan_Type = getLanType(iter.ItemType, iter.TypeSize);
                out.println(String.format("public %s %s;", lan_Type, iter.ItemName));
            }
            out.println("}");
            out.close();
            JavaFileObject file = new JavaSourceFromString(clsName, writer.toString());
            Iterable<? extends JavaFileObject> compilationUnits = Collections.singletonList(file);
            Iterable<String> options = Arrays.asList("-d", outputPath);

            JavaCompiler.CompilationTask task = compiler.getTask(null, null, diagnostics, options, null, compilationUnits);
            if (task.call()) {
                genCls = loader.loadClass(clsName);
                if (genCls == null) {
                    throw new NSException(String.format("gen cls %s, detail:%s", clsName, diagnostics.getDiagnostics().toString()));
                }
            }
        }
        return genCls;
    }

    String getLanType(String itemType, String maxSize) throws NSException {
        if (itemType.compareToIgnoreCase("char") == 0) {
            return String.class.getSimpleName();
        } else if (itemType.compareToIgnoreCase("varchar") == 0) {
            return String.class.getSimpleName();
        } else if (itemType.compareToIgnoreCase("datetime") == 0) {
            return LocalDateTime.class.getSimpleName();
        } else if (itemType.compareToIgnoreCase("date") == 0) {
            return LocalDate.class.getSimpleName();
        } else if (itemType.compareToIgnoreCase("int") == 0) {
            return Integer.class.getSimpleName();
        } else if (itemType.compareToIgnoreCase("timestamp") == 0) {
            return LocalDateTime.class.getSimpleName();
        } else if (itemType.compareToIgnoreCase("bigint") == 0) {
            return Long.class.getSimpleName();
        } else if (itemType.compareToIgnoreCase("MEDIUMTEXT") == 0) {
            return String.class.getSimpleName();
        } else if (itemType.compareToIgnoreCase("blob") == 0) {
            return String.class.getSimpleName();
        } else if (itemType.compareToIgnoreCase("varbinary") == 0
                && (maxSize != null && maxSize.compareToIgnoreCase("16") == 0)) {
            return BigInteger.class.getSimpleName();
        } else if (itemType.compareToIgnoreCase("text") == 0) {
            return String.class.getSimpleName();
        } else if (itemType.compareToIgnoreCase("json") == 0) {
            return String.class.getSimpleName();
        } else if (itemType.compareToIgnoreCase("tinyint") == 0) {
            return Integer.class.getSimpleName();
        } else if (itemType.compareToIgnoreCase("smallint") == 0) {
            return Integer.class.getSimpleName();
        } else if (itemType.compareToIgnoreCase("double") == 0) {
            return Double.class.getSimpleName();
        } else if (itemType.compareToIgnoreCase("decimal") == 0) {
            return BigDecimal.class.getSimpleName();
        }
        throw new NSException(String.format("database not support type. %s", itemType));
    }

}
