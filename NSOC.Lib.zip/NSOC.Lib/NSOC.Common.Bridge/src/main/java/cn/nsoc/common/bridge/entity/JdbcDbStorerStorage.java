package cn.nsoc.common.bridge.entity;

import cn.nsoc.base.entity.sys.IStorage;
import cn.nsoc.common.storer.db.JdbcDbStorer;


/**
 * Created by bobwang on 10/20/16.
 */
public class JdbcDbStorerStorage implements IStorage<JdbcDbStorer> {

    JdbcDbStorer dbStorer;

    public JdbcDbStorerStorage(JdbcDbStorer storer) {
        dbStorer = storer;
    }

    public static JdbcDbStorer convert(Object src) {
        if (src instanceof JdbcDbStorer) {
            return (JdbcDbStorer) src;
        }
        return null;
    }

    @Override
    public JdbcDbStorer get() {
        return dbStorer;
    }
}
