package cn.nsoc.common.bridge.mq.apply;

import cn.nsoc.common.bridge.mq.impl.ClientImpl;
import com.rabbitmq.client.Channel;
import com.rabbitmq.client.Connection;

import java.io.IOException;

/**
 * Created by bobwang on 11/23/16.
 */
public class TopicClient extends ClientImpl {

    String exchangeName;
    String queueName;

    public TopicClient(Connection conn, Channel ch, String exName, String queue) {
        super(conn, ch);
        queueName = queue;
        exchangeName = exName;
    }

    @Override
    public void subscribeTopic(String topic) throws IOException {
        channel.queueBind(queueName, exchangeName, topic);
    }

    @Override
    public void unSubscribeTopic(String topic) throws IOException {
        channel.queueBind(queueName, exchangeName, topic);
    }
}
