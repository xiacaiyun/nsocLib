package cn.nsoc.common.bridge.mq.entity;

import cn.nsoc.base.entity.sys.NSException;

/**
 * Created by bobwang on 11/22/16.
 */
public interface IPublish {
    void send(String message) throws NSException;

    void send(String routingKey, String message) throws NSException;

    void shutdown();
}
