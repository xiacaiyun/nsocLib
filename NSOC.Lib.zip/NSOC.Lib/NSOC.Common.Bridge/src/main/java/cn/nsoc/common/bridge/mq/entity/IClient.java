package cn.nsoc.common.bridge.mq.entity;

import java.io.IOException;

/**
 * Created by bobwang on 11/22/16.
 */
public interface IClient {
    void subscribeTopic(String topic) throws IOException;

    void unSubscribeTopic(String topic) throws IOException;

    void shutdown();
}
