package cn.nsoc.common.bridge.dyncloader;

import cn.nsoc.base.entity.sys.NSException;

import javax.tools.DiagnosticCollector;
import javax.tools.JavaCompiler;
import javax.tools.JavaFileObject;
import javax.tools.ToolProvider;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

/**
 * Created by sam on 17-2-12.
 */
public class DyncClass {

    JavaCompiler compiler;

    public DyncClass() {
        compiler = ToolProvider.getSystemJavaCompiler();
    }

    public Class genClass(String clsName, String javacode, String outputpath, String[] jars) throws NSException {
        Class genCls;

        DiagnosticCollector<JavaFileObject> diagnostics = new DiagnosticCollector<>();
        FileSystemClassLoader loader = new FileSystemClassLoader(outputpath);

        JavaFileObject file = new JavaSourceFromString(clsName, javacode);
        Iterable<? extends JavaFileObject> compilationUnits = Collections.singletonList(file);
        List<String> optionList = new ArrayList<>();

        optionList.addAll(Arrays.asList("-d", outputpath));

        if (jars != null) {
            optionList.addAll(Arrays.asList("-classpath", String.join(";", jars)));
        }


        JavaCompiler.CompilationTask task = compiler.getTask(null, null, diagnostics, optionList, null, compilationUnits);
        if (task.call()) {
            try {
                genCls = loader.loadClass(clsName);
            } catch (Exception ex) {
                throw new NSException(ex);
            }
            if (genCls == null) {
                throw new NSException(String.format("gen cls %s, detail:%s", clsName, diagnostics.getDiagnostics().toString()));
            }
        } else {
            throw new NSException(String.format("compile cls %s ,detail:%s", clsName, diagnostics.getDiagnostics().toString()));
        }
        return genCls;
    }

}
