package cn.nsoc.common.bridge.mq.entity;

import cn.nsoc.base.entity.sys.NSException;

/**
 * Created by bobwang on 11/22/16.
 */
public interface IFactory {
    IClient createClient(String queueName, Long ttl, IMessageQueueEvent event) throws NSException;

    IClient createTopicClient(String exchangeName, String topicName, IMessageQueueEvent event) throws NSException;

    IPublish createPublish(String exchangeName, String queueName, boolean distToAll, Long ttl) throws NSException;
}
