package cn.nsoc.common.bridge.mq.apply;

import cn.nsoc.base.entity.sys.NSException;
import cn.nsoc.common.bridge.mq.entity.IOutMessage;
import cn.nsoc.common.bridge.mq.impl.PublishImpl;
import com.rabbitmq.client.Channel;
import com.rabbitmq.client.Connection;

import java.io.IOException;

/**
 * Created by bobwang on 11/22/16.
 */
public class TopicPublish extends PublishImpl {

    String exName;

    public TopicPublish(Connection conn, Channel ch, String exchangeName) {
        super(conn, ch);
        exName = exchangeName;
    }

    @Override
    public void send(String routingKey, String message) throws NSException {
        prepareSend(new TopicMsg(routingKey, message));
    }

    @Override
    protected void onSend(IOutMessage msg) throws IOException {
        TopicMsg tpMsg = (TopicMsg) msg;
        channel.basicPublish(exName, tpMsg.getRoutingKey(), null, tpMsg.getMessage().getBytes(encoder));
    }
}
