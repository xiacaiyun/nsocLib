package cn.nsoc.base.entity.define;

/**
 * Created by bob.wang on 5/13/2016.
 */
public class NSExceptionCode {
    public static final int EXEC_OK  = 0;
    public static final int BaseMask = 0x8700000;


    public static final int Runtime_Error = 0x87010001;


    public static final int CommRangeBase            = 0x87020000;
    public static final int Com_UnKnown              = CommRangeBase + 1;
    public static final int Com_DuplicateArg         = CommRangeBase + 2;
    public static final int Com_WrongFormatArg       = CommRangeBase + 3;
    public static final int Com_Create_Storer        = CommRangeBase + 4;
    public static final int Com_Load_Jar_Failed      = CommRangeBase + 5;
    public static final int Com_Wrong_Biz_Type       = CommRangeBase + 6;
    public static final int Com_Load_Config_Failed   = CommRangeBase + 7;
    public static final int Com_Load_Regex_Failed    = CommRangeBase + 8;
    public static final int Com_Type_Convert_Failed  = CommRangeBase + 9;
    public static final int Com_Conveyor_Missing     = CommRangeBase + 10;
    public static final int Com_Expression_Wrong     = CommRangeBase + 11;
    public static final int Com_EXP_Oper_Wrong       = CommRangeBase + 12;
    public static final int Com_EXP_Exec_Wrong       = CommRangeBase + 13;
    public static final int Com_EXP_Right_Fmt_Wrong  = CommRangeBase + 14;
    public static final int Com_EXP_Param_Type_Wrong = CommRangeBase + 15;
    public static final int Com_Extern_Biz_Wrong     = CommRangeBase + 16;
    public static final int Com_Field_Missing        = CommRangeBase + 17;
    public static final int Com_Create_Object        = CommRangeBase + 18;
    public static final int Com_Time_Out             = CommRangeBase + 19;
    public static final int Com_Not_Implemented      = CommRangeBase + 20;

    public static final int BizRangeBase            = 0x87030000;
    public static final int Biz_Cache_Get_Failed    = BizRangeBase + 1;
    public static final int Biz_IPLoc_Config_Failed = BizRangeBase + 2;
    public static final int Biz_UAD_Load_Failed     = BizRangeBase + 3;
    public static final int Biz_IP_Setting_Failed   = BizRangeBase + 4;
    public static final int Biz_Type_Mismatch       = BizRangeBase + 5;


    public static final int ManagerRangeBase           = 0x87040000;
    public static final int Manager_TaskConfig_Missing = ManagerRangeBase + 1;

    public static final int AgentRangeBase              = 0x87050000;
    public static final int Agent_Channel_Open_Failed   = AgentRangeBase + 1;
    public static final int Agent_Read_Initialized      = AgentRangeBase + 2;
    public static final int Agent_Load_Jar_Failed       = AgentRangeBase + 3;
    public static final int Agent_Lib_Analyzer_NotFound = AgentRangeBase + 4;
    public static final int Agent_Lib_Persist_NotFound  = AgentRangeBase + 5;
    public static final int Agent_Load_Analyzer_Failed  = AgentRangeBase + 6;
    public static final int Agent_Load_Persist_Failed   = AgentRangeBase + 7;
    public static final int Agent_Request_Busy          = AgentRangeBase + 8;
    public static final int Agent_Channel_Init_Failed   = AgentRangeBase + 9;
    public static final int Agent_Read_Missing          = AgentRangeBase + 10;
    public static final int Agent_Analyzer_Missing      = AgentRangeBase + 11;
    public static final int Agent_Reader_Lib_Map        = AgentRangeBase + 12;
    public static final int Agent_Analyzer_Lib_Map      = AgentRangeBase + 13;
    public static final int Agent_Task_ID_Missing       = AgentRangeBase + 14;
    public static final int Agent_Cfg_File_Missing      = AgentRangeBase + 15;
    public static final int Agent_Date_Format           = AgentRangeBase + 16;
    public static final int Agent_Persist_Init_Failed   = AgentRangeBase + 17;

    public static final int ReaderRangeBase     = 0x87060000;
    public static final int Reader_Unknown_Type = ReaderRangeBase + 1;

    public static final int PersistRangeBase          = 0x87070000;
    public static final int Persist_Init_Failed       = PersistRangeBase + 1;
    public static final int Persist_Open_Failed       = PersistRangeBase + 2;
    public static final int Persist_Save_Failed       = PersistRangeBase + 3;
    public static final int Persist_Driver_Wrong      = PersistRangeBase + 4;
    public static final int Persist_Address_Wrong     = PersistRangeBase + 5;
    public static final int Persist_Account_Wrong     = PersistRangeBase + 6;
    public static final int Persist_Password_Wrong    = PersistRangeBase + 7;
    public static final int Persist_InitialSize_Wrong = PersistRangeBase + 8;
    public static final int Persist_Entity_Wrong      = PersistRangeBase + 9;
    public static final int Persist_Storer_Wrong      = PersistRangeBase + 10;
    public static final int Persist_Rule_Wrong        = PersistRangeBase + 11;

    public static final int WorkerRangBase             = 0x87080000;
    public static final int Worker_ID_Missing          = WorkerRangBase + 1;
    public static final int Worker_Sync_Failed         = WorkerRangBase + 2;
    public static final int Worker_Store_Cfg_Fmt       = WorkerRangBase + 3;
    public static final int Worker_Set_Guard           = WorkerRangBase + 4;
    public static final int Worker_Store_Cfg_Missing   = WorkerRangBase + 5;
    public static final int Worker_Sync_Task           = WorkerRangBase + 6;
    public static final int Worker_Fetch_Task          = WorkerRangBase + 7;
    public static final int Worker_Sync_Processor      = WorkerRangBase + 8;
    public static final int Worker_Fetch_Processor     = WorkerRangBase + 9;
    public static final int Worker_Init_No_Set         = WorkerRangBase + 10;
    public static final int Worker_No_Channel          = WorkerRangBase + 11;
    public static final int Worker_Analyzer_Failed     = WorkerRangBase + 12;
    public static final int Worker_Persist_Failed      = WorkerRangBase + 13;
    public static final int Worker_Workflow_Failed     = WorkerRangBase + 14;
    public static final int Worker_Task_Type_Missing   = WorkerRangBase + 15;
    public static final int Worker_Channel_Open_Failed = WorkerRangBase + 16;
    public static final int Worker_Profile_Missing     = WorkerRangBase + 17;
    public static final int Worker_Profile_Wrong       = WorkerRangBase + 18;

    public static final int ReaderRangBase        = 0x87090000;
    public static final int Reader_ParserID_Bad   = ReaderRangBase + 1;
    public static final int Reader_Fetch_Group_ID = ReaderRangBase + 2;
    public static final int Reader_Type_Mismatch  = ReaderRangBase + 3;

    public static final int AnalyzerRangbase           = 0x870A0000;
    public static final int Analyzer_Init_Failed       = AnalyzerRangbase + 1;
    public static final int Analyzer_Transfor_Failed   = AnalyzerRangbase + 2;
    public static final int Analyzer_Type_Mismatch     = AnalyzerRangbase + 3;
    public static final int Analyzer_Cond_Wrong        = AnalyzerRangbase + 4;
    public static final int Analyzer_Object_Type_Wrong = AnalyzerRangbase + 5;
    public static final int Analyzer_Param_Wrong       = AnalyzerRangbase + 6;
    public static final int Analyzer_RuleCond_Not      = AnalyzerRangbase + 7;
    public static final int Analyzer_TimeHour_Out      = AnalyzerRangbase + 8;
    public static final int Analyzer_TimeMinte_Out     = AnalyzerRangbase + 9;
    public static final int Analyzer_Siems_WorkChecker = AnalyzerRangbase + 10;
    public static final int Analyzer_Siems_WeekParse   = AnalyzerRangbase + 11;
    public static final int Analyzer_Siems_UnDefine    = AnalyzerRangbase + 12;
    public static final int Analyzer_Proxy_Init        = AnalyzerRangbase + 13;

    public static final int ES_RANGE_BASE  = 0x87100000;
    public static final int ES_INIT_FAILED = ES_RANGE_BASE + 1;
    public static final int ES_EXEC_FAILED = ES_RANGE_BASE + 2;

    public static final int SPIDER_MON_RANGE_BASE      = 0x87101000;
    public static final int SPIDER_MON_INIT_FAILED     = SPIDER_MON_RANGE_BASE + 1;
    public static final int SPIDER_MON_INIT_DATALOAD   = SPIDER_MON_RANGE_BASE + 2;
    public static final int SPIDER_MON_TYPE_UNKNOWN    = SPIDER_MON_RANGE_BASE + 3;
    public static final int SPIDER_MON_DETECT_UNNORMAL = SPIDER_MON_RANGE_BASE + 4;
    public static final int SPIDER_MON_FIELD_MISSING   = SPIDER_MON_RANGE_BASE + 5;
    public static final int SPIDER_MON_JS_EXCEPTION    = SPIDER_MON_RANGE_BASE + 6;
    public static final int SPIDER_MON_JSCODE_ERROR    = SPIDER_MON_RANGE_BASE + 7;
    public static final int SPIDER_MON_CHECK_EXCEPTION = SPIDER_MON_RANGE_BASE + 8;

    public static final int WEB_WEBEYE_RANGE_BASE  = 0x87110000;
    public static final int WEB_WEBEYE_STATIC_OVER = WEB_WEBEYE_RANGE_BASE + 1;
    public static final int WEB_WEBEYE_STATIC_LESS = WEB_WEBEYE_RANGE_BASE + 2;


    public static final String MSG_NOTSUITABLE    = "not suitable for this storer";
    public static final String MSG_NOTIMPLEMENTED = "not implemented";
}
