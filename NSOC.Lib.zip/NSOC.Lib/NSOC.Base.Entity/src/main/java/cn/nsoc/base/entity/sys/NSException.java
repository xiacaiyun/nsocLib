package cn.nsoc.base.entity.sys;

import cn.nsoc.base.entity.define.NSExceptionCode;

/**
 * Created by bob.wang on 5/13/2016.
 */
public class NSException extends Exception {
    private final int expCode;

    public NSException(int code) {
        super();
        expCode = code;
    }

    public NSException(int code, Exception orgExp) {
        super(orgExp);
        expCode = code;
    }

    public NSException(int code, String message) {
        super(message);
        expCode = code;
    }

    public NSException(Exception ex) {
        this(NSExceptionCode.Runtime_Error, ex);
    }


    public NSException(String message) {
        this(NSExceptionCode.Runtime_Error, message);
    }

    @Override
    public String toString() {
        return String.format("errCode: %x . info:%s", expCode, this.getMessage());
    }
}
