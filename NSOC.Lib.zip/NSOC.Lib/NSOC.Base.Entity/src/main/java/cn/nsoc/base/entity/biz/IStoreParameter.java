package cn.nsoc.base.entity.biz;

/**
 * Created by bobwang on 10/17/16.
 */
public interface IStoreParameter {
    String getDriverClassName();

    String getAddress();

    String getAccount();

    String getPassword();

    int getInitialSize();

    String getMoreSetting();
}
