package cn.nsoc.base.entity.tuple;

/**
 * Created by sam on 17-7-13.
 */

public class Tuple4<A, B, C, D> extends Tuple3<A, B, C> {

    private final D d;

    public Tuple4(A a, B b, C c, D d) {
        super(a, b, c);
        this.d = d;
    }

    public D getD() {
        return d;
    }
}
