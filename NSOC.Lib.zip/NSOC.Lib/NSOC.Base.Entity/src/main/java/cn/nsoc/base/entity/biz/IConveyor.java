package cn.nsoc.base.entity.biz;


import cn.nsoc.base.entity.define.NSExceptionCode;
import cn.nsoc.base.entity.sys.NSException;

import java.util.List;
import java.util.Set;

/**
 * Created by bobwang on 11/5/16.
 */

public interface IConveyor<T, U, R> {
    // T: key
    // U: result
    // R: user parameter
    U search(R key) throws NSException;

    default U search(R partialKey1, R partialKey2) throws NSException{
        throw new NSException(NSExceptionCode.MSG_NOTIMPLEMENTED);
    }

    default U search(R[] partialKeys) throws NSException{
        throw new NSException(NSExceptionCode.MSG_NOTIMPLEMENTED);
    }

    default List<U> searchMutiple(Set<R> keys) throws NSException{
        throw new NSException(NSExceptionCode.MSG_NOTIMPLEMENTED);
    }

    default List<U> getValues() throws NSException{
        throw new NSException(NSExceptionCode.MSG_NOTIMPLEMENTED);
    }

    default List<T> getKeys() throws NSException{
        throw new NSException(NSExceptionCode.MSG_NOTIMPLEMENTED);
    }

    void remove(R key) throws NSException;
}
