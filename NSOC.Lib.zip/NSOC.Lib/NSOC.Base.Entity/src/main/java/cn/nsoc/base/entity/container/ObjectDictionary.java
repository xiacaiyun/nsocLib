package cn.nsoc.base.entity.container;

import org.apache.commons.lang3.tuple.ImmutablePair;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Map;

/**
 * Created by bobwang on 10/13/16.
 */
public class ObjectDictionary {
    private Map<String, Object> singleCache;
    private List<String> arrayCache;

    public ObjectDictionary() {
        singleCache = new StringHashMap<>();
        arrayCache = new ArrayList<>();
    }

    public static List<ImmutablePair<String, Object>> convertToList(ObjectDictionary org) {
        List<ImmutablePair<String, Object>> items = new ArrayList<>();
        for (Map.Entry<String, Object> iter : org.singleCache.entrySet()) {
            items.add(new ImmutablePair<>(iter.getKey(), iter.getValue()));
        }
        return items;
    }

    public int getDictSize() {
        return singleCache.size();
    }

    public int getArraySize() {
        return arrayCache.size();
    }

    public void setItem(String key, Object val) {
        singleCache.put(key, val);
    }

    public void setList(String key, List<ObjectDictionary> objects) {
        singleCache.put(key, objects);
    }

    public void setObject(String key, ObjectDictionary sub) {
        singleCache.put(key, sub);
    }

    public void setArrayItem(String val) {
        arrayCache.add(val);
    }

    public boolean existKey(String key) {
        return singleCache.containsKey(key);
    }

    public String getValAsString(String key) {
        Object v = singleCache.get(key);
        return (v == null) ? null : v.toString();
    }

    public String getValAsString(String key, String defVal) {

        Object v = singleCache.getOrDefault(key, defVal);
        return (v == null) ? defVal : v.toString();
    }

    public boolean getValAsBoolean(String key) {
        String val = getValAsString(key);
        return (val.compareToIgnoreCase("true") == 0);
    }

    public boolean getValAsBoolean(String key, boolean defVal) {
        String val = getValAsString(key, "");
        try {
            return Boolean.valueOf(val);
        } catch (Exception exp) {
            ignoreException(exp);
            return defVal;
        }

    }

    private void ignoreException(Exception ex) {
        // for sonar
    }

    public int getValAsInt(String key) {
        String val = getValAsString(key);
        return Integer.valueOf(val);
    }

    public int getValAsInt(String key, int defVal) {
        String val = getValAsString(key, "");
        if (val == null || val.trim().length() == 0) {
            return defVal;
        }
        try {
            return Integer.valueOf(val);
        } catch (NumberFormatException exp) {
            return defVal;
        }
    }


    public ObjectDictionary getMapObject(String key) {
        Object target = singleCache.getOrDefault(key, null);
        if (target != null) {
            return (ObjectDictionary) target;
        }
        return null;
    }

    @SuppressWarnings("unchecked")
    public List<ObjectDictionary> getArrayObject(String key) {
        Object target = singleCache.getOrDefault(key, null);
        if (target != null) {
            return (List<ObjectDictionary>) target;
        }
        return Collections.emptyList();
    }

    public Map<String, Object> mapVals() {
        return singleCache;
    }

    public Object getMapVal(String key) {
        return singleCache.getOrDefault(key, null);
    }

    public List<String> arrayVals() {
        return arrayCache;
    }

}