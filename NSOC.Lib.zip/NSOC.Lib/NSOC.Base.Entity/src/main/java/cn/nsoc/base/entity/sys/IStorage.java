package cn.nsoc.base.entity.sys;

/**
 * Created by bobwang on 10/20/16.
 */
public interface IStorage<T> {
    T get();
}
