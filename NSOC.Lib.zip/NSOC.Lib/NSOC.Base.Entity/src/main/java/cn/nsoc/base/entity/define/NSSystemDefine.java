package cn.nsoc.base.entity.define;

import java.time.format.DateTimeFormatter;

/**
 * Created by bob.wang on 5/16/2016.
 */
public class NSSystemDefine {

    public static final String Log_Level_Info = "info";
    public static final String Log_Level_Error = "error";
    public static final String Log_Level_Warning = "warning";
    public static final String Log_Level_Debug = "debug";

    public static final String Object_Lib_Key = "lib";
    public static final String Object_Class_Key = "cls";
    public static final String Object_Config_Key = "config";

    public static final String Log_Pattern_Default = "'.'yyyy-MM-dd";

    public static final DateTimeFormatter Task_DateTime_Fmt = DateTimeFormatter.ISO_LOCAL_DATE_TIME;


}
