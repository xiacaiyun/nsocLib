package cn.nsoc.base.entity.container;

import com.google.common.primitives.Ints;

import java.util.Map;

/**
 * Created by bobwang on 6/2/16.
 */
public class PropertyConfigure {
    Map<String, Object> props;

    public PropertyConfigure() {
        props = new StringHashMap<>();
    }

    public PropertyConfigure(int capacity) {
        props = new StringHashMap<>(capacity);
    }

    public PropertyConfigure(Map<String, Object> props) {
        this.props = props;
    }

    public Object getVal(String key) {
        return props.get(key);
    }

    public Object getVal(String key, Object defVal) {
        return props.getOrDefault(key, defVal);
    }

    public void putVal(String key, Object val) {
        props.put(key, val);
    }

    public String getValAsString(String key, String defVal) {
        if (props.containsKey(key)) {
            return props.get(key).toString();
        }
        return defVal;
    }

    public String getValAsString(String key) {
        return props.get(key).toString();
    }

    public Integer getValAsInteger(String key) {
        return Ints.tryParse(props.get(key).toString());
    }


    public Integer getValAsInteger(String key, int defVal) {
        if (props.containsKey(key)) {
            Integer ret = Ints.tryParse(props.get(key).toString());
            if (ret != null) {
                return ret;
            }
        }
        return defVal;
    }

    public boolean getValAsBoolean(String key) {
        return Boolean.valueOf(props.get(key).toString());
    }

    public boolean getValAsBoolean(String key, boolean defVal) {
        if (props.containsKey(key)) {
            return Boolean.valueOf(props.get(key).toString());
        }
        return defVal;
    }

    public ObjectDictionary getValAsDict(String key) {

        Object val = getVal(key, null);
        if (val == null)
            return null;
        if (val instanceof ObjectDictionary) {
            return (ObjectDictionary) val;
        } else
            return null;
    }

    public boolean existKey(String key) {
        return props.containsKey(key);
    }
}
