package cn.nsoc.base.entity.container;

import java.util.Map;

/**
 * Created by bobwang on 10/18/16.
 */
public class NSDataMap<T, U> {
    Map<T, U> container;

    public NSDataMap(Map<T, U> map) {
        container = map;
    }

    public void put(T key, U val) {
        container.put(key, val);
    }

    public Map<T, U> getEntry() {
        return container;
    }

    public U get(T key) {
        return container.get(key);
    }

    public U getOrDefault(T key, U defVal) {
        return container.getOrDefault(key, defVal);
    }

    public boolean isEmpty() {
        return container.isEmpty();
    }

    public void clear() {
        container.clear();
    }

}
