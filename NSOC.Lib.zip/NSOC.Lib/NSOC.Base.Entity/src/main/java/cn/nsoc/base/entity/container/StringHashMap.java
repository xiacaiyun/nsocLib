package cn.nsoc.base.entity.container;


import java.util.HashMap;

/**
 * Created by bobwang on 11/11/16.
 */
public class StringHashMap<V> extends HashMap<String, V> {

    public StringHashMap() {
        super();
    }

    public StringHashMap(int capacity) {
        super(capacity);
    }

    @Override
    public V get(Object key) {
        if (key instanceof String) {
            return super.get(((String) key).toLowerCase());
        }
        return null;
    }

    @Override
    public V getOrDefault(Object key, V defaultValue) {
        if (key instanceof String) {
            return super.getOrDefault(((String) key).toLowerCase(), defaultValue);
        }
        return null;
    }

    @Override
    public boolean containsKey(Object key) {
        return key instanceof String && super.containsKey(((String) key).toLowerCase());
    }

    @Override
    public V put(String key, V value) {
        return super.put(key.toLowerCase(), value);
    }

    @Override
    public V remove(Object key) {
        if (key instanceof String) {
            return super.remove(((String) key).toLowerCase());
        }
        return null;
    }

    @Override
    public V putIfAbsent(String key, V value) {
        return super.putIfAbsent(key.toLowerCase(), value);
    }

    @Override
    public boolean remove(Object key, Object value) {
        return key instanceof String && super.remove(((String) key).toLowerCase(), value);
    }
}
