package cn.nsoc.common.util;

/**
 * Created by fengweiwei on 10/12/16.
 */
public class ExportHelper {

    public enum ExportType {

        Excel(0),
        Pdf(1);

        public final int val;

        ExportType(int val) {
            this.val = val;
        }
    }


    public static final int MaxExcelCount = 10000;
    public static final String MIME_EXCEL = "application/vnd.ms-excel";
    public static final String CELL_COLUMN = "<td style=\"mso-number-format:'\\@';\">%s</td>";

    public static String BuildDownLoadHtml(String strbody) {
        StringBuilder sb = new StringBuilder();
        sb.append("<html lang='zh'><head>");
        sb.append("<meta http-equiv='Content-Type' content='text/html; charset=utf-8' /><meta charset='utf-8' /></head>");
        sb.append(String.format("<body>%s</body>", strbody));
        sb.append("</html>");
        return sb.toString();
    }
}
