package cn.nsoc.common.util;

import cn.nsoc.base.entity.sys.NSException;
import org.springframework.util.Base64Utils;

import javax.crypto.Cipher;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;

/**
 * Created by sam on 16-6-11.
 */
public class AESCryptServiceProvider {

    private AESCryptServiceProvider() {

    }

    public static String encrypt(String text, String key, byte[] machinekey) throws NSException {
        return encrypt(text, Misc.hexStringToByteArray(key), machinekey);
    }


    public static String encrypt(String text, byte[] key, byte[] machinekey) throws NSException {
        if ((key == null) || (key.length != 16))
            throw new NSException("key 应该为32位16进制字符串");


        try {
            Cipher cipher = Cipher.getInstance("AES/CBC/PKCS5Padding");
            cipher.init(Cipher.ENCRYPT_MODE, new SecretKeySpec(key, "AES"), new IvParameterSpec(machinekey));
            byte[] bytes = cipher.doFinal(text.getBytes());

            return Base64Utils.encodeToString(bytes);
        } catch (Exception ex) {
            throw new NSException(ex);
        }
    }


    public static String decrypt(String encrypttext, String key, byte[] machinekey) throws NSException {
        return decrypt(encrypttext, Misc.hexStringToByteArray(key), machinekey);
    }

    public static String decrypt(String encrypttext, byte[] key, byte[] machinekey) throws NSException {
        if ((key == null) || (key.length != 16))
            throw new NSException("key 应该为32位16进制字符串");

        try {
            Cipher cipher = Cipher.getInstance("AES/CBC/PKCS5Padding");
            cipher.init(Cipher.DECRYPT_MODE, new SecretKeySpec(key, "AES"), new IvParameterSpec(machinekey));
            byte[] deBytes = cipher.doFinal(Base64Utils.decodeFromString(encrypttext));

            return new String(deBytes, "UTF-8");
        } catch (Exception ex) {
            throw new NSException(ex);
        }
    }
}
