package cn.nsoc.common.util;

import java.util.List;
import java.util.Map;

/**
 * Created by sam on 17-9-19.
 */
public class MapHelper {

    private MapHelper(){

    }

    public static Map<String,Object> getMapValue(Map<String,Object> map, String name){
        if (map == null) {
            return null;
        }
        return (Map<String,Object>)map.getOrDefault(name,null);
    }

    public static Map<String,Object> getMapValue(List<Map<String,Object>> list,int index){
        if (list == null) {
            return null;
        }

        if ((index< 0) || (index >= list.size() )) {
            return null;
        }

        return list.get(index);
    }

    public static List<Map<String,Object>> getMapValueArray(Map<String,Object> map,String name){
        if (map == null) {
            return null;
        }

        return (List<Map<String,Object>>)map.getOrDefault(name,null);
    }

    public static List<Map<String,Object>> getMapValueArray(List<Map<String,Object>> list,int index){
        if (list == null) {
            return null;
        }

        if ((index< 0) || (index >= list.size() )) {
            return null;
        }

        return (List<Map<String,Object>>)list.get(index);
    }
}
