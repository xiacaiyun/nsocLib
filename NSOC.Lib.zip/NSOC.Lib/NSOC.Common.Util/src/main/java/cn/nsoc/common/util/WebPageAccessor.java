package cn.nsoc.common.util;

import cn.nsoc.base.entity.sys.NSException;
import org.apache.http.HttpEntity;
import org.apache.http.HttpStatus;
import org.apache.http.client.ResponseHandler;
import org.apache.http.client.config.RequestConfig;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.util.EntityUtils;
import org.springframework.util.StringUtils;

import java.io.IOException;

/**
 * Created by bobwang on 12/19/16.
 */
public class WebPageAccessor {

    public static class PageResponse {
        private String pageBody;
        private int statusCode;
        private boolean bIsHtml;

        public PageResponse(int code) {
            statusCode = code;
        }

        public void setBody(String body) {
            pageBody = body;
        }

        public String getPageBody() {
            return pageBody;
        }

        public void setIsHtml(boolean isHtml) {
            bIsHtml = isHtml;
        }

        public boolean isHtml() {
            return bIsHtml;
        }
    }

    // url: like as http://www.baidu.com/
    // connectionRequestTimeout: 60000 is equal to 1 min
    public PageResponse visit(String url, int connectionRequestTimeout) throws NSException {
        CloseableHttpClient httpclient = HttpClients.createDefault();
        try {
            HttpGet httpget = new HttpGet(url);

            RequestConfig requestConfig = RequestConfig.custom()
                    .setRedirectsEnabled(true)
                    .setConnectionRequestTimeout(connectionRequestTimeout)
                    .build();

            httpget.setConfig(requestConfig);

            httpget.setHeader("User-Agent", "nsoc nsprider");
            httpget.setHeader("Accept", "*/*");
            httpget.setHeader("Accept-Charset", "GBK,utf-8;q=0.7,*;q=0.3");
            httpget.setHeader("Accept-Encoding", "gzip,deflate");
            httpget.setHeader("Accept-Language", "zh-CN,zh;q=0.8");

            // Create a custom response handler
            ResponseHandler<PageResponse> responseHandler = response -> {
                String contType = response.getEntity().getContentType().getValue();
                int status = response.getStatusLine().getStatusCode();
                PageResponse pageResponse = new PageResponse(status);
                if (status == HttpStatus.SC_OK) {
                    HttpEntity entity = response.getEntity();
                    String body = entity != null ? EntityUtils.toString(entity) : "";
                    pageResponse.setIsHtml(body.toLowerCase().contains("html"));
                    pageResponse.setBody(StringUtils.hasText(body) ? body : null);
                }
                return pageResponse;
            };
            return httpclient.execute(httpget, responseHandler);
        } catch (IOException exp) {
            throw new NSException(exp);
        } finally {
            try {
                httpclient.close();
            } catch (IOException ignored) {
                Misc.ignoreException(ignored);
            }
        }
    }
}
