package cn.nsoc.common.util;

import cn.nsoc.base.entity.sys.NSException;
import org.springframework.util.Assert;

/**
 * Created by sam on 16-7-4.
 */
public class IntEncoder {

    private static char[] chars36 = "0123456789abcdefghijklmnopqrstuvwxyz".toCharArray();
    private static char[] chars62 = "0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ".toCharArray();

    private IntEncoder() {

    }

    public static String encode36(long num) {
        return encode(num, chars36, -1);
    }

    public static String encode36(long num, int minlen) {
        return encode(num, chars36, minlen);
    }

    public static String encode62(long num) {
        return encode(num, chars62, -1);
    }

    public static String encode62(long num, int minlen) {
        return encode(num, chars62, minlen);
    }


    private static String encode(long num, char[] arr, int minlen) {
        if (num < 0)
            throw new IllegalArgumentException("不能是负数！");

        StringBuilder sb = new StringBuilder();
        long tempnum = num;

        for (; tempnum > 0; tempnum /= arr.length) {
            sb.insert(0, arr[(int) (tempnum % arr.length)]);
        }

        if (minlen > sb.length()) {
            int temp = minlen - sb.length();
            for (int i = 0; i < temp; i++) {
                sb.insert(0, "0");
            }
        }
        return sb.toString();
    }

    public static long decode36(String str) throws NSException {
        Assert.hasText(str);
        return decode(str.toLowerCase(), chars36);
    }

    public static long decode62(String str) throws NSException {
        Assert.hasText(str);
        return decode(str, chars62);
    }


    private static long decode(String str, char[] arr) throws NSException {
        long num = 0;
        for (char ch : str.trim().toCharArray()) {
            long temp;
            if ((ch <= '9') && (ch >= '0'))
                temp = (long) (ch - '0');
            else if (ch <= 'Z' && ch >= 'A')
                temp = (long) ((ch - 'A') + 36);
            else if ((ch <= 'z') && (ch >= 'a'))
                temp = (long) ((ch - 'a') + 10);
            else
                throw new NSException("格式不正确!");

            num = num * arr.length + temp;
        }
        return num;
    }

}