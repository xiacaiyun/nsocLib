package cn.nsoc.common.util;

import cn.nsoc.base.entity.sys.NSException;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.dom4j.Document;
import org.dom4j.DocumentHelper;
import org.dom4j.Element;
import org.springframework.util.Assert;
import org.springframework.util.Base64Utils;
import org.springframework.util.StringUtils;

import javax.crypto.Cipher;
import java.math.BigInteger;
import java.security.*;
import java.security.interfaces.RSAPrivateCrtKey;
import java.security.spec.RSAPrivateKeySpec;
import java.security.spec.RSAPublicKeySpec;

/**
 * Created by sam on 16-6-4.
 */
public class RSACryptoServiceProvider {

    private static final Log logger = LogFactory.getLog(RSACryptoServiceProvider.class);

    private byte[] modulusElem;
    private byte[] dElem;
    private byte[] p;
    private byte[] q;
    private byte[] dp;
    private byte[] dq;
    private byte[] inverseq;
    private byte[] d;

    public String encrypt(String data) {

        Assert.notNull(modulusElem);
        Assert.notNull(dElem);

        BigInteger modulus = new BigInteger(1, modulusElem);
        BigInteger tempd = new BigInteger(1, dElem);


        try {


//          C# ==> use fOAEP = false
//            fOAEP
//            类型： System.Boolean
//            如果为 true 则使用 OAEP 填充执行直接 RSA 加密；否则为 false 以使用 PKCS#1 v1.5 填充。

            KeyFactory factory = KeyFactory.getInstance("RSA");
            RSAPublicKeySpec keyspec = new RSAPublicKeySpec(modulus, tempd);
            PublicKey publicKey = factory.generatePublic(keyspec);

            Cipher cipher = Cipher.getInstance("RSA/ECB/PKCS1Padding");
            cipher.init(Cipher.ENCRYPT_MODE, publicKey);
            byte[] enBytes = cipher.doFinal(data.getBytes("UTF-8"));

            return Base64Utils.encodeToString(enBytes);

        } catch (Exception e) {
            Misc.ignoreException(e);
            return null;
        }
    }


    public String decyrpt(String data) {

        Assert.notNull(modulusElem);
        Assert.notNull(d);

        BigInteger modulus = new BigInteger(1, modulusElem);
        BigInteger dd = new BigInteger(1, this.d);


        try {
            KeyFactory factory = KeyFactory.getInstance("RSA");
            RSAPrivateKeySpec privateKeySpec = new RSAPrivateKeySpec(modulus, dd);
            PrivateKey privateKey = factory.generatePrivate(privateKeySpec);
            Cipher cipher = Cipher.getInstance("RSA/ECB/PKCS1Padding");
            cipher.init(Cipher.DECRYPT_MODE, privateKey);
            byte[] deBytes = cipher.doFinal(Base64Utils.decodeFromString(data));

            return new String(deBytes, "UTF-8");

        } catch (Exception e) {
            Misc.ignoreException(e);
            return null;
        }
    }

    public String sign(String data) {

        Assert.notNull(modulusElem);
        Assert.notNull(dElem);

        BigInteger modulus = new BigInteger(1, modulusElem);
        BigInteger tempd = new BigInteger(1, dElem);


        try {

            KeyFactory factory = KeyFactory.getInstance("RSA");

            RSAPrivateKeySpec privateKeySpec = new RSAPrivateKeySpec(modulus, tempd);
            PrivateKey privateKey = factory.generatePrivate(privateKeySpec);

            Signature signature = Signature.getInstance("SHA1withRSA");
            signature.initSign(privateKey);
            signature.update(data.getBytes("UTF-8"));
            byte[] signedBytes = signature.sign();

            return Base64Utils.encodeToString(signedBytes);

        } catch (Exception e) {
            Misc.ignoreException(e);
            return null;
        }
    }

    private byte[] parseValue(Element topElement, String key) {
        Element ele = topElement.element(key);
        if (ele == null)
            return null;
        String stringValue = ele.getStringValue();
        if (!StringUtils.hasText(stringValue))
            return null;
        return Base64Utils.decodeFromString(StringUtils.trimWhitespace(stringValue));
    }

    public boolean verifyData(byte[] data, byte[] signature) throws NSException {
        Assert.notNull(modulusElem);
        Assert.notNull(dElem);

        BigInteger modulus = new BigInteger(1, modulusElem);
        BigInteger d = new BigInteger(1, dElem);

        try {
            KeyFactory factory = KeyFactory.getInstance("RSA");
            RSAPublicKeySpec keyspec = new RSAPublicKeySpec(modulus, d);
            PublicKey publicKey = factory.generatePublic(keyspec);

            Signature sig = Signature.getInstance("SHA1withRSA");
            sig.initVerify(publicKey);
            sig.update(data);
            return sig.verify(signature);

        } catch (Exception e) {
            throw new NSException(e);
        }
    }

    public void fromXmlString(String xmlString) throws NSException {
        if (xmlString == null)
            throw new NSException("xmlString");

        try {
            Document doc = DocumentHelper.parseText(xmlString);
            Element topElement = doc.getRootElement();

            this.modulusElem = parseValue(topElement, "Modulus");
            Assert.notNull(modulusElem, "InvalidFromXmlString RSA Modulus");

            // Exponent is always present

            this.dElem = parseValue(topElement, "Exponent");
            Assert.notNull(dElem, "InvalidFromXmlString RSA Exponent");


            // P is optional
            this.p = parseValue(topElement, "P");

            // Q is optional
            this.q = parseValue(topElement, "Q");

            // DP is optional
            this.dp = parseValue(topElement, "DP");

            // DQ is optional
            this.dq = parseValue(topElement, "DQ");

            // InverseQ is optional
            this.inverseq = parseValue(topElement, "InverseQ");

            // D is optional
            this.d = parseValue(topElement, "D");
        } catch (Exception ex) {
            throw new NSException(ex);
        }
    }

    private void createNewKey() throws NSException {
        try {
            KeyPairGenerator keyPairGen = KeyPairGenerator.getInstance("RSA");
            keyPairGen.initialize(1024);

            long dt = System.currentTimeMillis();

            KeyPair keyPair = keyPairGen.generateKeyPair();

            long ts = System.currentTimeMillis() - dt;
            logger.info("RSACryptoServiceProvider.createNewKey took " + ts + " ms");


            RSAPrivateCrtKey prvKey = (RSAPrivateCrtKey) keyPair.getPrivate();
            this.modulusElem = prvKey.getModulus().toByteArray();
            this.dElem = prvKey.getPublicExponent().toByteArray();
            this.p = prvKey.getPrimeP().toByteArray();
            this.q = prvKey.getPrimeQ().toByteArray();
            this.dp = prvKey.getPrimeExponentP().toByteArray();
            this.dq = prvKey.getPrimeExponentQ().toByteArray();
            this.inverseq = prvKey.getCrtCoefficient().toByteArray();
            this.d = prvKey.getPrivateExponent().toByteArray();
        } catch (Exception ex) {
            throw new NSException(ex);
        }

    }


    public String toPkiString(boolean includePrivateParameters) throws NSException {
        if (this.modulusElem == null) {
            createNewKey();
        }

        BigInteger modulus = new BigInteger(1, modulusElem);
        BigInteger tempd = new BigInteger(1, dElem);

        try {
            KeyFactory factory = KeyFactory.getInstance("RSA");

            if (includePrivateParameters) {

                RSAPrivateKeySpec privateKeySpec = new RSAPrivateKeySpec(modulus, tempd);
                PrivateKey privateKey = factory.generatePrivate(privateKeySpec);

                return Base64Utils.encodeToString(privateKey.getEncoded());
            } else {
                RSAPublicKeySpec keyspec = new RSAPublicKeySpec(modulus, tempd);
                PublicKey publicKey = factory.generatePublic(keyspec);

                return Base64Utils.encodeToString(publicKey.getEncoded());
            }

        } catch (Exception e) {
            throw new NSException(e);
        }

    }


    public String toXmlString(boolean includePrivateParameters) throws NSException {
        if (this.modulusElem == null) {
            createNewKey();
        }

        // From the XMLDSIG spec, RFC 3075, Section 6.4.2, an RSAKeyValue looks like this:
            /*
               <element name="RSAKeyValue">
                 <complexType>
                   <sequence>
                     <element name="Modulus" type="ds:CryptoBinary"/>
                     <element name="Exponent" type="ds:CryptoBinary"/>
                   </sequence>
                 </complexType>
               </element>
            */
        // we extend appropriately for private components
        StringBuilder sb = new StringBuilder();
        sb.append("<RSAKeyValue>");
        // Add the modulus
        sb.append("<Modulus>").append(Base64Utils.encodeToString(this.modulusElem)).append("</Modulus>");
        // Add the exponent
        sb.append("<Exponent>").append(Base64Utils.encodeToString(this.dElem)).append("</Exponent>");

        if (includePrivateParameters) {
            // Add the private components
            sb.append("<P>").append(Base64Utils.encodeToString(this.p)).append("</P>");
            sb.append("<Q>").append(Base64Utils.encodeToString(this.q)).append("</Q>");
            sb.append("<DP>").append(Base64Utils.encodeToString(this.dp)).append("</DP>");
            sb.append("<DQ>").append(Base64Utils.encodeToString(this.dq)).append("</DQ>");
            sb.append("<InverseQ>").append(Base64Utils.encodeToString(this.inverseq)).append("</InverseQ>");
            sb.append("<D>").append(Base64Utils.encodeToString(this.d)).append("</D>");
        }
        sb.append("</RSAKeyValue>");
        return sb.toString();
    }
}
