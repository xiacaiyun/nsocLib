package cn.nsoc.common.util;


import cn.nsoc.base.entity.container.ObjectDictionary;
import cn.nsoc.base.entity.define.NSExceptionCode;
import cn.nsoc.base.entity.sys.NSException;
import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.stream.JsonReader;

import java.io.FileReader;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/**
 * Created by bobwang on 12/5/16.
 */
public class JsonConverter {
    public ObjectDictionary fromFile(String file) throws NSException {
        Gson gson = new Gson();
        ObjectDictionary objDict = new ObjectDictionary();

        try (JsonReader jsonReader = new JsonReader(new FileReader(file))) {
            JsonElement element = gson.fromJson(jsonReader, JsonElement.class);
            JsonObject objRoot = element.getAsJsonObject();
            accessElements(objRoot, objDict);
            return objDict;
        } catch (Exception exp) {
            throw new NSException(NSExceptionCode.Com_WrongFormatArg, exp);
        }
    }

    public ObjectDictionary fromText(String src) throws NSException {
        Gson gson = new Gson();
        ObjectDictionary objDict = new ObjectDictionary();
        try {
            JsonElement element = gson.fromJson(src, JsonElement.class);
            JsonObject objRoot = element.getAsJsonObject();
            accessElements(objRoot, objDict);
            return objDict;
        } catch (Exception exp) {
            throw new NSException(NSExceptionCode.Com_WrongFormatArg, exp);
        }

    }

    void accessElements(JsonObject currentVal, ObjectDictionary currentContainer) {
        if (currentVal.isJsonPrimitive()) {
            currentContainer.setArrayItem(currentVal.getAsString());
            return;
        }

        for (Map.Entry<String, JsonElement> subNode : currentVal.entrySet()) {
            if (subNode.getValue().isJsonNull()) {
                continue;
            }
            if (subNode.getValue().isJsonArray()) {
                JsonArray subArray = subNode.getValue().getAsJsonArray();
                List<ObjectDictionary> subList = new ArrayList<>();
                ObjectDictionary arrayItems = new ObjectDictionary();
                for (JsonElement subElement : subArray) {
                    if (subElement.isJsonPrimitive()) {
                        arrayItems.setArrayItem(subElement.getAsString());
                    } else {
                        JsonObject interObj = subElement.getAsJsonObject();
                        ObjectDictionary interDict = new ObjectDictionary();
                        accessElements(interObj, interDict);
                        subList.add(interDict);
                    }
                }
                if (arrayItems.arrayVals().isEmpty()) {
                    currentContainer.setList(subNode.getKey(), subList);
                } else {
                    currentContainer.setObject(subNode.getKey(), arrayItems);
                }
            } else if (subNode.getValue().isJsonObject()) {
                ObjectDictionary subDict = new ObjectDictionary();
                accessElements(subNode.getValue().getAsJsonObject(), subDict);
                currentContainer.setObject(subNode.getKey(), subDict);
            } else {
                currentContainer.setItem(subNode.getKey(), subNode.getValue().getAsString());
            }
        }
    }
}
