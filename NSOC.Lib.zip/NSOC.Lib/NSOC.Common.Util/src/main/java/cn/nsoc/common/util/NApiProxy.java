package cn.nsoc.common.util;


import cn.nsoc.base.entity.sys.NSException;
import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import org.springframework.util.Assert;
import org.springframework.util.StringUtils;

import java.time.LocalDateTime;
import java.util.HashMap;
import java.util.List;
import java.util.UUID;
import java.util.function.Supplier;

/**
 * Created by sam on 16-5-29.
 */
public class NApiProxy {

    private static NApiProxy defaultInstance;


    public static NApiProxy getInstance() {
        return defaultInstance;
    }

    public static void setInstance(NApiProxy defaultInstance) {
        NApiProxy.defaultInstance = defaultInstance;
    }

    public NApiProxy(String frameworkRoot, Supplier<String> supplier, UUID appID) {
        this.frameworkRoot = frameworkRoot;
        this.rsakeySupplier = supplier;
        this.appID = appID;
    }

    private Supplier<String> rsakeySupplier;


    private String frameworkRoot;

    public void setFrameworkRoot(String frameworkRoot) {
        Assert.hasText(frameworkRoot, "frameworkRoot 不能为空");
        this.frameworkRoot = frameworkRoot;
    }

    public String getFrameworkRoot() {
        return this.frameworkRoot;
    }


    private String rsaKey;

    protected String getRSAKey() {
        if (rsakeySupplier != null) {
            return rsakeySupplier.get();
        }
        else {
            return rsaKey;
        }
    }

    public void setRSAKey(String rsaKey) {
        this.rsaKey = rsaKey;
    }

    private UUID appID;

    public void setAppID(UUID appID) {
        this.appID = appID;
    }


    public String get(String url) throws NSException {
        return get(url, this.frameworkRoot, this.getRSAKey());
    }

    public String get(String url, String root) throws NSException {
        return get(url, root, this.getRSAKey());
    }

    public String get(String url, String root, String rsakey) throws NSException {
        String webroot = (root == null) ? "" : StringUtils.trimTrailingCharacter(root, '/');
        NApiHelper hlp = new NApiHelper();
        return hlp.get(webroot + url, buildHeader(rsakey));
    }

    public String post(String url, String data) throws NSException {
        return post(url, data, this.frameworkRoot, this.getRSAKey());
    }

    public String post(String url, String data, String root, String rsakey) throws NSException {
        String webroot = (root == null) ? "" : StringUtils.trimTrailingCharacter(root, '/');
        NApiHelper hlp = new NApiHelper();
        return hlp.post(webroot + url, data, buildHeader(rsakey));
    }

    private HashMap<String, String> buildHeader(String rsakey) throws NSException {

        if (this.appID == null)
            return null;
        if (!StringUtils.hasText(rsakey))
            return null;


        RSACryptoServiceProvider rsa = new RSACryptoServiceProvider();
        rsa.fromXmlString(rsakey);


        HashMap<String, String> map = new HashMap<>();
        map.put("APPID", Misc.toStdString(this.appID));
        map.put("APPVRY", rsa.encrypt(Misc.toStdUtcSting(LocalDateTime.now())));
        return map;
    }

    public <T> List<T> parserData(String html, Class<T[]> classOfTarr) {
        JsonParser jp = new JsonParser();
        JsonObject obj = jp.parse(html).getAsJsonObject();

        JsonArray data = obj.getAsJsonArray("data");

        if (data.isJsonNull()) {
            throw new IllegalArgumentException("数据不正确");
        }
        return Misc.fromJsonToList(data.toString(), classOfTarr);
    }

    public <T1, T2> Object[] parserPagerData(String html, Class<T2> classOfT2, Class<T1[]> classOfT1) {
        JsonParser jp = new JsonParser();
        JsonObject obj = jp.parse(html).getAsJsonObject();

        JsonArray data = obj.getAsJsonArray("data");
        JsonObject pager = obj.getAsJsonObject("pager");

        if (data.isJsonNull()) {
            throw new IllegalArgumentException("数据不正确");
        }

        List<T1> list = Misc.fromJsonToList(data.toString(), classOfT1);

        T2 pagerctx = null;

        if (pager.isJsonNull()) {
            pagerctx = Misc.fromJson(pager.toString(), classOfT2);
        }
        return new Object[]{list, pagerctx};
    }


}
