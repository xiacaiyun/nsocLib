package cn.nsoc.common.util;

import cn.nsoc.base.entity.sys.NSException;
import org.apache.log4j.Logger;
import org.springframework.util.StringUtils;

import java.lang.reflect.Field;
import java.math.BigDecimal;
import java.math.BigInteger;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.regex.Pattern;

/**
 * Created by xiacaiyun on 2016/12/23.
 */
public class UtilityHelper {
    private static final Logger logger = Logger.getLogger(UtilityHelper.class);


    private UtilityHelper() {

    }

    /*
    *  Example: ips = "192.168.1.107,192.168.1.45"
    *  return    "00c0a8016b,00c0a8012d"
    * */
    public static String ipsToHexStrings(String ips) {
        if (ips != null) {
            String[] split = ips.split(",");
            StringBuilder sb = new StringBuilder();
            for (String aSplit : split) {
                String s = Misc.byteArrayToHexString(Misc.ipToBigInt(aSplit).toByteArray());
                sb.append(s).append(",");
            }
            return sb.substring(0, sb.length() - 1);
        } else {
            return "";
        }
    }

    public static String ipsToNips(String ips) {
        if (ips != null) {
            String[] split = ips.split(",");
            StringBuilder sb = new StringBuilder();
            for (String aSplit : split) {
                String s = Misc.ipToBigInt(aSplit).toString();
                sb.append(s).append(",");
            }
            return sb.substring(0, sb.length() - 1);
        } else {
            return "";
        }
    }

    public static String nipsToHexStrings(String nips) {
        if (nips != null) {
            String[] split = nips.split(",");
            StringBuilder sb = new StringBuilder();
            for (String aSplit : split) {
                BigInteger big = new BigInteger(aSplit);
                String s = Misc.byteArrayToHexString(big.toByteArray());
                sb.append(s).append(",");
            }
            return sb.substring(0, sb.length() - 1);
        } else {
            return "";
        }
    }


    public static String regulateSplitValueOfINT(String splitchars, String joinchars, String s, StringBuilder illegalstr) throws NSException {
        List<String> list2 = new ArrayList<>();
        List<String> errlist = new ArrayList<>();
        if (!StringUtils.hasText(s)) {
            return "";
        }
        if (!StringUtils.hasText(splitchars)) {
            throw new NSException("splitchars 不能为空");
        }
        String[] array = s.split(String.valueOf((splitchars.toCharArray())));
        for (String text : array) {
            if (StringUtils.hasText(text)) {
                if (isNumeric(text) && text.length() < 10) {
                    Integer num = Integer.parseInt(text);
                    list2.add(num.toString());
                } else {
                    errlist.add(text);
                }
            }
        }
        if (!errlist.isEmpty()) {
            illegalstr.append(String.join(joinchars, errlist));
        }
        return String.join(joinchars, list2);
    }

    public static String verifyMultipleIPs(String splitchars, String joinchars, String ips, StringBuilder illegalstr) throws NSException {
        List<String> list2 = new ArrayList<>();
        List<String> errlist = new ArrayList<>();
        if (!StringUtils.hasText(ips)) {
            return "";
        }
        if (!StringUtils.hasText(splitchars)) {
            throw new NSException("splitchars 不能为空");
        }
        String[] array = ips.split(String.valueOf((splitchars.toCharArray())));
        for (String text : array) {
            if (StringUtils.hasText(text)) {
                if (Misc.isValidIPv4(text)) {
                    list2.add(text);
                } else {
                    errlist.add(text);
                }
            }
        }
        if (!errlist.isEmpty()) {
            illegalstr.append(String.join(joinchars, errlist));
        }
        return String.join(joinchars, list2);
    }

    public static boolean isNumeric(String str) {
        return StringUtils.hasText(str) && Pattern.compile("[0-9]*").matcher(str).matches();
    }

    public static String regulateSplitValueOfString(String splitchars, String joinchars, String s, StringBuilder illegalstr) throws NSException {
        List<String> list2 = new ArrayList<>();
        List<String> errlist = new ArrayList<>();
        if (!StringUtils.hasText(s)) {
            return "";
        }

        if (splitchars == null) {
            throw new NSException("splitchars 不能为空");
        }
        String[] array = s.split(String.valueOf((splitchars.toCharArray())));
        for (String text : array) {
            String[] arr = text.split("\\.");
            if (arr.length != 4) {
                errlist.add(text);
            }
            if (StringUtils.hasText(text)) {
                list2.add(text);
            }
        }
        if (!errlist.isEmpty()) {
            illegalstr.append(String.join(joinchars, errlist));
        }
        return String.join(joinchars, list2);
    }

    public static String regulateSplitValueOfINT(String spiltchar, String str) {

        if (!StringUtils.hasText(str)) {
            return null;
        }

        List<String> errMsg = new ArrayList<>();
        String[] array = str.split(String.valueOf(spiltchar.toCharArray()));
        for (String text : array) {
            if (StringUtils.hasText(text) && !isNumeric(text)) {
                errMsg.add(text);
            }
        }

        if (errMsg.isEmpty())
            return null;
        return String.join(",", errMsg);
    }

    public static String enumToSql(Enum e) {
        if (e == null) {
            return null;
        }
        return e.name().replace("__", " ").replace("_", ",");
    }

    public static String appendQuoteifNotNUll(Object o) {
        if (o == null) {
            return null;
        } else if (o instanceof Boolean) {
            return o.toString();
        } else if (o instanceof Integer) {
            return o.toString();
        } else if (o instanceof byte[]) {
            return "'" + Misc.byteArrayToHexString((byte[]) o) + "'";
        } else if (o instanceof String && !StringUtils.hasText(o.toString())) {
            return null;
        } else {
            return "'" + o + "'";
        }
    }

    public static Object loadToEntityFromMap(Class<?> classOfEntity, Map<String, Object> map) {
        Field[] fds = classOfEntity.getDeclaredFields();
        Object t = null;
        try {
            t = classOfEntity.newInstance();
            for (Field fd : fds) {
                fd.setAccessible(true);

                String name = fd.getName();
                Object val = map.get(name);

                if (val == null) {
                    continue;
                }
                Class<?> fdType = fd.getType();
                if (fdType.equals(LocalDateTime.class)) {
                    fd.set(t, Misc.parseISODateTime(val.toString().substring(0, 19)));
                } else if (fdType.equals(BigInteger.class)) {
                    if (val instanceof BigInteger) {
                        fd.set(t, val);
                    } else {
                        fd.set(t, new BigInteger(1, (byte[]) (val)));
                    }
                } else if (!fdType.equals(Long.class) && val instanceof Long) {
                    fd.set(t, Integer.valueOf(val.toString()));
                } else if (!fdType.equals(BigDecimal.class) &&
                        val instanceof BigDecimal) {
                    fd.set(t, Integer.valueOf(val.toString()));
                } else if (fdType.equals(Long.class) && val instanceof String)
                    fd.set(t, Long.parseLong(val.toString()));
                else if (fdType.equals(Integer.class) && val instanceof String)
                    fd.set(t, Integer.parseInt(val.toString()));
                else fd.set(t, val);

            }
        } catch (IllegalAccessException | InstantiationException ignored) {
            Misc.ignoreException(ignored);
        }
        return t;
    }

    public static <T> List<T> loadToEntityFromListMap(Class<T> classOfEntity, List<Map<String, Object>> list) {
        List<T> me = new ArrayList<>();
        list.forEach(l -> {
            Object o = loadToEntityFromMap(classOfEntity, l);
            me.add((T) o);
        });
        return me;
    }

    public static String bytesToHexString(byte[] bArray) {
        StringBuilder sb = new StringBuilder();
        String sTemp;
        for (byte aBArray : bArray) {
            sTemp = Integer.toHexString(0xFF & aBArray);
            if (sTemp.length() < 2)
                sb.append(0);
            sb.append(sTemp.toUpperCase());
        }
        return sb.toString();
    }

}
