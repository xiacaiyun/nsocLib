package cn.nsoc.common.util;


import cn.nsoc.base.entity.sys.NSException;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.client.ClientHttpRequest;
import org.springframework.http.client.ClientHttpResponse;
import org.springframework.http.client.SimpleClientHttpRequestFactory;
import org.springframework.util.StringUtils;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.URI;
import java.util.Map;

/**
 * Created by sam on 16-6-5.
 */
public class NApiHelper {

    public NApiHelper() {
        setContentType("application/json");
    }


    /// <summary>
    /// 毫秒超时，默认值是 0 , 代表 100,000 毫秒（100 秒）
    /// </summary>
    private int timeout = 0;

    public String post(String url, String data) throws NSException {
        return openUrl(url, HttpMethod.POST, data, null);
    }

    public String post(String url, String data, Map<String, String> hdrs) throws NSException {
        return openUrl(url, HttpMethod.POST, data, hdrs);
    }

    private String contentType;

    public String get(String url) throws NSException {
        return openUrl(url, HttpMethod.GET, null, null);
    }

    public String get(String url, Map<String, String> hdrs) throws NSException {
        return openUrl(url, HttpMethod.GET, null, hdrs);
    }

    public String openUrl(String url, HttpMethod verb, String data, Map<String, String> hdrs) throws NSException {
        SimpleClientHttpRequestFactory factory = new SimpleClientHttpRequestFactory();

        if (getTimeout() > 0) {
            factory.setConnectTimeout(getTimeout());
        }

        try {

            ClientHttpRequest request = factory.createRequest(URI.create(url), verb);
            HttpHeaders headers = request.getHeaders();

            headers.add("User-Agent", "NSOC.Api");
            headers.add("Accept", "*/*");
            headers.add("Accept-Charset", "GBK,utf-8;q=0.7,*;q=0.3");
            headers.add("Accept-Language", "zh-CN,zh;q=0.8");

            if (hdrs != null) {
                hdrs.forEach(headers::add);
            }

            if (StringUtils.hasLength(getContentType()))
                headers.add("Content-Type", getContentType());

            if (verb == HttpMethod.POST) {
                request.getBody().write(data.getBytes("UTF-8"));
            }


            ClientHttpResponse response = request.execute();

            if (response.getStatusCode() != HttpStatus.OK)
                throw new IOException(String.format("StatusCode: %d", response.getStatusCode().value()));

            InputStreamReader isr = new InputStreamReader(response.getBody(), "UTF-8");
            BufferedReader br = new BufferedReader(isr);
            StringBuilder sb = new StringBuilder();

            String str;
            while ((str = br.readLine()) != null) {
                sb.append(str);
                sb.append("\n");
            }

            br.close();
            isr.close();

            return sb.toString();
        } catch (Exception ex) {
            throw new NSException(ex);
        }
    }

    public int getTimeout() {
        return timeout;
    }

    public void setTimeout(int timeout) {
        this.timeout = timeout;
    }

    public String getContentType() {
        return contentType;
    }

    public void setContentType(String contentType) {
        this.contentType = contentType;
    }
}
