package cn.nsoc.common.util;

import cn.nsoc.base.entity.sys.NSException;
import org.springframework.util.Base64Utils;

import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;

/**
 * Created by sam on 17-3-2.
 */
public class ThreeDESCryptoServiceProvider {


    private static final String CRYPT_ALGORITHM = "DESede";  //DESede/ECB/PKCS5Padding  desede/CBC/NoPadding

    private ThreeDESCryptoServiceProvider() {

    }

    public static String encrypt(String text, byte[] key) throws NSException {

        try {
            if ((key == null) || (key.length != 24))
                throw new NSException("key 应该为24位16进制字符串");

            Cipher cipher = Cipher.getInstance(CRYPT_ALGORITHM);
            cipher.init(Cipher.ENCRYPT_MODE, new SecretKeySpec(key, CRYPT_ALGORITHM));

            byte[] encryptedByte = cipher.doFinal(text.getBytes());
            return Base64Utils.encodeToString(encryptedByte);
        } catch (Exception ex) {
            throw new NSException(ex);
        }
    }

    public static String decrypt(String encrypttext, byte[] key) throws NSException {
        try {
            if ((key == null) || (key.length != 24))
                throw new NSException("key 应该为24位16进制字符串");

            Cipher cipher = Cipher.getInstance(CRYPT_ALGORITHM);
            cipher.init(Cipher.DECRYPT_MODE, new SecretKeySpec(key, CRYPT_ALGORITHM));
            byte[] deBytes = cipher.doFinal(Base64Utils.decodeFromString(encrypttext));

            return new String(deBytes, "UTF-8");
        } catch (Exception ex) {
            throw new NSException(ex);
        }
    }
}
