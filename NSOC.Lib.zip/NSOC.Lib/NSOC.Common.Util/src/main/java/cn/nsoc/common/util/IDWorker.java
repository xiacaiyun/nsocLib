package cn.nsoc.common.util;

import java.time.LocalDateTime;
import java.time.ZoneOffset;
import java.util.Random;

/**
 * Created by sam on 16-7-4.
 */
public class IDWorker {
    long lastTimestamp = -1L;
    long sequence = 0L;
    long sequenceMask = 0;
    long wid = 0;
    long rand = 0;
    long twepoch = 0;
    int sequenceBits = 12;
    int widBits = 4;
    int randBits = 4;

    private static IDWorker instance;

    public static IDWorker getInstance() {
        if (instance == null) {
            instance = new IDWorker(new Random().nextInt());
        }
        return instance;
    }

    public static void setInstance(IDWorker inst) {
        instance = inst;
    }

    public static long NextID() {
        return getInstance().getId();
    }

    public IDWorker(long workerId) {
        wid = workerId & (~(-1L << widBits));
        sequenceMask = ~(-1L << sequenceBits);
        rand = new Random().nextInt() & (~(-1 << randBits));
        twepoch = getMilli(LocalDateTime.of(2010, 1, 1, 0, 0, 0));
    }

    public long getId() {
        return getNextId();
    }

    private long getMilli(LocalDateTime currentDT) {
        return currentDT.toInstant(ZoneOffset.ofTotalSeconds(0)).toEpochMilli();
    }

    private long timeGen() {
        return getMilli(LocalDateTime.now()) - twepoch;
    }

    protected synchronized long getNextId() {
        long timestamp = timeGen();

        if (lastTimestamp == timestamp) {
            sequence = (sequence + 1) & sequenceMask;
            if (sequence == 0) {
                timestamp = untilNextMillis(lastTimestamp);
            }
        } else {
            sequence = 0L;
        }
        if (timestamp < lastTimestamp) {
            rand = (rand + 1) & (~(-1L << randBits));
            timestamp = untilNextMillis(lastTimestamp);
            sequence = 0L;
        }

        lastTimestamp = timestamp;

        long tempNextId = timestamp;

        tempNextId = (tempNextId << widBits) | wid;
        tempNextId = (tempNextId << randBits) | rand;
        tempNextId = (tempNextId << sequenceBits) | sequence;
        return tempNextId;
    }

    protected long untilNextMillis(long prevTimeStamp) {
        long timestamp = timeGen();
        while (timestamp <= prevTimeStamp) {
            timestamp = timeGen();
        }
        return timestamp;
    }
}