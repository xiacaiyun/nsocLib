//package cn.nsoc.common.util;
//
//import junit.framework.TestCase;
//
///**
// * Created by sam on 17-3-22.
// */
//public class RSACryptoServiceProviderTest extends TestCase {
//    public void testToBase64String() throws Exception {
//
//        RSACryptoServiceProvider rsa = new RSACryptoServiceProvider();
//        String xml  =  rsa.toXmlString(true);
//
//
//        String pubjs = rsa.toPkiString(false);
//    }
//}