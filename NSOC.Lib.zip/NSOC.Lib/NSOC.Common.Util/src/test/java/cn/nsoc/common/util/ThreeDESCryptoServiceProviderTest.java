//package cn.nsoc.common.util;
//
//import junit.framework.TestCase;
//
///**
// * Created by sam on 17-3-2.
// */
//public class ThreeDESCryptoServiceProviderTest extends TestCase {
//    public void testEncrypt() throws Exception {
//
//        byte[] bytes = Misc.hexStringToByteArray("2998EA66DCCCC7B156DC9F369D9A41482998EA66DCCCC7B1");
//
//        String etext =  ThreeDESCryptoServiceProvider.encrypt("HS3!#k9p",bytes);
//
//        String text = ThreeDESCryptoServiceProvider.decrypt(etext,bytes);
//    }
//
//}