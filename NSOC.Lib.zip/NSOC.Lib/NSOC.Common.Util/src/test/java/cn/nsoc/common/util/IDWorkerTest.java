//package cn.nsoc.common.util;
//
//import junit.framework.TestCase;
//
//import java.io.Console;
//import java.time.LocalDateTime;
//import java.util.ArrayList;
//import java.util.List;
//
///**
// * Created by sam on 16-10-19.
// */
//public class IDWorkerTest extends TestCase {
//
//    public void testNextID() throws Exception {
//
//        IDWorker worker = IDWorker.getInstance();
//
//        LocalDateTime now = LocalDateTime.now();
//
//        List<Long> list = new ArrayList<>();
//        for(int i = 0; i < 1000000; i ++)
//        {
//            list.add(worker.getNextId());
//        }
//
//        LocalDateTime dt = LocalDateTime.now();
//
//
//
//        long i = list.stream().distinct().count();
//    }
//
//}