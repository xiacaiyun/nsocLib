package cn.nsoc.common.util;

import cn.nsoc.base.entity.sys.NSException;
import junit.framework.TestCase;

import java.math.BigDecimal;
import java.math.BigInteger;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.*;

/**
 * Created by sam on 16-6-4.
 */
public class MiscTest extends TestCase {

    static class TestEnity {
        private String Field1;
        private Integer Field2;
        private LocalDateTime Field3;
        private BigDecimal Field4;
        private BigInteger Field5;
        private Boolean Field6;
        private int Field7;
        private boolean Field8;
    }

    public void testIsEmail() throws Exception {
        assertTrue(Misc.isEmail("sam@nsoc.cn"));
        assertFalse(Misc.isEmail("sam.nsoc.cn"));
    }

    public void testToStdString() throws Exception {
        UUID id = UUID.randomUUID();
        String result = Misc.toStdString(id);
    }


    public void testJsonNumber() throws Exception {

        Map<String,Object> map = new HashMap<>();
        map.put("a",1);
        map.put("b",2.0);
        map.put("c",3.1);
        map.put("d",4.10);
        map.put("e",null);

        String sMap = Misc.toJson(map);
        String expect = "{\"a\":1,\"b\":2.0,\"c\":3.1,\"d\":4.1}";

        //for gson
        String actual2 = "{\"a\":1,\"b\":2,\"c\":3.1,\"d\":4.1}";
        assertEquals(sMap,actual2);

        Map<String,Object> rMap = (Map<String,Object>)Misc.fromJson(sMap,TreeMap.class);


        String sMapTree = Misc.toJson(rMap);
       // assertEquals(rMap.get("a"),1);
        assertEquals(sMapTree,actual2);
        Map<String,Object> rObj = (Map<String,Object>)Misc.fromJson(sMap,Object.class);
        //assertEquals(rObj.get("a"),1);
        String sMapObj = Misc.toJson(rObj);
        assertEquals(sMapObj,actual2);


        List<Object> list = new ArrayList<>();

        list.add(1);
        list.add(2.0);

        String sList = Misc.toJson(list);

        assertEquals(sList,"[1,2]");
        List<Object> rlist = Misc.fromJsonToList(sList,Object[].class);
        //assertEquals(rlist.get(0),1);

        //for gson
        assertEquals(rlist.get(0),1.0);
    }

    public void testJson() throws Exception {

        List<String> list = new ArrayList<>();
        list.add("<abc>");
        list.add("</123>");

        String result = Misc.toJson(list);

        List<String> retlist = Misc.fromJsonToList(result, String[].class);
    }


    public void testFromJson() throws Exception {

        String s = "[\"abc\",\"123\"]";

        List<String> list = Misc.<String>fromJsonToList(s, String[].class);

        assertNotNull(list);
    }


    public void testRsaEncrypt() throws Exception {
        String key = "<RSAKeyValue><Modulus>2D3e+4Sl2AplZuPYMAKNtiHKNIKV8IEz4ssD/aixqRlEC7NfxURT01Wlrdry7P41hED47qj12N4xHwCrbdPYagN8xhQezeeh5cBN/Y2RhEbU/oDKA4PvleFArrhj6UInI0g5CC0LulEiy6a4ISrYQSy9ZmrscCB0UCQkc2vC4Bk=</Modulus><Exponent>AQAB</Exponent><P>/EQ0MC3eo/qog1jrXm4zc6kwLhcmv2pfxgyxJn2Jgj2gzAzsLvuYip5F2OXhcd4jD/89YJrjpS7OrSY5nyeInw==</P><Q>23Es4tokOuVZgNLx/7Za/GXAT9UvLAi8ib9O/acpcYroe9WusCDdvcALKzROgN9BGtoWMllWWdNCQkbmymaERw==</Q><DP>q8OIwVFKKd7PBHfz8t0YHWWSj59l26mDQqd7q1iI22w44xbdbfQTXjb8Gf4ULeLxfr/su61a2SrwwIapb0uMww==</DP><DQ>QKB7LLA7/VBwZJ07gijNcQnyclCBnQFRrWu3MsLZVMQpJddPpDV5uJlncKjt+cxGW0chRGDFKp0qJWTGMZOxnw==</DQ><InverseQ>7M4rMYz3Un4LDWYPo/Y3RLzJqhobizC/Yzneman/vI4E85QyRZn7nIb+g1/GXB6leMTppNk4/Mf/McMZCRAazA==</InverseQ><D>Pc25LHPmHpAiGT0nrdkc/aA8tbNY/WtAFCLoGhib5nO1Mg7rYWs89hr1hnIcmkWxsAIN49Bgq8IdkfnUBUjWAjf4/lJIXHE9UUSVEFPdtYnUA28oQpRhhzFegwMV6gSOHz/Xc9gheXV0CoTt1WKustn2gLg/VeFLUOtVNiFcTb0=</D></RSAKeyValue>";
        String result = Misc.rsaEncrypt("abc", key);

        assertNotNull(result);
    }

    public void testGetMapFromObject() throws Exception {
        TestEnity e = new TestEnity();
        Map<String, Object> map = Misc.getMapFromObject(e);

        e.Field1 = "f1";
        e.Field2 = 2;
        e.Field3 = LocalDateTime.now();
        e.Field4 = BigDecimal.valueOf(4);
        e.Field5 = BigInteger.valueOf(5);
        e.Field6 = true;
        e.Field7 = 7;
        e.Field8 = false;

        map = Misc.getMapFromObject(e);

        assertEquals(e.Field1, (map.get("Field1")));
        assertEquals(e.Field2, (map.get("Field2")));
        assertEquals(e.Field3, (map.get("Field3")));
        assertEquals(e.Field4, (map.get("Field4")));
        assertEquals(e.Field5, (map.get("Field5")));
        assertEquals(e.Field6, (map.get("Field6")));
        assertEquals(e.Field7, (map.get("Field7")));
        assertEquals(e.Field8, (map.get("Field8")));
    }

    public void testDateTimeFormat() {
        LocalDateTime dt = LocalDateTime.of(2017, 1, 1, 0, 0, 0);
        LocalDateTime dt2 = LocalDateTime.of(2017, 1, 1, 8, 12, 50);

        String str = Misc.toStdDateString(dt);
        assertEquals(str, "2017-01-01");

        //parseISODate
        LocalDate date = Misc.parseISODate(str);
        assertEquals(date, dt.toLocalDate());

        LocalDateTime dateTime = Misc.parseISODateTime(str);
        assertEquals(dateTime, dt);

        str = Misc.toStdString(dt);
        assertEquals(str, "2017-01-01 00:00:00");

        str = Misc.toStdUtcSting(dt);
        assertEquals(str, "2016-12-31 16:00:00");

        str = Misc.toStdString(dt);
        assertEquals(str, "2017-01-01 00:00:00");

        //parseISODateTime
        LocalDateTime dTime = Misc.parseISODateTime(str);
        assertEquals(dTime, dt);

        //trimTime
        LocalDateTime trimlocaldt = Misc.trimTime(dt2);
        assertEquals(dt, trimlocaldt);


        //toStdDateString
        str = Misc.toStdDateString(date);
        assertEquals(str, "2017-01-01");

        String str2 = Misc.toStdDateString(dt2);
        assertEquals(str2, "2017-01-01");
        assertEquals(str2, str);

        str2 = Misc.toStdString(dt2);
        assertEquals(str2, "2017-01-01 08:12:50");

        str2 = Misc.toStdUtcSting(dt2);
        assertEquals(str2, "2017-01-01 00:12:50");

        str2 = Misc.toStdString(dt2);
        assertEquals(str2, "2017-01-01 08:12:50");

        LocalDateTime dateTime2 = Misc.parseISODateTime(str2);
        assertEquals(dateTime2, dt2);

        //parseDotNetDateTime
        LocalDateTime localdt = Misc.parseDotNetDateTime("/Date(00000001)/");
        assertEquals(localdt.getDayOfMonth(), 1);
        assertEquals(localdt.getDayOfYear(), 1);


    }


}