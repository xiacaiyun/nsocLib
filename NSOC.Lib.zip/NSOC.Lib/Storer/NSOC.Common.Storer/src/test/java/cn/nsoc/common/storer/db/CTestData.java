package cn.nsoc.common.storer.db;

import cn.nsoc.common.storer.EntityCollection;
import cn.nsoc.common.storer.EntityQuery;
import cn.nsoc.common.storer.annotation.DbField;
import cn.nsoc.common.storer.annotation.DbTable;

import java.math.BigDecimal;
import java.time.LocalDateTime;

/**
 * Created by chenxl on 2017/7/21.
 */
public class CTestData {
    @DbTable(name = "tbl_testData")
    public static class Entity {
        @DbField(isKey = true, isAutoIncrement = true)
        private int a;
        private String b;
        private boolean c;
        private Long d;
        private int f;
        private Integer g;
        private Boolean h;
        private LocalDateTime t;
        private BigDecimal j;

        public Integer getG() {
            return g;
        }

        public void setG(Integer g) {
            this.g = g;
        }

        public Boolean getH() {
            return h;
        }

        public void setH(Boolean h) {
            this.h = h;
        }

        public LocalDateTime getT() {
            return t;
        }

        public void setT(LocalDateTime t) {
            this.t = t;
        }

        public BigDecimal getJ() {
            return j;
        }

        public void setJ(BigDecimal j) {
            this.j = j;
        }

        public int getA() {
            return a;
        }

        public void setA(int a) {
            this.a = a;
        }

        public String getB() {
            return b;
        }

        public void setB(String b) {
            this.b = b;
        }

        public boolean isC() {
            return c;
        }

        public void setC(boolean c) {
            this.c = c;
        }

        public Long getD() {
            return d;
        }

        public void setD(Long d) {
            this.d = d;
        }

        public int getF() {
            return f;
        }

        public void setF(int f) {
            this.f = f;
        }
    }

    public static class Query extends EntityQuery {
        private Integer a;
        private String b;
        private Boolean c;
        private Long d;
        private Integer f;
        private Integer g;
        private Boolean h;
        private LocalDateTime t;
        private BigDecimal j;
        public int getA() {
            return a;
        }

        public void setA(int a) {
            this.a = a;
        }

        public String getB() {
            return b;
        }

        public void setB(String b) {
            this.b = b;
        }

        public boolean isC() {
            return c;
        }

        public void setC(boolean c) {
            this.c = c;
        }

        public Long getD() {
            return d;
        }

        public void setD(Long d) {
            this.d = d;
        }

        public int getF() {
            return f;
        }

        public void setF(int f) {
            this.f = f;
        }

        public Integer getG() {
            return g;
        }

        public void setG(Integer g) {
            this.g = g;
        }

        public Boolean getH() {
            return h;
        }

        public void setH(Boolean h) {
            this.h = h;
        }

        public LocalDateTime getT() {
            return t;
        }

        public void setT(LocalDateTime t) {
            this.t = t;
        }

        public BigDecimal getJ() {
            return j;
        }

        public void setJ(BigDecimal j) {
            this.j = j;
        }
    }

    public static class Coll extends EntityCollection<CTestData.Entity, CTestData.Query> {

        public Coll() {
            super(CTestData.Entity.class, CTestData.Query.class);
        }

        public Coll(CTestData.Query query) {
            this();

            setQuery(query);
        }
    }
}
