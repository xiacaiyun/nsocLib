package cn.nsoc.common.storer.db;

import cn.nsoc.common.storer.EntityCollection;
import cn.nsoc.common.storer.EntityQuery;
import cn.nsoc.common.storer.annotation.DbField;
import cn.nsoc.common.storer.annotation.DbTable;

/**
 * Created by sam on 17-7-19.
 */
public class CTest2 {
    @DbTable(name = "tbl_test2")
    public static class Entity {
        @DbField(isKey = true)
        private int a;
        private String b;
        private int c;
        private int d;

        public int getA() {
            return a;
        }

        public void setA(int a) {
            this.a = a;
        }

        public String getB() {
            return b;
        }

        public void setB(String b) {
            this.b = b;
        }

        public int getC() {
            return c;
        }

        public void setC(int c) {
            this.c = c;
        }

        public int getD() {
            return d;
        }

        public void setD(int d) {
            this.d = d;
        }
    }

    public static class Query extends EntityQuery {
        private Integer a;
        private String b;
        private Integer c;
        private Integer d;
        private Integer e;
        private Integer f;
        private Integer g;


        public Integer getA() {
            return a;
        }

        public void setA(Integer a) {
            this.a = a;
        }

        public String getB() {
            return b;
        }

        public void setB(String b) {
            this.b = b;
        }

        public Integer getC() {
            return c;
        }

        public void setC(Integer c) {
            this.c = c;
        }

        public Integer getD() {
            return d;
        }

        public void setD(Integer d) {
            this.d = d;
        }

        public Integer getE() {
            return e;
        }

        public void setE(Integer e) {
            this.e = e;
        }

        public Integer getF() {
            return f;
        }

        public void setF(Integer f) {
            this.f = f;
        }

        public Integer getG() {
            return g;
        }

        public void setG(Integer g) {
            this.g = g;
        }
    }

    public static class Coll extends EntityCollection<Entity, Query> {

        public Coll() {
            super(Entity.class, Query.class);
        }

        public Coll(Query query) {
            this();

            setQuery(query);
        }
    }
}
