package cn.nsoc.common.storer.db;

import cn.nsoc.common.storer.annotation.QueryOperator;
import cn.nsoc.common.storer.option.QueryBuilder;
import junit.framework.TestCase;
import org.apache.commons.dbcp2.BasicDataSource;

import java.math.BigDecimal;

import java.sql.Timestamp;
import java.time.LocalDate;
import java.time.LocalTime;
import java.util.ArrayList;
import java.time.LocalDateTime;
import java.util.Date;

/**
 * Created by chenxl on 2017/7/24.
 */
public class JdbcDbStorerTestDataByCxl extends TestCase {
    private JdbcDbStorer dbStorer;

    public void setUp() throws Exception {
        super.setUp();

        BasicDataSource dsTest = new BasicDataSource();
        dsTest.setDriverClassName("com.mysql.cj.jdbc.Driver");
        dsTest.setUrl("jdbc:mysql://192.168.1.39:34006/db_test?allowMultiQueries=true&useUnicode=true&characterEncoding=UTF8&autoReconnect=true&failOverReadOnly=false&zeroDateTimeBehavior=convertToNull&serverTimezone=UTC");
        dsTest.setUsername("test");
        dsTest.setPassword("tttttt");
        dsTest.setInitialSize(3);

        dbStorer = JdbcDbStorer.createJdbcDbStorer("mysql", dsTest);
    }

    // 测试 简单 QueryBuilder
    public void testBuildConditions_Data1() throws Exception {

        DbSelectBuilder dbSelectBuilder = new DbSelectBuilder(dbStorer, null);
        dbSelectBuilder.addQuery(new QueryBuilder().and("b", QueryOperator.Equal, "ceshi数据11111")
                .or("c", QueryOperator.Equal, false)
                .or("d", QueryOperator.Equal, 15211).or("f", QueryOperator.Equal, 123456));
        CTestData.Query query = new CTestData.Query();
        query.selectFields = dbSelectBuilder;
        CTestData.Coll coll = new CTestData.Coll(query);
        dbStorer.load(coll);
        assertTrue(!coll.isEmpty());

    }

    // 测试 嵌套 QueryBuilder
    public void testBuildConditions_Data2() throws Exception {

        DbSelectBuilder dbSelectBuilder = new DbSelectBuilder(dbStorer, null);
        QueryBuilder inner = new QueryBuilder();
        inner.add("b", QueryOperator.GreatEqual, "ceshi数据11111")
                .and("c", QueryOperator.LessEqual, true).and("f", QueryOperator.LessEqual, 123456);
        dbSelectBuilder.addQuery(new QueryBuilder().and("d", QueryOperator.Equal, 1521)
                .or(inner));
        CTestData.Query query = new CTestData.Query();
        query.selectFields = dbSelectBuilder;
        CTestData.Coll coll = new CTestData.Coll(query);
        dbStorer.load(coll);
        assertTrue(!coll.isEmpty());
    }

    // 测试 嵌套 QueryBuilder
    public void testBuildConditions_Data3() throws Exception {

        DbSelectBuilder dbSelectBuilder = new DbSelectBuilder(dbStorer, null);
        QueryBuilder inner = new QueryBuilder();
        inner.add("b", QueryOperator.GreatEqual, "ceshi数据11111")
                .and("c", QueryOperator.LessEqual, true);
        dbSelectBuilder.addQuery(new QueryBuilder().or(inner));
        CTestData.Query query = new CTestData.Query();
        query.setD(1521L);
        query.selectFields = dbSelectBuilder;
        CTestData.Coll coll = new CTestData.Coll(query);
        dbStorer.load(coll);
        assertTrue(!coll.isEmpty());
    }

    // 测试 Query without QueryBuilder
    public void testBuildConditions_Data4() throws Exception {

        CTestData.Query query = new CTestData.Query();
        query.setB("ceshi数据101");
        CTestData.Coll coll = new CTestData.Coll(query);
        dbStorer.load(coll);
        assertTrue(coll.size() != 1);

    }

    // 测试 不同 operator 的 QueryBuilder
    public void testBuildConditions5() throws Exception {
        //测试GreatEqual
        DbSelectBuilder dbSelectBuilder = new DbSelectBuilder(dbStorer, null);
        dbSelectBuilder.addQuery(new QueryBuilder().and("a", QueryOperator.GreatEqual, 6));
        CTestData.Query query = new CTestData.Query();
        query.selectFields = dbSelectBuilder;
        CTestData.Coll coll = new CTestData.Coll(query);
        dbStorer.load(coll);
        assertTrue(!coll.isEmpty());

        //测试Like
        dbSelectBuilder = new DbSelectBuilder(dbStorer, null);
        dbSelectBuilder.addQuery(new QueryBuilder().and("b", QueryOperator.Like, "ceshi数据11111"));
        query.selectFields = dbSelectBuilder;
        dbStorer.load(coll);
        assertTrue(!coll.isEmpty());

        //测试Equal
        dbSelectBuilder = new DbSelectBuilder(dbStorer, null);
        dbSelectBuilder.addQuery(new QueryBuilder().and("c", QueryOperator.Equal, false));
        query.selectFields = dbSelectBuilder;
        dbStorer.load(coll);
        assertTrue(!coll.isEmpty());

        //测试GreatThan
        dbSelectBuilder = new DbSelectBuilder(dbStorer, null);
        dbSelectBuilder.addQuery(new QueryBuilder().and("d", QueryOperator.GreatThan, 15210));
        query.selectFields = dbSelectBuilder;
        dbStorer.load(coll);
        assertTrue(!coll.isEmpty());

        //测试LessThan
        dbSelectBuilder = new DbSelectBuilder(dbStorer, null);
        dbSelectBuilder.addQuery(new QueryBuilder().and("j", QueryOperator.LessThan, 10001));
        query.selectFields = dbSelectBuilder;
        dbStorer.load(coll);
        assertTrue(!coll.isEmpty());

        //测试LessThan
        dbSelectBuilder = new DbSelectBuilder(dbStorer, null);
        dbSelectBuilder.addQuery(new QueryBuilder().and("f", QueryOperator.LessEqual, 123457));
        query.selectFields = dbSelectBuilder;
        dbStorer.load(coll);
        assertTrue(!coll.isEmpty());

        //声明数组对象
        ArrayList<Integer> listTest = new ArrayList<Integer>();
        listTest.add(123456);
        listTest.add(1234);
        listTest.add(1233);
        listTest.add(12336);

        //测试In
        dbSelectBuilder = new DbSelectBuilder(dbStorer, null);
        dbSelectBuilder.addQuery(new QueryBuilder().and("f", QueryOperator.In, listTest));
        query.selectFields = dbSelectBuilder;
        dbStorer.load(coll);
        assertTrue(!coll.isEmpty());

        //测试In
        dbSelectBuilder = new DbSelectBuilder(dbStorer, null);
        dbSelectBuilder.addQuery(new QueryBuilder().and("f", QueryOperator.NotIn, listTest));
        query.selectFields = dbSelectBuilder;
        dbStorer.load(coll);
        assertTrue(coll.isEmpty());

        //测试IsOrNotNull
        dbSelectBuilder = new DbSelectBuilder(dbStorer, null);
        dbSelectBuilder.addQuery(new QueryBuilder().and("b", QueryOperator.IsOrNotNull, true));
        query.selectFields = dbSelectBuilder;
        dbStorer.load(coll);
        assertTrue(coll.isEmpty());

        //测试IsOrNotNull
        dbSelectBuilder = new DbSelectBuilder(dbStorer, null);
        dbSelectBuilder.addQuery(new QueryBuilder().and("b", QueryOperator.IsOrNotNull, false));
        query.selectFields = dbSelectBuilder;
        dbStorer.load(coll);
        assertTrue(!coll.isEmpty());
    }

    // 测试 Query without QueryBuilder
    public void testBuildConditions_Data_testIUD() throws Exception {
        CTestData.Entity entity = new CTestData.Entity();
        entity.setB("ceshi数据100");
        entity.setC(true);
        entity.setD(1521L);
        entity.setF(123456);
        entity.setH(true);
        entity.setJ(new BigDecimal("10000"));
        entity.setT(LocalDateTime.now());
        entity.setG(1000);

        dbStorer.insert(entity);

        assertTrue(entity.getA() > 0);

        entity.setB("ceshi数据11111");
        entity.setC(false);
        entity.setD(15211L);
        entity.setF(123456);

        dbStorer.update(entity);

        CTestData.Query query = new CTestData.Query();
        query.setA(entity.getA());
        CTestData.Coll coll = (CTestData.Coll) dbStorer.load(new CTestData.Coll(query));

        CTestData.Entity found = coll.firstOrDefault();

        assertNotNull(found);
        assertTrue(found.getB().equals("ceshi数据11111"));
        assertTrue(found.isC() == false);
        assertTrue(found.getD() == 15211L);

        entity.setC(true);
        entity.setD(11L);

        DbUpdateBuilder ub = new DbUpdateBuilder(dbStorer);
        ub.exclude("b");
        dbStorer.update(entity, ub);

        coll = (CTestData.Coll) dbStorer.load(new CTestData.Coll(query));
        found = coll.firstOrDefault();

        assertNotNull(found);
        assertTrue(found.getB().equals("ceshi数据11111"));
        assertTrue(found.isC() == true);
        assertTrue(found.getD() == 11L);


        Long newD = 89L;
        entity.setD(newD);

        ub = new DbUpdateBuilder(dbStorer);
        ub.include("d");
        dbStorer.update(entity, ub);

        coll = (CTestData.Coll) dbStorer.load(new CTestData.Coll(query));
        found = coll.firstOrDefault();

        assertNotNull(found);
        assertTrue(found.getB().equals("ceshi数据11111"));
        assertTrue(found.isC() == true);
        assertEquals(newD, found.getD());

        dbStorer.delete(query, CTestData.Entity.class);
        coll = (CTestData.Coll) dbStorer.load(new CTestData.Coll(query));
        assertTrue(coll.isEmpty());

        dbStorer.delete(entity);
    }

    // 测试 Date
    public void testBuildConditionsByDate() throws Exception {
        CTestTime.Entity entity = new CTestTime.Entity();
        Date d = new Date();
        Timestamp ts = new Timestamp(System.currentTimeMillis());
        LocalDateTime ldt=LocalDateTime.now().withNano(0);
        entity.setDate(ldt);
        entity.setTimestamp(ldt);
        entity.setDatetime(ldt);

        dbStorer.insert(entity);

        assertTrue(entity.getId() > 0);

        entity.setDate(ldt);
        entity.setTimestamp(ldt);
        entity.setDatetime(ldt);

        dbStorer.update(entity);

        CTestTime.Query query = new CTestTime.Query();
        query.setId(entity.getId());
        CTestTime.Coll coll = (CTestTime.Coll) dbStorer.load(new CTestTime.Coll(query));

        CTestTime.Entity found = coll.firstOrDefault();

        assertNotNull(found);
        assertTrue(found.getTimestamp().equals(ldt));
        assertTrue(found.getDatetime().equals(ldt));


        dbStorer.delete(entity);

    }
}

