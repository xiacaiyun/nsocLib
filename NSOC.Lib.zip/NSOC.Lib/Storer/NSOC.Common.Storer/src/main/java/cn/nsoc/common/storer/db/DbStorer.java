package cn.nsoc.common.storer.db;

import cn.nsoc.base.entity.sys.NSException;
import cn.nsoc.common.storer.EntityCollection;
import cn.nsoc.common.storer.EntityQuery;
import cn.nsoc.common.storer.Storer;
import cn.nsoc.common.storer.ValueConverter;
import cn.nsoc.common.storer.annotation.DbField;
import cn.nsoc.common.storer.annotation.DbQuery;
import cn.nsoc.common.storer.annotation.QueryOperator;
import cn.nsoc.common.storer.context.ContextParser;
import cn.nsoc.common.storer.context.EntityContext;
import cn.nsoc.common.storer.context.EntityProperty;
import cn.nsoc.common.storer.entity.StorerTypeEnum;
import cn.nsoc.common.storer.option.InsertBuilder;
import cn.nsoc.common.storer.option.UpdateBuilder;
import org.apache.log4j.Logger;
import org.springframework.util.StringUtils;

import javax.sql.DataSource;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.function.Function;


/**
 * Created by sam on 16-6-21.
 */
public abstract class DbStorer implements Storer {
    private static Logger logger = Logger.getLogger(DbStorer.class);


    protected String parameterSymbol = "?";
    private String tblPrefix = "tbl_";
    private DataSource dataSource;
    protected String keywordQuoterLeft = "";
    protected String keywordQuoterRight = "";
    protected StorerTypeEnum storerType;
    private ContextParser contextParser;


    public DbStorer() {
    }


    public void setKeywordQuoter(String left, String right) {
        keywordQuoterLeft = (left != null) ? left : "";
        keywordQuoterRight = (right != null) ? right : "";
    }

    protected void setDataSource(DataSource dataSource) {
        this.dataSource = dataSource;
    }

    public Connection getConn() throws SQLException {
        return dataSource.getConnection();
    }

    public void startTransaction(Function<Connection, Exception> action) throws NSException {

        try (Connection conn = getConn()) {
            conn.setAutoCommit(false);
            try {
                Exception innerEx = action.apply(conn);
                if (innerEx != null) {
                    throw innerEx;
                }
                else {
                    conn.commit();
                }
            } catch (Exception ex) {
                conn.rollback();
                throw ex;
            } finally {
                conn.setAutoCommit(false);
            }
        } catch (Exception ex) {
            throw new NSException(ex);
        }
    }

    public String getTblPrefix() {
        return tblPrefix;
    }

    public StorerTypeEnum getStorerType() {
        return storerType;
    }

    protected void setTblPrefix(String tblPrefix) {
        this.tblPrefix = tblPrefix;
    }


    protected Object toDsValue(ValueConverter converter, Object me) {
        if (converter == null) {
            return me;
        }
        else {
            return converter.toDsValue(me);
        }
    }

    protected Object fromDsValue(ValueConverter converter, Object me) throws NSException {
        if (converter == null) {
            return me;
        }
        else {
            return converter.fromDsValue(me);
        }
    }

    protected String getQueryOperator(String fieldname, QueryOperator queryOperator, String symbol, Object v, DbQuery dbQuery) throws NSException {
        if (StringUtils.isEmpty(v)) {
            return null;
        }

        String op = null;
        String fd = fieldname;
        switch (queryOperator) {
            case Equal:
                op = "%s=%s";
                break;
            case NotEqual:
                op = "%s!=%s";
                break;
            case GreatEqual:
                op = "%s>=%s";
                fd = getContextParser().trimQueryFlag(queryOperator,fieldname);
                break;
            case GreatThan:
                op = "%s>%s";
                fd = getContextParser().trimQueryFlag(queryOperator,fieldname);
                break;
            case LessEqual:
                op = "%s<=%s";
                fd = getContextParser().trimQueryFlag(queryOperator,fieldname);
                break;
            case LessThan:
                op = "%s<%s";
                fd = getContextParser().trimQueryFlag(queryOperator,fieldname);
                break;
            case Like:
                op = "%s like %s";
                break;
            case In: {
                if (v instanceof List<?>) {
                    List<String> list = new ArrayList<>();
                    for (int i = 0; i < ((List<?>) v).size(); i++) {
                        list.add(symbol);
                    }
                    if (!list.isEmpty()) {
                        op = "%s in(" + String.join(",", list) + ")";
                    }
                }
                fd = getContextParser().trimQueryFlag(queryOperator,fieldname);

                break;
            }
            case NotIn: {
                if (v instanceof List<?>) {
                    List<String> list = new ArrayList<>();
                    for (int i = 0; i < ((List<?>) v).size(); i++) {
                        list.add(symbol);
                    }
                    if (!list.isEmpty()) {
                        op = "%s not in(" + String.join(",", list) + ")";
                    }
                }
                fd = getContextParser().trimQueryFlag(queryOperator,fieldname);
                break;
            }
            case IsOrNotNull: {
                if (v instanceof Boolean) {
                    if (!((Boolean) v)) {
                        op = "%s is not null";
                    } else {
                        op = "%s is null";
                    }
                    fd = getContextParser().trimQueryFlag(queryOperator,fieldname);
                }
                break;
            }
            case SubQuery: {
                if ((dbQuery != null) && StringUtils.hasText(dbQuery.express())) {
                    op = dbQuery.express();
                }
                break;
            }
            default:
                throw new NSException(queryOperator + "not impliment");
        }

        if (op == null) {
            return null;
        }
        else {
            return String.format(op, getQuoteField(fd), symbol);
        }
    }

    public String getQuoteField(String fieldname) {
        return String.format("%s%s%s", keywordQuoterLeft, fieldname, keywordQuoterRight);
    }

    public String getQuoteField(String joinStr, List<String> fieldlist) {
        List<String> temp = new ArrayList<>();
        for (String s : fieldlist) {
            temp.add(this.getQuoteField(s));
        }
        return String.join(joinStr, temp);
    }

    protected Object[] getQueryValue(QueryOperator queryOperator, Object v) {
        switch (queryOperator) {
            case In: {
                if (v instanceof List<?>)
                    return ((List) v).toArray();
                break;
            }
            case NotIn: {
                if (v instanceof List<?>)
                    return ((List) v).toArray();
                break;
            }
            default:
                break;
        }
        return new Object[]{v};
    }

    protected String enumToSql(Enum e) {
        return e.name().replace("__", " ").replace("_", ",");
    }


    protected String convertSelectFields(String fields, EntityContext ctx) {
        if (!ctx.hasRenamedField() || !StringUtils.hasText(fields)) {
            return fields;
        }
        if (!"*".equals(fields.trim()))
            return fields;
        else {
            List<String> list = new ArrayList<>();
            list.add("*");
            for (Map.Entry<String, EntityProperty> entry : ctx.getProperties().entrySet()) {
                EntityProperty prop = entry.getValue();
                DbField dbField = prop.getDbField();
                if ((dbField != null) && !dbField.isRequired())
                    continue;

                if (prop.isRenamed()) {
                    list.add(String.format("%s as %s", getQuoteField(entry.getKey()), prop.getFieldNameInClass()));
                }
            }
            return String.join(",", list);
        }
    }

    public String getParameterSymbol() {
        return parameterSymbol;
    }

    public String escapeValue(String val) {
        return val;
    }

    protected void ignoreException(Exception ex) {
        //for sonar
    }

    @Override
    public ContextParser getContextParser() {
        return contextParser;
    }

    protected void setContextParser(ContextParser contextParser) {
        this.contextParser = contextParser;
    }

    @Override
    public <E, Q extends EntityQuery, C extends EntityCollection<E,Q>> C load(C me) throws NSException {
        return load(me, null);
    }

    @Override
    public <E, Q extends EntityQuery, C extends EntityCollection<E,Q>> C load(C me, String tableName) throws NSException {
        try (Connection conn = getConn()) {
            return load(me, tableName,conn);
        } catch (Exception ex) {
            throw new NSException(ex);
        }
    }

    @Override
    public <E, Q extends EntityQuery, C extends EntityCollection<E,Q>> C load(EntityContext context, C me) throws NSException {
        try (Connection conn = getConn()) {
            return load(context, me, null ,conn);
        } catch (Exception ex) {
            throw new NSException(ex);
        }
    }

    public <E, Q extends EntityQuery, C extends EntityCollection<E,Q>> C load(C me, String tableName,Connection conn) throws NSException {
        return load(null,me,tableName,conn);
    }

    public abstract <E, Q extends EntityQuery, C extends EntityCollection<E,Q>> C load(EntityContext context, C me, String tableName, Connection conn) throws NSException;

    @Override
    public boolean insert(Object me) throws NSException {
        return insert(me, null);
    }

    public abstract boolean insert(Object me, InsertBuilder builder,Connection conn) throws NSException;

    @Override
    public boolean batchInsert(List<Object> list) throws NSException {
        return batchInsert(list, null);
    }

    @Override
    public boolean batchInsert(List<Object> list, InsertBuilder builder) throws NSException {
        if (list == null || list.isEmpty()) {
            return true;
        }

        Function<Connection, Exception> action = conn -> {
            try {
                batchInsert(list, builder,conn);
                return null;
            } catch (NSException sqlEx) {
                logger.error(sqlEx);
                return sqlEx;
            }
        };

        try {
            this.startTransaction(action);
            return true;
        } catch (Exception ex) {
            logger.error(ex);
            return false;
        }
    }


    public abstract boolean batchInsert(List<Object> melist, InsertBuilder builder,Connection conn) throws NSException;

    @Override
    public boolean update(Object me, UpdateBuilder builder) throws NSException{
        try (Connection conn = getConn()){
            return this.update(me,builder,conn);
        }catch (Exception ex) {
            throw new NSException(ex);
        }
    }

    public abstract boolean update(Object me, UpdateBuilder builder,Connection conn) throws NSException;

    @Override
    public abstract <Q extends EntityQuery> boolean update(Object me, UpdateBuilder builder, Q query) throws NSException;

    public abstract boolean delete(Object me,Connection conn) throws NSException;
}
