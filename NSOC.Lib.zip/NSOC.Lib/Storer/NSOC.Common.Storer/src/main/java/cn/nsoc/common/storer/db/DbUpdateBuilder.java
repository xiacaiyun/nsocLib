package cn.nsoc.common.storer.db;

import cn.nsoc.common.storer.option.UpdateBuilder;
import cn.nsoc.common.storer.option.UpdateOperator;
import org.springframework.util.Assert;
import org.springframework.util.StringUtils;

import java.util.*;

/**
 * Created by sam on 16-7-14.
 */
public class DbUpdateBuilder implements UpdateBuilder {

    private Map<String, UpdateOperator> includelist = new HashMap<>();
    private List<String> excludelist = new ArrayList<>();

    public DbUpdateBuilder(DbStorer dbStorer) {
        Assert.notNull(dbStorer);
    }


    @Override
    public UpdateBuilder include(String... fields) {

        for (String field : fields) {
            include(field, UpdateOperator.Set);
        }
        return this;
    }

    @Override
    public UpdateBuilder include(String field, UpdateOperator operator) {
        if (StringUtils.hasText(field)) {
            includelist.put(field, operator);
        }
        return this;
    }

    @Override
    public UpdateBuilder exclude(String... fields) {
        Collections.addAll(excludelist, fields);
        return this;
    }

    @Override
    public boolean hasInclude() {
        return !includelist.isEmpty();
    }

    @Override
    public boolean hasExclude() {
        return !excludelist.isEmpty();
    }

    @Override
    public Map<String, UpdateOperator> getIncludes() {
        return includelist;
    }

    @Override
    public List<String> getExcludes() {
        return excludelist;
    }
}
