package cn.nsoc.common.storer.db;

import cn.nsoc.common.storer.entity.StorerTypeEnum;

import javax.sql.DataSource;

/**
 * Created by sam on 16-9-20.
 */
public class OracleJdbcStorer extends JdbcDbStorer {

    public OracleJdbcStorer(DataSource ds) {
        super(ds, StorerTypeEnum.oracle);
        setKeywordQuoter("\"", "\"");
    }
}
