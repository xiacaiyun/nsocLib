package cn.nsoc.common.storer.annotation.graph;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;


@Target(ElementType.TYPE)
@Retention(RetentionPolicy.RUNTIME)
public @interface Neo4jObject {

    String name() default "";

    Neo4jType type() default Neo4jType.Node;
}
