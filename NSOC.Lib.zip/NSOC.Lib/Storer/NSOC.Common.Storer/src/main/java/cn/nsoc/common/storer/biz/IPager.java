package cn.nsoc.common.storer.biz;

/**
 * Created by sam on 17-2-7.
 */
public interface IPager {
    Integer getPageId();

    void setPageId(Integer pageId);

    Integer getCountPerPage();

    void setCountPerPage(Integer countPerPage);

    String getPageRecIds();

    void setPageRecIds(String pagerecids);
}
