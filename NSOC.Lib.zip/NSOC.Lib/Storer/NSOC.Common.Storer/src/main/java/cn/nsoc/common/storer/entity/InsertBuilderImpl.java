//package cn.nsoc.common.storer.entity;
//
//import cn.nsoc.common.storer.option.InsertBuilder;
//import cn.nsoc.common.storer.option.InsertOption;
//import cn.nsoc.common.storer.option.UpdateOperator;
//
///**
// * Created by bobwang on 3/24/17.
// */
//public class InsertBuilderImpl implements InsertBuilder {
//    @Override
//    public InsertOption getInsertOption() {
//        return null;
//    }
//
//    @Override
//    public void setInsertOption(InsertOption option) {
//        //empty
//    }
//
//    @Override
//    public InsertBuilder append(String field, UpdateOperator operator) {
//        return null;
//    }
//
//    @Override
//    public String getTableName() {
//        return null;
//    }
//
//    @Override
//    public String getIDValue() {
//        return null;
//    }
//}
