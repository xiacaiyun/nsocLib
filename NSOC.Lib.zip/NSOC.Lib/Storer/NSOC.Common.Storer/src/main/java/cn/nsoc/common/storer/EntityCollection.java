package cn.nsoc.common.storer;

import org.springframework.util.Assert;

import java.util.ArrayList;
import java.util.Map;

/**
 * Created by sam on 16-6-8.
 */
public class EntityCollection<E, Q extends EntityQuery> extends ArrayList<E> {

    private Class<Q> queryClass;
    private Class<E> entityClass;

    private transient Q query;
    private transient Map<String, Object> agg;

    public EntityCollection(Class<E> classofE, Class<Q> classofQ) {
        entityClass = classofE;
        queryClass = classofQ;
    }

    public E newEntity() {
        try {
            return getEntityClass().newInstance();
        } catch (Exception e) {
            ignoreException(e);
            return null;
        }
    }

    public Q getQuery() {

        try {
            if (this.query == null) {
                this.query = getQueryClass().newInstance();
            }
        } catch (Exception e) {
            this.query = null;
            ignoreException(e);
        }
        return this.query;
    }

    public void setQuery(Q q) {

        Assert.notNull(q);

        this.query = q;
    }

    public Class<E> getEntityClass() {
        return entityClass;
    }

    public Class<Q> getQueryClass() {
        return queryClass;
    }

    public E firstOrDefault() {
        return this.isEmpty() ? null : get(0);
    }

    private static void ignoreException(Exception ex) {
        // for sonar
    }

    public Map<String, Object> getAgg() {
        return agg;
    }

    public void setAgg(Map<String, Object> agg) {
        this.agg = agg;
    }

    @Override
    public void clear() {
        super.clear();
        setAgg(null);
    }
}
