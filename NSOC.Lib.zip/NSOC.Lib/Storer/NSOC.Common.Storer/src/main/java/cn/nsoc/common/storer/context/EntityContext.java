package cn.nsoc.common.storer.context;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Created by sam on 16-6-22.
 */
public class EntityContext {
    private HashMap<String, EntityProperty> properties;
    private Class<?> type;
    private String tableName;
    private List<EntityProperty> keyPropertys;
    private boolean bhasRenamedField;

    public EntityContext() {
        properties = new HashMap<>();
        keyPropertys = new ArrayList<>();
    }


    public Map<String, EntityProperty> getProperties() {
        return properties;
    }

    public EntityProperty addProperty(EntityProperty p) {
        properties.put(p.getFieldName(), p);
        return p;
    }

    public Class<?> getType() {
        return type;
    }

    public void setType(Class<?> type) {
        this.type = type;
    }

    public String getTableName() {
        return tableName;
    }

    public void setTableName(String tableName) {
        this.tableName = tableName;
    }

    public List<EntityProperty> getKeyProperty() {
        return keyPropertys;
    }

    public void setKeyProperty(EntityProperty keyProperty) {
        this.keyPropertys.add(keyProperty);
    }

    public boolean hasRenamedField() {
        return bhasRenamedField;
    }

    public void setHasRenamedField(boolean bhasRenamedField) {
        this.bhasRenamedField = bhasRenamedField;
    }
}
