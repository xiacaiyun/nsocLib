package cn.nsoc.common.storer.annotation;

/**
 * Created by sam on 16-6-27.
 */
public enum QueryOperator {
    Equal,
    GreatThan,
    GreatEqual,
    LessThan,
    LessEqual,
    In,
    Like,
    NotIn,
    IsOrNotNull,
    SubQuery,
    NotEqual
}
