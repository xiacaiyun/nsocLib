package cn.nsoc.common.storer.db;

import cn.nsoc.base.entity.tuple.Tuple2;
import cn.nsoc.common.storer.option.QueryBuilder;
import cn.nsoc.common.storer.option.QueryItem;
import cn.nsoc.common.storer.option.SelectBuilder;
import org.springframework.util.Assert;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by sam on 16-7-10.
 * <p>
 * 临时做法，以后要换掉
 */
public class DbSelectBuilder implements SelectBuilder {

    private final List<String> fields;
    private final List<String> quotedfields;
    private QueryBuilder conditions;

    private DbStorer dbStorer = null;

    public DbSelectBuilder(DbStorer dbStorer, String[] fields) {
        Assert.notNull(dbStorer);
        this.dbStorer = dbStorer;

        this.fields = new ArrayList<>();
        this.quotedfields = new ArrayList<>();

        if (fields != null) {
            addField(fields);
        }
    }

    public QueryBuilder addQuery(QueryBuilder builder) {
        Assert.notNull(builder);

        if (conditions == null)
            conditions = builder;
        else
            conditions.and(builder);

        return conditions;
    }

    public List<String> getFields() {
        return fields;
    }


    public SelectBuilder addField(String[] fields) {
        if (fields != null) {
            for (String f : fields) {
                addField(f);
            }
        }
        return this;
    }

    @Override
    public SelectBuilder addField(String field) {
        fields.add(field);
        quotedfields.add(dbStorer.getQuoteField(field));
        return this;
    }

    @Override
    public boolean hasCondition() {
        return (conditions != null) && !conditions.isEmpty();
    }

    @Override
    public Tuple2<String, List<QueryItem>> toStatment() {
        StringBuilder sb = new StringBuilder();
        List<QueryItem> list = new ArrayList<>();
        conditions.toStatment(sb, list);

        return new Tuple2<>(sb.toString(), list);
    }

    /*
    *
    * 临时做法，直接写 count(abc) as abc, 等等
    *
    */
    public SelectBuilder addField(String field, String express) {
        fields.add(field);
        quotedfields.add(String.format("%s as %s", express, dbStorer.getQuoteField(field)));
        return this;
    }

    @Override
    public String toString() {
        if (quotedfields.isEmpty())
            return "*";
        else
            return String.join(",", quotedfields);
    }
}
