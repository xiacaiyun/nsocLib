package cn.nsoc.common.storer.option;

/**
 * Created by sam on 16-7-14.
 */
public enum UpdateOperator {
    Set,
    Add
}
