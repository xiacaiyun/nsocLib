package cn.nsoc.common.storer;

import cn.nsoc.base.entity.sys.NSException;

/**
 * Created by bobwang on 9/23/16.
 */
public interface IDataConnector {

    enum AccessType {
        HDFS
    }

    String getData(String path) throws NSException;

    boolean exists(String path);
}
