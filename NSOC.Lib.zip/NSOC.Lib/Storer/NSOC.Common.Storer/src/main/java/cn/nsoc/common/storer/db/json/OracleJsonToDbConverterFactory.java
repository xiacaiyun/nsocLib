package cn.nsoc.common.storer.db.json;

/**
 * Created by sam on 17-3-8.
 */
public class OracleJsonToDbConverterFactory extends JsonToDbConverterFactory {

    public OracleJsonToDbConverterFactory() {
        super();
        converters.put("oracle.sql.TIMESTAMP", new OracleTimestampConverter());
    }

    public class OracleTimestampConverter implements JsonToDbConverter {
        @Override
        public Object toJsonValue(Object me) {
            String str = me.toString();
            int idx = str.indexOf('.');
            if (idx >= 0) {
                return str.substring(0, idx);
            } else
                return str;
        }
    }
}
