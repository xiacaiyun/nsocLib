package cn.nsoc.common.storer.entity;

import cn.nsoc.base.entity.sys.NSException;

import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Created by fengww on 12/26/16.
 */
public class QueryMap {
    private LinkedHashMap<String, Object> valContainer;
    private LinkedHashMap<String, String> opContainer;
    private LinkedHashSet<String> querys;
    private static final Pattern numPattern = Pattern.compile("\\d+");
    private static final Pattern strPattern = Pattern.compile("^\"[\\s|\\S]*?\"$");
    private static final Pattern opPattern = Pattern.compile(">|=|<|>=|<=");

    public QueryMap() {
        valContainer = new LinkedHashMap<>();
        opContainer = new LinkedHashMap<>();
        querys = new LinkedHashSet<>();
    }

    public void put(String field, String op, String sv) throws NSException {
        Matcher numMatch = numPattern.matcher(sv);
        Matcher strMatch = strPattern.matcher(sv);
        if (numMatch.matches()) {
            valContainer.putIfAbsent(field, Integer.parseInt(sv));
        } else if (strMatch.matches()) {
            String val = sv.substring(1, sv.length() - 1);
            valContainer.putIfAbsent(field, val);
        } else
            throw new NSException("invalid value!");

        Matcher opMatch = opPattern.matcher(op);
        if (opMatch.find()) {
            opContainer.putIfAbsent(field, op);
        } else
            throw new NSException("unimplement operation!");
        querys.add(field);
    }

    public String getOp(String field) {
        return opContainer.getOrDefault(field, null);
    }

    public Object getVal(String field) {
        return valContainer.getOrDefault(field, null);
    }

    public Set<String> getQuerys() {
        return querys;
    }
}
