package cn.nsoc.common.storer.option;

import cn.nsoc.base.entity.tuple.Tuple2;

import java.util.List;

/**
 * Created by sam on 16-7-10.
 */
public interface SelectBuilder {
    SelectBuilder addField(String field);

    boolean hasCondition();

    Tuple2<String, List<QueryItem>> toStatment();
}
