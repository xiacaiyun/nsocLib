package cn.nsoc.common.storer.option;

import cn.nsoc.common.storer.annotation.QueryOperator;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by sam on 17-7-12.
 */
public class QueryBuilder {
    enum QueryVerb {
        AND,
        OR,
        SubBegin,
        SubEnd
    }


    private List<Object> querys = new ArrayList<>();

    public QueryBuilder add(QueryItem query) {
        querys.add(query);
        return this;
    }

    public QueryBuilder add(QueryBuilder builder) {
        querys.add(QueryVerb.SubBegin);
        querys.add(builder);
        querys.add(QueryVerb.SubEnd);
        return this;
    }

    public QueryBuilder add(String field, QueryOperator operator, Object value) {
        querys.add(create(field, operator, value));
        return this;
    }

    public QueryBuilder and(QueryBuilder builder) {
        querys.add(QueryVerb.AND);
        querys.add(QueryVerb.SubBegin);
        querys.add(builder);
        querys.add(QueryVerb.SubEnd);
        return this;
    }

    public QueryBuilder and(QueryItem query) {
        querys.add(QueryVerb.AND);
        querys.add(query);
        return this;
    }

    public QueryBuilder or(QueryBuilder builder) {
        querys.add(QueryVerb.OR);
        querys.add(QueryVerb.SubBegin);
        querys.add(builder);
        querys.add(QueryVerb.SubEnd);
        return this;
    }

    public QueryBuilder or(QueryItem query) {
        querys.add(QueryVerb.OR);
        querys.add(query);
        return this;
    }


    public QueryBuilder and(String field, QueryOperator operator, Object value) {
        querys.add(QueryVerb.AND);
        querys.add(create(field, operator, value));
        return this;
    }

    public QueryBuilder or(String field, QueryOperator operator, Object value) {
        querys.add(QueryVerb.OR);
        querys.add(create(field, operator, value));
        return this;
    }


    public void toStatment(StringBuilder sb, List<QueryItem> values) {

        for (Object o : querys) {
            if (o instanceof Enum) {
                verbToStatment(sb, (QueryVerb) o);
            } else if (o instanceof QueryBuilder) {
                ((QueryBuilder) o).toStatment(sb, values);
            } else if (o instanceof QueryItem) {
                ((QueryItem) o).toStatment(sb, values);
            }
        }
    }


    private void verbToStatment(StringBuilder sb, QueryVerb verb) {
        switch (verb) {
            case AND:
            case OR:
                sb.append(" ").append(verb).append(" ");
                break;
            case SubBegin:
                sb.append(" (");
                break;
            case SubEnd:
                sb.append(") ");
                break;
            default:
                break;
        }
    }

    public boolean isEmpty() {
        return querys.isEmpty();
    }

    public static QueryItem create(String field, QueryOperator operator) {
        return new QueryItem(field, operator);
    }

    public static QueryItem create(String field, QueryOperator operator, Object value) {
        return new QueryItem(field, operator, value);
    }
}
