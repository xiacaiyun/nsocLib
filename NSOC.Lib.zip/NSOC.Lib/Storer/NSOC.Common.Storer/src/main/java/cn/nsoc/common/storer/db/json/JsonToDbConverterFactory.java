package cn.nsoc.common.storer.db.json;

import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Created by sam on 17-3-8.
 */
public class JsonToDbConverterFactory {

    private static JsonToDbConverterFactory instance;

    public static JsonToDbConverterFactory getInstance() {
        if (instance == null)
            instance = new JsonToDbConverterFactory();

        return instance;
    }

    public Object convertValueForJson(Object v) {
        JsonToDbConverter converter = converters.getOrDefault(v.getClass().getName(), null);
        if (converter == null)
            return v;
        else
            return converter.toJsonValue(v);
    }

    public List<Map<String, Object>> convertForJson(List<Map<String, Object>> list) {
        if (list != null) {
            for (Map<String, Object> map : list) {
                if (map != null) {
                    for (Map.Entry<String, Object> entry : map.entrySet()) {
                        Object v = entry.getValue();
                        if (v != null) {
                            entry.setValue(convertValueForJson(v));
                        }
                    }
                }
            }
        }
        return list;
    }

    protected HashMap<String, JsonToDbConverter> converters = new HashMap<>();

    public JsonToDbConverterFactory() {
        converters.put(Timestamp.class.getName(), new TimestampConverter());
    }

    public class TimestampConverter implements JsonToDbConverter {

        @Override
        public Object toJsonValue(Object me) {
            return new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format((Timestamp) me);
        }
    }
}
