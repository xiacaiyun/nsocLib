package cn.nsoc.common.storer.annotation.graph;

public enum Neo4jType {
    Node,
    Relation
}
