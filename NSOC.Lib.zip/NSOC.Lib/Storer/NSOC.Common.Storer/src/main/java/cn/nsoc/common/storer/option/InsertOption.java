package cn.nsoc.common.storer.option;

/**
 * Created by sam on 16-6-21.
 */

public enum InsertOption {

    IgnoreOnDuplicate,

    UpdateOnDuplicate
}
