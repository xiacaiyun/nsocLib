package cn.nsoc.common.storer.biz;

import cn.nsoc.common.storer.Storer;
import cn.nsoc.common.storer.db.DbStorer;

/**
 * Created by sam on 17-2-10.
 * 为了兼容之前的DbStorer
 */
public abstract class BaseBiz extends CommonBaseBiz {


    public BaseBiz() {
        super();
    }

    public BaseBiz(Storer storer, Storer readOnlyStorer) {
        super(storer, readOnlyStorer);
    }

    public BaseBiz(String name) {
        super(name);
    }

    public BaseBiz(Storer storer) {
        super(storer);
    }

    public DbStorer getDbStorer() {
        return (DbStorer)getStorer(false);
    }

    public DbStorer getDbStorer(boolean readonly) {
        return (DbStorer)getStorer(readonly);
    }

    public void setDbStorer(DbStorer dbStorer) {
        setStorer(dbStorer);
    }

    public void setDbStorer(DbStorer dbStorer, DbStorer dbReadOnlyStorer) {
        setStorer(dbStorer,dbReadOnlyStorer);
    }
}
