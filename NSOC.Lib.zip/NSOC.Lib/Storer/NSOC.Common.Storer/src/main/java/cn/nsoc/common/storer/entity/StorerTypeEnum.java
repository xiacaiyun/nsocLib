package cn.nsoc.common.storer.entity;

/**
 * Created by bobwang on 10/24/16.
 */
public enum StorerTypeEnum {
    mysql, oracle, sqlserver, jdbc
}
