package cn.nsoc.common.storer.annotation;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

/**
 * Created by sam on 16-6-22.
 */
@Target(ElementType.FIELD)
@Retention(RetentionPolicy.RUNTIME)
public @interface DbField {

    enum Direction {
        In,
        Out,
        INOUT
    }

    String name() default "";

    boolean isKey() default false;

    boolean isRequired() default true;

    Direction direction() default Direction.In;

    boolean isAutoIncrement() default true;

    boolean isCompressed() default false;
}
