package cn.nsoc.common.storer;

import cn.nsoc.base.entity.sys.NSException;
import cn.nsoc.common.storer.db.DbStorer;
import cn.nsoc.common.storer.entity.MetaDesc;

/**
 * Created by bobwang on 10/24/16.
 */
public interface IStoreMeta {
    MetaDesc getEntityDesc(DbStorer storer, String name, String url) throws NSException;
}
