package cn.nsoc.common.storer.db.json;

/**
 * Created by sam on 17-3-8.
 */
public class SqlJsonToDbConverterFactory extends JsonToDbConverterFactory {
}
