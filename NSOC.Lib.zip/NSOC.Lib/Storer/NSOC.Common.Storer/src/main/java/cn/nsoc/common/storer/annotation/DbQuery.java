package cn.nsoc.common.storer.annotation;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

/**
 * Created by sam on 16-6-27.
 */
@Target(ElementType.FIELD)
@Retention(RetentionPolicy.RUNTIME)
public @interface DbQuery {

    String name() default "";

    @Deprecated
    Class<?> valueType() default Integer.class;

    QueryOperator Operator() default QueryOperator.Equal;

    boolean isJsonType() default false;


    // 用法： " id in (select id from tbl_abc where $s = $s )"
    String express() default "";
}
