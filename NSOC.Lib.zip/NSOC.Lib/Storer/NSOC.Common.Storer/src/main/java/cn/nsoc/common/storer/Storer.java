package cn.nsoc.common.storer;

import cn.nsoc.base.entity.sys.NSException;
import cn.nsoc.common.storer.context.ContextParser;
import cn.nsoc.common.storer.context.EntityContext;
import cn.nsoc.common.storer.option.InsertBuilder;
import cn.nsoc.common.storer.option.UpdateBuilder;

import java.util.List;
import java.util.Map;

public interface Storer {

    boolean insert(Object me) throws NSException;

    boolean insert(Object me, InsertBuilder builder) throws NSException;

    boolean batchInsert(List<Object> melist) throws NSException;

    boolean batchInsert(List<Object> melist, InsertBuilder builder) throws NSException;

    boolean delete(Object me) throws NSException;

    <Q extends EntityQuery> boolean delete(Q query, Class<?> eClass) throws NSException;

    boolean update(Object me) throws NSException;

    boolean update(Object me, UpdateBuilder builder) throws NSException;

    <Q extends EntityQuery> boolean update(Object me, UpdateBuilder builder, Q query) throws NSException;

    <E, Q extends EntityQuery, C extends EntityCollection<E,Q>> C load(C me) throws NSException;

    <E, Q extends EntityQuery, C extends EntityCollection<E,Q>> C load(C me, String tableName) throws NSException;

    <E, Q extends EntityQuery, C extends EntityCollection<E,Q>> C load(EntityContext context, C me) throws NSException;

    List<Map<String, Object>> exec(String sql) throws NSException;

    InsertBuilder createInsertBuilder(EntityContext context);

    @Deprecated
    boolean insertKV(Map<String, Object> me, InsertBuilder builder) throws NSException;

    ContextParser getContextParser();

    default void shutdown(){}
}
