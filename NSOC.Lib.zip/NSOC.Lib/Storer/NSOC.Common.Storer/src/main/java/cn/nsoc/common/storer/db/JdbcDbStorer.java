package cn.nsoc.common.storer.db;

import cn.nsoc.base.entity.sys.NSException;
import cn.nsoc.base.entity.tuple.Tuple2;
import cn.nsoc.common.storer.EntityCollection;
import cn.nsoc.common.storer.EntityQuery;
import cn.nsoc.common.storer.ValueConverter;
import cn.nsoc.common.storer.annotation.DbField;
import cn.nsoc.common.storer.annotation.DbQuery;
import cn.nsoc.common.storer.annotation.QueryOperator;
import cn.nsoc.common.storer.context.ContextParser;
import cn.nsoc.common.storer.context.EntityContext;
import cn.nsoc.common.storer.context.EntityProperty;
import cn.nsoc.common.storer.db.json.JsonToDbConverterFactory;
import cn.nsoc.common.storer.db.json.MySqlJsonToDbConverterFactory;
import cn.nsoc.common.storer.db.json.OracleJsonToDbConverterFactory;
import cn.nsoc.common.storer.db.json.SqlJsonToDbConverterFactory;
import cn.nsoc.common.storer.entity.QueryMap;
import cn.nsoc.common.storer.entity.StorerTypeEnum;
import cn.nsoc.common.storer.option.*;
import org.apache.log4j.Logger;
import org.springframework.util.Assert;
import org.springframework.util.StringUtils;

import javax.sql.DataSource;
import java.lang.reflect.Field;
import java.math.BigDecimal;
import java.sql.*;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.*;
import java.util.stream.Collectors;


/**
 * Created by sam on 16-6-21.
 */
public class JdbcDbStorer extends DbStorer {

    private static JdbcDbStorer defaultInstance;
    private static JdbcDbStorer readonlyInstance;
    private static HashMap<String, JdbcDbStorer[]> instanceMap = new HashMap<>();
    private static Logger logger = Logger.getLogger("JdbcDbStorer");
    private JsonToDbConverterFactory jsonToDbConverterFactory;
    private DbValueConverterFactory dbValueConverterFactory = new DbValueConverterFactory();


    public JdbcDbStorer(DataSource ds) {
        Assert.notNull(ds);

        storerType = StorerTypeEnum.jdbc;
        setDataSource(ds);
        setJsonToDbConverterFactory(new JsonToDbConverterFactory());

        setContextParser(new ContextParser(dbValueConverterFactory, getTblPrefix()));
    }

    protected JdbcDbStorer(DataSource ds, StorerTypeEnum type) {
        this(ds);
        storerType = type;
    }

    public static JdbcDbStorer createJdbcDbStorer(String type, DataSource ds) throws NSException {
        Assert.notNull(type);

        StorerTypeEnum typeEnum = Enum.valueOf(StorerTypeEnum.class, type.toLowerCase());
        JdbcDbStorer jdbcDbStorer;

        switch (typeEnum) {
            case mysql:
                jdbcDbStorer = new MySqlJdbcStorer(ds);
                jdbcDbStorer.setJsonToDbConverterFactory(new MySqlJsonToDbConverterFactory());
                break;
            case oracle:
                jdbcDbStorer = new OracleJdbcStorer(ds);
                jdbcDbStorer.setJsonToDbConverterFactory(new OracleJsonToDbConverterFactory());
                break;
            case sqlserver:
                jdbcDbStorer = new SqlServerJdbcStorer(ds);
                jdbcDbStorer.setJsonToDbConverterFactory(new SqlJsonToDbConverterFactory());
                break;
            case jdbc:
                jdbcDbStorer = new JdbcDbStorer(ds);
                break;
            default:
                throw new NSException(type + " is not implemented");
        }
        return jdbcDbStorer;
    }

    public JsonToDbConverterFactory getJsonToDbConverterFactory() {
        return jsonToDbConverterFactory;
    }

    public void setJsonToDbConverterFactory(JsonToDbConverterFactory jsonToDbConverterFactory) {
        this.jsonToDbConverterFactory = jsonToDbConverterFactory;
    }

    public static void setHandler(String name, JdbcDbStorer handler) {
        setHandler(name, handler, null);
    }

    public static void setHandler(String name, JdbcDbStorer handler, JdbcDbStorer readonlyhandler) {
        Assert.notNull(handler);
        JdbcDbStorer[] handlers = new JdbcDbStorer[2];
        handlers[0] = handler;
        handlers[1] = (readonlyhandler == null) ? handler : readonlyhandler;
        instanceMap.put(name, handlers);
    }

    public static void setDefaultHandler(JdbcDbStorer handler) {
        setDefaultHandler(handler, null);
    }

    public static void setDefaultHandler(JdbcDbStorer handler, JdbcDbStorer readonlyhandler) {
        defaultInstance = handler;
        readonlyInstance = readonlyhandler;
    }

    public static JdbcDbStorer getInstance(String name) {
        return getInstance(name, false);
    }

    public static JdbcDbStorer getInstance(String name, boolean readonly) {
        JdbcDbStorer[] handlers = instanceMap.get(name);
        Assert.notNull(handlers);

        return handlers[readonly ? 1 : 0];
    }

    public static JdbcDbStorer getInstance() {
        Assert.notNull(defaultInstance);
        return defaultInstance;
    }

    public static JdbcDbStorer getReadonlyInstance() {
        if (readonlyInstance != null) {
            return readonlyInstance;
        }
        return getInstance();
    }

    protected <Q extends EntityQuery> String buildQuery(Q query, List<Tuple2<EntityProperty, QueryItem>> listProp) throws NSException {
        EntityContext qctx = getContextParser().getObjectProperties(query.getClass());
        StringBuilder sbWhere = new StringBuilder();

        try {

            for (EntityProperty prop : qctx.getProperties().values()) {

                Field fd = prop.getField();
                DbQuery dbQuery = prop.getDbQuery();
                Object v =  fd.get(query);
                if (v == null){
                    continue;
                }

                if (dbQuery != null && dbQuery.isJsonType()) {
                    String queryitem = buildJsonQuery(prop, fd.get(query), getParameterSymbol());
                    if (StringUtils.hasText(queryitem)) {
                        sbWhere.append(queryitem);

                        listProp.add(new Tuple2<>(prop, new QueryItem(prop.getFieldName(), dbQuery.Operator(), v)));
                    }
                    continue;
                }
                QueryOperator operator = (dbQuery == null) ? QueryOperator.Equal : dbQuery.Operator();
                String queryitem = super.getQueryOperator(prop.getFieldName(), operator, getParameterSymbol(), v, dbQuery);
                if (StringUtils.hasText(queryitem)) {
                    sbWhere.append(String.format(" and %s ", queryitem));
                    listProp.add(new Tuple2<>(prop, new QueryItem(prop.getFieldName(), operator, v)));
                }
            }
            return sbWhere.toString();
        } catch (Exception ex) {
            throw new NSException(ex);
        }
    }

    protected <Q extends EntityQuery> String buildConditions(Q query, List<Tuple2<EntityProperty, QueryItem>> listProp) throws NSException {
        EntityContext qctx = getContextParser().getObjectProperties(query.getClass());

        if (query.selectFields == null || !query.selectFields.hasCondition()) {
            return "";
        }

        Tuple2<String, List<QueryItem>> conditions = query.selectFields.toStatment();
        List<Object> phases = new ArrayList<>();

        Map<String, EntityProperty> props = qctx.getProperties();

        for (QueryItem o : conditions.getB()) {

            String queryitem = super.getQueryOperator(o.getField(), o.getOperator(), getParameterSymbol(), o.getValue(), null);
            if (StringUtils.hasText(queryitem)) {
                phases.add(queryitem);
                EntityProperty prop = props.getOrDefault(o.getField(), null);
                if (prop != null) {
                    listProp.add(new Tuple2<>(prop, o));
                }
                else {
                    throw new NSException(String.format("QueryBuilder: %s not found", o.getField()));
                }
            }
        }
        return String.format(conditions.getA(), phases.toArray());
    }

    protected String buildJsonQuery(EntityProperty prop, Object v, String parameterSymbol) throws NSException {
        if (StringUtils.isEmpty(v)) {
            return null;
        }
        if (v instanceof QueryMap) {
            QueryMap mv = (QueryMap) v;
            List<String> items = new ArrayList<>();
            StringBuilder sbWhere = new StringBuilder(" and ");
            String op = "%s->'$.%s'%s%s";
            mv.getQuerys().forEach(k -> items.add(String.format(op, prop.getFieldName(), k, mv.getOp(k), parameterSymbol)));
            sbWhere.append(String.join(" and ", items));
            return sbWhere.toString();
        } else {
            throw new NSException("json field must be mapped as QueryMap type!");
        }
    }

    protected String buildUpdateField(EntityContext ctx, Map<String, UpdateOperator> fields, List<EntityProperty> listProp) {

        Collection<EntityProperty> fdprops = ctx.getProperties().values();

        StringBuilder sbSet = new StringBuilder();

        for (Map.Entry<String, UpdateOperator> field : fields.entrySet()) {
            EntityProperty prop = fdprops.stream()
                    .filter(p -> p.getFieldName().equals(field.getKey()))
                    .findFirst().orElse(null);
            Assert.notNull(prop);

            switch (field.getValue()) {
                case Set:
                    sbSet.append(String.format(" %s = %s ,",
                            getQuoteField(prop.getFieldName()), getParameterSymbol()));
                    break;
                case Add:
                    sbSet.append(String.format(" %s = %s + %s,",
                            getQuoteField(prop.getFieldName()),
                            getQuoteField(prop.getFieldName()),
                            getParameterSymbol()));
                    break;
                default:
                    break;
            }
            listProp.add(prop);
        }
        Assert.isTrue(listProp.size() == fields.size());
        sbSet.deleteCharAt(sbSet.length() - 1);
        return sbSet.toString();
    }

    protected String buildExUpdateField(EntityContext ctx, List<String> excludefields, List<EntityProperty> listProp) {

        StringBuilder sbSet = new StringBuilder();
        for (EntityProperty prop : ctx.getProperties().values()) {

            DbField fd = prop.getDbField();
            if (fd != null && !fd.isRequired()) {
                continue;
            }
            if ((!prop.getIsKey()) && !excludefields.contains(prop.getField().getName())) {
                sbSet.append(String.format(" %s = %s ,", getQuoteField(prop.getFieldName()), getParameterSymbol()));
                listProp.add(prop);
            }
        }
        Assert.notEmpty(listProp);
        sbSet.deleteCharAt(sbSet.length() - 1);
        return sbSet.toString();
    }

    protected void fillQuery(PreparedStatement pstat, int startindex, List<Tuple2<EntityProperty, QueryItem>> listProp) throws NSException {
        try {
            int counter = startindex;
            for (Tuple2<EntityProperty, QueryItem> tuple2 : listProp) {
                EntityProperty prop = tuple2.getA();
                QueryItem qi = tuple2.getB();

                DbQuery dbQuery = prop.getDbQuery();
                if (dbQuery != null && dbQuery.isJsonType()) {
                    QueryMap meta = (QueryMap) qi.getValue();
                    for (String metaData : meta.getQuerys()) {
                        pstat.setObject(counter++, meta.getVal(metaData));
                    }
                    continue;
                }
                QueryOperator operator = qi.getOperator();
                ValueConverter converter = prop.getValueConverter();
                Object[] values = getQueryValue(operator, qi.getValue());
                for (Object val : values) {

                    switch (operator) {
                        case Like:
                            pstat.setObject(counter++, toDsValue(converter, "%" + escapeValue((String) val) + "%"));
                            break;
                        case IsOrNotNull:
                            break;
                        default:
                            pstat.setObject(counter++, toDsValue(converter, val));
                            break;
                    }
                }
            }
        } catch (Exception ex) {
            throw new NSException(ex);
        }
    }

    protected void fillObject(PreparedStatement pstat, int startindex, Object o, List<EntityProperty> listProp) throws NSException {
        try {
            int counter = startindex;
            for (EntityProperty prop : listProp) {
                Field fd = prop.getField();
                pstat.setObject(counter++, toDsValue(prop.getValueConverter(), fd.get(o)));
            }
        } catch (Exception ex) {
            throw new NSException(ex);
        }
    }

    protected boolean doInsert(Connection conn, Object me, InsertBuilder builder) throws NSException {


        EntityContext ctx = getContextParser().getObjectProperties(me);
        EntityProperty propAutoIncrement = null;

        List<EntityProperty> listProp = new ArrayList<>();
        List<String> listParameters = new ArrayList<>();
        List<String> listFields = new ArrayList<>();
        for (EntityProperty prop : ctx.getProperties().values()) {

            DbField dbFd = prop.getDbField();
            if (dbFd != null) {
                if (!dbFd.isRequired()) {
                    continue;
                }
                if (dbFd.isKey() && dbFd.isAutoIncrement()) {
                    propAutoIncrement = prop;
                }
            }

            listFields.add(prop.getFieldName());
            if (dbFd != null && dbFd.isCompressed()) {
                listParameters.add(String.join(getParameterSymbol(), "compress(", ")"));
            } else {
                listParameters.add(getParameterSymbol());
            }
            listProp.add(prop);
        }


        String builderString = "";
        InsertOption option = null;
        if (builder != null) {
            option = builder.getInsertOption();

            if (option == InsertOption.UpdateOnDuplicate) {
                builderString = " ON DUPLICATE KEY UPDATE " + builder.toString();
            }
        }


        String sql = String.format("insert %s into %s (%s) values (%s) %s ",
                (option == InsertOption.IgnoreOnDuplicate) ? "IGNORE" : "",
                ctx.getTableName(),
                getQuoteField(",", listFields),
                String.join(",", listParameters),
                builderString
        );


        PreparedStatement pstat = null;
        try {
            pstat = (propAutoIncrement != null) ?
                    conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS) :
                    conn.prepareStatement(sql);


            for (int i = 0; i < listProp.size(); i++) {
                EntityProperty prop = listProp.get(i);
                Field fd = prop.getField();
                pstat.setObject(i + 1, toDsValue(prop.getValueConverter(), fd.get(me)));
            }

            if (logger.isDebugEnabled()) {
                logger.debug(pstat.toString());
            }
            pstat.executeUpdate();
            if (propAutoIncrement != null) {
                ResultSet rs = pstat.getGeneratedKeys();
                if (rs.next()) {
                    propAutoIncrement.getField()
                            .set(me, fromDsValue(propAutoIncrement.getValueConverter(), rs.getObject(1)));
                }
                rs.close();
            }
            return true;
        } catch (Exception sqlex) {
            throw new NSException(sqlex);
        } finally {
            if (pstat != null) {
                try {
                    pstat.close();
                } catch (Exception ex) {
                    ignoreException(ex);
                }
            }
        }
    }

    @Override
    public boolean insert(Object me, InsertBuilder builder) throws NSException {
        try (Connection conn = getConn()) {
            return insert(me, builder,conn);
        } catch (Exception sqlex) {
            throw new NSException(sqlex);
        }
    }

    @Override
    public boolean insert(Object me, InsertBuilder builder,Connection conn) throws NSException {
        Assert.notNull(conn);
        return doInsert(conn, me, builder);
    }

    @Override
    public boolean batchInsert(List<Object> list, InsertBuilder builder,Connection conn) throws NSException {
        if (list == null || list.isEmpty()) {
            return true;
        }

        InsertOption option = (builder == null) ? null : builder.getInsertOption();
        StringBuilder sb = new StringBuilder();
        String builderString = "";
        if (option == InsertOption.UpdateOnDuplicate) {
            if (builder != null) { // for sonar
                builderString = " ON DUPLICATE KEY UPDATE " + builder.toString();
            }
        }

        Object me = list.get(0);
        List<String> listParameters = new ArrayList<>();
        List<String> listFieldName = new ArrayList<>();
        List<EntityProperty> listProp = new ArrayList<>();
        List<Field> listField = new ArrayList<>();
        List<ValueConverter> listDbValueConverter = new ArrayList<>();
        EntityContext ctx = getContextParser().getObjectProperties(me);
        for (EntityProperty prop : ctx.getProperties().values()) {
            DbField dbField = prop.getDbField();
            if (dbField != null) {
                if (!dbField.isRequired() || (dbField.isKey() && dbField.isAutoIncrement())) {
                    continue;
                }
            }
            listFieldName.add(prop.getFieldName());
            listParameters.add(getParameterSymbol());
            listProp.add(prop);
            listField.add(prop.getField());
            listDbValueConverter.add(prop.getValueConverter());
        }
        String sqlHead = String.format("insert %s into %s (%s) values",
                (option == InsertOption.IgnoreOnDuplicate) ? "IGNORE" : "",
                ctx.getTableName(),
                getQuoteField(",", listFieldName)
        );
        sb.append(sqlHead);
        String sqlValues = String.format("(%s),", String.join(",", listParameters));
        for (int i = 0; i < list.size(); i++) {
            sb.append(sqlValues);
        }
        sb.deleteCharAt(sb.length() - 1);
        sb.append(builderString);
        sb.append(";");
        String sql = sb.toString();

        try (PreparedStatement pstat = conn.prepareStatement(sql)) {
            int indexParameter = 1;
            for (Object o : list) {
                for (int i = 0; i < listProp.size(); i++) {
                    pstat.setObject(indexParameter++, toDsValue(listDbValueConverter.get(i), listField.get(i).get(o)));
                }
            }
            if (logger.isDebugEnabled()) {
                logger.debug(pstat.toString());
            }
            pstat.executeUpdate();
            pstat.close();
        } catch (Exception ex) {
            logger.error(ex);
            if (list.size() <= 1) {
                return false;
            }
            batchInsert(list.subList(0, list.size() / 2), builder,conn);
            batchInsert(list.subList(list.size() / 2, list.size()), builder,conn);
        }
        return true;
    }


    protected boolean doDelete(Object me, Connection conn) throws NSException {
        EntityContext ctx = getContextParser().getObjectProperties(me);

        List<EntityProperty> propkeys = ctx.getKeyProperty();
        Assert.notNull(propkeys);

        StringBuilder sbWhere = new StringBuilder();

        try {
            for (EntityProperty propKey : propkeys) {
                Field fd = propKey.getField();
                if (fd.get(me) == null) {
                    throw new NSException(ctx.getType().getName() + " Key为空");
                }

                if (sbWhere.length() > 0) {
                    sbWhere.append(" and ");
                }
                sbWhere.append(String.format(" %s = %s ", getQuoteField(propKey.getFieldName()), getParameterSymbol()));
            }
        } catch (Exception ex) {
            throw new NSException(ex);
        }

        String sql = String.format("delete from %s where %s", ctx.getTableName(), sbWhere.toString());
        try (PreparedStatement pstat = conn.prepareStatement(sql)) {
            fillObject(pstat, 1, me, propkeys);

            if (logger.isDebugEnabled()) {
                logger.debug(pstat.toString());
            }

            pstat.executeUpdate();
            pstat.close();
        } catch (Exception sqlex) {
            throw new NSException(sqlex);
        }
        return true;
    }

    @Override
    public boolean delete(Object me) throws NSException {
        try (Connection conn = getConn()) {
            return doDelete(me, conn);
        } catch (Exception sqlex) {
            throw new NSException(sqlex);
        }
    }

    @Override
    public boolean delete(Object me,Connection conn) throws NSException {
        return doDelete(me, conn);
    }

    @Override
    public <Q extends EntityQuery> boolean delete(Q query, Class<?> entityClass) throws NSException {

        // 避免用户用错entityClass, 应该entityClass,而不是Query.class
        Assert.isTrue(!EntityQuery.class.isAssignableFrom(entityClass),
                "delete(query，entityClass)中要用entity的Class不能用query的Class");

        EntityContext ectx = getContextParser().getObjectProperties(entityClass);

        List<Tuple2<EntityProperty, QueryItem>> listProp = new ArrayList<>();
        String sbWhere = buildQuery(query, listProp);
        Assert.hasText(sbWhere);

        String sql = String.format("delete from %s where 1=1 %s", ectx.getTableName(), sbWhere);
        try (Connection conn = getConn();
             PreparedStatement pstat = conn.prepareStatement(sql)) {
            fillQuery(pstat, 1, listProp);

            if (logger.isDebugEnabled()) {
                logger.debug(pstat.toString());
            }

            pstat.executeUpdate();
            pstat.close();
        } catch (Exception sqlex) {
            throw new NSException(sqlex);
        }
        return true;
    }

    @Override
    public boolean update(Object me) throws NSException {
        EntityContext ctx = getContextParser().getObjectProperties(me);

        List<EntityProperty> propKeys = ctx.getKeyProperty();
        Assert.notEmpty(propKeys);

        List<EntityProperty> listProp = new ArrayList<>();
        StringBuilder sbSet = new StringBuilder();
        StringBuilder sbWhere = new StringBuilder();

        List<EntityProperty> keyWhere = new ArrayList<>();
        sbWhere.append(" 1=1 ");
        try {
            for (EntityProperty prop : ctx.getProperties().values()) {
                DbField dbFd = prop.getDbField();
                if ((dbFd != null) && !dbFd.isRequired()) {
                    continue;
                }
                if (prop.getIsKey()) {
                    Field fd = prop.getField();
                    if (fd.get(me) == null) {
                        throw new NSException(ctx.getType().getName() + " Key为空");
                    }
                    sbWhere.append(String.format(" AND %s = %s ", getQuoteField(prop.getFieldName()), getParameterSymbol()));
                    keyWhere.add(prop);
                } else {
                    sbSet.append(String.format(" %s = %s ,", getQuoteField(prop.getFieldName()), getParameterSymbol()));
                    listProp.add(prop);
                }
            }
        } catch (Exception ex) {
            throw new NSException(ex);
        }
        Assert.notEmpty(listProp);
        sbSet.deleteCharAt(sbSet.length() - 1);
        listProp.addAll(keyWhere);

        String sql = String.format("update %s set %s where %s",
                ctx.getTableName(),
                sbSet,
                sbWhere);


        try (Connection conn = getConn();
             PreparedStatement pstat = conn.prepareStatement(sql)) {

            fillObject(pstat, 1, me, listProp);

            if (logger.isDebugEnabled()) {
                logger.debug(pstat.toString());
            }

            pstat.executeUpdate();
            pstat.close();
        } catch (Exception sqlex) {
            throw new NSException(sqlex);
        }
        return true;
    }

    @Override
    public boolean update(Object me, UpdateBuilder builder,Connection conn) throws NSException {

        EntityContext ctx = getContextParser().getObjectProperties(me);

        List<EntityProperty> propKeys = ctx.getKeyProperty();
        Assert.notNull(propKeys);

        List<EntityProperty> listProp = new ArrayList<>();

        String sbSet = "";
        if (builder != null) {
            if (builder.hasInclude()) {
                sbSet = buildUpdateField(ctx, builder.getIncludes(), listProp);
            } else {
                sbSet = buildExUpdateField(ctx, builder.getExcludes(), listProp);
            }
        }

        StringBuilder sbWhere = new StringBuilder();
        try {
            for (EntityProperty propKey : propKeys) {
                Field fd = propKey.getField();
                if (fd.get(me) == null) {
                    throw new NSException(ctx.getType().getName() + " Key为空");
                }
                if (sbWhere.length() > 0) {
                    sbWhere.append(" and ");
                }
                sbWhere.append(String.format(" %s = %s ", getQuoteField(propKey.getFieldName()), getParameterSymbol()));
                listProp.add(propKey);
            }
        } catch (Exception ex) {
            throw new NSException(ex);
        }

        String sql = String.format("update %s set %s where %s",
                ctx.getTableName(),
                sbSet,
                sbWhere.toString());
        try (PreparedStatement pstat = conn.prepareStatement(sql)) {

            fillObject(pstat, 1, me, listProp);

            if (logger.isDebugEnabled()) {
                logger.debug(pstat.toString());
            }

            pstat.executeUpdate();
            pstat.close();
        } catch (Exception ex) {
            throw new NSException(ex);
        }
        return true;
    }

    @Override
    public <Q extends EntityQuery> boolean update(Object me, UpdateBuilder builder, Q query) throws NSException {

        EntityContext ctx = getContextParser().getObjectProperties(me);

        List<EntityProperty> listFieldProp = new ArrayList<>();
        String sbSet = "";

        if (builder != null) {
            if (builder.hasInclude()) {
                sbSet = buildUpdateField(ctx, builder.getIncludes(), listFieldProp);
            } else {
                sbSet = buildExUpdateField(ctx, builder.getExcludes(), listFieldProp);
            }
        }

        List<Tuple2<EntityProperty, QueryItem>> listWhereProp = new ArrayList<>();
        String sbWhere = buildQuery(query, listWhereProp);
        Assert.hasText(sbWhere);


        String sql = String.format("update %s set %s where 1=1 %s",
                ctx.getTableName(),
                sbSet,
                sbWhere);

        try (Connection conn = getConn();
             PreparedStatement pstat = conn.prepareStatement(sql)) {

            fillObject(pstat, 1, me, listFieldProp);
            fillQuery(pstat, listFieldProp.size() + 1, listWhereProp);

            if (logger.isDebugEnabled()) {
                logger.debug(pstat.toString());
            }

            pstat.executeUpdate();
            pstat.close();
        } catch (Exception ex) {
            throw new NSException(ex);
        }
        return true;
    }

    protected <E> E loadEntityData(E me, ResultSet rs, EntityContext ectx) throws NSException {
        try {
            Map<String, EntityProperty> map = ectx.getProperties();
            HashMap<EntityProperty, Boolean> level = new HashMap<>();//复合属性
            ResultSetMetaData metaData = rs.getMetaData();
            List<String> cols = new ArrayList<>();//所有的colname
            for (int i = 1; i <= metaData.getColumnCount(); i++) {
                String colname = metaData.getColumnLabel(i);
                cols.add(colname);
                EntityProperty prop = map.getOrDefault(colname, null);
                if (prop == null) {
                    if (colname.contains(".")) {
                        level.put(map.get(colname.substring(0, colname.indexOf('.'))), false);
                    }
                } else {
                    Field fd = prop.getField();
                    Object v = rs.getObject(colname);

                    if (v != null) {
                        fd.set(me, fromDsValue(prop.getValueConverter(), v));
                    }
                }
            }

            for (Map.Entry<EntityProperty, Boolean> entry : level.entrySet()) {
                EntityProperty k = entry.getKey();
                Field fd = k.getField();
                List<String> sub = cols.stream()
                        .filter(c -> c.contains(".") && k.getFieldName().equals(c.substring(0, c.indexOf('.'))))
                        .collect(Collectors.toList());
                Class<?> cls = k.getField().getType();
                fd.set(me, fd.getType().newInstance());
                loadSubEntityData(fd.get(me), rs, getContextParser().getObjectProperties(cls), sub);
            }
            return me;
        } catch (Exception ex) {
            throw new NSException(ex);
        }
    }

    private void loadSubEntityData(Object me, ResultSet rs, EntityContext objectProperties, List<String> sub) throws NSException {

        try {
            Map<String, EntityProperty> map = objectProperties.getProperties();
            for (String colname : sub) {
                EntityProperty prop = map.get(colname.replaceFirst("(\\S+)\\.", ""));
                Field fd = prop.getField();
                Object v = rs.getObject(colname);
                if (v == null) {
                    continue;
                }
                fd.set(me, fromDsValue(prop.getValueConverter(), v));
            }
        } catch (Exception ex) {
            throw new NSException(ex);
        }
    }

    public void execCall(Connection conn, String sql) throws NSException {
        try (CallableStatement cstat = conn.prepareCall(sql)) {
            cstat.execute();
        } catch (Exception ex) {
            throw new NSException(ex);
        }
    }

    public List<Map<String, Object>> exec(Connection conn, String sql, List<Object> params) throws NSException {

        try (PreparedStatement pstat = conn.prepareStatement(sql)) {
            List<Map<String, Object>> list = new ArrayList<>();

            if (params != null) {

                for (int i = 1; i <= params.size(); i++) {
                    Object value = params.get(i - 1);
                    if (value == null) {
                        pstat.setObject(i, "NULL");
                    } else if (value instanceof String) {
                        pstat.setObject(i, value);
                    } else if (value instanceof BigDecimal) {
                        ValueConverter vc = dbValueConverterFactory.getValueConverter(BigDecimal.class);
                        pstat.setObject(i, vc.toDsValue(value));
                    } else if (value instanceof Long) {
                        ValueConverter vc = dbValueConverterFactory.getValueConverter(Long.class);
                        pstat.setObject(i, vc.toDsValue(value));
                    } else if (value instanceof LocalDate) {
                        ValueConverter vc = dbValueConverterFactory.getValueConverter(LocalDate.class);
                        pstat.setObject(i, vc.toDsValue(value));
                    } else if (value instanceof LocalDateTime) {
                        ValueConverter vc = dbValueConverterFactory.getValueConverter(LocalDateTime.class);
                        pstat.setObject(i, vc.toDsValue(value));
                    } else {
                        throw new NSException(String.format("没有实现此类型 %s 的DbValueConverter", value.getClass().getName()));
                    }
                }
            }
            if (logger.isDebugEnabled()) {
                logger.debug(pstat.toString());
            }
            boolean ret = pstat.execute();
            if (ret) {
                try(ResultSet rs = pstat.getResultSet()) {
                    while (rs.next()) {
                        Map<String, Object> mp = new HashMap<>();
                        ResultSetMetaData metaData = rs.getMetaData();

                        for (int i = 1; i <= metaData.getColumnCount(); i++) {
                            String colname = metaData.getColumnName(i);
                            Object v = rs.getObject(i);
                            mp.put(colname, v);
                        }
                        list.add(mp);
                    }
                }
            }
            pstat.close();
            return list;
        } catch (Exception ex) {
            throw new NSException(ex);
        }
    }

    public List<Map<String, Object>> exec(String sql, List<Object> params) throws NSException {
        try (Connection conn = getConn()) {
            return exec(conn, sql, params);
        } catch (Exception ex) {
            throw new NSException(ex);
        }
    }

    public List<Map<String, Object>> exec(Connection conn, String sql) throws NSException {
        return exec(conn, sql, null);
    }

    @Override
    public List<Map<String, Object>> exec(String sql) throws NSException {
        return exec(sql, null);
    }

    @Override
    public InsertBuilder createInsertBuilder(EntityContext context) {
        return new DbInsertBuilder(this);
    }


    @Override
    @Deprecated
    public boolean insertKV(Map<String, Object> me, InsertBuilder builder) throws NSException {
        return false;
    }

    @Override
    public <E, Q extends EntityQuery, C extends EntityCollection<E,Q>> C load(EntityContext context, C me, String tableName, Connection conn) throws NSException {
        Assert.notNull(conn);

        me.clear();

        EntityContext ectx = (context != null) ? context : getContextParser().getObjectProperties(me.getEntityClass());

        Q query = me.getQuery();

        List<Tuple2<EntityProperty, QueryItem>> listProp = new ArrayList<>();
        String sbWhere = buildQuery(query, listProp);
        String sbCondition = buildConditions(query, listProp);

        StringBuilder sbOrderBy = new StringBuilder();
        if (query.orderBy != null) {
            sbOrderBy.append(String.format(" order by %s ", enumToSql(query.orderBy)));
        }

        StringBuilder sbLimit = new StringBuilder();
        if ((query.start != 0) || (query.count != Integer.MAX_VALUE)) {
            sbLimit.append(String.format(" limit %d,%d ", query.start, query.count));
        }

        StringBuilder sbGroupBy = new StringBuilder();
        if (query.groupBy != null) {
            sbGroupBy.append(String.format(" group by %s ", enumToSql(query.groupBy)));
        }

        String sql = String.format("select %s %s from %s t where 1=1 %s %s %s %s %s; %s",
                query.skipTotalCount ? "" : "SQL_CALC_FOUND_ROWS",
                convertSelectFields((query.selectFields == null) ? "*" : query.selectFields.toString(), ectx),
                StringUtils.hasText(tableName) ? tableName : ectx.getTableName(),
                sbWhere,
                sbCondition,
                sbGroupBy,
                sbOrderBy,
                sbLimit,
                query.skipTotalCount ? "" : "select FOUND_ROWS();");


        try (PreparedStatement pstat = conn.prepareStatement(sql)) {

            fillQuery(pstat, 1, listProp);

            if (logger.isDebugEnabled()) {
                logger.debug(pstat.toString());
            }
            boolean ret = pstat.execute();
            if (ret) {
                try(ResultSet rs = pstat.getResultSet()) {
                    while (rs.next()) {
                        me.add(loadEntityData(me.newEntity(), rs, ectx));
                    }
                }

                if (!query.skipTotalCount && pstat.getMoreResults()) {
                    try (ResultSet rs2 = pstat.getResultSet()){
                        if ((rs2 != null) && rs2.next()) {
                            query.totalCount = rs2.getLong(1);
                        }
                    }
                }
            }
            pstat.close();
            return me;
        } catch (Exception ex) {
            throw new NSException(ex);
        }
    }
}
