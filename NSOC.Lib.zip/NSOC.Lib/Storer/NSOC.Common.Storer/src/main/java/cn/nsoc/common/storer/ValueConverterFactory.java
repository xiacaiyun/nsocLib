package cn.nsoc.common.storer;

import cn.nsoc.base.entity.sys.NSException;
import org.springframework.util.Assert;

import java.math.BigDecimal;
import java.math.BigInteger;
import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.util.Date;
import java.util.HashMap;
import java.util.UUID;

/**
 * Created by sam on 16-6-22.
 */
public abstract class ValueConverterFactory {

    //DateTimeFormatter ISO_LOCAL_DATE
    protected static final String STDFORMAT_DATE = "yyyy-MM-dd";
    protected static final String STDFORMAT_DATETIME = "yyyy-MM-dd HH:mm:ss";
    //DateTimeFormatter ISO_LOCAL_DATE_TIME
    protected static final String FORMAT_DATETIME1 = "yyyy-MM-dd'T'HH:mm:ss";
    protected static final String FORMAT_DATETIME2 = "yyyy-MM-dd'T'HH:mm:ss.SSS";


    protected static final DateTimeFormatter DTFMT_STD = DateTimeFormatter.ofPattern(STDFORMAT_DATETIME);
    protected static final DateTimeFormatter DTFMT_ISOLOCAL = DateTimeFormatter.ofPattern(FORMAT_DATETIME1);
    protected static final DateTimeFormatter DTFMT_ISOLOCALZ = DateTimeFormatter.ofPattern(FORMAT_DATETIME2);



    protected HashMap<Class<?>, ValueConverter> converters = new HashMap<>();

    public ValueConverter getValueConverter(Class<?> cls) {

        ValueConverter converter;

        if (cls.isArray()) {
            converter = converters.getOrDefault(cls.getComponentType(), null);
        }
        else {
            converter = converters.getOrDefault(cls, null);
        }

        if (converter != null) {
            return converter;
        }

        if (cls.isEnum()) {
            converter = new EnumConverter(cls);
            converters.putIfAbsent(cls, converter);
        }
        return converter;
    }

    public class DateConverter implements ValueConverter {
        @Override
        public Object toDsValue(Object me) {
            return (me == null) ? null : new SimpleDateFormat(STDFORMAT_DATE).format((Date) me);
        }

        @Override
        public Object fromDsValue(Object me) throws NSException {
            try {
                return (me == null) ? null : (new SimpleDateFormat(STDFORMAT_DATE)).parse(me.toString());
            } catch (Exception ex) {
                throw new NSException(ex);
            }

        }
    }

    public class LongConverter implements ValueConverter {

        private boolean enableString;

        public LongConverter() {

        }

        public LongConverter(boolean enableString) {
            this.enableString = enableString;
        }


        @Override
        public Object toDsValue(Object me) {
            return me;
        }

        @Override
        public Object fromDsValue(Object me) {
            if (me == null) {
                return null;
            }

            if (me instanceof Integer) {
                Integer temp = (Integer) me;
                return temp.longValue();
            }

            if (me instanceof BigInteger) {
                BigInteger temp = (BigInteger) me;
                return temp.longValue();
            }

            if (me instanceof BigDecimal){
                BigDecimal temp = (BigDecimal)me;
                return temp.longValue();
            }

            if (me instanceof String) {
                if (enableString) {
                    return Long.parseLong((String) me);
                }
            }
            return me;
        }
    }

    public class DoubleConverter implements ValueConverter {

        @Override
        public Object toDsValue(Object me) {
            return me;
        }

        @Override
        public Object fromDsValue(Object me) throws NSException {
            if (me == null) {
                return null;
            }
            else if (me instanceof BigDecimal) {
                BigDecimal tmp = (BigDecimal) me;
                return tmp.doubleValue();
            }
            return null;
        }
    }

    public class BigIntConverter implements ValueConverter {
        @Override
        public Object toDsValue(Object me) {
            if (me instanceof BigInteger) {
                return ((BigInteger) me).toByteArray();
            }
            return me;
        }

        @Override
        public Object fromDsValue(Object me) {
            if (me == null) {
                return null;
            }
            else if (me instanceof BigInteger) {
                return me;
            } else if (me instanceof byte[]) {
                return new BigInteger(1, (byte[]) me);
            } else if (me instanceof Long) {
                return BigInteger.valueOf((Long) me);
            } else {
                return me;
            }
        }
    }

    public class IntConverter implements ValueConverter {
        @Override
        public Object toDsValue(Object me) {
            return me;
        }

        @Override
        public Object fromDsValue(Object me) {
            if (me == null) {
                return null;
            }
            else if (me instanceof BigInteger) {
                BigInteger temp = (BigInteger) me;
                return temp.intValue();
            } else if (me instanceof BigDecimal) {
                BigDecimal temp = (BigDecimal) me;
                return temp.intValue();
            } else if (me instanceof Long) {
                return ((Long) me).intValue();
            } else {
                return me;
            }
        }
    }

    public class UUIDConverter implements ValueConverter {
        @Override
        public Object toDsValue(Object me) {
            return (me == null) ? null : me.toString();
        }

        @Override
        public Object fromDsValue(Object me) {
            String temp = (String) me;
            return (temp == null) ? null : UUID.fromString(temp);
        }
    }

    public class BoolConverter implements ValueConverter {

        @Override
        public Object toDsValue(Object me) {
            if (me == null) {
                return null;
            }
            else {
                return (boolean) me ? 1 : 0;
            }
        }

        @Override
        public Object fromDsValue(Object me) throws NSException {
            if (me == null)
                return null;
            else if (me instanceof Integer) {
                return ((Integer) me != 0);
            } else if (me instanceof Boolean) {
                return me;
            }
            throw new NSException(String.format("BoolConverter cant convert %s", me.getClass().toString()));
        }
    }

    public class LocalDateConverter implements ValueConverter {
        @Override
        public Object toDsValue(Object me) {
            return (me == null) ? null : me.toString();
        }

        @Override
        public Object fromDsValue(Object me) throws NSException {
            return (me == null) ? null : ((java.sql.Date) me).toLocalDate();
        }
    }

    public class LocalDateTimeConverter implements ValueConverter {

        private DateTimeFormatter outputformatter;

        public LocalDateTimeConverter(){
            this(DTFMT_STD);
        }

        public LocalDateTimeConverter(DateTimeFormatter outputformatter){
            Assert.notNull(outputformatter);
            this.outputformatter = outputformatter;
        }

        @Override
        public Object toDsValue(Object me) {
            return (me == null) ? null : ((LocalDateTime) me).format(outputformatter);
        }

        @Override
        public Object fromDsValue(Object me) throws NSException {
            if (me == null) {
                return null;
            } else {
                if (me instanceof Timestamp){
                    return LocalDateTime.ofInstant(((Timestamp) me).toInstant(), ZoneId.of("UTC"));
                }
                else if (me instanceof java.sql.Date){
                    return ((java.sql.Date) me).toLocalDate().atStartOfDay();
                }
                else {
                    String dt = me.toString();
                    if (dt.length() == 23) {
                        return LocalDateTime.parse(dt, DTFMT_ISOLOCALZ);
                    } else {
                        return LocalDateTime.parse(dt, DTFMT_ISOLOCAL);
                    }
                }
            }
        }
    }

    public class EnumConverter implements ValueConverter {

        private Class<? extends Enum> enumCls;


        public EnumConverter(Class<?> enumCls) {
            this.enumCls = enumCls.asSubclass(Enum.class);
        }


        @Override
        public Object toDsValue(Object me) {
            return (me == null) ? null : ((Enum) me).name();
        }

        @SuppressWarnings("unchecked")
        @Override
        public Object fromDsValue(Object me) throws NSException {
            return (me == null) ? null : Enum.valueOf(enumCls, (String) me);
        }
    }

    public class StringConverter implements ValueConverter{

        @Override
        public Object toDsValue(Object me) {
            return me;
        }

        @Override
        public Object fromDsValue(Object me) throws NSException {
            if (me == null) {
                return null;
            }
            else {
                return me.toString();
            }
        }
    }

}
