package cn.nsoc.common.storer.annotation.graph;


public enum RelationDirection {
    own,
    belongto,
    none,
    both
}
