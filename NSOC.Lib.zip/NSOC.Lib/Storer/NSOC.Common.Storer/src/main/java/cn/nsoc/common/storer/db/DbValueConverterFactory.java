package cn.nsoc.common.storer.db;

import cn.nsoc.common.storer.ValueConverter;
import cn.nsoc.common.storer.ValueConverterFactory;

import java.math.BigInteger;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.Date;
import java.util.UUID;

/**
 * Created by sam on 16-6-22.
 */

public class DbValueConverterFactory extends ValueConverterFactory {

    public DbValueConverterFactory() {
        converters.put(UUID.class, new UUIDConverter());

        converters.put(Date.class, new DateConverter());
        converters.put(LocalDateTime.class, new LocalDateTimeConverter());
        converters.put(LocalDate.class, new LocalDateConverter());

        ValueConverter temp = new IntConverter();
        converters.put(int.class, temp);
        converters.put(Integer.class, temp);

        temp = new LongConverter();
        converters.put(long.class, temp);
        converters.put(Long.class, temp);

        temp = new DoubleConverter();
        converters.put(double.class, temp);
        converters.put(Double.class, temp);

        temp = new BigIntConverter();
        converters.put(BigInteger.class, temp);

        converters.put(boolean.class, new BoolConverter());
        converters.put(Boolean.class, new BoolConverter());
    }
}
