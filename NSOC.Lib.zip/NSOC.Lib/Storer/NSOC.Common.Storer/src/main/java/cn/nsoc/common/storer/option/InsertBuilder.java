package cn.nsoc.common.storer.option;

import cn.nsoc.common.storer.context.EntityContext;

/**
 * Created by sam on 16-7-19.
 */
public interface InsertBuilder<T extends EntityContext> {

    default InsertOption getInsertOption() {
        return  null;
    }

    default void setInsertOption(InsertOption option){}

    InsertBuilder append(String field, UpdateOperator operator);

    T getContext();
}
