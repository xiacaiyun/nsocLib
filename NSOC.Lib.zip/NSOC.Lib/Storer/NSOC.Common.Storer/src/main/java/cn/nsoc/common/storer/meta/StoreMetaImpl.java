package cn.nsoc.common.storer.meta;

import cn.nsoc.base.entity.sys.NSException;
import cn.nsoc.common.storer.IStoreMeta;
import cn.nsoc.common.storer.db.DbStorer;
import cn.nsoc.common.storer.entity.MetaDesc;
import cn.nsoc.common.storer.entity.StorerTypeEnum;
import org.springframework.util.StringUtils;

import java.util.List;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Created by bobwang on 10/24/16.
 */
public class StoreMetaImpl implements IStoreMeta {


    @Override
    public MetaDesc getEntityDesc(DbStorer storer, String name, String schema_url) throws NSException {
        MetaDesc result = new MetaDesc();

        String schema = "";
        Matcher matcher = Pattern.compile(".*/(.*)\\?.*").matcher(schema_url);
        if (matcher.matches()) {
            schema = matcher.group(1);
        }

        String execScript = genQueryText(storer.getStorerType(), name, schema);
        List<Map<String, Object>> metaList = storer.exec(execScript);

        for (Map<String, Object> iter : metaList) {
            boolean bIsKey = false;
            boolean increment = false;
            String fd_ID = iter.get("COLUMN_NAME").toString();
            String fd_Type = iter.get("DATA_TYPE").toString();
            String fd_Key_Prop = iter.get("COLUMN_KEY").toString();
            if (fd_Key_Prop.compareToIgnoreCase("PRI") == 0) {
                bIsKey = true;
            }
            String fd_Extra = iter.get("EXTRA").toString();
            if (fd_Extra.compareToIgnoreCase("auto_increment") == 0) {
                increment = true;
            }
            String maxSize = "";
            Object objMaxSize = iter.get("CHARACTER_MAXIMUM_LENGTH");
            if (objMaxSize != null) {
                maxSize = objMaxSize.toString();
            }
            result.addDesc(fd_ID, fd_Type, maxSize, bIsKey, increment);
        }
        return result;
    }

    String genQueryText(StorerTypeEnum storerType, String name, String schema) throws NSException {
        if (storerType == StorerTypeEnum.mysql) {
            String select = "SELECT COLUMN_NAME,DATA_TYPE,COLUMN_KEY,CHARACTER_MAXIMUM_LENGTH,EXTRA";
            String from = String.format("FROM INFORMATION_SCHEMA.COLUMNS where TABLE_NAME = \'%s\' ", name);
            if (StringUtils.hasText(schema)) {
                from = String.format("%s %s \'%s\'", from, " AND TABLE_SCHEMA = ", schema);
            }
            String sort = "order by TABLE_NAME,ORDINAL_POSITION;";
            return String.format("%s %s %s", select, from, sort);
        }
        throw new NSException(String.format("type %s is not supported", storerType.name()));

    }
}
