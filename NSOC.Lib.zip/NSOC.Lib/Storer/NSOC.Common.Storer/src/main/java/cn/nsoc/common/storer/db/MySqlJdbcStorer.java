package cn.nsoc.common.storer.db;

import cn.nsoc.common.storer.entity.StorerTypeEnum;
import org.springframework.util.StringUtils;

import javax.sql.DataSource;

/**
 * Created by sam on 16-9-20.
 */
public class MySqlJdbcStorer extends JdbcDbStorer {

    public MySqlJdbcStorer(DataSource ds) {
        super(ds, StorerTypeEnum.mysql);
        setKeywordQuoter("`", "`");
    }


    @Override
    public String escapeValue(String val) {
        if (StringUtils.hasText(val)) {
            return val.replace("\\", "\\\\").replace("_", "\\_").replace("%", "\\%");
        } else
            return val;
    }
}
