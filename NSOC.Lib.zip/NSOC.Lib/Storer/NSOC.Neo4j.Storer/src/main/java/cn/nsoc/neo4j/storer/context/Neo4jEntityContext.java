package cn.nsoc.neo4j.storer.context;

import cn.nsoc.common.storer.annotation.graph.Neo4jType;
import cn.nsoc.common.storer.context.EntityContext;

public class Neo4jEntityContext extends EntityContext {

    private String label;

    private Neo4jType objType = Neo4jType.Node;

    private Neo4jEntityProperty propFrom;

    private Neo4jEntityProperty propTo;

    public String getLabel() {
        return label;
    }

    public void setLabel(String label) {
        this.label = label;
    }

    public Neo4jType getObjType() {
        return objType;
    }

    public void setObjType(Neo4jType objType) {
        this.objType = objType;
    }

    public Neo4jEntityProperty getPropFrom() {
        return propFrom;
    }

    public void setPropFrom(Neo4jEntityProperty propFrom) {
        this.propFrom = propFrom;
    }

    public Neo4jEntityProperty getPropTo() {
        return propTo;
    }

    public void setPropTo(Neo4jEntityProperty propTo) {
        this.propTo = propTo;
    }
}
