package cn.nsoc.neo4j.storer.context;

import cn.nsoc.common.storer.annotation.graph.Neo4jRelationField;
import cn.nsoc.common.storer.context.EntityProperty;

public class Neo4jEntityProperty extends EntityProperty {

    private Neo4jRelationField relationField;

    public Neo4jRelationField getRelationField() {
        return relationField;
    }

    public void setRelationField(Neo4jRelationField relationField) {
        this.relationField = relationField;
    }
}
