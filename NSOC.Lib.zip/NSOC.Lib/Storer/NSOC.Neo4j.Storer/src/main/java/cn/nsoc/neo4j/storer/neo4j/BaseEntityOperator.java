package cn.nsoc.neo4j.storer.neo4j;

import cn.nsoc.base.entity.sys.NSException;
import cn.nsoc.base.entity.tuple.Tuple2;
import cn.nsoc.base.entity.tuple.Tuple4;
import cn.nsoc.common.storer.EntityCollection;
import cn.nsoc.common.storer.EntityQuery;
import cn.nsoc.common.storer.annotation.DbField;
import cn.nsoc.common.storer.annotation.DbQuery;
import cn.nsoc.common.storer.annotation.QueryOperator;
import cn.nsoc.common.storer.annotation.graph.Neo4jRelationField;
import cn.nsoc.common.storer.annotation.graph.RelationDirection;
import cn.nsoc.common.storer.context.EntityContext;
import cn.nsoc.common.storer.context.EntityProperty;
import cn.nsoc.common.storer.option.InsertBuilder;
import cn.nsoc.common.storer.option.QueryItem;
import cn.nsoc.neo4j.storer.context.Neo4jEntityContext;
import cn.nsoc.neo4j.storer.context.Neo4jEntityProperty;
import org.apache.log4j.Logger;
import org.neo4j.driver.v1.StatementRunner;
import org.neo4j.driver.v1.types.Entity;
import org.springframework.util.Assert;
import org.springframework.util.StringUtils;

import java.lang.reflect.Field;
import java.util.*;
import java.util.stream.Collectors;

abstract class BaseEntityOperator {
    protected static final Logger logger = Logger.getLogger("Neo4jStorer");
    protected static final String GETID_SYMBOL = "id(%s)";
    protected static final String PARAM_SYMBOL = "$";
    protected static final String PATH_SYMBOL = "p";
    protected static final String KEY_PROP = "prop";
    protected static final String KEY_LIST = "list";
    protected static final String FMT_PARAM = PARAM_SYMBOL + KEY_PROP +".%s";
    protected static final String ROW_SYMBOL = "row";
    protected static final String FMT_PARAMROW = ROW_SYMBOL + ".%s";
    protected Neo4jStorer neo4jStorer;
    private String entitySymbol;

    class QueryCondition{
        Tuple4<String, String, String, Map<String, Object>> from;
        Tuple4<String, String, String, Map<String, Object>> to;
        RelationDirection direction = RelationDirection.both;
        Integer maxdepth;
        Integer mindepth;
    }


    BaseEntityOperator(Neo4jStorer neo4jStorer,String entitySymbol){
        Assert.notNull(neo4jStorer);
        this.entitySymbol = entitySymbol;
        this.neo4jStorer = neo4jStorer;
    }

    public abstract boolean insert(StatementRunner session, Object me, Neo4jEntityContext ectx) throws NSException;

    public abstract <E, Q extends EntityQuery, C extends EntityCollection<E, Q>> C load(Neo4jEntityContext ectx, C me, StatementRunner conn) throws NSException;

    public abstract boolean update(Object me, Neo4jEntityContext eCtx, StatementRunner conn) throws NSException;

    public Map<String, Object> buildProperties(Object me, Neo4jEntityContext ectx, StringBuilder sbStatement, String paramformat) throws NSException {
        try {
            List<String> clauses = new ArrayList<>();

            Map<String, Object> vals = new HashMap<>();
            for (EntityProperty prop : ectx.getProperties().values()) {
                Neo4jEntityProperty nprop = (Neo4jEntityProperty)prop;
                DbField dbField = prop.getDbField();
                if (dbField != null) {
                    if (!dbField.isRequired() || (dbField.isKey() && dbField.isAutoIncrement())) {
                        continue;
                    }
                }
                Neo4jRelationField rlfield = nprop.getRelationField();
                if (rlfield != null){
                    continue;
                }

                String fieldName = prop.getFieldName();
                vals.put(fieldName, neo4jStorer.toDsValue(prop.getValueConverter(), prop.getField().get(me)));
                if (sbStatement != null) {
                    clauses.add(String.format("%s:%s", fieldName, String.format(paramformat, fieldName)));
                }
            }

            if (sbStatement != null) {
                sbStatement.append("{}").insert(1, String.join(",", clauses));
            }
            return vals;
        } catch (Exception ex) {
            throw new NSException(ex);
        }
    }

    protected Map<String,Object> buildEntityWhereCondition(Object me, Neo4jEntityContext ectx, StringBuilder sbWhere, String symbol) throws NSException{
        try {
            List<String> clauses = new ArrayList<>();
            Map<String, Object> vals = new HashMap<>();
            for (EntityProperty prop : ectx.getProperties().values()) {
                Neo4jEntityProperty nprop = (Neo4jEntityProperty)prop;
                DbField dbField = prop.getDbField();
                boolean isAuto = false;
                if (dbField != null) {
                    isAuto = dbField.isKey() && dbField.isAutoIncrement();
                    if (!dbField.isRequired()){
                        continue;
                    }
                }
                Neo4jRelationField rlfield = nprop.getRelationField();
                if (rlfield != null){
                    continue;
                }
                Field fd = nprop.getField();
                Object v = fd.get(me);
                if (v == null){
                    continue;
                }

                DbQuery dbQuery = prop.getDbQuery();
                String fieldName = prop.getFieldName();


                String queryitem = neo4jStorer.getQueryOperator(prop.getFieldName(), QueryOperator.Equal,
                        neo4jStorer.getParameterSymbol(), v, dbQuery, isAuto,symbol);
                if (StringUtils.hasText(queryitem)) {
                    sbWhere.append(String.format(" and %s ", queryitem));
                    vals.put(fieldName, neo4jStorer.toDsValue(prop.getValueConverter(), prop.getField().get(me)));
                }
            }
            return vals;
        } catch (Exception ex) {
            throw new NSException(ex);
        }
    }

    public String getEntitySymbol() {
        return entitySymbol;
    }

    protected <E> E loadEntityData(E me, Entity entity, Neo4jEntityContext ectx) throws NSException {
        try {
            setAutoId(me,ectx,entity.id());

            Map<String, EntityProperty> map = ectx.getProperties();
            for (Map.Entry<String, Object> entry : entity.asMap().entrySet()) {

                EntityProperty prop = map.getOrDefault(entry.getKey(), null);
                if (prop != null) {
                    Field fd = prop.getField();
                    Object v = entry.getValue();

                    if (v != null) {
                        fd.set(me, neo4jStorer.fromDsValue(prop.getValueConverter(), v));
                    }
                }
            }
            return me;
        } catch (Exception ex) {
            throw new NSException(ex);
        }
    }

    protected <Q extends EntityQuery> String buildConditions(Q query, List<Tuple2<EntityProperty, QueryItem>> listProp) throws NSException {
        return "";
    }

    protected <Q extends EntityQuery> String buildQuery(Q query, List<Tuple2<EntityProperty, QueryItem>> listProp,Neo4jEntityContext entityContext,String symbol) throws NSException {
        EntityContext qctx = neo4jStorer.getContextParser().getObjectProperties(query.getClass());
        StringBuilder sbWhere = new StringBuilder();

        try {

            Map<String,EntityProperty> entityKeyPropMap = entityContext.getKeyProperty().stream().collect(Collectors.toMap(p->p.getFieldName(), p->p));
            for (EntityProperty prop : qctx.getProperties().values()) {
                Neo4jEntityProperty nprop = (Neo4jEntityProperty)prop;
                Field fd = prop.getField();
                DbQuery dbQuery = prop.getDbQuery();

                QueryOperator operator = (dbQuery == null) ? QueryOperator.Equal : dbQuery.Operator();

                Object v = fd.get(query);
                if (v == null) {
                    continue;
                }

                Neo4jRelationField rlfield = nprop.getRelationField();
                if (rlfield != null){
                    continue;
                }

                EntityProperty entityKeyProp = entityKeyPropMap.getOrDefault(fd.getName(),null);
                boolean isAuto = (entityKeyProp == null) ? false : (entityKeyProp.getIsKey() && entityKeyProp.getAutoIncrement());

                String queryitem = neo4jStorer.getQueryOperator(prop.getFieldName(), operator, neo4jStorer.getParameterSymbol(), v, dbQuery, isAuto,symbol);
                if (StringUtils.hasText(queryitem)) {
                    sbWhere.append(String.format(" and %s ", queryitem));
                    listProp.add(new Tuple2<>(prop, new QueryItem(prop.getFieldName(), operator, v)));
                }
            }
            return sbWhere.toString();
        } catch (Exception ex) {
            throw new NSException(ex);
        }
    }

    public abstract boolean delete(Object me, Neo4jEntityContext eCtx, StatementRunner conn) throws NSException;

    public abstract <Q extends EntityQuery>  boolean delete(Q query, Neo4jEntityContext qCtx, Neo4jEntityContext eCtx, StatementRunner conn) throws NSException;

    public abstract boolean batchInsert(List<Object> list, InsertBuilder builder, Neo4jEntityContext eCtx, StatementRunner conn) throws NSException;

    protected String escapeLabel(String label) throws NSException{
        if (StringUtils.isEmpty(label)){
            return label;
        }
        return String.format("`%s`", label);
    }

    protected void setAutoId(Object me, Neo4jEntityContext eCtx, long id) throws NSException,IllegalAccessException{
        for (EntityProperty keyprop : eCtx.getKeyProperty()) {
            if (keyprop.getAutoIncrement()) {
                keyprop.getField().set(me, neo4jStorer.fromDsValue(keyprop.getValueConverter(), id));
            }
        }
    }

    /**
     * (a:Person),
     * a.name = 'Node A'
     */
    protected Tuple4<String, String, String, Map<String, Object>> buildRelationCondition(Neo4jEntityProperty nprop, Object me) throws NSException {
        try {
            Field fd = nprop.getField();
            Class<?> type = fd.getType();
            Object v = fd.get(me);
            if (v == null) {
                return null;
            }
            if (v instanceof Integer || v instanceof Long) {
                Map<String, Object> params = new HashMap<>();
                String fdname = nprop.getFieldName();
                String symbol = fdname + "1";
                String match = String.format("(%s)", symbol);
                String where = String.format("(id(%s)=$%s.%s)", symbol, symbol, fdname);

                params.put(fdname, v);
                return new Tuple4(symbol, match, where, params);
            }

            throw new NSException(String.format("%s 's type %s is not supported ", fd.getName(), type));
        } catch (Exception ex) {
            throw new NSException(ex);
        }
    }

    protected <Q extends EntityQuery> QueryCondition parseQueryCondition(Q query,Neo4jEntityContext ctx) throws NSException {
        try {
            QueryCondition qc = new QueryCondition();

            for (EntityProperty prop : ctx.getProperties().values()) {
                Neo4jEntityProperty nprop = (Neo4jEntityProperty) prop;
                Neo4jRelationField rlfield = nprop.getRelationField();
                if (rlfield != null) {
                    switch (rlfield.type()) {
                        case from:
                            qc.from = buildRelationCondition(nprop, query);
                            break;
                        case to:
                            qc.to = buildRelationCondition(nprop, query);
                            break;
                        case direction: {
                            Object v = nprop.getField().get(query);
                            Optional<RelationDirection> opDirection = Optional.ofNullable((RelationDirection) v);
                            opDirection.ifPresent(p->qc.direction = p);
                            break;
                        }
                        case maxdepth: {
                            Object v = nprop.getField().get(query);
                            Optional<Integer> opDirection = Optional.ofNullable((Integer) v);
                            opDirection.ifPresent(p -> qc.maxdepth = p);
                            break;
                        }
                        case mindepth: {
                            Object v = nprop.getField().get(query);
                            Optional<Integer> opDirection = Optional.ofNullable((Integer) v);
                            opDirection.ifPresent(p -> qc.mindepth = p);
                            break;
                        }
                        default:
                            break;
                    }
                }
            }
            return qc;
        }
        catch (Exception ex){
            throw new NSException(ex);
        }
    }

}
