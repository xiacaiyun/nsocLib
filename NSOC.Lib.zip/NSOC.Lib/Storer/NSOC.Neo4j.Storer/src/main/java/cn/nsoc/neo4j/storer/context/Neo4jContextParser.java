package cn.nsoc.neo4j.storer.context;

import cn.nsoc.base.entity.sys.NSException;
import cn.nsoc.common.storer.ValueConverterFactory;
import cn.nsoc.common.storer.annotation.graph.Neo4jObject;
import cn.nsoc.common.storer.annotation.graph.Neo4jRelationField;
import cn.nsoc.common.storer.context.ContextParser;
import cn.nsoc.common.storer.context.EntityContext;
import cn.nsoc.common.storer.context.EntityProperty;
import org.springframework.util.StringUtils;

import java.lang.reflect.Field;


public class Neo4jContextParser  extends ContextParser {

    public Neo4jContextParser(ValueConverterFactory vcfactory){
        super(vcfactory,"");
    }

    @Override
    protected EntityContext parseContext(Class<?> cls) throws NSException {

        Neo4jEntityContext ctx = (Neo4jEntityContext)super.parseContext(cls);

        Neo4jObject node = cls.getAnnotation(Neo4jObject.class);
        String label = cls.getSimpleName();
        if (node != null) {
            ctx.setObjType(node.type());
            if (StringUtils.hasLength(node.name())) {
                label = node.name();
            }
        }
        ctx.setLabel(label);
        return ctx;
    }

    @Override
    protected EntityProperty parseField(EntityContext ctx, Field f) throws NSException {

        Neo4jEntityContext eCtx = (Neo4jEntityContext)ctx;

        Neo4jEntityProperty prop =  (Neo4jEntityProperty)super.parseField(ctx, f);
        if (prop != null){
            Neo4jRelationField fd = f.getAnnotation(Neo4jRelationField.class);
            if (fd != null) {
                prop.setRelationField(fd);

                switch (fd.type()){
                    case from:
                        eCtx.setPropFrom(prop);
                        break;
                    case to:
                        eCtx.setPropTo(prop);
                        break;
                    default:
                        break;
                }
            }
        }
        return prop;
    }


    @Override
    public Neo4jEntityContext createEntityContext() {
        return new Neo4jEntityContext();
    }

    @Override
    protected EntityProperty createEntityProperty() {
        return new Neo4jEntityProperty();
    }
}
