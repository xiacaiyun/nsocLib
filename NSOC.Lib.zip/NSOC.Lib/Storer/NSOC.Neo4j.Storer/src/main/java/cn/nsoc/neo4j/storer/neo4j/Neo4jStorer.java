package cn.nsoc.neo4j.storer.neo4j;

import cn.nsoc.base.entity.sys.NSException;
import cn.nsoc.common.storer.EntityCollection;
import cn.nsoc.common.storer.EntityQuery;
import cn.nsoc.common.storer.Storer;
import cn.nsoc.common.storer.ValueConverter;
import cn.nsoc.common.storer.annotation.DbQuery;
import cn.nsoc.common.storer.annotation.QueryOperator;
import cn.nsoc.common.storer.annotation.graph.Neo4jType;
import cn.nsoc.common.storer.context.EntityContext;
import cn.nsoc.common.storer.option.InsertBuilder;
import cn.nsoc.common.storer.option.UpdateBuilder;
import cn.nsoc.neo4j.storer.context.Neo4jConfig;
import cn.nsoc.neo4j.storer.context.Neo4jContextParser;
import cn.nsoc.neo4j.storer.context.Neo4jEntityContext;
import cn.nsoc.neo4j.storer.context.Neo4jValueConverterFactory;
import org.apache.log4j.Logger;
import org.neo4j.driver.v1.*;
import org.springframework.util.Assert;
import org.springframework.util.StringUtils;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.function.Function;

public class Neo4jStorer implements Storer {

    private static final Logger logger = Logger.getLogger("Neo4jStorer");
    protected static final String GETID_SYMBOL = "id(%s)";
    protected static final String PARAM_SYMBOL = "$";


    private final Map<Neo4jType, BaseEntityOperator> entityOperatorMap;

    private static Neo4jStorer defaultInstance;
    private Driver neo4jdriver;
    private Neo4jContextParser contextParser;
    private Neo4jValueConverterFactory valueConverterFactory = new Neo4jValueConverterFactory();

    public Neo4jStorer(Neo4jConfig config) throws NSException {
        entityOperatorMap = new HashMap<>();
        entityOperatorMap.put(Neo4jType.Node, new NodeOperator(this));
        entityOperatorMap.put(Neo4jType.Relation, new RelationOperator(this));

        setContextParser(new Neo4jContextParser(valueConverterFactory));
        initialize(config);
    }

    public static Neo4jStorer getInstance() {
        Assert.notNull(defaultInstance);
        return defaultInstance;
    }

    public static void setDefaultHandler(Neo4jStorer handler) {
        defaultInstance = handler;
    }

    public void initialize(Neo4jConfig config) throws NSException {
        if (!StringUtils.hasText(config.getUrl()) || !StringUtils.hasText(config.getUsername())) {
            throw new NSException(String.format("failed to initialize neo4j, url:%s, username:%d", config.getUrl(), config.getUsername()));
        }

        if (neo4jdriver == null) {
            neo4jdriver = GraphDatabase.driver(config.getUrl(), AuthTokens.basic(config.getUsername(), config.getPassword()));
        }
    }

    @Override
    public Neo4jContextParser getContextParser() {
        return contextParser;
    }

    protected void setContextParser(Neo4jContextParser contextParser) {
        this.contextParser = contextParser;
    }

    @Override
    public void shutdown() {
        if (neo4jdriver != null) {
            neo4jdriver.close();
            neo4jdriver = null;
        }
    }

    protected Session getConn() {
        return neo4jdriver.session();
    }

    protected BaseEntityOperator getOperator(Neo4jType type) {
        BaseEntityOperator operator = entityOperatorMap.get(type);
        Assert.notNull(operator);
        return operator;
    }

    @Override
    public boolean insert(Object me) throws NSException {
        Neo4jEntityContext ectx = (Neo4jEntityContext) getContextParser().getObjectProperties(me);

        try (Session session = getConn()) {
            return getOperator(ectx.getObjType()).insert(session, me, ectx);
        }
    }

    @Override
    public boolean insert(Object me, InsertBuilder builder) throws NSException {
        return insert(me, null);
    }

    @Override
    public boolean batchInsert(List<Object> list) throws NSException {

        if (list == null || list.isEmpty()) {
            return true;
        }

        Function<StatementRunner, Exception> action = conn -> {
            try {
                batchInsert(list, null, conn);
                return null;
            } catch (NSException sqlEx) {
                logger.error(sqlEx);
                return sqlEx;
            }
        };
        try {
            this.startTransaction(action);
            return true;
        } catch (Exception ex) {
            logger.error(ex);
            return false;
        }
    }

    @Override
    public boolean batchInsert(List<Object> melist, InsertBuilder builder) throws NSException {
        return batchInsert(melist, null);
    }

    @Override
    public boolean delete(Object me) throws NSException {

        Neo4jEntityContext eCtx = (Neo4jEntityContext) getContextParser().getObjectProperties(me);

        try(Session session = getConn()){
            return getOperator(eCtx.getObjType()).delete(me,eCtx,session);
        }
    }

    @Override
    public <Q extends EntityQuery> boolean delete(Q query, Class<?> eClass) throws NSException {
        Neo4jEntityContext eCtx = (Neo4jEntityContext) getContextParser().getObjectProperties(eClass);
        Neo4jEntityContext qCtx = (Neo4jEntityContext) getContextParser().getObjectProperties(query);

        try(Session session = getConn()){
            return getOperator(eCtx.getObjType()).delete(query,qCtx,eCtx,session);
        }
    }

    @Override
    public boolean update(Object me) throws NSException {

        Neo4jEntityContext eCtx = (Neo4jEntityContext) getContextParser().getObjectProperties(me);

        Assert.notEmpty(eCtx.getKeyProperty());

        try (Session session = getConn()) {

            return getOperator(eCtx.getObjType()).update(me, eCtx, session);
        }
    }

    @Override
    public boolean update(Object me, UpdateBuilder builder) throws NSException {
        return false;
    }

    @Override
    public <Q extends EntityQuery> boolean update(Object me, UpdateBuilder builder, Q query) throws NSException {
        return false;
    }

    @Override
    public <E, Q extends EntityQuery, C extends EntityCollection<E, Q>> C load(C me) throws NSException {
        try (Session session = getConn()) {
            return load(null, me, session);
        }
    }

    public <E, Q extends EntityQuery, C extends EntityCollection<E, Q>> C load(EntityContext context, C me, StatementRunner conn) throws NSException {
        Assert.notNull(conn);

        me.clear();

        Neo4jEntityContext ectx = (Neo4jEntityContext) ((context != null) ? context : getContextParser().getObjectProperties(me.getEntityClass()));

        return getOperator(ectx.getObjType()).load(ectx, me, conn);
    }

    @Override
    public <E, Q extends EntityQuery, C extends EntityCollection<E, Q>> C load(C me, String tableName) throws NSException {
        return null;
    }

    @Override
    public <E, Q extends EntityQuery, C extends EntityCollection<E, Q>> C load(EntityContext context, C me) throws NSException {
        return null;
    }

    @Override
    public List<Map<String, Object>> exec(String cql) throws NSException {
        Assert.hasText(cql);
        try (Session session = getConn()) {
            StatementResult result = session.run(cql);
            return result.list(p->{
                Map<String,Object> map = new HashMap<>();
                map.putAll(p.asMap());
                return map;
            });
        }
    }

    @Override
    public InsertBuilder createInsertBuilder(EntityContext context) {
        return null;
    }

    @Override
    public boolean insertKV(Map<String, Object> me, InsertBuilder builder) throws NSException {
        throw new NSException("not implemented");
    }

    public boolean batchInsert(List<Object> list, InsertBuilder builder, StatementRunner conn) throws NSException {
        if (list == null || list.isEmpty()) {
            return true;
        }

        Object me = list.get(0);
        Neo4jEntityContext eCtx = (Neo4jEntityContext) getContextParser().getObjectProperties(me);

        if (eCtx.getObjType() == Neo4jType.Relation){
            throw new NSException("not implemented");
        }

        BaseEntityOperator operator = getOperator(eCtx.getObjType());
        try {
            operator.batchInsert(list, builder, eCtx, conn);
        }
        catch (Exception ex){
            logger.error(ex);
            if (list.size() <= 1) {
                return false;
            }
            batchInsert(list.subList(0, list.size() / 2), builder, conn);
            batchInsert(list.subList(list.size() / 2, list.size()), builder, conn);
        }
        return true;
    }

    public void startTransaction(Function<StatementRunner, Exception> action) throws NSException {

        try (Session session = getConn()) {
            Transaction trans = session.beginTransaction();
            try {
                Exception innerEx = action.apply(trans);
                if (innerEx != null) {
                    throw innerEx;
                } else {
                    trans.success();
                }
            } catch (Exception ex) {
                trans.failure();
                throw ex;
            }
        } catch (Exception ex) {
            throw new NSException(ex);
        }
    }

    protected Object toDsValue(ValueConverter converter, Object me) {
        return (converter == null) ? me : converter.toDsValue(me);
    }

    protected Object fromDsValue(ValueConverter converter, Object me) throws NSException {
        return (converter == null) ? me : converter.fromDsValue(me);
    }

    protected String getQueryOperator(String fieldname, QueryOperator queryOperator, String paramsymbol, Object v, DbQuery dbQuery, boolean isAutoKey, String symbol) throws NSException {
        if (v == null) {
            return null;
        }
        if (v instanceof String && StringUtils.isEmpty((String) v)) {
            return null;
        }

        String op = null;
        String fd = fieldname;
        switch (queryOperator) {
            case Equal:
                op = "%s=%s";
                break;
            case GreatEqual:
                op = "%s>=%s";
                fd = getContextParser().trimQueryFlag(queryOperator, fieldname);
                break;
            case GreatThan:
                op = "%s>%s";
                fd = getContextParser().trimQueryFlag(queryOperator, fieldname);
                break;
            case LessEqual:
                op = "%s<=%s";
                fd = getContextParser().trimQueryFlag(queryOperator, fieldname);
                break;
            case LessThan:
                op = "%s<%s";
                fd = getContextParser().trimQueryFlag(queryOperator, fieldname);
                break;
//            case Like:
//                op = "%s like %s";
//                break;
//            case In: {
//                if (v instanceof List<?>) {
//                    List<String> list = new ArrayList<>();
//                    for (int i = 0; i < ((List<?>) v).size(); i++) {
//                        list.add(symbol);
//                    }
//                    if (!list.isEmpty()) {
//                        op = "%s in(" + String.join(",", list) + ")";
//                    }
//                }
//                fd = getContextParser().trimQueryFlag(queryOperator,fieldname);
//
//                break;
//            }
//            case NotIn: {
//                if (v instanceof List<?>) {
//                    List<String> list = new ArrayList<>();
//                    for (int i = 0; i < ((List<?>) v).size(); i++) {
//                        list.add(symbol);
//                    }
//                    if (!list.isEmpty()) {
//                        op = "%s not in(" + String.join(",", list) + ")";
//                    }
//                }
//                fd = getContextParser().trimQueryFlag(queryOperator,fieldname);
//                break;
//            }
//            case IsOrNotNull: {
//                if (v instanceof Boolean) {
//                    if (!((Boolean) v)) {
//                        op = "%s is not null";
//                    } else {
//                        op = "%s is null";
//                    }
//                    fd = getContextParser().trimQueryFlag(queryOperator,fieldname);
//                }
//                break;
//            }
//            case SubQuery: {
//                if ((dbQuery != null) && StringUtils.hasText(dbQuery.express())) {
//                    op = dbQuery.express();
//                }
//                break;
//            }
            default:
                throw new NSException(queryOperator + "not impliment");
        }

        String getidsymbol = String.format(GETID_SYMBOL, symbol);
        if (isAutoKey) {
            fd = getidsymbol;
        } else {
            fd = String.format("%s.%s", symbol, fd);
        }

        if (op == null) {
            return null;
        } else {
            return String.format(op, fd, paramsymbol + fieldname);
        }
    }

    public String getParameterSymbol() {
        return PARAM_SYMBOL;
    }
}
