package cn.nsoc.neo4j.storer.neo4j;

import cn.nsoc.base.entity.sys.NSException;
import cn.nsoc.base.entity.tuple.Tuple2;
import cn.nsoc.common.storer.EntityCollection;
import cn.nsoc.common.storer.EntityQuery;
import cn.nsoc.common.storer.context.EntityProperty;
import cn.nsoc.common.storer.option.InsertBuilder;
import cn.nsoc.common.storer.option.QueryItem;
import cn.nsoc.neo4j.storer.context.Neo4jEntityContext;
import org.neo4j.driver.v1.Record;
import org.neo4j.driver.v1.StatementResult;
import org.neo4j.driver.v1.StatementRunner;
import org.neo4j.driver.v1.Values;
import org.neo4j.driver.v1.types.Entity;
import org.springframework.util.Assert;

import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

class NodeOperator extends BaseEntityOperator {
    NodeOperator(Neo4jStorer neo4jStorer){
        super(neo4jStorer,"n");
    }

    @Override
    public boolean insert(StatementRunner conn, Object me, Neo4jEntityContext ectx) throws NSException {

        try {

            String getnodesymbol = String.format(GETID_SYMBOL, getEntitySymbol());
            StringBuilder sbpropertyStatement = new StringBuilder();
            Map<String, Object> properties = buildProperties(me, ectx, sbpropertyStatement, FMT_PARAM);
            String cql = String.format("CREATE (%s:%s %s) return %s",
                    getEntitySymbol(),
                    escapeLabel(ectx.getLabel()),
                    sbpropertyStatement,
                    getnodesymbol);

            if (logger.isTraceEnabled()) {
                logger.trace(cql);
            }

            Map<String,Object> params = new HashMap<>();
            params.put(KEY_PROP,properties);
            StatementResult result = conn.run(cql, params);
            if (result.hasNext()) {
                Record record = result.next();
                setAutoId(me,ectx,record.get(getnodesymbol).asLong());
            }
            int num = result.summary().counters().nodesCreated();
            if (logger.isTraceEnabled()) {
                logger.trace(String.format("%d nodesCreated", num));
            }
            return num > 0;
        }
        catch (Exception ex){
            throw  new NSException(ex);
        }
    }

    /**
    * match p=(a1) -[:`Relation`*..2]- (b1) where 1=1  and (id(a1)=7307)
     * unwind relationships(p) as r
     * with distinct r,a1 as a1,b1 as b1
     * return a1,b1
     * skip 0 limit 10
    */
    @Override
    public  <E, Q extends EntityQuery, C extends EntityCollection<E, Q>> C load(Neo4jEntityContext ectx, C me, StatementRunner conn) throws NSException {

        Q query = me.getQuery();

        List<Tuple2<EntityProperty, QueryItem>> listProp = new ArrayList<>();
        String sbWhere = buildQuery(query, listProp, ectx,getEntitySymbol());
        String sbCondition = buildConditions(query, listProp);

        StringBuilder sbLimit = new StringBuilder();
        if ((query.start != 0) || (query.count != Integer.MAX_VALUE)) {
            sbLimit.append(String.format(" SKIP %d LIMIT %d ", query.start, query.count));
        }

        String cql = String.format("match (%s:%s) where 1=1 %s %s return %s %s",
                getEntitySymbol(),
                escapeLabel(ectx.getLabel()),
                sbWhere,
                sbCondition,
                getEntitySymbol(),
                sbLimit);

        if (logger.isTraceEnabled()) {
            logger.trace(cql.toString());
        }

        Map<String, Object> params = new HashMap<>();
        for (Tuple2<EntityProperty, QueryItem> t2 : listProp) {
            QueryItem qi = t2.getB();
            params.put(qi.getField(), qi.getValue());
        }

        StatementResult result = conn.run(cql, params);
        while (result.hasNext()) {
            Record record = result.next();
            me.add(loadEntityData(me.newEntity(), record.get(getEntitySymbol()).asNode(), ectx));
        }


        if (logger.isTraceEnabled()) {
            logger.trace(String.format("%d node listed",me.size()));
        }
        return me;
    }

    @Override
    protected <E> E loadEntityData(E me, Entity entity, Neo4jEntityContext ectx) throws NSException {
        return super.loadEntityData(me,entity,ectx);
    }

    @Override
    public boolean update(Object me, Neo4jEntityContext eCtx, StatementRunner conn) throws NSException {

        Assert.notEmpty(eCtx.getKeyProperty());

        Map<String, Object> mapPropertes = new HashMap<>();
        Map<String, Object> mapKeys = new HashMap<>();


        StringBuilder sbWhere = new StringBuilder();
        sbWhere.append(" 1=1 ");
        try {
            for (EntityProperty prop : eCtx.getProperties().values()) {
                Field fd = prop.getField();
                Object v = fd.get(me);
                String fieldname = prop.getFieldName();

                if (prop.getIsKey()) {
                    if (v == null) {
                        throw new NSException(eCtx.getLabel() + " Key为空");
                    }
                    if (prop.getAutoIncrement()) {
                        sbWhere.append(String.format(" and id(%s)=$keys.%s", getEntitySymbol(), fieldname));
                    } else {
                        sbWhere.append(String.format(" and %s.%s=$keys.%s", getEntitySymbol(), fieldname, fieldname));
                    }
                    mapKeys.put(fieldname, v);
                } else {
                    mapPropertes.put(fieldname, v);
                }
            }
        } catch (Exception ex) {
            throw new NSException(ex);
        }


        String cql = String.format("MATCH (%s:%s) where %s set %s += $props",
                getEntitySymbol(),
                escapeLabel(eCtx.getLabel()),
                sbWhere,
                getEntitySymbol(),
                getEntitySymbol());

        if (logger.isTraceEnabled()) {
            logger.trace(cql);
        }

        Map<String, Object> params = new HashMap<>();
        params.put("props", mapPropertes);
        params.put("keys", mapKeys);
        StatementResult result = conn.run(cql, params);
        result.summary().counters();
        return true;
    }

    @Override
    public boolean delete(Object me,Neo4jEntityContext eCtx, StatementRunner conn ) throws NSException {

        StringBuilder sbWhere = new StringBuilder();
        Map<String, Object> mapParams = new HashMap<>();
        String getnodesymbol = String.format(GETID_SYMBOL, getEntitySymbol());
        try {
            for (EntityProperty prop : eCtx.getProperties().values()) {
                Field fd = prop.getField();
                String fn = prop.getFieldName();
                Object v = fd.get(me);

                if (v == null) {
                    continue;
                }

                mapParams.put(fn, v);

                if (sbWhere.length() > 0) {
                    sbWhere.append(" and ");
                }
                String fieldname;
                if (prop.getIsKey() && prop.getAutoIncrement()) {
                    fieldname = getnodesymbol;
                } else {
                    fieldname = String.format("%s.%s", getEntitySymbol(), fn);
                }
                sbWhere.append(String.format(" %s = $%s ", fieldname, fn));
            }
        } catch (Exception ex) {
            throw new NSException(ex);
        }

        if (sbWhere.length() == 0) {
            throw new NSException("DANGER! it will delete all node!");
        }

        String cql = String.format("MATCH (%s:%s) where %s DETACH DELETE %s",
                getEntitySymbol(),
                escapeLabel(eCtx.getLabel()),
                sbWhere,
                getEntitySymbol());

        if (logger.isTraceEnabled()) {
            logger.trace(cql);
        }
        StatementResult result = conn.run(cql, mapParams);

        int num = result.summary().counters().nodesDeleted();
        if (logger.isTraceEnabled()) {
            logger.trace(String.format("%d nodesDeleted", num));
        }
        return num > 0;
    }

    @Override
    public <Q extends EntityQuery> boolean delete(Q query, Neo4jEntityContext qCtx, Neo4jEntityContext eCtx, StatementRunner conn) throws NSException {

        List<Tuple2<EntityProperty, QueryItem>> listProp = new ArrayList<>();
        String sbWhere = buildQuery(query, listProp, eCtx,getEntitySymbol());
        String sbCondition = buildConditions(query, listProp);

        if (sbWhere.length() == 0) {
            throw new NSException("DANGER! it will delete all node!");
        }

        String cql = String.format("MATCH (%s:%s) where 1=1 %s %s DETACH DELETE %s",
                getEntitySymbol(),
                escapeLabel(eCtx.getLabel()),
                sbWhere,
                sbCondition,
                getEntitySymbol());

        if (logger.isTraceEnabled()) {
            logger.trace(cql);
        }

        Map<String, Object> params = new HashMap<>();
        for (Tuple2<EntityProperty, QueryItem> t2 : listProp) {
            QueryItem qi = t2.getB();
            params.put(qi.getField(), qi.getValue());
        }

        StatementResult result = conn.run(cql, params);

        if (logger.isTraceEnabled()) {
            logger.trace(String.format("%d nodesDeleted", result.summary().counters().nodesDeleted()));
        }
        return true;
    }

    @Override
    public boolean batchInsert(List<Object> list, InsertBuilder builder,Neo4jEntityContext eCtx,StatementRunner conn) throws NSException {

        List<Map<String, Object>> propertiesList = new ArrayList<>();
        StringBuilder sbPropertyStatement = new StringBuilder();
        for (Object o : list) {
            propertiesList.add(buildProperties(o, eCtx,
                    sbPropertyStatement.length() == 0 ? sbPropertyStatement : null,
                    FMT_PARAMROW));
        }
        String cql = String.format("UNWIND %s%s AS %s CREATE (%s:%s %s)",
                PARAM_SYMBOL,
                KEY_LIST,
                ROW_SYMBOL,
                getEntitySymbol(),
                escapeLabel(eCtx.getLabel()),
                sbPropertyStatement);

        if (logger.isTraceEnabled()) {
            logger.trace(cql);
        }

        StatementResult result = conn.run(cql, Values.parameters(KEY_LIST, propertiesList));
        if (logger.isTraceEnabled()) {
            logger.trace(String.format("nodesCreated: %d", result.summary().counters().nodesCreated()));
        }
        return true;
    }
}
