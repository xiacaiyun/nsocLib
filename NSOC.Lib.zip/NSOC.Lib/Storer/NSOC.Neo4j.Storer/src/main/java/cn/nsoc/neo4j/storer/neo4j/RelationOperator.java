package cn.nsoc.neo4j.storer.neo4j;

import cn.nsoc.base.entity.sys.NSException;
import cn.nsoc.base.entity.tuple.Tuple2;
import cn.nsoc.base.entity.tuple.Tuple4;
import cn.nsoc.common.storer.EntityCollection;
import cn.nsoc.common.storer.EntityQuery;
import cn.nsoc.common.storer.annotation.graph.Neo4jRelationField;
import cn.nsoc.common.storer.annotation.graph.RelationDirection;
import cn.nsoc.common.storer.context.EntityProperty;
import cn.nsoc.common.storer.option.InsertBuilder;
import cn.nsoc.common.storer.option.QueryItem;
import cn.nsoc.neo4j.storer.context.Neo4jEntityContext;
import cn.nsoc.neo4j.storer.context.Neo4jEntityProperty;
import org.neo4j.driver.v1.Record;
import org.neo4j.driver.v1.StatementResult;
import org.neo4j.driver.v1.StatementRunner;
import org.neo4j.driver.v1.types.Entity;
import org.neo4j.driver.v1.types.Relationship;
import org.springframework.util.Assert;
import org.springframework.util.StringUtils;

import java.lang.reflect.Field;
import java.util.*;

class RelationOperator extends BaseEntityOperator {

    RelationOperator(Neo4jStorer neo4jStorer) {
        super(neo4jStorer, "r");
    }

    /**
     * MATCH (a:Person),(b:Person)
     * WHERE a.name = 'Node A' AND b.name = 'Node B'
     * CREATE (a)-[r:RELTYPE]->(b)
     * RETURN r
     */
    @Override
    public boolean insert(StatementRunner conn, Object me, Neo4jEntityContext ectx) throws NSException {

        try {
            Tuple4<String, String, String, Map<String, Object>> from = null;
            Tuple4<String, String, String, Map<String, Object>> to = null;
            for (EntityProperty prop : ectx.getProperties().values()) {
                Neo4jEntityProperty nprop = (Neo4jEntityProperty) prop;
                Neo4jRelationField rlfield = nprop.getRelationField();
                if (rlfield != null) {
                    switch (rlfield.type()) {
                        case from:
                            from = buildRelationCondition(nprop, me);
                            break;
                        case to:
                            to = buildRelationCondition(nprop, me);
                            break;
                        default:
                            break;
                    }
                }
            }
            if (from == null || to == null) {
                throw new NSException("from , to must have value");
            }

            String getidsymbol = String.format(GETID_SYMBOL, getEntitySymbol());

            StringBuilder sbpropertyStatement = new StringBuilder();
            Map<String, Object> properties = buildProperties(me, ectx, sbpropertyStatement, FMT_PARAM);

            String match = String.join(",", from.getB(), to.getB());
            String where = String.join(" and ", from.getC(), to.getC());
            String rl = String.format("(%s)-[%s:%s %s]->(%s)",
                    from.getA(), getEntitySymbol(),
                    escapeLabel(ectx.getLabel()),
                    sbpropertyStatement,
                    to.getA());
            String ret = getidsymbol;
            Map<String, Object> params = new HashMap<>();
            params.put(from.getA(), from.getD());
            params.put(to.getA(), to.getD());
            params.put(KEY_PROP, properties);


            String cql = String.format("MATCH %s WHERE %s CREATE %s return %s",
                    match,
                    where,
                    rl,
                    ret);

            if (logger.isTraceEnabled()) {
                logger.trace(cql);
            }
            StatementResult result = conn.run(cql, params);
            if (result.hasNext()) {
                Record record = result.next();
                setAutoId(me,ectx,record.get(getidsymbol).asLong());
            }
            int num = result.summary().counters().relationshipsCreated();
            if (logger.isTraceEnabled()) {
                logger.trace(String.format("%d relationshipsCreated", num));
            }
            return num > 0;
        } catch (Exception ex) {
            throw new NSException(ex);
        }
    }

    /**
     * MATCH p=(a)-[:Relation *0..]-(b) where a.name="ddd"
     * unwind relationships(p) as r with distinct r where id(r)=5  return r skip 0 limit 100
     */
    @Override
    public <E, Q extends EntityQuery, C extends EntityCollection<E, Q>> C load(Neo4jEntityContext ectx, C me, StatementRunner conn) throws NSException {

        Q query = me.getQuery();
        Neo4jEntityContext qctx = (Neo4jEntityContext) neo4jStorer.getContextParser().getObjectProperties(query);

        QueryCondition qc = parseQueryCondition(query,qctx);

        if (qc.direction == RelationDirection.none){
            throw new NSException("bad design with none relationship searching, slow down performance seriously! ");
        }

        List<Tuple2<EntityProperty, QueryItem>> listProp = new ArrayList<>();
        String sbWhereRl = buildQuery(query, listProp, ectx, getEntitySymbol());
        String sbCondition = buildConditions(query, listProp);

        Map<String, Object> params = new HashMap<>();

        StringBuilder sbWhereNode = new StringBuilder();
        if (qc.from != null) {
            sbWhereNode.append(String.format(" and %s", qc.from.getC()));
            params.put(qc.from.getA(), qc.from.getD());

        }
        if (qc.to != null) {
            sbWhereNode.append(String.format(" and %s", qc.to.getC()));
            params.put(qc.to.getA(), qc.to.getD());
        }
        StringBuilder sbLimit = new StringBuilder();
        if ((query.start != 0) || (query.count != Integer.MAX_VALUE)) {
            sbLimit.append(String.format(" SKIP %d LIMIT %d ", query.start, query.count));
        }

        String rlLabel = String.format(":%s",escapeLabel(ectx.getLabel()));

        String rlDepth = "";
        if (qc.mindepth != null || qc.maxdepth != null){
            rlDepth = String.format("*%s..%s",
                    (qc.mindepth == null) ? "": qc.mindepth.toString(),
                    (qc.maxdepth == null) ? "": qc.maxdepth.toString());
        }
        //getEntitySymbol(),
        String  sbRl = String.format("%s-[%s%s]-%s",
                    (qc.direction == RelationDirection.belongto) ? "<" :"",
                    rlLabel,
                    rlDepth,
                    (qc.direction == RelationDirection.own) ? ">" :"");

        String cql = String.format("match %s=(%s) %s (%s) where 1=1 %s " +
                        "unwind relationships(%s) as %s with distinct %s  " +
                        "where 1=1 %s %s return %s %s",
                PATH_SYMBOL,
                (qc.from == null) ? "" : qc.from.getA(),
                sbRl,
                (qc.to == null) ? "" : qc.to.getA(),
                sbWhereNode,
                PATH_SYMBOL,
                getEntitySymbol(),
                getEntitySymbol(),
                sbWhereRl,
                sbCondition,
                getEntitySymbol(),
                sbLimit);


        if (logger.isTraceEnabled()) {
            logger.trace(cql.toString());
        }


        for (Tuple2<EntityProperty, QueryItem> t2 : listProp) {
            QueryItem qi = t2.getB();
            params.put(qi.getField(), qi.getValue());
        }


        StatementResult result = conn.run(cql, params);
        while (result.hasNext()) {
            Record record = result.next();
            me.add(loadEntityData(me.newEntity(), record.get(getEntitySymbol()).asRelationship(), ectx));
        }


        if (logger.isTraceEnabled()) {
            logger.trace(String.format("%d relations listed", me.size()));
        }

        //                if (!query.skipTotalCount && pstat.getMoreResults()) {
//                    try (ResultSet rs2 = pstat.getResultSet()){
//                        if ((rs2 != null) && rs2.next()) {
//                            query.totalCount = rs2.getLong(1);
//                        }
//                    }
//                }
        return me;
//
    }

    @Override
    public boolean update(Object me, Neo4jEntityContext eCtx, StatementRunner conn) throws NSException {

        Assert.notEmpty(eCtx.getKeyProperty());

        Map<String, Object> mapPropertes = new HashMap<>();
        Map<String, Object> mapKeys = new HashMap<>();


        StringBuilder sbWhere = new StringBuilder();
        sbWhere.append(" 1=1 ");
        try {
            for (EntityProperty prop : eCtx.getProperties().values()) {
                Field fd = prop.getField();
                Object v = fd.get(me);
                String fieldname = prop.getFieldName();

                if (prop.getIsKey()) {
                    if (v == null) {
                        throw new NSException(eCtx.getLabel() + " Key为空");
                    }
                    if (prop.getAutoIncrement()) {
                        sbWhere.append(String.format(" and id(%s)=$keys.%s", getEntitySymbol(), fieldname));
                    } else {
                        sbWhere.append(String.format(" and %s.%s=$keys.%s", getEntitySymbol(), fieldname, fieldname));
                    }
                    mapKeys.put(fieldname, v);
                } else {
                    mapPropertes.put(fieldname, v);
                }
            }
        } catch (Exception ex) {
            throw new NSException(ex);
        }

        String cql = String.format("MATCH ()-[%s:%s]->() where %s set %s += $props",
                getEntitySymbol(),
                escapeLabel(eCtx.getLabel()),
                sbWhere,
                getEntitySymbol(),
                getEntitySymbol());

        if (logger.isTraceEnabled()) {
            logger.trace(cql);
        }

        Map<String, Object> params = new HashMap<>();
        params.put("props", mapPropertes);
        params.put("keys", mapKeys);
        StatementResult result = conn.run(cql, params);

        if (logger.isTraceEnabled()) {
            logger.trace(cql);
            logger.trace(String.format("%d properties set", result.summary().counters().propertiesSet()));
        }
        return true;
    }

    @Override
    protected <E> E loadEntityData(E me, Entity entity, Neo4jEntityContext ectx) throws NSException {
        try {
            super.loadEntityData(me,entity,ectx);

            Relationship relationship = (Relationship)entity;

            Neo4jEntityProperty propFrom = ectx.getPropFrom();
            if (propFrom != null) {
                propFrom.getField().set(me, neo4jStorer.fromDsValue(propFrom.getValueConverter(), relationship.startNodeId()));
            }
            Neo4jEntityProperty propTo = ectx.getPropTo();
            if (propTo != null) {
                propTo.getField().set(me, neo4jStorer.fromDsValue(propFrom.getValueConverter(), relationship.endNodeId()));
            }
            return me;

        } catch (Exception ex) {
            throw new NSException(ex);
        }
    }

    @Override
    public boolean delete(Object me, Neo4jEntityContext eCtx, StatementRunner conn) throws NSException {

        StringBuilder sbWhere = new StringBuilder();

        String getentitysymbol = String.format(GETID_SYMBOL, getEntitySymbol());
        Map<String, Object> params = buildEntityWhereCondition(me,eCtx,sbWhere,getEntitySymbol());
        if (sbWhere.length() == 0) {
            throw new NSException("DANGER! it will delete all relations!");
        }

        String cql = String.format("MATCH ()-[%s:%s]->() where 1=1 %s DELETE %s",
                getEntitySymbol(),
                escapeLabel(eCtx.getLabel()),
                sbWhere,
                getEntitySymbol());

        if (logger.isTraceEnabled()) {
            logger.trace(cql);
        }
        StatementResult result = conn.run(cql, params);

        if (logger.isTraceEnabled()) {
            logger.trace(String.format("%d relationshipsDeleted", result.summary().counters().relationshipsDeleted()));
        }
        return true;
    }

    @Override
    public <Q extends EntityQuery> boolean delete(Q query, Neo4jEntityContext qCtx, Neo4jEntityContext eCtx, StatementRunner conn) throws NSException {

        QueryCondition qc =  parseQueryCondition(query,qCtx);

        List<Tuple2<EntityProperty, QueryItem>> listProp = new ArrayList<>();
        String sbWhereRl = buildQuery(query, listProp, eCtx, getEntitySymbol());
        String sbCondition = buildConditions(query, listProp);

        Map<String, Object> params = new HashMap<>();

        StringBuilder sbWhereNode = new StringBuilder();
        if (qc.from != null) {
            sbWhereNode.append(String.format(" and %s", qc.from.getC()));
            params.put(qc.from.getA(), qc.from.getD());

        }
        if (qc.to != null) {
            sbWhereNode.append(String.format(" and %s", qc.to.getC()));
            params.put(qc.to.getA(), qc.to.getD());
        }

        if (qc.from == null && qc.to == null && (sbWhereRl.length() == 0)) {
            throw new NSException("DANGER! it will delete all relations!");
        }

        String cql = String.format("MATCH (%s)-[%s:%s]->(%s) where (1=1 %s) %s %s  DELETE %s",
                (qc.from == null) ? "" : qc.from.getA(),
                getEntitySymbol(),
                escapeLabel(eCtx.getLabel()),
                (qc.to == null) ? "" : qc.to.getA(),
                sbWhereNode,
                sbWhereRl,
                sbCondition,
                getEntitySymbol());

        if (logger.isTraceEnabled()) {
            logger.trace(cql);
        }
        StatementResult result = conn.run(cql, params);

        if (logger.isTraceEnabled()) {
            logger.trace(String.format("%d relationshipsDeleted", result.summary().counters().relationshipsDeleted()));
        }
        return true;
    }

    @Override
    public boolean batchInsert(List<Object> list, InsertBuilder builder, Neo4jEntityContext eCtx, StatementRunner conn) throws NSException {
        throw new NSException("not implemented");
    }
}
