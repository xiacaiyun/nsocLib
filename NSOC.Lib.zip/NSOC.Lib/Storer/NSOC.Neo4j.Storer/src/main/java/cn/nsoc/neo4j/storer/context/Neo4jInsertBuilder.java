package cn.nsoc.neo4j.storer.context;

public class Neo4jInsertBuilder {
}
