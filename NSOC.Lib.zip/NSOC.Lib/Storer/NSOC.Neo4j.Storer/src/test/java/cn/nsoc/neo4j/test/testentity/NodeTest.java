package cn.nsoc.neo4j.test.testentity;

import cn.nsoc.common.storer.EntityCollection;
import cn.nsoc.common.storer.EntityQuery;
import cn.nsoc.common.storer.annotation.DbField;
import cn.nsoc.common.storer.annotation.graph.Neo4jObject;
import cn.nsoc.common.storer.annotation.graph.Neo4jRelationField;
import cn.nsoc.common.storer.annotation.graph.RelationDirection;
import cn.nsoc.common.storer.annotation.graph.RelationFieldType;

public class NodeTest {
    @Neo4jObject(name = "NodeTest")
    public static  class Entity {
        @DbField(isKey = true)
        private int id;
        private String name;
        private Integer value;

        public String getName() {
            return name;
        }

        public void setName(String name) {
            this.name = name;
        }

        public Integer getValue() {
            return value;
        }

        public void setValue(Integer value) {
            this.value = value;
        }

        public int getId() {
            return id;
        }

        public void setId(int id) {
            this.id = id;
        }
    }

    public static class Query extends EntityQuery {
        private Integer id;

        private String name;

        private Integer value;

        @Neo4jRelationField(type= RelationFieldType.from)
        private Integer a;

        @Neo4jRelationField(type= RelationFieldType.to)
        private Integer b;

        @Neo4jRelationField(type= RelationFieldType.direction)
        private RelationDirection direction;

        @Neo4jRelationField(type= RelationFieldType.mindepth)
        private Integer mindepth;

        @Neo4jRelationField(type= RelationFieldType.maxdepth)
        private Integer maxdepth;

        public String getName() {
            return name;
        }

        public void setName(String name) {
            this.name = name;
        }

        public Integer getId() {
            return id;
        }

        public void setId(Integer id) {
            this.id = id;
        }

        public Integer getValue() {
            return value;
        }

        public void setValue(Integer value) {
            this.value = value;
        }

        public Integer getA() {
            return a;
        }

        public void setA(Integer a) {
            this.a = a;
        }

        public Integer getB() {
            return b;
        }

        public void setB(Integer b) {
            this.b = b;
        }

        public RelationDirection getDirection() {
            return direction;
        }

        public void setDirection(RelationDirection direction) {
            this.direction = direction;
        }

        public Integer getMindepth() {
            return mindepth;
        }

        public void setMindepth(Integer mindepth) {
            this.mindepth = mindepth;
        }

        public Integer getMaxdepth() {
            return maxdepth;
        }

        public void setMaxdepth(Integer maxdepth) {
            this.maxdepth = maxdepth;
        }
    }

    public static class Coll extends EntityCollection<Entity,Query> {

        public Coll() {
            super(Entity.class, Query.class);
        }

        public Coll(Query query) {
            super(Entity.class, Query.class);
            setQuery(query);;
        }
    }
}
