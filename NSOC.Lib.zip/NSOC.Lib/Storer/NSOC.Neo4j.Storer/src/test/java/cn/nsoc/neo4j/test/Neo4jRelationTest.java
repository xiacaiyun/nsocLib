package cn.nsoc.neo4j.test;

import cn.nsoc.common.storer.annotation.graph.RelationDirection;
import cn.nsoc.neo4j.storer.context.Neo4jConfig;
import cn.nsoc.neo4j.storer.neo4j.Neo4jStorer;
import cn.nsoc.neo4j.test.testentity.NodeOneAutoKey;
import cn.nsoc.neo4j.test.testentity.Relation;
import junit.framework.TestCase;

public class Neo4jRelationTest extends TestCase {
    private Neo4jStorer neo4jStorer;

    public void setUp() throws Exception {
        super.setUp();
        Neo4jConfig config = new Neo4jConfig("bolt://192.168.1.27", "neo4j", "111111");
        neo4jStorer = new Neo4jStorer(config);
    }


    public void testRelationIDU() throws Exception {

        int constvalue   = 777777;
        NodeOneAutoKey.Query clearQuery = new NodeOneAutoKey.Query();
        clearQuery.setValue(constvalue);
        neo4jStorer.delete(clearQuery,NodeOneAutoKey.Entity.class);
        NodeOneAutoKey.Coll nodecoll = neo4jStorer.load(new NodeOneAutoKey.Coll(clearQuery));
        assertTrue(nodecoll.size() == 0);


        NodeOneAutoKey.Entity node1 = new NodeOneAutoKey.Entity();

        node1.setName("n1");
        node1.setValue(constvalue);
        neo4jStorer.insert(node1);

        int nodeId1 = node1.getId();

        NodeOneAutoKey.Entity node2 = new NodeOneAutoKey.Entity();

        node2.setName("n2");
        node2.setValue(constvalue);
        neo4jStorer.insert(node2);

        int nodeId2 = node2.getId();

        Relation.Entity relation = new Relation.Entity();
        relation.setA(nodeId1);
        relation.setB(nodeId2);
        relation.setName("own");

        neo4jStorer.insert(relation);

        assertTrue(relation.getId() > 0);


        Relation.Query query = new Relation.Query();
        query.setDirection(RelationDirection.own);
        query.setId(relation.getId());
        Relation.Coll coll = neo4jStorer.load(new Relation.Coll(query));
        assertTrue(coll.size() == 1);

        neo4jStorer.delete(relation);
        coll = neo4jStorer.load(new Relation.Coll(query));
        assertTrue(coll.size() == 0);
        neo4jStorer.insert(relation);

        query.setId(relation.getId());
        coll = neo4jStorer.load(new Relation.Coll(query));
        assertTrue(coll.size() == 1);

        relation.setName("changedName");
        neo4jStorer.update(relation);
        coll = neo4jStorer.load(new Relation.Coll(query));
        assertTrue(coll.size() == 1);
        Relation.Entity fromDb = coll.firstOrDefault();
        assertEquals(fromDb.getName(),relation.getName());



        Relation.Query query2 = new Relation.Query();
        query2.setA(nodeId1);
        query2.setB(nodeId2);
        query2.setName(relation.getName());
        coll = neo4jStorer.load(new Relation.Coll(query2));
        assertTrue(coll.size() == 1);

        Relation.Entity relation2 = new Relation.Entity();
        relation2.setA(nodeId1);
        relation2.setB(nodeId2);
        relation2.setName("both");
        neo4jStorer.insert(relation2);

        Relation.Query query3 = new Relation.Query();
        query3.setA(nodeId1);
        query3.setB(nodeId2);
        coll = neo4jStorer.load(new Relation.Coll(query3));
        assertTrue(coll.size() == 2);


        neo4jStorer.delete(query3, Relation.Entity.class);
        coll = neo4jStorer.load(new Relation.Coll(query3));
        assertTrue(coll.size() == 0);


        neo4jStorer.delete(node1);
        neo4jStorer.delete(node2);

    }

    public void testRelationQuery() throws Exception {

        int constvalue   = 888888;
        NodeOneAutoKey.Query clearQuery = new NodeOneAutoKey.Query();
        clearQuery.setValue(constvalue);
        neo4jStorer.delete(clearQuery,NodeOneAutoKey.Entity.class);
        NodeOneAutoKey.Coll nodecoll = neo4jStorer.load(new NodeOneAutoKey.Coll(clearQuery));
        assertTrue(nodecoll.size() == 0);


        NodeOneAutoKey.Entity node1 = new NodeOneAutoKey.Entity();
        node1.setName("p1");
        node1.setValue(constvalue);
        neo4jStorer.insert(node1);

        NodeOneAutoKey.Entity node2 = new NodeOneAutoKey.Entity();
        node2.setName("p2");
        node1.setValue(constvalue);
        neo4jStorer.insert(node2);

        NodeOneAutoKey.Entity node3 = new NodeOneAutoKey.Entity();
        node3.setName("p3");
        node1.setValue(constvalue);
        neo4jStorer.insert(node3);

        NodeOneAutoKey.Entity node4 = new NodeOneAutoKey.Entity();
        node4.setName("p4");
        node1.setValue(constvalue);
        neo4jStorer.insert(node4);


        Relation.Entity relation1 = new Relation.Entity();
        relation1.setA(node1.getId());
        relation1.setB(node2.getId());
        relation1.setName("r1");
        neo4jStorer.insert(relation1);

        Relation.Entity relation2 = new Relation.Entity();
        relation2.setA(node2.getId());
        relation2.setB(node3.getId());
        relation2.setName("r2");
        neo4jStorer.insert(relation2);

        Relation.Entity relation3 = new Relation.Entity();
        relation3.setA(node3.getId());
        relation3.setB(node4.getId());
        relation3.setName("r3");
        neo4jStorer.insert(relation3);

        Relation.Entity relation4 = new Relation.Entity();
        relation4.setA(node1.getId());
        relation4.setB(node4.getId());
        relation4.setName("r4");
        neo4jStorer.insert(relation4);


        Relation.Query query = new Relation.Query();
        query.setDirection(RelationDirection.both);
        Relation.Coll coll = neo4jStorer.load(new Relation.Coll(query));
        assertTrue(coll.size() >= 4);

        query.setA(node2.getId());
        query.setDirection(RelationDirection.own);
        coll = neo4jStorer.load(new Relation.Coll(query));
        assertTrue(coll.size() == 1);
        assertEquals(coll.get(0).getB(),node3.getId());

        query.setA(node2.getId());
        query.setDirection(RelationDirection.belongto);
        coll = neo4jStorer.load(new Relation.Coll(query));
        assertTrue(coll.size() == 1);
        assertEquals(coll.get(0).getA(),node1.getId());


        query.setDirection(RelationDirection.own);
        query.setMindepth(3);
        coll = neo4jStorer.load(new Relation.Coll(query));
        assertTrue(coll.size() == 0);

        query.setDirection(RelationDirection.own);
        query.setMindepth(2);
        coll = neo4jStorer.load(new Relation.Coll(query));
        assertTrue(coll.size() == 2);

        query.setDirection(RelationDirection.both);
        query.setMindepth(2);
        query.setMindepth(3);
        coll = neo4jStorer.load(new Relation.Coll(query));
        assertTrue(coll.size() == 4);


        query.setDirection(RelationDirection.both);
        query.setMaxdepth(1);
        query.setMindepth(null);
        coll = neo4jStorer.load(new Relation.Coll(query));
        assertTrue(coll.size() == 2);

        query.setDirection(RelationDirection.both);
        query.setMaxdepth(3);
        query.setMindepth(3);
        coll = neo4jStorer.load(new Relation.Coll(query));
        assertTrue(coll.size() == 4);

        query.setDirection(RelationDirection.both);
        query.setMaxdepth(0);
        query.setMindepth(0);
        coll = neo4jStorer.load(new Relation.Coll(query));
        assertTrue(coll.size() == 0);

        neo4jStorer.delete(clearQuery,NodeOneAutoKey.Entity.class);
        nodecoll = neo4jStorer.load(new NodeOneAutoKey.Coll(clearQuery));
        assertTrue(nodecoll.size() == 0);

    }
}