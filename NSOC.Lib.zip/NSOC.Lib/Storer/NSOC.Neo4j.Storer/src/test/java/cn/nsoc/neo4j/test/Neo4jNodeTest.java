package cn.nsoc.neo4j.test;

import cn.nsoc.base.entity.sys.NSException;
import cn.nsoc.common.storer.annotation.graph.RelationDirection;
import cn.nsoc.neo4j.storer.context.Neo4jConfig;
import cn.nsoc.neo4j.storer.neo4j.Neo4jStorer;
import cn.nsoc.neo4j.test.testentity.*;
import junit.framework.TestCase;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

public class Neo4jNodeTest extends TestCase {
    private Neo4jStorer neo4jStorer;

    public void setUp() throws Exception {
        super.setUp();
        Neo4jConfig config = new Neo4jConfig("bolt://192.168.1.27", "neo4j", "111111");
        neo4jStorer = new Neo4jStorer(config);
    }

    public void testInsertNodeNoKey() throws Exception {
        NodeNoKey.Entity node = new NodeNoKey.Entity();
        node.setId(1);
        node.setValue(101);
        node.setName("n1");

        NodeNoKey.Entity node2 = new NodeNoKey.Entity();
        node2.setId(2);
        node2.setName("n2");
        node2.setValue(102);


        //clear
        neo4jStorer.delete(node);
        neo4jStorer.delete(node2);

        //begin

        neo4jStorer.insert(node);


        NodeNoKey.Query query = new NodeNoKey.Query();
        query.setId(1);
        NodeNoKey.Coll coll = neo4jStorer.load(new NodeNoKey.Coll(query));
        assertTrue(coll.size() == 1);

        neo4jStorer.insert(node);
        coll = neo4jStorer.load(new NodeNoKey.Coll(query));
        assertTrue(coll.size() == 2);


        neo4jStorer.insert(node2);

        NodeNoKey.Query query2 = new NodeNoKey.Query();
        query2.setId(2);
        NodeNoKey.Coll coll2 = neo4jStorer.load(new NodeNoKey.Coll(query2));
        assertTrue(coll2.size() == 1);

        neo4jStorer.delete(node);
        coll = neo4jStorer.load(new NodeNoKey.Coll(query));
        assertTrue(coll.isEmpty());

        neo4jStorer.delete(node2);
        coll2 = neo4jStorer.load(new NodeNoKey.Coll(query2));
        assertTrue(coll2.isEmpty());
    }

    public void testInsertNodeOneAutoKey() throws Exception {
        NodeOneAutoKey.Entity node = new NodeOneAutoKey.Entity();

        //begin

        node.setName("n1");
        node.setValue(101);
        neo4jStorer.insert(node);
        neo4jStorer.shutdown();

        int nodeId = node.getId();

        assertTrue(nodeId != 0);


        NodeOneAutoKey.Query query = new NodeOneAutoKey.Query();
        query.setId(nodeId);
        NodeOneAutoKey.Coll coll = neo4jStorer.load(new NodeOneAutoKey.Coll(query));
        assertTrue(coll.size() == 1);
        assertTrue(coll.get(0).getId() == nodeId);
        assertTrue(coll.get(0).getName().equals(node.getName()));
        assertTrue(coll.get(0).getValue() == node.getValue());

        NodeOneAutoKey.Query queryWithName = new NodeOneAutoKey.Query();
        queryWithName.setId(nodeId);
        queryWithName.setName(node.getName());
        coll = neo4jStorer.load(new NodeOneAutoKey.Coll(queryWithName));
        assertTrue(coll.size() == 1);
        assertTrue(coll.get(0).getId() == nodeId);
        assertTrue(coll.get(0).getName().equals(node.getName()));
        assertTrue(coll.get(0).getValue() == node.getValue());

        neo4jStorer.insert(node);

        int nodeId2 = node.getId();
        assertTrue(nodeId != nodeId2);
        query.setId(nodeId2);
        coll = neo4jStorer.load(new NodeOneAutoKey.Coll(query));
        assertTrue(coll.size() == 1);
        assertTrue(coll.get(0).getId() == nodeId2);
        assertTrue(coll.get(0).getName().equals(node.getName()));
        assertTrue(coll.get(0).getValue() == node.getValue());



        NodeOneAutoKey.Entity nodetodel = new NodeOneAutoKey.Entity();
        nodetodel.setId(nodeId);
        neo4jStorer.delete(nodetodel);
        query.setId(nodeId);
        coll = neo4jStorer.load(new NodeOneAutoKey.Coll(query));
        assertTrue(coll.isEmpty());

        nodetodel.setId(nodeId2);
        neo4jStorer.delete(nodetodel);
        query.setId(nodeId2);
        coll = neo4jStorer.load(new NodeOneAutoKey.Coll(query));
        assertTrue(coll.isEmpty());
    }

    public void testInsertNodeOneKeyNoAuto() throws Exception {
        NodeOneKeyNoAuto.Entity node = new NodeOneKeyNoAuto.Entity();
        node.setId(1);
        NodeOneKeyNoAuto.Entity node2 = new NodeOneKeyNoAuto.Entity();
        node2.setId(2);


        //clear
        neo4jStorer.delete(node);
        neo4jStorer.delete(node2);

        //begin

        node.setName("n1");
        node.setValue(101);
        neo4jStorer.insert(node);


        NodeOneKeyNoAuto.Query query = new NodeOneKeyNoAuto.Query();
        query.setId(1);
        NodeOneKeyNoAuto.Coll coll = neo4jStorer.load(new NodeOneKeyNoAuto.Coll(query));
        assertTrue(coll.size() == 1);

        neo4jStorer.insert(node);
        coll = neo4jStorer.load(new NodeOneKeyNoAuto.Coll(query));
        assertTrue(coll.size() == 2);


        node2.setName("n2");
        node2.setValue(102);
        neo4jStorer.insert(node2);

        NodeOneKeyNoAuto.Query query2 = new NodeOneKeyNoAuto.Query();
        query2.setId(2);
        NodeOneKeyNoAuto.Coll coll2 = neo4jStorer.load(new NodeOneKeyNoAuto.Coll(query2));
        assertTrue(coll2.size() == 1);

        neo4jStorer.delete(node);
        coll = neo4jStorer.load(new NodeOneKeyNoAuto.Coll(query));
        assertTrue(coll.isEmpty());

        neo4jStorer.delete(node2);
        coll2 = neo4jStorer.load(new NodeOneKeyNoAuto.Coll(query2));
        assertTrue(coll2.isEmpty());
    }

    public void testInsertNodeTwoKeyWithAuto() throws Exception {
        NodeTwoKeyWithAuto.Entity node = new NodeTwoKeyWithAuto.Entity();
        NodeTwoKeyWithAuto.Entity node2 = new NodeTwoKeyWithAuto.Entity();

        //begin

        node.setName("n1");
        node.setValue(101);
        neo4jStorer.insert(node);
        int nodeId = node.getId();

        assertTrue(nodeId != 0);

        NodeTwoKeyWithAuto.Query query = new NodeTwoKeyWithAuto.Query();
        query.setId(nodeId);
        NodeTwoKeyWithAuto.Coll coll = neo4jStorer.load(new NodeTwoKeyWithAuto.Coll(query));
        assertTrue(coll.size() == 1);
        assertTrue(coll.get(0).getId() == nodeId);
        assertTrue(coll.get(0).getName().equals(node.getName()));
        assertTrue(coll.get(0).getValue() == node.getValue());

        neo4jStorer.insert(node);
        int nodeId2 = node.getId();
        coll = neo4jStorer.load(new NodeTwoKeyWithAuto.Coll(query));
        assertTrue(coll.size() == 1);
        assertTrue(coll.get(0).getId() == nodeId);
        assertTrue(coll.get(0).getName().equals(node.getName()));
        assertTrue(coll.get(0).getValue() == node.getValue());


        node2.setName("n2");
        node2.setValue(102);
        neo4jStorer.insert(node2);

        int nodeId3 = node2.getId();

        NodeTwoKeyWithAuto.Query query2 = new NodeTwoKeyWithAuto.Query();
        query2.setId(nodeId3);
        NodeTwoKeyWithAuto.Coll coll2 = neo4jStorer.load(new NodeTwoKeyWithAuto.Coll(query2));
        assertTrue(coll2.size() == 1);
        assertTrue(coll2.get(0).getId() == nodeId3);
        assertTrue(coll2.get(0).getName().equals(node2.getName()));
        assertTrue(coll2.get(0).getValue() == node2.getValue());




        neo4jStorer.delete(node);
        query.setId(node.getId());
        coll = neo4jStorer.load(new NodeTwoKeyWithAuto.Coll(query));
        assertTrue(coll.isEmpty());


        NodeOneAutoKey.Entity nodetodel = new NodeOneAutoKey.Entity();
        nodetodel.setId(nodeId);
        coll = neo4jStorer.load(new NodeTwoKeyWithAuto.Coll(query));
        assertTrue(coll.isEmpty());

        neo4jStorer.delete(node2);
        coll2 = neo4jStorer.load(new NodeTwoKeyWithAuto.Coll(query2));
        assertTrue(coll2.isEmpty());
    }

    public void testInsertNodeNodeTwoKeyWithNoAuto() throws Exception {
        NodeTwoKeyWithNoAuto.Entity node = new NodeTwoKeyWithNoAuto.Entity();
        node.setId(1);
        NodeTwoKeyWithNoAuto.Entity node2 = new NodeTwoKeyWithNoAuto.Entity();
        node2.setId(2);


        //clear
        neo4jStorer.delete(node);
        neo4jStorer.delete(node2);

        //begin

        node.setName("n1");
        node.setValue(101);
        neo4jStorer.insert(node);


        NodeTwoKeyWithNoAuto.Query query = new NodeTwoKeyWithNoAuto.Query();
        query.setId(1);
        NodeTwoKeyWithNoAuto.Coll coll = neo4jStorer.load(new NodeTwoKeyWithNoAuto.Coll(query));
        assertTrue(coll.size() == 1);

        neo4jStorer.insert(node);
        coll = neo4jStorer.load(new NodeTwoKeyWithNoAuto.Coll(query));
        assertTrue(coll.size() == 2);


        node2.setName("n2");
        node2.setValue(102);
        neo4jStorer.insert(node2);

        NodeTwoKeyWithNoAuto.Query query2 = new NodeTwoKeyWithNoAuto.Query();
        query2.setId(2);
        NodeTwoKeyWithNoAuto.Coll coll2 = neo4jStorer.load(new NodeTwoKeyWithNoAuto.Coll(query2));
        assertTrue(coll2.size() == 1);

        neo4jStorer.delete(node);
        coll = neo4jStorer.load(new NodeTwoKeyWithNoAuto.Coll(query));
        assertTrue(coll.isEmpty());

        neo4jStorer.delete(node2);
        coll2 = neo4jStorer.load(new NodeTwoKeyWithNoAuto.Coll(query2));
        assertTrue(coll2.isEmpty());
    }

    public void testBatchInsert() throws NSException{

        List<Object> list = new ArrayList<>();
        int count = 10;
        int constvalue = 99999999;

        for(int i = 0; i < count; i ++){
            NodeOneAutoKey.Entity entity = new NodeOneAutoKey.Entity();
            entity.setName(String.format("name%d",i));
            entity.setValue(constvalue);
            list.add(entity);
        }
        neo4jStorer.batchInsert(list);

        NodeOneAutoKey.Query query = new NodeOneAutoKey.Query();
        query.setValue(constvalue);

        neo4jStorer.delete(query,NodeOneAutoKey.Entity.class);

        NodeOneAutoKey.Coll coll = neo4jStorer.load(new NodeOneAutoKey.Coll(query));
        assertEquals(0, coll.size());
    }

//    public void testNodeQuery() throws Exception {
//
//        int constvalue   = 666666;
//        NodeTest.Query clearQuery = new NodeTest.Query();
//        clearQuery.setValue(constvalue);
//        neo4jStorer.delete(clearQuery,NodeTest.Entity.class);
//        NodeTest.Coll nodecoll = neo4jStorer.load(new NodeTest.Coll(clearQuery));
//        assertTrue(nodecoll.size() == 0);
//
//
//        NodeTest.Entity node1 = new NodeTest.Entity();
//        node1.setName("p1");
//        node1.setValue(constvalue);
//        neo4jStorer.insert(node1);
//
//        NodeTest.Entity node2 = new NodeTest.Entity();
//        node2.setName("p2");
//        node1.setValue(constvalue);
//        neo4jStorer.insert(node2);
//
//        NodeTest.Entity node3 = new NodeTest.Entity();
//        node3.setName("p3");
//        node1.setValue(constvalue);
//        neo4jStorer.insert(node3);
//
//        NodeTest.Entity node4 = new NodeTest.Entity();
//        node4.setName("p4");
//        node1.setValue(constvalue);
//        neo4jStorer.insert(node4);
//
//
//        Relation.Entity relation1 = new Relation.Entity();
//        relation1.setA(node1.getId());
//        relation1.setB(node2.getId());
//        relation1.setName("r1");
//        neo4jStorer.insert(relation1);
//
//        Relation.Entity relation2 = new Relation.Entity();
//        relation2.setA(node2.getId());
//        relation2.setB(node3.getId());
//        relation2.setName("r2");
//        neo4jStorer.insert(relation2);
//
//        Relation.Entity relation3 = new Relation.Entity();
//        relation3.setA(node3.getId());
//        relation3.setB(node4.getId());
//        relation3.setName("r3");
//        neo4jStorer.insert(relation3);
//
//        Relation.Entity relation4 = new Relation.Entity();
//        relation4.setA(node1.getId());
//        relation4.setB(node4.getId());
//        relation4.setName("r4");
//        neo4jStorer.insert(relation4);
//
//
//        NodeTest.Query query = new NodeTest.Query();
//        query.setDirection(RelationDirection.both);
//        NodeTest.Coll coll = neo4jStorer.load(new NodeTest.Coll(query));
//        assertTrue(coll.size() >= 4);
//
////        query.setA(node2.getId());
////        query.setDirection(RelationDirection.own);
////        coll = neo4jStorer.load(new NodeTest.Coll(query));
////        assertTrue(coll.size() == 1);
////        assertEquals(coll.get(0).getB(),node3.getId());
////
////        query.setA(node2.getId());
////        query.setDirection(RelationDirection.belongto);
////        coll = neo4jStorer.load(new NodeTest.Coll(query));
////        assertTrue(coll.size() == 1);
////        assertEquals(coll.get(0).getA(),node1.getId());
////
////
////        query.setDirection(RelationDirection.own);
////        query.setMindepth(3);
////        coll = neo4jStorer.load(new NodeTest.Coll(query));
////        assertTrue(coll.size() == 0);
////
////        query.setDirection(RelationDirection.own);
////        query.setMindepth(2);
////        coll = neo4jStorer.load(new NodeTest.Coll(query));
////        assertTrue(coll.size() == 2);
////
////        query.setDirection(RelationDirection.both);
////        query.setMindepth(2);
////        query.setMindepth(3);
////        coll = neo4jStorer.load(new NodeTest.Coll(query));
////        assertTrue(coll.size() == 4);
////
////
////        query.setDirection(RelationDirection.both);
////        query.setMaxdepth(1);
////        query.setMindepth(null);
////        coll = neo4jStorer.load(new NodeTest.Coll(query));
////        assertTrue(coll.size() == 2);
////
////        query.setDirection(RelationDirection.both);
////        query.setMaxdepth(3);
////        query.setMindepth(3);
////        coll = neo4jStorer.load(new NodeTest.Coll(query));
////        assertTrue(coll.size() == 4);
////
////        query.setDirection(RelationDirection.both);
////        query.setMaxdepth(0);
////        query.setMindepth(0);
////        coll = neo4jStorer.load(new NodeTest.Coll(query));
////        assertTrue(coll.size() == 0);
//
//        neo4jStorer.delete(clearQuery,NodeTest.Entity.class);
//        nodecoll = neo4jStorer.load(new NodeTest.Coll(clearQuery));
//        assertTrue(nodecoll.size() == 0);
//    }

    /**
     * match p=(a1)-[*2..]->(b1) return p
     * match p=(a1)-[*2..]->(b1) unwind nodes(p) as n return n
     */
    public void testExec() throws NSException{
        String cql = "match p=(a1)-[*2..]->(b1) unwind nodes(p) as n return n";
        List<Map<String,Object>> list = neo4jStorer.exec(cql);
        assertTrue(list.size() > 0);
    }
}
