package cn.nsoc.neo4j.test.testentity;

import cn.nsoc.common.storer.EntityCollection;
import cn.nsoc.common.storer.EntityQuery;
import cn.nsoc.common.storer.annotation.DbField;
import cn.nsoc.common.storer.annotation.graph.*;

public class Relation {
    @Neo4jObject(name = "Relation", type = Neo4jType.Relation)
    public static  class Entity {
        @DbField(isKey = true)
        private long id;

        @Neo4jRelationField(type= RelationFieldType.from)
        private int a;

        @Neo4jRelationField(type= RelationFieldType.to)
        private int b;

        private String name;

        public long getId() {
            return id;
        }

        public void setId(long id) {
            this.id = id;
        }

        public int getA() {
            return a;
        }

        public void setA(int a) {
            this.a = a;
        }

        public int getB() {
            return b;
        }

        public void setB(int b) {
            this.b = b;
        }

        public String getName() {
            return name;
        }

        public void setName(String name) {
            this.name = name;
        }
    }

    public static class Query extends EntityQuery {
        private Long id;

        public Long getId() {
            return id;
        }

        public void setId(Long id) {
            this.id = id;
        }

        @Neo4jRelationField(type= RelationFieldType.from)
        private Integer a;

        @Neo4jRelationField(type= RelationFieldType.to)
        private Integer b;

        @Neo4jRelationField(type= RelationFieldType.direction)
        private RelationDirection direction;

        @Neo4jRelationField(type= RelationFieldType.mindepth)
        private Integer mindepth;

        @Neo4jRelationField(type= RelationFieldType.maxdepth)
        private Integer maxdepth;

        private String name;

        public Integer getA() {
            return a;
        }

        public void setA(Integer a) {
            this.a = a;
        }

        public Integer getB() {
            return b;
        }

        public void setB(Integer b) {
            this.b = b;
        }

        public String getName() {
            return name;
        }

        public void setName(String name) {
            this.name = name;
        }

        public RelationDirection getDirection() {
            return direction;
        }

        public void setDirection(RelationDirection direction) {
            this.direction = direction;
        }

        public Integer getMindepth() {
            return mindepth;
        }

        public void setMindepth(Integer mindepth) {
            this.mindepth = mindepth;
        }

        public Integer getMaxdepth() {
            return maxdepth;
        }

        public void setMaxdepth(Integer maxdepth) {
            this.maxdepth = maxdepth;
        }
    }

    public static class Coll extends EntityCollection<Entity,Query> {

        public Coll() {
            super(Entity.class, Query.class);
        }

        public Coll(Query query) {
            super(Entity.class, Query.class);
            setQuery(query);
        }
    }
}
