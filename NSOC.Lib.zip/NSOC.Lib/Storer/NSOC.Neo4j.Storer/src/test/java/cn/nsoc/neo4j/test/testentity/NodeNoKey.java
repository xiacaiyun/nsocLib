package cn.nsoc.neo4j.test.testentity;

import cn.nsoc.common.storer.EntityCollection;
import cn.nsoc.common.storer.EntityQuery;
import cn.nsoc.common.storer.annotation.graph.Neo4jObject;

public class NodeNoKey {
    @Neo4jObject(name = "NodeNoKey")
    public static  class Entity {
        private int id;
        private String name;
        private int value;

        public String getName() {
            return name;
        }

        public void setName(String name) {
            this.name = name;
        }

        public int getValue() {
            return value;
        }

        public void setValue(int value) {
            this.value = value;
        }

        public int getId() {
            return id;
        }

        public void setId(int id) {
            this.id = id;
        }
    }

    public static class Query extends EntityQuery {
        private Integer id;

        private String name;

        public String getName() {
            return name;
        }

        public void setName(String name) {
            this.name = name;
        }

        public int getId() {
            return id;
        }

        public void setId(int id) {
            this.id = id;
        }
    }

    public static class Coll extends EntityCollection<Entity,Query> {

        public Coll() {
            super(Entity.class, Query.class);
        }

        public Coll(Query query) {
            super(Entity.class, Query.class);
            setQuery(query);;
        }
    }
}
