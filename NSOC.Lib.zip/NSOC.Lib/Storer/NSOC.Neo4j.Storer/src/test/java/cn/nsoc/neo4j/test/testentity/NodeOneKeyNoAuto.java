package cn.nsoc.neo4j.test.testentity;

import cn.nsoc.common.storer.EntityCollection;
import cn.nsoc.common.storer.EntityQuery;
import cn.nsoc.common.storer.annotation.DbField;
import cn.nsoc.common.storer.annotation.graph.Neo4jObject;

public class NodeOneKeyNoAuto {
    @Neo4jObject(name = "NodeOneKeyNoAuto")
    public static  class Entity {
        @DbField(isKey = true, isAutoIncrement = false)
        private int id;
        private String name;
        private Integer value;

        public String getName() {
            return name;
        }

        public void setName(String name) {
            this.name = name;
        }

        public Integer getValue() {
            return value;
        }

        public void setValue(Integer value) {
            this.value = value;
        }

        public int getId() {
            return id;
        }

        public void setId(int id) {
            this.id = id;
        }
    }

    public static class Query extends EntityQuery {
        private Integer id;

        private String name;

        public String getName() {
            return name;
        }

        public void setName(String name) {
            this.name = name;
        }

        public Integer getId() {
            return id;
        }

        public void setId(Integer id) {
            this.id = id;
        }
    }

    public static class Coll extends EntityCollection<Entity,Query> {

        public Coll() {
            super(Entity.class, Query.class);
        }

        public Coll(Query query) {
            super(Entity.class, Query.class);
            setQuery(query);;
        }
    }
}
