package cn.nsoc.redis.storer.context;

public enum RedisDataType {
    string,
    list,
    set,
    zset,
    hash,
    none;

    public static RedisDataType convert(String val) {
        return Enum.valueOf(RedisDataType.class,val);
    }
}

