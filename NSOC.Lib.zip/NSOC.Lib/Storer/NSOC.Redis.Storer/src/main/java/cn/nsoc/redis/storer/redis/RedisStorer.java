package cn.nsoc.redis.storer.redis;

import cn.nsoc.base.entity.sys.NSException;
import cn.nsoc.common.storer.EntityCollection;
import cn.nsoc.common.storer.EntityQuery;
import cn.nsoc.common.storer.Storer;
import cn.nsoc.common.storer.ValueConverter;
import cn.nsoc.common.storer.context.ContextParser;
import cn.nsoc.common.storer.context.EntityContext;
import cn.nsoc.common.storer.context.EntityProperty;
import cn.nsoc.common.storer.option.InsertBuilder;
import cn.nsoc.common.storer.option.UpdateBuilder;
import cn.nsoc.redis.storer.context.*;
import org.apache.log4j.Logger;
import org.springframework.util.Assert;
import org.springframework.util.StringUtils;
import redis.clients.jedis.*;

import java.io.Closeable;
import java.util.*;
import java.util.stream.Collectors;

/*
*   Redis 命令参考
*   http://doc.redisfans.com/
*/

public class RedisStorer implements Storer {

    private static RedisStorer defaultInstance;
    private static RedisStorer readonlyInstance;
    private static HashMap<String, RedisStorer[]> instanceMap = new HashMap<>();
    private static final Logger logger = Logger.getLogger("RedisStorer");
    private static int timeout = 2000;
    private static int maxAttempt = 5;


    private JedisPool jedisPool = null;
    private JedisCluster jedisCluster = null;
    private ShardedJedisPool  shardedJedisPool = null;
    private RedisValueConverterFactory valueConverterFactory = new RedisValueConverterFactory();
    private ContextParser contextParser;
    private ListOperator listOperator = new ListOperator();
    private String redispassword;

    public enum RedisMode{
        single,
        cluster,
        shard
    }

    public class RedisConnection implements AutoCloseable {

        private JedisCommands cmd;
        private boolean closeable;

        public RedisConnection(JedisCommands cmd,boolean closeable){
                this.cmd = cmd;
                this.closeable = closeable;
        }

        @Override
        public void close() throws Exception {
            if (closeable){
                ((Closeable) getCmd()).close();
                cmd = null;
            }
        }

        public JedisCommands getCmd() {
            return cmd;
        }
    }

    class BaseOperator{
        String getKey(RedisEntityContext entCtx, Object me) throws NSException{
            try {
                EntityProperty propkey = entCtx.getKeyProperty().get(0);
                String sval = toDsValue(propkey.getValueConverter(), propkey.getField().get(me));
                if (!StringUtils.hasText(sval)) {
                    throw new NSException(entCtx.getType().getName() + " Key为空");
                }
                return sval;
            }
            catch (Exception ex){
                throw new NSException(ex);
            }
        }
    }

    public class ListOperator extends BaseOperator{

        /**
         *  posIndex based 0,  element in posIndex will not be deleted
         */
        public boolean deleteAfter(Object me, int posIndex) throws NSException{
            return trim(me, 0, posIndex);
        }

        /**
         *  posIndex based 0,  element in posIndex will not be deleted
         */
        public boolean deleteBefore(Object me, int posIndex) throws NSException{
            return trim(me,  posIndex, -1);
        }
        /**
         *  posIndex based 0,  element before start and after end will also be deleted
         */
        public boolean trim(Object me, int start, int end) throws NSException{
            RedisEntityContext entCtx = (RedisEntityContext) getContextParser().getObjectProperties(me);

            Assert.isTrue(entCtx.getDataType() == RedisDataType.list);

            String sval = getKey(entCtx,me);
            try (RedisConnection jedis = getConn(entCtx.getDbIndex())) {
                jedis.getCmd().ltrim(sval,start,end);
                return true;
            } catch (Exception ex) {
                throw new NSException(ex);
            }
        }
    }


    public static void setHandler(String name, RedisStorer handler) {
        setHandler(name, handler, null);
    }

    public static void setHandler(String name, RedisStorer handler, RedisStorer readonlyhandler) {
        Assert.notNull(handler);
        RedisStorer[] handlers = new RedisStorer[2];
        handlers[0] = handler;
        handlers[1] = (readonlyhandler == null) ? handler : readonlyhandler;
        instanceMap.put(name, handlers);
    }

    public static RedisStorer getInstance(String name) {
        return getInstance(name, false);
    }

    public static RedisStorer getInstance(String name, boolean readonly) {
        RedisStorer[] handlers = instanceMap.get(name);
        Assert.notNull(handlers);

        return handlers[readonly ? 1 : 0];
    }

    public static void setDefaultHandler(RedisStorer handler) {
        setDefaultHandler(handler,handler);
    }

    public static void setDefaultHandler(RedisStorer handler,RedisStorer readonlyhandler) {
        defaultInstance = handler;
        readonlyInstance = readonlyhandler;
    }

    public static RedisStorer getInstance() {
        Assert.notNull(defaultInstance);
        return defaultInstance;
    }

    public static RedisStorer getReadonlyInstance() {
        if (readonlyInstance != null) {
            return readonlyInstance;
        }
        return getInstance();
    }

    public RedisStorer(String hosts, String password,String mode) throws NSException {

        Assert.hasText(mode,"Redis mode parameter must be provided");
        RedisMode m = RedisMode.valueOf(mode);

        initialize(hosts,password,m);
        setContextParser(new RedisContextParser(valueConverterFactory));
    }

    public void initialize(String hosts,String password,RedisMode mode) throws NSException {

        if (!StringUtils.hasText(hosts)) {
            throw new NSException(String.format("failed to initialize redis, host is null "));
        }

        try {
            Set<HostAndPort> nodes = new HashSet<>();
            for (String url : hosts.split(",")) {
                if (StringUtils.hasText(url)) {
                    nodes.add(HostAndPort.parseString(url.trim()));
                }
            }

            if (StringUtils.hasText(password)) {
                redispassword = password;
            }
            JedisPoolConfig config = new JedisPoolConfig();
            switch (mode) {
                case single: {
                    logger.info("init redis with single mode");
                    if (jedisPool == null) {
                        HostAndPort hp = nodes.stream().findFirst().get();
                        jedisPool = new JedisPool(config, hp.getHost(), hp.getPort(), timeout, redispassword);
                    }
                    break;
                }
                case cluster: {
                    logger.info("init redis with cluster mode");
                    jedisCluster = new JedisCluster(nodes, timeout, timeout, maxAttempt, redispassword, config);
                    break;
                }
                case shard: {
                    logger.info("init redis with shard mode");
                    List<JedisShardInfo> infos = nodes.stream().map(p -> {
                        JedisShardInfo jsi = new JedisShardInfo(p.getHost(), p.getPort());
                        jsi.setPassword(redispassword);
                        return jsi;
                    }).collect(Collectors.toList());
                    shardedJedisPool = new ShardedJedisPool(config, infos);
                    break;
                }
                default: {
                    throw new NSException(String.format("unimplemented mode: %s", mode));
                }
            }
        }
        catch (Exception ex){
            throw  new NSException(ex);
        }
    }

    protected void setContextParser(ContextParser contextParser) {
        this.contextParser = contextParser;
    }

    public ListOperator getListOperator() {
        return listOperator;
    }

    protected RedisConnection getConn(int dbIndex) {

        if (jedisPool != null) {
            Jedis jedis = jedisPool.getResource();

            if (dbIndex > 0) {
                jedis.select(dbIndex);
            }
            return new RedisConnection(jedis,true);
        }
        if (jedisCluster != null){
            return new RedisConnection(jedisCluster,false);
        }

        if (shardedJedisPool != null){
            return new RedisConnection(shardedJedisPool.getResource(),false);
        }
        throw new RuntimeException("no no no!");
    }

    private String convertToString(Object o) {
        if (o == null) {
            return null;
        } else {
            return o.toString();
        }
    }


    public void increment(String key, Integer val) throws NSException {
        if (!StringUtils.hasText(key)) {
            return;
        }

        try (RedisConnection jedis = getConn(0)) {
            jedis.getCmd().incrBy(key, val);
        }catch (Exception ex){
            throw new NSException(ex);
        }
    }

    public void increment(String key) throws NSException {
        increment(key, 1);
    }


    @Override
    public boolean insert(Object me) throws NSException {
        return insert(me, null);
    }

    @Override
    public boolean insert(Object me, InsertBuilder builder) throws NSException {


        RedisEntityContext entCtx = (RedisEntityContext) getContextParser().getObjectProperties(me);
        Assert.isTrue(entCtx.getKeyProperty().size() == 1);

        try (RedisConnection jedis = getConn(entCtx.getDbIndex())) {

            EntityProperty keyprop = entCtx.getKeyProperty().get(0);
            String key = convertToString(keyprop.getField().get(me));
            if (!StringUtils.hasText(key)) {
                throw new NSException("key 不能为空");
            }

            if ((entCtx.getDataType() == RedisDataType.hash) && (entCtx.getValProperty() == null)) {
                Map<String, String> values = new HashMap<>();
                for (Map.Entry<String, EntityProperty> kv : entCtx.getProperties().entrySet()) {
                    EntityProperty prop = kv.getValue();
                    values.put(kv.getKey(), toDsValue(prop.getValueConverter(), prop.getField().get(me)));
                }

                jedis.getCmd().hmset(key, values);
                return true;
            }

            EntityProperty valprop = entCtx.getValProperty();

            Object v = valprop.getField().get(me);

            switch (entCtx.getDataType()) {
                case hash: {
                    Map<String, String> vals = new HashMap<>();
                    ValueConverter vc = valprop.getValueConverter();
                    ((Map<String, Object>) v).forEach((key1, value) -> vals.put(key1, toDsValue(vc, value)));
                    jedis.getCmd().hmset(key, vals);
                    break;
                }
                case list: {
                    List<String> vals = new ArrayList<>();
                    ValueConverter vc = valprop.getValueConverter();
                    ((List<Object>) v).forEach(p -> vals.add(toDsValue(vc, p)));
                    jedis.getCmd().rpush(key, vals.toArray(new String[]{}));
                    break;
                }
                case set: {
                    ValueConverter vc = valprop.getValueConverter();
                    List<String> vals = new ArrayList<>();
                    ((Set<Object>) v).forEach(p -> vals.add(toDsValue(vc, p)));
                    jedis.getCmd().sadd(key, vals.toArray(new String[]{}));
                    break;
                }
                case string: {
                    ValueConverter vc = valprop.getValueConverter();
                    jedis.getCmd().set(key, toDsValue(vc, v));
                    break;
                }
                default:
                    break;
            }
            return true;
        } catch (Exception ex) {
            throw new NSException(ex);
        }
    }

    @Override
    public boolean batchInsert(List<Object> melist) throws NSException {
        throw new NSException("NotImplemented");
    }

    @Override
    public boolean batchInsert(List<Object> melist, InsertBuilder builder) throws NSException {
        throw new NSException("NotImplemented");
    }

    @Override
    public boolean delete(Object me) throws NSException {
        RedisEntityContext entCtx = (RedisEntityContext) getContextParser().getObjectProperties(me);

        try (RedisConnection jedis = getConn(entCtx.getDbIndex())) {
            EntityProperty propkey = entCtx.getKeyProperty().get(0);
            String sval = toDsValue(propkey.getValueConverter(), propkey.getField().get(me));
            if (!StringUtils.hasText(sval)) {
                throw new NSException(entCtx.getType().getName() + " Key为空");
            }
            jedis.getCmd().del(sval);
            return true;
        } catch (Exception ex) {
            throw new NSException(ex);
        }
    }

    @Override
    public <Q extends EntityQuery> boolean delete(Q query, Class<?> entityClass) throws NSException {
        throw new NSException("NotImplemented");
//        // 避免用户用错entityClass, 应该entityClass,而不是Query.class
    }

    @Override
    public boolean update(Object me) throws NSException {
        throw new NSException("NotImplemented");
    }

    @Override
    public boolean update(Object me, UpdateBuilder builder) throws NSException {
        throw new NSException("NotImplemented");
    }

    @Override
    public <Q extends EntityQuery> boolean update(Object me, UpdateBuilder builder, Q query) throws NSException {
        throw new NSException("NotImplemented");
    }

    @Override
    public <E, Q extends EntityQuery, C extends EntityCollection<E, Q>> C load(C me) throws NSException {
        return load(me, null);
    }

    @Override
    public <E, Q extends EntityQuery, C extends EntityCollection<E, Q>> C load(C me, String tableName) throws NSException {
        RedisEntityContext entCtx = (RedisEntityContext) getContextParser().getObjectProperties(me.getEntityClass());
        entCtx.setTableName(tableName);
        return load(entCtx, me);
    }

    @Override
    public <E, Q extends EntityQuery, C extends EntityCollection<E, Q>> C load(EntityContext context, C me) throws NSException {
        me.clear();

        RedisEntityContext entCtx = (RedisEntityContext) context;

        Q objQuery = me.getQuery();
        EntityContext qctx = getContextParser().getObjectProperties(objQuery);
        EntityProperty qkeyField = qctx.getKeyProperty().get(0);

        Assert.notNull(qkeyField);


        try (RedisConnection jedis = getConn(entCtx.getDbIndex())) {
            String key = convertToString(qkeyField.getField().get(objQuery));

            RedisDataType datatype = RedisDataType.convert(jedis.getCmd().type(key));
            if (datatype == RedisDataType.none){
                return me;
            }
            Assert.isTrue(datatype == entCtx.getDataType(),
                    String.format("redis key 和实体类型不一致，redis:%s 实体:%s class:%s",
                            datatype,
                            entCtx.getDataType(),
                            entCtx.getTableName()));


            E newentity = me.newEntity();

            EntityProperty keyProp = entCtx.getKeyProperty().get(0);
            keyProp.getField().set(newentity, fromDsValue(keyProp.getValueConverter(), key));

            Map<String, EntityProperty> props = entCtx.getProperties();
            EntityProperty valProp = entCtx.getValProperty();


            switch (entCtx.getDataType()) {
                case string:
                    valProp.getField().set(newentity, fromDsValue(valProp.getValueConverter(), jedis.getCmd().get(key)));
                    me.add(newentity);
                    break;
                case hash:{
                    Map<String,String> vals = jedis.getCmd().hgetAll(key);
                    if (entCtx.getValProperty() == null) {
                        for (Map.Entry<String, String> kv : vals.entrySet()) {
                            EntityProperty prop = props.getOrDefault(kv.getKey(), null);
                            if (prop != null) {
                                prop.getField().set(newentity, fromDsValue(prop.getValueConverter(), kv.getValue()));
                            }
                        }
                        me.add(newentity);
                    }
                    else {
                        Map data = (Map)entCtx.getValProperty().getField().get(newentity);
                        notNull(data,entCtx.getDataType());
                        ValueConverter vc= valProp.getValueConverter();
                        for (Map.Entry<String, String> kv : vals.entrySet()) {
                            data.put(kv.getKey(),fromDsValue(vc,kv.getValue()));
                        }
                        me.add(newentity);
                    }
                    break;
                }
                case list: {
                    List<String> vals = jedis.getCmd().lrange(key, objQuery.start, (objQuery.count == Integer.MAX_VALUE) ? -1 : (objQuery.count - 1));
                    List data = (List) entCtx.getValProperty().getField().get(newentity);
                    notNull(data, entCtx.getDataType());
                    ValueConverter vc = valProp.getValueConverter();
                    for (String k : vals) {
                        data.add(fromDsValue(vc, k));
                    }
                    me.add(newentity);
                    break;
                }
                case set: {
                    Set<String> vals = jedis.getCmd().smembers(key);
                    Set data = (Set) entCtx.getValProperty().getField().get(newentity);
                    notNull(data,entCtx.getDataType());
                    ValueConverter vc= valProp.getValueConverter();
                    for (String k : vals) {
                        data.add(fromDsValue(vc,k));
                    }
                    me.add(newentity);
                    break;
                }
                case zset: {
                    Set<String> vals = jedis.getCmd().zrange(key, 0, -1);
                    Set data = (Set) entCtx.getValProperty().getField().get(newentity);
                    notNull(data,entCtx.getDataType());
                    ValueConverter vc= valProp.getValueConverter();
                    for (String k : vals) {
                        data.add(fromDsValue(vc,k));
                    }
                    me.add(newentity);
                    break;
                }
                default:
                    break;
            }
            return me;
        } catch (Exception ex) {
            throw new NSException(ex);
        }
    }

    private void notNull(Object v, RedisDataType dataType) throws NSException{
        if (v == null){
            throw new NSException(String.format("Redis %s type's field must created by constructor", dataType.name()));
        }
    }

    protected String toDsValue(ValueConverter converter, Object me) {
        Object v = (converter == null) ? me : converter.toDsValue(me);
        return convertToString(v);
    }

    protected Object fromDsValue(ValueConverter converter, Object me) throws NSException {
        return (converter == null) ? me : converter.fromDsValue(me);
    }

    @Override
    public List<Map<String, Object>> exec(String sql) throws NSException {
        throw new NSException("NotImplemented");
    }

    @Override
    public InsertBuilder createInsertBuilder(EntityContext context) {
        return new RedisInsertBuilder((RedisEntityContext) context);
    }

    @Override
    public boolean insertKV(Map<String, Object> me, InsertBuilder builder) throws NSException {
        throw new NSException("NotImplemented");
    }

    @Override
    public ContextParser getContextParser() {
        return this.contextParser;
    }

    @Override
    public void shutdown(){
        if (jedisPool != null) {
            jedisPool.close();
            jedisPool = null;
        }
        if (shardedJedisPool != null){
            shardedJedisPool.close();
            shardedJedisPool = null;
        }
        try {
            if (jedisCluster != null) {
                jedisCluster.close();
                jedisCluster = null;
            }
        }
        catch (Exception ex){
            logger.error(String.format("error to close jedisCluster. %s",ex));
        }
    }
}
