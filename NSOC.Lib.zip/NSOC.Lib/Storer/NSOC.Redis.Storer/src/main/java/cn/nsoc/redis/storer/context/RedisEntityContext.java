package cn.nsoc.redis.storer.context;

import cn.nsoc.common.storer.context.EntityContext;
import cn.nsoc.common.storer.context.EntityProperty;

/**
 * Created by sam on 16-6-22.
 */
public class RedisEntityContext extends EntityContext {
    private RedisDataType dataType;
    private EntityProperty valProperty;
    private int dbIndex;

    public RedisDataType getDataType() {
        return dataType;
    }

    public void setDataType(RedisDataType dataType) {
        this.dataType = dataType;
    }

    public EntityProperty getValProperty() {
        return valProperty;
    }

    public void setValProperty(EntityProperty valProperty) {
        this.valProperty = valProperty;
    }

    public int getDbIndex() {
        return dbIndex;
    }

    public void setDbIndex(int dbIndex) {
        this.dbIndex = dbIndex;
    }
}
