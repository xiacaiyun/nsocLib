package cn.nsoc.redis.storer.context;

import cn.nsoc.base.entity.sys.NSException;
import cn.nsoc.common.storer.ValueConverterFactory;
import cn.nsoc.common.storer.annotation.redis.RedisTable;
import cn.nsoc.common.storer.context.ContextParser;
import cn.nsoc.common.storer.context.EntityContext;
import cn.nsoc.common.storer.context.EntityProperty;

import java.lang.reflect.Field;
import java.util.*;
import java.util.concurrent.locks.ReentrantLock;

/**
 * Created by sam on 17-8-3.
 */
public class RedisContextParser extends ContextParser {

    private final HashMap<Class<?>, RedisEntityContext> typeMap = new HashMap<>();
    private final ReentrantLock mapLock = new ReentrantLock();


    public RedisContextParser(ValueConverterFactory vcfactory){
        super(vcfactory,"");
    }


    @Override
    protected EntityContext parseContext(Class<?> cls) throws NSException {
        RedisEntityContext ctx = (RedisEntityContext) super.parseContext(cls);
        if (ctx.getKeyProperty().size() != 1) {
            throw new NSException("Redis class including entity and query can't must have one and only one key!");
        }

        RedisTable tbl = cls.getAnnotation(RedisTable.class);
        if (tbl != null) {
            ctx.setDbIndex(tbl.dbIndex());
        }

        if (ctx.getProperties().size() - ctx.getKeyProperty().size() > 1){
            ctx.setDataType(RedisDataType.hash);
        }
        else {

            EntityProperty keyprop = ctx.getKeyProperty().get(0);
            for (EntityProperty prop : ctx.getProperties().values()){
                if (prop == keyprop) {
                    continue;
                }

                Field fd = prop.getField();
                Class<?> clsField =  fd.getType();
                if (List.class.isAssignableFrom(clsField)){
                    ctx.setDataType(RedisDataType.list);
                }
                else if (Map.class.isAssignableFrom(clsField)){
                    ctx.setDataType(RedisDataType.hash);
                }
                else if (SortedSet.class.isAssignableFrom(clsField)){
                    //ctx.setDataType(RedisDataType.zset);
                    //todo 暂时不实现
                    ctx.setDataType(RedisDataType.set);
                }
                else if (Set.class.isAssignableFrom(clsField)){
                    ctx.setDataType(RedisDataType.set);
                }
                else {
                    ctx.setDataType(RedisDataType.string);
                }

                Class<?> genericType = getGenericClass(fd);
                prop.setValueConverter(getVcfactory().getValueConverter(genericType));

                ctx.setValProperty(prop);
                break;
            }
        }
        return ctx;
    }

    @Override
    public RedisEntityContext createEntityContext() {
        return new RedisEntityContext();
    }
}
