package cn.nsoc.redis.storer.context;

import cn.nsoc.common.storer.option.InsertBuilder;
import cn.nsoc.common.storer.option.UpdateOperator;
import org.springframework.util.Assert;

public class RedisInsertBuilder implements InsertBuilder<RedisEntityContext> {

    private RedisEntityContext context;

    public RedisInsertBuilder(RedisEntityContext context) {
        Assert.notNull(context);
        this.context = context;
    }



    @Override
    public InsertBuilder append(String field, UpdateOperator operator) {
        return null;
    }

    @Override
    public RedisEntityContext getContext() {
        return context;
    }



}
