package cn.nsoc.redis.storer.context;

import cn.nsoc.base.entity.sys.NSException;
import cn.nsoc.common.storer.ValueConverter;
import cn.nsoc.common.storer.ValueConverterFactory;
import org.springframework.util.Assert;
import org.springframework.util.StringUtils;

import java.math.BigDecimal;
import java.math.BigInteger;
import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Date;
import java.util.UUID;

public class RedisValueConverterFactory extends ValueConverterFactory {

    public RedisValueConverterFactory() {
        converters.put(UUID.class, new RedisUUIDConverter());

        converters.put(Date.class, new RedisDateConverter());
        converters.put(LocalDateTime.class, new RedisLocalDateTimeConverter());

        ValueConverter temp = new RedisIntConverter();
        converters.put(int.class, temp);
        converters.put(Integer.class, temp);

        temp = new RedisLongConverter();
        converters.put(long.class, temp);
        converters.put(Long.class, temp);

        temp = new RedisDoubleConverter();
        converters.put(double.class, temp);
        converters.put(Double.class, temp);

        temp = new RedisBigIntConverter();
        converters.put(BigInteger.class, temp);

        temp = new RedisBoolConverter();
        converters.put(boolean.class,temp);
        converters.put(Boolean.class,temp);

    }


    abstract class BaseStringValueConverter implements ValueConverter{
        @Override
        public Object toDsValue(Object me) {
            return (me == null) ? null : me.toString();
        }

        protected boolean isEmpty(Object me) {
            return me == null || !StringUtils.hasText((String) me);
        }
    }


    public class RedisDateConverter implements ValueConverter {
        @Override
        public Object toDsValue(Object me) {
            return (me == null) ? null : new SimpleDateFormat(STDFORMAT_DATE).format((Date) me);
        }

        @Override
        public Object fromDsValue(Object me) throws NSException {
            try {
                return (me == null) ? null : (new SimpleDateFormat(STDFORMAT_DATE)).parse((String)me);
            } catch (Exception ex) {
                throw new NSException(ex);
            }

        }
    }

    public class RedisLongConverter extends BaseStringValueConverter {

        @Override
        public Object fromDsValue(Object me) {
            if (isEmpty(me)) {
                return null;
            }
            return Long.parseLong((String) me);
        }
    }

    public class RedisDoubleConverter extends BaseStringValueConverter {


        @Override
        public Object fromDsValue(Object me) throws NSException {
            if (isEmpty(me)) {
                return null;
            }
            return new BigDecimal((String)me);
        }
    }

    public class RedisBigIntConverter extends BaseStringValueConverter {

        @Override
        public Object fromDsValue(Object me) {
            if (isEmpty(me)) {
                return null;
            }
            return new BigInteger((String)me);
        }
    }

    public class RedisIntConverter extends BaseStringValueConverter {

        @Override
        public Object fromDsValue(Object me) {
            if (isEmpty(me)) {
                return null;
            }
            return Integer.parseInt((String)me);
        }
    }

    public class RedisUUIDConverter extends BaseStringValueConverter {

        @Override
        public Object fromDsValue(Object me) {
            return (me == null) ? null : UUID.fromString((String) me);
        }
    }

    public class RedisBoolConverter extends BaseStringValueConverter {

        @Override
        public Object fromDsValue(Object me) throws NSException {
            if (isEmpty(me)) {
                return null;
            }
            return Boolean.parseBoolean((String)me);
        }
    }



    public class RedisLocalDateTimeConverter implements ValueConverter {

        private DateTimeFormatter outputformatter;

        public RedisLocalDateTimeConverter(){
            this(DTFMT_STD);
        }

        public RedisLocalDateTimeConverter(DateTimeFormatter outputformatter){
            Assert.notNull(outputformatter);
            this.outputformatter = outputformatter;
        }

        @Override
        public Object toDsValue(Object me) {
            return (me == null) ? null : ((LocalDateTime) me).format(outputformatter);
        }

        @Override
        public Object fromDsValue(Object me) throws NSException {
            if (me == null) {
                return null;
            }

            String dt =(String) me;
            if (dt.length() == 23) {
                return LocalDateTime.parse(dt, DTFMT_ISOLOCALZ);
            } else {
                return LocalDateTime.parse(dt, DTFMT_ISOLOCAL);
            }
        }
    }
}
