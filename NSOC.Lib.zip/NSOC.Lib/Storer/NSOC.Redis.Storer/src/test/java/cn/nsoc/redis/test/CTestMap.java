package cn.nsoc.redis.test;

import cn.nsoc.common.storer.EntityCollection;
import cn.nsoc.common.storer.EntityQuery;
import cn.nsoc.common.storer.annotation.DbField;

import java.util.HashMap;
import java.util.Map;

public class CTestMap {

    public static class Entity {
        @DbField(isKey = true)
        private String id;

        private Map<String,Integer> data = new HashMap<>();

        public String getId() {
            return id;
        }

        public void setId(String id) {
            this.id = id;
        }

        public Map<String, Integer> getData() {
            return data;
        }

        public void setData(Map<String, Integer> data) {
            this.data = data;
        }
    }

    public static class Query extends EntityQuery {
        @DbField(isKey = true)
        private String id;

        public String getId() {
            return id;
        }

        public void setId(String id) {
            this.id = id;
        }
    }

    public static class Coll extends EntityCollection<Entity, Query> {

        public Coll() {
            super(Entity.class, Query.class);
        }

        public Coll(Query query) {
            this();

            setQuery(query);
        }
    }
}