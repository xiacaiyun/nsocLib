package cn.nsoc.redis.test;

import cn.nsoc.common.storer.EntityCollection;
import cn.nsoc.common.storer.EntityQuery;
import cn.nsoc.common.storer.annotation.DbField;

import java.util.ArrayList;
import java.util.List;

public class CTestList {

    public static class Entity {
        @DbField(isKey = true)
        private String id;

        private List<Integer> list = new ArrayList<>();

        public String getId() {
            return id;
        }

        public void setId(String id) {
            this.id = id;
        }

        public List<Integer> getList() {
            return list;
        }

        public void setList(List<Integer> list) {
            this.list = list;
        }
    }

    public static  class Query extends EntityQuery {
        @DbField(isKey = true)
        private String id;

        public String getId() {
            return id;
        }

        public void setId(String id) {
            this.id = id;
        }
    }

    public static  class Coll extends EntityCollection<Entity, Query> {

        public Coll() {
            super(Entity.class, Query.class);
        }

        public Coll(Query query) {
            this();

            setQuery(query);
        }
    }
}
