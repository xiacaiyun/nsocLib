package cn.nsoc.redis.test;

import cn.nsoc.base.entity.sys.NSException;
import cn.nsoc.redis.storer.redis.RedisStorer;
import junit.framework.TestCase;

import java.util.*;

public class RedisTest extends TestCase {
    private RedisStorer storer;

    public void setUp() throws Exception {
        super.setUp();
        storer = new RedisStorer("192.168.1.27:6379","","single");
    }


    // 测试insert
    public void testIUD() throws NSException {
        CTest.Entity data = new CTest.Entity();
        data.setId("1111");

        storer.delete(data);

        data.setTaskName("Name");
        data.setNum("3");
        storer.insert(data);


        CTest.Query query = new CTest.Query();
        query.setId("1111");

        CTest.Coll coll = storer.load(new CTest.Coll(query));
        assertFalse(coll.isEmpty());

        CTest.Entity found = coll.firstOrDefault();
        assertEquals(found.getId(),data.getId());
        assertEquals(found.getTaskName(),data.getTaskName());
        assertEquals(found.getNum(),data.getNum());

        //check insert exists row
        storer.insert(data);

        storer.delete(found);
        storer.load(coll);
        assertTrue(coll.isEmpty());
    }

    public void testList() throws NSException{

        CTestList.Entity data = new CTestList.Entity();
        data.setId("list");

        storer.delete(data);

        List<Integer> list  = new ArrayList<>();
        list.add(333);
        list.add(333444);
        data.setList(list);
        storer.insert(data);


        CTestList.Query query = new CTestList.Query();
        query.setId("list");

        CTestList.Coll coll = storer.load(new CTestList.Coll(query));
        assertFalse(coll.isEmpty());

        CTestList.Entity found = coll.firstOrDefault();
        assertEquals(found.getList().size(),data.getList().size());
        assertEquals(found.getList().get(0),data.getList().get(0));
        assertEquals(found.getList().get(1),data.getList().get(1));


    }


    public void testListDeleteRange() throws NSException{

        CTestList.Entity data = new CTestList.Entity();
        data.setId("listRange");

        storer.delete(data);

        List<Integer> list  = new ArrayList<>();
        list.add(111);
        list.add(222);
        list.add(333);
        list.add(444);
        list.add(555);
        list.add(666);
        data.setList(list);
        storer.insert(data);


        CTestList.Query query = new CTestList.Query();
        query.setId("listRange");

        CTestList.Coll coll = storer.load(new CTestList.Coll(query));
        assertFalse(coll.isEmpty());
        assertEquals(coll.firstOrDefault().getList().size(),list.size());


        int end = 2;

        RedisStorer redisStorer = (RedisStorer)storer;
        redisStorer.getListOperator().deleteAfter(data, end);

        storer.load(coll);
        assertFalse(coll.isEmpty());

        CTestList.Entity found = coll.firstOrDefault();
        assertEquals(found.getList().size(),data.getList().size() - (end + 1));
        assertEquals(found.getList().get(0),data.getList().get(0));
        assertEquals(found.getList().get(1),data.getList().get(1));


        int start = 1;
        redisStorer.getListOperator().deleteBefore(data, start);

        storer.load(coll);
        assertFalse(coll.isEmpty());

        found = coll.firstOrDefault();
        assertEquals(found.getList().size(),data.getList().size() - (end + start + 1));
        assertEquals(found.getList().get(0),data.getList().get(0 + start));
        assertEquals(found.getList().get(1),data.getList().get(1 + start));

        storer.delete(data);
    }



    public void testMap() throws NSException{

        CTestMap.Entity data = new CTestMap.Entity();
        data.setId("map");

        storer.delete(data);

        Map<String,Integer> map  = new HashMap<>();
        map.put("3322",4444);
        map.put("xxxx",222);
        data.setData(map);
        storer.insert(data);


        CTestMap.Query query = new CTestMap.Query();
        query.setId("map");

        CTestMap.Coll coll = storer.load(new CTestMap.Coll(query));
        assertFalse(coll.isEmpty());

        CTestMap.Entity found = coll.firstOrDefault();
        assertEquals(found.getData().size(),data.getData().size());
        assertEquals(found.getData().get("3322"),data.getData().get("3322"));
        assertEquals(found.getData().get("xxxx"),data.getData().get("xxxx"));
    }


    public void testSet() throws NSException{

        CTestSet.Entity data = new CTestSet.Entity();
        data.setId("set");

        storer.delete(data);

        Set<Integer> set  = new HashSet<>();
        set.add(4444);
        set.add(222);
        data.setData(set);
        storer.insert(data);

        CTestSet.Query query = new CTestSet.Query();
        query.setId("set");

        CTestSet.Coll coll = storer.load(new CTestSet.Coll(query));
        assertFalse(coll.isEmpty());

        CTestSet.Entity found = coll.firstOrDefault();
        assertEquals(found.getData().size(),data.getData().size());
        assertTrue(found.getData().contains(4444));
        assertTrue(found.getData().contains(222));
    }

    public void testSortedSet() throws NSException{

        CTestSortedSet.Entity data = new CTestSortedSet.Entity();
        data.setId("zset");

        storer.delete(data);

        TreeSet<Integer> set  = new TreeSet<>();
        set.add(4444);
        set.add(222);
        data.setData(set);
        storer.insert(data);

        CTestSet.Query query = new CTestSet.Query();
        query.setId("set");

        CTestSet.Coll coll = storer.load(new CTestSet.Coll(query));
        assertFalse(coll.isEmpty());

        CTestSet.Entity found = coll.firstOrDefault();
        assertEquals(found.getData().size(),data.getData().size());
        assertTrue(found.getData().contains(4444));
        assertTrue(found.getData().contains(222));
    }


    // 测试insert
    public void testDbIndex() throws NSException {
        CTestDbIndex.Entity data = new CTestDbIndex.Entity();
        data.setId("555");

        storer.delete(data);

        List<Integer> list  = new ArrayList<>();
        list.add(5555555);
        list.add(666666666);
        data.setList(list);
        storer.insert(data);

        CTestDbIndex.Query query = new CTestDbIndex.Query();
        query.setId("555");

        CTestDbIndex.Coll coll = storer.load(new CTestDbIndex.Coll(query));
        assertFalse(coll.isEmpty());

        CTestDbIndex.Entity found = coll.firstOrDefault();
        assertEquals(found.getList().size(),data.getList().size());
        assertEquals(found.getList().get(0),data.getList().get(0));
        assertEquals(found.getList().get(1),data.getList().get(1));

        //check insert exists row
        storer.insert(data);

        storer.delete(found);
        storer.load(coll);
        assertTrue(coll.isEmpty());
    }
}
