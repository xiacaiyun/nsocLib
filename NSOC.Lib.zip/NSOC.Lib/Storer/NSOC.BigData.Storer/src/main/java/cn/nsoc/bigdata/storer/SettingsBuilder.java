package cn.nsoc.bigdata.storer;

import org.springframework.util.StringUtils;

import java.util.HashMap;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Created by bobwang on 3/23/17.
 */
public class SettingsBuilder extends HashMap<String, Object> {

    public SettingsBuilder() {
        super();
    }

    public SettingsBuilder(int capacity) {
        super(capacity);
    }

    public static SettingsBuilder convert(String dictText) {
        SettingsBuilder setBuilder = new SettingsBuilder();
        if (StringUtils.hasText(dictText)) {
            Pattern re = Pattern.compile("(?<key>[^&=]+)=(?<val>[^&]+)");
            Matcher m = re.matcher(dictText);
            while (m.find()) {
                setBuilder.put(m.group("key"), m.group("val"));
            }
        }
        return setBuilder;
    }


    @Override
    public Object get(Object key) {
        if (key instanceof String) {
            return super.get(((String) key).toLowerCase());
        }
        return null;
    }

    @Override
    public Object getOrDefault(Object key, Object defaultValue) {
        if (key instanceof String) {
            return super.getOrDefault(((String) key).toLowerCase(), defaultValue);
        }
        return null;
    }

    @Override
    public boolean containsKey(Object key) {
        return key instanceof String && super.containsKey(((String) key).toLowerCase());
    }

    @Override
    public Object put(String key, Object value) {
        return super.put(key.toLowerCase(), value);
    }

    @Override
    public Object remove(Object key) {
        if (key instanceof String) {
            return super.remove(((String) key).toLowerCase());
        }
        return null;
    }

    @Override
    public Object putIfAbsent(String key, Object value) {
        return super.putIfAbsent(key.toLowerCase(), value);
    }

    @Override
    public boolean remove(Object key, Object value) {
        return key instanceof String && super.remove(((String) key).toLowerCase(), value);
    }


    public String getValAsString(String key, String defVal) {
        Object ret = getOrDefault(key, defVal);
        if (ret != null) {
            return ret.toString().trim();
        }
        return defVal;
    }

    public Integer getValAsInteger(String key, Integer defVal) {
        Object ret = getOrDefault(key, defVal);
        if (ret != null) {
            if (ret instanceof Integer) {
                return (Integer) ret;
            } else {
                return Integer.parseInt(ret.toString().trim());
            }
        }
        return defVal;
    }

    public Boolean getValAsBoolean(String key, Boolean defVal) {
        Object ret = getOrDefault(key, defVal);
        if (ret != null) {
            if (ret instanceof Boolean) {
                return (Boolean) ret;
            } else {
                return Boolean.parseBoolean(ret.toString().trim());
            }
        }
        return defVal;
    }

    public boolean existKey(String key) {
        return containsKey(key);
    }

}
