package cn.nsoc.bigdata.es;

import cn.nsoc.base.entity.sys.NSException;
import cn.nsoc.common.storer.ValueConverterFactory;
import cn.nsoc.common.storer.context.ContextParser;
import cn.nsoc.common.storer.context.EntityContext;
import org.springframework.util.Assert;

/**
 * Created by sam on 17-8-9.
 */
public class ESContextParser extends ContextParser {

    public ESContextParser(){
        this(null);
    }

    public ESContextParser(ValueConverterFactory vcfactory) {
        this(vcfactory,"");
    }


    public ESContextParser(ValueConverterFactory vcfactory, String tblPrefix) {
        super(vcfactory,tblPrefix);
    }


    @Override
    public EntityContext createEntityContext() {
        return new ESEntityContext();
    }

    @Override
    protected EntityContext parseContext(Class<?> cls) throws NSException {
        EntityContext ctx = super.parseContext(cls);
        Assert.isInstanceOf(ESEntityContext.class,ctx);
        Assert.hasText(ctx.getTableName());
        Assert.hasText(((ESEntityContext)ctx).get_type());

        if (ctx.getKeyProperty().size() > 1) {
            throw new NSException("ES class can't have more then one key!");
        }

        return  ctx;
    }
}
