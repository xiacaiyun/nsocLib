package cn.nsoc.bigdata.storer;

import cn.nsoc.base.entity.define.NSExceptionCode;
import cn.nsoc.base.entity.sys.NSException;
import org.apache.hadoop.hbase.TableName;
import org.apache.hadoop.hbase.client.Connection;
import org.apache.hadoop.hbase.client.ConnectionFactory;
import org.apache.hadoop.hbase.client.Table;
import org.apache.log4j.Logger;

import java.io.IOException;

/**
 * Created by bobwang on 4/1/17.
 */
public class HBConnectionPool {

    private Logger                               appLogger;
    private Connection                           clientConn;
    private org.apache.hadoop.conf.Configuration conf;

    public HBConnectionPool(org.apache.hadoop.conf.Configuration conf) {
        appLogger = Logger.getLogger("HBConnectionPool");
        this.conf = conf;
    }

    public void initialize() throws NSException {
        clientConn = fireConnect();
    }

    private Connection fireConnect() throws NSException {
        try {
            return ConnectionFactory.createConnection(conf);
        } catch (IOException exp) {
            appLogger.warn(String.format("create connection exception:%s", exp.getMessage()));
            throw new NSException(NSExceptionCode.Runtime_Error, exp);
        }
    }

    private synchronized void fireClose(Connection conn) {
        try {
            if (clientConn != null && conn.equals(clientConn)) {
                clientConn.close();
            }
        } catch (IOException exp) {
            appLogger.warn(String.format("HBConnectionPool close exception:%s", exp.getMessage()));
        } finally {
            clientConn = null;
        }
    }

    public void shutdown() {
        fireClose(clientConn);
    }

    public Table get(String tableName) throws NSException {
        try {
            if (clientConn == null) {
                throw new NSException(NSExceptionCode.Com_Create_Object, String.format("create %s . connection is null", tableName));
            }
            return clientConn.getTable(TableName.valueOf(tableName));
        } catch (IOException ex) {
            throw new NSException(ex);
        }
    }

    public void release(Table tb) {
        try {
            tb.close();
        } catch (IOException exp) {
            appLogger.warn(String.format("HBConnectionPool release exception:%s", exp.getMessage()));
        }
    }
}