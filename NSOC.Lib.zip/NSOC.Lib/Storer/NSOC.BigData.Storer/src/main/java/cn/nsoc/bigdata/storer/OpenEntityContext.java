package cn.nsoc.bigdata.storer;

import cn.nsoc.common.storer.context.EntityContext;

/**
 * Created by sam on 17-8-3.
 */
public class OpenEntityContext extends EntityContext {


    public OpenEntityContext() {
    }

    public OpenEntityContext(String tablename) {
        setTableName(tablename);
    }


}
