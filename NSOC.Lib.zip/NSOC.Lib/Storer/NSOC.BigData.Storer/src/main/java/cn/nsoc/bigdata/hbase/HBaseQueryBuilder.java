package cn.nsoc.bigdata.hbase;

import cn.nsoc.common.storer.option.QueryBuilder;
import org.apache.hadoop.hbase.util.Bytes;

/**
 * Created by bobwang on 10/25/17.
 */
public class HBaseQueryBuilder extends QueryBuilder {
    private byte[] family;
    private String tableName;
    private int rowCount = 100;
    private String rowkeyText;

    public HBaseQueryBuilder(String tableName,String fm,String rowKey) {
        setFamily(fm);
        this.tableName = tableName;
        rowkeyText = rowKey;
    }

    public String getTableName() {
        return tableName;
    }

    public byte[] getFamily() {
        return family;
    }

    public String getKeyText(){
        return rowkeyText;
    }

    public void setFamily(String fm) {
        this.family = Bytes.toBytes(fm);
    }

    public void setRowCount(int newVal){
        rowCount = newVal;
    }

    public int getRowCount(){
        return rowCount;
    }
}

