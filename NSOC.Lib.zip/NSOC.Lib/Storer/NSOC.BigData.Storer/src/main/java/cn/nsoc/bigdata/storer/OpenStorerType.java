package cn.nsoc.bigdata.storer;

/**
 * Created by bobwang on 3/23/17.
 */
public enum OpenStorerType {
    HBASE,

    ELASTICSEARCH,
}
