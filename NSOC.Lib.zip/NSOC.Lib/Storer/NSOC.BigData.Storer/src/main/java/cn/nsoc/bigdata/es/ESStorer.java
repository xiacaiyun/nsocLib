package cn.nsoc.bigdata.es;

import cn.nsoc.base.entity.container.NSDataMap;
import cn.nsoc.base.entity.define.NSExceptionCode;
import cn.nsoc.base.entity.sys.NSException;
import cn.nsoc.base.entity.tuple.Tuple2;
import cn.nsoc.bigdata.storer.BigDataItem;
import cn.nsoc.bigdata.storer.OpenStorer;
import cn.nsoc.bigdata.storer.SettingsBuilder;
import cn.nsoc.common.storer.EntityCollection;
import cn.nsoc.common.storer.EntityQuery;
import cn.nsoc.common.storer.ValueConverter;
import cn.nsoc.common.storer.annotation.DbField;
import cn.nsoc.common.storer.annotation.DbQuery;
import cn.nsoc.common.storer.annotation.QueryOperator;
import cn.nsoc.common.storer.context.EntityContext;
import cn.nsoc.common.storer.context.EntityProperty;
import cn.nsoc.common.storer.option.InsertBuilder;
import com.google.common.primitives.Ints;
import org.apache.commons.lang3.StringUtils;
import org.apache.log4j.Logger;
import org.elasticsearch.action.DocWriteResponse;
import org.elasticsearch.action.bulk.*;
import org.elasticsearch.action.index.IndexRequest;
import org.elasticsearch.action.index.IndexResponse;
import org.elasticsearch.action.search.SearchRequestBuilder;
import org.elasticsearch.action.search.SearchResponse;
import org.elasticsearch.action.search.SearchType;
import org.elasticsearch.client.transport.TransportClient;
import org.elasticsearch.common.settings.ClusterSettings;
import org.elasticsearch.common.settings.Setting;
import org.elasticsearch.common.settings.Settings;
import org.elasticsearch.common.transport.InetSocketTransportAddress;
import org.elasticsearch.index.query.BoolQueryBuilder;
import org.elasticsearch.index.query.QueryBuilder;
import org.elasticsearch.index.query.QueryBuilders;
import org.elasticsearch.search.SearchHit;
import org.elasticsearch.search.SearchHits;
import org.elasticsearch.search.aggregations.Aggregation;
import org.elasticsearch.search.aggregations.AggregationBuilders;
import org.elasticsearch.search.aggregations.Aggregations;
import org.elasticsearch.search.aggregations.bucket.terms.LongTerms;
import org.elasticsearch.search.aggregations.bucket.terms.TermsAggregationBuilder;
import org.elasticsearch.search.sort.SortOrder;
import org.elasticsearch.transport.client.PreBuiltTransportClient;
import org.springframework.util.Assert;

import java.lang.reflect.Field;
import java.net.InetAddress;
import java.util.*;
import java.util.stream.Collectors;

/**
 * Created by bobwang on 3/23/17.
 */
public class ESStorer extends OpenStorer {

    private static final Logger logger = Logger.getLogger("ElasticSearch");
    private TransportClient tpClient;
    private static final int DEFAULT_TRANSPORT_PORT = 9300;
    private static final int MAX_OUTPUT_RECORDS = 10000;
    private String tblPrefix = "";


    public ESStorer() {
        super(ESStorer.class);

        setContextParser(new ESContextParser(new ESValueConverterFactory(), getTblPrefix()));
    }

    @Override
    public void initialize(SettingsBuilder cfg) throws NSException {
        tpClient = initClient(cfg);
    }


    @Override
    public void shutdown() {
        if (tpClient != null) {
            tpClient.close();
            tpClient = null;
        }
    }

    private TransportClient initClient(SettingsBuilder params) throws NSException {

        boolean bSniff = false;
        Settings.Builder builder = Settings.builder();
        List<Tuple2<InetAddress, Integer>> addressLst = new ArrayList<>();
        Set<String> clientDefaultKeys = clientDefaultKeys();
        params.forEach((k,v)->{
            switch (k.toLowerCase()){
                case "host":
                    break;
                default:
                    if(clientDefaultKeys.contains(k)) {
                        builder.put(k, v);
                    } else {
                        logger.warn(String.format("Check you settings key: %s undefined.", k));
                    }
                    break;
            }
        });


        String paramHost = params.getValAsString("Host", null);
        if (StringUtils.isNoneBlank(paramHost)) {
            InetAddress inetAddress;
            for (String address : paramHost.split(",")) {
                String[] config = address.split(":");
                String host = config[0];
                if (StringUtils.isEmpty(host)) {
                    throw new NSException("host is empty");
                }
                try {
                    inetAddress = InetAddress.getByName(host);
                } catch (Exception ex) {
                    throw new NSException(String.format("bad host name :%s", address));
                }

                Integer gotPort = null;
                if (config.length > 1) {
                    gotPort = Ints.tryParse(config[1]);
                }
                if (gotPort == null || gotPort == 0) {
                    gotPort = DEFAULT_TRANSPORT_PORT;
                }
                addressLst.add(new Tuple2<>(inetAddress, gotPort));
            }
        }
        if (addressLst.isEmpty() && !bSniff) {
            throw new NSException("no address available");
        }

        TransportClient transClient = new PreBuiltTransportClient(builder.build());
        for (Tuple2<InetAddress, Integer> address : addressLst) {
            transClient.addTransportAddress(new InetSocketTransportAddress(address.getA(), address.getB()));
        }
        return transClient;
    }


    //ES 默认给10条数据,count = 10
    @Override
    public <E, Q extends EntityQuery, C extends EntityCollection<E,Q>> C load(C me, String tableName) throws NSException {

        me.clear();

        EntityContext entCtx = getContextParser().getObjectProperties(me.getEntityClass());
        BoolQueryBuilder queryBuilder = QueryBuilders.boolQuery();
        String indexes = StringUtils.isNotBlank(tableName) ? tableName : entCtx.getTableName();

        SearchRequestBuilder requestBuilder = tpClient.prepareSearch(indexes);
        requestBuilder.setSearchType(SearchType.QUERY_THEN_FETCH);

        Q objQuery = me.getQuery();

        buildQuery(queryBuilder, objQuery);

        if (objQuery.orderBy != null) {

            // _id 不能用来排序，_uid可以，不过 _uid = _type#_id,  所以 _uid 也不用作排序
            enumToSql(objQuery.orderBy).forEach(p -> {
                String[] opers = p.split(" ");

                SortOrder sortorder = SortOrder.ASC;
                if ((opers.length > 1) && "desc".equalsIgnoreCase(opers[1])) {
                    sortorder = SortOrder.DESC;
                }
                requestBuilder.addSort( opers[0], sortorder);
            });
        }


        //requestBuilder.setFetchSource("eq",null);
        requestBuilder.setQuery(queryBuilder);
        requestBuilder.setFrom(objQuery.start);
        requestBuilder.setSize(Math.min(objQuery.count,MAX_OUTPUT_RECORDS));


        if (objQuery.groupBy != null) {

            TermsAggregationBuilder termsbuilder = null;

            for(String aggfield : enumToSql(objQuery.groupBy)){
                if (termsbuilder == null){
                    termsbuilder = AggregationBuilders.terms(aggfield).field(aggfield);
                }
                else{
                    termsbuilder.subAggregation(AggregationBuilders.terms(aggfield).field(aggfield));
                }
            }
            requestBuilder.addAggregation(termsbuilder);
        }

        if (logger.isTraceEnabled()){
            logger.trace(requestBuilder.toString());
        }
        SearchResponse esResponse = requestBuilder.get();


        SearchHits hits = esResponse.getHits();
        for (SearchHit sHit : hits) {
            me.add(loadEntityData(me.newEntity(), sHit.getId(), sHit.getSource(), entCtx));
        }


        Aggregations aggs = esResponse.getAggregations();
        if (aggs != null) {
            me.setAgg(loadaggdata(aggs));
        }
        objQuery.totalCount = hits.getTotalHits();
        return me;
    }


    private Map<String,Object> loadaggdata(Aggregations aggs){
        Map<String,Object> map = new HashMap<>();
        if (aggs == null) {
            return map;
        }

        for(Aggregation agg: aggs){

            List<Map<Object,Object>> groups = new ArrayList<>();
            LongTerms longTerms = (LongTerms) agg;
            for (LongTerms.Bucket b : longTerms.getBuckets()) {
                Map<Object,Object> submap = new HashMap<>();
                Map<String,Object> submap2 = loadaggdata(b.getAggregations());
                if (!submap2.isEmpty() ) {
                    submap.put("groups",submap2);
                }
                submap.put("key",b.getKey());
                submap.put("value",b.getDocCount());
                groups.add(submap);
            }
            map.put(longTerms.getName(),groups);
        }
        return map;
    }


    /**
     * Get transport default keys
     * @return Set<String> keys
     */
    private Set<String> clientDefaultKeys() {
        Set<Setting<?>> settingSet = ClusterSettings.BUILT_IN_CLUSTER_SETTINGS;
        Set<String> clientDefaultKey = new HashSet<>();
        for (Setting<?> aSetting : settingSet) {
            String key = aSetting.getKey();
            clientDefaultKey.add(key);
        }

        return clientDefaultKey;
    }

    @Override
    public InsertBuilder createInsertBuilder(EntityContext context) {
        Assert.isInstanceOf(ESEntityContext.class,context);
        return new ESInsertBuilder((ESEntityContext) context);
    }

    @Override
    public boolean batchInsert(List<Object> melist, InsertBuilder builder) throws NSException {
        if(melist.isEmpty()) {
           return true;
        }

        BulkRequestBuilder requestBuilder = tpClient.prepareBulk();
        ESEntityContext context = (ESEntityContext)builder.getContext();
        String index = context.getTableName();
        String type = context.get_type();
        for (Object me : melist) {
            if (!(me instanceof BigDataItem)) {
                throw new NSException("wrong parameter: melist");
            }

            BigDataItem item = (BigDataItem) me;

            IndexRequest request;
            if(item.getId() == null) {
                 request = new IndexRequest()
                        .index(index)
                        .type(type)
                        .source(item.getFields());
            } else {
                //Changed sync insert
                 request = new IndexRequest()
                        .index(index)
                        .type(type)
                        .id(item.getId().toString())
                        .source(item.getFields());
            }


            requestBuilder.add(request);
        }

        //Sync insert
        BulkResponse responses = requestBuilder.execute().actionGet();

        logger.debug(String.format("Insert %s, count %d, time consuming %sms, current time %sms.",
                index, melist.size(),  responses.getTookInMillis(), System.currentTimeMillis()));
        if(responses.hasFailures()) {
            logger.error(String.format("BatchInsert error. ErrorCode: %s \n Message: %s", NSExceptionCode.ES_EXEC_FAILED, responses.hasFailures()));
            throw new NSException(NSExceptionCode.ES_EXEC_FAILED ,responses.buildFailureMessage());
        }

        return true;
    }



    @Override
    public boolean insert(Object me) throws NSException {
        EntityContext ctx = getContextParser().getObjectProperties(me);
        Assert.isTrue(ctx.getKeyProperty().size() == 1);


        Map<String, Object> values = new HashMap<>();
        String id = null;

        try {
            for (EntityProperty prop : ctx.getProperties().values()) {
                DbField dbFd = prop.getDbField();
                if (dbFd != null) {
                    if (!dbFd.isRequired()) {
                        continue;
                    }
                    if (dbFd.isKey()) {
                        Object v = prop.getField().get(me);
                        if (v != null) {
                            id = v.toString();
                        }
                    }
                }
                values.put(prop.getFieldName(), prop.getField().get(me));
            }

            if (StringUtils.isBlank(id)) {
                throw new NSException("key 不能为空");
            }
            IndexResponse response = tpClient.prepareIndex(ctx.getTableName(), ctx.getTableName(), id)
                    .setSource(values)
                    .get();


            DocWriteResponse.Result ret = response.getResult();
            return (ret == DocWriteResponse.Result.CREATED
                    || ret == DocWriteResponse.Result.UPDATED);
        } catch (Exception ex) {
            throw new NSException(ex);
        }
    }

    @Override
    public boolean insert(Map<String, Object> fields, String id, InsertBuilder builder) throws NSException {
        return insert(new BigDataItem(fields, id), builder);
    }

    @Override
    public boolean insert(Object me, InsertBuilder builder) throws NSException {
        if (me instanceof BigDataItem) {
            BigDataItem item = (BigDataItem) me;

            Assert.notNull(item.getId());

            ESEntityContext context = (ESEntityContext)builder.getContext();

            tpClient.prepareIndex(context.getTableName(),
                                   context.get_type(),
                                    item.getId().toString())
                    .setSource(item.getFields())
                    .get();

            return true;
        } else {
            throw new NSException("Wrong parameter: me");
        }
    }

    private <Q extends EntityQuery> void buildQuery(BoolQueryBuilder queryBuilder, Q objQuery)
            throws NSException {
        try {

            EntityContext qctx = getContextParser().getObjectProperties(objQuery);
            for (EntityProperty prop : qctx.getProperties().values()) {
                Field fd = prop.getField();

                Object objV = fd.get(objQuery);
                if (objV == null) {
                    continue;
                }

                Object objVal = toDsValue(prop.getValueConverter(),objV);

                DbQuery dbQuery = prop.getDbQuery();
                DbField dbField = prop.getDbField();
                QueryOperator queryOperator = (dbQuery == null) ? QueryOperator.Equal : dbQuery.Operator();

                String fieldname = prop.getFieldName();

                switch (queryOperator) {
                    case Equal:
                        queryBuilder.must(QueryBuilders.termQuery(fieldname, objVal));
                        break;
                    case GreatEqual:
                        queryBuilder.must(QueryBuilders.rangeQuery(getContextParser().trimQueryFlag(queryOperator,fieldname)).gte(objVal));
                        break;
                    case GreatThan:
                        queryBuilder.must(QueryBuilders.rangeQuery(getContextParser().trimQueryFlag(queryOperator,fieldname)).gt(objVal));
                        break;
                    case LessEqual:
                        queryBuilder.must(QueryBuilders.rangeQuery(getContextParser().trimQueryFlag(queryOperator,fieldname)).lte(objVal));
                        break;
                    case LessThan:
                        queryBuilder.must(QueryBuilders.rangeQuery(getContextParser().trimQueryFlag(queryOperator,fieldname)).lt(objVal));
                        break;
                    case IsOrNotNull: {
                            QueryBuilder qb = QueryBuilders.existsQuery(getContextParser().trimQueryFlag(queryOperator, fieldname));
                            if (objVal instanceof Boolean) {
                                if ((Boolean) objVal) {
                                    queryBuilder.must(qb);
                                } else {
                                    queryBuilder.mustNot(qb);
                                }
                            }
                            break;
                        }
                    case Like:
                        queryBuilder.must(QueryBuilders.matchQuery(fieldname, objVal));
                        break;
                    case In: {
                            if (!(objVal instanceof List<?>)) {
                                throw new NSException("Wrong fieldname Type, it must bu List<?>");
                            }
                            queryBuilder.must(QueryBuilders.termsQuery(getContextParser().trimQueryFlag(queryOperator,fieldname),(List)objVal));
                        }
                        break;
                    default:
                        break;
                }
            }
        } catch (Exception ex) {
            throw new NSException(ex);
        }
    }

    protected Object toDsValue(ValueConverter converter, Object me) {
        if (converter == null) {
            return me;
        }
        else {
            return converter.toDsValue(me);
        }
    }

    protected Object fromDsValue(ValueConverter converter, Object me) throws NSException {
        if (converter == null) {
            return me;
        }
        else {
            return converter.fromDsValue(me);
        }
    }

    protected <E> E loadEntityData(E me, String id, Map<String, Object> resultMap, EntityContext ectx) throws NSException {
        Assert.notNull(ectx.getType());

        try {

            Map<String, EntityProperty> map = ectx.getProperties();
            HashMap<EntityProperty, Boolean> level = new HashMap<>();//复合属性
            List<String> cols = new ArrayList<>();//所有的colname

            if (NSDataMap.class.isAssignableFrom(ectx.getType())){
                NSDataMap nsDataMap = (NSDataMap)me;
                for (Map.Entry<String, Object> kv : resultMap.entrySet()) {
                    nsDataMap.put(kv.getKey(),kv.getValue());
                }
            }
            else {
                for (Map.Entry<String, Object> kv : resultMap.entrySet()) {
                    String colname = kv.getKey();
                    cols.add(colname);
                    EntityProperty prop = map.getOrDefault(colname, null);
                    if (prop == null) {
                        if (colname.contains(".")) {
                            level.put(map.get(colname.substring(0, colname.indexOf('.'))), false);
                        }
                    } else {
                        Field fd = prop.getField();
                        Object v = kv.getValue();
                        if (v != null) {
                            fd.set(me, fromDsValue(prop.getValueConverter(), v));
                        }
                    }
                }

                for (Map.Entry<EntityProperty, Boolean> entry : level.entrySet()) {
                    EntityProperty k = entry.getKey();
                    Field fd = k.getField();
                    List<String> sub = cols.stream()
                            .filter(c -> c.contains(".") && k.getFieldName().equals(c.substring(0, c.indexOf('.'))))
                            .collect(Collectors.toList());
                    Class<?> cls = k.getField().getType();
                    fd.set(me, fd.getType().newInstance());
                    loadSubEntityData(fd.get(me), resultMap, getContextParser().getObjectProperties(cls), sub);
                }
            }
            return me;
        } catch (Exception ex) {
            throw new NSException(ex);
        }
    }

    private void loadSubEntityData(Object me, Map<String, Object> resultmap, EntityContext objectProperties, List<String> sub) throws NSException {

        try {
            Map<String, EntityProperty> map = objectProperties.getProperties();
            for (String colname : sub) {
                EntityProperty prop = map.get(colname.replaceFirst("(\\S+)\\.", ""));
                Field fd = prop.getField();
                Object v = resultmap.getOrDefault(colname, null);
                if (v == null) {
                    continue;
                }
                fd.set(me, fromDsValue(prop.getValueConverter(), v));
            }
        } catch (Exception ex) {
            throw new NSException(ex);
        }
    }

    public String getTblPrefix() {
        return tblPrefix;
    }

    public void setTblPrefix(String tblPrefix) {
        this.tblPrefix = tblPrefix;
    }

}
