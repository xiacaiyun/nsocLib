package cn.nsoc.bigdata.connector;

import cn.nsoc.base.entity.sys.NSException;
import cn.nsoc.common.storer.IDataConnector;

/**
 * Created by bobwang on 9/23/16.
 */
public abstract class ConnectorFactory implements IDataConnector {

    public ConnectorFactory() {
    }

    public static IDataConnector createInstance(IDataConnector.AccessType type) throws NSException {
        if (type.equals(AccessType.HDFS)) {
            return new HDFSConnector();
        }
        throw new NSException(String.format("type %s is not supported", type.name()));
    }

    @Override
    public String getData(String path) throws NSException {
        return null;
    }

    @Override
    public boolean exists(String path) {
        return false;
    }
}
