package cn.nsoc.bigdata.connector;

import cn.nsoc.base.entity.sys.NSException;
import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.FSDataInputStream;
import org.apache.hadoop.fs.FileSystem;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.IOUtils;

import java.io.ByteArrayOutputStream;
import java.net.URI;

/**
 * Created by bobwang on 9/23/16.
 */
public class HDFSConnector extends ConnectorFactory {

    public HDFSConnector() {
        super();
    }

    @Override
    public String getData(String uri) throws NSException {
        Configuration conf = new Configuration();
        String target;
        FSDataInputStream in = null;
        try (FileSystem fs = FileSystem.get(new URI(uri), conf)) {


            in = fs.open(new Path(uri));
            ByteArrayOutputStream output = new ByteArrayOutputStream();
            IOUtils.copyBytes(in, output, 4096, false);
            target = output.toString();

            return target;
        } catch (Exception exp) {
            throw new NSException(exp);
        } finally {
            if (in != null) {
                IOUtils.closeStream(in);
            }

        }
    }
}
