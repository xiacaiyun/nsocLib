package cn.nsoc.bigdata.es;

import cn.nsoc.common.storer.option.InsertBuilder;
import cn.nsoc.common.storer.option.UpdateOperator;
import org.springframework.util.Assert;

/**
 * Created by bobwang on 3/24/17.
 */
public class ESInsertBuilder implements InsertBuilder<ESEntityContext> {

    private ESEntityContext context;

    public ESInsertBuilder(ESEntityContext context) {
        Assert.notNull(context);
        this.context = context;
    }

    @Override
    public InsertBuilder append(String field, UpdateOperator operator) {
        return null;
    }

    @Override
    public ESEntityContext getContext() {
        return context;
    }

}
