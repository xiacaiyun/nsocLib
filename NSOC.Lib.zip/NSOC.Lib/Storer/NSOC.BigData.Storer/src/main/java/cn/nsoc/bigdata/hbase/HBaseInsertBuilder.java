package cn.nsoc.bigdata.hbase;

import cn.nsoc.common.storer.context.EntityContext;
import cn.nsoc.common.storer.option.InsertBuilder;
import cn.nsoc.common.storer.option.InsertOption;
import cn.nsoc.common.storer.option.UpdateOperator;
import org.springframework.util.Assert;

/**
 * Created by sam on 17-8-3.
 */
public class HBaseInsertBuilder implements InsertBuilder<EntityContext> {

    private EntityContext context;
    private String        family;
    private String        tableName;

    public HBaseInsertBuilder(EntityContext context) {
        Assert.notNull(context);
        this.context = context;
    }

    @Override
    public InsertOption getInsertOption() {
        return null;
    }

    @Override
    public void setInsertOption(InsertOption option) {

    }

    @Override
    public InsertBuilder append(String field, UpdateOperator operator) {
        return null;
    }

    @Override
    public EntityContext getContext() {
        return context;
    }

    public String getTableName() {
        // context is null means map mode, otherwise it is entity mode
        return (context == null) ? this.tableName : context.getTableName();
    }

    public String getFamily() {
        return family;
    }

    public void setFamily(String fm) {
        this.family = fm;
    }
}
