package cn.nsoc.bigdata.hbase;

import cn.nsoc.base.entity.define.NSExceptionCode;
import cn.nsoc.base.entity.sys.NSException;
import cn.nsoc.bigdata.storer.*;
import cn.nsoc.common.storer.EntityCollection;
import cn.nsoc.common.storer.EntityQuery;
import cn.nsoc.common.storer.annotation.DbQuery;
import cn.nsoc.common.storer.annotation.QueryOperator;
import cn.nsoc.common.storer.context.ContextParser;
import cn.nsoc.common.storer.context.EntityContext;
import cn.nsoc.common.storer.context.EntityProperty;
import cn.nsoc.common.storer.option.InsertBuilder;
import cn.nsoc.common.storer.option.QueryBuilder;
import com.google.common.base.Optional;
import org.apache.commons.lang3.StringUtils;
import org.apache.hadoop.hbase.HBaseConfiguration;
import org.apache.hadoop.hbase.client.*;
import org.apache.hadoop.hbase.filter.*;
import org.apache.hadoop.hbase.util.Bytes;
import org.dom4j.Attribute;
import org.dom4j.tree.DefaultElement;

import java.lang.reflect.Field;
import java.math.BigDecimal;
import java.math.BigInteger;
import java.sql.Timestamp;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.ZoneId;
import java.util.*;

/**
 * Created by bobwang on 9/20/16.
 */
public class HBaseStorer extends OpenStorer {
    private static final String CFG_ADDRESS            = "hbase.zookeeper.quorum";
    private static final String CFG_PORT               = "hbase.zookeeper.property.clientPort";
    private static final String CFG_RETRIES_NUMBER     = "hbase.client.retries.number";
    private static final String CFG_AUTHENTICATION     = "hbase.security.authentication";
    private static final String CFG_RPC_ENGINE         = "hbase.rpc.engine";
    private static final String MSG_HBASE_MISMATCH     = "HBase mapping mismatch:%s";
    private static final long   CONNECTION_EXPIRED_MIN = 15L;
    private static final int    INSTANCE_CAPACITY_DEF  = 5;


    private HBConnectionPool hbConnectionPool;

    private OpenValueConverterFactory valueConverterFactory = new OpenValueConverterFactory();
    private String                    tblPrefix             = "";

    public HBaseStorer() {
        super(HBaseStorer.class);

        setContextParser(new ContextParser(valueConverterFactory, getTblPrefix()));
    }

    @Override
    public InsertBuilder createInsertBuilder(EntityContext context) {
        return new HBaseInsertBuilder(context);
    }

    @Override
    public void initialize(SettingsBuilder cfg) throws NSException {

        org.apache.hadoop.conf.Configuration conf = HBaseConfiguration.create();

        conf.set(CFG_ADDRESS, cfg.getValAsString(HBaseConfigDef.ADDRESS, ""));
        conf.set(CFG_PORT, cfg.getValAsString(HBaseConfigDef.PORT, ""));

        if (cfg.existKey(HBaseConfigDef.RETRIES_NUM)) {
            String target = cfg.getValAsString(HBaseConfigDef.RETRIES_NUM, "");
            if (target.length() > 0) {
                conf.set(CFG_RETRIES_NUMBER, target);
            }
        }
        if (cfg.existKey(HBaseConfigDef.AUTHENTICATION)) {
            String target = cfg.getValAsString(HBaseConfigDef.AUTHENTICATION, "");
            if (target.length() > 0) {
                conf.set(CFG_AUTHENTICATION, target);
            }
        }
        if (cfg.existKey(HBaseConfigDef.CHANNEL_RPC)) {
            String target = cfg.getValAsString(HBaseConfigDef.CHANNEL_RPC, "");
            if (target.length() > 0) {
                conf.set(CFG_RPC_ENGINE, target);
            }
        }
        hbConnectionPool = new HBConnectionPool(conf);
        hbConnectionPool.initialize();
    }

    @Override
    public void shutdown() {
        if (hbConnectionPool != null) {
            hbConnectionPool.shutdown();
        }
    }

    public List<Map<String, Object>> prefixFilter(Object cond, IValueTransform<byte[], Object> transform, QueryBuilder builder) throws NSException {
        Table                        tb        = null;
        ResultScanner                scanner   = null;
        byte[]                       lastRowID = null;
        byte[]                       fm;
        Result                       result;
        int                          nRowSum   = 0;
        int                          nRowCount = 10;
        Object                       objFetch  = null;
        HBaseQueryBuilder            qb        = (HBaseQueryBuilder) builder;
        Scan                         userScan  = new Scan();
        Map<String, Object>          valMap    = null;
        List<Map<String, Object>>    rows      = new ArrayList<>();
        NavigableMap<byte[], byte[]> fds       = null;

        userScan.addFamily(qb.getFamily());
        Filter prefixFL = new PrefixFilter(convertObject2Bytes(cond));
        userScan.setFilter(prefixFL);
        userScan.setCaching(qb.getRowCount());

        try {
            tb = hbConnectionPool.get(qb.getTableName().toLowerCase());
            scanner = tb.getScanner(userScan);
            do {
                result = scanner.next();
                if (result == null) {
                    break;
                }

                fds = result.getFamilyMap(qb.getFamily());
                if (fds != null) {
                    valMap = new HashMap<>();
                    objFetch = transform.call(qb.getKeyText(), result.getRow());
                    if (objFetch != null) {
                        valMap.put(qb.getKeyText(), objFetch);
                    }
                    for (NavigableMap.Entry<byte[], byte[]> fd : fds.entrySet()) {
                        String fdID = Bytes.toString(fd.getKey());
                        objFetch = transform.call(fdID, fd.getValue());
                        if (objFetch != null) {
                            valMap.put(fdID, objFetch);
                        }
                    }
                    if (valMap.isEmpty() == false) {
                        rows.add(valMap);
                    }
                }
                nRowSum++;
            }
            while (nRowSum < qb.getRowCount());

        } catch (Exception exp) {
            throw new NSException(exp);
        } finally {
            if (scanner != null) {
                scanner.close();
            }
            if (tb != null) {
                try {
                    hbConnectionPool.release(tb);
                } catch (Exception ex) {
                    appLogger.warn(ex.getMessage());
                    ignoreException(ex);
                }
            }
        }
        return rows;
    }

    @Override
    public boolean batchInsert(List<Object> melist, InsertBuilder builder) throws NSException {
        List<Put>          puts = new ArrayList<>();
        HBaseInsertBuilder ib   = (HBaseInsertBuilder) builder;
        for (Object me : melist) {
            if (!(me instanceof BigDataItem)) {
                throw new NSException("wrong parameter: melist");
            }
            BigDataItem item = (BigDataItem) me;
            puts.add(createSinglePut(ib.getFamily(), item.getId().toString(), item.getFields()));
        }

        Table tb = null;
        try {
            tb = hbConnectionPool.get(ib.getTableName().toLowerCase());
            tb.put(puts);
        } catch (Exception exp) {
            throw new NSException(exp);
        } finally {
            if (tb != null) {
                try {
                    hbConnectionPool.release(tb);
                } catch (Exception ex) {
                    appLogger.warn(ex.getMessage());
                    ignoreException(ex);
                }
            }
        }
        return true;
    }

//    boolean isRowKeyEmpty(byte[] vals) {
//        for (byte val : vals) {
//            if (val > 0) {builder
//                return false;
//            }
//        }
//        return true;
//    }


    @Override
    public <E, Q extends EntityQuery, C extends EntityCollection<E, Q>> C load(C me, String tableName) throws
            NSException {
        throw new NSException(NSExceptionCode.Com_Not_Implemented, "this methed is not implemented");
//        me.clear();
//
//        EntityContext entCtx     = getContextParser().parseContext(me.getEntityClass());
//        Q objQuery = me.getQuery();
//        if (objQuery.orderBy != null) {
//            appLogger.warn(String.format("orderBy %s is not supported in hbase now", objQuery.orderBy));
//        }
//
//        if (objQuery.groupBy != null) {
//            appLogger.warn(String.format("groupby %s is not supported in hbase now", objQuery.groupBy));
//        }
//
//        Table tb = null;
//        try {
//            tb = hbConnectionPool.get(tableName);
//            Scan userScan = new Scan();
//            userScan.addFamily(rowKeyDesc.getColFamilyBytes());
//            byte[] startRow = rowKeyDesc.createKeyBuffer().getResult();
//            byte[] startRowDesc = rowKeyDesc.createKeyBuffer(1).getResult();
//            byte[] stopRow = rowKeyDesc.createKeyBuffer().getResult();
//            byte[] stopRowDesc = rowKeyDesc.createKeyBuffer(1).getResult();
//            FilterList filterLst = new FilterList(FilterList.Operator.MUST_PASS_ALL);
//            buildQuery(rowKeyDesc, startRow, startRowDesc, stopRow, stopRowDesc, filterLst, objQuery);
//
//            if (StringUtils.isNoneBlank(objQuery.nextRow)) {
//                filterLst.addFilter(new RowFilter(CompareFilter.CompareOp.GREATER, new BinaryComparator(Bytes.toBytesBinary(objQuery.nextRow))));
//            }
//
//            if (objQuery.count != Integer.MAX_VALUE) {
//                filterLst.addFilter(new PageFilter(objQuery.count));
//            }
//
//            FuzzyRowFilter rowFilter;
//            rowFilter = new FuzzyRowFilter(Collections.singletonList(new Pair<>(startRow, startRowDesc)));
//
//            filterLst.addFilter(rowFilter);
//            userScan.setFilter(filterLst);
//
//            ResultScanner scanner = null;
//            int nRowSum = 0;
//            objQuery.nextRow = null;
//            try {
//                scanner = tb.getScanner(userScan);
//                Result result;
//                byte[] lastRowID = null;
//                do {
//                    result = scanner.next();
//                    if (result == null) {
//                        break;
//                    }
//                    me.add(loadEntityData(me.newEntity(), result, rowKeyDesc, entCtx));
//                    // save last row id
//                    lastRowID = result.getRow();
//                    nRowSum++;
//                } while (nRowSum < objQuery.count);
//
//                if (lastRowID != null) {
//                    objQuery.nextRow = Bytes.toStringBinary(lastRowID);
//                }
//            } finally {
//                if (scanner != null) {
//                    scanner.close();
//                }
//            }
//        } catch (Exception exp) {
//            throw new NSException(exp);
//        } finally {
//            if (tb != null) {
//                try {
//                    hbConnectionPool.release(tb);
//                } catch (Exception ex) {
//                    appLogger.warn(ex.getMessage());
//                    ignoreException(ex);
//                }
//            }
//        }
//        return me;
    }


    @Override
    public boolean insertKV(Map<String, Object> me, InsertBuilder builder) throws NSException {
        return insertSingleRow(me, ((HBaseInsertBuilder) builder).getTableName());
    }

    @Override
    public boolean insert(Object me) throws NSException {
        EntityContext       entCtx   = getContextParser().getObjectProperties(me);
        Map<String, Object> hashVals = convertEntity(entCtx, me);
        return insertSingleRow(hashVals, entCtx.getTableName());
    }

    @Override
    public boolean batchInsert(List<Object> melist) throws NSException {
        throw new NSException(NSExceptionCode.Com_Not_Implemented, "this methed is not implemented");
//        EntityContext entCtx     = getContextParser().parseContext(melist.get(0).getClass());
//        RowKeyDesc    rowKeyDesc = rowKeyMapping.getOrDefault(entCtx.getTableName(), null);
//        if (rowKeyDesc == null) {
//            throw new NSException(String.format(MSG_HBASE_MISMATCH, entCtx.getTableName()));
//        }
//        List<Put> puts = new ArrayList<>();
//        for (Object me : melist) {
//            puts.add(createSinglePut(rowKeyDesc, convertEntity(entCtx, me)));
//        }
//
//        Table tb = null;
//        try {
//            tb = hbConnectionPool.getAvailableInstance(rowKeyDesc.getTableName());
//            tb.put(puts);
//        } catch (Exception exp) {
//            throw new NSException(exp);
//        } finally {
//            if (tb != null) {
//                try {
//                    hbConnectionPool.pushOne(rowKeyDesc.getTableName(), tb);
//                } catch (Exception ex) {
//                    appLogger.warn(ex.getMessage());
//                    ignoreException(ex);
//                }
//            }
//        }
//        return true;
    }

    private void fillBytesFixVal(int setVal, byte[] dst, int of, int size) {
        for (int nItemIndex = 0; nItemIndex < size; nItemIndex++) {
            dst[of + nItemIndex] = (byte) setVal;
        }
    }

    private void fillBytes(Object objVal, byte[] dst, int of, int size) throws NSException {
        byte[] src = convertObject2Bytes(objVal);
        if (size > src.length) {
            System.arraycopy(src, 0, dst, of + size - src.length, src.length);
        } else {
            System.arraycopy(src, src.length - size, dst, of, size);
        }
    }

    private <Q extends EntityQuery> void buildQuery(RowKeyDesc rowKeyDesc
            , byte[] startRow
            , byte[] startRowDesc
            , byte[] stopRow
            , byte[] stopRowDesc
            , FilterList filterLst
            , Q objQuery) throws NSException {

        EntityContext qctx = getContextParser().getObjectProperties(objQuery);

        try {
            for (EntityProperty prop : qctx.getProperties().values()) {
                Field fd = prop.getField();
                DbQuery dbQuery = prop.getDbQuery();
                Object objVal = fd.get(objQuery);
                if (objVal == null) {
                    continue;
                }
                QueryOperator queryOperator = (dbQuery == null) ? QueryOperator.Equal : dbQuery.Operator();

                RowKeyDesc.FieldMapping fdMapping;
                String targetFD;
                switch (queryOperator) {
                    case Equal:
                        // startRow stopRow SingleColumnValueFilter
                        fdMapping = rowKeyDesc.queryByEntityName(prop.getFieldName());
                        targetFD = StringUtils.isNoneBlank(fdMapping.getKeyID()) ? fdMapping.getKeyID() : prop.getFieldName();

                        if (fdMapping.getByteSize() > 0) {
                            fillBytes(objVal, startRow, fdMapping.getOffset(), fdMapping.getByteSize());
                            fillBytesFixVal(0, startRowDesc, fdMapping.getOffset(), fdMapping.getByteSize());
                            fillBytes(objVal, stopRow, fdMapping.getOffset(), fdMapping.getByteSize());
                            fillBytesFixVal(0, stopRowDesc, fdMapping.getOffset(), fdMapping.getByteSize());
                        } else {
                            filterLst.addFilter(new SingleColumnValueFilter(rowKeyDesc.getColFamilyBytes()
                                    , Bytes.toBytes(targetFD)
                                    , CompareFilter.CompareOp.EQUAL
                                    , convertObject2Bytes(objVal)));
                        }
                        break;
                    case GreatEqual:
                        // startRow SingleColumnValueFilter
                        fdMapping = rowKeyDesc.queryByEntityName(getContextParser().trimQueryFlag(queryOperator, prop.getFieldName()));
                        targetFD = StringUtils.isNoneBlank(fdMapping.getKeyID()) ? fdMapping.getKeyID() : prop.getFieldName();
                        if (fdMapping.getByteSize() > 0) {
                            fillBytes(objVal, startRow, fdMapping.getOffset(), fdMapping.getByteSize());
                            fillBytesFixVal(0, startRowDesc, fdMapping.getOffset(), fdMapping.getByteSize());
                        } else {
                            filterLst.addFilter(new SingleColumnValueFilter(rowKeyDesc.getColFamilyBytes()
                                    , Bytes.toBytes(targetFD)
                                    , CompareFilter.CompareOp.GREATER_OR_EQUAL
                                    , convertObject2Bytes(objVal)));
                        }
                        break;
                    case GreatThan:
                        // SingleColumnValueFilter
                        fdMapping = rowKeyDesc.queryByEntityName(getContextParser().trimQueryFlag(queryOperator, prop.getFieldName()));
                        targetFD = StringUtils.isNoneBlank(fdMapping.getKeyID()) ? fdMapping.getKeyID() : prop.getFieldName();
                        filterLst.addFilter(new SingleColumnValueFilter(rowKeyDesc.getColFamilyBytes()
                                , Bytes.toBytes(targetFD)
                                , CompareFilter.CompareOp.GREATER
                                , convertObject2Bytes(objVal)));
                        break;
                    case LessEqual:
                        // stopRow SingleColumnValueFilter
                        fdMapping = rowKeyDesc.queryByEntityName(getContextParser().trimQueryFlag(queryOperator, prop.getFieldName()));
                        targetFD = StringUtils.isNoneBlank(fdMapping.getKeyID()) ? fdMapping.getKeyID() : prop.getFieldName();
                        if (fdMapping.getByteSize() > 0) {
                            fillBytes(objVal, stopRow, fdMapping.getOffset(), fdMapping.getByteSize());
                            fillBytesFixVal(0, stopRowDesc, fdMapping.getOffset(), fdMapping.getByteSize());
                        } else {
                            filterLst.addFilter(new SingleColumnValueFilter(rowKeyDesc.getColFamilyBytes()
                                    , Bytes.toBytes(targetFD)
                                    , CompareFilter.CompareOp.LESS_OR_EQUAL
                                    , convertObject2Bytes(objVal)));
                        }
                        break;
                    case LessThan:
                        // SingleColumnValueFilter
                        fdMapping = rowKeyDesc.queryByEntityName(getContextParser().trimQueryFlag(queryOperator, prop.getFieldName()));
                        targetFD = StringUtils.isNoneBlank(fdMapping.getKeyID()) ? fdMapping.getKeyID() : prop.getFieldName();
                        filterLst.addFilter(new SingleColumnValueFilter(rowKeyDesc.getColFamilyBytes()
                                , Bytes.toBytes(targetFD)
                                , CompareFilter.CompareOp.LESS
                                , convertObject2Bytes(objVal)));
                        break;
                    case Like:
                        // SingleColumnValueFilter substringcomparator
                        fdMapping = rowKeyDesc.queryByEntityName(prop.getFieldName());
                        targetFD = StringUtils.isNoneBlank(fdMapping.getKeyID()) ? fdMapping.getKeyID() : prop.getFieldName();
                        filterLst.addFilter(new SingleColumnValueFilter(rowKeyDesc.getColFamilyBytes()
                                , Bytes.toBytes(targetFD)
                                , CompareFilter.CompareOp.LESS_OR_EQUAL
                                , new SubstringComparator(objVal.toString())));
                        break;
                    default:
                        break;
                }
            }
        } catch (Exception ex) {
            throw new NSException(ex);
        }

    }

    protected <E> E loadEntityData(E me, Result resultVal, RowKeyDesc rowKeyDesc, EntityContext ectx) throws
            NSException {
        NavigableMap<byte[], byte[]> fds = resultVal.getFamilyMap(rowKeyDesc.getColFamilyBytes());
        if (fds != null) {
            for (NavigableMap.Entry<byte[], byte[]> fd : fds.entrySet()) {
                String fdID = Bytes.toString(fd.getKey());
                String mappingName = rowKeyDesc.queryByID(fdID).getMemberName();
                String fID = StringUtils.isNoneBlank(mappingName) ? mappingName : fdID;
                EntityProperty property = ectx.getProperties().getOrDefault(fID, null);
                if (property != null) {
                    try {
                        Field objFD = property.getField();
                        if (objFD.getType().isAssignableFrom(Integer.class)) {
                            objFD.set(me, Bytes.toInt(fd.getValue()));
                        } else if (objFD.getType().isAssignableFrom(String.class)) {
                            objFD.set(me, Bytes.toString(fd.getValue()));
                        } else if (objFD.getType().isAssignableFrom(Long.class)) {
                            objFD.set(me, Bytes.toLong(fd.getValue()));
                        } else if (objFD.getType().isAssignableFrom(Double.class)) {
                            objFD.set(me, Bytes.toDouble(fd.getValue()));
                        } else if (objFD.getType().isAssignableFrom(BigInteger.class)) {
                            objFD.set(me, new BigInteger(fd.getValue()));
                        } else if (objFD.getType().isAssignableFrom(LocalDateTime.class)) {
                            Long dtl = Bytes.toLong(fd.getValue());
                            objFD.set(me, new Timestamp(dtl).toLocalDateTime().atZone(ZoneId.systemDefault()).toLocalDateTime());
                        } else if (objFD.getType().isAssignableFrom(Boolean.class)) {
                            objFD.set(me, Bytes.toBoolean(fd.getValue()));
                        } else {
                            throw new NSException(String.format("field %s can not  deserial type %s", fID, objFD.getType().getName()));
                        }
                    } catch (Exception ex) {
                        throw new NSException(ex);
                    }
                }
            }
        }
        return me;
    }

    private boolean insertSingleRow(Map<String, Object> me, String tableName) throws NSException {
        throw new NSException(NSExceptionCode.Com_Not_Implemented, "this methed is not implemented");
//        RowKeyDesc rowKeyDesc = rowKeyMapping.getOrDefault(tableName, null);
//        if (rowKeyDesc == null) {
//            throw new NSException(String.format(MSG_HBASE_MISMATCH, tableName));
//        }
//
//        Put   row = createSinglePut(rowKeyDesc, me);
//        Table tb  = null;
//        try {
//            tb = hbConnectionPool.get(rowKeyDesc.getTableName());
//            tb.put(row);
//        } catch (Exception exp) {
//            throw new NSException(exp);
//        } finally {
//            if (tb != null) {
//                try {
//                    hbConnectionPool.release(tb);
//                } catch (Exception exp) {
//                    ignoreException(exp);
//                    appLogger.warn(exp.getMessage());
//                }
//            }
//        }
//        return true;
    }

    private void ignoreException(Exception ex) {
        // for sonar
    }

    private Put createSinglePut(String fm, String rowKey, Map<String, Object> me) throws NSException {
        Put    row    = new Put(Bytes.toBytes(rowKey));
        byte[] family = Bytes.toBytes(fm);
        for (Map.Entry<String, Object> objIter : me.entrySet()) {
            row.addColumn(family, Bytes.toBytes(objIter.getKey()), convertObject2Bytes(objIter.getValue()));
        }
        return row;
    }

    private Map<String, Object> convertEntity(EntityContext entCtx, Object me) throws NSException {
        Map<String, Object> hashVals = new HashMap<>();

        try {
            for (HashMap.Entry<String, EntityProperty> iterProp : entCtx.getProperties().entrySet()) {
                Field fd = iterProp.getValue().getField();
                Object objVal = fd.get(me);
                if (objVal == null) {
                    continue;
                }
                hashVals.put(iterProp.getKey(), objVal);
            }
            return hashVals;
        } catch (Exception ex) {
            throw new NSException(ex);
        }
    }

    private byte[] convertObject2Bytes(Object objVal) throws NSException {
        if (objVal instanceof String) {
            return Bytes.toBytes((String) objVal);
        } else if (objVal instanceof Integer) {
            return Bytes.toBytes((Integer) objVal);
        } else if (objVal instanceof Boolean) {
            return Bytes.toBytes((Boolean) objVal);
        } else if (objVal instanceof Long) {
            return Bytes.toBytes((Long) objVal);
        } else if (objVal instanceof Float) {
            return Bytes.toBytes((Float) objVal);
        } else if (objVal instanceof Double) {
            return Bytes.toBytes((Double) objVal);
        } else if (objVal instanceof Short) {
            return Bytes.toBytes((Short) objVal);
        } else if (objVal instanceof BigDecimal) {
            return Bytes.toBytes((BigDecimal) objVal);
        } else if (objVal instanceof BigInteger) {
            return ((BigInteger) objVal).toByteArray();
        } else if (objVal instanceof LocalDateTime) {
            return Bytes.toBytes(Timestamp.valueOf((LocalDateTime) objVal).getTime());
        } else if (objVal instanceof LocalDate) {
            return Bytes.toBytes(Timestamp.valueOf(LocalDateTime.of((LocalDate) objVal, LocalTime.MIDNIGHT)).getTime());
        } else if (objVal instanceof LocalTime) {
            return Bytes.toBytes(Timestamp.valueOf(LocalDateTime.of(LocalDate.MIN, (LocalTime) objVal)).getTime());
        } else {
            throw new NSException(String.format("HBase wrong param mapping:%s", objVal.getClass().getSimpleName()));
        }
    }

    private Optional<String> getAttributeText(DefaultElement element, String text) {
        Attribute attr = element.attribute(text);
        if (attr != null) {
            String attrVal = attr.getValue().trim();
            if (!StringUtils.isEmpty(attrVal)) {
                return Optional.of(attrVal);
            }
        }
        return Optional.absent();
    }

//    private void loadRowKeySetting(Connection conn, String config) throws NSException {
//
//        int       rowBytes = 0;
//        SAXReader reader   = new SAXReader();
//        Document  document;
//        try {
//            document = reader.read(new ByteArrayInputStream(config.getBytes("UTF-8")));
//        } catch (Exception ex) {
//            throw new NSException(ex);
//        }
//
//        if (document == null) {
//            throw new NSException("loadRowKeySetting: document is null");
//        }
//
//        List<Node> instances = document.selectNodes("mapping//table");
//        if (instances.isEmpty()) {
//            throw new NSException("rowkey wrong format:row key mapping");
//        }
//
//        int rowIndex = 0;
//        for (Node eleRow : instances) {
//            DefaultElement eleInst = (DefaultElement) eleRow;
//
//            String tableName = getAttributeText(eleInst, "name").orNull();
//            if (StringUtils.isEmpty(tableName)) {
//                throw new NSException(String.format("rowkey %d wrong format:name", rowIndex));
//            }
//
//            String colFamily = getAttributeText(eleInst, "colfamily").orNull();
//            if (StringUtils.isEmpty(colFamily)) {
//                throw new NSException(String.format("rowkey %d wrong format:colfamily", rowIndex));
//            }
//
//            String entityName = getAttributeText(eleInst, "entity").orNull();
//            if (StringUtils.isEmpty(entityName)) {
//                throw new NSException(String.format("rowkey %d wrong format:entity", rowIndex));
//            }
//
//            List<Node> fds = eleInst.selectNodes("field");
//            if (fds.isEmpty()) {
//                throw new NSException(String.format("rowkey %d wrong format:no field", rowIndex));
//            } else {
//
//                List<RowKeyDesc.FieldMapping> keyMappings = new ArrayList<>();
//                RowKeyDesc rowKeyDesc = new RowKeyDesc(tableName, entityName, Bytes.toBytes(colFamily));
//
//                for (Node fd : fds) {
//                    DefaultElement eleFD = (DefaultElement) fd;
//
//                    String keyID = getAttributeText(eleFD, "id").orNull();
//                    if (StringUtils.isEmpty(keyID)) {
//                        throw new NSException(String.format("rowkey %d wrong format:id", rowIndex));
//                    }
//
//                    String memberName = getAttributeText(eleFD, "name").orNull();
//                    if (StringUtils.isEmpty(keyID)) {
//                        throw new NSException(String.format("rowkey %d wrong format:name", rowIndex));
//                    }
//
//
//                    int offset = 0;
//                    Attribute fdAttr = eleFD.attribute("offset");
//                    if (fdAttr != nullString
//                            && !StringUtils.isEmpty(fdAttr.getValue())) {
//                        Integer of = Ints.tryParse(fdAttr.getValue());
//                        if (of == null) {
//                            throw new NSException(String.format("rowkey %d wrong format: offset %s", rowIndex, fdAttr.getValue()));
//                        }
//                        offset = of;
//                    }
//                    if (offset == 0) {
//                        offset = rowBytes;
//                    }
//
//                    int byteSize = 0;
//                    fdAttr = eleFD.attribute("size");
//                    if (fdAttr != null
//                            && !StringUtils.isEmpty(fdAttr.getValue())) {
//                        Integer of = Ints.tryParse(fdAttr.getValue());
//                        if (of == null) {
//                            throw new NSException(String.format("rowkey %d  wrong format: size %s", rowIndex, fdAttr.getValue()));
//                        }
//                        byteSize = of;
//                    }
//
//                    boolean optimize = false;
//                    fdAttr = eleFD.attribute("optimize");
//                    if (fdAttr != null) {
//                        if (fdAttr.getValue().compareToIgnoreCase("true") == 0) {
//                            optimize = true;
//                        } else if (fdAttr.getValue().compareToIgnoreCase("false") == 0) {
//                            optimize = false;
//                        }
//                    }
//                    keyMappings.add(rowKeyDesc.addFieldMapping(keyID, memberName, offset, byteSize, optimize));
//                    rowBytes += byteSize;
//                }
//                for (RowKeyDesc.FieldMapping fdMapping : keyMappings) {
//                    if (fdMapping.getByteSize() + fdMapping.getOffset() > rowBytes) {
//                        throw new NSException(String.format("rowkey  wrong format: offset too big %s", fdMapping.getKeyID()));
//                    }
//                }
//                if (rowKeyMapping.putIfAbsent(rowKeyDesc.getEntityName(), rowKeyDesc) != null) {
//                    throw new NSException(String.format("rowkey  wrong format: member duplicate %s", rowKeyDesc.getEntityName()));
//                }
//            }
//            rowIndex++;
//        }
//    }

    public String getTblPrefix() {
        return tblPrefix;
    }

    public void setTblPrefix(String tblPrefix) {
        this.tblPrefix = tblPrefix;
    }
}
