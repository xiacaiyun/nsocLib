package cn.nsoc.bigdata.storer;

import java.util.Map;

/**
 * Created by sam on 17-7-27.
 */
public class BigDataItem {
    private Map<String, Object> fields;
    private Object id;


    public BigDataItem(Map<String, Object> fields, Object id) {
        setFields(fields);
        setId(id);
    }

    public Map<String, Object> getFields() {
        return fields;
    }

    public void setFields(Map<String, Object> fields) {
        this.fields = fields;
    }

    public Object getId() {
        return id;
    }

    public void setId(Object id) {
        this.id = id;
    }
}
