package cn.nsoc.bigdata.es;

import cn.nsoc.bigdata.storer.OpenValueConverterFactory;
import cn.nsoc.common.storer.ValueConverter;

import java.time.LocalDateTime;

/**
 * Created by sam on 17-8-4.
 */
public class ESValueConverterFactory extends OpenValueConverterFactory {

    public ESValueConverterFactory() {
        ValueConverter temp = new LongConverter(true);
        converters.put(long.class, temp);
        converters.put(Long.class, temp);

        temp = new StringConverter();
        converters.put(String.class,temp);


        converters.put(LocalDateTime.class, new LocalDateTimeConverter(DTFMT_ISOLOCAL));
    }
}
