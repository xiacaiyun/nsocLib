package cn.nsoc.bigdata.storer;

/**
 * Created by sam on 17-8-3.
 */
public class BigDataContext {
    private String tablename;

    public String getTablename() {
        return tablename;
    }


    public BigDataContext(String tablename) {
        this.tablename = tablename;
    }
}
