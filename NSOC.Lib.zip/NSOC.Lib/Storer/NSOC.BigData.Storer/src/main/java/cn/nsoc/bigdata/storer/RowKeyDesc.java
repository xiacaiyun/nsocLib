package cn.nsoc.bigdata.storer;

import cn.nsoc.base.entity.sys.NSException;
import org.apache.hadoop.hbase.util.Bytes;

import java.math.BigInteger;
import java.sql.Timestamp;
import java.time.LocalDateTime;
import java.util.HashMap;
import java.util.Map;

/**
 * Created by bobwang on 3/30/17.
 */
public class RowKeyDesc {


    public class RowKeyBuffer {

        private byte[] buffer;

        private RowKeyBuffer(int bytes) {
            buffer = new byte[bytes];
        }

        private RowKeyBuffer(int bytes, int initVal) {
            this(bytes);
            for (int nItemIndex = 0; nItemIndex < bytes; nItemIndex++) {
                buffer[nItemIndex] = (byte) initVal;
            }
        }

        public final byte[] getResult() {
            return buffer;
        }

        public void copyBuf(int of, int byteSize, byte[] newVal) {
            System.arraycopy(newVal, 0, buffer, of + byteSize - newVal.length, newVal.length);
        }

        public void copyBuf(int of, int byteSize, Boolean newVal) {
            byte[] target = Bytes.toBytes(newVal);
            System.arraycopy(target, 0, buffer, of + byteSize - target.length, target.length);
        }

        public void copyBuf(int of, int byteSize, Float newVal) {
            byte[] target = Bytes.toBytes(newVal);
            System.arraycopy(target, 0, buffer, of + byteSize - target.length, target.length);
        }

        public void copyBuf(int of, int byteSize, Double newVal) {
            byte[] target = Bytes.toBytes(newVal);
            System.arraycopy(target, 0, buffer, of + byteSize - target.length, target.length);
        }


        public void copyBuf(int of, int byteSize, Integer newVal) {
            byte[] target = Bytes.toBytes(newVal);
            System.arraycopy(target, 4 - byteSize, buffer, of, byteSize);
        }

        public void copyBuf(int of, int byteSize, Long newVal) {
            byte[] target = Bytes.toBytes(newVal);
            System.arraycopy(target, 8 - byteSize, buffer, of, byteSize);
        }

        public void copyBuf(int of, int byteSize, Short newVal) {
            byte[] target = Bytes.toBytes(newVal);
            System.arraycopy(target, 2 - byteSize, buffer, of, byteSize);
        }

        public void copyBuf(int of, int byteSize, String newVal) {
            byte[] target = Bytes.toBytes(newVal);
            System.arraycopy(target, 0, buffer, of, target.length);
        }
    }

    public class FieldMapping {
        private String keyID;
        private String memberName;
        private int offset;
        private int byteSize;
        private boolean opt;

        public FieldMapping(String id, String memName, int of, int bytes, boolean optimize) {
            keyID = id;
            memberName = memName;
            offset = of;
            byteSize = bytes;
            opt = optimize;
        }

        public int getOffset() {
            return offset;
        }

        public int getByteSize() {
            return byteSize;
        }

        public String getKeyID() {
            return keyID;
        }

        public String getMemberName() {
            return memberName;
        }

        public boolean isOptimize() {
            return opt;
        }
    }

    private int maxBytes;
    private String entityName;
    private String tableName;
    private byte[] colFamilyBytes;
    private Map<String, FieldMapping> fieldMappingMap;
    private Map<String, FieldMapping> entityMappingMap;
    private FieldMapping defaultFDMapping;

    public RowKeyDesc(String tbName, String entity, byte[] cf) {
        tableName = tbName;
        entityName = entity;
        colFamilyBytes = cf;
        maxBytes = 0;
        fieldMappingMap = new HashMap<>();
        entityMappingMap = new HashMap<>();
        defaultFDMapping = new FieldMapping(null, null, 0, 0, false);
    }

    public void close() {
        // do nothing
    }

    public FieldMapping addFieldMapping(String id, String memName, int of, int bytes, boolean optimize) throws NSException {
        if (fieldMappingMap.containsKey(id)) {
            throw new NSException(String.format("duplicate id:%s", id));
        }
        FieldMapping newInst = new FieldMapping(id, memName, of, bytes, optimize);
        fieldMappingMap.put(id, newInst);
        entityMappingMap.put(memName, newInst);
        maxBytes += bytes;
        return newInst;
    }

    public FieldMapping queryByID(String id) {
        return fieldMappingMap.getOrDefault(id, defaultFDMapping);
    }


    public FieldMapping queryByEntityName(String memName) {
        return entityMappingMap.getOrDefault(memName, defaultFDMapping);
    }

    public String getTableName() {
        return tableName;
    }

    public String getEntityName() {
        return entityName;
    }

    public String getShortName(String orgName) {
        FieldMapping fdMapping = entityMappingMap.getOrDefault(orgName, null);
        if (fdMapping == null) {
            return orgName;
        } else {
            return fdMapping.getKeyID();
        }
    }

    public RowKeyBuffer createKeyBuffer() {
        return new RowKeyBuffer(maxBytes);
    }

    public RowKeyBuffer createKeyBuffer(int initVal) {
        return new RowKeyBuffer(maxBytes, initVal);
    }


    public RowKeyBuffer createKeyBuffer(Map<String, Object> objDict) throws NSException {
        RowKeyBuffer rkBuf = createKeyBuffer();
        for (Map.Entry<String, FieldMapping> iter : fieldMappingMap.entrySet()) {
            FieldMapping fdMapping = iter.getValue();
            if (fdMapping.getByteSize() == 0) {
                continue;
            }
            Object objVal = objDict.getOrDefault(iter.getValue().getMemberName(), null);
            if (objVal == null) {
                continue;
            }
            fillBuffer(rkBuf, objVal, fdMapping);
        }
        return rkBuf;
    }


    public byte[] getColFamilyBytes() {
        return colFamilyBytes;
    }

    private void fillBuffer(RowKeyBuffer rkBuf, Object objVal, FieldMapping fdMapping) throws NSException {
        if (objVal instanceof String) {
            rkBuf.copyBuf(fdMapping.getOffset(), fdMapping.getByteSize(), (String) objVal);
        } else if (objVal instanceof Integer) {
            rkBuf.copyBuf(fdMapping.getOffset(), fdMapping.getByteSize(), (Integer) objVal);
        } else if (objVal instanceof Boolean) {
            rkBuf.copyBuf(fdMapping.getOffset(), fdMapping.getByteSize(), (Boolean) objVal);
        } else if (objVal instanceof Long) {
            rkBuf.copyBuf(fdMapping.getOffset(), fdMapping.getByteSize(), (Long) objVal);
        } else if (objVal instanceof Float) {
            rkBuf.copyBuf(fdMapping.getOffset(), fdMapping.getByteSize(), (Float) objVal);
        } else if (objVal instanceof Double) {
            rkBuf.copyBuf(fdMapping.getOffset(), fdMapping.getByteSize(), (Double) objVal);
        } else if (objVal instanceof Short) {
            rkBuf.copyBuf(fdMapping.getOffset(), fdMapping.getByteSize(), (Short) objVal);
        } else if (objVal instanceof BigInteger) {
            rkBuf.copyBuf(fdMapping.getOffset(), fdMapping.getByteSize(), ((BigInteger) objVal).toByteArray());
        } else if (objVal instanceof LocalDateTime) {
            rkBuf.copyBuf(fdMapping.getOffset(), fdMapping.getByteSize(), Bytes.toBytes(Timestamp.valueOf((LocalDateTime) objVal).getTime()));
        } else {
            throw new NSException(String.format("mapping not supported type:%s", objVal.getClass().getName()));
        }
    }


}
