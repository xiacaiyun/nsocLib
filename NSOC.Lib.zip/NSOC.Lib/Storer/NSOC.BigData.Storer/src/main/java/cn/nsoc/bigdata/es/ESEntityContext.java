package cn.nsoc.bigdata.es;

import cn.nsoc.bigdata.storer.OpenEntityContext;
import org.springframework.util.Assert;
import org.springframework.util.StringUtils;

/**
 * Created by sam on 17-9-21.
 */
public class ESEntityContext extends OpenEntityContext {

    private String _type;

    public ESEntityContext() {
    }

    public ESEntityContext(String tablename, String type) {
        super(tablename);

        Assert.notNull(tablename);
        Assert.notNull(type);

        set_type(type);
    }

    public String get_type() {
        return StringUtils.hasText(_type) ? _type : getTableName();
    }

    public void set_type(String _type) {
        this._type = _type;
    }
}
