package cn.nsoc.bigdata.storer;

import cn.nsoc.base.entity.sys.NSException;
import cn.nsoc.bigdata.es.ESStorer;
import cn.nsoc.bigdata.hbase.HBaseStorer;
import cn.nsoc.common.storer.Storer;
import org.springframework.util.StringUtils;

/**
 * Created by bobwang on 3/23/17.
 */
public class OpenStorerLoader {

    private OpenStorerLoader() {

    }

    public static Storer createInstance(OpenStorerType storerType, SettingsBuilder configure) throws NSException {
        if (storerType == null) {
            throw new NSException(" store type is null ");
        }

        OpenStorer store;
        switch (storerType) {
            case HBASE:
                store = new HBaseStorer();
                break;
            case ELASTICSEARCH:
                store = new ESStorer();
                break;
            default:
                throw new NSException(String.format("invalidate store type:%s", storerType));
        }
        try {
            store.initialize(configure);
            return store;
        } catch (NSException ex) {
            store.shutdown();
            throw ex;
        }
    }

    public static Storer createInstance(String type, SettingsBuilder configure) throws NSException {

        if (!StringUtils.hasText(type)) {
            throw new NSException(" store type is empty ");
        }

        OpenStorerType storerType = Enum.valueOf(OpenStorerType.class, type.toUpperCase());
        return createInstance(storerType, configure);
    }

    public static Storer createInstance(String type, String configText) throws NSException {
        return createInstance(type, SettingsBuilder.convert(configText));
    }

    public static Storer createInstance(OpenStorerType storerType, String configText) throws NSException {
        return createInstance(storerType, SettingsBuilder.convert(configText));
    }
}
