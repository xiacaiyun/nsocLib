package cn.nsoc.bigdata.storer;


import cn.nsoc.base.entity.define.NSExceptionCode;
import cn.nsoc.base.entity.sys.NSException;
import cn.nsoc.common.storer.EntityCollection;
import cn.nsoc.common.storer.EntityQuery;
import cn.nsoc.common.storer.Storer;
import cn.nsoc.common.storer.context.ContextParser;
import cn.nsoc.common.storer.context.EntityContext;
import cn.nsoc.common.storer.option.InsertBuilder;
import cn.nsoc.common.storer.option.UpdateBuilder;
import org.apache.log4j.Logger;

import java.util.Arrays;
import java.util.List;
import java.util.Map;

/**
 * Created by bobwang on 9/20/16.
 */
public abstract class OpenStorer implements Storer {

    public interface IValueTransform<T, R> {
        R call(String key,T src) throws NSException;
    }

    protected Logger appLogger;

    private ContextParser contextParser;


    public OpenStorer(Class<?> implCls) {
        appLogger = Logger.getLogger(implCls.getSimpleName());
    }


    public void initialize(SettingsBuilder configure) throws NSException {
    }

    @Override
    public boolean insert(Object me) throws NSException {
        return false;
    }

    @Override
    public boolean batchInsert(List<Object> melist) throws NSException {
        return false;
    }

    @Override
    public boolean insert(Object me, InsertBuilder builder) throws NSException {
        return false;
    }

    public boolean insert(Map<String, Object> data, String id, InsertBuilder builder) throws NSException {
        BigDataItem item = new BigDataItem(data, id);
        return insert(item, builder);
    }

    @Override
    public boolean batchInsert(List<Object> melist, InsertBuilder builder) throws NSException {
        return false;
    }

    @Override
    public boolean delete(Object me) throws NSException {
        return false;
    }

    @Override
    public <Q extends EntityQuery> boolean delete(Q query, Class<?> eClass) throws NSException {
        return false;
    }

    @Override
    public boolean update(Object me) throws NSException {
        return false;
    }

    @Override
    public boolean update(Object me, UpdateBuilder builder) throws NSException {
        return false;
    }

    @Override
    public <Q extends EntityQuery> boolean update(Object me, UpdateBuilder builder, Q query) throws NSException {
        return false;
    }

    @Override
    public <E, Q extends EntityQuery, C extends EntityCollection<E,Q>> C load(C me) throws NSException {
        return load(me, null);
    }

    @Override
    public List<Map<String, Object>> exec(String sql) throws NSException {
        throw new NSException(NSExceptionCode.MSG_NOTSUITABLE);
    }


    @Deprecated
    @Override
    public boolean insertKV(Map<String, Object> me, InsertBuilder builder) throws NSException {
        throw new NSException(NSExceptionCode.MSG_NOTSUITABLE);
    }


    protected List<String> enumToSql(Enum e) {
        return Arrays.asList(e.name().replace("__", " ").replace("_", ",").split(","));
    }

    @Override
    public ContextParser getContextParser() {
        return contextParser;
    }

    public void setContextParser(ContextParser contextParser) {
        this.contextParser = contextParser;
    }

    @Override
    public <E, Q extends EntityQuery, C extends EntityCollection<E,Q>> C load(EntityContext context, C me) throws NSException {
        throw new NSException(NSExceptionCode.MSG_NOTIMPLEMENTED);
    }
}
