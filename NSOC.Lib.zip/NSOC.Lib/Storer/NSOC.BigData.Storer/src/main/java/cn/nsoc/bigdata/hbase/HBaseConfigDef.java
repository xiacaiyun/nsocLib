package cn.nsoc.bigdata.hbase;

/**
 * Created by bobwang on 3/23/17.
 */
public class HBaseConfigDef {

    public static final String ADDRESS = "address";
    public static final String PORT = "port";
    public static final String RETRIES_NUM = "retries";
    public static final String AUTHENTICATION = "authentication";
    public static final String CHANNEL_RPC = "rpc";
    public static final String ROW_KEY_MAPPING = "rowkeymapping";
    public static final String DELAY_CLOSE_MIN = "delayclose";
    public static final String MAX_INSTANCE_COUNT = "maxinstance";

    private HBaseConfigDef() {

    }
}
