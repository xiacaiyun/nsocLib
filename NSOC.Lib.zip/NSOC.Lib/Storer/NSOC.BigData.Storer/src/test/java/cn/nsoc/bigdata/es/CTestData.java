package cn.nsoc.bigdata.es;

import cn.nsoc.common.storer.EntityCollection;
import cn.nsoc.common.storer.EntityQuery;
import cn.nsoc.common.storer.annotation.DbField;
import cn.nsoc.common.storer.annotation.DbQuery;
import cn.nsoc.common.storer.annotation.DbTable;
import cn.nsoc.common.storer.annotation.QueryOperator;

import java.time.LocalDateTime;
import java.util.List;

/**
 * Created by chenxl on 2017/7/21.
 * updated by chenxl on 2017/8/10.
 */
public class CTestData {
    @DbTable(name = "es_testdata")
    public static class Entity {
        @DbField(isKey = true)
        private Long a;
        private String likeB;
        private boolean likeC;
        private Long likeD;
        private Integer inF;
        private String likeG;
        private Integer lessThanH;
        private Integer j;
        private Integer notInK;
        private Integer l;
        private String eq;
        private Integer greatEqualNN;
        private String p;
        private Integer lessEqualT;
        private Integer greatThanS;
        private LocalDateTime equalDtime;
        //private List<Long> arrayLists;

        public Integer getGreatEqualNN() {
            return greatEqualNN;
        }

        public void setGreatEqualNN(Integer greatEqualNN) {
            this.greatEqualNN = greatEqualNN;
        }

        public Long getA() {
            return a;
        }

        public void setA(Long a) {
            this.a = a;
        }

        public String getLikeB() {
            return likeB;
        }

        public void setLikeB(String likeB) {
            this.likeB = likeB;
        }

        public boolean isLikeC() {
            return likeC;
        }

        public void setLikeC(boolean likeC) {
            this.likeC = likeC;
        }

        public Long getLikeD() {
            return likeD;
        }

        public void setLikeD(Long likeD) {
            this.likeD = likeD;
        }

        public Integer getInF() {
            return inF;
        }

        public void setInF(Integer inF) {
            this.inF = inF;
        }

        public String getLikeG() {
            return likeG;
        }

        public void setLikeG(String likeG) {
            this.likeG = likeG;
        }

        public Integer getLessThanH() {
            return lessThanH;
        }

        public void setLessThanH(Integer lessThanH) {
            this.lessThanH = lessThanH;
        }

        public Integer getJ() {
            return j;
        }

        public void setJ(Integer j) {
            this.j = j;
        }

        public Integer getNotInK() {
            return notInK;
        }

        public void setNotInK(Integer notInK) {
            this.notInK = notInK;
        }

        public Integer getL() {
            return l;
        }

        public void setL(Integer l) {
            this.l = l;
        }

        public String getP() {
            return p;
        }

        public void setP(String p) {
            this.p = p;
        }

        public Integer getLessEqualT() {
            return lessEqualT;
        }

        public void setLessEqualT(Integer lessEqualT) {
            this.lessEqualT = lessEqualT;
        }

        public Integer getGreatThanS() {
            return greatThanS;
        }

        public void setGreatThanS(Integer greatThanS) {
            this.greatThanS = greatThanS;
        }

        public String getEq() {
            return eq;
        }

        public void setEq(String eq) {
            this.eq = eq;
        }

        public LocalDateTime getEqualDtime() {
            return equalDtime;
        }

        public void setEqualDtime(LocalDateTime equalDtime) {
            this.equalDtime = equalDtime;
        }


    }

    public static class Query extends EntityQuery {

        @DbField(isKey = true)
        private Long a;

        public Long getA() {
            return a;
        }

        public void setA(Long a) {
            this.a = a;
        }

        enum OrderByEnum {
            likeD__desc,
            likeD,
            a,
            a__desc
        }

        enum GroupByEnum {
            likeD,
            likeD_inF
        }

        @DbQuery(Operator = QueryOperator.LessThan)
        private Integer tolessThanH;

        @DbQuery(Operator = QueryOperator.Equal)
        private LocalDateTime equalDtime;
        //private String p;

        @DbQuery(Operator = QueryOperator.LessEqual)
        private Integer tolessEqualT;

        @DbQuery(Operator = QueryOperator.IsOrNotNull)
        private Boolean eqIsOrNotNull;

        @DbQuery(Operator = QueryOperator.GreatThan)
        private Integer FromgreatThanS;

        @DbQuery(Operator = QueryOperator.GreatEqual)
        private Integer FromgreatEqualNN;

        @DbQuery(Operator = QueryOperator.NotIn, valueType = Long.class)
        private List<Long> likeDNotInIDList;
        private Integer notInK;

        @DbQuery(Operator = QueryOperator.Like)
        private String likeB;
        private Boolean likeC;
        private Long likeD;


        @DbQuery(Operator = QueryOperator.In, valueType = Long.class)
        private List<Long> likeDIDList;
        private Integer inF;

        @DbQuery(Operator = QueryOperator.Like)
        private String likeG;

        public List<Long> getaNotInIDList() {
            return likeDNotInIDList;
        }

        public List<Long> getLikeDNotInIDList() {
            return likeDNotInIDList;
        }

        public void setLikeDNotInIDList(List<Long> likeDNotInIDList) {
            this.likeDNotInIDList = likeDNotInIDList;
        }

        public List<Long> getLikeDIDList() {
            return likeDIDList;
        }

        public void setLikeDIDList(List<Long> likeDIDList) {
            this.likeDIDList = likeDIDList;
        }

        public Integer getTolessEqualT() {
            return tolessEqualT;
        }

        public void setTolessEqualT(Integer tolessEqualT) {
            this.tolessEqualT = tolessEqualT;
        }


        public Integer getNotInK() {
            return notInK;
        }

        public void setNotInK(Integer notInK) {
            this.notInK = notInK;
        }

        public String getLikeB() {
            return likeB;
        }

        public void setLikeB(String likeB) {
            this.likeB = likeB;
        }

        public Boolean getLikeC() {
            return likeC;
        }

        public void setLikeC(Boolean likeC) {
            this.likeC = likeC;
        }

        public Long getLikeD() {
            return likeD;
        }

        public void setLikeD(Long likeD) {
            this.likeD = likeD;
        }


        public Integer getInF() {
            return inF;
        }

        public void setInF(Integer inF) {
            this.inF = inF;
        }

        public String getLikeG() {
            return likeG;
        }

        public void setLikeG(String likeG) {
            this.likeG = likeG;
        }

        public boolean isEqIsOrNotNull() {
            return eqIsOrNotNull;
        }

        public void setEqIsOrNotNull(boolean eqIsOrNotNull) {
            this.eqIsOrNotNull = eqIsOrNotNull;
        }

        public Integer getTolessThanH() {
            return tolessThanH;
        }

        public void setTolessThanH(Integer tolessThanH) {
            this.tolessThanH = tolessThanH;
        }

        public Integer getFromgreatThanS() {
            return FromgreatThanS;
        }

        public void setFromgreatThanS(Integer fromgreatThanS) {
            FromgreatThanS = fromgreatThanS;
        }

        public Integer getFromgreatEqualNN() {
            return FromgreatEqualNN;
        }

        public void setFromgreatEqualNN(Integer fromgreatEqualNN) {
            FromgreatEqualNN = fromgreatEqualNN;
        }

        public LocalDateTime getEqualDtime() {
            return equalDtime;
        }

        public void setEqualDtime(LocalDateTime equalDtime) {
            this.equalDtime = equalDtime;
        }
    }

    public static class Coll extends EntityCollection<Entity, Query> {

        public Coll() {
            super(Entity.class, Query.class);
        }

        public Coll(Query query) {
            this();

            setQuery(query);
        }
    }
}
