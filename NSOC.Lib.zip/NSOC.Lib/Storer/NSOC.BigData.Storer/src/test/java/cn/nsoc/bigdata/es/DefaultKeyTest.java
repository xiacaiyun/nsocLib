package cn.nsoc.bigdata.es;

import junit.framework.TestCase;
import org.elasticsearch.common.settings.ClusterSettings;
import org.elasticsearch.common.settings.Setting;
import java.util.Set;

public class DefaultKeyTest extends TestCase{
    Set<Setting<?>> set;
    @Override
    public void setUp() throws Exception {
        super.setUp();
        set = ClusterSettings.BUILT_IN_CLUSTER_SETTINGS;
    }

    public void testKey() {
        for (Setting<?> aSet : set) {
            String key = aSet.getKey();
            System.out.println(key);
        }
    }

}
