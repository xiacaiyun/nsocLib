package cn.nsoc.bigdata.es;

import cn.nsoc.base.entity.sys.NSException;
import cn.nsoc.bigdata.storer.BigDataItem;
import cn.nsoc.bigdata.storer.OpenStorerLoader;
import cn.nsoc.bigdata.storer.OpenStorerType;
import cn.nsoc.bigdata.storer.SettingsBuilder;
import cn.nsoc.common.storer.context.EntityContext;

import java.util.*;

public class ESStoreConcurrentTest {
    public static void main(String ... args) throws NSException {
        SettingsBuilder setBuilder = new SettingsBuilder();
        setBuilder.put("cluster.name", "elasticsearch_nsoc");
        setBuilder.put("host", "192.168.1.123:9300,192.168.1.122:9300,192.168.1.121:9300");
        setBuilder.put("client.transport.sniff",false);
		settingsBuilder.put("transport.connections_per_node.bulk", 6);
        settingsBuilder.put("bulkActions", 2000);
        settingsBuilder.put("concurrentRequests", 2);
        settingsBuilder.put("flushInterval", 60); //5s
        settingsBuilder.put("bo.time", 100); //100ms
        settingsBuilder.put("bo.retry", 8);
        settingsBuilder.put("bulkSize", 10); //5M
		ESStorer storer = (ESStorer) OpenStorerLoader.createInstance(OpenStorerType.ELASTICSEARCH, setBuilder);
        Random random = new Random();
        for(int i = 0; i < 4; i ++) {
            new Thread(
                    new InsertThread(storer,
                            "test_concurrent",
                            "test",
                            1000,
                            10000)).start();
        }
    }
}

class InsertThread implements Runnable {
    private ESStorer storer;
    private int insertNumber, onceInsertNumber;
    private String index, type;

    public InsertThread(ESStorer storer, String index, String type, int insertNumber, int onceInsertNumber) {
        this.storer = storer;
        this.index = index;
        this.type = type;
        this.insertNumber = insertNumber;
        this.onceInsertNumber = onceInsertNumber;
    }

    @Override
    public void run() {
        Random random = new Random();
        for(int batchCount = 0; batchCount < insertNumber; batchCount ++) {
            List<Object> list = new ArrayList<>();
            for (long counter = 0; counter < onceInsertNumber; counter++) {

                Map<String, Object> map = new HashMap<>();
                map.put("U1", System.currentTimeMillis());
                map.put("U2", UUID.randomUUID());
                map.put("U3", random.nextInt());
                map.put("U4", random.nextLong());
                map.put("U5", UUID.randomUUID());
                map.put("U6", UUID.randomUUID());

                list.add(new BigDataItem(map, UUID.randomUUID()));
            }

            EntityContext ctx = new EntityContext();
            ctx.setTableName("text");
            ESInsertBuilder ib = new ESInsertBuilder(new ESEntityContext(index,type));
            try {
                storer.batchInsert(list, ib);
            } catch (NSException e) {
                e.printStackTrace();
            }
        }
    }
}
