package cn.nsoc.bigdata.es;

import cn.nsoc.base.entity.sys.NSException;
import cn.nsoc.bigdata.storer.BigDataItem;
import cn.nsoc.bigdata.storer.OpenStorerLoader;
import cn.nsoc.bigdata.storer.OpenStorerType;
import cn.nsoc.bigdata.storer.SettingsBuilder;
import cn.nsoc.common.storer.annotation.QueryOperator;
import cn.nsoc.common.storer.context.EntityContext;
import cn.nsoc.common.storer.option.InsertBuilder;
import cn.nsoc.common.storer.option.QueryBuilder;
import junit.framework.TestCase;
import org.elasticsearch.common.settings.ClusterSettings;
import org.elasticsearch.common.settings.Setting;
import org.elasticsearch.common.settings.Settings;

import java.time.LocalDateTime;
import java.time.ZoneOffset;
import java.util.*;

/**
 * Created by sam on 17-7-27.
 * updated by chenxiling 17-8-10
 */
public class ESStorerTest extends TestCase {

    ESStorer storer;
    String indexname = "es_testdata1";


    public void setUp() throws Exception {
        super.setUp();


        SettingsBuilder setBuilder = new SettingsBuilder();
        setBuilder.put("cluster.name", "elasticsearch_nsoc");
        setBuilder.put("host", "192.168.1.122:9300");
        setBuilder.put("client.transport.sniff",false);
        setBuilder.put("transport.connections_per_node.bulk", 6);
        setBuilder.put("transport.connections_per_node.reg", 6);
        storer = (ESStorer) OpenStorerLoader.createInstance(OpenStorerType.ELASTICSEARCH, setBuilder);
    }

    //测试插入操作
    public void testInsert() throws Exception {

        Map<String, Object> map = new HashMap<>();
        map.put("name", "single");
        map.put("key", "hhhhh");


        long id = LocalDateTime.now().toEpochSecond(ZoneOffset.UTC);

        map.put("counter", id);
        EntityContext ctx = (ESEntityContext)storer.getContextParser().createEntityContext();
        ctx.setTableName(indexname);
        InsertBuilder ib = storer.createInsertBuilder(ctx);

        storer.insert(map, Long.toString(id), ib);
    }
    //测试批量插入操作
    public void testBatchInsert() throws Exception {

        List<Object> list = new ArrayList();
        for (long counter = 0; counter < 99; counter++) {

            Map<String, Object> map = new HashMap<>();
            map.put("name", "batch");
            map.put("key", "kkkkk");

            long id = LocalDateTime.now().toEpochSecond(ZoneOffset.UTC);
            long temp = id * 1000 + counter;
            map.put("counter", temp);

            list.add(new BigDataItem(map, temp));
        }

        EntityContext ctx = new EntityContext();
        ctx.setTableName("text");
        ESInsertBuilder ib = new ESInsertBuilder(new ESEntityContext(indexname,indexname));
        storer.batchInsert(list, ib);
    }

    public void testBatchInsert1() throws NSException {

        long t1 = System.currentTimeMillis();
        for(int batchCount = 0; batchCount < 1; batchCount ++) {
            List<Object> list = new ArrayList<>();
            for(long counter = 0; counter < 5; counter ++) {
                Map<String, Object> map = new HashMap<>();
                map.put("U1", UUID.randomUUID());
                map.put("U2", UUID.randomUUID());
                map.put("U3", UUID.randomUUID());
                map.put("U4", UUID.randomUUID());
                list.add(new BigDataItem(map, UUID.randomUUID()));
            }

            ESInsertBuilder ib = new ESInsertBuilder(new ESEntityContext("test_conn", "test_conn"));
            long tt1 = System.currentTimeMillis();
            storer.batchInsert(list, ib);
            long tt2 = System.currentTimeMillis();
            System.out.println("One time: " + (tt2 - tt1)/1000D);
        }
        long t2 = System.currentTimeMillis();
        System.out.println("TIME: " + (t2 - t1)/1000D);
    }

    //测试查询操作
    public void testQuery() throws Exception {

        EntityContext ctx = new EntityContext();
        ctx.setTableName("text");
        QueryBuilder queryBuilder=new QueryBuilder();
        queryBuilder.add("name", QueryOperator.Equal,"single");

    }

}