package cn.nsoc.bigdata.es;

import cn.nsoc.base.entity.sys.NSException;
import cn.nsoc.bigdata.storer.OpenStorerLoader;
import cn.nsoc.bigdata.storer.SettingsBuilder;
import cn.nsoc.common.util.IDWorker;
import junit.framework.TestCase;
import org.springframework.util.Assert;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Arrays;


/**
 * Created by sam on 17-8-3.
 * updated by chenxiling on 17-8-10.
 */
public class ESStorerEntityTest extends TestCase {
    ESStorer storer;

    LocalDateTime ldt = LocalDateTime.now();

    public void setUp() throws Exception {
        super.setUp();

        SettingsBuilder setBuilder = new SettingsBuilder();
        setBuilder.put("cluster.name", "nsoc-es-cluster");
        setBuilder.put("host", "192.168.1.27:9300,192.168.1.27:9301,192.168.1.27:9302");
        setBuilder.put("client.transport.sniff", false);

        storer = (ESStorer) OpenStorerLoader.createInstance("ElasticSearch", setBuilder);
    }

    public void testAInsert() throws NSException {

        CTestData.Entity entity = new CTestData.Entity();
        entity.setLikeB("ceshi98");
        entity.setLikeC(true);
        entity.setLikeD(1521L);
        entity.setInF(987);
        entity.setLikeG("测试836");
        entity.setLessThanH(567);
        entity.setJ(803);
        entity.setNotInK(134);
        entity.setL(284);
        entity.setGreatThanS(463);
        entity.setGreatEqualNN(368);
        entity.setP("Equa777");
        entity.setLessEqualT(666);
        entity.setEq("ceshi08");
        entity.setEqualDtime(ldt);

        entity.setA(IDWorker.NextID());
        boolean ret = storer.insert(entity);
        assertTrue(ret);
    }

    public void testLoadWithGroupBy() throws Exception {
        CTestData.Entity entity = new CTestData.Entity();
        entity.setLikeB("ceshi");
        entity.setLikeC(true);
        entity.setLikeD(1521L);
        entity.setInF(671);
        entity.setLikeG("测试6");
        entity.setLessThanH(800);
        entity.setJ(161);
        entity.setNotInK(333);
        entity.setL(667);
        entity.setGreatThanS(979);
        entity.setGreatEqualNN(166);
        entity.setP("Equalstr6");
        entity.setLessEqualT(666);
        entity.setEq("ceshi08");
        entity.setEqualDtime(ldt);

        Long newid = IDWorker.NextID();
        entity.setA(newid);
        boolean ret = storer.insert(entity);
        assertTrue(ret);

        Thread.sleep(3000);

        CTestData.Coll coll = new CTestData.Coll();
        CTestData.Query query = coll.getQuery();

        query.setLikeB("ceshi");
        query.count = 1;
        query.groupBy = CTestData.Query.GroupByEnum.likeD;
        storer.load(coll);

        query.groupBy = CTestData.Query.GroupByEnum.likeD_inF;
        storer.load(coll);

        assertTrue(!coll.isEmpty());
    }

    public void testLoadWithQueryKey() throws Exception {

        CTestData.Entity entity = new CTestData.Entity();
        entity.setLikeB("ceshi6");
        entity.setLikeC(true);
        entity.setLikeD(1521L);
        entity.setInF(671);
        entity.setLikeG("测试6");
        entity.setLessThanH(800);
        entity.setJ(161);
        entity.setNotInK(333);
        entity.setL(667);
        entity.setGreatThanS(979);
        entity.setGreatEqualNN(166);
        entity.setP("Equalstr6");
        entity.setLessEqualT(666);
        entity.setEq("ceshi08");
        entity.setEqualDtime(ldt);

        Long newid = IDWorker.NextID();
        entity.setA(newid);
        boolean ret = storer.insert(entity);
        assertTrue(ret);

        Thread.sleep(3000);
        CTestData.Coll coll = new CTestData.Coll();
        CTestData.Query query = coll.getQuery();

        query.setA(newid);
        query.count = 10;
        Thread.sleep(1000);
        storer.load(coll);
        assertTrue(coll.size() == 1);
        assertTrue(coll.firstOrDefault().getA().equals(newid));
    }

    public void testLoadWithIDList() throws Exception {

        CTestData.Entity entity = new CTestData.Entity();
        entity.setLikeB("ceshi6");
        entity.setLikeC(true);
        entity.setLikeD(1421L);
        entity.setInF(671);
        entity.setLikeG("测试6");
        entity.setLessThanH(800);
        entity.setJ(161);
        entity.setNotInK(333);
        entity.setL(667);
        entity.setGreatThanS(979);
        entity.setGreatEqualNN(166);
        entity.setP("Equalstr6");
        entity.setLessEqualT(666);
        entity.setEq("ceshi08");
        entity.setEqualDtime(ldt);

        Long newid = IDWorker.NextID();
        entity.setA(newid);
        boolean ret = storer.insert(entity);

        assertTrue(ret);
        Thread.sleep(3000);
        CTestData.Coll coll = new CTestData.Coll();
        CTestData.Query query = coll.getQuery();


        query.setLikeDNotInIDList(Arrays.asList(1521L, 1421L));
        query.setLikeD(1421L);
        query.count = 10;
        storer.load(coll);

        assertTrue(!coll.isEmpty());
    }

    public void testLoadWithSortOrder() throws Exception {
        CTestData.Entity entity = new CTestData.Entity();
        entity.setLikeB("ceshi6");
        entity.setLikeC(true);
        entity.setLikeD(1421L);
        entity.setInF(671);
        entity.setLikeG("测试6");
        entity.setLessThanH(800);
        entity.setJ(161);
        entity.setNotInK(333);
        entity.setL(667);
        entity.setGreatThanS(979);
        entity.setGreatEqualNN(166);
        entity.setP("Equalstr6");
        entity.setLessEqualT(666);
        entity.setEq("ceshi08");
        entity.setEqualDtime(ldt);

        Long newid = IDWorker.NextID();
        entity.setA(newid);
        boolean ret = storer.insert(entity);
        assertTrue(ret);

        Thread.sleep(3000);
        CTestData.Entity entity1 = new CTestData.Entity();
        entity.setLikeD(1521L);
        entity.setInF(671);
        entity.setLikeG("测试6");
        entity.setLessThanH(800);
        entity.setJ(161);
        entity.setNotInK(333);
        entity.setL(667);
        entity.setEqualDtime(ldt);
        entity.setEq("ceshi08");
        Long newid2 = IDWorker.NextID();
        entity.setA(newid);
        boolean ret1 = storer.insert(entity);
        assertTrue(ret1);

        CTestData.Coll coll = new CTestData.Coll();
        CTestData.Query query = coll.getQuery();

        Long val, val1;

        query.orderBy = CTestData.Query.OrderByEnum.likeD;
        query.count = 10;
        storer.load(coll);
        val = coll.firstOrDefault().getLikeD();

        query.orderBy = CTestData.Query.OrderByEnum.likeD__desc;
        query.count = 10;
        storer.load(coll);
        val1 = coll.firstOrDefault().getLikeD();
        assertTrue(val < val1);



        query.orderBy = CTestData.Query.OrderByEnum.a;
        query.count = 10;
        storer.load(coll);
        val = coll.firstOrDefault().getA();

        query.orderBy = CTestData.Query.OrderByEnum.a__desc;
        query.count = 10;
        storer.load(coll);
        val1 = coll.firstOrDefault().getA();
        assertTrue(val < val1);
    }

    public void testLoad() throws Exception {
        CTestData.Entity entity = new CTestData.Entity();
        entity.setLikeB("ceshi");
        entity.setLikeC(true);
        entity.setLikeD(1521L);
        entity.setInF(671);
        entity.setLikeG("测试");
        entity.setLessThanH(800);
        entity.setJ(161);
        entity.setNotInK(333);
        entity.setL(667);
        entity.setGreatThanS(979);
        entity.setGreatEqualNN(166);
        entity.setP("Equalstr6");
        entity.setLessEqualT(666);
        entity.setEq("ceshi08");
        entity.setEqualDtime(ldt);

        Long newid = IDWorker.NextID();
        entity.setA(newid);
        boolean ret = storer.insert(entity);
        assertTrue(ret);
        Thread.sleep(3000);
        CTestData.Coll coll = new CTestData.Coll();
        CTestData.Query query = coll.getQuery();

        query = new CTestData.Query();
        query.setLikeB("ceshi");
        coll.setQuery(query);
        //query.count = 100;
        storer.load(coll);
        assertTrue(coll.size() > 0);

        query.setLikeD(1521L);
        //query.count = 100;
        storer.load(coll);
        assertTrue(coll.size() > 0);

        query = new CTestData.Query();
        query.setLikeB("ceshi");
        query.setLikeD(1500L);
        coll.setQuery(query);
        //query.count = 100;
        storer.load(coll);
        assertTrue(coll.isEmpty());

        query = new CTestData.Query();
        query.setLikeB("ceshi");
        query.setLikeG("测试");
        coll.setQuery(query);
        //  query.count = 100;
        storer.load(coll);
        assertTrue(!coll.isEmpty());

    }

    //测试操作 In 操作
    public void testIn() throws Exception {
        CTestData.Entity entity = new CTestData.Entity();
        entity.setLikeB("ceshi6");
        entity.setLikeC(true);
        entity.setLikeD(1521L);
        entity.setInF(67890);
        entity.setLikeG("测试6");
        entity.setLessThanH(800);
        entity.setJ(161);
        entity.setNotInK(333);
        entity.setL(667);
        entity.setGreatThanS(979);
        entity.setGreatEqualNN(500);
        entity.setP("Equalstr6");
        entity.setLessEqualT(666);
        entity.setEq("ceshi08");
        entity.setEqualDtime(ldt);

        Long newid = IDWorker.NextID();
        entity.setA(newid);
        boolean ret = storer.insert(entity);
        assertTrue(ret);
        Thread.sleep(3000);
        CTestData.Coll coll = new CTestData.Coll();
        CTestData.Query query = coll.getQuery();

        //声明数组对象
        ArrayList<Long> listTest = new ArrayList<Long>();
        listTest.add(12345l);
        listTest.add(67890l);
        listTest.add(1233l);
        listTest.add(12336l);

        query.setLikeDIDList(listTest);
        query.setInF(67890);
        coll.setQuery(query);
        storer.load(coll);
        assertTrue(coll.isEmpty());

    }

    //测试操作 NotIn 操作
    public void testNotIn() throws Exception {
        CTestData.Entity entity = new CTestData.Entity();
        entity.setLikeB("ceshi008");
        entity.setLikeC(true);
        entity.setLikeD(333l);
        entity.setInF(671);
        entity.setLikeG("测试6");
        entity.setLessThanH(800);
        entity.setJ(161);
        entity.setNotInK(333);
        entity.setL(667);
        entity.setGreatThanS(979);
        entity.setGreatEqualNN(500);
        entity.setP("Equalstr6");
        entity.setLessEqualT(666);
        entity.setEq("ceshi08");
        entity.setEqualDtime(ldt);

        Long newid = IDWorker.NextID();
        entity.setA(newid);
        boolean ret = storer.insert(entity);
        assertTrue(ret);
        Thread.sleep(3000);
        CTestData.Coll coll = new CTestData.Coll();
        CTestData.Query query = coll.getQuery();

        //声明数组对象
        ArrayList<Long> listTest = new ArrayList<Long>();
        listTest.add(12345l);
        listTest.add(1234l);
        listTest.add(333l);
        listTest.add(12336l);

        query.setLikeDNotInIDList(listTest);
        query.setLikeD(333l);
        coll.setQuery(query);
        storer.load(coll);
        assertTrue(!coll.isEmpty());

        query.setLikeDNotInIDList(listTest);
        query.setLikeD(33634l);
        coll.setQuery(query);
        storer.load(coll);
        assertTrue(coll.isEmpty());
    }

    //测试操作 Like 操作
    public void testLike() throws Exception {
        CTestData.Entity entity = new CTestData.Entity();
        entity.setLikeB("ceshi");
        entity.setLikeC(true);
        entity.setLikeD(333l);
        entity.setInF(671);
        entity.setLikeG("测试6");
        entity.setLessThanH(800);
        entity.setJ(161);
        entity.setNotInK(333);
        entity.setL(667);
        entity.setGreatThanS(979);
        entity.setGreatEqualNN(500);
        entity.setP("Equalstr6");
        entity.setLessEqualT(666);
        entity.setEq("ceshi08");
        entity.setEqualDtime(ldt);

        Long newid = IDWorker.NextID();
        entity.setA(newid);
        boolean ret = storer.insert(entity);
        assertTrue(ret);
        Thread.sleep(3000);
        CTestData.Coll coll = new CTestData.Coll();
        CTestData.Query query = coll.getQuery();


        query.setLikeC(true);
        coll.setQuery(query);
        storer.load(coll);
        assertTrue(!coll.isEmpty());

        query.setLikeB("ceshi");
        coll.setQuery(query);
        storer.load(coll);
        assertTrue(!coll.isEmpty());

        query.setLikeB("ceshi0009");
        coll.setQuery(query);
        storer.load(coll);
        assertTrue(coll.isEmpty());


        query.setLikeB("ceshi");
        query.setLikeC(true);
        coll.setQuery(query);
        storer.load(coll);
        assertTrue(!coll.isEmpty());

        query.setLikeB("ceshi10011");
        query.setLikeC(false);
        coll.setQuery(query);
        storer.load(coll);
        assertTrue(coll.isEmpty());
        entity.setEq("ceshi08");
        query.setLikeB("ceshi008");
        query.setLikeC(true);
        query.setLikeD(1822L);
        coll.setQuery(query);
        storer.load(coll);
        assertTrue(coll.isEmpty());

        query.setLikeB("ceshi数据10011");
        query.setLikeC(false);
        query.setLikeD(15291L);
        coll.setQuery(query);
        storer.load(coll);
        assertTrue(coll.isEmpty());

    }

    //测试操作 LessThan 操作
    public void testLessThan() throws Exception {
        CTestData.Entity entity = new CTestData.Entity();
        entity.setLikeB("ceshi");
        entity.setLikeC(true);
        entity.setLikeD(333l);
        entity.setInF(671);
        entity.setLikeG("测试6");
        entity.setLessThanH(600);
        entity.setJ(161);
        entity.setNotInK(333);
        entity.setL(667);
        entity.setGreatThanS(979);
        entity.setGreatEqualNN(500);
        entity.setP("Equalstr6");
        entity.setLessEqualT(666);
        entity.setEq("ceshi08");
        entity.setEqualDtime(ldt);

        Long newid = IDWorker.NextID();
        entity.setA(newid);
        boolean ret = storer.insert(entity);
        assertTrue(ret);
        Thread.sleep(3000);
        CTestData.Coll coll = new CTestData.Coll();
        CTestData.Query query = coll.getQuery();

        query.setTolessThanH(1);
        coll.setQuery(query);
        storer.load(coll);
        assertTrue(coll.isEmpty());

        query.setTolessThanH(610);
        coll.setQuery(query);
        storer.load(coll);
        assertTrue(!coll.isEmpty());

        query.setTolessThanH(20000);
        coll.setQuery(query);
        storer.load(coll);
        assertTrue(!coll.isEmpty());

    }

    //测试操作 LessEqual 操作
    public void testLessEqual() throws Exception {

        CTestData.Entity entity = new CTestData.Entity();
        entity.setLikeB("ceshi");
        entity.setLikeC(true);
        entity.setLikeD(333l);
        entity.setInF(671);
        entity.setLikeG("测试6");
        entity.setLessThanH(800);
        entity.setJ(161);
        entity.setNotInK(333);
        entity.setL(667);
        entity.setGreatThanS(979);
        entity.setGreatEqualNN(500);
        entity.setP("Equalstr6");
        entity.setLessEqualT(666);
        entity.setEq("ceshi08");
        entity.setEqualDtime(ldt);

        Long newid = IDWorker.NextID();
        entity.setA(newid);
        boolean ret = storer.insert(entity);
        assertTrue(ret);
        Thread.sleep(5000);

        CTestData.Coll coll = new CTestData.Coll();
        CTestData.Query query = coll.getQuery();

        query.setTolessEqualT(666);
        coll.setQuery(query);
        storer.load(coll);
        assertTrue(!coll.isEmpty());

        query.setTolessEqualT(600);
        coll.setQuery(query);
        storer.load(coll);
        assertTrue(coll.isEmpty());

        query.setTolessEqualT(0);
        coll.setQuery(query);
        storer.load(coll);
        assertTrue(coll.isEmpty());
    }

    //    //测试操作 IsOrNotNull 操作
    public void testIsOrNotNull() throws Exception {
        CTestData.Entity entity = new CTestData.Entity();
        entity.setLikeB("ceshi");
        entity.setLikeC(true);

        entity.setEq("ceshi08");
        entity.setEqualDtime(ldt);

        Long newid = IDWorker.NextID();
        entity.setA(newid);
        boolean ret = storer.insert(entity);
        assertTrue(ret);
        Thread.sleep(5000);

        CTestData.Coll coll = new CTestData.Coll();
        CTestData.Query query = coll.getQuery();

        query.setEqIsOrNotNull(true);
        coll.setQuery(query);
        storer.load(coll);
        assertTrue(!coll.isEmpty());

        for (CTestData.Entity e : coll) {
            Assert.notNull(e.getEq());
        }

        query.setEqIsOrNotNull(false);
        coll.setQuery(query);
        storer.load(coll);
        assertTrue(!coll.isEmpty());


        for (CTestData.Entity e : coll) {
            Assert.isNull(e.getEq());
        }
    }


    //测试操作 GreatThan 操作
    public void testGreatThan() throws Exception {

        CTestData.Entity entity = new CTestData.Entity();
        entity.setLikeB("ceshi");
        entity.setLikeC(true);
        entity.setLikeD(333l);
        entity.setInF(671);
        entity.setLikeG("测试6");
        entity.setLessThanH(800);
        entity.setJ(161);
        entity.setNotInK(333);
        entity.setL(667);
        entity.setGreatThanS(710);
        entity.setGreatEqualNN(500);
        entity.setP("Equalstr6");
        entity.setLessEqualT(666);
        entity.setEq("ceshi08");
        entity.setEqualDtime(ldt);

        Long newid = IDWorker.NextID();
        entity.setA(newid);
        boolean ret = storer.insert(entity);
        assertTrue(ret);
        Thread.sleep(5000);
        CTestData.Coll coll = new CTestData.Coll();
        CTestData.Query query = coll.getQuery();

        query.setFromgreatThanS(700);
        coll.setQuery(query);
        storer.load(coll);
        assertTrue(!coll.isEmpty());

        query.setFromgreatThanS(700000);
        coll.setQuery(query);
        storer.load(coll);
        assertTrue(coll.isEmpty());
    }

    //测试操作 GreatEqual 操作
    public void testGreatEqual() throws Exception {
        CTestData.Entity entity = new CTestData.Entity();
        entity.setLikeB("ceshi6");
        entity.setLikeC(true);
        entity.setLikeD(1521L);
        entity.setInF(671);
        entity.setLikeG("测试6");
        entity.setLessThanH(800);
        entity.setJ(161);
        entity.setNotInK(333);
        entity.setL(667);
        entity.setGreatThanS(979);
        entity.setGreatEqualNN(666);
        entity.setP("Equalstr6");
        entity.setLessEqualT(666);
        entity.setEq("ceshi08");
        entity.setEqualDtime(ldt);

        Long newid = IDWorker.NextID();
        entity.setA(newid);
        boolean ret = storer.insert(entity);
        assertTrue(ret);
        Thread.sleep(3000);
        CTestData.Coll coll = new CTestData.Coll();
        CTestData.Query query = coll.getQuery();

        query.setFromgreatEqualNN(666);
        coll.setQuery(query);
        storer.load(coll);
        assertTrue(!coll.isEmpty());

        query.setFromgreatEqualNN(8888888);
        coll.setQuery(query);
        storer.load(coll);
        assertTrue(coll.isEmpty());

        query.setFromgreatEqualNN(500);
        coll.setQuery(query);
        storer.load(coll);
        assertTrue(!coll.isEmpty());
    }

    //测试操作 Equal 操作
    public void testLocalDateTimeEqual() throws Exception {
        CTestData.Entity entity = new CTestData.Entity();
        entity.setEqualDtime(ldt);
        Long newid = IDWorker.NextID();
        entity.setA(newid);
        entity.setEq("ceshi08");
        entity.setA(12345L);
        boolean ret = storer.insert(entity);
        assertTrue(ret);
        Thread.sleep(3000);
        CTestData.Coll coll = new CTestData.Coll();
        CTestData.Query query = coll.getQuery();

        query.setEqualDtime(ldt);
        coll.setQuery(query);
        storer.load(coll);
        assertTrue(!coll.isEmpty());
    }

}
