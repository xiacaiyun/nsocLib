package cn.nsoc.bigdata.hb;

import cn.nsoc.bigdata.hbase.HBaseConfigDef;
import cn.nsoc.bigdata.hbase.HBaseInsertBuilder;
import cn.nsoc.bigdata.hbase.HBaseStorer;
import cn.nsoc.bigdata.storer.*;
import junit.framework.TestCase;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Created by bobwang on 9/14/17.
 */
public class HBBulkInsert extends TestCase {

    private HBaseStorer storer;

    public void setUp() throws Exception {
        super.setUp();
        SettingsBuilder setBuilder = new SettingsBuilder();
        setBuilder.put(HBaseConfigDef.ADDRESS, "192.168.1.123,192.168.1.122,192.168.1.121");
        setBuilder.put(HBaseConfigDef.PORT, "2181");
        storer = (HBaseStorer) OpenStorerLoader.createInstance(OpenStorerType.HBASE, setBuilder);
    }

    public void testBulkInsert() throws Exception{
        System.out.println("fireBulkInsert");
        String             tableName     = "dev_test";
        HBaseInsertBuilder insertBuilder = new HBaseInsertBuilder(new OpenEntityContext(tableName));
        insertBuilder.setFamily("contact_info");
        List<Object> rows = new ArrayList<>();

        try {
            LocalDateTime dtNow = LocalDateTime.now();
            for (int nItemIndex = 0; nItemIndex < 10; nItemIndex++) {
                Map<String, Object> row = new HashMap<>();
                row.put("seq", nItemIndex);
                row.put("nano", dtNow.getNano());
                row.put("time", LocalDateTime.now().toLocalTime());
                rows.add(new BigDataItem(row, String.format("row_%s_%d",  System.getenv("USERNAME"), nItemIndex)));
            }
            storer.batchInsert(rows, insertBuilder);
        } catch (Exception exp) {
            exp.printStackTrace();
        }
    }
}
